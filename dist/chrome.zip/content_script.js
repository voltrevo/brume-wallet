/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
var __webpack_exports__ = {};

;// CONCATENATED MODULE: ./node_modules/@swc/helpers/esm/_class_apply_descriptor_get.js
function _class_apply_descriptor_get(receiver, descriptor) {
    if (descriptor.get) return descriptor.get.call(receiver);

    return descriptor.value;
}


;// CONCATENATED MODULE: ./node_modules/@swc/helpers/esm/_class_extract_field_descriptor.js
function _class_extract_field_descriptor(receiver, privateMap, action) {
    if (!privateMap.has(receiver)) throw new TypeError("attempted to " + action + " private field on non-instance");

    return privateMap.get(receiver);
}


;// CONCATENATED MODULE: ./node_modules/@swc/helpers/esm/_class_private_field_get.js



function _class_private_field_get(receiver, privateMap) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "get");
    return _class_apply_descriptor_get(receiver, descriptor);
}


;// CONCATENATED MODULE: ./node_modules/@swc/helpers/esm/_check_private_redeclaration.js
function _check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}


;// CONCATENATED MODULE: ./node_modules/@swc/helpers/esm/_class_private_field_init.js


function _class_private_field_init(obj, privateMap, value) {
    _check_private_redeclaration(obj, privateMap);
    privateMap.set(obj, value);
}


;// CONCATENATED MODULE: ./node_modules/@swc/helpers/esm/_class_apply_descriptor_set.js
function _class_apply_descriptor_set(receiver, descriptor, value) {
    if (descriptor.set) descriptor.set.call(receiver, value);
    else {
        if (!descriptor.writable) {
            // This should only throw in strict mode, but class bodies are
            // always strict and private fields can only be used inside
            // class bodies.
            throw new TypeError("attempted to set read only private field");
        }
        descriptor.value = value;
    }
}


;// CONCATENATED MODULE: ./node_modules/@swc/helpers/esm/_class_private_field_set.js



function _class_private_field_set(receiver, privateMap, value) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "set");
    _class_apply_descriptor_set(receiver, descriptor, value);
    return value;
}


;// CONCATENATED MODULE: ./node_modules/@hazae41/option/dist/esm/mods/option/none.mjs


class NoneError extends Error {
    constructor() {
        super(`Option is a None`);
    }
}
class none_None {
    inner;
    /**
     * An empty value
     */
    constructor(inner = undefined) {
        this.inner = inner;
    }
    /**
     * Create a `None`
     * @returns `None`
     */
    static new() {
        return new none_None();
    }
    static from(init) {
        return new none_None();
    }
    /**
     * Type guard for `Some`
     * @returns `true` if `Some`, `false` if `None`
     */
    isSome() {
        return false;
    }
    /**
     * Returns `true` if the option is a `Some` and the value inside of it matches a predicate
     * @param somePredicate
     * @returns `true` if `Some` and `await somePredicate(this.inner)`, `None` otherwise
     */
    async isSomeAnd(somePredicate) {
        return false;
    }
    /**
     * Returns `true` if the option is a `Some` and the value inside of it matches a predicate
     * @param somePredicate
     * @returns `true` if `Some` and `somePredicate(this.inner)`, `None` otherwise
     */
    isSomeAndSync(somePredicate) {
        return false;
    }
    /**
     * Type guard for `None`
     * @returns `true` if `None`, `false` if `Some`
     */
    isNone() {
        return true;
    }
    /**
     * Compile-time safely get `this.inner`
     * @returns `this.inner`
     */
    get() {
        return this.inner;
    }
    /**
     * Returns an iterator over the possibly contained value
     * @yields `this.inner` if `Some`
     */
    *[Symbol.iterator]() {
        return;
    }
    /**
     * Get the inner value if `Some`, throw `Error(message)` otherwise
     * @param message
     * @returns `this.inner` if `Some`
     * @throws `Error(message)` if `None`
     */
    expect(message) {
        throw new Error(message, { cause: new NoneError() });
    }
    /**
     * Get the inner value or throw a NoneError
     * @returns `this.inner` if `Some`
     * @throws `NoneError` if `None`
     */
    unwrap() {
        throw new NoneError();
    }
    /**
     * Get the inner value or a default one
     * @param value
     * @returns `this.inner` if `Some`, `value` if `None`
     */
    unwrapOr(value) {
        return value;
    }
    /**
     * Returns the contained `Some` value or computes it from a closure
     * @param noneCallback
     * @returns `this.inner` if `Some`, `await noneCallback()` if `None`
     */
    async unwrapOrElse(noneCallback) {
        return await noneCallback();
    }
    /**
     * Returns the contained `Some` value or computes it from a closure
     * @param noneCallback
     * @returns `this.inner` if `Some`, `noneCallback()` if `None`
     */
    unwrapOrElseSync(noneCallback) {
        return noneCallback();
    }
    /**
     * Transform `Option<T>` into `Result<T, NoneError>`
     * @returns `Ok(this.inner)` if `Some`, `Err(NoneError)` if `None`
     */
    ok() {
        return new err_Err(new NoneError());
    }
    /**
     * Transform `Option<T>` into `Result<T, E>`
     * @param error
     * @returns `Ok(this.inner)` if `Some`, `Err(error)` if `None`
     */
    okOr(error) {
        return new err_Err(error);
    }
    /**
     * Transforms the `Option<T>` into a `Result<T, E>`, mapping `Some(v)` to `Ok(v)` and `None` to `Err(err())`
     * @param noneCallback
     * @returns `Ok(this.inner)` if `Some`, `Err(await noneCallback())` is `None`
     */
    async okOrElse(noneCallback) {
        return new err_Err(await noneCallback());
    }
    /**
     * Transforms the `Option<T>` into a `Result<T, E>`, mapping `Some(v)` to `Ok(v)` and `None` to `Err(err())`
     * @param noneCallback
     * @returns `Ok(this.inner)` if `Some`, `Err(noneCallback())` is `None`
     */
    okOrElseSync(noneCallback) {
        return new err_Err(noneCallback());
    }
    /**
     * Returns `None` if the option is `None`, otherwise calls `somePredicate` with the wrapped value
     * @param somePredicate
     * @returns `Some` if `Some` and `await somePredicate(this.inner)`, `None` otherwise
     */
    async filter(somePredicate) {
        return this;
    }
    /**
     * Returns `None` if the option is `None`, otherwise calls `somePredicate` with the wrapped value
     * @param somePredicate
     * @returns `Some` if `Some` and `somePredicate(this.inner)`, `None` otherwise
     */
    filterSync(somePredicate) {
        return this;
    }
    /**
     * Transform `Option<Promise<T>>` into `Promise<Option<T>>`
     * @returns `Promise<Option<T>>`
     */
    async await() {
        return this;
    }
    /**
     * Returns `true` if the option is a `Some` value containing the given value
     * @param value
     * @returns `true` if `Some` and `this.inner === value`, `None` otherwise
     */
    contains(value) {
        return false;
    }
    /**
     * Calls the given callback with the inner value if `Ok`
     * @param someCallback
     * @returns `this`
     */
    async inspect(someCallback) {
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Ok`
     * @param someCallback
     * @returns `this`
     */
    inspectSync(someCallback) {
        return this;
    }
    /**
     * Maps an `Option<T>` to `Option<U>` by applying a function to a contained value (if `Some`) or returns `None` (if `None`)
     * @param someMapper
     * @returns `Some(await someMapper(this.inner))` if `Some`, `this` if `None`
     */
    async map(someMapper) {
        return this;
    }
    /**
     * Maps an `Option<T>` to `Option<U>` by applying a function to a contained value (if `Some`) or returns `None` (if `None`)
     * @param someMapper
     * @returns `Some(someMapper(this.inner))` if `Some`, `this` if `None`
     */
    mapSync(someMapper) {
        return this;
    }
    /**
     * Returns the provided default result (if none), or applies a function to the contained value (if any)
     * @param value
     * @param someMapper
     * @returns `value` if `None`, `await someMapper(this.inner)` if `Some`
     */
    async mapOr(value, someMapper) {
        return value;
    }
    /**
     * Returns the provided default result (if none), or applies a function to the contained value (if any)
     * @param value
     * @param someMapper
     * @returns `value` if `None`, `someMapper(this.inner)` if `Some`
     */
    mapOrSync(value, someMapper) {
        return value;
    }
    /**
     * Computes a default function result (if none), or applies a different function to the contained value (if any)
     * @param noneCallback
     * @param someMapper
     * @returns `await someMapper(this.inner)` if `Some`, `await noneCallback()` if `None`
     */
    async mapOrElse(noneCallback, someMapper) {
        return await noneCallback();
    }
    /**
     * Computes a default function result (if none), or applies a different function to the contained value (if any)
     * @param noneCallback
     * @param someMapper
     * @returns `someMapper(this.inner)` if `Some`, `noneCallback()` if `None`
     */
    mapOrElseSync(noneCallback, someMapper) {
        return noneCallback();
    }
    /**
     * Returns `None` if the option is `None`, otherwise returns `value`
     * @param value
     * @returns `None` if `None`, `value` if `Some`
     */
    and(value) {
        return this;
    }
    /**
     * Returns `None` if the option is `None`, otherwise calls `someMapper` with the wrapped value and returns the result
     * @param someMapper
     * @returns `None` if `None`, `await someMapper(this.inner)` if `Some`
     */
    async andThen(someMapper) {
        return this;
    }
    /**
     * Returns `None` if the option is `None`, otherwise calls `someMapper` with the wrapped value and returns the result
     * @param someMapper
     * @returns `None` if `None`, `someMapper(this.inner)` if `Some`
     */
    andThenSync(someMapper) {
        return this;
    }
    /**
     * Returns `this` if `Some`, otherwise returns `value`
     * @param value
     * @returns `this` if `Some`, `value` if `None`
     */
    or(value) {
        return value;
    }
    /**
     * Returns `this` if `Some`, otherwise calls `noneCallback` and returns the result
     * @param noneCallback
     * @returns `this` if `Some`, `await noneCallback()` if `None`
     */
    async orElse(noneCallback) {
        return await noneCallback();
    }
    /**
     * Returns `this` if `Some`, otherwise calls `noneCallback` and returns the result
     * @param noneCallback
     * @returns `this` if `Some`, `noneCallback()` if `None`
     */
    orElseSync(noneCallback) {
        return noneCallback();
    }
    /**
     * Returns `Some` if exactly one of the options is `Some`, otherwise returns `None`
     * @param value
     * @returns `None` if both are `Some` or both are `None`, the only `Some` otherwise
     */
    xor(value) {
        return value;
    }
    /**
     * Zips `this` with another `Option`
     * @param other
     * @returns `Some([this.inner, other.inner])` if both are `Some`, `None` if one of them is `None`
     */
    zip(other) {
        return this;
    }
}


//# sourceMappingURL=none.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/result/dist/esm/mods/debug/debug.mjs
var Debug;
(function (Debug) {
    Debug.debug = false;
})(Debug || (Debug = {}));


//# sourceMappingURL=debug.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/errors.mjs
class Unimplemented extends (/* unused pure expression or super */ null && (Error)) {
    #class = Unimplemented;
    name = this.#class.name;
}
class Panic extends Error {
    #class = Panic;
    name = this.#class.name;
    static from(cause) {
        return new Panic(undefined, { cause });
    }
    static fromAndThrow(cause) {
        throw Panic.from(cause);
    }
}
class Catched extends Error {
    #class = Catched;
    name = this.#class.name;
    static from(cause) {
        return new Catched(undefined, { cause });
    }
    static fromAndThrow(cause) {
        throw Catched.from(cause);
    }
}


//# sourceMappingURL=errors.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/ok.mjs




class ok_Ok {
    #inner;
    #timeout;
    /**
     * A success
     * @param inner
     */
    constructor(inner) {
        this.#inner = inner;
        if (!Debug.debug)
            return;
        const error = new Panic(`Unhandled result`, { cause: this });
        this.#timeout = setTimeout(async () => { throw error; }, 1000);
    }
    /**
     * Create an empty `Ok`
     * @returns `Ok(void)`
     */
    static void() {
        return new ok_Ok(undefined);
    }
    /**
     * Create an `Ok`
     * @param inner
     * @returns `Ok(inner)`
     */
    static new(inner) {
        return new ok_Ok(inner);
    }
    get inner() {
        return this.#inner;
    }
    /**
     * Set this result as handled
     */
    ignore() {
        if (!this.#timeout)
            return this;
        clearTimeout(this.#timeout);
        this.#timeout = undefined;
        return this;
    }
    /**
     * Type guard for `Ok`
     * @returns `true` if `Ok`, `false` if `Err`
     */
    isOk() {
        return true;
    }
    /**
     * Returns true if the result is `Ok` and the value inside of it matches a predicate
     * @param okPredicate
     * @returns `true` if `Ok` and `await okPredicate(this.inner)`, `false` otherwise
     */
    async isOkAnd(okPredicate) {
        return await okPredicate(this.inner);
    }
    /**
     * Returns true if the result is `Ok` and the value inside of it matches a predicate
     * @param okPredicate
     * @returns `true` if `Ok` and `await okPredicate(this.inner)`, `false` otherwise
     */
    isOkAndSync(okPredicate) {
        return okPredicate(this.inner);
    }
    /**
     * Type guard for `Err`
     * @returns `true` if `Err`, `false` if `Ok`
     */
    isErr() {
        return false;
    }
    /**
     * Returns true if the result is `Err` and the value inside of it matches a predicate
     * @param errPredicate
     * @returns `true` if `Err` and `await errPredicate(this.inner)`, `false` otherwise
     */
    async isErrAnd(errPredicate) {
        return false;
    }
    /**
     * Returns true if the result is `Err` and the value inside of it matches a predicate
     * @param errPredicate
     * @returns `true` if `Err` and `await errPredicate(this.inner)`, `false` otherwise
     */
    isErrAndSync(errPredicate) {
        return false;
    }
    /**
     * Compile-time safely get `this.inner`
     * @returns `this.inner`
     */
    get() {
        this.ignore();
        return this.inner;
    }
    /**
     * Transform `Result<T, E>` into `Option<T>`
     * @returns `Some(this.inner)` if `Ok`, `None` if `Err`
     */
    ok() {
        this.ignore();
        return new some_Some(this.inner);
    }
    /**
     * Transform `Result<T, E>` into `Option<E>`
     * @returns `Some(this.inner)` if `Err`, `None` if `Ok`
     */
    err() {
        this.ignore();
        return new none_None();
    }
    /**
     * Returns an iterator over the possibly contained value
     * @yields `this.inner` if `Ok`
     */
    *[Symbol.iterator]() {
        this.ignore();
        yield this.inner;
    }
    /**
     * Transform `Result<T,E>` into `[T,E]`
     * @returns `[this.inner, undefined]` if `Ok`, `[undefined, this.inner]` if `Err`
     */
    split() {
        this.ignore();
        return [this.inner, undefined];
    }
    /**
     * Returns true if the result is an `Ok` value containing the given value
     * @param value
     * @returns `true` if `Ok` and `this.inner === value`, `false` otherwise
     */
    contains(value) {
        return this.inner === value;
    }
    /**
     * Returns true if the result is an `Err` value containing the given value
     * @param value
     * @returns `true` if `Err` and `this.inner === value`, `false` otherwise
     */
    containsErr(value) {
        return false;
    }
    /**
     * Just like `unwrap` but it throws to the closest `Result.unthrow`
     * @returns `this.inner` if `Ok`
     * @throws `this` if `Err`
     * @see Result.unthrow
     * @see Result.unthrowSync
     */
    throw(thrower) {
        this.ignore();
        return this.inner;
    }
    /**
     * Get the inner value or throw the inner error wrapped inside another Error
     * @param message
     * @returns `this.inner` if `Ok`, `Error(message, { cause: this.inner })` if `Err`
     */
    expect(message) {
        this.ignore();
        return this.inner;
    }
    /**
     * Get the inner error or throw the inner value wrapped inside another Error
     * @param message
     * @returns `this.inner` if `Err`, `Error(message, { cause: this.inner })` if `Ok`
     */
    expectErr(message) {
        this.ignore();
        throw new Panic(message, { cause: this.inner });
    }
    /**
     * Get the inner value or throw the inner error
     * @returns `this.inner` if `Ok`
     * @throws `this.inner` if `Err`
     */
    unwrap() {
        this.ignore();
        return this.inner;
    }
    /**
     * Throw the inner value or get the inner error
     * @returns `this.inner` if `Err`
     * @throws `this.inner` if `Ok`
     */
    unwrapErr() {
        this.ignore();
        throw new Panic(undefined, { cause: this.inner });
    }
    /**
     * Get the inner value or a default one
     * @param value
     * @returns `this.inner` if `Ok`, `value` if `Err`
     */
    unwrapOr(value) {
        this.ignore();
        return this.inner;
    }
    /**
     * Get the inner value or compute a default one from the inner error
     * @param errMapper
     * @returns `this.inner` if `Ok`, `await errMapper(this.inner)` if `Err`
     * @throws if `await errMapper(this.inner)` throws
     */
    async unwrapOrElse(errMapper) {
        this.ignore();
        return this.inner;
    }
    /**
     * Get the inner value or compute a default one from the inner error
     * @param errMapper
     * @returns `this.inner` if `Ok`, `errMapper(this.inner)` if `Err`
     * @throws if `errMapper(this.inner)` throws
     */
    unwrapOrElseSync(errMapper) {
        this.ignore();
        return this.inner;
    }
    /**
     * Transform Result<Promise<T>, E> into Promise<Result<T, E>>
     * @returns `await this.inner` if `Ok`, `this` if `Err`
     */
    async await() {
        return new ok_Ok(await this.inner);
    }
    /**
     * Transform Result<T, Promise<E>> into Promise<Result<T, E>>
     * @returns `await this.inner` if `Err`, `this` if `Ok`
     */
    async awaitErr() {
        return this;
    }
    /**
     * Transform Result<Promise<T>, Promise<E>> into Promise<Result<T, E>>
     * @returns `await this.inner`
     */
    async awaitAll() {
        return await this.await();
    }
    /**
     * Transform `Result<T, E>` into `Result<void, E>`
     * @returns `Ok<void>` if `Ok<T>`, `Err<E>` if `E<E>`
     */
    clear() {
        this.ignore();
        return ok_Ok.void();
    }
    /**
     * Transform `Result<T, E>` into `Result<T, void>`
     * @returns `Ok<T>` if `Ok<T>`, `Err<void>` if `E<E>`
     */
    clearErr() {
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Ok`
     * @param okCallback
     * @returns `this`
     */
    async inspect(okCallback) {
        await okCallback(this.inner);
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Ok`
     * @param okCallback
     * @returns `this`
     */
    inspectSync(okCallback) {
        okCallback(this.inner);
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Err`
     * @param errCallback
     * @returns `this`
     */
    async inspectErr(errCallback) {
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Err`
     * @param errCallback
     * @returns `this`
     */
    inspectErrSync(errCallback) {
        return this;
    }
    /**
     * Return a new `Ok` but with the given `inner`
     * @param inner
     * @returns `Ok(inner)` if `Ok`, `this` if `Err`
     */
    set(inner) {
        return new ok_Ok(inner);
    }
    /**
     * Return a new `Err` but with the given `inner`
     * @param inner
     * @returns `Err(inner)` if `Err`, `this` if `Ok`
     */
    setErr(inner) {
        return this;
    }
    /**
     * Map the inner value into another
     * @param okMapper
     * @returns `Ok(await okMapper(this.inner))` if `Ok`, `this` if `Err`
     * @throws if `await okMapper(this.inner)` throws
     */
    async map(okMapper) {
        this.ignore();
        return new ok_Ok(await okMapper(this.inner));
    }
    /**
     * Map the inner value into another
     * @param okMapper
     * @returns `Ok(okMapper(this.inner))` if `Ok`, `this` if `Err`
     * @throws if `okMapper(this.inner)` throws
     */
    mapSync(okMapper) {
        this.ignore();
        return new ok_Ok(okMapper(this.inner));
    }
    /**
     * Map the inner error into another
     * @param errMapper
     * @returns `Err(await errMapper(this.inner))` if `Err`, `this` if `Ok`
     * @throws if `await errMapper(this.inner)` throws
     */
    async mapErr(errMapper) {
        return this;
    }
    /**
     * Map the inner error into another
     * @param errMapper
     * @returns `Err(errMapper(this.inner))` if `Err`, `this` if `Ok`
     * @throws if `errMapper(this.inner)` throws
     */
    mapErrSync(errMapper) {
        return this;
    }
    /**
     * Map the inner value into another, or a default one
     * @param value
     * @param okMapper
     * @returns `await okMapper(this.inner)` if `Ok`, `value` if `Err`
     * @throws if `await okMapper(this.inner)` throws
     */
    async mapOr(value, okMapper) {
        this.ignore();
        return await okMapper(this.inner);
    }
    /**
     * Map the inner value into another, or a default one
     * @param value
     * @param okMapper
     * @returns `okMapper(this.inner)` if `Ok`, `value` if `Err`
     * @throws if `okMapper(this.inner)` throws
     */
    mapOrSync(value, okMapper) {
        this.ignore();
        return okMapper(this.inner);
    }
    /**
     * Map the inner value into another, or a default one
     * @param errMapper
     * @param okMapper
     * @returns `await okMapper(this.inner)` if `Ok`, `await errMapper(this.inner)` if `Err`
     * @throws if `await okMapper(this.inner)` or `await errMapper(this.inner)` throws
     */
    async mapOrElse(errMapper, okMapper) {
        this.ignore();
        return await okMapper(this.inner);
    }
    /**
     * Map the inner value into another, or a default one
     * @param errMapper
     * @param okMapper
     * @returns `okMapper(this.inner)` if `Ok`, `errMapper(this.inner)` if `Err`
     * @throws if `okMapper(this.inner)` or `errMapper(this.inner)` throws
     */
    mapOrElseSync(errMapper, okMapper) {
        this.ignore();
        return okMapper(this.inner);
    }
    /**
     * Return `value` if `Ok`, return `this` if `Err`
     * @param value
     * @returns `value` if `Ok`, `this` if `Err`
     */
    and(value) {
        this.ignore();
        return value;
    }
    /**
     * Return `await okMapper(this.inner)` if `Ok`, return `this` if `Err`
     * @param okMapper
     * @returns `await okMapper(this.inner)` if `Ok`, `this` if `Err`
     * @throws if `await okMapper(this.inner)` throws
     */
    async andThen(okMapper) {
        this.ignore();
        return await okMapper(this.inner);
    }
    /**
     * Return `okMapper(this.inner)` if `Ok`, return `this` if `Err`
     * @param okMapper
     * @returns `okMapper(this.inner)` if `Ok`, `this` if `Err`
     * @throws if `okMapper(this.inner)` throws
     */
    andThenSync(okMapper) {
        this.ignore();
        return okMapper(this.inner);
    }
    /**
     * Return `value` if `Err`, return `this` if `Ok`
     * @param value
     * @returns `value` if `Err`, `this` if `Ok`
     */
    or(value) {
        return this;
    }
    /**
     * Return `await errMapper(this.inner)` if `Err`, return `this` if `Ok`
     * @param errMapper
     * @returns `await errMapper(this.inner)` if `Err`, `this` if `Ok`
     * @throws if `await errMapper(this.inner)` throws
     */
    async orElse(errMapper) {
        return this;
    }
    /**
     * Return `errMapper(this.inner)` if `Err`, return `this` if `Ok`
     * @param errMapper
     * @returns `errMapper(this.inner)` if `Err`, `this` if `Ok`
     * @throws if `errMapper(this.inner)` throws
     */
    orElseSync(errMapper) {
        return this;
    }
}


//# sourceMappingURL=ok.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/option/dist/esm/mods/option/some.mjs



class some_Some {
    inner;
    /**
     * An existing value
     * @param inner
     */
    constructor(inner) {
        this.inner = inner;
    }
    /**
     * Create a `Some`
     * @param inner
     * @returns `Some(inner)`
     */
    static new(inner) {
        return new this(inner);
    }
    static from(init) {
        return new some_Some(init.inner);
    }
    /**
     * Type guard for `Some`
     * @returns `true` if `Some`, `false` if `None`
     */
    isSome() {
        return true;
    }
    /**
     * Returns `true` if the option is a `Some` and the value inside of it matches a predicate
     * @param somePredicate
     * @returns `true` if `Some` and `await somePredicate(this.inner)`, `None` otherwise
     */
    async isSomeAnd(somePredicate) {
        return await somePredicate(this.inner);
    }
    /**
     * Returns `true` if the option is a `Some` and the value inside of it matches a predicate
     * @param somePredicate
     * @returns `true` if `Some` and `somePredicate(this.inner)`, `None` otherwise
     */
    isSomeAndSync(somePredicate) {
        return somePredicate(this.inner);
    }
    /**
     * Type guard for `None`
     * @returns `true` if `None`, `false` if `Some`
     */
    isNone() {
        return false;
    }
    /**
     * Compile-time safely get `this.inner`
     * @returns `this.inner`
     */
    get() {
        return this.inner;
    }
    /**
     * Returns an iterator over the possibly contained value
     * @yields `this.inner` if `Some`
     */
    *[Symbol.iterator]() {
        yield this.inner;
    }
    /**
     * Get the inner value if `Some`, throw `Error(message)` otherwise
     * @param message
     * @returns `this.inner` if `Some`
     * @throws `Error(message)` if `None`
     */
    expect(message) {
        return this.inner;
    }
    /**
     * Get the inner value or throw a NoneError
     * @returns `this.inner` if `Some`
     * @throws `NoneError` if `None`
     */
    unwrap() {
        return this.inner;
    }
    /**
     * Get the inner value or a default one
     * @param value
     * @returns `this.inner` if `Some`, `value` if `None`
     */
    unwrapOr(value) {
        return this.inner;
    }
    /**
     * Returns the contained `Some` value or computes it from a closure
     * @param noneCallback
     * @returns `this.inner` if `Some`, `await noneCallback()` if `None`
     */
    async unwrapOrElse(noneCallback) {
        return this.inner;
    }
    /**
     * Returns the contained `Some` value or computes it from a closure
     * @param noneCallback
     * @returns `this.inner` if `Some`, `noneCallback()` if `None`
     */
    unwrapOrElseSync(noneCallback) {
        return this.inner;
    }
    /**
     * Transform `Option<T>` into `Result<T, NoneError>`
     * @returns `Ok(this.inner)` if `Some`, `Err(NoneError)` if `None`
     */
    ok() {
        return new ok_Ok(this.inner);
    }
    /**
     * Transform `Option<T>` into `Result<T, E>`
     * @param error
     * @returns `Ok(this.inner)` if `Some`, `Err(error)` if `None`
     */
    okOr(error) {
        return new ok_Ok(this.inner);
    }
    /**
     * Transforms the `Option<T>` into a `Result<T, E>`, mapping `Some(v)` to `Ok(v)` and `None` to `Err(err())`
     * @param noneCallback
     * @returns `Ok(this.inner)` if `Some`, `Err(await noneCallback())` is `None`
     */
    async okOrElse(noneCallback) {
        return new ok_Ok(this.inner);
    }
    /**
     * Transforms the `Option<T>` into a `Result<T, E>`, mapping `Some(v)` to `Ok(v)` and `None` to `Err(err())`
     * @param noneCallback
     * @returns `Ok(this.inner)` if `Some`, `Err(noneCallback())` is `None`
     */
    okOrElseSync(noneCallback) {
        return new ok_Ok(this.inner);
    }
    /**
     * Returns `None` if the option is `None`, otherwise calls `somePredicate` with the wrapped value
     * @param somePredicate
     * @returns `Some` if `Some` and `await somePredicate(this.inner)`, `None` otherwise
     */
    async filter(somePredicate) {
        if (await somePredicate(this.inner))
            return this;
        else
            return new none_None();
    }
    /**
     * Returns `None` if the option is `None`, otherwise calls `somePredicate` with the wrapped value
     * @param somePredicate
     * @returns `Some` if `Some` and `somePredicate(this.inner)`, `None` otherwise
     */
    filterSync(somePredicate) {
        if (somePredicate(this.inner))
            return this;
        else
            return new none_None();
    }
    /**
     * Transform `Option<Promise<T>>` into `Promise<Option<T>>`
     * @returns `Promise<Option<T>>`
     */
    async await() {
        return new some_Some(await this.inner);
    }
    /**
     * Returns `true` if the option is a `Some` value containing the given value
     * @param value
     * @returns `true` if `Some` and `this.inner === value`, `None` otherwise
     */
    contains(value) {
        return this.inner === value;
    }
    /**
     * Calls the given callback with the inner value if `Ok`
     * @param someCallback
     * @returns `this`
     */
    async inspect(someCallback) {
        await someCallback(this.inner);
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Ok`
     * @param someCallback
     * @returns `this`
     */
    inspectSync(someCallback) {
        someCallback(this.inner);
        return this;
    }
    /**
     * Maps an `Option<T>` to `Option<U>` by applying a function to a contained value (if `Some`) or returns `None` (if `None`)
     * @param someMapper
     * @returns `Some(await someMapper(this.inner))` if `Some`, `this` if `None`
     */
    async map(someMapper) {
        return new some_Some(await someMapper(this.inner));
    }
    /**
     * Maps an `Option<T>` to `Option<U>` by applying a function to a contained value (if `Some`) or returns `None` (if `None`)
     * @param someMapper
     * @returns `Some(someMapper(this.inner))` if `Some`, `this` if `None`
     */
    mapSync(someMapper) {
        return new some_Some(someMapper(this.inner));
    }
    /**
     * Returns the provided default result (if none), or applies a function to the contained value (if any)
     * @param value
     * @param someMapper
     * @returns `value` if `None`, `await someMapper(this.inner)` if `Some`
     */
    async mapOr(value, someMapper) {
        return await someMapper(this.inner);
    }
    /**
     * Returns the provided default result (if none), or applies a function to the contained value (if any)
     * @param value
     * @param someMapper
     * @returns `value` if `None`, `someMapper(this.inner)` if `Some`
     */
    mapOrSync(value, someMapper) {
        return someMapper(this.inner);
    }
    /**
     * Computes a default function result (if none), or applies a different function to the contained value (if any)
     * @param noneCallback
     * @param someMapper
     * @returns `await someMapper(this.inner)` if `Some`, `await noneCallback()` if `None`
     */
    async mapOrElse(noneCallback, someMapper) {
        return await someMapper(this.inner);
    }
    /**
     * Computes a default function result (if none), or applies a different function to the contained value (if any)
     * @param noneCallback
     * @param someMapper
     * @returns `someMapper(this.inner)` if `Some`, `noneCallback()` if `None`
     */
    mapOrElseSync(noneCallback, someMapper) {
        return someMapper(this.inner);
    }
    /**
     * Returns `None` if the option is `None`, otherwise returns `value`
     * @param value
     * @returns `None` if `None`, `value` if `Some`
     */
    and(value) {
        return value;
    }
    /**
     * Returns `None` if the option is `None`, otherwise calls `someMapper` with the wrapped value and returns the result
     * @param someMapper
     * @returns `None` if `None`, `await someMapper(this.inner)` if `Some`
     */
    async andThen(someMapper) {
        return await someMapper(this.inner);
    }
    /**
     * Returns `None` if the option is `None`, otherwise calls `someMapper` with the wrapped value and returns the result
     * @param someMapper
     * @returns `None` if `None`, `someMapper(this.inner)` if `Some`
     */
    andThenSync(someMapper) {
        return someMapper(this.inner);
    }
    /**
     * Returns `this` if `Some`, otherwise returns `value`
     * @param value
     * @returns `this` if `Some`, `value` if `None`
     */
    or(value) {
        return this;
    }
    /**
     * Returns `this` if `Some`, otherwise calls `noneCallback` and returns the result
     * @param noneCallback
     * @returns `this` if `Some`, `await noneCallback()` if `None`
     */
    async orElse(noneCallback) {
        return this;
    }
    /**
     * Returns `this` if `Some`, otherwise calls `noneCallback` and returns the result
     * @param noneCallback
     * @returns `this` if `Some`, `noneCallback()` if `None`
     */
    orElseSync(noneCallback) {
        return this;
    }
    /**
     * Returns `Some` if exactly one of the options is `Some`, otherwise returns `None`
     * @param value
     * @returns `None` if both are `Some` or both are `None`, the only `Some` otherwise
     */
    xor(value) {
        if (value.isSome())
            return new none_None();
        else
            return this;
    }
    /**
     * Zips `this` with another `Option`
     * @param other
     * @returns `Some([this.inner, other.inner])` if both are `Some`, `None` if one of them is `None`
     */
    zip(other) {
        if (other.isSome())
            return new some_Some([this.inner, other.inner]);
        else
            return other;
    }
}


//# sourceMappingURL=some.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/err.mjs




class err_Err {
    #inner;
    #timeout;
    /**
     * A failure
     * @param inner
     */
    constructor(inner) {
        this.#inner = inner;
        if (!Debug.debug)
            return;
        const error = new Panic(`Unhandled result`, { cause: this });
        this.#timeout = setTimeout(async () => { throw error; }, 1000);
    }
    /**
     * Create an empty `Err`
     * @returns `Err(void)`
     */
    static void() {
        return new err_Err(undefined);
    }
    /**
     * Create an `Err`
     * @param inner
     * @returns `Err(inner)`
     */
    static new(inner) {
        return new err_Err(inner);
    }
    /**
     * Create an `Err` with an `Error` inside
     * @param message
     * @param options
     * @returns `Err<Error>`
     */
    static error(message, options) {
        return new err_Err(new Error(message, options));
    }
    get inner() {
        return this.#inner;
    }
    /**
     * Set this result as handled
     */
    ignore() {
        if (!this.#timeout)
            return this;
        clearTimeout(this.#timeout);
        this.#timeout = undefined;
        return this;
    }
    /**
     * Type guard for `Ok`
     * @returns `true` if `Ok`, `false` if `Err`
     */
    isOk() {
        return false;
    }
    /**
     * Returns true if the result is `Ok` and the value inside of it matches a predicate
     * @param okPredicate
     * @returns `true` if `Ok` and `await okPredicate(this.inner)`, `false` otherwise
     */
    async isOkAnd(okPredicate) {
        return false;
    }
    /**
     * Returns true if the result is `Ok` and the value inside of it matches a predicate
     * @param okPredicate
     * @returns `true` if `Ok` and `await okPredicate(this.inner)`, `false` otherwise
     */
    isOkAndSync(okPredicate) {
        return false;
    }
    /**
     * Type guard for `Err`
     * @returns `true` if `Err`, `false` if `Ok`
     */
    isErr() {
        return true;
    }
    /**
     * Returns true if the result is `Err` and the value inside of it matches a predicate
     * @param errPredicate
     * @returns `true` if `Err` and `await errPredicate(this.inner)`, `false` otherwise
     */
    async isErrAnd(errPredicate) {
        return await errPredicate(this.inner);
    }
    /**
     * Returns true if the result is `Err` and the value inside of it matches a predicate
     * @param errPredicate
     * @returns `true` if `Err` and `await errPredicate(this.inner)`, `false` otherwise
     */
    isErrAndSync(errPredicate) {
        return errPredicate(this.inner);
    }
    /**
     * Compile-time safely get `this.inner`
     * @returns `this.inner`
     */
    get() {
        this.ignore();
        return this.inner;
    }
    /**
     * Transform `Result<T, E>` into `Option<T>`
     * @returns `Some(this.inner)` if `Ok`, `None` if `Err`
     */
    ok() {
        this.ignore();
        return new none_None();
    }
    /**
     * Transform `Result<T, E>` into `Option<E>`
     * @returns `Some(this.inner)` if `Err`, `None` if `Ok`
     */
    err() {
        this.ignore();
        return new some_Some(this.inner);
    }
    /**
     * Returns an iterator over the possibly contained value
     * @yields `this.inner` if `Ok`
     */
    *[Symbol.iterator]() {
        this.ignore();
        return;
    }
    /**
     * Transform `Result<T,E>` into `[T,E]`
     * @returns `[this.inner, undefined]` if `Ok`, `[undefined, this.inner]` if `Err`
     */
    split() {
        this.ignore();
        return [undefined, this.inner];
    }
    /**
     * Returns true if the result is an `Ok` value containing the given value
     * @param value
     * @returns `true` if `Ok` and `this.inner === value`, `false` otherwise
     */
    contains(value) {
        return false;
    }
    /**
     * Returns true if the result is an `Err` value containing the given value
     * @param value
     * @returns `true` if `Err` and `this.inner === value`, `false` otherwise
     */
    containsErr(value) {
        return this.inner === value;
    }
    /**
     * Get the inner value or throw to the closest `Result.unthrow`
     * @param thrower The thrower from `Result.unthrow`
     * @returns `this.inner` if `Ok`
     * @throws `undefined` if `Err`
     * @see Result.unthrow
     * @see Result.unthrowSync
     */
    throw(thrower) {
        thrower(this);
        throw new Panic(`Thrown result was try-catched`);
    }
    /**
     * Get the inner value or throw the inner error wrapped inside another Error
     * @param message
     * @returns `this.inner` if `Ok`, `Error(message, { cause: this.inner })` if `Err`
     */
    expect(message) {
        this.ignore();
        throw new Panic(message, { cause: this.inner });
    }
    /**
     * Get the inner error or throw the inner value wrapped inside another Error
     * @param message
     * @returns `this.inner` if `Err`, `Error(message, { cause: this.inner })` if `Ok`
     */
    expectErr(message) {
        this.ignore();
        return this.inner;
    }
    /**
     * Get the inner value or throw the inner error
     * @returns `this.inner` if `Ok`
     * @throws `this.inner` if `Err`
     */
    unwrap() {
        this.ignore();
        throw new Panic(undefined, { cause: this.inner });
    }
    /**
     * Throw the inner value or get the inner error
     * @returns `this.inner` if `Err`
     * @throws `this.inner` if `Ok`
     */
    unwrapErr() {
        this.ignore();
        return this.inner;
    }
    /**
     * Get the inner value or a default one
     * @param value
     * @returns `this.inner` if `Ok`, `value` if `Err`
     */
    unwrapOr(value) {
        this.ignore();
        return value;
    }
    /**
     * Get the inner value or compute a default one from the inner error
     * @param errMapper
     * @returns `this.inner` if `Ok`, `await errMapper(this.inner)` if `Err`
     * @throws if `await errMapper(this.inner)` throws
     */
    async unwrapOrElse(errMapper) {
        this.ignore();
        return await errMapper(this.inner);
    }
    /**
     * Get the inner value or compute a default one from the inner error
     * @param errMapper
     * @returns `this.inner` if `Ok`, `errMapper(this.inner)` if `Err`
     * @throws if `errMapper(this.inner)` throws
     */
    unwrapOrElseSync(errMapper) {
        this.ignore();
        return errMapper(this.inner);
    }
    /**
     * Transform Result<Promise<T>, E> into Promise<Result<T, E>>
     * @returns `await this.inner` if `Ok`, `this` if `Err`
     */
    async await() {
        return this;
    }
    /**
     * Transform Result<T, Promise<E>> into Promise<Result<T, E>>
     * @returns `await this.inner` if `Err`, `this` if `Ok`
     */
    async awaitErr() {
        return new err_Err(await this.inner);
    }
    /**
     * Transform Result<Promise<T>, Promise<E>> into Promise<Result<T, E>>
     * @returns `await this.inner`
     */
    async awaitAll() {
        return await this.awaitErr();
    }
    /**
     * Transform `Result<T, E>` into `Result<void, E>`
     * @returns `Ok<void>` if `Ok<T>`, `Err<E>` if `E<E>`
     */
    clear() {
        return this;
    }
    /**
     * Transform `Result<T, E>` into `Result<T, void>`
     * @returns `Ok<T>` if `Ok<T>`, `Err<void>` if `E<E>`
     */
    clearErr() {
        this.ignore();
        return err_Err.void();
    }
    /**
     * Calls the given callback with the inner value if `Ok`
     * @param okCallback
     * @returns `this`
     */
    async inspect(okCallback) {
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Ok`
     * @param okCallback
     * @returns `this`
     */
    inspectSync(okCallback) {
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Err`
     * @param errCallback
     * @returns `this`
     */
    async inspectErr(errCallback) {
        await errCallback(this.inner);
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Err`
     * @param errCallback
     * @returns `this`
     */
    inspectErrSync(errCallback) {
        errCallback(this.inner);
        return this;
    }
    /**
     * Return a new `Ok` but with the given `inner`
     * @param inner
     * @returns `Ok(inner)` if `Ok`, `this` if `Err`
     */
    set(inner) {
        return this;
    }
    /**
     * Return a new `Err` but with the given `inner`
     * @param inner
     * @returns `Err(inner)` if `Err`, `this` if `Ok`
     */
    setErr(inner) {
        return new err_Err(inner);
    }
    /**
     * Map the inner value into another
     * @param okMapper
     * @returns `Ok(await okMapper(this.inner))` if `Ok`, `this` if `Err`
     * @throws if `await okMapper(this.inner)` throws
     */
    async map(okMapper) {
        return this;
    }
    /**
     * Map the inner value into another
     * @param okMapper
     * @returns `Ok(okMapper(this.inner))` if `Ok`, `this` if `Err`
     * @throws if `okMapper(this.inner)` throws
     */
    mapSync(okMapper) {
        return this;
    }
    /**
     * Map the inner error into another
     * @param errMapper
     * @returns `Err(await errMapper(this.inner))` if `Err`, `this` if `Ok`
     * @throws if `await errMapper(this.inner)` throws
     */
    async mapErr(errMapper) {
        this.ignore();
        return new err_Err(await errMapper(this.inner));
    }
    /**
     * Map the inner error into another
     * @param errMapper
     * @returns `Err(errMapper(this.inner))` if `Err`, `this` if `Ok`
     * @throws if `errMapper(this.inner)` throws
     */
    mapErrSync(errMapper) {
        this.ignore();
        return new err_Err(errMapper(this.inner));
    }
    /**
     * Map the inner value into another, or a default one
     * @param value
     * @param okMapper
     * @returns `await okMapper(this.inner)` if `Ok`, `value` if `Err`
     * @throws if `await okMapper(this.inner)` throws
     */
    async mapOr(value, okMapper) {
        this.ignore();
        return value;
    }
    /**
     * Map the inner value into another, or a default one
     * @param value
     * @param okMapper
     * @returns `okMapper(this.inner)` if `Ok`, `value` if `Err`
     * @throws if `okMapper(this.inner)` throws
     */
    mapOrSync(value, okMapper) {
        this.ignore();
        return value;
    }
    /**
     * Map the inner value into another, or a default one
     * @param errMapper
     * @param okMapper
     * @returns `await okMapper(this.inner)` if `Ok`, `await errMapper(this.inner)` if `Err`
     * @throws if `await okMapper(this.inner)` or `await errMapper(this.inner)` throws
     */
    async mapOrElse(errMapper, okMapper) {
        this.ignore();
        return await errMapper(this.inner);
    }
    /**
     * Map the inner value into another, or a default one
     * @param errMapper
     * @param okMapper
     * @returns `okMapper(this.inner)` if `Ok`, `errMapper(this.inner)` if `Err`
     * @throws if `okMapper(this.inner)` or `errMapper(this.inner)` throws
     */
    mapOrElseSync(errMapper, okMapper) {
        this.ignore();
        return errMapper(this.inner);
    }
    /**
     * Return `value` if `Ok`, return `this` if `Err`
     * @param value
     * @returns `value` if `Ok`, `this` if `Err`
     */
    and(value) {
        return this;
    }
    /**
     * Return `await okMapper(this.inner)` if `Ok`, return `this` if `Err`
     * @param okMapper
     * @returns `await okMapper(this.inner)` if `Ok`, `this` if `Err`
     * @throws if `await okMapper(this.inner)` throws
     */
    async andThen(okMapper) {
        return this;
    }
    /**
     * Return `okMapper(this.inner)` if `Ok`, return `this` if `Err`
     * @param okMapper
     * @returns `okMapper(this.inner)` if `Ok`, `this` if `Err`
     * @throws if `okMapper(this.inner)` throws
     */
    andThenSync(okMapper) {
        return this;
    }
    /**
     * Return `value` if `Err`, return `this` if `Ok`
     * @param value
     * @returns `value` if `Err`, `this` if `Ok`
     */
    or(value) {
        this.ignore();
        return value;
    }
    /**
     * Return `await errMapper(this.inner)` if `Err`, return `this` if `Ok`
     * @param errMapper
     * @returns `await errMapper(this.inner)` if `Err`, `this` if `Ok`
     * @throws if `await errMapper(this.inner)` throws
     */
    async orElse(errMapper) {
        this.ignore();
        return await errMapper(this.inner);
    }
    /**
     * Return `errMapper(this.inner)` if `Err`, return `this` if `Ok`
     * @param errMapper
     * @returns `errMapper(this.inner)` if `Err`, `this` if `Ok`
     * @throws if `errMapper(this.inner)` throws
     */
    orElseSync(errMapper) {
        this.ignore();
        return errMapper(this.inner);
    }
}


//# sourceMappingURL=err.mjs.map

;// CONCATENATED MODULE: ./src/libs/browser/browser.ts




var _globalThis_browser;
const browser = (_globalThis_browser = globalThis.browser) !== null && _globalThis_browser !== void 0 ? _globalThis_browser : globalThis.chrome;
var _class = /*#__PURE__*/ new WeakMap();
class BrowserError extends Error {
    static from(cause) {
        return new BrowserError(undefined, {
            cause
        });
    }
    constructor(...args){
        super(...args);
        _class_private_field_init(this, _class, {
            writable: true,
            value: void 0
        });
        _class_private_field_set(this, _class, BrowserError);
        this.name = _class_private_field_get(this, _class).name;
    }
}
async function tryBrowser(callback) {
    try {
        const result = await callback();
        if (browser.runtime.lastError) return new err_Err(new BrowserError());
        return new ok_Ok(result);
    } catch (e) {
        return new err_Err(new BrowserError());
    }
}
function tryBrowserSync(callback) {
    try {
        const result = callback();
        const error = browser.runtime.lastError;
        if (error) return new err_Err(BrowserError.from(error));
        return new ok_Ok(result);
    } catch (e) {
        return new err_Err(BrowserError.from(e));
    }
}

;// CONCATENATED MODULE: ./node_modules/@hazae41/cleaner/dist/esm/mods/cleaner/cleaner.mjs
var Cleanable;
(function (Cleanable) {
    async function runWith(cleanable, callback) {
        try {
            return await callback(cleanable);
        }
        finally {
            cleanable?.clean();
        }
    }
    Cleanable.runWith = runWith;
    function runWithSync(cleanable, callback) {
        try {
            return callback(cleanable);
        }
        finally {
            cleanable?.clean();
        }
    }
    Cleanable.runWithSync = runWithSync;
})(Cleanable = Cleanable || (Cleanable = {}));
class cleaner_Cleaner {
    inner;
    clean;
    constructor(inner, clean) {
        this.inner = inner;
        this.clean = clean;
    }
}
(function (Cleaner) {
    async function wait(cleaner) {
        try {
            return await cleaner.inner;
        }
        finally {
            cleaner.clean();
        }
    }
    Cleaner.wait = wait;
    async function race(cleaners) {
        const promises = new Array(cleaners.length);
        const cleanups = new Array(cleaners.length);
        for (let i = 0; i < cleaners.length; i++) {
            promises[i] = cleaners[i].inner;
            cleanups[i] = cleaners[i].clean;
        }
        try {
            return await Promise.race(promises);
        }
        finally {
            cleanups.forEach(cleanup => cleanup());
        }
    }
    Cleaner.race = race;
})(cleaner_Cleaner = cleaner_Cleaner || (cleaner_Cleaner = {}));


//# sourceMappingURL=cleaner.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/future/dist/esm/mods/future/future.mjs
class Future {
    #resolve;
    #reject;
    promise;
    /**
     * Just like a Promise but you can manually resolve or reject it
     */
    constructor() {
        this.promise = new Promise((subresolve, subreject) => {
            this.#resolve = subresolve;
            this.#reject = subreject;
        });
    }
    get resolve() {
        return this.#resolve;
    }
    get reject() {
        return this.#reject;
    }
}


//# sourceMappingURL=future.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/plume/dist/esm/mods/errors.mjs





class errors_AbortedError extends Error {
    #class = errors_AbortedError;
    name = this.#class.name;
    static from(cause) {
        return new errors_AbortedError(`Aborted`, { cause });
    }
    static wait(signal) {
        const future = new Future();
        const onAbort = (event) => {
            future.resolve(new err_Err(errors_AbortedError.from(event)));
        };
        signal.addEventListener("abort", onAbort, { passive: true });
        const off = () => signal.removeEventListener("abort", onAbort);
        return new cleaner_Cleaner(future.promise, off);
    }
}
class errors_ErroredError extends Error {
    #class = errors_ErroredError;
    name = this.#class.name;
    static from(cause) {
        return new errors_ErroredError(`Errored`, { cause });
    }
    static wait(target) {
        return target.wait("error", (future, event) => {
            const error = errors_ErroredError.from(event);
            future.resolve(new err_Err(error));
            return new none_None();
        });
    }
}
class errors_ClosedError extends Error {
    #class = errors_ClosedError;
    name = this.#class.name;
    static from(cause) {
        return new errors_ClosedError(`Closed`, { cause });
    }
    static wait(target) {
        return target.wait("close", (future, event) => {
            const error = errors_ClosedError.from(event);
            future.resolve(new err_Err(error));
            return new none_None();
        });
    }
}


//# sourceMappingURL=errors.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/plume/dist/esm/mods/waiters.mjs



async function tryWaitOrSignal(target, type, callback, signal) {
    const abort = AbortedError.wait(signal);
    const event = target.wait(type, callback);
    return await Cleaner.race([abort, event]);
}
async function tryWaitOrCloseOrError(target, type, callback) {
    const error = errors_ErroredError.wait(target);
    const close = errors_ClosedError.wait(target);
    const event = target.wait(type, callback);
    return await cleaner_Cleaner.race([error, close, event]);
}
async function tryWaitOrCloseOrErrorOrSignal(target, type, callback, signal) {
    const abort = AbortedError.wait(signal);
    const error = ErroredError.wait(target);
    const close = ClosedError.wait(target);
    const event = target.wait(type, callback);
    return await Cleaner.race([abort, error, close, event]);
}


//# sourceMappingURL=waiters.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/plume/dist/esm/mods/target.mjs




class EventError extends (/* unused pure expression or super */ null && (Error)) {
    #class = EventError;
    name = this.#class.name;
    constructor(cause) {
        super(`Event failed`, { cause });
    }
    static new(cause) {
        return new EventError(cause);
    }
}
class target_SuperEventTarget {
    #listeners = new Map();
    get listeners() {
        return this.#listeners;
    }
    /**
     * Add a listener to an event
     * @param type Event type //  "abort", "error", "message", "close"
     * @param listener Event listener // (e) => new Some(123)
     * @param options Options // { passive: true }
     * @returns
     */
    on(type, listener, options = {}) {
        let listeners = this.#listeners.get(type);
        if (listeners === undefined) {
            listeners = new Map();
            this.#listeners.set(type, listeners);
        }
        const off = () => this.off(type, listener);
        const internalOptions = { ...options, off };
        internalOptions.signal?.addEventListener("abort", off, { passive: true });
        listeners.set(listener, internalOptions);
        return off;
    }
    /**
     * Remove a listener from an event
     * @param type Event type //  "abort", "error", "message", "close"
     * @param listener Event listener // (e) => console.log("hello")
     * @param options Just to look like DOM's EventTarget
     * @returns
     */
    off(type, listener) {
        const listeners = this.#listeners.get(type);
        if (!listeners)
            return;
        const options = listeners.get(listener);
        if (!options)
            return;
        options.signal?.removeEventListener("abort", options.off);
        listeners.delete(listener);
        if (listeners.size > 0)
            return;
        this.#listeners.delete(type);
    }
    /**
     * Dispatch an event to its listeners
     *
     * - Dispatch to active listeners sequencially
     * - Return if one of the listeners returned something
     * - Dispatch to passive listeners concurrently
     * - Return if one of the listeners returned something
     * - Return nothing
     * @param value The object to emit
     * @returns `Some` if the event
     */
    async emit(type, value) {
        const listeners = this.#listeners.get(type);
        if (!listeners)
            return new none_None();
        const promises = new Array();
        for (const [listener, options] of listeners) {
            if (options.passive)
                continue;
            if (options.once)
                this.off(type, listener);
            const returned = await listener(...value);
            if (returned.isNone())
                continue;
            return returned;
        }
        for (const [listener, options] of listeners) {
            if (!options.passive)
                continue;
            if (options.once)
                this.off(type, listener);
            const returned = listener(...value);
            if (returned instanceof Promise) {
                promises.push(returned);
                continue;
            }
            if (returned.isNone())
                continue;
            return returned;
        }
        const returneds = await Promise.all(promises);
        for (const returned of returneds)
            if (returned.isSome())
                return returned;
        return new none_None();
    }
    /**
     * Like `.on`, but instead of returning to the target, capture the returned value in a future, and return nothing to the target
     * @param type
     * @param callback
     * @returns
     */
    wait(type, callback) {
        const future = new Future();
        const onEvent = async (...params) => {
            try {
                return await callback(future, ...params);
            }
            catch (e) {
                future.reject(e);
                throw e;
            }
        };
        const off = this.on(type, onEvent, { passive: true });
        return new cleaner_Cleaner(future.promise, off);
    }
}


//# sourceMappingURL=target.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/option/dist/esm/mods/option/option.mjs



var Option;
(function (Option) {
    function from(init) {
        if ("inner" in init)
            return new some_Some(init.inner);
        return new none_None();
    }
    Option.from = from;
    /**
     * Create an Option from a maybe undefined value
     * @param inner
     * @returns `Some<T>` if `T`, `None` if `undefined`
     */
    function wrap(inner) {
        if (inner == null)
            return new none_None();
        return new some_Some(inner);
    }
    Option.wrap = wrap;
    async function map(inner, mapper) {
        return Option.wrap(inner).map(mapper).then(o => o.get());
    }
    Option.map = map;
    function mapSync(inner, mapper) {
        return Option.wrap(inner).mapSync(mapper).get();
    }
    Option.mapSync = mapSync;
    function unwrap(inner) {
        return Option.wrap(inner).unwrap();
    }
    Option.unwrap = unwrap;
})(Option || (Option = {}));


//# sourceMappingURL=option.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/result.mjs





var Result;
(function (Result) {
    /**
     * Create a Result from a maybe Error value
     * @param inner
     * @returns `Ok<T>` if `T`, `Err<Error>` if `Error`
     */
    function from(inner) {
        if (inner instanceof Error)
            return new err_Err(inner);
        else
            return new ok_Ok(inner);
    }
    Result.from = from;
    /**
     * Create a Result from a boolean
     * @param value
     * @returns
     */
    function assert(value) {
        if (value)
            return new ok_Ok(undefined);
        else
            return new err_Err(undefined);
    }
    Result.assert = assert;
    function rewrap(wrapper) {
        try {
            return new ok_Ok(wrapper.unwrap());
        }
        catch (error) {
            return new err_Err(error);
        }
    }
    Result.rewrap = rewrap;
    /**
     * Catch an Err thrown from Err.throw
     * @param callback
     * @param type
     * @returns `Ok<T>` if no `Err` was thrown, `Err<E>` otherwise
     * @see Err.throw
     */
    async function unthrow(callback) {
        let ref;
        try {
            return await callback((e) => ref = e);
        }
        catch (e) {
            if (ref !== undefined)
                return ref;
            throw e;
        }
    }
    Result.unthrow = unthrow;
    /**
     * Catch an Err thrown from Err.throw
     * @param callback
     * @param type
     * @returns `Ok<T>` if no `Err` was thrown, `Err<E>` otherwise
     * @see Err.throw
     */
    function unthrowSync(callback) {
        let ref;
        try {
            return callback((e) => ref = e);
        }
        catch (e) {
            if (ref !== undefined)
                return ref;
            throw e;
        }
    }
    Result.unthrowSync = unthrowSync;
    /**
     * Wrap with catching
     * @param callback
     * @returns
     */
    async function catchAndWrap(callback) {
        try {
            return new ok_Ok(await callback());
        }
        catch (e) {
            return new err_Err(Catched.from(e));
        }
    }
    Result.catchAndWrap = catchAndWrap;
    /**
     * Wrap with catching
     * @param callback
     * @returns
     */
    function catchAndWrapSync(callback) {
        try {
            return new ok_Ok(callback());
        }
        catch (e) {
            return new err_Err(Catched.from(e));
        }
    }
    Result.catchAndWrapSync = catchAndWrapSync;
    /**
     * Catch
     * @param callback
     * @returns
     */
    async function recatch(callback) {
        try {
            return await callback();
        }
        catch (e) {
            return new err_Err(Catched.from(e));
        }
    }
    Result.recatch = recatch;
    /**
     * Catch
     * @param callback
     * @returns
     */
    function recatchSync(callback) {
        try {
            return callback();
        }
        catch (e) {
            return new err_Err(Catched.from(e));
        }
    }
    Result.recatchSync = recatchSync;
    /**
     * Transform `Iterable<Result<T,E>` into `Result<Array<T>, E>`
     * @param iterable
     * @returns `Result<Array<T>, E>`
     */
    function all(iterable) {
        return collect(iterate(iterable));
    }
    Result.all = all;
    function maybeAll(iterable) {
        return maybeCollect(maybeIterate(iterable));
    }
    Result.maybeAll = maybeAll;
    /**
     * Transform `Iterable<Result<T,E>` into `Iterator<T, Result<void, E>>`
     * @param iterable
     * @returns `Iterator<T, Result<void, E>>`
     */
    function* iterate(iterable) {
        for (const result of iterable) {
            if (result.isOk())
                yield result.get();
            else
                return result;
        }
        return ok_Ok.void();
    }
    Result.iterate = iterate;
    function* maybeIterate(iterable) {
        for (const result of iterable) {
            if (result == null)
                return result;
            else if (result.isOk())
                yield result.get();
            else
                return result;
        }
        return ok_Ok.void();
    }
    Result.maybeIterate = maybeIterate;
    /**
     * Transform `Iterator<T, Result<void, E>>` into `Result<Array<T>, E>`
     * @param iterator `Result<Array<T>, E>`
     */
    function collect(iterator) {
        const array = new Array();
        let result = iterator.next();
        for (; !result.done; result = iterator.next())
            array.push(result.value);
        return result.value.set(array);
    }
    Result.collect = collect;
    function maybeCollect(iterator) {
        const array = new Array();
        let result = iterator.next();
        for (; !result.done; result = iterator.next())
            array.push(result.value);
        return Option.mapSync(result.value, result => result.set(array));
    }
    Result.maybeCollect = maybeCollect;
    /**
     * Call the callback:
     * - if it throws, wrap the thrown error into `Catched` and throw it
     * - if the result is `Err`, unwrap it and throw it
     * - if the result is `Ok`, unwrap it and return it
     * @param callback
     * @returns `T` if `Ok`
     * @throws `Catched` if `callback()` throws, `E` if `Err`
     */
    async function catchAndUnwrap(callback) {
        let result;
        try {
            result = await callback();
        }
        catch (e) {
            throw Catched.from(e);
        }
        return result.unwrap();
    }
    Result.catchAndUnwrap = catchAndUnwrap;
    /**
     * Call the callback:
     * - if it throws, wrap the thrown error into `Catched` and throw it
     * - if the result is `Err`, unwrap it and throw it
     * - if the result is `Ok`, unwrap it and return it
     * @param callback
     * @returns `T` if `Ok`
     * @throws `Catched` if `callback()` throws, `E` if `Err`
     */
    function catchAndUnwrapSync(callback) {
        let result;
        try {
            result = callback();
        }
        catch (e) {
            throw Catched.from(e);
        }
        return result.unwrap();
    }
    Result.catchAndUnwrapSync = catchAndUnwrapSync;
    /**
     * Rethrow `CatchedError`
     * @param error
     * @returns `Err(error)` if not `CatchedError`
     * @throws `error.cause` if `CatchedError`
     */
    function rethrow(error) {
        if (error instanceof Catched)
            throw error.cause;
        return new err_Err(error);
    }
    Result.rethrow = rethrow;
})(Result || (Result = {}));


//# sourceMappingURL=result.mjs.map

;// CONCATENATED MODULE: ./src/libs/rpc/ok.ts

var RpcOkInit;
(function(RpcOkInit) {
    function clone(init) {
        const { jsonrpc, id, result } = init;
        return {
            jsonrpc,
            id,
            result
        };
    }
    RpcOkInit.clone = clone;
})(RpcOkInit || (RpcOkInit = {}));
(function(RpcOkInit) {
    function from(response) {
        const { jsonrpc, id, result } = response;
        return {
            jsonrpc,
            id,
            result
        };
    }
    RpcOkInit.from = from;
})(RpcOkInit || (RpcOkInit = {}));
class RpcOk extends ok_Ok {
    static from(init) {
        return new RpcOk(init.id, init.result);
    }
    constructor(id, result){
        super(result);
        this.id = id;
        this.result = result;
        this.jsonrpc = "2.0";
    }
}

;// CONCATENATED MODULE: ./src/libs/rpc/request.ts
var RpcRequestInit;
(function(RpcRequestInit) {
    function clone(init) {
        const { id, method, params } = init;
        return {
            id,
            method,
            params
        };
    }
    RpcRequestInit.clone = clone;
})(RpcRequestInit || (RpcRequestInit = {}));
class RpcRequest {
    static from(init) {
        const { id, method, params } = init;
        return new RpcRequest(id, method, params);
    }
    constructor(id, method, params){
        this.id = id;
        this.method = method;
        this.params = params;
        this.jsonrpc = "2.0";
    }
}

;// CONCATENATED MODULE: ./src/libs/rpc/err.ts

class RpcError extends Error {
    static from(error) {
        return new RpcError(error.message);
    }
    toJSON() {
        const { message } = this;
        return {
            message
        };
    }
}
class RpcErr extends err_Err {
    static from(init) {
        return new RpcErr(init.id, new RpcError(init.error.message));
    }
    constructor(id, error){
        super(error);
        this.id = id;
        this.error = error;
        this.jsonrpc = "2.0";
    }
}

;// CONCATENATED MODULE: ./src/libs/rpc/response.ts


var response_RpcResponse;
(function(RpcResponse) {
    function from(init) {
        if ("error" in init) return RpcErr.from(init);
        return RpcOk.from(init);
    }
    RpcResponse.from = from;
    function rewrap(id, result) {
        result.ignore();
        if (result.isOk()) return new RpcOk(id, result.inner);
        if (result.inner instanceof Error) return new RpcErr(id, RpcError.from(result.inner));
        return new RpcErr(id, new RpcError());
    }
    RpcResponse.rewrap = rewrap;
})(response_RpcResponse || (response_RpcResponse = {}));

;// CONCATENATED MODULE: ./node_modules/@swc/helpers/esm/_class_apply_descriptor_update.js
function _class_apply_descriptor_update(receiver, descriptor) {
    if (descriptor.set) {
        if (!descriptor.get) throw new TypeError("attempted to read set only private field");

        if (!("__destrWrapper" in descriptor)) {
            descriptor.__destrWrapper = {
                set value(v) {
                    descriptor.set.call(receiver, v);
                },
                get value() {
                    return descriptor.get.call(receiver);
                }
            };
        }

        return descriptor.__destrWrapper;
    } else {
        if (!descriptor.writable) {
            // This should only throw in strict mode, but class bodies are
            // always strict and private fields can only be used inside
            // class bodies.
            throw new TypeError("attempted to set read only private field");
        }

        return descriptor;
    }
}


;// CONCATENATED MODULE: ./node_modules/@swc/helpers/esm/_class_private_field_update.js



function _class_private_field_update(receiver, privateMap) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "update");
    return _class_apply_descriptor_update(receiver, descriptor);
}


;// CONCATENATED MODULE: ./src/libs/rpc/rpc.ts










var _id = /*#__PURE__*/ new WeakMap();
class rpc_RpcClient {
    get id() {
        return _class_private_field_get(this, _id);
    }
    create(init) {
        const { method, params } = init;
        const id = _class_private_field_update(this, _id).value++;
        return {
            jsonrpc: "2.0",
            id,
            method,
            params
        };
    }
    async fetch(input, init) {
        const { method, params, ...rest } = init;
        const request = this.create({
            method,
            params
        });
        return Rpc.fetch(input, {
            ...rest,
            ...request
        });
    }
    async tryFetchWithSocket(socket, request, signal) {
        return await Rpc.tryFetchWithSocket(socket, this.create(request), signal);
    }
    constructor(){
        _class_private_field_init(this, _id, {
            writable: true,
            value: void 0
        });
        _class_private_field_set(this, _id, 0);
    }
}
var Rpc;
(function(Rpc) {
    async function fetch(input, init) {
        const { id, method, params, ...rest } = init;
        const headers = new Headers(rest.headers);
        headers.set("Content-Type", "application/json");
        const request = new RpcRequest(id, method, params);
        const body = JSON.stringify(request);
        const res = await globalThis.fetch(input, {
            ...init,
            headers,
            body
        });
        if (!res.ok) {
            const error = new RpcError(await res.text());
            return new RpcErr(request.id, error);
        }
        const response = response_RpcResponse.from(await res.json());
        if (response.id !== request.id) return new err_Err(new Panic("Invalid response ID"));
        return response;
    }
    Rpc.fetch = fetch;
    async function tryFetchWithSocket(socket, request, signal) {
        const { id, method, params = [] } = request;
        socket.send(JSON.stringify(new RpcRequest(id, method, params)));
        const future = new Future();
        const onMessage = async (event)=>{
            const msgEvent = event;
            const response = response_RpcResponse.from(JSON.parse(msgEvent.data));
            if (response.id !== request.id) return;
            future.resolve(new ok_Ok(response));
        };
        const onError = (e)=>{
            const result = new err_Err(errors_ErroredError.from(e));
            future.resolve(result);
        };
        const onClose = (e)=>{
            const result = new err_Err(errors_ClosedError.from(e));
            future.resolve(result);
        };
        const onAbort = ()=>{
            socket.close();
            const result = new err_Err(errors_AbortedError.from(signal.reason));
            future.resolve(result);
        };
        try {
            socket.addEventListener("message", onMessage, {
                passive: true
            });
            socket.addEventListener("close", onClose, {
                passive: true
            });
            socket.addEventListener("error", onError, {
                passive: true
            });
            signal.addEventListener("abort", onAbort, {
                passive: true
            });
            return await future.promise;
        } finally{
            socket.removeEventListener("message", onMessage);
            socket.removeEventListener("close", onClose);
            socket.removeEventListener("error", onError);
            signal.removeEventListener("abort", onAbort);
        }
    }
    Rpc.tryFetchWithSocket = tryFetchWithSocket;
})(Rpc || (Rpc = {}));

;// CONCATENATED MODULE: ./src/libs/rpc/index.ts






;// CONCATENATED MODULE: ./src/libs/channel/channel.ts





class WebsitePort {
    async runPingLoop() {
        while(true){
            const result = await this.tryRequestOrSignal({
                method: "brume_ping"
            }, AbortSignal.timeout(1000));
            if (result.isErr()) {
                await this.events.emit("close", [
                    undefined
                ]);
                return;
            }
            await new Promise((ok)=>setTimeout(ok, 1000));
        }
    }
    async tryRouteRequest(request) {
        if (request.method === "brume_ping") return Ok.void();
        const returned = await this.events.emit("request", [
            request
        ]);
        if (returned.isSome()) return returned.inner;
        return new Err(new Error("Unhandled JSON-RPC request ".concat(request)));
    }
    async onRequest(request) {
        console.log(this.name, "->", request);
        const result = await this.tryRouteRequest(request);
        const response = RpcResponse.rewrap(request.id, result);
        console.log(this.name, "<-", response);
        this.port.postMessage(JSON.stringify(response));
    }
    async onResponse(response) {
        const returned = await this.events.emit("response", [
            response
        ]);
        if (returned.isSome()) return returned.inner;
        return new Err(new Error("Unhandled JSON-RPC response ".concat(response)));
    }
    async onMessage(message) {
        const data = JSON.parse(message.data);
        if ("method" in data) return await this.onRequest(data);
        return await this.onResponse(data);
    }
    async tryRequest(init) {
        const request = this.client.create(init);
        this.port.postMessage(JSON.stringify(request));
        return Plume.tryWaitOrCloseOrError(this.events, "response", (future, init)=>{
            if (init.id !== request.id) return new None();
            const response = RpcResponse.from(init);
            future.resolve(new Ok(response));
            return new Some(undefined);
        });
    }
    async tryRequestOrSignal(init, signal) {
        const request = this.client.create(init);
        this.port.postMessage(JSON.stringify(request));
        return Plume.tryWaitOrCloseOrErrorOrSignal(this.events, "response", (future, init)=>{
            if (init.id !== request.id) return new None();
            const response = RpcResponse.from(init);
            future.resolve(new Ok(response));
            return new Some(undefined);
        }, signal);
    }
    constructor(name, port){
        this.name = name;
        this.port = port;
        this.client = new RpcClient();
        this.uuid = crypto.randomUUID();
        this.events = new SuperEventTarget();
        const onMessage = this.onMessage.bind(this);
        this.port.addEventListener("message", onMessage, {
            passive: true
        });
        this.clean = ()=>{
            this.port.removeEventListener("message", onMessage);
        };
    }
}
class ExtensionPort {
    async tryRouteRequest(request) {
        if (request.method === "brume_ping") return ok_Ok.void();
        const returned = await this.events.emit("request", [
            request
        ]);
        if (returned.isSome()) return returned.inner;
        return new err_Err(new Error("Unhandled JSON-RPC request ".concat(request)));
    }
    async onRequest(request) {
        console.log(this.name, "->", request);
        const result = await this.tryRouteRequest(request);
        const response = response_RpcResponse.rewrap(request.id, result);
        console.log(this.name, "<-", response);
        tryBrowserSync(()=>{
            this.port.postMessage(JSON.stringify(response));
        }).ignore();
    }
    async onResponse(response) {
        const returned = await this.events.emit("response", [
            response
        ]);
        if (returned.isSome()) return returned.inner;
        return new err_Err(new Error("Unhandled JSON-RPC response ".concat(response)));
    }
    async onMessage(message) {
        const data = JSON.parse(message);
        if ("method" in data) return await this.onRequest(data);
        return await this.onResponse(data);
    }
    async onDisconnect() {
        await this.events.emit("close", [
            undefined
        ]);
    }
    async tryRequest(init) {
        return await Result.unthrow(async (t)=>{
            const request = this.client.create(init);
            tryBrowserSync(()=>{
                this.port.postMessage(JSON.stringify(request));
            }).throw(t);
            return tryWaitOrCloseOrError(this.events, "response", (future, init)=>{
                if (init.id !== request.id) return new none_None();
                const response = response_RpcResponse.from(init);
                future.resolve(new ok_Ok(response));
                return new some_Some(undefined);
            });
        });
    }
    constructor(name, port){
        this.name = name;
        this.port = port;
        this.client = new rpc_RpcClient();
        this.uuid = crypto.randomUUID();
        this.events = new target_SuperEventTarget();
        const onMessage = this.onMessage.bind(this);
        const onDisconnect = this.onDisconnect.bind(this);
        this.port.onMessage.addListener(onMessage);
        this.port.onDisconnect.addListener(onDisconnect);
        this.clean = ()=>{
            this.port.onMessage.removeListener(onMessage);
            this.port.onDisconnect.removeListener(onDisconnect);
        };
    }
}

;// CONCATENATED MODULE: ./node_modules/@hazae41/arrays/dist/esm/mods/arrays/arrays.mjs
/**
 * Get the last value
 * @param array
 * @returns
 */
function last(array) {
    return array[lastIndex(array)];
}
/**
 * Get the last index
 * @param array
 * @returns
 */
function lastIndex(array) {
    return array.length - 1;
}
/**
 * Get a random value using Math's PRNG
 * @param array
 * @returns
 */
function random(array) {
    return array[randomIndex(array)];
}
/**
 * Get a random index using Math's PRNG
 * @param array
 * @returns
 */
function randomIndex(array) {
    return Math.floor(Math.random() * array.length);
}
/**
 * Get a random value using WebCrypto's CSPRNG
 * @param array
 * @returns
 */
function cryptoRandom(array) {
    return array[cryptoRandomIndex(array)];
}
/**
 * Get a random value using WebCrypto's CSPRNG
 * @param array
 * @returns
 */
function cryptoRandomIndex(array) {
    const values = new Uint32Array(1);
    crypto.getRandomValues(values);
    return values[0] % array.length;
}
/**
 * Get a random value using Math's PRNG and delete it from the array
 * @param array
 * @returns
 */
function takeRandom(array) {
    const index = randomIndex(array);
    const element = array[index];
    array.splice(index, 1);
    return element;
}
/**
 * Get a random value using WebCrypto's CSPRNG and delete it from the array
 * @param array
 * @returns
 */
function takeCryptoRandom(array) {
    const index = cryptoRandomIndex(array);
    const element = array[index];
    array.splice(index, 1);
    return element;
}


//# sourceMappingURL=arrays.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/piscine/dist/esm/libs/signals/signals.mjs
var AbortSignals;
(function (AbortSignals) {
    function timeout(delay, parent) {
        return merge(AbortSignal.timeout(delay), parent);
    }
    AbortSignals.timeout = timeout;
    function merge(a, b) {
        if (b === undefined)
            return a;
        const c = new AbortController();
        const onAbort = (reason) => {
            c.abort(reason);
            a.removeEventListener("abort", onAbort);
            b.removeEventListener("abort", onAbort);
        };
        a.addEventListener("abort", onAbort, { passive: true });
        b.addEventListener("abort", onAbort, { passive: true });
        return c.signal;
    }
    AbortSignals.merge = merge;
})(AbortSignals || (AbortSignals = {}));


//# sourceMappingURL=signals.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/piscine/dist/esm/mods/pool/pool.mjs





var PoolOkEntry;
(function (PoolOkEntry) {
    function is(x) {
        return x.result.isOk();
    }
    PoolOkEntry.is = is;
})(PoolOkEntry || (PoolOkEntry = {}));
class EmptyPoolError extends Error {
    #class = EmptyPoolError;
    name = this.#class.name;
    constructor() {
        super(`Empty pool`);
    }
}
class EmptySlotError extends Error {
    #class = EmptySlotError;
    name = this.#class.name;
    constructor() {
        super(`Empty pool slot`);
    }
}
class Pool {
    create;
    params;
    events = new target_SuperEventTarget();
    capacity;
    signal;
    #controller;
    #allEntries;
    #allCleanups;
    #allPromises;
    #okEntries = new Set();
    /**
     * A pool of circuits
     * @param tor
     * @param params
     */
    constructor(create, params = {}) {
        this.create = create;
        this.params = params;
        const { capacity = 3 } = params;
        this.capacity = capacity;
        this.#controller = new AbortController();
        this.signal = AbortSignals.merge(this.#controller.signal, params.signal);
        this.#allEntries = new Array(capacity);
        this.#allCleanups = new Array(capacity);
        this.#allPromises = new Array(capacity);
        for (let index = 0; index < capacity; index++)
            this.#start(index);
    }
    abort(reason) {
        this.#controller.abort(reason);
    }
    #start(index) {
        const promise = this.#createAndUnwrap(index);
        this.#allPromises[index] = promise;
        promise.catch(e => console.debug({ e }));
    }
    async #tryCreate(index) {
        const { signal } = this;
        if (signal.aborted)
            return new err_Err(errors_AbortedError.from(signal.reason));
        return await this.create({ pool: this, index, signal });
    }
    async #createAndUnwrap(index) {
        const result = await Result.recatch(() => this.#tryCreate(index));
        if (result.isOk()) {
            const ok = new ok_Ok(result.inner.inner);
            const clean = () => result.inner.clean();
            const entry = { index, result: ok };
            this.#allEntries[index] = entry;
            this.#allCleanups[index] = clean;
            this.#okEntries.add(entry);
            this.events.emit("created", [entry]).catch(e => console.error({ e }));
        }
        else {
            const entry = { index, result };
            this.#allEntries[index] = entry;
            this.events.emit("created", [entry]).catch(e => console.error({ e }));
        }
        return result.clear().unwrap();
    }
    /**
     * Delete the index, restart the index, and return the entry
     * @param element
     * @returns
     */
    delete(index) {
        const entry = this.#allEntries.at(index);
        if (entry === undefined)
            return undefined;
        if (PoolOkEntry.is(entry)) {
            this.#okEntries.delete(entry);
            this.#allCleanups[index]();
            delete this.#allCleanups[index];
        }
        delete this.#allEntries[index];
        this.#start(index);
        this.events.emit("deleted", [entry]).catch(e => console.error({ e }));
        return entry;
    }
    /**
     * Number of open elements
     */
    get size() {
        return this.#okEntries.size;
    }
    /**
     * Iterator on open elements
     * @returns
     */
    [Symbol.iterator]() {
        return this.#okEntries.values();
    }
    /**
     * Get the element at index
     * @param index
     * @returns
     */
    async tryGet(index) {
        try {
            await this.#allPromises[index];
        }
        catch (e) { }
        return this.tryGetSync(index).unwrap();
    }
    /**
     * Get the element at index
     * @param index
     * @returns
     */
    tryGetSync(index) {
        const entry = this.#allEntries.at(index);
        if (entry === undefined)
            return new err_Err(new EmptySlotError());
        return new ok_Ok(entry.result);
    }
    /**
     * Wait for any element to be created, then get a random one using Math's PRNG
     * @returns
     */
    async tryGetRandom() {
        return await Result
            .catchAndWrap(() => Promise.any(this.#allPromises))
            .then(r => r.mapErrSync(e => e.cause))
            .then(r => r.mapSync(() => this.tryGetRandomSync().unwrap()));
    }
    /**
     * Get a random element from the pool using Math's PRNG, throws if none available
     * @returns
     */
    tryGetRandomSync() {
        if (!this.#okEntries.size)
            return new err_Err(new EmptyPoolError());
        const entries = [...this.#okEntries];
        const entry = random(entries);
        return new ok_Ok(entry);
    }
    /**
     * Wait for any circuit to be created, then get a random one using WebCrypto's CSPRNG
     * @returns
     */
    async tryGetCryptoRandom() {
        return await Result
            .catchAndWrap(() => Promise.any(this.#allPromises))
            .then(r => r.mapErrSync(e => e.cause))
            .then(r => r.mapSync(() => this.tryGetCryptoRandomSync().unwrap()));
    }
    /**
     * Get a random circuit from the pool using WebCrypto's CSPRNG, throws if none available
     * @returns
     */
    tryGetCryptoRandomSync() {
        if (!this.#okEntries.size)
            return new err_Err(new EmptyPoolError());
        const entries = [...this.#okEntries];
        const entry = cryptoRandom(entries);
        return new ok_Ok(entry);
    }
    static async takeRandom(pool) {
        return await pool.lock(async (pool) => {
            const result = await pool.tryGetRandom();
            if (result.isOk())
                pool.delete(result.inner.index);
            return result;
        });
    }
    static async takeCryptoRandom(pool) {
        return await pool.lock(async (pool) => {
            const result = await pool.tryGetCryptoRandom();
            if (result.isOk())
                pool.delete(result.inner.index);
            return result;
        });
    }
}


//# sourceMappingURL=pool.mjs.map

;// CONCATENATED MODULE: ./src/mods/background/content_script/index.ts







const mouse = {
    x: window.screen.width / 2,
    y: window.screen.height / 2
};
addEventListener("mousemove", (e)=>{
    mouse.x = e.screenX;
    mouse.y = e.screenY;
}, {
    passive: true
});
if (false || false) {
    const container = document.documentElement;
    const scriptBody = atob("LyoqKioqKi8gKCgpID0+IHsgLy8gd2VicGFja0Jvb3RzdHJhcAovKioqKioqLyAJInVzZSBzdHJpY3QiOwp2YXIgX193ZWJwYWNrX2V4cG9ydHNfXyA9IHt9OwoKOy8vIENPTkNBVEVOQVRFRCBNT0RVTEU6IC4vbm9kZV9tb2R1bGVzL0Bzd2MvaGVscGVycy9lc20vX2NsYXNzX2FwcGx5X2Rlc2NyaXB0b3JfZ2V0LmpzCmZ1bmN0aW9uIF9jbGFzc19hcHBseV9kZXNjcmlwdG9yX2dldChyZWNlaXZlciwgZGVzY3JpcHRvcikgewogICAgaWYgKGRlc2NyaXB0b3IuZ2V0KSByZXR1cm4gZGVzY3JpcHRvci5nZXQuY2FsbChyZWNlaXZlcik7CgogICAgcmV0dXJuIGRlc2NyaXB0b3IudmFsdWU7Cn0KCgo7Ly8gQ09OQ0FURU5BVEVEIE1PRFVMRTogLi9ub2RlX21vZHVsZXMvQHN3Yy9oZWxwZXJzL2VzbS9fY2xhc3NfZXh0cmFjdF9maWVsZF9kZXNjcmlwdG9yLmpzCmZ1bmN0aW9uIF9jbGFzc19leHRyYWN0X2ZpZWxkX2Rlc2NyaXB0b3IocmVjZWl2ZXIsIHByaXZhdGVNYXAsIGFjdGlvbikgewogICAgaWYgKCFwcml2YXRlTWFwLmhhcyhyZWNlaXZlcikpIHRocm93IG5ldyBUeXBlRXJyb3IoImF0dGVtcHRlZCB0byAiICsgYWN0aW9uICsgIiBwcml2YXRlIGZpZWxkIG9uIG5vbi1pbnN0YW5jZSIpOwoKICAgIHJldHVybiBwcml2YXRlTWFwLmdldChyZWNlaXZlcik7Cn0KCgo7Ly8gQ09OQ0FURU5BVEVEIE1PRFVMRTogLi9ub2RlX21vZHVsZXMvQHN3Yy9oZWxwZXJzL2VzbS9fY2xhc3NfcHJpdmF0ZV9maWVsZF9nZXQuanMKCgoKZnVuY3Rpb24gX2NsYXNzX3ByaXZhdGVfZmllbGRfZ2V0KHJlY2VpdmVyLCBwcml2YXRlTWFwKSB7CiAgICB2YXIgZGVzY3JpcHRvciA9IF9jbGFzc19leHRyYWN0X2ZpZWxkX2Rlc2NyaXB0b3IocmVjZWl2ZXIsIHByaXZhdGVNYXAsICJnZXQiKTsKICAgIHJldHVybiBfY2xhc3NfYXBwbHlfZGVzY3JpcHRvcl9nZXQocmVjZWl2ZXIsIGRlc2NyaXB0b3IpOwp9CgoKOy8vIENPTkNBVEVOQVRFRCBNT0RVTEU6IC4vbm9kZV9tb2R1bGVzL0Bzd2MvaGVscGVycy9lc20vX2NoZWNrX3ByaXZhdGVfcmVkZWNsYXJhdGlvbi5qcwpmdW5jdGlvbiBfY2hlY2tfcHJpdmF0ZV9yZWRlY2xhcmF0aW9uKG9iaiwgcHJpdmF0ZUNvbGxlY3Rpb24pIHsKICAgIGlmIChwcml2YXRlQ29sbGVjdGlvbi5oYXMob2JqKSkgewogICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoIkNhbm5vdCBpbml0aWFsaXplIHRoZSBzYW1lIHByaXZhdGUgZWxlbWVudHMgdHdpY2Ugb24gYW4gb2JqZWN0Iik7CiAgICB9Cn0KCgo7Ly8gQ09OQ0FURU5BVEVEIE1PRFVMRTogLi9ub2RlX21vZHVsZXMvQHN3Yy9oZWxwZXJzL2VzbS9fY2xhc3NfcHJpdmF0ZV9maWVsZF9pbml0LmpzCgoKZnVuY3Rpb24gX2NsYXNzX3ByaXZhdGVfZmllbGRfaW5pdChvYmosIHByaXZhdGVNYXAsIHZhbHVlKSB7CiAgICBfY2hlY2tfcHJpdmF0ZV9yZWRlY2xhcmF0aW9uKG9iaiwgcHJpdmF0ZU1hcCk7CiAgICBwcml2YXRlTWFwLnNldChvYmosIHZhbHVlKTsKfQoKCjsvLyBDT05DQVRFTkFURUQgTU9EVUxFOiAuL25vZGVfbW9kdWxlcy9Ac3djL2hlbHBlcnMvZXNtL19jbGFzc19hcHBseV9kZXNjcmlwdG9yX3NldC5qcwpmdW5jdGlvbiBfY2xhc3NfYXBwbHlfZGVzY3JpcHRvcl9zZXQocmVjZWl2ZXIsIGRlc2NyaXB0b3IsIHZhbHVlKSB7CiAgICBpZiAoZGVzY3JpcHRvci5zZXQpIGRlc2NyaXB0b3Iuc2V0LmNhbGwocmVjZWl2ZXIsIHZhbHVlKTsKICAgIGVsc2UgewogICAgICAgIGlmICghZGVzY3JpcHRvci53cml0YWJsZSkgewogICAgICAgICAgICAvLyBUaGlzIHNob3VsZCBvbmx5IHRocm93IGluIHN0cmljdCBtb2RlLCBidXQgY2xhc3MgYm9kaWVzIGFyZQogICAgICAgICAgICAvLyBhbHdheXMgc3RyaWN0IGFuZCBwcml2YXRlIGZpZWxkcyBjYW4gb25seSBiZSB1c2VkIGluc2lkZQogICAgICAgICAgICAvLyBjbGFzcyBib2RpZXMuCiAgICAgICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoImF0dGVtcHRlZCB0byBzZXQgcmVhZCBvbmx5IHByaXZhdGUgZmllbGQiKTsKICAgICAgICB9CiAgICAgICAgZGVzY3JpcHRvci52YWx1ZSA9IHZhbHVlOwogICAgfQp9CgoKOy8vIENPTkNBVEVOQVRFRCBNT0RVTEU6IC4vbm9kZV9tb2R1bGVzL0Bzd2MvaGVscGVycy9lc20vX2NsYXNzX3ByaXZhdGVfZmllbGRfc2V0LmpzCgoKCmZ1bmN0aW9uIF9jbGFzc19wcml2YXRlX2ZpZWxkX3NldChyZWNlaXZlciwgcHJpdmF0ZU1hcCwgdmFsdWUpIHsKICAgIHZhciBkZXNjcmlwdG9yID0gX2NsYXNzX2V4dHJhY3RfZmllbGRfZGVzY3JpcHRvcihyZWNlaXZlciwgcHJpdmF0ZU1hcCwgInNldCIpOwogICAgX2NsYXNzX2FwcGx5X2Rlc2NyaXB0b3Jfc2V0KHJlY2VpdmVyLCBkZXNjcmlwdG9yLCB2YWx1ZSk7CiAgICByZXR1cm4gdmFsdWU7Cn0KCgo7Ly8gQ09OQ0FURU5BVEVEIE1PRFVMRTogLi9ub2RlX21vZHVsZXMvQGhhemFlNDEvcmVzdWx0L2Rpc3QvZXNtL21vZHMvZGVidWcvZGVidWcubWpzCnZhciBEZWJ1ZzsKKGZ1bmN0aW9uIChEZWJ1ZykgewogICAgRGVidWcuZGVidWcgPSBmYWxzZTsKfSkoRGVidWcgfHwgKERlYnVnID0ge30pKTsKCgovLyMgc291cmNlTWFwcGluZ1VSTD1kZWJ1Zy5tanMubWFwCgo7Ly8gQ09OQ0FURU5BVEVEIE1PRFVMRTogLi9ub2RlX21vZHVsZXMvQGhhemFlNDEvcmVzdWx0L2Rpc3QvZXNtL21vZHMvcmVzdWx0L2Vycm9ycy5tanMKY2xhc3MgVW5pbXBsZW1lbnRlZCBleHRlbmRzICgvKiB1bnVzZWQgcHVyZSBleHByZXNzaW9uIG9yIHN1cGVyICovIG51bGwgJiYgKEVycm9yKSkgewogICAgI2NsYXNzID0gVW5pbXBsZW1lbnRlZDsKICAgIG5hbWUgPSB0aGlzLiNjbGFzcy5uYW1lOwp9CmNsYXNzIFBhbmljIGV4dGVuZHMgRXJyb3IgewogICAgI2NsYXNzID0gUGFuaWM7CiAgICBuYW1lID0gdGhpcy4jY2xhc3MubmFtZTsKICAgIHN0YXRpYyBmcm9tKGNhdXNlKSB7CiAgICAgICAgcmV0dXJuIG5ldyBQYW5pYyh1bmRlZmluZWQsIHsgY2F1c2UgfSk7CiAgICB9CiAgICBzdGF0aWMgZnJvbUFuZFRocm93KGNhdXNlKSB7CiAgICAgICAgdGhyb3cgUGFuaWMuZnJvbShjYXVzZSk7CiAgICB9Cn0KY2xhc3MgQ2F0Y2hlZCBleHRlbmRzICgvKiB1bnVzZWQgcHVyZSBleHByZXNzaW9uIG9yIHN1cGVyICovIG51bGwgJiYgKEVycm9yKSkgewogICAgI2NsYXNzID0gQ2F0Y2hlZDsKICAgIG5hbWUgPSB0aGlzLiNjbGFzcy5uYW1lOwogICAgc3RhdGljIGZyb20oY2F1c2UpIHsKICAgICAgICByZXR1cm4gbmV3IENhdGNoZWQodW5kZWZpbmVkLCB7IGNhdXNlIH0pOwogICAgfQogICAgc3RhdGljIGZyb21BbmRUaHJvdyhjYXVzZSkgewogICAgICAgIHRocm93IENhdGNoZWQuZnJvbShjYXVzZSk7CiAgICB9Cn0KCgovLyMgc291cmNlTWFwcGluZ1VSTD1lcnJvcnMubWpzLm1hcAoKOy8vIENPTkNBVEVOQVRFRCBNT0RVTEU6IC4vbm9kZV9tb2R1bGVzL0BoYXphZTQxL3Jlc3VsdC9kaXN0L2VzbS9tb2RzL3Jlc3VsdC9lcnIubWpzCgoKCgpjbGFzcyBFcnIgewogICAgI2lubmVyOwogICAgI3RpbWVvdXQ7CiAgICAvKioKICAgICAqIEEgZmFpbHVyZQogICAgICogQHBhcmFtIGlubmVyCiAgICAgKi8KICAgIGNvbnN0cnVjdG9yKGlubmVyKSB7CiAgICAgICAgdGhpcy4jaW5uZXIgPSBpbm5lcjsKICAgICAgICBpZiAoIURlYnVnLmRlYnVnKQogICAgICAgICAgICByZXR1cm47CiAgICAgICAgY29uc3QgZXJyb3IgPSBuZXcgUGFuaWMoYFVuaGFuZGxlZCByZXN1bHRgLCB7IGNhdXNlOiB0aGlzIH0pOwogICAgICAgIHRoaXMuI3RpbWVvdXQgPSBzZXRUaW1lb3V0KGFzeW5jICgpID0+IHsgdGhyb3cgZXJyb3I7IH0sIDEwMDApOwogICAgfQogICAgLyoqCiAgICAgKiBDcmVhdGUgYW4gZW1wdHkgYEVycmAKICAgICAqIEByZXR1cm5zIGBFcnIodm9pZClgCiAgICAgKi8KICAgIHN0YXRpYyB2b2lkKCkgewogICAgICAgIHJldHVybiBuZXcgRXJyKHVuZGVmaW5lZCk7CiAgICB9CiAgICAvKioKICAgICAqIENyZWF0ZSBhbiBgRXJyYAogICAgICogQHBhcmFtIGlubmVyCiAgICAgKiBAcmV0dXJucyBgRXJyKGlubmVyKWAKICAgICAqLwogICAgc3RhdGljIG5ldyhpbm5lcikgewogICAgICAgIHJldHVybiBuZXcgRXJyKGlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogQ3JlYXRlIGFuIGBFcnJgIHdpdGggYW4gYEVycm9yYCBpbnNpZGUKICAgICAqIEBwYXJhbSBtZXNzYWdlCiAgICAgKiBAcGFyYW0gb3B0aW9ucwogICAgICogQHJldHVybnMgYEVycjxFcnJvcj5gCiAgICAgKi8KICAgIHN0YXRpYyBlcnJvcihtZXNzYWdlLCBvcHRpb25zKSB7CiAgICAgICAgcmV0dXJuIG5ldyBFcnIobmV3IEVycm9yKG1lc3NhZ2UsIG9wdGlvbnMpKTsKICAgIH0KICAgIGdldCBpbm5lcigpIHsKICAgICAgICByZXR1cm4gdGhpcy4jaW5uZXI7CiAgICB9CiAgICAvKioKICAgICAqIFNldCB0aGlzIHJlc3VsdCBhcyBoYW5kbGVkCiAgICAgKi8KICAgIGlnbm9yZSgpIHsKICAgICAgICBpZiAoIXRoaXMuI3RpbWVvdXQpCiAgICAgICAgICAgIHJldHVybiB0aGlzOwogICAgICAgIGNsZWFyVGltZW91dCh0aGlzLiN0aW1lb3V0KTsKICAgICAgICB0aGlzLiN0aW1lb3V0ID0gdW5kZWZpbmVkOwogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBUeXBlIGd1YXJkIGZvciBgT2tgCiAgICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYE9rYCwgYGZhbHNlYCBpZiBgRXJyYAogICAgICovCiAgICBpc09rKCkgewogICAgICAgIHJldHVybiBmYWxzZTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyB0cnVlIGlmIHRoZSByZXN1bHQgaXMgYE9rYCBhbmQgdGhlIHZhbHVlIGluc2lkZSBvZiBpdCBtYXRjaGVzIGEgcHJlZGljYXRlCiAgICAgKiBAcGFyYW0gb2tQcmVkaWNhdGUKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgT2tgIGFuZCBgYXdhaXQgb2tQcmVkaWNhdGUodGhpcy5pbm5lcilgLCBgZmFsc2VgIG90aGVyd2lzZQogICAgICovCiAgICBhc3luYyBpc09rQW5kKG9rUHJlZGljYXRlKSB7CiAgICAgICAgcmV0dXJuIGZhbHNlOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIHRydWUgaWYgdGhlIHJlc3VsdCBpcyBgT2tgIGFuZCB0aGUgdmFsdWUgaW5zaWRlIG9mIGl0IG1hdGNoZXMgYSBwcmVkaWNhdGUKICAgICAqIEBwYXJhbSBva1ByZWRpY2F0ZQogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBPa2AgYW5kIGBhd2FpdCBva1ByZWRpY2F0ZSh0aGlzLmlubmVyKWAsIGBmYWxzZWAgb3RoZXJ3aXNlCiAgICAgKi8KICAgIGlzT2tBbmRTeW5jKG9rUHJlZGljYXRlKSB7CiAgICAgICAgcmV0dXJuIGZhbHNlOwogICAgfQogICAgLyoqCiAgICAgKiBUeXBlIGd1YXJkIGZvciBgRXJyYAogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBFcnJgLCBgZmFsc2VgIGlmIGBPa2AKICAgICAqLwogICAgaXNFcnIoKSB7CiAgICAgICAgcmV0dXJuIHRydWU7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgdHJ1ZSBpZiB0aGUgcmVzdWx0IGlzIGBFcnJgIGFuZCB0aGUgdmFsdWUgaW5zaWRlIG9mIGl0IG1hdGNoZXMgYSBwcmVkaWNhdGUKICAgICAqIEBwYXJhbSBlcnJQcmVkaWNhdGUKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgRXJyYCBhbmQgYGF3YWl0IGVyclByZWRpY2F0ZSh0aGlzLmlubmVyKWAsIGBmYWxzZWAgb3RoZXJ3aXNlCiAgICAgKi8KICAgIGFzeW5jIGlzRXJyQW5kKGVyclByZWRpY2F0ZSkgewogICAgICAgIHJldHVybiBhd2FpdCBlcnJQcmVkaWNhdGUodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgdHJ1ZSBpZiB0aGUgcmVzdWx0IGlzIGBFcnJgIGFuZCB0aGUgdmFsdWUgaW5zaWRlIG9mIGl0IG1hdGNoZXMgYSBwcmVkaWNhdGUKICAgICAqIEBwYXJhbSBlcnJQcmVkaWNhdGUKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgRXJyYCBhbmQgYGF3YWl0IGVyclByZWRpY2F0ZSh0aGlzLmlubmVyKWAsIGBmYWxzZWAgb3RoZXJ3aXNlCiAgICAgKi8KICAgIGlzRXJyQW5kU3luYyhlcnJQcmVkaWNhdGUpIHsKICAgICAgICByZXR1cm4gZXJyUHJlZGljYXRlKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBDb21waWxlLXRpbWUgc2FmZWx5IGdldCBgdGhpcy5pbm5lcmAKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYAogICAgICovCiAgICBnZXQoKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gdGhpcy5pbm5lcjsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtIGBSZXN1bHQ8VCwgRT5gIGludG8gYE9wdGlvbjxUPmAKICAgICAqIEByZXR1cm5zIGBTb21lKHRoaXMuaW5uZXIpYCBpZiBgT2tgLCBgTm9uZWAgaWYgYEVycmAKICAgICAqLwogICAgb2soKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gbmV3IE5vbmUoKTsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtIGBSZXN1bHQ8VCwgRT5gIGludG8gYE9wdGlvbjxFPmAKICAgICAqIEByZXR1cm5zIGBTb21lKHRoaXMuaW5uZXIpYCBpZiBgRXJyYCwgYE5vbmVgIGlmIGBPa2AKICAgICAqLwogICAgZXJyKCkgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIG5ldyBTb21lKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGFuIGl0ZXJhdG9yIG92ZXIgdGhlIHBvc3NpYmx5IGNvbnRhaW5lZCB2YWx1ZQogICAgICogQHlpZWxkcyBgdGhpcy5pbm5lcmAgaWYgYE9rYAogICAgICovCiAgICAqW1N5bWJvbC5pdGVyYXRvcl0oKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm47CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBgUmVzdWx0PFQsRT5gIGludG8gYFtULEVdYAogICAgICogQHJldHVybnMgYFt0aGlzLmlubmVyLCB1bmRlZmluZWRdYCBpZiBgT2tgLCBgW3VuZGVmaW5lZCwgdGhpcy5pbm5lcl1gIGlmIGBFcnJgCiAgICAgKi8KICAgIHNwbGl0KCkgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIFt1bmRlZmluZWQsIHRoaXMuaW5uZXJdOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIHRydWUgaWYgdGhlIHJlc3VsdCBpcyBhbiBgT2tgIHZhbHVlIGNvbnRhaW5pbmcgdGhlIGdpdmVuIHZhbHVlCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgT2tgIGFuZCBgdGhpcy5pbm5lciA9PT0gdmFsdWVgLCBgZmFsc2VgIG90aGVyd2lzZQogICAgICovCiAgICBjb250YWlucyh2YWx1ZSkgewogICAgICAgIHJldHVybiBmYWxzZTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyB0cnVlIGlmIHRoZSByZXN1bHQgaXMgYW4gYEVycmAgdmFsdWUgY29udGFpbmluZyB0aGUgZ2l2ZW4gdmFsdWUKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBFcnJgIGFuZCBgdGhpcy5pbm5lciA9PT0gdmFsdWVgLCBgZmFsc2VgIG90aGVyd2lzZQogICAgICovCiAgICBjb250YWluc0Vycih2YWx1ZSkgewogICAgICAgIHJldHVybiB0aGlzLmlubmVyID09PSB2YWx1ZTsKICAgIH0KICAgIC8qKgogICAgICogR2V0IHRoZSBpbm5lciB2YWx1ZSBvciB0aHJvdyB0byB0aGUgY2xvc2VzdCBgUmVzdWx0LnVudGhyb3dgCiAgICAgKiBAcGFyYW0gdGhyb3dlciBUaGUgdGhyb3dlciBmcm9tIGBSZXN1bHQudW50aHJvd2AKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgT2tgCiAgICAgKiBAdGhyb3dzIGB1bmRlZmluZWRgIGlmIGBFcnJgCiAgICAgKiBAc2VlIFJlc3VsdC51bnRocm93CiAgICAgKiBAc2VlIFJlc3VsdC51bnRocm93U3luYwogICAgICovCiAgICB0aHJvdyh0aHJvd2VyKSB7CiAgICAgICAgdGhyb3dlcih0aGlzKTsKICAgICAgICB0aHJvdyBuZXcgUGFuaWMoYFRocm93biByZXN1bHQgd2FzIHRyeS1jYXRjaGVkYCk7CiAgICB9CiAgICAvKioKICAgICAqIEdldCB0aGUgaW5uZXIgdmFsdWUgb3IgdGhyb3cgdGhlIGlubmVyIGVycm9yIHdyYXBwZWQgaW5zaWRlIGFub3RoZXIgRXJyb3IKICAgICAqIEBwYXJhbSBtZXNzYWdlCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAgaWYgYE9rYCwgYEVycm9yKG1lc3NhZ2UsIHsgY2F1c2U6IHRoaXMuaW5uZXIgfSlgIGlmIGBFcnJgCiAgICAgKi8KICAgIGV4cGVjdChtZXNzYWdlKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICB0aHJvdyBuZXcgUGFuaWMobWVzc2FnZSwgeyBjYXVzZTogdGhpcy5pbm5lciB9KTsKICAgIH0KICAgIC8qKgogICAgICogR2V0IHRoZSBpbm5lciBlcnJvciBvciB0aHJvdyB0aGUgaW5uZXIgdmFsdWUgd3JhcHBlZCBpbnNpZGUgYW5vdGhlciBFcnJvcgogICAgICogQHBhcmFtIG1lc3NhZ2UKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgRXJyYCwgYEVycm9yKG1lc3NhZ2UsIHsgY2F1c2U6IHRoaXMuaW5uZXIgfSlgIGlmIGBPa2AKICAgICAqLwogICAgZXhwZWN0RXJyKG1lc3NhZ2UpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiB0aGlzLmlubmVyOwogICAgfQogICAgLyoqCiAgICAgKiBHZXQgdGhlIGlubmVyIHZhbHVlIG9yIHRocm93IHRoZSBpbm5lciBlcnJvcgogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBPa2AKICAgICAqIEB0aHJvd3MgYHRoaXMuaW5uZXJgIGlmIGBFcnJgCiAgICAgKi8KICAgIHVud3JhcCgpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHRocm93IG5ldyBQYW5pYyh1bmRlZmluZWQsIHsgY2F1c2U6IHRoaXMuaW5uZXIgfSk7CiAgICB9CiAgICAvKioKICAgICAqIFRocm93IHRoZSBpbm5lciB2YWx1ZSBvciBnZXQgdGhlIGlubmVyIGVycm9yCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAgaWYgYEVycmAKICAgICAqIEB0aHJvd3MgYHRoaXMuaW5uZXJgIGlmIGBPa2AKICAgICAqLwogICAgdW53cmFwRXJyKCkgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIHRoaXMuaW5uZXI7CiAgICB9CiAgICAvKioKICAgICAqIEdldCB0aGUgaW5uZXIgdmFsdWUgb3IgYSBkZWZhdWx0IG9uZQogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAgaWYgYE9rYCwgYHZhbHVlYCBpZiBgRXJyYAogICAgICovCiAgICB1bndyYXBPcih2YWx1ZSkgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIHZhbHVlOwogICAgfQogICAgLyoqCiAgICAgKiBHZXQgdGhlIGlubmVyIHZhbHVlIG9yIGNvbXB1dGUgYSBkZWZhdWx0IG9uZSBmcm9tIHRoZSBpbm5lciBlcnJvcgogICAgICogQHBhcmFtIGVyck1hcHBlcgogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBPa2AsIGBhd2FpdCBlcnJNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBFcnJgCiAgICAgKiBAdGhyb3dzIGlmIGBhd2FpdCBlcnJNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICBhc3luYyB1bndyYXBPckVsc2UoZXJyTWFwcGVyKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gYXdhaXQgZXJyTWFwcGVyKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBHZXQgdGhlIGlubmVyIHZhbHVlIG9yIGNvbXB1dGUgYSBkZWZhdWx0IG9uZSBmcm9tIHRoZSBpbm5lciBlcnJvcgogICAgICogQHBhcmFtIGVyck1hcHBlcgogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBPa2AsIGBlcnJNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBFcnJgCiAgICAgKiBAdGhyb3dzIGlmIGBlcnJNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICB1bndyYXBPckVsc2VTeW5jKGVyck1hcHBlcikgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIGVyck1hcHBlcih0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtIFJlc3VsdDxQcm9taXNlPFQ+LCBFPiBpbnRvIFByb21pc2U8UmVzdWx0PFQsIEU+PgogICAgICogQHJldHVybnMgYGF3YWl0IHRoaXMuaW5uZXJgIGlmIGBPa2AsIGB0aGlzYCBpZiBgRXJyYAogICAgICovCiAgICBhc3luYyBhd2FpdCgpIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtIFJlc3VsdDxULCBQcm9taXNlPEU+PiBpbnRvIFByb21pc2U8UmVzdWx0PFQsIEU+PgogICAgICogQHJldHVybnMgYGF3YWl0IHRoaXMuaW5uZXJgIGlmIGBFcnJgLCBgdGhpc2AgaWYgYE9rYAogICAgICovCiAgICBhc3luYyBhd2FpdEVycigpIHsKICAgICAgICByZXR1cm4gbmV3IEVycihhd2FpdCB0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtIFJlc3VsdDxQcm9taXNlPFQ+LCBQcm9taXNlPEU+PiBpbnRvIFByb21pc2U8UmVzdWx0PFQsIEU+PgogICAgICogQHJldHVybnMgYGF3YWl0IHRoaXMuaW5uZXJgCiAgICAgKi8KICAgIGFzeW5jIGF3YWl0QWxsKCkgewogICAgICAgIHJldHVybiBhd2FpdCB0aGlzLmF3YWl0RXJyKCk7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBgUmVzdWx0PFQsIEU+YCBpbnRvIGBSZXN1bHQ8dm9pZCwgRT5gCiAgICAgKiBAcmV0dXJucyBgT2s8dm9pZD5gIGlmIGBPazxUPmAsIGBFcnI8RT5gIGlmIGBFPEU+YAogICAgICovCiAgICBjbGVhcigpIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtIGBSZXN1bHQ8VCwgRT5gIGludG8gYFJlc3VsdDxULCB2b2lkPmAKICAgICAqIEByZXR1cm5zIGBPazxUPmAgaWYgYE9rPFQ+YCwgYEVycjx2b2lkPmAgaWYgYEU8RT5gCiAgICAgKi8KICAgIGNsZWFyRXJyKCkgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIEVyci52b2lkKCk7CiAgICB9CiAgICAvKioKICAgICAqIENhbGxzIHRoZSBnaXZlbiBjYWxsYmFjayB3aXRoIHRoZSBpbm5lciB2YWx1ZSBpZiBgT2tgCiAgICAgKiBAcGFyYW0gb2tDYWxsYmFjawogICAgICogQHJldHVybnMgYHRoaXNgCiAgICAgKi8KICAgIGFzeW5jIGluc3BlY3Qob2tDYWxsYmFjaykgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBDYWxscyB0aGUgZ2l2ZW4gY2FsbGJhY2sgd2l0aCB0aGUgaW5uZXIgdmFsdWUgaWYgYE9rYAogICAgICogQHBhcmFtIG9rQ2FsbGJhY2sKICAgICAqIEByZXR1cm5zIGB0aGlzYAogICAgICovCiAgICBpbnNwZWN0U3luYyhva0NhbGxiYWNrKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIENhbGxzIHRoZSBnaXZlbiBjYWxsYmFjayB3aXRoIHRoZSBpbm5lciB2YWx1ZSBpZiBgRXJyYAogICAgICogQHBhcmFtIGVyckNhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgdGhpc2AKICAgICAqLwogICAgYXN5bmMgaW5zcGVjdEVycihlcnJDYWxsYmFjaykgewogICAgICAgIGF3YWl0IGVyckNhbGxiYWNrKHRoaXMuaW5uZXIpOwogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBDYWxscyB0aGUgZ2l2ZW4gY2FsbGJhY2sgd2l0aCB0aGUgaW5uZXIgdmFsdWUgaWYgYEVycmAKICAgICAqIEBwYXJhbSBlcnJDYWxsYmFjawogICAgICogQHJldHVybnMgYHRoaXNgCiAgICAgKi8KICAgIGluc3BlY3RFcnJTeW5jKGVyckNhbGxiYWNrKSB7CiAgICAgICAgZXJyQ2FsbGJhY2sodGhpcy5pbm5lcik7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybiBhIG5ldyBgT2tgIGJ1dCB3aXRoIHRoZSBnaXZlbiBgaW5uZXJgCiAgICAgKiBAcGFyYW0gaW5uZXIKICAgICAqIEByZXR1cm5zIGBPayhpbm5lcilgIGlmIGBPa2AsIGB0aGlzYCBpZiBgRXJyYAogICAgICovCiAgICBzZXQoaW5uZXIpIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJuIGEgbmV3IGBFcnJgIGJ1dCB3aXRoIHRoZSBnaXZlbiBgaW5uZXJgCiAgICAgKiBAcGFyYW0gaW5uZXIKICAgICAqIEByZXR1cm5zIGBFcnIoaW5uZXIpYCBpZiBgRXJyYCwgYHRoaXNgIGlmIGBPa2AKICAgICAqLwogICAgc2V0RXJyKGlubmVyKSB7CiAgICAgICAgcmV0dXJuIG5ldyBFcnIoaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBNYXAgdGhlIGlubmVyIHZhbHVlIGludG8gYW5vdGhlcgogICAgICogQHBhcmFtIG9rTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgT2soYXdhaXQgb2tNYXBwZXIodGhpcy5pbm5lcikpYCBpZiBgT2tgLCBgdGhpc2AgaWYgYEVycmAKICAgICAqIEB0aHJvd3MgaWYgYGF3YWl0IG9rTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgYXN5bmMgbWFwKG9rTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIE1hcCB0aGUgaW5uZXIgdmFsdWUgaW50byBhbm90aGVyCiAgICAgKiBAcGFyYW0gb2tNYXBwZXIKICAgICAqIEByZXR1cm5zIGBPayhva01hcHBlcih0aGlzLmlubmVyKSlgIGlmIGBPa2AsIGB0aGlzYCBpZiBgRXJyYAogICAgICogQHRocm93cyBpZiBgb2tNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICBtYXBTeW5jKG9rTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIE1hcCB0aGUgaW5uZXIgZXJyb3IgaW50byBhbm90aGVyCiAgICAgKiBAcGFyYW0gZXJyTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgRXJyKGF3YWl0IGVyck1hcHBlcih0aGlzLmlubmVyKSlgIGlmIGBFcnJgLCBgdGhpc2AgaWYgYE9rYAogICAgICogQHRocm93cyBpZiBgYXdhaXQgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgYXN5bmMgbWFwRXJyKGVyck1hcHBlcikgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIG5ldyBFcnIoYXdhaXQgZXJyTWFwcGVyKHRoaXMuaW5uZXIpKTsKICAgIH0KICAgIC8qKgogICAgICogTWFwIHRoZSBpbm5lciBlcnJvciBpbnRvIGFub3RoZXIKICAgICAqIEBwYXJhbSBlcnJNYXBwZXIKICAgICAqIEByZXR1cm5zIGBFcnIoZXJyTWFwcGVyKHRoaXMuaW5uZXIpKWAgaWYgYEVycmAsIGB0aGlzYCBpZiBgT2tgCiAgICAgKiBAdGhyb3dzIGlmIGBlcnJNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICBtYXBFcnJTeW5jKGVyck1hcHBlcikgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIG5ldyBFcnIoZXJyTWFwcGVyKHRoaXMuaW5uZXIpKTsKICAgIH0KICAgIC8qKgogICAgICogTWFwIHRoZSBpbm5lciB2YWx1ZSBpbnRvIGFub3RoZXIsIG9yIGEgZGVmYXVsdCBvbmUKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHBhcmFtIG9rTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgYXdhaXQgb2tNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBPa2AsIGB2YWx1ZWAgaWYgYEVycmAKICAgICAqIEB0aHJvd3MgaWYgYGF3YWl0IG9rTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgYXN5bmMgbWFwT3IodmFsdWUsIG9rTWFwcGVyKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gdmFsdWU7CiAgICB9CiAgICAvKioKICAgICAqIE1hcCB0aGUgaW5uZXIgdmFsdWUgaW50byBhbm90aGVyLCBvciBhIGRlZmF1bHQgb25lCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEBwYXJhbSBva01hcHBlcgogICAgICogQHJldHVybnMgYG9rTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgT2tgLCBgdmFsdWVgIGlmIGBFcnJgCiAgICAgKiBAdGhyb3dzIGlmIGBva01hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIG1hcE9yU3luYyh2YWx1ZSwgb2tNYXBwZXIpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiB2YWx1ZTsKICAgIH0KICAgIC8qKgogICAgICogTWFwIHRoZSBpbm5lciB2YWx1ZSBpbnRvIGFub3RoZXIsIG9yIGEgZGVmYXVsdCBvbmUKICAgICAqIEBwYXJhbSBlcnJNYXBwZXIKICAgICAqIEBwYXJhbSBva01hcHBlcgogICAgICogQHJldHVybnMgYGF3YWl0IG9rTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgT2tgLCBgYXdhaXQgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgRXJyYAogICAgICogQHRocm93cyBpZiBgYXdhaXQgb2tNYXBwZXIodGhpcy5pbm5lcilgIG9yIGBhd2FpdCBlcnJNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICBhc3luYyBtYXBPckVsc2UoZXJyTWFwcGVyLCBva01hcHBlcikgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIGF3YWl0IGVyck1hcHBlcih0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogTWFwIHRoZSBpbm5lciB2YWx1ZSBpbnRvIGFub3RoZXIsIG9yIGEgZGVmYXVsdCBvbmUKICAgICAqIEBwYXJhbSBlcnJNYXBwZXIKICAgICAqIEBwYXJhbSBva01hcHBlcgogICAgICogQHJldHVybnMgYG9rTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgT2tgLCBgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgRXJyYAogICAgICogQHRocm93cyBpZiBgb2tNYXBwZXIodGhpcy5pbm5lcilgIG9yIGBlcnJNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICBtYXBPckVsc2VTeW5jKGVyck1hcHBlciwgb2tNYXBwZXIpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiBlcnJNYXBwZXIodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybiBgdmFsdWVgIGlmIGBPa2AsIHJldHVybiBgdGhpc2AgaWYgYEVycmAKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHJldHVybnMgYHZhbHVlYCBpZiBgT2tgLCBgdGhpc2AgaWYgYEVycmAKICAgICAqLwogICAgYW5kKHZhbHVlKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybiBgYXdhaXQgb2tNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBPa2AsIHJldHVybiBgdGhpc2AgaWYgYEVycmAKICAgICAqIEBwYXJhbSBva01hcHBlcgogICAgICogQHJldHVybnMgYGF3YWl0IG9rTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgT2tgLCBgdGhpc2AgaWYgYEVycmAKICAgICAqIEB0aHJvd3MgaWYgYGF3YWl0IG9rTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgYXN5bmMgYW5kVGhlbihva01hcHBlcikgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm4gYG9rTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgT2tgLCByZXR1cm4gYHRoaXNgIGlmIGBFcnJgCiAgICAgKiBAcGFyYW0gb2tNYXBwZXIKICAgICAqIEByZXR1cm5zIGBva01hcHBlcih0aGlzLmlubmVyKWAgaWYgYE9rYCwgYHRoaXNgIGlmIGBFcnJgCiAgICAgKiBAdGhyb3dzIGlmIGBva01hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIGFuZFRoZW5TeW5jKG9rTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybiBgdmFsdWVgIGlmIGBFcnJgLCByZXR1cm4gYHRoaXNgIGlmIGBPa2AKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHJldHVybnMgYHZhbHVlYCBpZiBgRXJyYCwgYHRoaXNgIGlmIGBPa2AKICAgICAqLwogICAgb3IodmFsdWUpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiB2YWx1ZTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJuIGBhd2FpdCBlcnJNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBFcnJgLCByZXR1cm4gYHRoaXNgIGlmIGBPa2AKICAgICAqIEBwYXJhbSBlcnJNYXBwZXIKICAgICAqIEByZXR1cm5zIGBhd2FpdCBlcnJNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBFcnJgLCBgdGhpc2AgaWYgYE9rYAogICAgICogQHRocm93cyBpZiBgYXdhaXQgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgYXN5bmMgb3JFbHNlKGVyck1hcHBlcikgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIGF3YWl0IGVyck1hcHBlcih0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJuIGBlcnJNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBFcnJgLCByZXR1cm4gYHRoaXNgIGlmIGBPa2AKICAgICAqIEBwYXJhbSBlcnJNYXBwZXIKICAgICAqIEByZXR1cm5zIGBlcnJNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBFcnJgLCBgdGhpc2AgaWYgYE9rYAogICAgICogQHRocm93cyBpZiBgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgb3JFbHNlU3luYyhlcnJNYXBwZXIpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiBlcnJNYXBwZXIodGhpcy5pbm5lcik7CiAgICB9Cn0KCgovLyMgc291cmNlTWFwcGluZ1VSTD1lcnIubWpzLm1hcAoKOy8vIENPTkNBVEVOQVRFRCBNT0RVTEU6IC4vbm9kZV9tb2R1bGVzL0BoYXphZTQxL29wdGlvbi9kaXN0L2VzbS9tb2RzL29wdGlvbi9ub25lLm1qcwoKCmNsYXNzIE5vbmVFcnJvciBleHRlbmRzIEVycm9yIHsKICAgIGNvbnN0cnVjdG9yKCkgewogICAgICAgIHN1cGVyKGBPcHRpb24gaXMgYSBOb25lYCk7CiAgICB9Cn0KY2xhc3MgTm9uZSB7CiAgICBpbm5lcjsKICAgIC8qKgogICAgICogQW4gZW1wdHkgdmFsdWUKICAgICAqLwogICAgY29uc3RydWN0b3IoaW5uZXIgPSB1bmRlZmluZWQpIHsKICAgICAgICB0aGlzLmlubmVyID0gaW5uZXI7CiAgICB9CiAgICAvKioKICAgICAqIENyZWF0ZSBhIGBOb25lYAogICAgICogQHJldHVybnMgYE5vbmVgCiAgICAgKi8KICAgIHN0YXRpYyBuZXcoKSB7CiAgICAgICAgcmV0dXJuIG5ldyBOb25lKCk7CiAgICB9CiAgICBzdGF0aWMgZnJvbShpbml0KSB7CiAgICAgICAgcmV0dXJuIG5ldyBOb25lKCk7CiAgICB9CiAgICAvKioKICAgICAqIFR5cGUgZ3VhcmQgZm9yIGBTb21lYAogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBTb21lYCwgYGZhbHNlYCBpZiBgTm9uZWAKICAgICAqLwogICAgaXNTb21lKCkgewogICAgICAgIHJldHVybiBmYWxzZTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBgdHJ1ZWAgaWYgdGhlIG9wdGlvbiBpcyBhIGBTb21lYCBhbmQgdGhlIHZhbHVlIGluc2lkZSBvZiBpdCBtYXRjaGVzIGEgcHJlZGljYXRlCiAgICAgKiBAcGFyYW0gc29tZVByZWRpY2F0ZQogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBTb21lYCBhbmQgYGF3YWl0IHNvbWVQcmVkaWNhdGUodGhpcy5pbm5lcilgLCBgTm9uZWAgb3RoZXJ3aXNlCiAgICAgKi8KICAgIGFzeW5jIGlzU29tZUFuZChzb21lUHJlZGljYXRlKSB7CiAgICAgICAgcmV0dXJuIGZhbHNlOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGB0cnVlYCBpZiB0aGUgb3B0aW9uIGlzIGEgYFNvbWVgIGFuZCB0aGUgdmFsdWUgaW5zaWRlIG9mIGl0IG1hdGNoZXMgYSBwcmVkaWNhdGUKICAgICAqIEBwYXJhbSBzb21lUHJlZGljYXRlCiAgICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYFNvbWVgIGFuZCBgc29tZVByZWRpY2F0ZSh0aGlzLmlubmVyKWAsIGBOb25lYCBvdGhlcndpc2UKICAgICAqLwogICAgaXNTb21lQW5kU3luYyhzb21lUHJlZGljYXRlKSB7CiAgICAgICAgcmV0dXJuIGZhbHNlOwogICAgfQogICAgLyoqCiAgICAgKiBUeXBlIGd1YXJkIGZvciBgTm9uZWAKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgTm9uZWAsIGBmYWxzZWAgaWYgYFNvbWVgCiAgICAgKi8KICAgIGlzTm9uZSgpIHsKICAgICAgICByZXR1cm4gdHJ1ZTsKICAgIH0KICAgIC8qKgogICAgICogQ29tcGlsZS10aW1lIHNhZmVseSBnZXQgYHRoaXMuaW5uZXJgCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAKICAgICAqLwogICAgZ2V0KCkgewogICAgICAgIHJldHVybiB0aGlzLmlubmVyOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGFuIGl0ZXJhdG9yIG92ZXIgdGhlIHBvc3NpYmx5IGNvbnRhaW5lZCB2YWx1ZQogICAgICogQHlpZWxkcyBgdGhpcy5pbm5lcmAgaWYgYFNvbWVgCiAgICAgKi8KICAgICpbU3ltYm9sLml0ZXJhdG9yXSgpIHsKICAgICAgICByZXR1cm47CiAgICB9CiAgICAvKioKICAgICAqIEdldCB0aGUgaW5uZXIgdmFsdWUgaWYgYFNvbWVgLCB0aHJvdyBgRXJyb3IobWVzc2FnZSlgIG90aGVyd2lzZQogICAgICogQHBhcmFtIG1lc3NhZ2UKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgU29tZWAKICAgICAqIEB0aHJvd3MgYEVycm9yKG1lc3NhZ2UpYCBpZiBgTm9uZWAKICAgICAqLwogICAgZXhwZWN0KG1lc3NhZ2UpIHsKICAgICAgICB0aHJvdyBuZXcgRXJyb3IobWVzc2FnZSwgeyBjYXVzZTogbmV3IE5vbmVFcnJvcigpIH0pOwogICAgfQogICAgLyoqCiAgICAgKiBHZXQgdGhlIGlubmVyIHZhbHVlIG9yIHRocm93IGEgTm9uZUVycm9yCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAgaWYgYFNvbWVgCiAgICAgKiBAdGhyb3dzIGBOb25lRXJyb3JgIGlmIGBOb25lYAogICAgICovCiAgICB1bndyYXAoKSB7CiAgICAgICAgdGhyb3cgbmV3IE5vbmVFcnJvcigpOwogICAgfQogICAgLyoqCiAgICAgKiBHZXQgdGhlIGlubmVyIHZhbHVlIG9yIGEgZGVmYXVsdCBvbmUKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBTb21lYCwgYHZhbHVlYCBpZiBgTm9uZWAKICAgICAqLwogICAgdW53cmFwT3IodmFsdWUpIHsKICAgICAgICByZXR1cm4gdmFsdWU7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgdGhlIGNvbnRhaW5lZCBgU29tZWAgdmFsdWUgb3IgY29tcHV0ZXMgaXQgZnJvbSBhIGNsb3N1cmUKICAgICAqIEBwYXJhbSBub25lQ2FsbGJhY2sKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgU29tZWAsIGBhd2FpdCBub25lQ2FsbGJhY2soKWAgaWYgYE5vbmVgCiAgICAgKi8KICAgIGFzeW5jIHVud3JhcE9yRWxzZShub25lQ2FsbGJhY2spIHsKICAgICAgICByZXR1cm4gYXdhaXQgbm9uZUNhbGxiYWNrKCk7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgdGhlIGNvbnRhaW5lZCBgU29tZWAgdmFsdWUgb3IgY29tcHV0ZXMgaXQgZnJvbSBhIGNsb3N1cmUKICAgICAqIEBwYXJhbSBub25lQ2FsbGJhY2sKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgU29tZWAsIGBub25lQ2FsbGJhY2soKWAgaWYgYE5vbmVgCiAgICAgKi8KICAgIHVud3JhcE9yRWxzZVN5bmMobm9uZUNhbGxiYWNrKSB7CiAgICAgICAgcmV0dXJuIG5vbmVDYWxsYmFjaygpOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm0gYE9wdGlvbjxUPmAgaW50byBgUmVzdWx0PFQsIE5vbmVFcnJvcj5gCiAgICAgKiBAcmV0dXJucyBgT2sodGhpcy5pbm5lcilgIGlmIGBTb21lYCwgYEVycihOb25lRXJyb3IpYCBpZiBgTm9uZWAKICAgICAqLwogICAgb2soKSB7CiAgICAgICAgcmV0dXJuIG5ldyBFcnIobmV3IE5vbmVFcnJvcigpKTsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtIGBPcHRpb248VD5gIGludG8gYFJlc3VsdDxULCBFPmAKICAgICAqIEBwYXJhbSBlcnJvcgogICAgICogQHJldHVybnMgYE9rKHRoaXMuaW5uZXIpYCBpZiBgU29tZWAsIGBFcnIoZXJyb3IpYCBpZiBgTm9uZWAKICAgICAqLwogICAgb2tPcihlcnJvcikgewogICAgICAgIHJldHVybiBuZXcgRXJyKGVycm9yKTsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtcyB0aGUgYE9wdGlvbjxUPmAgaW50byBhIGBSZXN1bHQ8VCwgRT5gLCBtYXBwaW5nIGBTb21lKHYpYCB0byBgT2sodilgIGFuZCBgTm9uZWAgdG8gYEVycihlcnIoKSlgCiAgICAgKiBAcGFyYW0gbm9uZUNhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgT2sodGhpcy5pbm5lcilgIGlmIGBTb21lYCwgYEVycihhd2FpdCBub25lQ2FsbGJhY2soKSlgIGlzIGBOb25lYAogICAgICovCiAgICBhc3luYyBva09yRWxzZShub25lQ2FsbGJhY2spIHsKICAgICAgICByZXR1cm4gbmV3IEVycihhd2FpdCBub25lQ2FsbGJhY2soKSk7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybXMgdGhlIGBPcHRpb248VD5gIGludG8gYSBgUmVzdWx0PFQsIEU+YCwgbWFwcGluZyBgU29tZSh2KWAgdG8gYE9rKHYpYCBhbmQgYE5vbmVgIHRvIGBFcnIoZXJyKCkpYAogICAgICogQHBhcmFtIG5vbmVDYWxsYmFjawogICAgICogQHJldHVybnMgYE9rKHRoaXMuaW5uZXIpYCBpZiBgU29tZWAsIGBFcnIobm9uZUNhbGxiYWNrKCkpYCBpcyBgTm9uZWAKICAgICAqLwogICAgb2tPckVsc2VTeW5jKG5vbmVDYWxsYmFjaykgewogICAgICAgIHJldHVybiBuZXcgRXJyKG5vbmVDYWxsYmFjaygpKTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBgTm9uZWAgaWYgdGhlIG9wdGlvbiBpcyBgTm9uZWAsIG90aGVyd2lzZSBjYWxscyBgc29tZVByZWRpY2F0ZWAgd2l0aCB0aGUgd3JhcHBlZCB2YWx1ZQogICAgICogQHBhcmFtIHNvbWVQcmVkaWNhdGUKICAgICAqIEByZXR1cm5zIGBTb21lYCBpZiBgU29tZWAgYW5kIGBhd2FpdCBzb21lUHJlZGljYXRlKHRoaXMuaW5uZXIpYCwgYE5vbmVgIG90aGVyd2lzZQogICAgICovCiAgICBhc3luYyBmaWx0ZXIoc29tZVByZWRpY2F0ZSkgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGBOb25lYCBpZiB0aGUgb3B0aW9uIGlzIGBOb25lYCwgb3RoZXJ3aXNlIGNhbGxzIGBzb21lUHJlZGljYXRlYCB3aXRoIHRoZSB3cmFwcGVkIHZhbHVlCiAgICAgKiBAcGFyYW0gc29tZVByZWRpY2F0ZQogICAgICogQHJldHVybnMgYFNvbWVgIGlmIGBTb21lYCBhbmQgYHNvbWVQcmVkaWNhdGUodGhpcy5pbm5lcilgLCBgTm9uZWAgb3RoZXJ3aXNlCiAgICAgKi8KICAgIGZpbHRlclN5bmMoc29tZVByZWRpY2F0ZSkgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm0gYE9wdGlvbjxQcm9taXNlPFQ+PmAgaW50byBgUHJvbWlzZTxPcHRpb248VD4+YAogICAgICogQHJldHVybnMgYFByb21pc2U8T3B0aW9uPFQ+PmAKICAgICAqLwogICAgYXN5bmMgYXdhaXQoKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYHRydWVgIGlmIHRoZSBvcHRpb24gaXMgYSBgU29tZWAgdmFsdWUgY29udGFpbmluZyB0aGUgZ2l2ZW4gdmFsdWUKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBTb21lYCBhbmQgYHRoaXMuaW5uZXIgPT09IHZhbHVlYCwgYE5vbmVgIG90aGVyd2lzZQogICAgICovCiAgICBjb250YWlucyh2YWx1ZSkgewogICAgICAgIHJldHVybiBmYWxzZTsKICAgIH0KICAgIC8qKgogICAgICogQ2FsbHMgdGhlIGdpdmVuIGNhbGxiYWNrIHdpdGggdGhlIGlubmVyIHZhbHVlIGlmIGBPa2AKICAgICAqIEBwYXJhbSBzb21lQ2FsbGJhY2sKICAgICAqIEByZXR1cm5zIGB0aGlzYAogICAgICovCiAgICBhc3luYyBpbnNwZWN0KHNvbWVDYWxsYmFjaykgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBDYWxscyB0aGUgZ2l2ZW4gY2FsbGJhY2sgd2l0aCB0aGUgaW5uZXIgdmFsdWUgaWYgYE9rYAogICAgICogQHBhcmFtIHNvbWVDYWxsYmFjawogICAgICogQHJldHVybnMgYHRoaXNgCiAgICAgKi8KICAgIGluc3BlY3RTeW5jKHNvbWVDYWxsYmFjaykgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBNYXBzIGFuIGBPcHRpb248VD5gIHRvIGBPcHRpb248VT5gIGJ5IGFwcGx5aW5nIGEgZnVuY3Rpb24gdG8gYSBjb250YWluZWQgdmFsdWUgKGlmIGBTb21lYCkgb3IgcmV0dXJucyBgTm9uZWAgKGlmIGBOb25lYCkKICAgICAqIEBwYXJhbSBzb21lTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgU29tZShhd2FpdCBzb21lTWFwcGVyKHRoaXMuaW5uZXIpKWAgaWYgYFNvbWVgLCBgdGhpc2AgaWYgYE5vbmVgCiAgICAgKi8KICAgIGFzeW5jIG1hcChzb21lTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIE1hcHMgYW4gYE9wdGlvbjxUPmAgdG8gYE9wdGlvbjxVPmAgYnkgYXBwbHlpbmcgYSBmdW5jdGlvbiB0byBhIGNvbnRhaW5lZCB2YWx1ZSAoaWYgYFNvbWVgKSBvciByZXR1cm5zIGBOb25lYCAoaWYgYE5vbmVgKQogICAgICogQHBhcmFtIHNvbWVNYXBwZXIKICAgICAqIEByZXR1cm5zIGBTb21lKHNvbWVNYXBwZXIodGhpcy5pbm5lcikpYCBpZiBgU29tZWAsIGB0aGlzYCBpZiBgTm9uZWAKICAgICAqLwogICAgbWFwU3luYyhzb21lTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgdGhlIHByb3ZpZGVkIGRlZmF1bHQgcmVzdWx0IChpZiBub25lKSwgb3IgYXBwbGllcyBhIGZ1bmN0aW9uIHRvIHRoZSBjb250YWluZWQgdmFsdWUgKGlmIGFueSkKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHBhcmFtIHNvbWVNYXBwZXIKICAgICAqIEByZXR1cm5zIGB2YWx1ZWAgaWYgYE5vbmVgLCBgYXdhaXQgc29tZU1hcHBlcih0aGlzLmlubmVyKWAgaWYgYFNvbWVgCiAgICAgKi8KICAgIGFzeW5jIG1hcE9yKHZhbHVlLCBzb21lTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIHZhbHVlOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIHRoZSBwcm92aWRlZCBkZWZhdWx0IHJlc3VsdCAoaWYgbm9uZSksIG9yIGFwcGxpZXMgYSBmdW5jdGlvbiB0byB0aGUgY29udGFpbmVkIHZhbHVlIChpZiBhbnkpCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEBwYXJhbSBzb21lTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgdmFsdWVgIGlmIGBOb25lYCwgYHNvbWVNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBTb21lYAogICAgICovCiAgICBtYXBPclN5bmModmFsdWUsIHNvbWVNYXBwZXIpIHsKICAgICAgICByZXR1cm4gdmFsdWU7CiAgICB9CiAgICAvKioKICAgICAqIENvbXB1dGVzIGEgZGVmYXVsdCBmdW5jdGlvbiByZXN1bHQgKGlmIG5vbmUpLCBvciBhcHBsaWVzIGEgZGlmZmVyZW50IGZ1bmN0aW9uIHRvIHRoZSBjb250YWluZWQgdmFsdWUgKGlmIGFueSkKICAgICAqIEBwYXJhbSBub25lQ2FsbGJhY2sKICAgICAqIEBwYXJhbSBzb21lTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgYXdhaXQgc29tZU1hcHBlcih0aGlzLmlubmVyKWAgaWYgYFNvbWVgLCBgYXdhaXQgbm9uZUNhbGxiYWNrKClgIGlmIGBOb25lYAogICAgICovCiAgICBhc3luYyBtYXBPckVsc2Uobm9uZUNhbGxiYWNrLCBzb21lTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIGF3YWl0IG5vbmVDYWxsYmFjaygpOwogICAgfQogICAgLyoqCiAgICAgKiBDb21wdXRlcyBhIGRlZmF1bHQgZnVuY3Rpb24gcmVzdWx0IChpZiBub25lKSwgb3IgYXBwbGllcyBhIGRpZmZlcmVudCBmdW5jdGlvbiB0byB0aGUgY29udGFpbmVkIHZhbHVlIChpZiBhbnkpCiAgICAgKiBAcGFyYW0gbm9uZUNhbGxiYWNrCiAgICAgKiBAcGFyYW0gc29tZU1hcHBlcgogICAgICogQHJldHVybnMgYHNvbWVNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBTb21lYCwgYG5vbmVDYWxsYmFjaygpYCBpZiBgTm9uZWAKICAgICAqLwogICAgbWFwT3JFbHNlU3luYyhub25lQ2FsbGJhY2ssIHNvbWVNYXBwZXIpIHsKICAgICAgICByZXR1cm4gbm9uZUNhbGxiYWNrKCk7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYE5vbmVgIGlmIHRoZSBvcHRpb24gaXMgYE5vbmVgLCBvdGhlcndpc2UgcmV0dXJucyBgdmFsdWVgCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEByZXR1cm5zIGBOb25lYCBpZiBgTm9uZWAsIGB2YWx1ZWAgaWYgYFNvbWVgCiAgICAgKi8KICAgIGFuZCh2YWx1ZSkgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGBOb25lYCBpZiB0aGUgb3B0aW9uIGlzIGBOb25lYCwgb3RoZXJ3aXNlIGNhbGxzIGBzb21lTWFwcGVyYCB3aXRoIHRoZSB3cmFwcGVkIHZhbHVlIGFuZCByZXR1cm5zIHRoZSByZXN1bHQKICAgICAqIEBwYXJhbSBzb21lTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgTm9uZWAgaWYgYE5vbmVgLCBgYXdhaXQgc29tZU1hcHBlcih0aGlzLmlubmVyKWAgaWYgYFNvbWVgCiAgICAgKi8KICAgIGFzeW5jIGFuZFRoZW4oc29tZU1hcHBlcikgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGBOb25lYCBpZiB0aGUgb3B0aW9uIGlzIGBOb25lYCwgb3RoZXJ3aXNlIGNhbGxzIGBzb21lTWFwcGVyYCB3aXRoIHRoZSB3cmFwcGVkIHZhbHVlIGFuZCByZXR1cm5zIHRoZSByZXN1bHQKICAgICAqIEBwYXJhbSBzb21lTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgTm9uZWAgaWYgYE5vbmVgLCBgc29tZU1hcHBlcih0aGlzLmlubmVyKWAgaWYgYFNvbWVgCiAgICAgKi8KICAgIGFuZFRoZW5TeW5jKHNvbWVNYXBwZXIpIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBgdGhpc2AgaWYgYFNvbWVgLCBvdGhlcndpc2UgcmV0dXJucyBgdmFsdWVgCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEByZXR1cm5zIGB0aGlzYCBpZiBgU29tZWAsIGB2YWx1ZWAgaWYgYE5vbmVgCiAgICAgKi8KICAgIG9yKHZhbHVlKSB7CiAgICAgICAgcmV0dXJuIHZhbHVlOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGB0aGlzYCBpZiBgU29tZWAsIG90aGVyd2lzZSBjYWxscyBgbm9uZUNhbGxiYWNrYCBhbmQgcmV0dXJucyB0aGUgcmVzdWx0CiAgICAgKiBAcGFyYW0gbm9uZUNhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgdGhpc2AgaWYgYFNvbWVgLCBgYXdhaXQgbm9uZUNhbGxiYWNrKClgIGlmIGBOb25lYAogICAgICovCiAgICBhc3luYyBvckVsc2Uobm9uZUNhbGxiYWNrKSB7CiAgICAgICAgcmV0dXJuIGF3YWl0IG5vbmVDYWxsYmFjaygpOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGB0aGlzYCBpZiBgU29tZWAsIG90aGVyd2lzZSBjYWxscyBgbm9uZUNhbGxiYWNrYCBhbmQgcmV0dXJucyB0aGUgcmVzdWx0CiAgICAgKiBAcGFyYW0gbm9uZUNhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgdGhpc2AgaWYgYFNvbWVgLCBgbm9uZUNhbGxiYWNrKClgIGlmIGBOb25lYAogICAgICovCiAgICBvckVsc2VTeW5jKG5vbmVDYWxsYmFjaykgewogICAgICAgIHJldHVybiBub25lQ2FsbGJhY2soKTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBgU29tZWAgaWYgZXhhY3RseSBvbmUgb2YgdGhlIG9wdGlvbnMgaXMgYFNvbWVgLCBvdGhlcndpc2UgcmV0dXJucyBgTm9uZWAKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHJldHVybnMgYE5vbmVgIGlmIGJvdGggYXJlIGBTb21lYCBvciBib3RoIGFyZSBgTm9uZWAsIHRoZSBvbmx5IGBTb21lYCBvdGhlcndpc2UKICAgICAqLwogICAgeG9yKHZhbHVlKSB7CiAgICAgICAgcmV0dXJuIHZhbHVlOwogICAgfQogICAgLyoqCiAgICAgKiBaaXBzIGB0aGlzYCB3aXRoIGFub3RoZXIgYE9wdGlvbmAKICAgICAqIEBwYXJhbSBvdGhlcgogICAgICogQHJldHVybnMgYFNvbWUoW3RoaXMuaW5uZXIsIG90aGVyLmlubmVyXSlgIGlmIGJvdGggYXJlIGBTb21lYCwgYE5vbmVgIGlmIG9uZSBvZiB0aGVtIGlzIGBOb25lYAogICAgICovCiAgICB6aXAob3RoZXIpIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KfQoKCi8vIyBzb3VyY2VNYXBwaW5nVVJMPW5vbmUubWpzLm1hcAoKOy8vIENPTkNBVEVOQVRFRCBNT0RVTEU6IC4vbm9kZV9tb2R1bGVzL0BoYXphZTQxL29wdGlvbi9kaXN0L2VzbS9tb2RzL29wdGlvbi9zb21lLm1qcwoKCgpjbGFzcyBTb21lIHsKICAgIGlubmVyOwogICAgLyoqCiAgICAgKiBBbiBleGlzdGluZyB2YWx1ZQogICAgICogQHBhcmFtIGlubmVyCiAgICAgKi8KICAgIGNvbnN0cnVjdG9yKGlubmVyKSB7CiAgICAgICAgdGhpcy5pbm5lciA9IGlubmVyOwogICAgfQogICAgLyoqCiAgICAgKiBDcmVhdGUgYSBgU29tZWAKICAgICAqIEBwYXJhbSBpbm5lcgogICAgICogQHJldHVybnMgYFNvbWUoaW5uZXIpYAogICAgICovCiAgICBzdGF0aWMgbmV3KGlubmVyKSB7CiAgICAgICAgcmV0dXJuIG5ldyB0aGlzKGlubmVyKTsKICAgIH0KICAgIHN0YXRpYyBmcm9tKGluaXQpIHsKICAgICAgICByZXR1cm4gbmV3IFNvbWUoaW5pdC5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFR5cGUgZ3VhcmQgZm9yIGBTb21lYAogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBTb21lYCwgYGZhbHNlYCBpZiBgTm9uZWAKICAgICAqLwogICAgaXNTb21lKCkgewogICAgICAgIHJldHVybiB0cnVlOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGB0cnVlYCBpZiB0aGUgb3B0aW9uIGlzIGEgYFNvbWVgIGFuZCB0aGUgdmFsdWUgaW5zaWRlIG9mIGl0IG1hdGNoZXMgYSBwcmVkaWNhdGUKICAgICAqIEBwYXJhbSBzb21lUHJlZGljYXRlCiAgICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYFNvbWVgIGFuZCBgYXdhaXQgc29tZVByZWRpY2F0ZSh0aGlzLmlubmVyKWAsIGBOb25lYCBvdGhlcndpc2UKICAgICAqLwogICAgYXN5bmMgaXNTb21lQW5kKHNvbWVQcmVkaWNhdGUpIHsKICAgICAgICByZXR1cm4gYXdhaXQgc29tZVByZWRpY2F0ZSh0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBgdHJ1ZWAgaWYgdGhlIG9wdGlvbiBpcyBhIGBTb21lYCBhbmQgdGhlIHZhbHVlIGluc2lkZSBvZiBpdCBtYXRjaGVzIGEgcHJlZGljYXRlCiAgICAgKiBAcGFyYW0gc29tZVByZWRpY2F0ZQogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBTb21lYCBhbmQgYHNvbWVQcmVkaWNhdGUodGhpcy5pbm5lcilgLCBgTm9uZWAgb3RoZXJ3aXNlCiAgICAgKi8KICAgIGlzU29tZUFuZFN5bmMoc29tZVByZWRpY2F0ZSkgewogICAgICAgIHJldHVybiBzb21lUHJlZGljYXRlKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBUeXBlIGd1YXJkIGZvciBgTm9uZWAKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgTm9uZWAsIGBmYWxzZWAgaWYgYFNvbWVgCiAgICAgKi8KICAgIGlzTm9uZSgpIHsKICAgICAgICByZXR1cm4gZmFsc2U7CiAgICB9CiAgICAvKioKICAgICAqIENvbXBpbGUtdGltZSBzYWZlbHkgZ2V0IGB0aGlzLmlubmVyYAogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgCiAgICAgKi8KICAgIGdldCgpIHsKICAgICAgICByZXR1cm4gdGhpcy5pbm5lcjsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBhbiBpdGVyYXRvciBvdmVyIHRoZSBwb3NzaWJseSBjb250YWluZWQgdmFsdWUKICAgICAqIEB5aWVsZHMgYHRoaXMuaW5uZXJgIGlmIGBTb21lYAogICAgICovCiAgICAqW1N5bWJvbC5pdGVyYXRvcl0oKSB7CiAgICAgICAgeWllbGQgdGhpcy5pbm5lcjsKICAgIH0KICAgIC8qKgogICAgICogR2V0IHRoZSBpbm5lciB2YWx1ZSBpZiBgU29tZWAsIHRocm93IGBFcnJvcihtZXNzYWdlKWAgb3RoZXJ3aXNlCiAgICAgKiBAcGFyYW0gbWVzc2FnZQogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBTb21lYAogICAgICogQHRocm93cyBgRXJyb3IobWVzc2FnZSlgIGlmIGBOb25lYAogICAgICovCiAgICBleHBlY3QobWVzc2FnZSkgewogICAgICAgIHJldHVybiB0aGlzLmlubmVyOwogICAgfQogICAgLyoqCiAgICAgKiBHZXQgdGhlIGlubmVyIHZhbHVlIG9yIHRocm93IGEgTm9uZUVycm9yCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAgaWYgYFNvbWVgCiAgICAgKiBAdGhyb3dzIGBOb25lRXJyb3JgIGlmIGBOb25lYAogICAgICovCiAgICB1bndyYXAoKSB7CiAgICAgICAgcmV0dXJuIHRoaXMuaW5uZXI7CiAgICB9CiAgICAvKioKICAgICAqIEdldCB0aGUgaW5uZXIgdmFsdWUgb3IgYSBkZWZhdWx0IG9uZQogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAgaWYgYFNvbWVgLCBgdmFsdWVgIGlmIGBOb25lYAogICAgICovCiAgICB1bndyYXBPcih2YWx1ZSkgewogICAgICAgIHJldHVybiB0aGlzLmlubmVyOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIHRoZSBjb250YWluZWQgYFNvbWVgIHZhbHVlIG9yIGNvbXB1dGVzIGl0IGZyb20gYSBjbG9zdXJlCiAgICAgKiBAcGFyYW0gbm9uZUNhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAgaWYgYFNvbWVgLCBgYXdhaXQgbm9uZUNhbGxiYWNrKClgIGlmIGBOb25lYAogICAgICovCiAgICBhc3luYyB1bndyYXBPckVsc2Uobm9uZUNhbGxiYWNrKSB7CiAgICAgICAgcmV0dXJuIHRoaXMuaW5uZXI7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgdGhlIGNvbnRhaW5lZCBgU29tZWAgdmFsdWUgb3IgY29tcHV0ZXMgaXQgZnJvbSBhIGNsb3N1cmUKICAgICAqIEBwYXJhbSBub25lQ2FsbGJhY2sKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgU29tZWAsIGBub25lQ2FsbGJhY2soKWAgaWYgYE5vbmVgCiAgICAgKi8KICAgIHVud3JhcE9yRWxzZVN5bmMobm9uZUNhbGxiYWNrKSB7CiAgICAgICAgcmV0dXJuIHRoaXMuaW5uZXI7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBgT3B0aW9uPFQ+YCBpbnRvIGBSZXN1bHQ8VCwgTm9uZUVycm9yPmAKICAgICAqIEByZXR1cm5zIGBPayh0aGlzLmlubmVyKWAgaWYgYFNvbWVgLCBgRXJyKE5vbmVFcnJvcilgIGlmIGBOb25lYAogICAgICovCiAgICBvaygpIHsKICAgICAgICByZXR1cm4gbmV3IE9rKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm0gYE9wdGlvbjxUPmAgaW50byBgUmVzdWx0PFQsIEU+YAogICAgICogQHBhcmFtIGVycm9yCiAgICAgKiBAcmV0dXJucyBgT2sodGhpcy5pbm5lcilgIGlmIGBTb21lYCwgYEVycihlcnJvcilgIGlmIGBOb25lYAogICAgICovCiAgICBva09yKGVycm9yKSB7CiAgICAgICAgcmV0dXJuIG5ldyBPayh0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtcyB0aGUgYE9wdGlvbjxUPmAgaW50byBhIGBSZXN1bHQ8VCwgRT5gLCBtYXBwaW5nIGBTb21lKHYpYCB0byBgT2sodilgIGFuZCBgTm9uZWAgdG8gYEVycihlcnIoKSlgCiAgICAgKiBAcGFyYW0gbm9uZUNhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgT2sodGhpcy5pbm5lcilgIGlmIGBTb21lYCwgYEVycihhd2FpdCBub25lQ2FsbGJhY2soKSlgIGlzIGBOb25lYAogICAgICovCiAgICBhc3luYyBva09yRWxzZShub25lQ2FsbGJhY2spIHsKICAgICAgICByZXR1cm4gbmV3IE9rKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm1zIHRoZSBgT3B0aW9uPFQ+YCBpbnRvIGEgYFJlc3VsdDxULCBFPmAsIG1hcHBpbmcgYFNvbWUodilgIHRvIGBPayh2KWAgYW5kIGBOb25lYCB0byBgRXJyKGVycigpKWAKICAgICAqIEBwYXJhbSBub25lQ2FsbGJhY2sKICAgICAqIEByZXR1cm5zIGBPayh0aGlzLmlubmVyKWAgaWYgYFNvbWVgLCBgRXJyKG5vbmVDYWxsYmFjaygpKWAgaXMgYE5vbmVgCiAgICAgKi8KICAgIG9rT3JFbHNlU3luYyhub25lQ2FsbGJhY2spIHsKICAgICAgICByZXR1cm4gbmV3IE9rKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGBOb25lYCBpZiB0aGUgb3B0aW9uIGlzIGBOb25lYCwgb3RoZXJ3aXNlIGNhbGxzIGBzb21lUHJlZGljYXRlYCB3aXRoIHRoZSB3cmFwcGVkIHZhbHVlCiAgICAgKiBAcGFyYW0gc29tZVByZWRpY2F0ZQogICAgICogQHJldHVybnMgYFNvbWVgIGlmIGBTb21lYCBhbmQgYGF3YWl0IHNvbWVQcmVkaWNhdGUodGhpcy5pbm5lcilgLCBgTm9uZWAgb3RoZXJ3aXNlCiAgICAgKi8KICAgIGFzeW5jIGZpbHRlcihzb21lUHJlZGljYXRlKSB7CiAgICAgICAgaWYgKGF3YWl0IHNvbWVQcmVkaWNhdGUodGhpcy5pbm5lcikpCiAgICAgICAgICAgIHJldHVybiB0aGlzOwogICAgICAgIGVsc2UKICAgICAgICAgICAgcmV0dXJuIG5ldyBOb25lKCk7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYE5vbmVgIGlmIHRoZSBvcHRpb24gaXMgYE5vbmVgLCBvdGhlcndpc2UgY2FsbHMgYHNvbWVQcmVkaWNhdGVgIHdpdGggdGhlIHdyYXBwZWQgdmFsdWUKICAgICAqIEBwYXJhbSBzb21lUHJlZGljYXRlCiAgICAgKiBAcmV0dXJucyBgU29tZWAgaWYgYFNvbWVgIGFuZCBgc29tZVByZWRpY2F0ZSh0aGlzLmlubmVyKWAsIGBOb25lYCBvdGhlcndpc2UKICAgICAqLwogICAgZmlsdGVyU3luYyhzb21lUHJlZGljYXRlKSB7CiAgICAgICAgaWYgKHNvbWVQcmVkaWNhdGUodGhpcy5pbm5lcikpCiAgICAgICAgICAgIHJldHVybiB0aGlzOwogICAgICAgIGVsc2UKICAgICAgICAgICAgcmV0dXJuIG5ldyBOb25lKCk7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBgT3B0aW9uPFByb21pc2U8VD4+YCBpbnRvIGBQcm9taXNlPE9wdGlvbjxUPj5gCiAgICAgKiBAcmV0dXJucyBgUHJvbWlzZTxPcHRpb248VD4+YAogICAgICovCiAgICBhc3luYyBhd2FpdCgpIHsKICAgICAgICByZXR1cm4gbmV3IFNvbWUoYXdhaXQgdGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYHRydWVgIGlmIHRoZSBvcHRpb24gaXMgYSBgU29tZWAgdmFsdWUgY29udGFpbmluZyB0aGUgZ2l2ZW4gdmFsdWUKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBTb21lYCBhbmQgYHRoaXMuaW5uZXIgPT09IHZhbHVlYCwgYE5vbmVgIG90aGVyd2lzZQogICAgICovCiAgICBjb250YWlucyh2YWx1ZSkgewogICAgICAgIHJldHVybiB0aGlzLmlubmVyID09PSB2YWx1ZTsKICAgIH0KICAgIC8qKgogICAgICogQ2FsbHMgdGhlIGdpdmVuIGNhbGxiYWNrIHdpdGggdGhlIGlubmVyIHZhbHVlIGlmIGBPa2AKICAgICAqIEBwYXJhbSBzb21lQ2FsbGJhY2sKICAgICAqIEByZXR1cm5zIGB0aGlzYAogICAgICovCiAgICBhc3luYyBpbnNwZWN0KHNvbWVDYWxsYmFjaykgewogICAgICAgIGF3YWl0IHNvbWVDYWxsYmFjayh0aGlzLmlubmVyKTsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogQ2FsbHMgdGhlIGdpdmVuIGNhbGxiYWNrIHdpdGggdGhlIGlubmVyIHZhbHVlIGlmIGBPa2AKICAgICAqIEBwYXJhbSBzb21lQ2FsbGJhY2sKICAgICAqIEByZXR1cm5zIGB0aGlzYAogICAgICovCiAgICBpbnNwZWN0U3luYyhzb21lQ2FsbGJhY2spIHsKICAgICAgICBzb21lQ2FsbGJhY2sodGhpcy5pbm5lcik7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIE1hcHMgYW4gYE9wdGlvbjxUPmAgdG8gYE9wdGlvbjxVPmAgYnkgYXBwbHlpbmcgYSBmdW5jdGlvbiB0byBhIGNvbnRhaW5lZCB2YWx1ZSAoaWYgYFNvbWVgKSBvciByZXR1cm5zIGBOb25lYCAoaWYgYE5vbmVgKQogICAgICogQHBhcmFtIHNvbWVNYXBwZXIKICAgICAqIEByZXR1cm5zIGBTb21lKGF3YWl0IHNvbWVNYXBwZXIodGhpcy5pbm5lcikpYCBpZiBgU29tZWAsIGB0aGlzYCBpZiBgTm9uZWAKICAgICAqLwogICAgYXN5bmMgbWFwKHNvbWVNYXBwZXIpIHsKICAgICAgICByZXR1cm4gbmV3IFNvbWUoYXdhaXQgc29tZU1hcHBlcih0aGlzLmlubmVyKSk7CiAgICB9CiAgICAvKioKICAgICAqIE1hcHMgYW4gYE9wdGlvbjxUPmAgdG8gYE9wdGlvbjxVPmAgYnkgYXBwbHlpbmcgYSBmdW5jdGlvbiB0byBhIGNvbnRhaW5lZCB2YWx1ZSAoaWYgYFNvbWVgKSBvciByZXR1cm5zIGBOb25lYCAoaWYgYE5vbmVgKQogICAgICogQHBhcmFtIHNvbWVNYXBwZXIKICAgICAqIEByZXR1cm5zIGBTb21lKHNvbWVNYXBwZXIodGhpcy5pbm5lcikpYCBpZiBgU29tZWAsIGB0aGlzYCBpZiBgTm9uZWAKICAgICAqLwogICAgbWFwU3luYyhzb21lTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIG5ldyBTb21lKHNvbWVNYXBwZXIodGhpcy5pbm5lcikpOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIHRoZSBwcm92aWRlZCBkZWZhdWx0IHJlc3VsdCAoaWYgbm9uZSksIG9yIGFwcGxpZXMgYSBmdW5jdGlvbiB0byB0aGUgY29udGFpbmVkIHZhbHVlIChpZiBhbnkpCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEBwYXJhbSBzb21lTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgdmFsdWVgIGlmIGBOb25lYCwgYGF3YWl0IHNvbWVNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBTb21lYAogICAgICovCiAgICBhc3luYyBtYXBPcih2YWx1ZSwgc29tZU1hcHBlcikgewogICAgICAgIHJldHVybiBhd2FpdCBzb21lTWFwcGVyKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIHRoZSBwcm92aWRlZCBkZWZhdWx0IHJlc3VsdCAoaWYgbm9uZSksIG9yIGFwcGxpZXMgYSBmdW5jdGlvbiB0byB0aGUgY29udGFpbmVkIHZhbHVlIChpZiBhbnkpCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEBwYXJhbSBzb21lTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgdmFsdWVgIGlmIGBOb25lYCwgYHNvbWVNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBTb21lYAogICAgICovCiAgICBtYXBPclN5bmModmFsdWUsIHNvbWVNYXBwZXIpIHsKICAgICAgICByZXR1cm4gc29tZU1hcHBlcih0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogQ29tcHV0ZXMgYSBkZWZhdWx0IGZ1bmN0aW9uIHJlc3VsdCAoaWYgbm9uZSksIG9yIGFwcGxpZXMgYSBkaWZmZXJlbnQgZnVuY3Rpb24gdG8gdGhlIGNvbnRhaW5lZCB2YWx1ZSAoaWYgYW55KQogICAgICogQHBhcmFtIG5vbmVDYWxsYmFjawogICAgICogQHBhcmFtIHNvbWVNYXBwZXIKICAgICAqIEByZXR1cm5zIGBhd2FpdCBzb21lTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgU29tZWAsIGBhd2FpdCBub25lQ2FsbGJhY2soKWAgaWYgYE5vbmVgCiAgICAgKi8KICAgIGFzeW5jIG1hcE9yRWxzZShub25lQ2FsbGJhY2ssIHNvbWVNYXBwZXIpIHsKICAgICAgICByZXR1cm4gYXdhaXQgc29tZU1hcHBlcih0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogQ29tcHV0ZXMgYSBkZWZhdWx0IGZ1bmN0aW9uIHJlc3VsdCAoaWYgbm9uZSksIG9yIGFwcGxpZXMgYSBkaWZmZXJlbnQgZnVuY3Rpb24gdG8gdGhlIGNvbnRhaW5lZCB2YWx1ZSAoaWYgYW55KQogICAgICogQHBhcmFtIG5vbmVDYWxsYmFjawogICAgICogQHBhcmFtIHNvbWVNYXBwZXIKICAgICAqIEByZXR1cm5zIGBzb21lTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgU29tZWAsIGBub25lQ2FsbGJhY2soKWAgaWYgYE5vbmVgCiAgICAgKi8KICAgIG1hcE9yRWxzZVN5bmMobm9uZUNhbGxiYWNrLCBzb21lTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIHNvbWVNYXBwZXIodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYE5vbmVgIGlmIHRoZSBvcHRpb24gaXMgYE5vbmVgLCBvdGhlcndpc2UgcmV0dXJucyBgdmFsdWVgCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEByZXR1cm5zIGBOb25lYCBpZiBgTm9uZWAsIGB2YWx1ZWAgaWYgYFNvbWVgCiAgICAgKi8KICAgIGFuZCh2YWx1ZSkgewogICAgICAgIHJldHVybiB2YWx1ZTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBgTm9uZWAgaWYgdGhlIG9wdGlvbiBpcyBgTm9uZWAsIG90aGVyd2lzZSBjYWxscyBgc29tZU1hcHBlcmAgd2l0aCB0aGUgd3JhcHBlZCB2YWx1ZSBhbmQgcmV0dXJucyB0aGUgcmVzdWx0CiAgICAgKiBAcGFyYW0gc29tZU1hcHBlcgogICAgICogQHJldHVybnMgYE5vbmVgIGlmIGBOb25lYCwgYGF3YWl0IHNvbWVNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBTb21lYAogICAgICovCiAgICBhc3luYyBhbmRUaGVuKHNvbWVNYXBwZXIpIHsKICAgICAgICByZXR1cm4gYXdhaXQgc29tZU1hcHBlcih0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBgTm9uZWAgaWYgdGhlIG9wdGlvbiBpcyBgTm9uZWAsIG90aGVyd2lzZSBjYWxscyBgc29tZU1hcHBlcmAgd2l0aCB0aGUgd3JhcHBlZCB2YWx1ZSBhbmQgcmV0dXJucyB0aGUgcmVzdWx0CiAgICAgKiBAcGFyYW0gc29tZU1hcHBlcgogICAgICogQHJldHVybnMgYE5vbmVgIGlmIGBOb25lYCwgYHNvbWVNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBTb21lYAogICAgICovCiAgICBhbmRUaGVuU3luYyhzb21lTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIHNvbWVNYXBwZXIodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYHRoaXNgIGlmIGBTb21lYCwgb3RoZXJ3aXNlIHJldHVybnMgYHZhbHVlYAogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcmV0dXJucyBgdGhpc2AgaWYgYFNvbWVgLCBgdmFsdWVgIGlmIGBOb25lYAogICAgICovCiAgICBvcih2YWx1ZSkgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGB0aGlzYCBpZiBgU29tZWAsIG90aGVyd2lzZSBjYWxscyBgbm9uZUNhbGxiYWNrYCBhbmQgcmV0dXJucyB0aGUgcmVzdWx0CiAgICAgKiBAcGFyYW0gbm9uZUNhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgdGhpc2AgaWYgYFNvbWVgLCBgYXdhaXQgbm9uZUNhbGxiYWNrKClgIGlmIGBOb25lYAogICAgICovCiAgICBhc3luYyBvckVsc2Uobm9uZUNhbGxiYWNrKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYHRoaXNgIGlmIGBTb21lYCwgb3RoZXJ3aXNlIGNhbGxzIGBub25lQ2FsbGJhY2tgIGFuZCByZXR1cm5zIHRoZSByZXN1bHQKICAgICAqIEBwYXJhbSBub25lQ2FsbGJhY2sKICAgICAqIEByZXR1cm5zIGB0aGlzYCBpZiBgU29tZWAsIGBub25lQ2FsbGJhY2soKWAgaWYgYE5vbmVgCiAgICAgKi8KICAgIG9yRWxzZVN5bmMobm9uZUNhbGxiYWNrKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYFNvbWVgIGlmIGV4YWN0bHkgb25lIG9mIHRoZSBvcHRpb25zIGlzIGBTb21lYCwgb3RoZXJ3aXNlIHJldHVybnMgYE5vbmVgCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEByZXR1cm5zIGBOb25lYCBpZiBib3RoIGFyZSBgU29tZWAgb3IgYm90aCBhcmUgYE5vbmVgLCB0aGUgb25seSBgU29tZWAgb3RoZXJ3aXNlCiAgICAgKi8KICAgIHhvcih2YWx1ZSkgewogICAgICAgIGlmICh2YWx1ZS5pc1NvbWUoKSkKICAgICAgICAgICAgcmV0dXJuIG5ldyBOb25lKCk7CiAgICAgICAgZWxzZQogICAgICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogWmlwcyBgdGhpc2Agd2l0aCBhbm90aGVyIGBPcHRpb25gCiAgICAgKiBAcGFyYW0gb3RoZXIKICAgICAqIEByZXR1cm5zIGBTb21lKFt0aGlzLmlubmVyLCBvdGhlci5pbm5lcl0pYCBpZiBib3RoIGFyZSBgU29tZWAsIGBOb25lYCBpZiBvbmUgb2YgdGhlbSBpcyBgTm9uZWAKICAgICAqLwogICAgemlwKG90aGVyKSB7CiAgICAgICAgaWYgKG90aGVyLmlzU29tZSgpKQogICAgICAgICAgICByZXR1cm4gbmV3IFNvbWUoW3RoaXMuaW5uZXIsIG90aGVyLmlubmVyXSk7CiAgICAgICAgZWxzZQogICAgICAgICAgICByZXR1cm4gb3RoZXI7CiAgICB9Cn0KCgovLyMgc291cmNlTWFwcGluZ1VSTD1zb21lLm1qcy5tYXAKCjsvLyBDT05DQVRFTkFURUQgTU9EVUxFOiAuL25vZGVfbW9kdWxlcy9AaGF6YWU0MS9yZXN1bHQvZGlzdC9lc20vbW9kcy9yZXN1bHQvb2subWpzCgoKCgpjbGFzcyBPayB7CiAgICAjaW5uZXI7CiAgICAjdGltZW91dDsKICAgIC8qKgogICAgICogQSBzdWNjZXNzCiAgICAgKiBAcGFyYW0gaW5uZXIKICAgICAqLwogICAgY29uc3RydWN0b3IoaW5uZXIpIHsKICAgICAgICB0aGlzLiNpbm5lciA9IGlubmVyOwogICAgICAgIGlmICghRGVidWcuZGVidWcpCiAgICAgICAgICAgIHJldHVybjsKICAgICAgICBjb25zdCBlcnJvciA9IG5ldyBQYW5pYyhgVW5oYW5kbGVkIHJlc3VsdGAsIHsgY2F1c2U6IHRoaXMgfSk7CiAgICAgICAgdGhpcy4jdGltZW91dCA9IHNldFRpbWVvdXQoYXN5bmMgKCkgPT4geyB0aHJvdyBlcnJvcjsgfSwgMTAwMCk7CiAgICB9CiAgICAvKioKICAgICAqIENyZWF0ZSBhbiBlbXB0eSBgT2tgCiAgICAgKiBAcmV0dXJucyBgT2sodm9pZClgCiAgICAgKi8KICAgIHN0YXRpYyB2b2lkKCkgewogICAgICAgIHJldHVybiBuZXcgT2sodW5kZWZpbmVkKTsKICAgIH0KICAgIC8qKgogICAgICogQ3JlYXRlIGFuIGBPa2AKICAgICAqIEBwYXJhbSBpbm5lcgogICAgICogQHJldHVybnMgYE9rKGlubmVyKWAKICAgICAqLwogICAgc3RhdGljIG5ldyhpbm5lcikgewogICAgICAgIHJldHVybiBuZXcgT2soaW5uZXIpOwogICAgfQogICAgZ2V0IGlubmVyKCkgewogICAgICAgIHJldHVybiB0aGlzLiNpbm5lcjsKICAgIH0KICAgIC8qKgogICAgICogU2V0IHRoaXMgcmVzdWx0IGFzIGhhbmRsZWQKICAgICAqLwogICAgaWdub3JlKCkgewogICAgICAgIGlmICghdGhpcy4jdGltZW91dCkKICAgICAgICAgICAgcmV0dXJuIHRoaXM7CiAgICAgICAgY2xlYXJUaW1lb3V0KHRoaXMuI3RpbWVvdXQpOwogICAgICAgIHRoaXMuI3RpbWVvdXQgPSB1bmRlZmluZWQ7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIFR5cGUgZ3VhcmQgZm9yIGBPa2AKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgT2tgLCBgZmFsc2VgIGlmIGBFcnJgCiAgICAgKi8KICAgIGlzT2soKSB7CiAgICAgICAgcmV0dXJuIHRydWU7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgdHJ1ZSBpZiB0aGUgcmVzdWx0IGlzIGBPa2AgYW5kIHRoZSB2YWx1ZSBpbnNpZGUgb2YgaXQgbWF0Y2hlcyBhIHByZWRpY2F0ZQogICAgICogQHBhcmFtIG9rUHJlZGljYXRlCiAgICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYE9rYCBhbmQgYGF3YWl0IG9rUHJlZGljYXRlKHRoaXMuaW5uZXIpYCwgYGZhbHNlYCBvdGhlcndpc2UKICAgICAqLwogICAgYXN5bmMgaXNPa0FuZChva1ByZWRpY2F0ZSkgewogICAgICAgIHJldHVybiBhd2FpdCBva1ByZWRpY2F0ZSh0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyB0cnVlIGlmIHRoZSByZXN1bHQgaXMgYE9rYCBhbmQgdGhlIHZhbHVlIGluc2lkZSBvZiBpdCBtYXRjaGVzIGEgcHJlZGljYXRlCiAgICAgKiBAcGFyYW0gb2tQcmVkaWNhdGUKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgT2tgIGFuZCBgYXdhaXQgb2tQcmVkaWNhdGUodGhpcy5pbm5lcilgLCBgZmFsc2VgIG90aGVyd2lzZQogICAgICovCiAgICBpc09rQW5kU3luYyhva1ByZWRpY2F0ZSkgewogICAgICAgIHJldHVybiBva1ByZWRpY2F0ZSh0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogVHlwZSBndWFyZCBmb3IgYEVycmAKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgRXJyYCwgYGZhbHNlYCBpZiBgT2tgCiAgICAgKi8KICAgIGlzRXJyKCkgewogICAgICAgIHJldHVybiBmYWxzZTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyB0cnVlIGlmIHRoZSByZXN1bHQgaXMgYEVycmAgYW5kIHRoZSB2YWx1ZSBpbnNpZGUgb2YgaXQgbWF0Y2hlcyBhIHByZWRpY2F0ZQogICAgICogQHBhcmFtIGVyclByZWRpY2F0ZQogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBFcnJgIGFuZCBgYXdhaXQgZXJyUHJlZGljYXRlKHRoaXMuaW5uZXIpYCwgYGZhbHNlYCBvdGhlcndpc2UKICAgICAqLwogICAgYXN5bmMgaXNFcnJBbmQoZXJyUHJlZGljYXRlKSB7CiAgICAgICAgcmV0dXJuIGZhbHNlOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIHRydWUgaWYgdGhlIHJlc3VsdCBpcyBgRXJyYCBhbmQgdGhlIHZhbHVlIGluc2lkZSBvZiBpdCBtYXRjaGVzIGEgcHJlZGljYXRlCiAgICAgKiBAcGFyYW0gZXJyUHJlZGljYXRlCiAgICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYEVycmAgYW5kIGBhd2FpdCBlcnJQcmVkaWNhdGUodGhpcy5pbm5lcilgLCBgZmFsc2VgIG90aGVyd2lzZQogICAgICovCiAgICBpc0VyckFuZFN5bmMoZXJyUHJlZGljYXRlKSB7CiAgICAgICAgcmV0dXJuIGZhbHNlOwogICAgfQogICAgLyoqCiAgICAgKiBDb21waWxlLXRpbWUgc2FmZWx5IGdldCBgdGhpcy5pbm5lcmAKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYAogICAgICovCiAgICBnZXQoKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gdGhpcy5pbm5lcjsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtIGBSZXN1bHQ8VCwgRT5gIGludG8gYE9wdGlvbjxUPmAKICAgICAqIEByZXR1cm5zIGBTb21lKHRoaXMuaW5uZXIpYCBpZiBgT2tgLCBgTm9uZWAgaWYgYEVycmAKICAgICAqLwogICAgb2soKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gbmV3IFNvbWUodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBgUmVzdWx0PFQsIEU+YCBpbnRvIGBPcHRpb248RT5gCiAgICAgKiBAcmV0dXJucyBgU29tZSh0aGlzLmlubmVyKWAgaWYgYEVycmAsIGBOb25lYCBpZiBgT2tgCiAgICAgKi8KICAgIGVycigpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiBuZXcgTm9uZSgpOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGFuIGl0ZXJhdG9yIG92ZXIgdGhlIHBvc3NpYmx5IGNvbnRhaW5lZCB2YWx1ZQogICAgICogQHlpZWxkcyBgdGhpcy5pbm5lcmAgaWYgYE9rYAogICAgICovCiAgICAqW1N5bWJvbC5pdGVyYXRvcl0oKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICB5aWVsZCB0aGlzLmlubmVyOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm0gYFJlc3VsdDxULEU+YCBpbnRvIGBbVCxFXWAKICAgICAqIEByZXR1cm5zIGBbdGhpcy5pbm5lciwgdW5kZWZpbmVkXWAgaWYgYE9rYCwgYFt1bmRlZmluZWQsIHRoaXMuaW5uZXJdYCBpZiBgRXJyYAogICAgICovCiAgICBzcGxpdCgpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiBbdGhpcy5pbm5lciwgdW5kZWZpbmVkXTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyB0cnVlIGlmIHRoZSByZXN1bHQgaXMgYW4gYE9rYCB2YWx1ZSBjb250YWluaW5nIHRoZSBnaXZlbiB2YWx1ZQogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYE9rYCBhbmQgYHRoaXMuaW5uZXIgPT09IHZhbHVlYCwgYGZhbHNlYCBvdGhlcndpc2UKICAgICAqLwogICAgY29udGFpbnModmFsdWUpIHsKICAgICAgICByZXR1cm4gdGhpcy5pbm5lciA9PT0gdmFsdWU7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgdHJ1ZSBpZiB0aGUgcmVzdWx0IGlzIGFuIGBFcnJgIHZhbHVlIGNvbnRhaW5pbmcgdGhlIGdpdmVuIHZhbHVlCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgRXJyYCBhbmQgYHRoaXMuaW5uZXIgPT09IHZhbHVlYCwgYGZhbHNlYCBvdGhlcndpc2UKICAgICAqLwogICAgY29udGFpbnNFcnIodmFsdWUpIHsKICAgICAgICByZXR1cm4gZmFsc2U7CiAgICB9CiAgICAvKioKICAgICAqIEp1c3QgbGlrZSBgdW53cmFwYCBidXQgaXQgdGhyb3dzIHRvIHRoZSBjbG9zZXN0IGBSZXN1bHQudW50aHJvd2AKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgT2tgCiAgICAgKiBAdGhyb3dzIGB0aGlzYCBpZiBgRXJyYAogICAgICogQHNlZSBSZXN1bHQudW50aHJvdwogICAgICogQHNlZSBSZXN1bHQudW50aHJvd1N5bmMKICAgICAqLwogICAgdGhyb3codGhyb3dlcikgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIHRoaXMuaW5uZXI7CiAgICB9CiAgICAvKioKICAgICAqIEdldCB0aGUgaW5uZXIgdmFsdWUgb3IgdGhyb3cgdGhlIGlubmVyIGVycm9yIHdyYXBwZWQgaW5zaWRlIGFub3RoZXIgRXJyb3IKICAgICAqIEBwYXJhbSBtZXNzYWdlCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAgaWYgYE9rYCwgYEVycm9yKG1lc3NhZ2UsIHsgY2F1c2U6IHRoaXMuaW5uZXIgfSlgIGlmIGBFcnJgCiAgICAgKi8KICAgIGV4cGVjdChtZXNzYWdlKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gdGhpcy5pbm5lcjsKICAgIH0KICAgIC8qKgogICAgICogR2V0IHRoZSBpbm5lciBlcnJvciBvciB0aHJvdyB0aGUgaW5uZXIgdmFsdWUgd3JhcHBlZCBpbnNpZGUgYW5vdGhlciBFcnJvcgogICAgICogQHBhcmFtIG1lc3NhZ2UKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgRXJyYCwgYEVycm9yKG1lc3NhZ2UsIHsgY2F1c2U6IHRoaXMuaW5uZXIgfSlgIGlmIGBPa2AKICAgICAqLwogICAgZXhwZWN0RXJyKG1lc3NhZ2UpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHRocm93IG5ldyBQYW5pYyhtZXNzYWdlLCB7IGNhdXNlOiB0aGlzLmlubmVyIH0pOwogICAgfQogICAgLyoqCiAgICAgKiBHZXQgdGhlIGlubmVyIHZhbHVlIG9yIHRocm93IHRoZSBpbm5lciBlcnJvcgogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBPa2AKICAgICAqIEB0aHJvd3MgYHRoaXMuaW5uZXJgIGlmIGBFcnJgCiAgICAgKi8KICAgIHVud3JhcCgpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiB0aGlzLmlubmVyOwogICAgfQogICAgLyoqCiAgICAgKiBUaHJvdyB0aGUgaW5uZXIgdmFsdWUgb3IgZ2V0IHRoZSBpbm5lciBlcnJvcgogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBFcnJgCiAgICAgKiBAdGhyb3dzIGB0aGlzLmlubmVyYCBpZiBgT2tgCiAgICAgKi8KICAgIHVud3JhcEVycigpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHRocm93IG5ldyBQYW5pYyh1bmRlZmluZWQsIHsgY2F1c2U6IHRoaXMuaW5uZXIgfSk7CiAgICB9CiAgICAvKioKICAgICAqIEdldCB0aGUgaW5uZXIgdmFsdWUgb3IgYSBkZWZhdWx0IG9uZQogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAgaWYgYE9rYCwgYHZhbHVlYCBpZiBgRXJyYAogICAgICovCiAgICB1bndyYXBPcih2YWx1ZSkgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIHRoaXMuaW5uZXI7CiAgICB9CiAgICAvKioKICAgICAqIEdldCB0aGUgaW5uZXIgdmFsdWUgb3IgY29tcHV0ZSBhIGRlZmF1bHQgb25lIGZyb20gdGhlIGlubmVyIGVycm9yCiAgICAgKiBAcGFyYW0gZXJyTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAgaWYgYE9rYCwgYGF3YWl0IGVyck1hcHBlcih0aGlzLmlubmVyKWAgaWYgYEVycmAKICAgICAqIEB0aHJvd3MgaWYgYGF3YWl0IGVyck1hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIGFzeW5jIHVud3JhcE9yRWxzZShlcnJNYXBwZXIpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiB0aGlzLmlubmVyOwogICAgfQogICAgLyoqCiAgICAgKiBHZXQgdGhlIGlubmVyIHZhbHVlIG9yIGNvbXB1dGUgYSBkZWZhdWx0IG9uZSBmcm9tIHRoZSBpbm5lciBlcnJvcgogICAgICogQHBhcmFtIGVyck1hcHBlcgogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBPa2AsIGBlcnJNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBFcnJgCiAgICAgKiBAdGhyb3dzIGlmIGBlcnJNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICB1bndyYXBPckVsc2VTeW5jKGVyck1hcHBlcikgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIHRoaXMuaW5uZXI7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBSZXN1bHQ8UHJvbWlzZTxUPiwgRT4gaW50byBQcm9taXNlPFJlc3VsdDxULCBFPj4KICAgICAqIEByZXR1cm5zIGBhd2FpdCB0aGlzLmlubmVyYCBpZiBgT2tgLCBgdGhpc2AgaWYgYEVycmAKICAgICAqLwogICAgYXN5bmMgYXdhaXQoKSB7CiAgICAgICAgcmV0dXJuIG5ldyBPayhhd2FpdCB0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtIFJlc3VsdDxULCBQcm9taXNlPEU+PiBpbnRvIFByb21pc2U8UmVzdWx0PFQsIEU+PgogICAgICogQHJldHVybnMgYGF3YWl0IHRoaXMuaW5uZXJgIGlmIGBFcnJgLCBgdGhpc2AgaWYgYE9rYAogICAgICovCiAgICBhc3luYyBhd2FpdEVycigpIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtIFJlc3VsdDxQcm9taXNlPFQ+LCBQcm9taXNlPEU+PiBpbnRvIFByb21pc2U8UmVzdWx0PFQsIEU+PgogICAgICogQHJldHVybnMgYGF3YWl0IHRoaXMuaW5uZXJgCiAgICAgKi8KICAgIGFzeW5jIGF3YWl0QWxsKCkgewogICAgICAgIHJldHVybiBhd2FpdCB0aGlzLmF3YWl0KCk7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBgUmVzdWx0PFQsIEU+YCBpbnRvIGBSZXN1bHQ8dm9pZCwgRT5gCiAgICAgKiBAcmV0dXJucyBgT2s8dm9pZD5gIGlmIGBPazxUPmAsIGBFcnI8RT5gIGlmIGBFPEU+YAogICAgICovCiAgICBjbGVhcigpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiBPay52b2lkKCk7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBgUmVzdWx0PFQsIEU+YCBpbnRvIGBSZXN1bHQ8VCwgdm9pZD5gCiAgICAgKiBAcmV0dXJucyBgT2s8VD5gIGlmIGBPazxUPmAsIGBFcnI8dm9pZD5gIGlmIGBFPEU+YAogICAgICovCiAgICBjbGVhckVycigpIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogQ2FsbHMgdGhlIGdpdmVuIGNhbGxiYWNrIHdpdGggdGhlIGlubmVyIHZhbHVlIGlmIGBPa2AKICAgICAqIEBwYXJhbSBva0NhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgdGhpc2AKICAgICAqLwogICAgYXN5bmMgaW5zcGVjdChva0NhbGxiYWNrKSB7CiAgICAgICAgYXdhaXQgb2tDYWxsYmFjayh0aGlzLmlubmVyKTsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogQ2FsbHMgdGhlIGdpdmVuIGNhbGxiYWNrIHdpdGggdGhlIGlubmVyIHZhbHVlIGlmIGBPa2AKICAgICAqIEBwYXJhbSBva0NhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgdGhpc2AKICAgICAqLwogICAgaW5zcGVjdFN5bmMob2tDYWxsYmFjaykgewogICAgICAgIG9rQ2FsbGJhY2sodGhpcy5pbm5lcik7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIENhbGxzIHRoZSBnaXZlbiBjYWxsYmFjayB3aXRoIHRoZSBpbm5lciB2YWx1ZSBpZiBgRXJyYAogICAgICogQHBhcmFtIGVyckNhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgdGhpc2AKICAgICAqLwogICAgYXN5bmMgaW5zcGVjdEVycihlcnJDYWxsYmFjaykgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBDYWxscyB0aGUgZ2l2ZW4gY2FsbGJhY2sgd2l0aCB0aGUgaW5uZXIgdmFsdWUgaWYgYEVycmAKICAgICAqIEBwYXJhbSBlcnJDYWxsYmFjawogICAgICogQHJldHVybnMgYHRoaXNgCiAgICAgKi8KICAgIGluc3BlY3RFcnJTeW5jKGVyckNhbGxiYWNrKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybiBhIG5ldyBgT2tgIGJ1dCB3aXRoIHRoZSBnaXZlbiBgaW5uZXJgCiAgICAgKiBAcGFyYW0gaW5uZXIKICAgICAqIEByZXR1cm5zIGBPayhpbm5lcilgIGlmIGBPa2AsIGB0aGlzYCBpZiBgRXJyYAogICAgICovCiAgICBzZXQoaW5uZXIpIHsKICAgICAgICByZXR1cm4gbmV3IE9rKGlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJuIGEgbmV3IGBFcnJgIGJ1dCB3aXRoIHRoZSBnaXZlbiBgaW5uZXJgCiAgICAgKiBAcGFyYW0gaW5uZXIKICAgICAqIEByZXR1cm5zIGBFcnIoaW5uZXIpYCBpZiBgRXJyYCwgYHRoaXNgIGlmIGBPa2AKICAgICAqLwogICAgc2V0RXJyKGlubmVyKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIE1hcCB0aGUgaW5uZXIgdmFsdWUgaW50byBhbm90aGVyCiAgICAgKiBAcGFyYW0gb2tNYXBwZXIKICAgICAqIEByZXR1cm5zIGBPayhhd2FpdCBva01hcHBlcih0aGlzLmlubmVyKSlgIGlmIGBPa2AsIGB0aGlzYCBpZiBgRXJyYAogICAgICogQHRocm93cyBpZiBgYXdhaXQgb2tNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICBhc3luYyBtYXAob2tNYXBwZXIpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiBuZXcgT2soYXdhaXQgb2tNYXBwZXIodGhpcy5pbm5lcikpOwogICAgfQogICAgLyoqCiAgICAgKiBNYXAgdGhlIGlubmVyIHZhbHVlIGludG8gYW5vdGhlcgogICAgICogQHBhcmFtIG9rTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgT2sob2tNYXBwZXIodGhpcy5pbm5lcikpYCBpZiBgT2tgLCBgdGhpc2AgaWYgYEVycmAKICAgICAqIEB0aHJvd3MgaWYgYG9rTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgbWFwU3luYyhva01hcHBlcikgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIG5ldyBPayhva01hcHBlcih0aGlzLmlubmVyKSk7CiAgICB9CiAgICAvKioKICAgICAqIE1hcCB0aGUgaW5uZXIgZXJyb3IgaW50byBhbm90aGVyCiAgICAgKiBAcGFyYW0gZXJyTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgRXJyKGF3YWl0IGVyck1hcHBlcih0aGlzLmlubmVyKSlgIGlmIGBFcnJgLCBgdGhpc2AgaWYgYE9rYAogICAgICogQHRocm93cyBpZiBgYXdhaXQgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgYXN5bmMgbWFwRXJyKGVyck1hcHBlcikgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBNYXAgdGhlIGlubmVyIGVycm9yIGludG8gYW5vdGhlcgogICAgICogQHBhcmFtIGVyck1hcHBlcgogICAgICogQHJldHVybnMgYEVycihlcnJNYXBwZXIodGhpcy5pbm5lcikpYCBpZiBgRXJyYCwgYHRoaXNgIGlmIGBPa2AKICAgICAqIEB0aHJvd3MgaWYgYGVyck1hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIG1hcEVyclN5bmMoZXJyTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIE1hcCB0aGUgaW5uZXIgdmFsdWUgaW50byBhbm90aGVyLCBvciBhIGRlZmF1bHQgb25lCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEBwYXJhbSBva01hcHBlcgogICAgICogQHJldHVybnMgYGF3YWl0IG9rTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgT2tgLCBgdmFsdWVgIGlmIGBFcnJgCiAgICAgKiBAdGhyb3dzIGlmIGBhd2FpdCBva01hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIGFzeW5jIG1hcE9yKHZhbHVlLCBva01hcHBlcikgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIGF3YWl0IG9rTWFwcGVyKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBNYXAgdGhlIGlubmVyIHZhbHVlIGludG8gYW5vdGhlciwgb3IgYSBkZWZhdWx0IG9uZQogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcGFyYW0gb2tNYXBwZXIKICAgICAqIEByZXR1cm5zIGBva01hcHBlcih0aGlzLmlubmVyKWAgaWYgYE9rYCwgYHZhbHVlYCBpZiBgRXJyYAogICAgICogQHRocm93cyBpZiBgb2tNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICBtYXBPclN5bmModmFsdWUsIG9rTWFwcGVyKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gb2tNYXBwZXIodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIE1hcCB0aGUgaW5uZXIgdmFsdWUgaW50byBhbm90aGVyLCBvciBhIGRlZmF1bHQgb25lCiAgICAgKiBAcGFyYW0gZXJyTWFwcGVyCiAgICAgKiBAcGFyYW0gb2tNYXBwZXIKICAgICAqIEByZXR1cm5zIGBhd2FpdCBva01hcHBlcih0aGlzLmlubmVyKWAgaWYgYE9rYCwgYGF3YWl0IGVyck1hcHBlcih0aGlzLmlubmVyKWAgaWYgYEVycmAKICAgICAqIEB0aHJvd3MgaWYgYGF3YWl0IG9rTWFwcGVyKHRoaXMuaW5uZXIpYCBvciBgYXdhaXQgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgYXN5bmMgbWFwT3JFbHNlKGVyck1hcHBlciwgb2tNYXBwZXIpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiBhd2FpdCBva01hcHBlcih0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogTWFwIHRoZSBpbm5lciB2YWx1ZSBpbnRvIGFub3RoZXIsIG9yIGEgZGVmYXVsdCBvbmUKICAgICAqIEBwYXJhbSBlcnJNYXBwZXIKICAgICAqIEBwYXJhbSBva01hcHBlcgogICAgICogQHJldHVybnMgYG9rTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgT2tgLCBgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgRXJyYAogICAgICogQHRocm93cyBpZiBgb2tNYXBwZXIodGhpcy5pbm5lcilgIG9yIGBlcnJNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICBtYXBPckVsc2VTeW5jKGVyck1hcHBlciwgb2tNYXBwZXIpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiBva01hcHBlcih0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJuIGB2YWx1ZWAgaWYgYE9rYCwgcmV0dXJuIGB0aGlzYCBpZiBgRXJyYAogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcmV0dXJucyBgdmFsdWVgIGlmIGBPa2AsIGB0aGlzYCBpZiBgRXJyYAogICAgICovCiAgICBhbmQodmFsdWUpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiB2YWx1ZTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJuIGBhd2FpdCBva01hcHBlcih0aGlzLmlubmVyKWAgaWYgYE9rYCwgcmV0dXJuIGB0aGlzYCBpZiBgRXJyYAogICAgICogQHBhcmFtIG9rTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgYXdhaXQgb2tNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBPa2AsIGB0aGlzYCBpZiBgRXJyYAogICAgICogQHRocm93cyBpZiBgYXdhaXQgb2tNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICBhc3luYyBhbmRUaGVuKG9rTWFwcGVyKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gYXdhaXQgb2tNYXBwZXIodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybiBgb2tNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBPa2AsIHJldHVybiBgdGhpc2AgaWYgYEVycmAKICAgICAqIEBwYXJhbSBva01hcHBlcgogICAgICogQHJldHVybnMgYG9rTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgT2tgLCBgdGhpc2AgaWYgYEVycmAKICAgICAqIEB0aHJvd3MgaWYgYG9rTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgYW5kVGhlblN5bmMob2tNYXBwZXIpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiBva01hcHBlcih0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJuIGB2YWx1ZWAgaWYgYEVycmAsIHJldHVybiBgdGhpc2AgaWYgYE9rYAogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcmV0dXJucyBgdmFsdWVgIGlmIGBFcnJgLCBgdGhpc2AgaWYgYE9rYAogICAgICovCiAgICBvcih2YWx1ZSkgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm4gYGF3YWl0IGVyck1hcHBlcih0aGlzLmlubmVyKWAgaWYgYEVycmAsIHJldHVybiBgdGhpc2AgaWYgYE9rYAogICAgICogQHBhcmFtIGVyck1hcHBlcgogICAgICogQHJldHVybnMgYGF3YWl0IGVyck1hcHBlcih0aGlzLmlubmVyKWAgaWYgYEVycmAsIGB0aGlzYCBpZiBgT2tgCiAgICAgKiBAdGhyb3dzIGlmIGBhd2FpdCBlcnJNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICBhc3luYyBvckVsc2UoZXJyTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybiBgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgRXJyYCwgcmV0dXJuIGB0aGlzYCBpZiBgT2tgCiAgICAgKiBAcGFyYW0gZXJyTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgRXJyYCwgYHRoaXNgIGlmIGBPa2AKICAgICAqIEB0aHJvd3MgaWYgYGVyck1hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIG9yRWxzZVN5bmMoZXJyTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9Cn0KCgovLyMgc291cmNlTWFwcGluZ1VSTD1vay5tanMubWFwCgo7Ly8gQ09OQ0FURU5BVEVEIE1PRFVMRTogLi9zcmMvbGlicy9ycGMvb2sudHMKCnZhciBScGNPa0luaXQ7CihmdW5jdGlvbihScGNPa0luaXQpIHsKICAgIGZ1bmN0aW9uIGNsb25lKGluaXQpIHsKICAgICAgICBjb25zdCB7IGpzb25ycGMsIGlkLCByZXN1bHQgfSA9IGluaXQ7CiAgICAgICAgcmV0dXJuIHsKICAgICAgICAgICAganNvbnJwYywKICAgICAgICAgICAgaWQsCiAgICAgICAgICAgIHJlc3VsdAogICAgICAgIH07CiAgICB9CiAgICBScGNPa0luaXQuY2xvbmUgPSBjbG9uZTsKfSkoUnBjT2tJbml0IHx8IChScGNPa0luaXQgPSB7fSkpOwooZnVuY3Rpb24oUnBjT2tJbml0KSB7CiAgICBmdW5jdGlvbiBmcm9tKHJlc3BvbnNlKSB7CiAgICAgICAgY29uc3QgeyBqc29ucnBjLCBpZCwgcmVzdWx0IH0gPSByZXNwb25zZTsKICAgICAgICByZXR1cm4gewogICAgICAgICAgICBqc29ucnBjLAogICAgICAgICAgICBpZCwKICAgICAgICAgICAgcmVzdWx0CiAgICAgICAgfTsKICAgIH0KICAgIFJwY09rSW5pdC5mcm9tID0gZnJvbTsKfSkoUnBjT2tJbml0IHx8IChScGNPa0luaXQgPSB7fSkpOwpjbGFzcyBScGNPayBleHRlbmRzIE9rIHsKICAgIHN0YXRpYyBmcm9tKGluaXQpIHsKICAgICAgICByZXR1cm4gbmV3IFJwY09rKGluaXQuaWQsIGluaXQucmVzdWx0KTsKICAgIH0KICAgIGNvbnN0cnVjdG9yKGlkLCByZXN1bHQpewogICAgICAgIHN1cGVyKHJlc3VsdCk7CiAgICAgICAgdGhpcy5pZCA9IGlkOwogICAgICAgIHRoaXMucmVzdWx0ID0gcmVzdWx0OwogICAgICAgIHRoaXMuanNvbnJwYyA9ICIyLjAiOwogICAgfQp9Cgo7Ly8gQ09OQ0FURU5BVEVEIE1PRFVMRTogLi9zcmMvbGlicy9ycGMvcmVxdWVzdC50cwp2YXIgUnBjUmVxdWVzdEluaXQ7CihmdW5jdGlvbihScGNSZXF1ZXN0SW5pdCkgewogICAgZnVuY3Rpb24gY2xvbmUoaW5pdCkgewogICAgICAgIGNvbnN0IHsgaWQsIG1ldGhvZCwgcGFyYW1zIH0gPSBpbml0OwogICAgICAgIHJldHVybiB7CiAgICAgICAgICAgIGlkLAogICAgICAgICAgICBtZXRob2QsCiAgICAgICAgICAgIHBhcmFtcwogICAgICAgIH07CiAgICB9CiAgICBScGNSZXF1ZXN0SW5pdC5jbG9uZSA9IGNsb25lOwp9KShScGNSZXF1ZXN0SW5pdCB8fCAoUnBjUmVxdWVzdEluaXQgPSB7fSkpOwpjbGFzcyBScGNSZXF1ZXN0IHsKICAgIHN0YXRpYyBmcm9tKGluaXQpIHsKICAgICAgICBjb25zdCB7IGlkLCBtZXRob2QsIHBhcmFtcyB9ID0gaW5pdDsKICAgICAgICByZXR1cm4gbmV3IFJwY1JlcXVlc3QoaWQsIG1ldGhvZCwgcGFyYW1zKTsKICAgIH0KICAgIGNvbnN0cnVjdG9yKGlkLCBtZXRob2QsIHBhcmFtcyl7CiAgICAgICAgdGhpcy5pZCA9IGlkOwogICAgICAgIHRoaXMubWV0aG9kID0gbWV0aG9kOwogICAgICAgIHRoaXMucGFyYW1zID0gcGFyYW1zOwogICAgICAgIHRoaXMuanNvbnJwYyA9ICIyLjAiOwogICAgfQp9Cgo7Ly8gQ09OQ0FURU5BVEVEIE1PRFVMRTogLi9zcmMvbGlicy9ycGMvZXJyLnRzCgpjbGFzcyBScGNFcnJvciBleHRlbmRzIEVycm9yIHsKICAgIHN0YXRpYyBmcm9tKGVycm9yKSB7CiAgICAgICAgcmV0dXJuIG5ldyBScGNFcnJvcihlcnJvci5tZXNzYWdlKTsKICAgIH0KICAgIHRvSlNPTigpIHsKICAgICAgICBjb25zdCB7IG1lc3NhZ2UgfSA9IHRoaXM7CiAgICAgICAgcmV0dXJuIHsKICAgICAgICAgICAgbWVzc2FnZQogICAgICAgIH07CiAgICB9Cn0KY2xhc3MgUnBjRXJyIGV4dGVuZHMgRXJyIHsKICAgIHN0YXRpYyBmcm9tKGluaXQpIHsKICAgICAgICByZXR1cm4gbmV3IFJwY0Vycihpbml0LmlkLCBuZXcgUnBjRXJyb3IoaW5pdC5lcnJvci5tZXNzYWdlKSk7CiAgICB9CiAgICBjb25zdHJ1Y3RvcihpZCwgZXJyb3IpewogICAgICAgIHN1cGVyKGVycm9yKTsKICAgICAgICB0aGlzLmlkID0gaWQ7CiAgICAgICAgdGhpcy5lcnJvciA9IGVycm9yOwogICAgICAgIHRoaXMuanNvbnJwYyA9ICIyLjAiOwogICAgfQp9Cgo7Ly8gQ09OQ0FURU5BVEVEIE1PRFVMRTogLi9zcmMvbGlicy9ycGMvcmVzcG9uc2UudHMKCgp2YXIgUnBjUmVzcG9uc2U7CihmdW5jdGlvbihScGNSZXNwb25zZSkgewogICAgZnVuY3Rpb24gZnJvbShpbml0KSB7CiAgICAgICAgaWYgKCJlcnJvciIgaW4gaW5pdCkgcmV0dXJuIFJwY0Vyci5mcm9tKGluaXQpOwogICAgICAgIHJldHVybiBScGNPay5mcm9tKGluaXQpOwogICAgfQogICAgUnBjUmVzcG9uc2UuZnJvbSA9IGZyb207CiAgICBmdW5jdGlvbiByZXdyYXAoaWQsIHJlc3VsdCkgewogICAgICAgIHJlc3VsdC5pZ25vcmUoKTsKICAgICAgICBpZiAocmVzdWx0LmlzT2soKSkgcmV0dXJuIG5ldyBScGNPayhpZCwgcmVzdWx0LmlubmVyKTsKICAgICAgICBpZiAocmVzdWx0LmlubmVyIGluc3RhbmNlb2YgRXJyb3IpIHJldHVybiBuZXcgUnBjRXJyKGlkLCBScGNFcnJvci5mcm9tKHJlc3VsdC5pbm5lcikpOwogICAgICAgIHJldHVybiBuZXcgUnBjRXJyKGlkLCBuZXcgUnBjRXJyb3IoKSk7CiAgICB9CiAgICBScGNSZXNwb25zZS5yZXdyYXAgPSByZXdyYXA7Cn0pKFJwY1Jlc3BvbnNlIHx8IChScGNSZXNwb25zZSA9IHt9KSk7Cgo7Ly8gQ09OQ0FURU5BVEVEIE1PRFVMRTogLi9ub2RlX21vZHVsZXMvQHN3Yy9oZWxwZXJzL2VzbS9fY2xhc3NfYXBwbHlfZGVzY3JpcHRvcl91cGRhdGUuanMKZnVuY3Rpb24gX2NsYXNzX2FwcGx5X2Rlc2NyaXB0b3JfdXBkYXRlKHJlY2VpdmVyLCBkZXNjcmlwdG9yKSB7CiAgICBpZiAoZGVzY3JpcHRvci5zZXQpIHsKICAgICAgICBpZiAoIWRlc2NyaXB0b3IuZ2V0KSB0aHJvdyBuZXcgVHlwZUVycm9yKCJhdHRlbXB0ZWQgdG8gcmVhZCBzZXQgb25seSBwcml2YXRlIGZpZWxkIik7CgogICAgICAgIGlmICghKCJfX2Rlc3RyV3JhcHBlciIgaW4gZGVzY3JpcHRvcikpIHsKICAgICAgICAgICAgZGVzY3JpcHRvci5fX2Rlc3RyV3JhcHBlciA9IHsKICAgICAgICAgICAgICAgIHNldCB2YWx1ZSh2KSB7CiAgICAgICAgICAgICAgICAgICAgZGVzY3JpcHRvci5zZXQuY2FsbChyZWNlaXZlciwgdik7CiAgICAgICAgICAgICAgICB9LAogICAgICAgICAgICAgICAgZ2V0IHZhbHVlKCkgewogICAgICAgICAgICAgICAgICAgIHJldHVybiBkZXNjcmlwdG9yLmdldC5jYWxsKHJlY2VpdmVyKTsKICAgICAgICAgICAgICAgIH0KICAgICAgICAgICAgfTsKICAgICAgICB9CgogICAgICAgIHJldHVybiBkZXNjcmlwdG9yLl9fZGVzdHJXcmFwcGVyOwogICAgfSBlbHNlIHsKICAgICAgICBpZiAoIWRlc2NyaXB0b3Iud3JpdGFibGUpIHsKICAgICAgICAgICAgLy8gVGhpcyBzaG91bGQgb25seSB0aHJvdyBpbiBzdHJpY3QgbW9kZSwgYnV0IGNsYXNzIGJvZGllcyBhcmUKICAgICAgICAgICAgLy8gYWx3YXlzIHN0cmljdCBhbmQgcHJpdmF0ZSBmaWVsZHMgY2FuIG9ubHkgYmUgdXNlZCBpbnNpZGUKICAgICAgICAgICAgLy8gY2xhc3MgYm9kaWVzLgogICAgICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCJhdHRlbXB0ZWQgdG8gc2V0IHJlYWQgb25seSBwcml2YXRlIGZpZWxkIik7CiAgICAgICAgfQoKICAgICAgICByZXR1cm4gZGVzY3JpcHRvcjsKICAgIH0KfQoKCjsvLyBDT05DQVRFTkFURUQgTU9EVUxFOiAuL25vZGVfbW9kdWxlcy9Ac3djL2hlbHBlcnMvZXNtL19jbGFzc19wcml2YXRlX2ZpZWxkX3VwZGF0ZS5qcwoKCgpmdW5jdGlvbiBfY2xhc3NfcHJpdmF0ZV9maWVsZF91cGRhdGUocmVjZWl2ZXIsIHByaXZhdGVNYXApIHsKICAgIHZhciBkZXNjcmlwdG9yID0gX2NsYXNzX2V4dHJhY3RfZmllbGRfZGVzY3JpcHRvcihyZWNlaXZlciwgcHJpdmF0ZU1hcCwgInVwZGF0ZSIpOwogICAgcmV0dXJuIF9jbGFzc19hcHBseV9kZXNjcmlwdG9yX3VwZGF0ZShyZWNlaXZlciwgZGVzY3JpcHRvcik7Cn0KCgo7Ly8gQ09OQ0FURU5BVEVEIE1PRFVMRTogLi9ub2RlX21vZHVsZXMvQGhhemFlNDEvZnV0dXJlL2Rpc3QvZXNtL21vZHMvZnV0dXJlL2Z1dHVyZS5tanMKY2xhc3MgRnV0dXJlIHsKICAgICNyZXNvbHZlOwogICAgI3JlamVjdDsKICAgIHByb21pc2U7CiAgICAvKioKICAgICAqIEp1c3QgbGlrZSBhIFByb21pc2UgYnV0IHlvdSBjYW4gbWFudWFsbHkgcmVzb2x2ZSBvciByZWplY3QgaXQKICAgICAqLwogICAgY29uc3RydWN0b3IoKSB7CiAgICAgICAgdGhpcy5wcm9taXNlID0gbmV3IFByb21pc2UoKHN1YnJlc29sdmUsIHN1YnJlamVjdCkgPT4gewogICAgICAgICAgICB0aGlzLiNyZXNvbHZlID0gc3VicmVzb2x2ZTsKICAgICAgICAgICAgdGhpcy4jcmVqZWN0ID0gc3VicmVqZWN0OwogICAgICAgIH0pOwogICAgfQogICAgZ2V0IHJlc29sdmUoKSB7CiAgICAgICAgcmV0dXJuIHRoaXMuI3Jlc29sdmU7CiAgICB9CiAgICBnZXQgcmVqZWN0KCkgewogICAgICAgIHJldHVybiB0aGlzLiNyZWplY3Q7CiAgICB9Cn0KCgovLyMgc291cmNlTWFwcGluZ1VSTD1mdXR1cmUubWpzLm1hcAoKOy8vIENPTkNBVEVOQVRFRCBNT0RVTEU6IC4vbm9kZV9tb2R1bGVzL0BoYXphZTQxL2NsZWFuZXIvZGlzdC9lc20vbW9kcy9jbGVhbmVyL2NsZWFuZXIubWpzCnZhciBDbGVhbmFibGU7CihmdW5jdGlvbiAoQ2xlYW5hYmxlKSB7CiAgICBhc3luYyBmdW5jdGlvbiBydW5XaXRoKGNsZWFuYWJsZSwgY2FsbGJhY2spIHsKICAgICAgICB0cnkgewogICAgICAgICAgICByZXR1cm4gYXdhaXQgY2FsbGJhY2soY2xlYW5hYmxlKTsKICAgICAgICB9CiAgICAgICAgZmluYWxseSB7CiAgICAgICAgICAgIGNsZWFuYWJsZT8uY2xlYW4oKTsKICAgICAgICB9CiAgICB9CiAgICBDbGVhbmFibGUucnVuV2l0aCA9IHJ1bldpdGg7CiAgICBmdW5jdGlvbiBydW5XaXRoU3luYyhjbGVhbmFibGUsIGNhbGxiYWNrKSB7CiAgICAgICAgdHJ5IHsKICAgICAgICAgICAgcmV0dXJuIGNhbGxiYWNrKGNsZWFuYWJsZSk7CiAgICAgICAgfQogICAgICAgIGZpbmFsbHkgewogICAgICAgICAgICBjbGVhbmFibGU/LmNsZWFuKCk7CiAgICAgICAgfQogICAgfQogICAgQ2xlYW5hYmxlLnJ1bldpdGhTeW5jID0gcnVuV2l0aFN5bmM7Cn0pKENsZWFuYWJsZSA9IENsZWFuYWJsZSB8fCAoQ2xlYW5hYmxlID0ge30pKTsKY2xhc3MgQ2xlYW5lciB7CiAgICBpbm5lcjsKICAgIGNsZWFuOwogICAgY29uc3RydWN0b3IoaW5uZXIsIGNsZWFuKSB7CiAgICAgICAgdGhpcy5pbm5lciA9IGlubmVyOwogICAgICAgIHRoaXMuY2xlYW4gPSBjbGVhbjsKICAgIH0KfQooZnVuY3Rpb24gKENsZWFuZXIpIHsKICAgIGFzeW5jIGZ1bmN0aW9uIHdhaXQoY2xlYW5lcikgewogICAgICAgIHRyeSB7CiAgICAgICAgICAgIHJldHVybiBhd2FpdCBjbGVhbmVyLmlubmVyOwogICAgICAgIH0KICAgICAgICBmaW5hbGx5IHsKICAgICAgICAgICAgY2xlYW5lci5jbGVhbigpOwogICAgICAgIH0KICAgIH0KICAgIENsZWFuZXIud2FpdCA9IHdhaXQ7CiAgICBhc3luYyBmdW5jdGlvbiByYWNlKGNsZWFuZXJzKSB7CiAgICAgICAgY29uc3QgcHJvbWlzZXMgPSBuZXcgQXJyYXkoY2xlYW5lcnMubGVuZ3RoKTsKICAgICAgICBjb25zdCBjbGVhbnVwcyA9IG5ldyBBcnJheShjbGVhbmVycy5sZW5ndGgpOwogICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgY2xlYW5lcnMubGVuZ3RoOyBpKyspIHsKICAgICAgICAgICAgcHJvbWlzZXNbaV0gPSBjbGVhbmVyc1tpXS5pbm5lcjsKICAgICAgICAgICAgY2xlYW51cHNbaV0gPSBjbGVhbmVyc1tpXS5jbGVhbjsKICAgICAgICB9CiAgICAgICAgdHJ5IHsKICAgICAgICAgICAgcmV0dXJuIGF3YWl0IFByb21pc2UucmFjZShwcm9taXNlcyk7CiAgICAgICAgfQogICAgICAgIGZpbmFsbHkgewogICAgICAgICAgICBjbGVhbnVwcy5mb3JFYWNoKGNsZWFudXAgPT4gY2xlYW51cCgpKTsKICAgICAgICB9CiAgICB9CiAgICBDbGVhbmVyLnJhY2UgPSByYWNlOwp9KShDbGVhbmVyID0gQ2xlYW5lciB8fCAoQ2xlYW5lciA9IHt9KSk7CgoKLy8jIHNvdXJjZU1hcHBpbmdVUkw9Y2xlYW5lci5tanMubWFwCgo7Ly8gQ09OQ0FURU5BVEVEIE1PRFVMRTogLi9ub2RlX21vZHVsZXMvQGhhemFlNDEvcGx1bWUvZGlzdC9lc20vbW9kcy9lcnJvcnMubWpzCgoKCgoKY2xhc3MgQWJvcnRlZEVycm9yIGV4dGVuZHMgRXJyb3IgewogICAgI2NsYXNzID0gQWJvcnRlZEVycm9yOwogICAgbmFtZSA9IHRoaXMuI2NsYXNzLm5hbWU7CiAgICBzdGF0aWMgZnJvbShjYXVzZSkgewogICAgICAgIHJldHVybiBuZXcgQWJvcnRlZEVycm9yKGBBYm9ydGVkYCwgeyBjYXVzZSB9KTsKICAgIH0KICAgIHN0YXRpYyB3YWl0KHNpZ25hbCkgewogICAgICAgIGNvbnN0IGZ1dHVyZSA9IG5ldyBGdXR1cmUoKTsKICAgICAgICBjb25zdCBvbkFib3J0ID0gKGV2ZW50KSA9PiB7CiAgICAgICAgICAgIGZ1dHVyZS5yZXNvbHZlKG5ldyBFcnIoQWJvcnRlZEVycm9yLmZyb20oZXZlbnQpKSk7CiAgICAgICAgfTsKICAgICAgICBzaWduYWwuYWRkRXZlbnRMaXN0ZW5lcigiYWJvcnQiLCBvbkFib3J0LCB7IHBhc3NpdmU6IHRydWUgfSk7CiAgICAgICAgY29uc3Qgb2ZmID0gKCkgPT4gc2lnbmFsLnJlbW92ZUV2ZW50TGlzdGVuZXIoImFib3J0Iiwgb25BYm9ydCk7CiAgICAgICAgcmV0dXJuIG5ldyBDbGVhbmVyKGZ1dHVyZS5wcm9taXNlLCBvZmYpOwogICAgfQp9CmNsYXNzIEVycm9yZWRFcnJvciBleHRlbmRzIEVycm9yIHsKICAgICNjbGFzcyA9IEVycm9yZWRFcnJvcjsKICAgIG5hbWUgPSB0aGlzLiNjbGFzcy5uYW1lOwogICAgc3RhdGljIGZyb20oY2F1c2UpIHsKICAgICAgICByZXR1cm4gbmV3IEVycm9yZWRFcnJvcihgRXJyb3JlZGAsIHsgY2F1c2UgfSk7CiAgICB9CiAgICBzdGF0aWMgd2FpdCh0YXJnZXQpIHsKICAgICAgICByZXR1cm4gdGFyZ2V0LndhaXQoImVycm9yIiwgKGZ1dHVyZSwgZXZlbnQpID0+IHsKICAgICAgICAgICAgY29uc3QgZXJyb3IgPSBFcnJvcmVkRXJyb3IuZnJvbShldmVudCk7CiAgICAgICAgICAgIGZ1dHVyZS5yZXNvbHZlKG5ldyBFcnIoZXJyb3IpKTsKICAgICAgICAgICAgcmV0dXJuIG5ldyBOb25lKCk7CiAgICAgICAgfSk7CiAgICB9Cn0KY2xhc3MgQ2xvc2VkRXJyb3IgZXh0ZW5kcyBFcnJvciB7CiAgICAjY2xhc3MgPSBDbG9zZWRFcnJvcjsKICAgIG5hbWUgPSB0aGlzLiNjbGFzcy5uYW1lOwogICAgc3RhdGljIGZyb20oY2F1c2UpIHsKICAgICAgICByZXR1cm4gbmV3IENsb3NlZEVycm9yKGBDbG9zZWRgLCB7IGNhdXNlIH0pOwogICAgfQogICAgc3RhdGljIHdhaXQodGFyZ2V0KSB7CiAgICAgICAgcmV0dXJuIHRhcmdldC53YWl0KCJjbG9zZSIsIChmdXR1cmUsIGV2ZW50KSA9PiB7CiAgICAgICAgICAgIGNvbnN0IGVycm9yID0gQ2xvc2VkRXJyb3IuZnJvbShldmVudCk7CiAgICAgICAgICAgIGZ1dHVyZS5yZXNvbHZlKG5ldyBFcnIoZXJyb3IpKTsKICAgICAgICAgICAgcmV0dXJuIG5ldyBOb25lKCk7CiAgICAgICAgfSk7CiAgICB9Cn0KCgovLyMgc291cmNlTWFwcGluZ1VSTD1lcnJvcnMubWpzLm1hcAoKOy8vIENPTkNBVEVOQVRFRCBNT0RVTEU6IC4vc3JjL2xpYnMvcnBjL3JwYy50cwoKCgoKCgoKCgoKdmFyIF9pZCA9IC8qI19fUFVSRV9fKi8gbmV3IFdlYWtNYXAoKTsKY2xhc3MgUnBjQ2xpZW50IHsKICAgIGdldCBpZCgpIHsKICAgICAgICByZXR1cm4gX2NsYXNzX3ByaXZhdGVfZmllbGRfZ2V0KHRoaXMsIF9pZCk7CiAgICB9CiAgICBjcmVhdGUoaW5pdCkgewogICAgICAgIGNvbnN0IHsgbWV0aG9kLCBwYXJhbXMgfSA9IGluaXQ7CiAgICAgICAgY29uc3QgaWQgPSBfY2xhc3NfcHJpdmF0ZV9maWVsZF91cGRhdGUodGhpcywgX2lkKS52YWx1ZSsrOwogICAgICAgIHJldHVybiB7CiAgICAgICAgICAgIGpzb25ycGM6ICIyLjAiLAogICAgICAgICAgICBpZCwKICAgICAgICAgICAgbWV0aG9kLAogICAgICAgICAgICBwYXJhbXMKICAgICAgICB9OwogICAgfQogICAgYXN5bmMgZmV0Y2goaW5wdXQsIGluaXQpIHsKICAgICAgICBjb25zdCB7IG1ldGhvZCwgcGFyYW1zLCAuLi5yZXN0IH0gPSBpbml0OwogICAgICAgIGNvbnN0IHJlcXVlc3QgPSB0aGlzLmNyZWF0ZSh7CiAgICAgICAgICAgIG1ldGhvZCwKICAgICAgICAgICAgcGFyYW1zCiAgICAgICAgfSk7CiAgICAgICAgcmV0dXJuIFJwYy5mZXRjaChpbnB1dCwgewogICAgICAgICAgICAuLi5yZXN0LAogICAgICAgICAgICAuLi5yZXF1ZXN0CiAgICAgICAgfSk7CiAgICB9CiAgICBhc3luYyB0cnlGZXRjaFdpdGhTb2NrZXQoc29ja2V0LCByZXF1ZXN0LCBzaWduYWwpIHsKICAgICAgICByZXR1cm4gYXdhaXQgUnBjLnRyeUZldGNoV2l0aFNvY2tldChzb2NrZXQsIHRoaXMuY3JlYXRlKHJlcXVlc3QpLCBzaWduYWwpOwogICAgfQogICAgY29uc3RydWN0b3IoKXsKICAgICAgICBfY2xhc3NfcHJpdmF0ZV9maWVsZF9pbml0KHRoaXMsIF9pZCwgewogICAgICAgICAgICB3cml0YWJsZTogdHJ1ZSwKICAgICAgICAgICAgdmFsdWU6IHZvaWQgMAogICAgICAgIH0pOwogICAgICAgIF9jbGFzc19wcml2YXRlX2ZpZWxkX3NldCh0aGlzLCBfaWQsIDApOwogICAgfQp9CnZhciBScGM7CihmdW5jdGlvbihScGMpIHsKICAgIGFzeW5jIGZ1bmN0aW9uIGZldGNoKGlucHV0LCBpbml0KSB7CiAgICAgICAgY29uc3QgeyBpZCwgbWV0aG9kLCBwYXJhbXMsIC4uLnJlc3QgfSA9IGluaXQ7CiAgICAgICAgY29uc3QgaGVhZGVycyA9IG5ldyBIZWFkZXJzKHJlc3QuaGVhZGVycyk7CiAgICAgICAgaGVhZGVycy5zZXQoIkNvbnRlbnQtVHlwZSIsICJhcHBsaWNhdGlvbi9qc29uIik7CiAgICAgICAgY29uc3QgcmVxdWVzdCA9IG5ldyBScGNSZXF1ZXN0KGlkLCBtZXRob2QsIHBhcmFtcyk7CiAgICAgICAgY29uc3QgYm9keSA9IEpTT04uc3RyaW5naWZ5KHJlcXVlc3QpOwogICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGdsb2JhbFRoaXMuZmV0Y2goaW5wdXQsIHsKICAgICAgICAgICAgLi4uaW5pdCwKICAgICAgICAgICAgaGVhZGVycywKICAgICAgICAgICAgYm9keQogICAgICAgIH0pOwogICAgICAgIGlmICghcmVzLm9rKSB7CiAgICAgICAgICAgIGNvbnN0IGVycm9yID0gbmV3IFJwY0Vycm9yKGF3YWl0IHJlcy50ZXh0KCkpOwogICAgICAgICAgICByZXR1cm4gbmV3IFJwY0VycihyZXF1ZXN0LmlkLCBlcnJvcik7CiAgICAgICAgfQogICAgICAgIGNvbnN0IHJlc3BvbnNlID0gUnBjUmVzcG9uc2UuZnJvbShhd2FpdCByZXMuanNvbigpKTsKICAgICAgICBpZiAocmVzcG9uc2UuaWQgIT09IHJlcXVlc3QuaWQpIHJldHVybiBuZXcgRXJyKG5ldyBQYW5pYygiSW52YWxpZCByZXNwb25zZSBJRCIpKTsKICAgICAgICByZXR1cm4gcmVzcG9uc2U7CiAgICB9CiAgICBScGMuZmV0Y2ggPSBmZXRjaDsKICAgIGFzeW5jIGZ1bmN0aW9uIHRyeUZldGNoV2l0aFNvY2tldChzb2NrZXQsIHJlcXVlc3QsIHNpZ25hbCkgewogICAgICAgIGNvbnN0IHsgaWQsIG1ldGhvZCwgcGFyYW1zID0gW10gfSA9IHJlcXVlc3Q7CiAgICAgICAgc29ja2V0LnNlbmQoSlNPTi5zdHJpbmdpZnkobmV3IFJwY1JlcXVlc3QoaWQsIG1ldGhvZCwgcGFyYW1zKSkpOwogICAgICAgIGNvbnN0IGZ1dHVyZSA9IG5ldyBGdXR1cmUoKTsKICAgICAgICBjb25zdCBvbk1lc3NhZ2UgPSBhc3luYyAoZXZlbnQpPT57CiAgICAgICAgICAgIGNvbnN0IG1zZ0V2ZW50ID0gZXZlbnQ7CiAgICAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gUnBjUmVzcG9uc2UuZnJvbShKU09OLnBhcnNlKG1zZ0V2ZW50LmRhdGEpKTsKICAgICAgICAgICAgaWYgKHJlc3BvbnNlLmlkICE9PSByZXF1ZXN0LmlkKSByZXR1cm47CiAgICAgICAgICAgIGZ1dHVyZS5yZXNvbHZlKG5ldyBPayhyZXNwb25zZSkpOwogICAgICAgIH07CiAgICAgICAgY29uc3Qgb25FcnJvciA9IChlKT0+ewogICAgICAgICAgICBjb25zdCByZXN1bHQgPSBuZXcgRXJyKEVycm9yZWRFcnJvci5mcm9tKGUpKTsKICAgICAgICAgICAgZnV0dXJlLnJlc29sdmUocmVzdWx0KTsKICAgICAgICB9OwogICAgICAgIGNvbnN0IG9uQ2xvc2UgPSAoZSk9PnsKICAgICAgICAgICAgY29uc3QgcmVzdWx0ID0gbmV3IEVycihDbG9zZWRFcnJvci5mcm9tKGUpKTsKICAgICAgICAgICAgZnV0dXJlLnJlc29sdmUocmVzdWx0KTsKICAgICAgICB9OwogICAgICAgIGNvbnN0IG9uQWJvcnQgPSAoKT0+ewogICAgICAgICAgICBzb2NrZXQuY2xvc2UoKTsKICAgICAgICAgICAgY29uc3QgcmVzdWx0ID0gbmV3IEVycihBYm9ydGVkRXJyb3IuZnJvbShzaWduYWwucmVhc29uKSk7CiAgICAgICAgICAgIGZ1dHVyZS5yZXNvbHZlKHJlc3VsdCk7CiAgICAgICAgfTsKICAgICAgICB0cnkgewogICAgICAgICAgICBzb2NrZXQuYWRkRXZlbnRMaXN0ZW5lcigibWVzc2FnZSIsIG9uTWVzc2FnZSwgewogICAgICAgICAgICAgICAgcGFzc2l2ZTogdHJ1ZQogICAgICAgICAgICB9KTsKICAgICAgICAgICAgc29ja2V0LmFkZEV2ZW50TGlzdGVuZXIoImNsb3NlIiwgb25DbG9zZSwgewogICAgICAgICAgICAgICAgcGFzc2l2ZTogdHJ1ZQogICAgICAgICAgICB9KTsKICAgICAgICAgICAgc29ja2V0LmFkZEV2ZW50TGlzdGVuZXIoImVycm9yIiwgb25FcnJvciwgewogICAgICAgICAgICAgICAgcGFzc2l2ZTogdHJ1ZQogICAgICAgICAgICB9KTsKICAgICAgICAgICAgc2lnbmFsLmFkZEV2ZW50TGlzdGVuZXIoImFib3J0Iiwgb25BYm9ydCwgewogICAgICAgICAgICAgICAgcGFzc2l2ZTogdHJ1ZQogICAgICAgICAgICB9KTsKICAgICAgICAgICAgcmV0dXJuIGF3YWl0IGZ1dHVyZS5wcm9taXNlOwogICAgICAgIH0gZmluYWxseXsKICAgICAgICAgICAgc29ja2V0LnJlbW92ZUV2ZW50TGlzdGVuZXIoIm1lc3NhZ2UiLCBvbk1lc3NhZ2UpOwogICAgICAgICAgICBzb2NrZXQucmVtb3ZlRXZlbnRMaXN0ZW5lcigiY2xvc2UiLCBvbkNsb3NlKTsKICAgICAgICAgICAgc29ja2V0LnJlbW92ZUV2ZW50TGlzdGVuZXIoImVycm9yIiwgb25FcnJvcik7CiAgICAgICAgICAgIHNpZ25hbC5yZW1vdmVFdmVudExpc3RlbmVyKCJhYm9ydCIsIG9uQWJvcnQpOwogICAgICAgIH0KICAgIH0KICAgIFJwYy50cnlGZXRjaFdpdGhTb2NrZXQgPSB0cnlGZXRjaFdpdGhTb2NrZXQ7Cn0pKFJwYyB8fCAoUnBjID0ge30pKTsKCjsvLyBDT05DQVRFTkFURUQgTU9EVUxFOiAuL3NyYy9saWJzL3JwYy9pbmRleC50cwoKCgoKCgo7Ly8gQ09OQ0FURU5BVEVEIE1PRFVMRTogLi9zcmMvbW9kcy9iYWNrZ3JvdW5kL2luamVjdGVkX3NjcmlwdC9pbmRleC50cwoKCgoKCnZhciBfY2xpZW50ID0gLyojX19QVVJFX18qLyBuZXcgV2Vha01hcCgpLCBfbGlzdGVuZXJzID0gLyojX19QVVJFX18qLyBuZXcgV2Vha01hcCgpOwpjbGFzcyBQcm92aWRlciB7CiAgICBnZXQgaXNCcnVtZSgpIHsKICAgICAgICByZXR1cm4gdHJ1ZTsKICAgIH0KICAgIGlzQ29ubmVjdGVkKCkgewogICAgICAgIHJldHVybiB0cnVlOwogICAgfQogICAgYXN5bmMgcmVxdWVzdChpbml0KSB7CiAgICAgICAgY29uc3QgcmVxdWVzdCA9IF9jbGFzc19wcml2YXRlX2ZpZWxkX2dldCh0aGlzLCBfY2xpZW50KS5jcmVhdGUoaW5pdCk7CiAgICAgICAgY29uc3QgZnV0dXJlID0gbmV3IEZ1dHVyZSgpOwogICAgICAgIGNvbnN0IG9uUmVzcG9uc2UgPSAoZSk9PnsKICAgICAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBKU09OLnBhcnNlKGUuZGV0YWlsKTsKICAgICAgICAgICAgaWYgKHJlcXVlc3QuaWQgIT09IHJlc3BvbnNlLmlkKSByZXR1cm47CiAgICAgICAgICAgIGlmICgiZXJyb3IiIGluIHJlc3BvbnNlKSBmdXR1cmUucmVqZWN0KHJlc3BvbnNlLmVycm9yKTsKICAgICAgICAgICAgZWxzZSBmdXR1cmUucmVzb2x2ZShyZXNwb25zZS5yZXN1bHQpOwogICAgICAgIH07CiAgICAgICAgdHJ5IHsKICAgICAgICAgICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoImV0aGVyZXVtI3Jlc3BvbnNlIiwgb25SZXNwb25zZSk7CiAgICAgICAgICAgIGNvbnN0IGRldGFpbCA9IEpTT04uc3RyaW5naWZ5KHJlcXVlc3QpOwogICAgICAgICAgICBjb25zdCBldmVudCA9IG5ldyBDdXN0b21FdmVudCgiZXRoZXJldW0jcmVxdWVzdCIsIHsKICAgICAgICAgICAgICAgIGRldGFpbAogICAgICAgICAgICB9KTsKICAgICAgICAgICAgd2luZG93LmRpc3BhdGNoRXZlbnQoZXZlbnQpOwogICAgICAgICAgICByZXR1cm4gYXdhaXQgZnV0dXJlLnByb21pc2U7CiAgICAgICAgfSBmaW5hbGx5ewogICAgICAgICAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcigiZXRoZXJldW0jcmVzcG9uc2UiLCBvblJlc3BvbnNlKTsKICAgICAgICB9CiAgICB9CiAgICBvbihrZXksIHN1Ymxpc3RlbmVyKSB7CiAgICAgICAgbGV0IGxpc3RlbmVycyA9IF9jbGFzc19wcml2YXRlX2ZpZWxkX2dldCh0aGlzLCBfbGlzdGVuZXJzKS5nZXQoa2V5KTsKICAgICAgICBpZiAobGlzdGVuZXJzID09IG51bGwpIHsKICAgICAgICAgICAgbGlzdGVuZXJzID0gbmV3IE1hcCgpOwogICAgICAgICAgICBfY2xhc3NfcHJpdmF0ZV9maWVsZF9nZXQodGhpcywgX2xpc3RlbmVycykuc2V0KGtleSwgbGlzdGVuZXJzKTsKICAgICAgICB9CiAgICAgICAgbGV0IHN1cGxpc3RlbmVyID0gbGlzdGVuZXJzLmdldChzdWJsaXN0ZW5lcik7CiAgICAgICAgaWYgKHN1cGxpc3RlbmVyID09IG51bGwpIHsKICAgICAgICAgICAgc3VwbGlzdGVuZXIgPSAoZSk9PnZvaWQgc3VibGlzdGVuZXIoSlNPTi5wYXJzZShlLmRldGFpbCkpOwogICAgICAgICAgICBsaXN0ZW5lcnMuc2V0KHN1Ymxpc3RlbmVyLCBzdXBsaXN0ZW5lcik7CiAgICAgICAgfQogICAgICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCJldGhlcmV1bSMiLmNvbmNhdChrZXkpLCBzdXBsaXN0ZW5lciwgewogICAgICAgICAgICBwYXNzaXZlOiB0cnVlCiAgICAgICAgfSk7CiAgICB9CiAgICBvZmYoa2V5LCBzdWJsaXN0ZW5lcikgewogICAgICAgIGNvbnN0IGxpc3RlbmVycyA9IF9jbGFzc19wcml2YXRlX2ZpZWxkX2dldCh0aGlzLCBfbGlzdGVuZXJzKS5nZXQoa2V5KTsKICAgICAgICBpZiAobGlzdGVuZXJzID09IG51bGwpIHJldHVybjsKICAgICAgICBjb25zdCBzdXBsaXN0ZW5lciA9IGxpc3RlbmVycy5nZXQoc3VibGlzdGVuZXIpOwogICAgICAgIGlmIChzdXBsaXN0ZW5lciA9PSBudWxsKSByZXR1cm47CiAgICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoImV0aGVyZXVtIyIuY29uY2F0KGtleSksIHN1cGxpc3RlbmVyKTsKICAgICAgICBsaXN0ZW5lcnMuZGVsZXRlKHN1Ymxpc3RlbmVyKTsKICAgICAgICBpZiAobGlzdGVuZXJzLnNpemUgIT09IDApIHJldHVybjsKICAgICAgICBfY2xhc3NfcHJpdmF0ZV9maWVsZF9nZXQodGhpcywgX2xpc3RlbmVycykuZGVsZXRlKGtleSk7CiAgICB9CiAgICBjb25zdHJ1Y3RvcigpewogICAgICAgIF9jbGFzc19wcml2YXRlX2ZpZWxkX2luaXQodGhpcywgX2NsaWVudCwgewogICAgICAgICAgICB3cml0YWJsZTogdHJ1ZSwKICAgICAgICAgICAgdmFsdWU6IHZvaWQgMAogICAgICAgIH0pOwogICAgICAgIF9jbGFzc19wcml2YXRlX2ZpZWxkX2luaXQodGhpcywgX2xpc3RlbmVycywgewogICAgICAgICAgICB3cml0YWJsZTogdHJ1ZSwKICAgICAgICAgICAgdmFsdWU6IHZvaWQgMAogICAgICAgIH0pOwogICAgICAgIF9jbGFzc19wcml2YXRlX2ZpZWxkX3NldCh0aGlzLCBfY2xpZW50LCBuZXcgUnBjQ2xpZW50KCkpOwogICAgICAgIF9jbGFzc19wcml2YXRlX2ZpZWxkX3NldCh0aGlzLCBfbGlzdGVuZXJzLCBuZXcgTWFwKCkpOwogICAgfQp9CndpbmRvdy5ldGhlcmV1bSA9IG5ldyBQcm92aWRlcigpOwoKLyoqKioqKi8gfSkoKQo7");
    const scriptUrl = browser.runtime.getURL("injected_script.js");
    const element = document.createElement("script");
    element.type = "text/javascript";
    element.textContent = "".concat(scriptBody, "\n//# sourceURL=").concat(scriptUrl);
    container.insertBefore(element, container.children[0]);
    container.removeChild(element);
}
new Pool(async (params)=>{
    return Result.unthrow(async (t)=>{
        const { index, pool } = params;
        await new Promise((ok)=>setTimeout(ok, 1));
        const raw = await tryBrowser(async ()=>{
            const port = browser.runtime.connect({
                name: location.origin
            });
            port.onDisconnect.addListener(()=>void chrome.runtime.lastError);
            return port;
        }).then((r)=>r.throw(t));
        const port = new ExtensionPort("background", raw);
        const onScriptRequest = async (input)=>{
            const request = JSON.parse(input.detail);
            const result = await port.tryRequest({
                method: "brume_mouse",
                params: [
                    request,
                    mouse
                ]
            });
            const response = result.unwrapOrElseSync((e)=>response_RpcResponse.rewrap(request.id, new err_Err(e)));
            const detail = JSON.stringify(response);
            const output = new CustomEvent("ethereum#response", {
                detail
            });
            window.dispatchEvent(output);
        };
        window.addEventListener("ethereum#request", onScriptRequest, {
            passive: true
        });
        const onAccountsChanged = async (request)=>{
            const [accounts] = request.params;
            const detail = JSON.stringify(accounts);
            const output = new CustomEvent("ethereum#accountsChanged", {
                detail
            });
            window.dispatchEvent(output);
            return ok_Ok.void();
        };
        const onChainChanged = async (request)=>{
            const [chainId] = request.params;
            const detail = JSON.stringify(chainId);
            const output = new CustomEvent("ethereum#chainChanged", {
                detail
            });
            window.dispatchEvent(output);
            return ok_Ok.void();
        };
        const onBackgroundRequest = async (request)=>{
            if (request.method === "accountsChanged") return new some_Some(await onAccountsChanged(request));
            if (request.method === "chainChanged") return new some_Some(await onChainChanged(request));
            return new none_None();
        };
        port.events.on("request", onBackgroundRequest, {
            passive: true
        });
        const onClose = ()=>{
            pool.delete(index);
            return new none_None();
        };
        port.events.on("close", onClose, {
            passive: true
        });
        const onClean = ()=>{
            window.removeEventListener("ethereum#request", onScriptRequest);
            port.events.off("close", onClose);
            port.clean();
            raw.disconnect();
        };
        return new ok_Ok(new cleaner_Cleaner(raw, onClean));
    });
}, {
    capacity: 1
});

/******/ })()
;