"use strict";
(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[989],{

/***/ 4811:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  DonePage: function() { return /* binding */ DonePage; },
  PersonalSignPage: function() { return /* binding */ PersonalSignPage; },
  TransactPage: function() { return /* binding */ TransactPage; },
  TypedSignPage: function() { return /* binding */ TypedSignPage; },
  WalletAndChainSelectPage: function() { return /* binding */ WalletAndChainSelectPage; },
  "default": function() { return /* binding */ Popup; }
});

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
// EXTERNAL MODULE: ./src/libs/errors/errors.ts
var errors = __webpack_require__(783);
// EXTERNAL MODULE: ./src/libs/ethereum/mods/chain.tsx
var chain = __webpack_require__(3411);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/XMarkIcon.js
var XMarkIcon = __webpack_require__(9005);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/CheckIcon.js
var CheckIcon = __webpack_require__(2506);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/PlusIcon.js
var PlusIcon = __webpack_require__(8105);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/HomeIcon.js
var HomeIcon = __webpack_require__(4201);
// EXTERNAL MODULE: ./src/libs/react/callback.tsx
var callback = __webpack_require__(2702);
// EXTERNAL MODULE: ./src/libs/react/events.ts
var events = __webpack_require__(904);
// EXTERNAL MODULE: ./src/libs/ui/dialog/dialog.tsx
var dialog = __webpack_require__(6202);
// EXTERNAL MODULE: ./src/libs/ui2/menu/menu.tsx
var menu = __webpack_require__(5857);
// EXTERNAL MODULE: ./src/libs/ui2/page/header.tsx
var header = __webpack_require__(7480);
// EXTERNAL MODULE: ./src/libs/ui2/page/page.tsx
var page = __webpack_require__(6698);
// EXTERNAL MODULE: ./src/libs/url/url.ts
var url = __webpack_require__(445);
// EXTERNAL MODULE: ./src/mods/foreground/background/context.tsx + 4 modules
var context = __webpack_require__(3891);
// EXTERNAL MODULE: ./src/mods/foreground/entities/requests/data.tsx + 1 modules
var data = __webpack_require__(6361);
// EXTERNAL MODULE: ./src/libs/maps/maps.ts
var maps = __webpack_require__(5416);
// EXTERNAL MODULE: ./src/libs/rpc/rpc.ts + 136 modules
var rpc = __webpack_require__(7073);
// EXTERNAL MODULE: ./src/libs/signals/signals.ts
var signals = __webpack_require__(1100);
// EXTERNAL MODULE: ./src/libs/uuid/uuid.ts
var uuid = __webpack_require__(6655);
// EXTERNAL MODULE: ./node_modules/@hazae41/arrays/dist/esm/mods/arrays/arrays.mjs
var arrays = __webpack_require__(9408);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/fetched/fetched.mjs
var fetched = __webpack_require__(1458);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/fetched/fail.mjs
var fail = __webpack_require__(9164);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/queries/simple/query.mjs
var query = __webpack_require__(6233);
// EXTERNAL MODULE: ./node_modules/@hazae41/jsonrpc/dist/esm/mods/rpc/rpc.mjs
var rpc_rpc = __webpack_require__(3954);
// EXTERNAL MODULE: ./node_modules/@hazae41/network-bundle/dist/esm/src/node/mods/index.mjs + 1 modules
var mods = __webpack_require__(9354);
// EXTERNAL MODULE: ./node_modules/@hazae41/network-bundle/dist/esm/wasm/pkg/bundle.mjs
var bundle = __webpack_require__(4486);
// EXTERNAL MODULE: ./node_modules/@hazae41/option/dist/esm/mods/option/option.mjs
var option_option = __webpack_require__(5316);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/errors.mjs
var result_errors = __webpack_require__(2564);
;// CONCATENATED MODULE: ./src/mods/background/service_worker/entities/simulations/data.ts










var BgSimulation;
(function(BgSimulation) {
    async function generateOrThrow(params) {
        const { chainIdString, contractZeroHex, receiverZeroHex, nonceZeroHex, minimumZeroHex } = params;
        await (0,mods/* initBundledOnce */.LA)();
        const chainIdBase16 = Number(chainIdString).toString(16).padStart(64, "0");
        const chainIdMemory = (0,bundle/* base16_decode_mixed */.NX)(chainIdBase16);
        const contractBase16 = contractZeroHex.slice(2).padStart(64, "0");
        const contractMemory = (0,bundle/* base16_decode_mixed */.NX)(contractBase16);
        const receiverBase16 = receiverZeroHex.slice(2).padStart(64, "0");
        const receiverMemory = (0,bundle/* base16_decode_mixed */.NX)(receiverBase16);
        const nonceBase16 = nonceZeroHex.slice(2).padStart(64, "0");
        const nonceMemory = (0,bundle/* base16_decode_mixed */.NX)(nonceBase16);
        const mixinStruct = new bundle/* NetworkMixin */.jh(chainIdMemory, contractMemory, receiverMemory, nonceMemory);
        const minimumBase16 = minimumZeroHex.slice(2).padStart(64, "0");
        const minimumMemory = (0,bundle/* base16_decode_mixed */.NX)(minimumBase16);
        const generatedStruct = mixinStruct.generate(minimumMemory);
        const secretMemory = generatedStruct.to_secret();
        const secretBase16 = (0,bundle/* base16_encode_lower */.Aj)(secretMemory);
        const secretZeroHex = "0x".concat(secretBase16);
        return secretZeroHex;
    }
    async function fetchOrFail(ethereum, init) {
        let more = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
        try {
            const { signal: parentSignal } = more;
            const { brume } = ethereum;
            const circuits = brume.circuits;
            async function runWithCircuitOrThrow(index) {
                const circuitSignal = signals/* AbortSignals */.f.timeout(5000, parentSignal);
                const circuit = await circuits.tryGet(index, circuitSignal).then((r)=>r.unwrap().unwrap().inner.inner);
                const session = (0,uuid/* randomUUID */.H)();
                const url = new URL("https://signal.node0.hazae41.me");
                url.searchParams.set("session", session);
                const params = await rpc/* TorRpc */.H.fetchWithCircuitOrThrow(url, {
                    circuit,
                    signal: signals/* AbortSignals */.f.timeout(10000, parentSignal),
                    ...new rpc_rpc/* RpcCounter */.n().prepare({
                        method: "net_get"
                    })
                }).then((r)=>r.unwrap());
                const secret = await generateOrThrow(params);
                await rpc/* TorRpc */.H.fetchWithCircuitOrThrow(url, {
                    circuit,
                    signal: signals/* AbortSignals */.f.timeout(10000, parentSignal),
                    ...new rpc_rpc/* RpcCounter */.n().prepare({
                        method: "net_tip",
                        params: [
                            secret
                        ]
                    })
                }).then((r)=>r.unwrap());
                const nodes = await rpc/* TorRpc */.H.fetchWithCircuitOrThrow(url, {
                    circuit,
                    signal: signals/* AbortSignals */.f.timeout(10000, parentSignal),
                    ...new rpc_rpc/* RpcCounter */.n().prepare({
                        method: "net_search",
                        params: [
                            {},
                            {
                                protocols: [
                                    "https:json-rpc:(pay-by-char|tenderly:".concat(ethereum.chain.chainId, ")")
                                ]
                            }
                        ]
                    })
                }).then((r)=>r.unwrap());
                const node = arrays/* cryptoRandom */.vk(nodes);
                if (node == null) throw new Error("No node found for ".concat(ethereum.chain.name));
                {
                    const url = new URL("".concat(node.location));
                    url.searchParams.set("session", session);
                    const params = await rpc/* TorRpc */.H.fetchWithCircuitOrThrow(url, {
                        circuit,
                        signal: signals/* AbortSignals */.f.timeout(10000, parentSignal),
                        ...new rpc_rpc/* RpcCounter */.n().prepare({
                            method: "net_get"
                        })
                    }).then((r)=>r.unwrap());
                    const secret = await generateOrThrow(params);
                    await rpc/* TorRpc */.H.fetchWithCircuitOrThrow(url, {
                        circuit,
                        signal: signals/* AbortSignals */.f.timeout(10000, parentSignal),
                        ...new rpc_rpc/* RpcCounter */.n().prepare({
                            method: "net_tip",
                            params: [
                                secret
                            ]
                        })
                    }).then((r)=>r.unwrap());
                    return await rpc/* TorRpc */.H.fetchWithCircuitOrThrow(url, {
                        circuit,
                        signal: signals/* AbortSignals */.f.timeout(10000, parentSignal),
                        ...new rpc_rpc/* RpcCounter */.n().prepare(init)
                    }).then((r)=>fetched/* Fetched */.F.rewrap(r));
                }
            }
            const random = await circuits.getCryptoRandomOrThrow();
            const promises = [
                runWithCircuitOrThrow(random.index)
            ];
            const results = await Promise.allSettled(promises);
            const fetcheds = new Map();
            const counters = new Map();
            for (const result of results){
                if (result.status === "rejected") continue;
                if (result.value.isErr()) continue;
                if (init === null || init === void 0 ? void 0 : init.noCheck) return result.value;
                const raw = JSON.stringify(result.value.inner);
                const previous = option_option/* Option */.W.wrap(counters.get(raw)).unwrapOr(0);
                counters.set(raw, previous + 1);
                fetcheds.set(raw, result.value);
            }
            /**
             * One truth -> return it
             * Zero truth -> throw AggregateError
             */ if (counters.size < 2) return await Promise.any(promises);
            console.warn("Different results from multiple circuits for ".concat(init.method, " on ").concat(ethereum.chain.name), {
                fetcheds
            });
            /**
             * Sort truths by occurence
             */ const sorteds = [
                ...maps/* Maps */.o.entries(counters)
            ].sort((a, b)=>b.value - a.value);
            /**
             * Two concurrent truths
             */ if (sorteds[0].value === sorteds[1].value) {
                console.warn("Could not choose truth for ".concat(init.method, " on ").concat(ethereum.chain.name));
                const random = Math.round(Math.random());
                return fetcheds.get(sorteds[random].key);
            }
            return fetcheds.get(sorteds[0].key);
        } catch (e) {
            return new fail/* Fail */.M(result_errors/* Catched */.$.wrap(e));
        }
    }
    BgSimulation.fetchOrFail = fetchOrFail;
    BgSimulation.method = "tenderly_simulateTransaction";
    function key(chainId, tx, block) {
        return {
            chainId,
            method: BgSimulation.method,
            params: [
                tx,
                block
            ],
            noCheck: true
        };
    }
    BgSimulation.key = key;
    async function parseOrThrow(ethereum, request, storage) {
        const [tx, block] = request.params;
        return schema(ethereum, tx, block, storage);
    }
    BgSimulation.parseOrThrow = parseOrThrow;
    function schema(ethereum, tx, block, storage) {
        const fetcher = async (request, more)=>await fetchOrFail(ethereum, request, more).then((r)=>r.inspectErrSync((e)=>console.error({
                        e
                    })));
        return (0,query/* createQuery */.rP)({
            key: key(ethereum.chain.chainId, tx, block),
            fetcher,
            storage
        });
    }
    BgSimulation.schema = schema;
})(BgSimulation || (BgSimulation = {}));

// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/react/hooks/queries/simple.mjs + 1 modules
var simple = __webpack_require__(564);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/react/hooks/blocks/use-fetch.mjs
var use_fetch = __webpack_require__(4704);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/react/hooks/blocks/use-error.mjs
var use_error = __webpack_require__(3399);
// EXTERNAL MODULE: ./src/mods/foreground/storage/user.tsx
var user = __webpack_require__(2536);
// EXTERNAL MODULE: ./src/mods/foreground/entities/wallets/data.ts
var wallets_data = __webpack_require__(4844);
;// CONCATENATED MODULE: ./src/mods/foreground/entities/simulations/data.ts





var FgSimulation;
(function(FgSimulation) {
    FgSimulation.key = BgSimulation.key;
    function schema(tx, block, context, storage) {
        if (context == null) return;
        if (tx == null) return;
        if (block == null) return;
        const fetcher = async (request)=>await (0,wallets_data/* customFetchOrFail */.Ky)(request, context);
        return (0,query/* createQuery */.rP)({
            key: FgSimulation.key(context.chain.chainId, tx, block),
            fetcher,
            storage
        });
    }
    FgSimulation.schema = schema;
})(FgSimulation || (FgSimulation = {}));
function useSimulation(tx, block, context) {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(FgSimulation.schema, [
        tx,
        block,
        context,
        storage
    ]);
    (0,use_fetch/* useFetch */.i)(query);
    (0,use_error/* useError */.V)(query, errors/* Errors */.D.onQueryError);
    return query;
}

// EXTERNAL MODULE: ./src/mods/foreground/entities/transactions/data.ts + 1 modules
var transactions_data = __webpack_require__(408);
// EXTERNAL MODULE: ./src/mods/foreground/entities/users/all/page.tsx + 18 modules
var all_page = __webpack_require__(4190);
// EXTERNAL MODULE: ./src/mods/foreground/entities/wallets/actions/eth_sendTransaction/index.tsx + 6 modules
var eth_sendTransaction = __webpack_require__(6388);
// EXTERNAL MODULE: ./src/mods/foreground/entities/wallets/actions/send/index.tsx + 9 modules
var send = __webpack_require__(8856);
// EXTERNAL MODULE: ./src/mods/foreground/entities/wallets/all/create/index.tsx
var create = __webpack_require__(7309);
// EXTERNAL MODULE: ./src/mods/foreground/entities/wallets/all/create/readonly.tsx
var readonly = __webpack_require__(1286);
// EXTERNAL MODULE: ./src/mods/foreground/entities/wallets/all/create/standalone.tsx
var standalone = __webpack_require__(4925);
// EXTERNAL MODULE: ./src/mods/foreground/entities/wallets/all/page.tsx
var wallets_all_page = __webpack_require__(5750);
// EXTERNAL MODULE: ./src/mods/foreground/entities/wallets/context.tsx
var wallets_context = __webpack_require__(3291);
// EXTERNAL MODULE: ./src/mods/foreground/errors/errors.ts
var errors_errors = __webpack_require__(8350);
// EXTERNAL MODULE: ./src/mods/foreground/overlay/navbar.tsx
var navbar = __webpack_require__(9295);
// EXTERNAL MODULE: ./src/mods/foreground/overlay/overlay.tsx + 2 modules
var overlay = __webpack_require__(690);
// EXTERNAL MODULE: ./src/mods/foreground/router/path/context.tsx
var path_context = __webpack_require__(9046);
// EXTERNAL MODULE: ./src/mods/foreground/router/router.tsx + 34 modules
var router = __webpack_require__(3068);
// EXTERNAL MODULE: ./node_modules/@hazae41/base16/dist/esm/src/mods/base16/adapter.mjs
var adapter = __webpack_require__(2248);
// EXTERNAL MODULE: ./node_modules/@hazae41/bytes/dist/esm/mods/bytes/bytes.mjs + 3 modules
var bytes = __webpack_require__(1694);
// EXTERNAL MODULE: ./node_modules/@hazae41/jsonrpc/dist/esm/mods/rpc/ok.mjs
var ok = __webpack_require__(1752);
// EXTERNAL MODULE: ./node_modules/@hazae41/jsonrpc/dist/esm/mods/rpc/err.mjs
var err = __webpack_require__(667);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/err.mjs
var result_err = __webpack_require__(166);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/result.mjs
var result = __webpack_require__(918);
// EXTERNAL MODULE: ./node_modules/react/index.js
var react = __webpack_require__(7294);
;// CONCATENATED MODULE: ./pages/popup.tsx



































function Popup() {
    const background = (0,context/* useBackgroundContext */.D_)().unwrap();
    (0,react.useEffect)(()=>{
        background.requestOrThrow({
            method: "popup_hello"
        }).then((r)=>r.unwrap());
    }, [
        background
    ]);
    const [loading, setLoading] = (0,react.useState)(false);
    (0,react.useMemo)(()=>{
        if (location.hash !== "") return;
        background.requestOrThrow({
            method: "brume_getPath"
        }).then((r)=>{
            location.hash = r.unwrap();
            setLoading(false);
        });
        setLoading(true);
    }, [
        background
    ]);
    (0,react.useEffect)(()=>{
        const onHashChange = ()=>void background.requestOrThrow({
                method: "brume_setPath",
                params: [
                    location.hash
                ]
            }).then((r)=>r.unwrap());
        addEventListener("hashchange", onHashChange, {
            passive: true
        });
        return ()=>removeEventListener("hashchange", onHashChange);
    }, [
        background
    ]);
    if (loading) return null;
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("main", {
        id: "main",
        className: "p-safe h-full w-full flex flex-col overflow-hidden",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(navbar/* NavBar */.l, {}),
            /*#__PURE__*/ (0,jsx_runtime.jsx)(overlay/* Overlay */.aV, {
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(router/* Router */.F, {})
            })
        ]
    });
}
function TransactPage() {
    var _walletQuery_current, _trialQuery_current, _transactionQuery_current;
    const path = (0,path_context/* usePathContext */.td)().unwrap();
    const background = (0,context/* useBackgroundContext */.D_)().unwrap();
    const subpath = (0,path_context/* useHashSubpath */.IL)(path);
    const id = option_option/* Option */.W.unwrap(path.url.searchParams.get("id"));
    const walletId = option_option/* Option */.W.unwrap(path.url.searchParams.get("walletId"));
    const walletQuery = (0,wallets_data/* useWallet */.Os)(walletId);
    const maybeWallet = (_walletQuery_current = walletQuery.current) === null || _walletQuery_current === void 0 ? void 0 : _walletQuery_current.ok().get();
    const chainId = option_option/* Option */.W.unwrap(path.url.searchParams.get("chainId"));
    const chainData = option_option/* Option */.W.unwrap(chain/* chainDataByChainId */.wz[Number(chainId)]);
    const maybeContext = (0,wallets_data/* useEthereumContext2 */.IL)(maybeWallet === null || maybeWallet === void 0 ? void 0 : maybeWallet.uuid, chainData).get();
    const from = option_option/* Option */.W.unwrap(path.url.searchParams.get("from"));
    const maybeTo = path.url.searchParams.get("to");
    const maybeGas = path.url.searchParams.get("gas");
    const maybeValue = path.url.searchParams.get("value");
    const maybeNonce = path.url.searchParams.get("nonce");
    const maybeData = path.url.searchParams.get("data");
    const maybeGasPrice = path.url.searchParams.get("gasPrice");
    const maybeMaxFeePerGas = path.url.searchParams.get("maxFeePerGas");
    const maybeMaxPriorityFeePerGas = path.url.searchParams.get("maxPriorityFeePerGas");
    const trialQuery = (0,transactions_data/* useTransactionTrial */.pC)(id);
    const maybeTrialData = (_trialQuery_current = trialQuery.current) === null || _trialQuery_current === void 0 ? void 0 : _trialQuery_current.ok().get();
    const transactionQuery = (0,transactions_data/* useTransactionWithReceipt */.Fx)(maybeTrialData === null || maybeTrialData === void 0 ? void 0 : maybeTrialData.transactions[0].uuid, maybeContext);
    const maybeTransaction = (_transactionQuery_current = transactionQuery.current) === null || _transactionQuery_current === void 0 ? void 0 : _transactionQuery_current.ok().get();
    const preTx = (0,react.useMemo)(()=>{
        return {
            from: from,
            to: maybeTo,
            gas: maybeGas,
            value: maybeValue,
            data: maybeData,
            nonce: maybeNonce,
            gasPrice: maybeGasPrice,
            maxFeePerGas: maybeMaxFeePerGas,
            maxPriorityFeePerGas: maybeMaxPriorityFeePerGas
        };
    }, [
        from,
        maybeTo,
        maybeValue,
        maybeNonce,
        maybeData,
        maybeGas,
        maybeGasPrice,
        maybeMaxFeePerGas,
        maybeMaxPriorityFeePerGas
    ]);
    const simulationQuery = useSimulation(preTx, "pending", maybeContext);
    const currentSimulation = simulationQuery.current;
    const approveOrAlert = (0,callback/* useAsyncUniqueCallback */.T)(()=>errors/* Errors */.D.runAndLogAndAlert(async ()=>{
            const transaction = option_option/* Option */.W.unwrap(maybeTransaction);
            await background.requestOrThrow({
                method: "brume_respond",
                params: [
                    new ok/* RpcOk */.r(id, transaction.hash)
                ]
            }).then((r)=>r.unwrap());
            location.replace(path.go("/done"));
        }), [
        background,
        id,
        path,
        maybeTransaction
    ]);
    const rejectOrAlert = (0,callback/* useAsyncUniqueCallback */.T)(()=>errors/* Errors */.D.runAndLogAndAlert(async ()=>{
            await background.requestOrThrow({
                method: "brume_respond",
                params: [
                    err/* RpcErr */.s6.rewrap(id, new result_err/* Err */.U(new errors_errors/* UserRejectedError */.Ai()))
                ]
            }).then((r)=>r.unwrap());
            location.replace(path.go("/done"));
        }), [
        background,
        id,
        path
    ]);
    const onSendTransactionClick = (0,react.useCallback)(()=>{
        location.replace(subpath.go((0,url/* qurl */.d)("/eth_sendTransaction", {
            trial: id,
            chain: chainId,
            target: maybeTo,
            value: maybeValue,
            nonce: maybeNonce,
            data: maybeData,
            gas: maybeGas,
            gasMode: "custom",
            gasPrice: maybeGasPrice,
            maxFeePerGas: maybeMaxFeePerGas,
            maxPriorityFeePerGas: maybeMaxPriorityFeePerGas,
            disableData: true,
            disableSign: true
        })));
    }, [
        subpath,
        id,
        chainId,
        maybeTo,
        maybeValue,
        maybeNonce,
        maybeData,
        maybeGas,
        maybeGasPrice,
        maybeMaxFeePerGas,
        maybeMaxPriorityFeePerGas
    ]);
    (0,react.useEffect)(()=>{
        if (maybeTransaction == null) return;
        approveOrAlert.run();
    }, [
        maybeTransaction,
        approveOrAlert
    ]);
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(wallets_context/* WalletDataContext */.qM.Provider, {
        value: maybeWallet,
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)(page/* Page */.T, {
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsx)(path_context/* HashSubpathProvider */.qd, {
                    children: subpath.url.pathname === "/eth_sendTransaction" && /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Dialog2 */.gP, {
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(eth_sendTransaction/* WalletTransactionDialog */.Ul, {})
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsxs)(header/* PageBody */.xV, {
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Dialog */.Vq.Title, {
                            children: "Transaction"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "h-2"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "text-contrast",
                            children: "Do you want to send the following transaction?"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "h-4"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "font-medium",
                            children: "Transaction"
                        }),
                        preTx.from && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    className: "h-2"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)(send/* SimpleLabel */.JJ, {
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                            className: "shrink-0",
                                            children: "From"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                            className: "w-4"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)(send/* SimpleInput */.Jc, {
                                            readOnly: true,
                                            value: preTx.from
                                        })
                                    ]
                                })
                            ]
                        }),
                        preTx.to && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    className: "h-2"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)(send/* SimpleLabel */.JJ, {
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                            className: "shrink-0",
                                            children: "To"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                            className: "w-4"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)(send/* SimpleInput */.Jc, {
                                            readOnly: true,
                                            value: preTx.to
                                        })
                                    ]
                                })
                            ]
                        }),
                        preTx.value && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    className: "h-2"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)(send/* SimpleLabel */.JJ, {
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                            className: "shrink-0",
                                            children: "Value"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                            className: "w-4"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)(send/* SimpleInput */.Jc, {
                                            readOnly: true,
                                            value: preTx.value
                                        })
                                    ]
                                })
                            ]
                        }),
                        preTx.nonce && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    className: "h-2"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)(send/* SimpleLabel */.JJ, {
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                            className: "shrink-0",
                                            children: "Nonce"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                            className: "w-4"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)(send/* SimpleInput */.Jc, {
                                            readOnly: true,
                                            value: preTx.nonce
                                        })
                                    ]
                                })
                            ]
                        }),
                        preTx.data && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    className: "h-2"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)(send/* SimpleLabel */.JJ, {
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                            className: "shrink-0",
                                            children: "Data"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                            className: "w-4"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)(send/* SimpleTextarea */.pm, {
                                            readOnly: true,
                                            rows: 3,
                                            value: preTx.data
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "h-4"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "font-medium",
                            children: "Simulation"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "text-contrast",
                            children: "The simulation logs are a preview of the transaction execution on the blockchain."
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "h-2"
                        }),
                        currentSimulation == null && /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "text-contrast",
                            children: "Loading..."
                        }),
                        (currentSimulation === null || currentSimulation === void 0 ? void 0 : currentSimulation.isErr()) && /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "text-red-400 dark:text-red-500",
                            children: currentSimulation.getErr().message
                        }),
                        (currentSimulation === null || currentSimulation === void 0 ? void 0 : currentSimulation.isOk()) && /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "flex flex-col gap-2",
                            children: currentSimulation.get().logs.map((log, i)=>/*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: "p-2 bg-contrast rounded-xl",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                            className: "font-medium",
                                            children: log.name
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                            className: "text-contrast truncate",
                                            children: log.raw.address
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                            className: "h-2"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                            className: "flex flex-col gap-2",
                                            children: log.inputs.map((input, j)=>/*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                    className: "p-2 bg-contrast rounded-xl",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                            className: "font-medium",
                                                            children: [
                                                                input.name,
                                                                " ",
                                                                input.type
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                                            className: "text-contrast truncate",
                                                            children: typeof input.value === "string" ? input.value : JSON.stringify(input.value)
                                                        })
                                                    ]
                                                }, j))
                                        })
                                    ]
                                }, i))
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "h-4 grow"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "flex items-center flex-wrap-reverse gap-2",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)(send/* WideShrinkableContrastButton */.pN, {
                                    onClick: rejectOrAlert.run,
                                    disabled: rejectOrAlert.loading,
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)(XMarkIcon/* default */.Z, {
                                            className: "size-5"
                                        }),
                                        "Reject"
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)(send/* WideShrinkableOppositeButton */.kd, {
                                    onClick: onSendTransactionClick,
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)(CheckIcon/* default */.Z, {
                                            className: "size-5"
                                        }),
                                        "Transact"
                                    ]
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
}
function PersonalSignPage() {
    var _walletQuery_current;
    const path = (0,path_context/* usePathContext */.td)().unwrap();
    const background = (0,context/* useBackgroundContext */.D_)().unwrap();
    const id = option_option/* Option */.W.unwrap(path.url.searchParams.get("id"));
    const walletId = option_option/* Option */.W.unwrap(path.url.searchParams.get("walletId"));
    const walletQuery = (0,wallets_data/* useWallet */.Os)(walletId);
    const maybeWallet = (_walletQuery_current = walletQuery.current) === null || _walletQuery_current === void 0 ? void 0 : _walletQuery_current.ok().get();
    const message = option_option/* Option */.W.unwrap(path.url.searchParams.get("message"));
    const triedUserMessage = (0,react.useMemo)(()=>result/* Result */.x.runAndWrapSync(()=>{
            return message.startsWith("0x") ? bytes/* Bytes */.J.toUtf8(adapter/* get */.U().padStartAndDecodeOrThrow(message.slice(2)).copyAndDispose()) : message;
        }), [
        message
    ]);
    const approveOrAlert = (0,callback/* useAsyncUniqueCallback */.T)(()=>errors/* Errors */.D.runAndLogAndAlert(async ()=>{
            const wallet = option_option/* Option */.W.unwrap(maybeWallet);
            const message = triedUserMessage.unwrap();
            const instance = await wallets_data/* EthereumWalletInstance */.Vy.tryFrom(wallet, background).then((r)=>r.unwrap());
            const signature = await instance.trySignPersonalMessage(message, background).then((r)=>r.unwrap());
            await background.requestOrThrow({
                method: "brume_respond",
                params: [
                    new ok/* RpcOk */.r(id, signature)
                ]
            }).then((r)=>r.unwrap());
            location.replace(path.go("/done"));
        }), [
        background,
        id,
        path,
        maybeWallet,
        triedUserMessage
    ]);
    const rejectOrAlert = (0,callback/* useAsyncUniqueCallback */.T)(()=>errors/* Errors */.D.runAndLogAndAlert(async ()=>{
            await background.requestOrThrow({
                method: "brume_respond",
                params: [
                    err/* RpcErr */.s6.rewrap(id, new result_err/* Err */.U(new errors_errors/* UserRejectedError */.Ai()))
                ]
            }).then((r)=>r.unwrap());
            location.replace(path.go("/done"));
        }), [
        background,
        id,
        path
    ]);
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(page/* Page */.T, {
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)(header/* PageBody */.xV, {
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Dialog */.Vq.Title, {
                    children: "Signature"
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "h-2"
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "text-contrast",
                    children: "Do you want to sign the following message?"
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "h-2"
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "text-contrast",
                    children: "Some applications may ask you to sign a message to prove you own a specific address or to approve a specific action without doing a transaction."
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "h-4"
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "grow p-4 bg-contrast rounded-xl whitespace-pre-wrap break-words",
                    children: triedUserMessage.unwrapOr("Could not decode message")
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "h-4 grow"
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                    className: "flex items-center flex-wrap-reverse gap-2",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime.jsxs)(send/* WideShrinkableContrastButton */.pN, {
                            onClick: rejectOrAlert.run,
                            disabled: rejectOrAlert.loading,
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)(XMarkIcon/* default */.Z, {
                                    className: "size-5"
                                }),
                                "Reject"
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsxs)(send/* WideShrinkableOppositeButton */.kd, {
                            onClick: approveOrAlert.run,
                            disabled: approveOrAlert.loading,
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)(CheckIcon/* default */.Z, {
                                    className: "size-5"
                                }),
                                "Approve"
                            ]
                        })
                    ]
                })
            ]
        })
    });
}
function TypedSignPage() {
    var _walletQuery_current;
    const path = (0,path_context/* usePathContext */.td)().unwrap();
    const background = (0,context/* useBackgroundContext */.D_)().unwrap();
    const id = option_option/* Option */.W.unwrap(path.url.searchParams.get("id"));
    const walletId = option_option/* Option */.W.unwrap(path.url.searchParams.get("walletId"));
    const walletQuery = (0,wallets_data/* useWallet */.Os)(walletId);
    const maybeWallet = (_walletQuery_current = walletQuery.current) === null || _walletQuery_current === void 0 ? void 0 : _walletQuery_current.ok().get();
    const data = option_option/* Option */.W.unwrap(path.url.searchParams.get("data"));
    const triedParsedData = (0,react.useMemo)(()=>result/* Result */.x.runAndWrapSync(()=>{
            return JSON.parse(data);
        }), [
        data
    ]);
    const approveOrAlert = (0,callback/* useAsyncUniqueCallback */.T)(()=>errors/* Errors */.D.runAndLogAndAlert(async ()=>{
            const wallet = option_option/* Option */.W.unwrap(maybeWallet);
            const data = triedParsedData.unwrap();
            const instance = await wallets_data/* EthereumWalletInstance */.Vy.tryFrom(wallet, background).then((r)=>r.unwrap());
            const signature = await instance.trySignEIP712HashedMessage(data, background).then((r)=>r.unwrap());
            await background.requestOrThrow({
                method: "brume_respond",
                params: [
                    new ok/* RpcOk */.r(id, signature)
                ]
            }).then((r)=>r.unwrap());
            location.replace(path.go("/done"));
        }), [
        background,
        id,
        path,
        maybeWallet,
        triedParsedData
    ]);
    const rejectOrAlert = (0,callback/* useAsyncUniqueCallback */.T)(()=>errors/* Errors */.D.runAndLogAndAlert(async ()=>{
            await background.requestOrThrow({
                method: "brume_respond",
                params: [
                    err/* RpcErr */.s6.rewrap(id, new result_err/* Err */.U(new errors_errors/* UserRejectedError */.Ai()))
                ]
            }).then((r)=>r.unwrap());
            location.replace(path.go("/done"));
        }), [
        background,
        id,
        path
    ]);
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(page/* Page */.T, {
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)(header/* PageBody */.xV, {
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Dialog */.Vq.Title, {
                    children: "Signature"
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "h-2"
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "text-contrast",
                    children: "Do you want to sign the following message?"
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "h-2"
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "text-contrast",
                    children: "Some applications may ask you to sign a message to prove you own a specific address or to approve a specific action without doing a transaction."
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "h-4"
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "grow p-4 bg-contrast rounded-xl whitespace-pre-wrap break-words",
                    children: triedParsedData.mapSync((x)=>JSON.stringify(x, undefined, 2)).unwrapOr("Could not decode message")
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "h-4 grow"
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                    className: "flex items-center flex-wrap-reverse gap-2",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime.jsxs)(send/* WideShrinkableContrastButton */.pN, {
                            onClick: rejectOrAlert.run,
                            disabled: rejectOrAlert.loading,
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)(XMarkIcon/* default */.Z, {
                                    className: "size-5"
                                }),
                                "Reject"
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsxs)(send/* WideShrinkableOppositeButton */.kd, {
                            onClick: approveOrAlert.run,
                            disabled: approveOrAlert.loading,
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)(CheckIcon/* default */.Z, {
                                    className: "size-5"
                                }),
                                "Approve"
                            ]
                        })
                    ]
                })
            ]
        })
    });
}
function WalletAndChainSelectPage() {
    var _wallets_data;
    const path = (0,path_context/* usePathContext */.td)().unwrap();
    const background = (0,context/* useBackgroundContext */.D_)().unwrap();
    const subpath = (0,path_context/* useHashSubpath */.IL)(path);
    const creator = (0,all_page/* useGenius */.y6)(subpath, "/create");
    const id = option_option/* Option */.W.unwrap(path.url.searchParams.get("id"));
    const wallets = (0,wallets_data/* useWallets */.rB)();
    const [persistent, setPersistent] = (0,react.useState)(true);
    const onPersistentChange = (0,events/* useInputChange */.Xy)((e)=>{
        setPersistent(e.currentTarget.checked);
    }, []);
    const [selecteds, setSelecteds] = (0,react.useState)([]);
    const onWalletClick = (0,react.useCallback)((wallet)=>{
        const clone = new Set(selecteds);
        if (clone.has(wallet)) clone.delete(wallet);
        else clone.add(wallet);
        setSelecteds([
            ...clone
        ]);
    }, [
        selecteds
    ]);
    const approveOrAlert = (0,callback/* useAsyncUniqueCallback */.T)(()=>errors/* Errors */.D.runAndLogAndAlert(async ()=>{
            if (selecteds.length === 0) throw new errors/* UIError */.m("No wallet selected");
            await background.requestOrThrow({
                method: "brume_respond",
                params: [
                    new ok/* RpcOk */.r(id, [
                        persistent,
                        selecteds
                    ])
                ]
            }).then((r)=>r.unwrap());
            location.replace(path.go("/done"));
        }), [
        background,
        id,
        path,
        selecteds,
        persistent
    ]);
    const rejectOrAlert = (0,callback/* useAsyncUniqueCallback */.T)(()=>errors/* Errors */.D.runAndLogAndAlert(async ()=>{
            await background.requestOrThrow({
                method: "brume_respond",
                params: [
                    err/* RpcErr */.s6.rewrap(id, new result_err/* Err */.U(new errors_errors/* UserRejectedError */.Ai()))
                ]
            }).then((r)=>r.unwrap());
            location.replace(path.go("/done"));
        }), [
        background,
        id,
        path
    ]);
    const Header = /*#__PURE__*/ (0,jsx_runtime.jsx)(header/* UserPageHeader */.To, {
        title: "Connect",
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(send/* PaddedRoundedShrinkableNakedAnchor */.wW, {
            onKeyDown: creator.onKeyDown,
            onClick: creator.onClick,
            href: creator.href,
            children: /*#__PURE__*/ (0,jsx_runtime.jsx)(PlusIcon/* default */.Z, {
                className: "size-5"
            })
        })
    });
    const Body = /*#__PURE__*/ (0,jsx_runtime.jsxs)(header/* PageBody */.xV, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(wallets_all_page/* SelectableWalletGrid */.Y7, {
                wallets: (_wallets_data = wallets.data) === null || _wallets_data === void 0 ? void 0 : _wallets_data.get(),
                ok: onWalletClick,
                selecteds: selecteds
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-4"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("label", {
                className: "po-md flex items-center bg-contrast rounded-xl",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "shrink-0",
                        children: "Stay connected"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-4 grow"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("input", {
                        className: "bg-transparent outline-none min-w-0 disabled:text-contrast",
                        type: "checkbox",
                        checked: persistent,
                        onChange: onPersistentChange
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-4"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "flex items-center flex-wrap-reverse gap-2",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(send/* WideShrinkableContrastButton */.pN, {
                        onClick: rejectOrAlert.run,
                        disabled: rejectOrAlert.loading,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(XMarkIcon/* default */.Z, {
                                className: "size-5"
                            }),
                            "Reject"
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(send/* WideShrinkableOppositeButton */.kd, {
                        onClick: approveOrAlert.run,
                        disabled: approveOrAlert.loading,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(CheckIcon/* default */.Z, {
                                className: "size-5"
                            }),
                            "Approve"
                        ]
                    })
                ]
            })
        ]
    });
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(page/* Page */.T, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(path_context/* HashSubpathProvider */.qd, {
                children: [
                    subpath.url.pathname === "/create" && /*#__PURE__*/ (0,jsx_runtime.jsx)(menu/* Menu */.v, {
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(create/* WalletCreatorMenu */.C, {})
                    }),
                    subpath.url.pathname === "/create/standalone" && /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Dialog2 */.gP, {
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(standalone/* StandaloneWalletCreatorDialog */.e, {})
                    }),
                    subpath.url.pathname === "/create/readonly" && /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Dialog2 */.gP, {
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(readonly/* ReadonlyWalletCreatorDialog */.V, {})
                    })
                ]
            }),
            Header,
            Body
        ]
    });
}
function DonePage() {
    var _useAppRequests_current;
    const path = (0,path_context/* usePathContext */.td)().unwrap();
    const requests = (_useAppRequests_current = (0,data/* useAppRequests */.fU)().current) === null || _useAppRequests_current === void 0 ? void 0 : _useAppRequests_current.ok().get();
    (0,react.useEffect)(()=>{
        if (!(requests === null || requests === void 0 ? void 0 : requests.length)) return;
        location.replace(path.go("/requests"));
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        requests
    ]);
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(page/* Page */.T, {
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)(header/* PageBody */.xV, {
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Dialog */.Vq.Title, {
                    children: "Done"
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "h-2"
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "text-contrast",
                    children: "You can now close this window or continue to use it"
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "h-4"
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "grow flex flex-col items-center justify-center",
                    children: /*#__PURE__*/ (0,jsx_runtime.jsxs)(all_page/* SmallShrinkableOppositeAnchor */.ee, {
                        href: "#/home",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(HomeIcon/* default */.Z, {
                                className: "size-5"
                            }),
                            "Home"
                        ]
                    })
                })
            ]
        })
    });
}


/***/ }),

/***/ 6361:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Vd: function() { return /* binding */ useAppRequest; },
  fU: function() { return /* binding */ useAppRequests; }
});

// UNUSED EXPORTS: FgAppRequest

// EXTERNAL MODULE: ./src/libs/glacier/mutators.ts
var mutators = __webpack_require__(7811);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/queries/simple/query.mjs
var query = __webpack_require__(6233);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/fetched/data.mjs
var data = __webpack_require__(8123);
;// CONCATENATED MODULE: ./src/mods/background/service_worker/entities/requests/data.tsx


var AppRequestRef;
(function(AppRequestRef) {
    function from(request) {
        return {
            ref: true,
            id: request.id
        };
    }
    AppRequestRef.from = from;
})(AppRequestRef || (AppRequestRef = {}));
var BgAppRequest;
(function(BgAppRequest) {
    let All;
    (function(All) {
        All.key = "requests";
        function schema() {
            return (0,query/* createQuery */.rP)({
                key: All.key
            });
        }
        All.schema = schema;
    })(All = BgAppRequest.All || (BgAppRequest.All = {}));
    function key(id) {
        return "request/".concat(id);
    }
    BgAppRequest.key = key;
    function schema(id) {
        const indexer = async (states)=>{
            var _previous_real_current_ok, _previous_real, _current_real_current_ok, _current_real;
            const { current, previous } = states;
            const previousData = previous === null || previous === void 0 ? void 0 : (_previous_real = previous.real) === null || _previous_real === void 0 ? void 0 : (_previous_real_current_ok = _previous_real.current.ok()) === null || _previous_real_current_ok === void 0 ? void 0 : _previous_real_current_ok.get();
            const currentData = (_current_real = current.real) === null || _current_real === void 0 ? void 0 : (_current_real_current_ok = _current_real.current.ok()) === null || _current_real_current_ok === void 0 ? void 0 : _current_real_current_ok.get();
            await BgAppRequest.All.schema().mutate(mutators/* Mutators */.g.mapData(function() {
                let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : new data/* Data */.V([]);
                if ((previousData === null || previousData === void 0 ? void 0 : previousData.id) === (currentData === null || currentData === void 0 ? void 0 : currentData.id)) return d;
                if (previousData != null) d = d.mapSync((p)=>p.filter((x)=>x.id !== previousData.id));
                if (currentData != null) d = d.mapSync((p)=>[
                        ...p,
                        AppRequestRef.from(currentData)
                    ]);
                return d;
            }));
        };
        return (0,query/* createQuery */.rP)({
            key: key(id),
            indexer
        });
    }
    BgAppRequest.schema = schema;
})(BgAppRequest || (BgAppRequest = {}));

// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/react/hooks/queries/simple.mjs + 1 modules
var simple = __webpack_require__(564);
// EXTERNAL MODULE: ./src/mods/foreground/storage/user.tsx
var user = __webpack_require__(2536);
;// CONCATENATED MODULE: ./src/mods/foreground/entities/requests/data.tsx




var FgAppRequest;
(function(FgAppRequest) {
    let All;
    (function(All) {
        All.key = BgAppRequest.All.key;
        function schema(storage) {
            return (0,query/* createQuery */.rP)({
                key: All.key,
                storage
            });
        }
        All.schema = schema;
    })(All = FgAppRequest.All || (FgAppRequest.All = {}));
    FgAppRequest.key = BgAppRequest.key;
    function schema(id, storage) {
        if (id == null) return;
        const indexer = async (states)=>{
            var _previous_real_current_ok, _previous_real, _current_real_current_ok, _current_real;
            const { current, previous } = states;
            const previousData = previous === null || previous === void 0 ? void 0 : (_previous_real = previous.real) === null || _previous_real === void 0 ? void 0 : (_previous_real_current_ok = _previous_real.current.ok()) === null || _previous_real_current_ok === void 0 ? void 0 : _previous_real_current_ok.get();
            const currentData = (_current_real = current.real) === null || _current_real === void 0 ? void 0 : (_current_real_current_ok = _current_real.current.ok()) === null || _current_real_current_ok === void 0 ? void 0 : _current_real_current_ok.get();
            await All.schema(storage).mutate(mutators/* Mutators */.g.mapData(function() {
                let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : new data/* Data */.V([]);
                if ((previousData === null || previousData === void 0 ? void 0 : previousData.id) === (currentData === null || currentData === void 0 ? void 0 : currentData.id)) return d;
                if (previousData != null) d = d.mapSync((p)=>p.filter((x)=>x.id !== previousData.id));
                if (currentData != null) d = d.mapSync((p)=>[
                        ...p,
                        AppRequestRef.from(currentData)
                    ]);
                return d;
            }));
        };
        return (0,query/* createQuery */.rP)({
            key: FgAppRequest.key(id),
            indexer,
            storage
        });
    }
    FgAppRequest.schema = schema;
})(FgAppRequest || (FgAppRequest = {}));
function useAppRequest(id) {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(FgAppRequest.schema, [
        id,
        storage
    ]);
    return query;
}
function useAppRequests() {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(FgAppRequest.All.schema, [
        storage
    ]);
    return query;
}


/***/ }),

/***/ 7309:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   C: function() { return /* binding */ WalletCreatorMenu; }
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _libs_icons_icons__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(162);
/* harmony import */ var _libs_icons_icons__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(379);
/* harmony import */ var _mods_foreground_router_path_context__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9046);
/* harmony import */ var _users_all_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4190);
/* harmony import */ var _actions_send__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8856);





function WalletCreatorMenu(props) {
    const path = (0,_mods_foreground_router_path_context__WEBPACK_IMPORTED_MODULE_1__/* .usePathContext */ .td)().unwrap();
    const readonly = (0,_users_all_page__WEBPACK_IMPORTED_MODULE_2__/* .useGenius */ .y6)(path, "/create/readonly");
    const standalone = (0,_users_all_page__WEBPACK_IMPORTED_MODULE_2__/* .useGenius */ .y6)(path, "/create/standalone");
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex flex-col text-left gap-2",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_actions_send__WEBPACK_IMPORTED_MODULE_3__/* .WideShrinkableNakedMenuAnchor */ .s_, {
                onClick: standalone.onClick,
                onKeyDown: standalone.onKeyDown,
                href: standalone.href,
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_libs_icons_icons__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                        className: "size-4"
                    }),
                    "Standalone"
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_actions_send__WEBPACK_IMPORTED_MODULE_3__/* .WideShrinkableNakedMenuAnchor */ .s_, {
                onClick: readonly.onClick,
                onKeyDown: readonly.onKeyDown,
                href: readonly.href,
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_libs_icons_icons__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        className: "size-4"
                    }),
                    "Watch-only"
                ]
            })
        ]
    });
}


/***/ }),

/***/ 1286:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   V: function() { return /* binding */ ReadonlyWalletCreatorDialog; }
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _libs_colors_colors__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1311);
/* harmony import */ var _libs_emojis_emojis__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1792);
/* harmony import */ var _libs_errors_errors__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(783);
/* harmony import */ var _libs_ethereum_mods_chain__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3411);
/* harmony import */ var _libs_icons_icons__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(8105);
/* harmony import */ var _libs_modhash_modhash__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2637);
/* harmony import */ var _libs_react_callback__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2702);
/* harmony import */ var _libs_react_events__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(904);
/* harmony import */ var _libs_react_ref__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9195);
/* harmony import */ var _libs_ui_dialog_dialog__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6202);
/* harmony import */ var _libs_uuid_uuid__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(6655);
/* harmony import */ var _mods_foreground_background_context__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3891);
/* harmony import */ var _hazae41_cubane__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(6113);
/* harmony import */ var _hazae41_cubane__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(7657);
/* harmony import */ var _hazae41_option__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(5316);
/* harmony import */ var _hazae41_result__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(2564);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(7294);
/* harmony import */ var _names_data__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(2319);
/* harmony import */ var _actions_send__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(8856);
/* harmony import */ var _card__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(5007);
/* harmony import */ var _data__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(4844);
/* harmony import */ var _standalone__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(4925);






















function ReadonlyWalletCreatorDialog(props) {
    var _ensAddressQuery_current;
    const close = (0,_libs_ui_dialog_dialog__WEBPACK_IMPORTED_MODULE_9__/* .useCloseContext */ .gX)().unwrap();
    const background = (0,_mods_foreground_background_context__WEBPACK_IMPORTED_MODULE_10__/* .useBackgroundContext */ .D_)().unwrap();
    const uuid = (0,_libs_react_ref__WEBPACK_IMPORTED_MODULE_8__/* .useConstant */ .hS)(()=>(0,_libs_uuid_uuid__WEBPACK_IMPORTED_MODULE_17__/* .randomUUID */ .H)());
    const modhash = (0,_libs_modhash_modhash__WEBPACK_IMPORTED_MODULE_5__/* .useModhash */ .jR)(uuid);
    const color = _libs_colors_colors__WEBPACK_IMPORTED_MODULE_1__/* .Color */ .I.get(modhash);
    const emoji = _libs_emojis_emojis__WEBPACK_IMPORTED_MODULE_2__/* .Emojis */ .A.get(modhash);
    const mainnet = (0,_data__WEBPACK_IMPORTED_MODULE_15__/* .useEthereumContext */ .Kn)(uuid, _libs_ethereum_mods_chain__WEBPACK_IMPORTED_MODULE_4__/* .chainDataByChainId */ .wz[1]);
    const [rawNameInput = "", setRawNameInput] = (0,react__WEBPACK_IMPORTED_MODULE_11__.useState)();
    const defNameInput = (0,react__WEBPACK_IMPORTED_MODULE_11__.useDeferredValue)(rawNameInput);
    const onNameInputChange = (0,_libs_react_events__WEBPACK_IMPORTED_MODULE_7__/* .useInputChange */ .Xy)((e)=>{
        setRawNameInput(e.currentTarget.value);
    }, []);
    const finalNameInput = (0,react__WEBPACK_IMPORTED_MODULE_11__.useMemo)(()=>{
        return defNameInput || "Vitalik";
    }, [
        defNameInput
    ]);
    const [rawAddressInput = "", setRawAddressInput] = (0,react__WEBPACK_IMPORTED_MODULE_11__.useState)();
    const defAddressInput = (0,react__WEBPACK_IMPORTED_MODULE_11__.useDeferredValue)(rawAddressInput);
    const onAddressInputChange = (0,_libs_react_events__WEBPACK_IMPORTED_MODULE_7__/* .useTextAreaChange */ .aN)((e)=>{
        setRawAddressInput(e.currentTarget.value);
    }, []);
    const maybeEnsKey = (0,react__WEBPACK_IMPORTED_MODULE_11__.useMemo)(()=>{
        if (!defAddressInput.endsWith(".eth")) return;
        return defAddressInput;
    }, [
        defAddressInput
    ]);
    const ensAddressQuery = (0,_names_data__WEBPACK_IMPORTED_MODULE_12__/* .useEnsLookup */ .aZ)(maybeEnsKey, mainnet);
    const maybeEnsAddress = (_ensAddressQuery_current = ensAddressQuery.current) === null || _ensAddressQuery_current === void 0 ? void 0 : _ensAddressQuery_current.ok().get();
    const maybeAddress = (0,react__WEBPACK_IMPORTED_MODULE_11__.useMemo)(()=>{
        if (maybeEnsAddress != null) return maybeEnsAddress;
        if (_hazae41_cubane__WEBPACK_IMPORTED_MODULE_18__/* .ZeroHexString */ .T.is(defAddressInput)) return defAddressInput;
        return undefined;
    }, [
        defAddressInput,
        maybeEnsAddress
    ]);
    const addOrAlert = (0,_libs_react_callback__WEBPACK_IMPORTED_MODULE_6__/* .useAsyncUniqueCallback */ .T)(()=>_libs_errors_errors__WEBPACK_IMPORTED_MODULE_3__/* .Errors */ .D.runAndLogAndAlert(async ()=>{
            if (!finalNameInput) throw new _hazae41_result__WEBPACK_IMPORTED_MODULE_19__/* .Panic */ .F();
            const address = _hazae41_option__WEBPACK_IMPORTED_MODULE_20__/* .Option */ .W.wrap(maybeAddress).okOrElseSync(()=>{
                return new _libs_errors_errors__WEBPACK_IMPORTED_MODULE_3__/* .UIError */ .m("Could not fetch or parse address");
            }).mapSync((x)=>_hazae41_cubane__WEBPACK_IMPORTED_MODULE_21__/* .Address */ .k.from(x)).unwrap();
            const wallet = {
                coin: "ethereum",
                type: "readonly",
                uuid,
                name: finalNameInput,
                color: _libs_colors_colors__WEBPACK_IMPORTED_MODULE_1__/* .Color */ .I.all.indexOf(color),
                emoji,
                address
            };
            await background.requestOrThrow({
                method: "brume_createWallet",
                params: [
                    wallet
                ]
            }).then((r)=>r.unwrap());
            close();
        }), [
        finalNameInput,
        maybeAddress,
        uuid,
        color,
        emoji,
        background,
        close
    ]);
    const addDisabled = (0,react__WEBPACK_IMPORTED_MODULE_11__.useMemo)(()=>{
        if (addOrAlert.loading) return "Loading...";
        if (!finalNameInput) return "Please enter a name";
        if (!defAddressInput) return "Please enter an address";
        return undefined;
    }, [
        addOrAlert.loading,
        finalNameInput,
        defAddressInput
    ]);
    const NameInput = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_actions_send__WEBPACK_IMPORTED_MODULE_13__/* .SimpleLabel */ .JJ, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "shrink-0",
                children: "Name"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "w-4"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_actions_send__WEBPACK_IMPORTED_MODULE_13__/* .SimpleInput */ .Jc, {
                placeholder: "Vitalik",
                value: rawNameInput,
                onChange: onNameInputChange
            })
        ]
    });
    const AddressInput = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_actions_send__WEBPACK_IMPORTED_MODULE_13__/* .SimpleLabel */ .JJ, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "shrink-0",
                children: "Address"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "w-4"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_actions_send__WEBPACK_IMPORTED_MODULE_13__/* .SimpleTextarea */ .pm, {
                placeholder: "vitalik.eth",
                value: rawAddressInput,
                onChange: onAddressInputChange,
                rows: 4
            })
        ]
    });
    const AddButon = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_actions_send__WEBPACK_IMPORTED_MODULE_13__/* .WideShrinkableGradientButton */ .sz, {
        color: color,
        disabled: Boolean(addDisabled),
        onClick: addOrAlert.run,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_libs_icons_icons__WEBPACK_IMPORTED_MODULE_22__/* ["default"] */ .Z, {
                className: "size-5"
            }),
            addDisabled || "Add"
        ]
    });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_libs_ui_dialog_dialog__WEBPACK_IMPORTED_MODULE_9__/* .Dialog */ .Vq.Title, {
                children: "New wallet"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "h-4"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "flex-1 flex flex-col items-center justify-center",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "w-full max-w-sm",
                    children: [
                        maybeAddress != null && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                            className: "w-full aspect-video rounded-xl",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_card__WEBPACK_IMPORTED_MODULE_14__/* .RawWalletCard */ .AD, {
                                uuid: uuid,
                                name: finalNameInput,
                                emoji: emoji,
                                address: maybeAddress,
                                color: color
                            })
                        }),
                        maybeAddress == null && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_standalone__WEBPACK_IMPORTED_MODULE_16__/* .EmptyRectangularCard */ .Y, {})
                    ]
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "h-2"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex-1 flex flex-col",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: "grow"
                    }),
                    NameInput,
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: "h-2"
                    }),
                    AddressInput,
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: "h-4"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: "flex items-center flex-wrap-reverse gap-2",
                        children: AddButon
                    })
                ]
            })
        ]
    });
}


/***/ }),

/***/ 4925:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Y: function() { return /* binding */ EmptyRectangularCard; },
/* harmony export */   e: function() { return /* binding */ StandaloneWalletCreatorDialog; }
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _libs_colors_colors__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1311);
/* harmony import */ var _libs_emojis_emojis__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1792);
/* harmony import */ var _libs_errors_errors__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(783);
/* harmony import */ var _libs_icons_icons__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(4357);
/* harmony import */ var _libs_icons_icons__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(8105);
/* harmony import */ var _libs_icons_icons__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(651);
/* harmony import */ var _libs_modhash_modhash__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2637);
/* harmony import */ var _libs_platform_platform__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(9686);
/* harmony import */ var _libs_react_callback__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2702);
/* harmony import */ var _libs_react_events__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(904);
/* harmony import */ var _libs_react_memo__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9210);
/* harmony import */ var _libs_react_ref__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9195);
/* harmony import */ var _libs_ui_dialog_dialog__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6202);
/* harmony import */ var _libs_uuid_uuid__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(6655);
/* harmony import */ var _libs_webauthn_webauthn__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(789);
/* harmony import */ var _mods_foreground_background_context__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(3891);
/* harmony import */ var _hazae41_base16__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(2248);
/* harmony import */ var _hazae41_base64__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(9467);
/* harmony import */ var _hazae41_bytes__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(1694);
/* harmony import */ var _hazae41_cubane__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(6113);
/* harmony import */ var _hazae41_cubane__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(7657);
/* harmony import */ var _hazae41_result__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(918);
/* harmony import */ var _hazae41_result__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(2564);
/* harmony import */ var _hazae41_secp256k1__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(9347);
/* harmony import */ var _noble_curves_secp256k1__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(9578);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(7294);
/* harmony import */ var _actions_send__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(8856);
/* harmony import */ var _card__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(5007);

var __addDisposableResource = undefined && undefined.__addDisposableResource || function(env, value, async) {
    if (value !== null && value !== void 0) {
        if (typeof value !== "object" && typeof value !== "function") throw new TypeError("Object expected.");
        var dispose;
        if (async) {
            if (!Symbol.asyncDispose) throw new TypeError("Symbol.asyncDispose is not defined.");
            dispose = value[Symbol.asyncDispose];
        }
        if (dispose === void 0) {
            if (!Symbol.dispose) throw new TypeError("Symbol.dispose is not defined.");
            dispose = value[Symbol.dispose];
        }
        if (typeof dispose !== "function") throw new TypeError("Object not disposable.");
        env.stack.push({
            value: value,
            dispose: dispose,
            async: async
        });
    } else if (async) {
        env.stack.push({
            async: true
        });
    }
    return value;
};
var __disposeResources = undefined && undefined.__disposeResources || function(SuppressedError1) {
    return function(env) {
        function fail(e) {
            env.error = env.hasError ? new SuppressedError1(e, env.error, "An error was suppressed during disposal.") : e;
            env.hasError = true;
        }
        function next() {
            while(env.stack.length){
                var rec = env.stack.pop();
                try {
                    var result = rec.dispose && rec.dispose.call(rec.value);
                    if (rec.async) return Promise.resolve(result).then(next, function(e) {
                        fail(e);
                        return next();
                    });
                } catch (e) {
                    fail(e);
                }
            }
            if (env.hasError) throw env.error;
        }
        return next();
    };
}(typeof SuppressedError === "function" ? SuppressedError : function(error, suppressed, message) {
    var e = new Error(message);
    return e.name = "SuppressedError", e.error = error, e.suppressed = suppressed, e;
});
























function StandaloneWalletCreatorDialog(props) {
    const close = (0,_libs_ui_dialog_dialog__WEBPACK_IMPORTED_MODULE_9__/* .useCloseContext */ .gX)().unwrap();
    const background = (0,_mods_foreground_background_context__WEBPACK_IMPORTED_MODULE_11__/* .useBackgroundContext */ .D_)().unwrap();
    const uuid = (0,_libs_react_ref__WEBPACK_IMPORTED_MODULE_8__/* .useConstant */ .hS)(()=>(0,_libs_uuid_uuid__WEBPACK_IMPORTED_MODULE_15__/* .randomUUID */ .H)());
    const modhash = (0,_libs_modhash_modhash__WEBPACK_IMPORTED_MODULE_4__/* .useModhash */ .jR)(uuid);
    const color = _libs_colors_colors__WEBPACK_IMPORTED_MODULE_1__/* .Color */ .I.get(modhash);
    const emoji = _libs_emojis_emojis__WEBPACK_IMPORTED_MODULE_2__/* .Emojis */ .A.get(modhash);
    const [rawNameInput = "", setRawNameInput] = (0,react__WEBPACK_IMPORTED_MODULE_12__.useState)();
    const defNameInput = (0,react__WEBPACK_IMPORTED_MODULE_12__.useDeferredValue)(rawNameInput);
    const onNameInputChange = (0,_libs_react_events__WEBPACK_IMPORTED_MODULE_6__/* .useInputChange */ .Xy)((e)=>{
        setRawNameInput(e.currentTarget.value);
    }, []);
    const finalNameInput = (0,react__WEBPACK_IMPORTED_MODULE_12__.useMemo)(()=>{
        return defNameInput || "Holder";
    }, [
        defNameInput
    ]);
    const [rawKeyInput = "", setRawKeyInput] = (0,react__WEBPACK_IMPORTED_MODULE_12__.useState)();
    const defKeyInput = (0,react__WEBPACK_IMPORTED_MODULE_12__.useDeferredValue)(rawKeyInput);
    const zeroHexKey = _hazae41_cubane__WEBPACK_IMPORTED_MODULE_16__/* .ZeroHexString */ .T.from(defKeyInput);
    const onKeyInputChange = (0,_libs_react_events__WEBPACK_IMPORTED_MODULE_6__/* .useTextAreaChange */ .aN)((e)=>{
        setRawKeyInput(e.currentTarget.value);
    }, []);
    const generateOrAlert = (0,react__WEBPACK_IMPORTED_MODULE_12__.useCallback)(()=>_libs_errors_errors__WEBPACK_IMPORTED_MODULE_3__/* .Errors */ .D.runAndLogAndAlertSync(()=>{
            const env_1 = {
                stack: [],
                error: void 0,
                hasError: false
            };
            try {
                const memory = __addDisposableResource(env_1, _hazae41_secp256k1__WEBPACK_IMPORTED_MODULE_17__/* .get */ .U().PrivateKey.tryRandom().unwrap().tryExport().unwrap(), false);
                setRawKeyInput("0x".concat(_hazae41_base16__WEBPACK_IMPORTED_MODULE_18__/* .get */ .U().encodeOrThrow(memory)));
            } catch (e_1) {
                env_1.error = e_1;
                env_1.hasError = true;
            } finally{
                __disposeResources(env_1);
            }
        }), []);
    const triedAddress = (0,react__WEBPACK_IMPORTED_MODULE_12__.useMemo)(()=>_hazae41_result__WEBPACK_IMPORTED_MODULE_19__/* .Result */ .x.runAndDoubleWrapSync(()=>{
            const env_2 = {
                stack: [],
                error: void 0,
                hasError: false
            };
            try {
                const privateKeyMemory = __addDisposableResource(env_2, _hazae41_base16__WEBPACK_IMPORTED_MODULE_18__/* .get */ .U().padStartAndDecodeOrThrow(zeroHexKey.slice(2)), false);
                const privateKey = __addDisposableResource(env_2, _hazae41_secp256k1__WEBPACK_IMPORTED_MODULE_17__/* .get */ .U().PrivateKey.tryImport(privateKeyMemory).unwrap(), false);
                const publicKey = __addDisposableResource(env_2, privateKey.tryGetPublicKey().unwrap(), false);
                const uncompressedPublicKeyMemory = __addDisposableResource(env_2, publicKey.tryExportUncompressed().unwrap(), false);
                return _hazae41_cubane__WEBPACK_IMPORTED_MODULE_20__/* .Address */ .k.compute(uncompressedPublicKeyMemory.bytes);
            } catch (e_2) {
                env_2.error = e_2;
                env_2.hasError = true;
            } finally{
                __disposeResources(env_2);
            }
        }), [
        zeroHexKey
    ]);
    const addUnauthenticatedOrAlert = (0,_libs_react_callback__WEBPACK_IMPORTED_MODULE_5__/* .useAsyncUniqueCallback */ .T)(()=>_libs_errors_errors__WEBPACK_IMPORTED_MODULE_3__/* .Errors */ .D.runAndLogAndAlert(async ()=>{
            if (!finalNameInput) throw new _hazae41_result__WEBPACK_IMPORTED_MODULE_21__/* .Panic */ .F();
            if (!_noble_curves_secp256k1__WEBPACK_IMPORTED_MODULE_22__/* .secp256k1 */ .kA.utils.isValidPrivateKey(zeroHexKey.slice(2))) throw new _hazae41_result__WEBPACK_IMPORTED_MODULE_21__/* .Panic */ .F();
            if (!(0,_libs_platform_platform__WEBPACK_IMPORTED_MODULE_23__/* .isSafariExtension */ .WB)() && confirm("Did you backup your private key?") === false) return;
            const address = triedAddress.unwrap();
            const wallet = {
                coin: "ethereum",
                type: "privateKey",
                uuid,
                name: finalNameInput,
                color: _libs_colors_colors__WEBPACK_IMPORTED_MODULE_1__/* .Color */ .I.all.indexOf(color),
                emoji,
                address,
                privateKey: zeroHexKey
            };
            await background.requestOrThrow({
                method: "brume_createWallet",
                params: [
                    wallet
                ]
            }).then((r)=>r.unwrap());
            close();
        }), [
        finalNameInput,
        zeroHexKey,
        uuid,
        color,
        emoji,
        background,
        close
    ]);
    const triedEncryptedPrivateKey = (0,_libs_react_memo__WEBPACK_IMPORTED_MODULE_7__/* .useAsyncReplaceMemo */ .EY)(()=>_hazae41_result__WEBPACK_IMPORTED_MODULE_19__/* .Result */ .x.runAndWrap(async ()=>{
            const env_3 = {
                stack: [],
                error: void 0,
                hasError: false
            };
            try {
                if (!finalNameInput) throw new _hazae41_result__WEBPACK_IMPORTED_MODULE_21__/* .Panic */ .F();
                if (!_noble_curves_secp256k1__WEBPACK_IMPORTED_MODULE_22__/* .secp256k1 */ .kA.utils.isValidPrivateKey(zeroHexKey.slice(2))) throw new _hazae41_result__WEBPACK_IMPORTED_MODULE_21__/* .Panic */ .F();
                const privateKeyMemory = __addDisposableResource(env_3, _hazae41_base16__WEBPACK_IMPORTED_MODULE_18__/* .get */ .U().padStartAndDecodeOrThrow(zeroHexKey.slice(2)), false);
                const privateKeyBase64 = _hazae41_base64__WEBPACK_IMPORTED_MODULE_24__/* .get */ .U().encodePaddedOrThrow(privateKeyMemory);
                const [ivBase64, cipherBase64] = await background.requestOrThrow({
                    method: "brume_encrypt",
                    params: [
                        privateKeyBase64
                    ]
                }).then((r)=>r.unwrap());
                return [
                    ivBase64,
                    cipherBase64
                ];
            } catch (e_3) {
                env_3.error = e_3;
                env_3.hasError = true;
            } finally{
                __disposeResources(env_3);
            }
        }), [
        finalNameInput,
        zeroHexKey,
        background
    ]);
    const [id, setId] = (0,react__WEBPACK_IMPORTED_MODULE_12__.useState)();
    (0,react__WEBPACK_IMPORTED_MODULE_12__.useEffect)(()=>{
        setId(undefined);
    }, [
        zeroHexKey
    ]);
    const addAuthenticatedOrAlert1 = (0,_libs_react_callback__WEBPACK_IMPORTED_MODULE_5__/* .useAsyncUniqueCallback */ .T)(()=>_libs_errors_errors__WEBPACK_IMPORTED_MODULE_3__/* .Errors */ .D.runAndLogAndAlert(async ()=>{
            if (!finalNameInput) throw new _hazae41_result__WEBPACK_IMPORTED_MODULE_21__/* .Panic */ .F();
            if (triedEncryptedPrivateKey == null) throw new _hazae41_result__WEBPACK_IMPORTED_MODULE_21__/* .Panic */ .F();
            if (!(0,_libs_platform_platform__WEBPACK_IMPORTED_MODULE_23__/* .isSafariExtension */ .WB)() && confirm("Did you backup your private key?") === false) return;
            const [_, cipherBase64] = triedEncryptedPrivateKey.unwrap();
            const cipher = _hazae41_base64__WEBPACK_IMPORTED_MODULE_24__/* .get */ .U().decodePaddedOrThrow(cipherBase64).copyAndDispose();
            const id = await _libs_webauthn_webauthn__WEBPACK_IMPORTED_MODULE_10__/* .WebAuthnStorage */ .g.createOrThrow(finalNameInput, cipher);
            setId(id);
        }), [
        finalNameInput,
        triedEncryptedPrivateKey
    ]);
    const addAuthenticatedOrAlert2 = (0,_libs_react_callback__WEBPACK_IMPORTED_MODULE_5__/* .useAsyncUniqueCallback */ .T)(()=>_libs_errors_errors__WEBPACK_IMPORTED_MODULE_3__/* .Errors */ .D.runAndLogAndAlert(async ()=>{
            const env_4 = {
                stack: [],
                error: void 0,
                hasError: false
            };
            try {
                if (id == null) throw new _hazae41_result__WEBPACK_IMPORTED_MODULE_21__/* .Panic */ .F();
                if (!finalNameInput) throw new _hazae41_result__WEBPACK_IMPORTED_MODULE_21__/* .Panic */ .F();
                if (triedEncryptedPrivateKey == null) throw new _hazae41_result__WEBPACK_IMPORTED_MODULE_21__/* .Panic */ .F();
                const address = triedAddress.unwrap();
                const [ivBase64, cipherBase64] = triedEncryptedPrivateKey.unwrap();
                const cipherMemory = __addDisposableResource(env_4, _hazae41_base64__WEBPACK_IMPORTED_MODULE_24__/* .get */ .U().decodePaddedOrThrow(cipherBase64), false);
                const cipherBytes = await _libs_webauthn_webauthn__WEBPACK_IMPORTED_MODULE_10__/* .WebAuthnStorage */ .g.getOrThrow(id);
                if (!_hazae41_bytes__WEBPACK_IMPORTED_MODULE_25__/* .Bytes */ .J.equals(cipherMemory.bytes, cipherBytes)) throw new _libs_webauthn_webauthn__WEBPACK_IMPORTED_MODULE_10__/* .WebAuthnStorageError */ .$();
                const idBase64 = _hazae41_base64__WEBPACK_IMPORTED_MODULE_24__/* .get */ .U().encodePaddedOrThrow(id);
                const privateKey = {
                    ivBase64,
                    idBase64
                };
                const wallet = {
                    coin: "ethereum",
                    type: "authPrivateKey",
                    uuid,
                    name: finalNameInput,
                    color: _libs_colors_colors__WEBPACK_IMPORTED_MODULE_1__/* .Color */ .I.all.indexOf(color),
                    emoji,
                    address,
                    privateKey
                };
                await background.requestOrThrow({
                    method: "brume_createWallet",
                    params: [
                        wallet
                    ]
                }).then((r)=>r.unwrap());
                close();
            } catch (e_4) {
                env_4.error = e_4;
                env_4.hasError = true;
            } finally{
                __disposeResources(env_4);
            }
        }), [
        id,
        finalNameInput,
        triedAddress,
        triedEncryptedPrivateKey,
        uuid,
        color,
        emoji,
        background,
        close
    ]);
    const NameInput = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_actions_send__WEBPACK_IMPORTED_MODULE_13__/* .SimpleLabel */ .JJ, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "shrink-0",
                children: "Name"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "w-4"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_actions_send__WEBPACK_IMPORTED_MODULE_13__/* .SimpleInput */ .Jc, {
                placeholder: "Holder",
                value: rawNameInput,
                onChange: onNameInputChange
            })
        ]
    });
    const KeyInput = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "po-md flex flex-col bg-contrast rounded-xl",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex items-start",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: "shrink-0",
                        children: "Private key"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: "w-4"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_actions_send__WEBPACK_IMPORTED_MODULE_13__/* .SimpleTextarea */ .pm, {
                        placeholder: "0x",
                        value: rawKeyInput,
                        onChange: onKeyInputChange,
                        rows: 3
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "h-2"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_actions_send__WEBPACK_IMPORTED_MODULE_13__/* .WideShrinkableContrastButton */ .pN, {
                onClick: generateOrAlert,
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_libs_icons_icons__WEBPACK_IMPORTED_MODULE_26__/* ["default"] */ .Z, {
                        className: "size-5"
                    }),
                    "Generate"
                ]
            })
        ]
    });
    const canAdd = (0,react__WEBPACK_IMPORTED_MODULE_12__.useMemo)(()=>{
        if (!finalNameInput) return false;
        if (!_noble_curves_secp256k1__WEBPACK_IMPORTED_MODULE_22__/* .secp256k1 */ .kA.utils.isValidPrivateKey(zeroHexKey.slice(2))) return false;
        return true;
    }, [
        finalNameInput,
        zeroHexKey
    ]);
    const AddUnauthButton = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_actions_send__WEBPACK_IMPORTED_MODULE_13__/* .WideShrinkableContrastButton */ .pN, {
        disabled: !canAdd,
        onClick: addUnauthenticatedOrAlert.run,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_libs_icons_icons__WEBPACK_IMPORTED_MODULE_27__/* ["default"] */ .Z, {
                className: "size-5"
            }),
            "Add without authentication"
        ]
    });
    const AddAuthButton1 = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_actions_send__WEBPACK_IMPORTED_MODULE_13__/* .WideShrinkableGradientButton */ .sz, {
        color: color,
        disabled: !canAdd,
        onClick: addAuthenticatedOrAlert1.run,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_libs_icons_icons__WEBPACK_IMPORTED_MODULE_28__/* ["default"] */ .Z, {
                className: "size-5"
            }),
            "Add with authentication"
        ]
    });
    const AddAuthButton2 = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_actions_send__WEBPACK_IMPORTED_MODULE_13__/* .WideShrinkableGradientButton */ .sz, {
        color: color,
        disabled: !canAdd,
        onClick: addAuthenticatedOrAlert2.run,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_libs_icons_icons__WEBPACK_IMPORTED_MODULE_28__/* ["default"] */ .Z, {
                className: "size-5"
            }),
            "Add with authentication (1/2)"
        ]
    });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_libs_ui_dialog_dialog__WEBPACK_IMPORTED_MODULE_9__/* .Dialog */ .Vq.Title, {
                children: "New wallet"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "h-4"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "flex-1 flex flex-col items-center justify-center",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "w-full max-w-sm",
                    children: [
                        triedAddress.isOk() && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                            className: "w-full aspect-video rounded-xl",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_card__WEBPACK_IMPORTED_MODULE_14__/* .RawWalletCard */ .AD, {
                                uuid: uuid,
                                name: finalNameInput,
                                emoji: emoji,
                                address: triedAddress.get(),
                                color: color
                            })
                        }),
                        triedAddress.isErr() && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(EmptyRectangularCard, {})
                    ]
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "h-2"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex-1 flex flex-col",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: "grow"
                    }),
                    NameInput,
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: "h-2"
                    }),
                    KeyInput,
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: "h-4"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex items-center flex-wrap-reverse gap-2",
                        children: [
                            AddUnauthButton,
                            id == null ? AddAuthButton1 : AddAuthButton2
                        ]
                    })
                ]
            })
        ]
    });
}
function EmptyRectangularCard(props) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        className: "po-md w-full aspect-video rounded-xl flex gap-2 justify-center items-center border border-contrast border-dashed hovered-or-clicked-or-focused:scale-105 !transition-transform"
    });
}


/***/ }),

/***/ 5750:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FU: function() { return /* binding */ WalletsPage; },
/* harmony export */   Gn: function() { return /* binding */ NewRectangularAnchorCard; },
/* harmony export */   Y7: function() { return /* binding */ SelectableWalletGrid; },
/* harmony export */   oS: function() { return /* binding */ ClickableWalletGrid; }
/* harmony export */ });
/* unused harmony exports CheckableWalletCard, ClickableWalletCard */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _libs_icons_icons__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(5836);
/* harmony import */ var _libs_icons_icons__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(8105);
/* harmony import */ var _libs_ui_dialog_dialog__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6202);
/* harmony import */ var _libs_ui2_menu_menu__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5857);
/* harmony import */ var _libs_ui2_page_header__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7480);
/* harmony import */ var _libs_ui2_page_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6698);
/* harmony import */ var _mods_foreground_router_path_context__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9046);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7294);
/* harmony import */ var _users_all_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4190);
/* harmony import */ var _actions_send__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8856);
/* harmony import */ var _card__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5007);
/* harmony import */ var _context__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3291);
/* harmony import */ var _data__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4844);
/* harmony import */ var _create__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(7309);
/* harmony import */ var _create_readonly__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(1286);
/* harmony import */ var _create_standalone__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(4925);
/* eslint-disable @next/next/no-img-element */ 















function WalletsPage() {
    var _walletsQuery_current, _trashedWalletsQuery_current;
    const path = (0,_mods_foreground_router_path_context__WEBPACK_IMPORTED_MODULE_5__/* .usePathContext */ .td)().unwrap();
    const walletsQuery = (0,_data__WEBPACK_IMPORTED_MODULE_11__/* .useWallets */ .rB)();
    const maybeWallets = (_walletsQuery_current = walletsQuery.current) === null || _walletsQuery_current === void 0 ? void 0 : _walletsQuery_current.ok().get();
    const trashedWalletsQuery = (0,_data__WEBPACK_IMPORTED_MODULE_11__/* .useTrashedWallets */ .Pd)();
    const maybeTrashedWallets = (_trashedWalletsQuery_current = trashedWalletsQuery.current) === null || _trashedWalletsQuery_current === void 0 ? void 0 : _trashedWalletsQuery_current.ok().get();
    const subpath = (0,_mods_foreground_router_path_context__WEBPACK_IMPORTED_MODULE_5__/* .useHashSubpath */ .IL)(path);
    const creator = (0,_users_all_page__WEBPACK_IMPORTED_MODULE_7__/* .useGenius */ .y6)(subpath, "/create");
    const onWalletClick = (0,react__WEBPACK_IMPORTED_MODULE_6__.useCallback)((wallet)=>{
        location.assign(path.go("/wallet/".concat(wallet.uuid)));
    }, [
        path
    ]);
    const Body = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_libs_ui2_page_header__WEBPACK_IMPORTED_MODULE_3__/* .PageBody */ .xV, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(ClickableWalletGrid, {
                ok: onWalletClick,
                wallets: maybeWallets
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "h-4"
            }),
            maybeTrashedWallets != null && maybeTrashedWallets.length > 0 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "flex items-center flex-wrap-reverse gap-2",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_users_all_page__WEBPACK_IMPORTED_MODULE_7__/* .WideShrinkableContrastAnchor */ .yF, {
                    href: "#/wallets/trash",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_libs_icons_icons__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                            className: "size-5"
                        }),
                        "Trash (",
                        maybeTrashedWallets.length,
                        ")"
                    ]
                })
            })
        ]
    });
    const Header = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_libs_ui2_page_header__WEBPACK_IMPORTED_MODULE_3__/* .UserPageHeader */ .To, {
                title: "Wallets",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_actions_send__WEBPACK_IMPORTED_MODULE_8__/* .PaddedRoundedShrinkableNakedAnchor */ .wW, {
                    onKeyDown: creator.onKeyDown,
                    onClick: creator.onClick,
                    href: creator.href,
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_libs_icons_icons__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                        className: "size-5"
                    })
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "po-md flex items-center",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                    className: "text-contrast",
                    children: "Wallets allow you to hold funds and generate signatures. You can import wallets from a private key or generate them from a seed."
                })
            })
        ]
    });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_libs_ui2_page_page__WEBPACK_IMPORTED_MODULE_4__/* .Page */ .T, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mods_foreground_router_path_context__WEBPACK_IMPORTED_MODULE_5__/* .HashSubpathProvider */ .qd, {
                children: [
                    subpath.url.pathname === "/create" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_libs_ui2_menu_menu__WEBPACK_IMPORTED_MODULE_2__/* .Menu */ .v, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_create__WEBPACK_IMPORTED_MODULE_12__/* .WalletCreatorMenu */ .C, {})
                    }),
                    subpath.url.pathname === "/create/standalone" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_libs_ui_dialog_dialog__WEBPACK_IMPORTED_MODULE_1__/* .Dialog2 */ .gP, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_create_standalone__WEBPACK_IMPORTED_MODULE_14__/* .StandaloneWalletCreatorDialog */ .e, {})
                    }),
                    subpath.url.pathname === "/create/readonly" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_libs_ui_dialog_dialog__WEBPACK_IMPORTED_MODULE_1__/* .Dialog2 */ .gP, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_create_readonly__WEBPACK_IMPORTED_MODULE_13__/* .ReadonlyWalletCreatorDialog */ .V, {})
                    })
                ]
            }),
            Header,
            Body
        ]
    });
}
function ClickableWalletGrid(props) {
    const { wallets, ok, disableNew } = props;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "grid grow place-content-start gap-2 grid-cols-[repeat(auto-fill,minmax(10rem,1fr))]",
        children: [
            wallets === null || wallets === void 0 ? void 0 : wallets.map((wallet)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(ClickableWalletCard, {
                    wallet: wallet,
                    ok: ok
                }, wallet.uuid)),
            !disableNew && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(NewRectangularAnchorCard, {
                children: "New wallet"
            })
        ]
    });
}
function SelectableWalletGrid(props) {
    const { wallets, ok, selecteds, disableNew } = props;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "grid grow place-content-start gap-2 grid-cols-[repeat(auto-fill,minmax(10rem,1fr))]",
        children: [
            wallets === null || wallets === void 0 ? void 0 : wallets.map((wallet)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(CheckableWalletCard, {
                    wallet: wallet,
                    index: selecteds.indexOf(wallet),
                    ok: ok
                }, wallet.uuid)),
            !disableNew && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(NewRectangularAnchorCard, {
                children: "New wallet"
            })
        ]
    });
}
function CheckableWalletCard(props) {
    const { wallet, ok, index } = props;
    const checked = index !== -1;
    const onClick = (0,react__WEBPACK_IMPORTED_MODULE_6__.useCallback)(()=>{
        ok(wallet);
    }, [
        ok,
        wallet
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        className: "w-full aspect-video rounded-xl overflow-hidden cursor-pointer aria-checked:outline aria-checked:outline-2 aria-checked:outline-blue-600 animate-vibrate-loop",
        role: "checkbox",
        "aria-checked": checked,
        onClick: onClick,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_context__WEBPACK_IMPORTED_MODULE_10__/* .WalletDataProvider */ .lp, {
            uuid: wallet.uuid,
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_card__WEBPACK_IMPORTED_MODULE_9__/* .RawWalletDataCard */ .tM, {
                index: index
            })
        })
    });
}
function ClickableWalletCard(props) {
    const { wallet, ok } = props;
    const onClick = (0,react__WEBPACK_IMPORTED_MODULE_6__.useCallback)(()=>{
        ok(wallet);
    }, [
        ok,
        wallet
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        className: "w-full aspect-video rounded-xl overflow-hidden cursor-pointer hovered-or-clicked-or-focused:scale-105 !transition-transform",
        role: "button",
        onClick: onClick,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_context__WEBPACK_IMPORTED_MODULE_10__/* .WalletDataProvider */ .lp, {
            uuid: wallet.uuid,
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_card__WEBPACK_IMPORTED_MODULE_9__/* .RawWalletDataCard */ .tM, {})
        })
    });
}
function NewRectangularAnchorCard(props) {
    const path = (0,_mods_foreground_router_path_context__WEBPACK_IMPORTED_MODULE_5__/* .usePathContext */ .td)().unwrap();
    const { children } = props;
    const subpath = (0,_mods_foreground_router_path_context__WEBPACK_IMPORTED_MODULE_5__/* .useHashSubpath */ .IL)(path);
    const creator = (0,_users_all_page__WEBPACK_IMPORTED_MODULE_7__/* .useGenius */ .y6)(subpath, "/create");
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
        className: "po-md w-full aspect-video rounded-xl flex gap-2 justify-center items-center border border-contrast border-dashed active:scale-90 transition-transform",
        onContextMenu: creator.onContextMenu,
        onKeyDown: creator.onKeyDown,
        onClick: creator.onClick,
        href: creator.href,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_libs_icons_icons__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                className: "size-5"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "font-medium",
                children: children
            })
        ]
    });
}


/***/ }),

/***/ 8350:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Ai: function() { return /* binding */ UserRejectedError; }
/* harmony export */ });
/* unused harmony exports UnauthorizedError, UnsupportedMethodError, DisconnectedError, ChainDisconnectedError */
/* harmony import */ var _swc_helpers_class_private_field_get__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7121);
/* harmony import */ var _swc_helpers_class_private_field_init__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9886);
/* harmony import */ var _swc_helpers_class_private_field_set__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5321);
/* harmony import */ var _hazae41_jsonrpc__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(667);



var _a, _b, _c, _d, _e;

var _class = /*#__PURE__*/ new WeakMap();
class UserRejectedError extends _hazae41_jsonrpc__WEBPACK_IMPORTED_MODULE_0__/* .RpcError */ .lt {
    static new() {
        return new _a();
    }
    constructor(){
        super(4001, "The user rejected the request.");
        (0,_swc_helpers_class_private_field_init__WEBPACK_IMPORTED_MODULE_1__._)(this, _class, {
            writable: true,
            value: void 0
        });
        (0,_swc_helpers_class_private_field_set__WEBPACK_IMPORTED_MODULE_2__._)(this, _class, _a);
        this.name = (0,_swc_helpers_class_private_field_get__WEBPACK_IMPORTED_MODULE_3__._)(this, _class).name;
    }
}
_a = UserRejectedError;
var _class1 = /*#__PURE__*/ new WeakMap();
class UnauthorizedError extends _hazae41_jsonrpc__WEBPACK_IMPORTED_MODULE_0__/* .RpcError */ .lt {
    static new() {
        return new _b();
    }
    constructor(){
        super(4100, "The requested method and/or account has not been authorized by the user.");
        (0,_swc_helpers_class_private_field_init__WEBPACK_IMPORTED_MODULE_1__._)(this, _class1, {
            writable: true,
            value: void 0
        });
        (0,_swc_helpers_class_private_field_set__WEBPACK_IMPORTED_MODULE_2__._)(this, _class1, _b);
        this.name = (0,_swc_helpers_class_private_field_get__WEBPACK_IMPORTED_MODULE_3__._)(this, _class1).name;
    }
}
_b = UnauthorizedError;
var _class2 = /*#__PURE__*/ new WeakMap();
class UnsupportedMethodError extends _hazae41_jsonrpc__WEBPACK_IMPORTED_MODULE_0__/* .RpcError */ .lt {
    static new() {
        return new _c();
    }
    constructor(){
        super(4200, "The Provider does not support the requested method.");
        (0,_swc_helpers_class_private_field_init__WEBPACK_IMPORTED_MODULE_1__._)(this, _class2, {
            writable: true,
            value: void 0
        });
        (0,_swc_helpers_class_private_field_set__WEBPACK_IMPORTED_MODULE_2__._)(this, _class2, _c);
        this.name = (0,_swc_helpers_class_private_field_get__WEBPACK_IMPORTED_MODULE_3__._)(this, _class2).name;
    }
}
_c = UnsupportedMethodError;
var _class3 = /*#__PURE__*/ new WeakMap();
class DisconnectedError extends _hazae41_jsonrpc__WEBPACK_IMPORTED_MODULE_0__/* .RpcError */ .lt {
    static new() {
        return new _d();
    }
    constructor(){
        super(4900, "The Provider is disconnected from all chains.");
        (0,_swc_helpers_class_private_field_init__WEBPACK_IMPORTED_MODULE_1__._)(this, _class3, {
            writable: true,
            value: void 0
        });
        (0,_swc_helpers_class_private_field_set__WEBPACK_IMPORTED_MODULE_2__._)(this, _class3, _d);
        this.name = (0,_swc_helpers_class_private_field_get__WEBPACK_IMPORTED_MODULE_3__._)(this, _class3).name;
    }
}
_d = DisconnectedError;
var _class4 = /*#__PURE__*/ new WeakMap();
class ChainDisconnectedError extends _hazae41_jsonrpc__WEBPACK_IMPORTED_MODULE_0__/* .RpcError */ .lt {
    static new() {
        return new _e();
    }
    constructor(){
        super(4901, "The Provider is not connected to the requested chain.");
        (0,_swc_helpers_class_private_field_init__WEBPACK_IMPORTED_MODULE_1__._)(this, _class4, {
            writable: true,
            value: void 0
        });
        (0,_swc_helpers_class_private_field_set__WEBPACK_IMPORTED_MODULE_2__._)(this, _class4, _e);
        this.name = (0,_swc_helpers_class_private_field_get__WEBPACK_IMPORTED_MODULE_3__._)(this, _class4).name;
    }
}
_e = ChainDisconnectedError;


/***/ }),

/***/ 9295:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   l: function() { return /* binding */ NavBar; }
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _libs_browser_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2650);
/* harmony import */ var _libs_errors_errors__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(783);
/* harmony import */ var _libs_icons_icons__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9881);
/* harmony import */ var _libs_react_callback__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2702);
/* harmony import */ var _libs_ui_button__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1203);
/* harmony import */ var _router_path_context__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9046);







function NavBar() {
    const { url } = (0,_router_path_context__WEBPACK_IMPORTED_MODULE_5__/* .usePathContext */ .td)().unwrap();
    const openOrAlert = (0,_libs_react_callback__WEBPACK_IMPORTED_MODULE_3__/* .useAsyncUniqueCallback */ .T)(()=>_libs_errors_errors__WEBPACK_IMPORTED_MODULE_2__/* .Errors */ .D.runAndLogAndAlert(async ()=>{
            await _libs_browser_browser__WEBPACK_IMPORTED_MODULE_1__/* .BrowserError */ .v.runOrThrow(()=>_libs_browser_browser__WEBPACK_IMPORTED_MODULE_1__.browser.tabs.create({
                    url: "index.html?_=".concat(encodeURIComponent(_router_path_context__WEBPACK_IMPORTED_MODULE_5__/* .Paths */ .nB.path(url)))
                }));
        }), [
        url
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        className: "w-full po-md border-b border-b-contrast flex items-center",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "bg-contrast rounded-xl po-sm grow flex items-center min-w-0",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "grow whitespace-nowrap overflow-hidden text-ellipsis text-sm",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                            className: "text-contrast",
                            children: "brume://"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                            children: url.pathname.slice(1)
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                    className: "w-2"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_libs_ui_button__WEBPACK_IMPORTED_MODULE_4__/* .Button.Base */ .z.X, {
                    className: "text-contrast hovered-or-clicked-or-focused:scale-105 !transition",
                    onClick: openOrAlert.run,
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: "".concat(_libs_ui_button__WEBPACK_IMPORTED_MODULE_4__/* .Button.Shrinker */ .z.N.className),
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_libs_icons_icons__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                            className: "size-4"
                        })
                    })
                })
            ]
        })
    });
}


/***/ }),

/***/ 690:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  aV: function() { return /* binding */ Overlay; }
});

// UNUSED EXPORTS: ExtensionOverlay, OtherOverlay, UpdateBanner, WebsiteOverlay

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
// EXTERNAL MODULE: ./src/libs/browser/browser.ts
var browser = __webpack_require__(2650);
;// CONCATENATED MODULE: ./src/libs/fetch/fetch.ts

async function tryFetchAsJson(input, init) {
    return Result.runAndDoubleWrap(()=>fetchAsJsonOrThrow(input, init));
}
async function fetchAsJsonOrThrow(input, init) {
    const res = await fetch(input, init);
    if (!res.ok) throw new Error(await res.text());
    return await res.json();
}
async function tryFetchAsBlob(input, init) {
    return Result.runAndDoubleWrap(()=>fetchAsBlobOrThrow(input, init));
}
async function fetchAsBlobOrThrow(input, init) {
    const res = await fetch(input, init);
    if (!res.ok) throw new Error(await res.text());
    return await res.blob();
}

// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/ArrowPathIcon.js
var ArrowPathIcon = __webpack_require__(2280);
// EXTERNAL MODULE: ./src/libs/platform/platform.ts
var platform = __webpack_require__(9686);
;// CONCATENATED MODULE: ./src/libs/semver/semver.ts
var Semver;
(function(Semver) {
    function isGreater(left, right) {
        const [la, lb, lc] = left.split(".").map((x)=>parseInt(x));
        const [ra, rb, rc] = right.split(".").map((x)=>parseInt(x));
        if (la > ra) return true;
        if (lb > rb) return true;
        if (lc > rc) return true;
        return false;
    }
    Semver.isGreater = isGreater;
})(Semver || (Semver = {}));

// EXTERNAL MODULE: ./src/libs/ui/button.tsx + 3 modules
var ui_button = __webpack_require__(1203);
// EXTERNAL MODULE: ./node_modules/@hazae41/option/dist/esm/mods/option/none.mjs
var none = __webpack_require__(1371);
// EXTERNAL MODULE: ./node_modules/react/index.js
var react = __webpack_require__(7294);
// EXTERNAL MODULE: ./src/mods/foreground/background/context.tsx + 4 modules
var context = __webpack_require__(3891);
;// CONCATENATED MODULE: ./src/mods/foreground/overlay/overlay.tsx










const MAIN_PACKAGE_URL = "https://raw.githubusercontent.com/brumewallet/wallet/main/package.json";
function UpdateBanner(props) {
    const { ok } = props;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
        className: "w-full text-white bg-green-500 po-sm",
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "w-full max-w-[400px] m-auto flex flex-wrap gap-2 items-center text-sm",
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "grow",
                    children: "An update is available"
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.Base */.z.X, {
                    className: "hovered-or-clicked-or-focused:scale-105 !transition",
                    onClick: ok,
                    children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "".concat(ui_button/* Button.Shrinker */.z.N.className),
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(ArrowPathIcon/* default */.Z, {
                                className: "size-5"
                            }),
                            "Update"
                        ]
                    })
                })
            ]
        })
    });
}
function Overlay(props) {
    const { children } = props;
    if ((0,platform/* isWebsite */.hC)()) return /*#__PURE__*/ (0,jsx_runtime.jsx)(WebsiteOverlay, {
        children: children
    });
    if ((0,platform/* isExtension */.p1)()) return /*#__PURE__*/ (0,jsx_runtime.jsx)(ExtensionOverlay, {
        children: children
    });
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(OtherOverlay, {
        children: children
    });
}
async function checkWebsiteUpdateOrThrow() {
    const cached = await fetchAsJsonOrThrow("/manifest.json");
    const current = await fetchAsJsonOrThrow("/manifest.json?");
    if (current.version !== cached.version) return false; // Will be handled by SW
    const main = await fetchAsJsonOrThrow(MAIN_PACKAGE_URL);
    return Semver.isGreater(main.version, cached.version);
}
function WebsiteOverlay(props) {
    const { children } = props;
    const background = (0,context/* useBackgroundContext */.D_)().unwrap();
    const [updating, setUpdating] = (0,react.useState)();
    (0,react.useEffect)(()=>{
        const onUpdate = (sw)=>{
            setUpdating(sw);
            return new none/* None */.H();
        };
        return background.serviceWorker.on("update", onUpdate);
    }, [
        background
    ]);
    const update = (0,react.useCallback)(()=>{
        updating === null || updating === void 0 ? void 0 : updating.postMessage("SKIP_WAITING");
    }, [
        updating
    ]);
    const [updatable, setUpdatable] = (0,react.useState)(false);
    (0,react.useEffect)(()=>{
        checkWebsiteUpdateOrThrow().then(setUpdatable).catch(console.warn);
    }, []);
    const update2 = (0,react.useCallback)(()=>{
        open("https://github.com/brumewallet/wallet/releases", "_blank", "noreferrer");
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            updating && /*#__PURE__*/ (0,jsx_runtime.jsx)(UpdateBanner, {
                ok: update
            }),
            updatable && /*#__PURE__*/ (0,jsx_runtime.jsx)(UpdateBanner, {
                ok: update2
            }),
            children
        ]
    });
}
async function checkDevExtensionUpdateOrThrow(self) {
    const main = await fetchAsJsonOrThrow(MAIN_PACKAGE_URL);
    return Semver.isGreater(main.version, self.version);
}
async function checkExtensionUpdateOrThrow() {
    const self = await browser/* BrowserError */.v.runOrThrow(()=>browser.browser.management.getSelf());
    if (self.installType === "development") return await checkDevExtensionUpdateOrThrow(self);
    return false;
}
function ExtensionOverlay(props) {
    const { children } = props;
    const [updatable, setUpdatable] = (0,react.useState)(false);
    (0,react.useEffect)(()=>{
        checkExtensionUpdateOrThrow().then(setUpdatable).catch(console.warn);
    }, []);
    const update = (0,react.useCallback)(()=>{
        open("https://github.com/brumewallet/wallet/releases", "_blank", "noreferrer");
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            updatable && /*#__PURE__*/ (0,jsx_runtime.jsx)(UpdateBanner, {
                ok: update
            }),
            children
        ]
    });
}
function OtherOverlay(props) {
    const { children } = props;
    const [updatable, setUpdatable] = (0,react.useState)(false);
    (0,react.useEffect)(()=>{
    // TODO 
    }, []);
    const update = (0,react.useCallback)(()=>{
        open("https://github.com/brumewallet/wallet/releases", "_blank", "noreferrer");
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            updatable && /*#__PURE__*/ (0,jsx_runtime.jsx)(UpdateBanner, {
                ok: update
            }),
            children
        ]
    });
}


/***/ }),

/***/ 3068:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  F: function() { return /* binding */ Router; }
});

// UNUSED EXPORTS: Layout

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
// EXTERNAL MODULE: ./src/libs/platform/platform.ts
var platform = __webpack_require__(9686);
// EXTERNAL MODULE: ./pages/popup.tsx + 2 modules
var popup = __webpack_require__(4811);
// EXTERNAL MODULE: ./src/libs/errors/errors.ts
var errors = __webpack_require__(783);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/TrashIcon.js
var TrashIcon = __webpack_require__(5836);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/CubeTransparentIcon.js
var CubeTransparentIcon = __webpack_require__(5720);
// EXTERNAL MODULE: ./src/libs/react/callback.tsx
var callback = __webpack_require__(2702);
// EXTERNAL MODULE: ./node_modules/react/index.js
var react = __webpack_require__(7294);
;// CONCATENATED MODULE: ./src/libs/ui/image/image_with_fallback.tsx


function ImageWithFallback(props) {
    const { children, src, onError, ...img } = props;
    const [error, setError] = (0,react.useState)(false);
    (0,react.useEffect)(()=>setError(false), [
        src
    ]);
    const onError2 = (0,react.useCallback)((event)=>{
        setError(true);
        return onError === null || onError === void 0 ? void 0 : onError(event);
    }, [
        onError
    ]);
    if (error) return /*#__PURE__*/ (0,jsx_runtime.jsx)(jsx_runtime.Fragment, {
        children: children
    });
    if (src == null) return /*#__PURE__*/ (0,jsx_runtime.jsx)(jsx_runtime.Fragment, {
        children: children
    });
    // eslint-disable-next-line jsx-a11y/alt-text, @next/next/no-img-element
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("img", {
        src: src,
        onError: onError2,
        ...img
    });
}

// EXTERNAL MODULE: ./src/libs/ui2/page/header.tsx
var header = __webpack_require__(7480);
// EXTERNAL MODULE: ./src/libs/ui2/page/page.tsx
var page = __webpack_require__(6698);
// EXTERNAL MODULE: ./src/libs/url/url.ts
var url = __webpack_require__(445);
// EXTERNAL MODULE: ./src/mods/foreground/background/context.tsx + 4 modules
var context = __webpack_require__(3891);
// EXTERNAL MODULE: ./src/mods/foreground/errors/errors.ts
var errors_errors = __webpack_require__(8350);
// EXTERNAL MODULE: ./src/mods/foreground/router/path/context.tsx
var path_context = __webpack_require__(9046);
// EXTERNAL MODULE: ./node_modules/@hazae41/jsonrpc/dist/esm/mods/rpc/err.mjs
var err = __webpack_require__(667);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/err.mjs
var result_err = __webpack_require__(166);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/queries/simple/query.mjs
var query = __webpack_require__(6233);
;// CONCATENATED MODULE: ./src/mods/background/service_worker/entities/blobbys/data.ts

var BlobbyRef;
(function(BlobbyRef) {
    function create(id) {
        return {
            ref: true,
            id
        };
    }
    BlobbyRef.create = create;
    function from(blobby) {
        return create(blobby.id);
    }
    BlobbyRef.from = from;
})(BlobbyRef || (BlobbyRef = {}));
var BgBlobby;
(function(BgBlobby) {
    function key(id) {
        return "blobby/".concat(id);
    }
    BgBlobby.key = key;
    function schema(id, storage) {
        return (0,query/* createQuery */.rP)({
            key: key(id),
            storage
        });
    }
    BgBlobby.schema = schema;
})(BgBlobby || (BgBlobby = {}));

// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/react/hooks/queries/simple.mjs + 1 modules
var simple = __webpack_require__(564);
// EXTERNAL MODULE: ./src/mods/foreground/storage/user.tsx
var user = __webpack_require__(2536);
;// CONCATENATED MODULE: ./src/mods/foreground/entities/blobbys/data.ts



var FgBlobby;
(function(FgBlobby) {
    FgBlobby.key = BgBlobby.key;
    function schema(id, storage) {
        if (id == null) return;
        return (0,query/* createQuery */.rP)({
            key: FgBlobby.key(id),
            storage
        });
    }
    FgBlobby.schema = schema;
})(FgBlobby || (FgBlobby = {}));
function useBlobby(id) {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(FgBlobby.schema, [
        id,
        storage
    ]);
    return query;
}

;// CONCATENATED MODULE: ./src/mods/background/service_worker/entities/origins/data.ts

var BgOrigin;
(function(BgOrigin) {
    function key(origin) {
        return "origins/".concat(origin);
    }
    BgOrigin.key = key;
    function schema(origin, storage) {
        return (0,query/* createQuery */.rP)({
            key: key(origin),
            storage
        });
    }
    BgOrigin.schema = schema;
})(BgOrigin || (BgOrigin = {}));

;// CONCATENATED MODULE: ./src/mods/foreground/entities/origins/data.ts



var FgOrigin;
(function(FgOrigin) {
    FgOrigin.key = BgOrigin.key;
    function schema(origin, storage) {
        if (origin == null) return;
        return (0,query/* createQuery */.rP)({
            key: FgOrigin.key(origin),
            storage
        });
    }
    FgOrigin.schema = schema;
})(FgOrigin || (FgOrigin = {}));
function useOrigin(origin) {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(FgOrigin.schema, [
        origin,
        storage
    ]);
    return query;
}

// EXTERNAL MODULE: ./src/mods/foreground/entities/wallets/actions/send/index.tsx + 9 modules
var send = __webpack_require__(8856);
// EXTERNAL MODULE: ./src/mods/foreground/entities/requests/data.tsx + 1 modules
var data = __webpack_require__(6361);
;// CONCATENATED MODULE: ./src/mods/foreground/entities/requests/all/page.tsx
/* eslint-disable @next/next/no-img-element */ 


















function RequestsPage() {
    var _requestsQuery_data;
    const background = (0,context/* useBackgroundContext */.D_)().unwrap();
    const requestsQuery = (0,data/* useAppRequests */.fU)();
    const maybeRequests = (_requestsQuery_data = requestsQuery.data) === null || _requestsQuery_data === void 0 ? void 0 : _requestsQuery_data.get();
    const rejectAllOrAlert = (0,callback/* useAsyncUniqueCallback */.T)(()=>errors/* Errors */.D.runAndLogAndAlert(async ()=>{
            if (maybeRequests == null) return;
            if (!(0,platform/* isSafariExtension */.WB)() && confirm("Do you want to reject all requests?") === false) return;
            for (const { id } of maybeRequests)await background.requestOrThrow({
                method: "brume_respond",
                params: [
                    err/* RpcErr */.s6.rewrap(id, new result_err/* Err */.U(new errors_errors/* UserRejectedError */.Ai()))
                ]
            }).then((r)=>r.unwrap());
            return;
        }), [
        background,
        maybeRequests
    ]);
    const Body = /*#__PURE__*/ (0,jsx_runtime.jsx)(header/* PageBody */.xV, {
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
            className: "flex flex-col gap-2",
            children: maybeRequests === null || maybeRequests === void 0 ? void 0 : maybeRequests.map((request)=>/*#__PURE__*/ (0,jsx_runtime.jsx)(RequestRow, {
                    request: request
                }, request.id))
        })
    });
    const Header = /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(header/* UserPageHeader */.To, {
                title: "Requests",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(send/* PaddedRoundedShrinkableNakedButton */.t5, {
                    disabled: rejectAllOrAlert.loading || !Boolean(maybeRequests === null || maybeRequests === void 0 ? void 0 : maybeRequests.length),
                    onClick: rejectAllOrAlert.run,
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)(TrashIcon/* default */.Z, {
                        className: "size-5"
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "po-md flex items-center",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "text-contrast",
                    children: "Request allow you to approve various actions such as transactions and signatures. These requests are sent by applications through sessions."
                })
            })
        ]
    });
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(page/* Page */.T, {
        children: [
            Header,
            Body
        ]
    });
}
function RequestRow(props) {
    var _requestQuery_data, _originQuery_data, _maybeOriginData_icons, _iconDatas_find;
    const requestQuery = (0,data/* useAppRequest */.Vd)(props.request.id);
    const maybeRequestData = (_requestQuery_data = requestQuery.data) === null || _requestQuery_data === void 0 ? void 0 : _requestQuery_data.get();
    const originQuery = useOrigin(maybeRequestData === null || maybeRequestData === void 0 ? void 0 : maybeRequestData.origin);
    const maybeOriginData = (_originQuery_data = originQuery.data) === null || _originQuery_data === void 0 ? void 0 : _originQuery_data.get();
    const [iconDatas, setIconDatas] = (0,react.useState)([]);
    const onIconData = (0,react.useCallback)((param)=>{
        let [index, data] = param;
        setIconDatas((iconDatas)=>{
            iconDatas[index] = data;
            return [
                ...iconDatas
            ];
        });
    }, []);
    if (maybeRequestData == null) return null;
    if (maybeOriginData == null) return null;
    const { id, method, params } = maybeRequestData;
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("a", {
        className: "po-md rounded-xl flex items-center gap-4",
        href: "#".concat(path_context/* Paths */.nB.path((0,url/* qurl */.d)("/".concat(method, "?id=").concat(id), params))),
        children: [
            (_maybeOriginData_icons = maybeOriginData.icons) === null || _maybeOriginData_icons === void 0 ? void 0 : _maybeOriginData_icons.map((x, i)=>/*#__PURE__*/ (0,jsx_runtime.jsx)(IndexedBlobbyLoader, {
                    index: i,
                    id: x.id,
                    ok: onIconData
                }, x.id)),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "shrink-0",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(ImageWithFallback, {
                    className: "size-10",
                    alt: "icon",
                    src: (_iconDatas_find = iconDatas.find(Boolean)) === null || _iconDatas_find === void 0 ? void 0 : _iconDatas_find.data,
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)(CubeTransparentIcon/* default */.Z, {
                        className: "size-10"
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "grow",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "font-medium",
                        children: maybeOriginData.title
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "text-contrast",
                        children: maybeOriginData.origin
                    })
                ]
            })
        ]
    });
}
function IndexedBlobbyLoader(props) {
    const { index, id, ok } = props;
    const { data } = useBlobby(id);
    (0,react.useEffect)(()=>{
        ok([
            index,
            data === null || data === void 0 ? void 0 : data.inner
        ]);
    }, [
        index,
        data,
        ok
    ]);
    return null;
}

// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/PlusIcon.js
var PlusIcon = __webpack_require__(8105);
// EXTERNAL MODULE: ./src/libs/ui/dialog/dialog.tsx
var dialog = __webpack_require__(6202);
// EXTERNAL MODULE: ./src/libs/ui2/menu/menu.tsx
var menu_menu = __webpack_require__(5857);
// EXTERNAL MODULE: ./src/mods/foreground/entities/users/all/page.tsx + 18 modules
var all_page = __webpack_require__(4190);
// EXTERNAL MODULE: ./src/mods/foreground/entities/wallets/all/page.tsx
var wallets_all_page = __webpack_require__(5750);
// EXTERNAL MODULE: ./src/libs/colors/colors.ts
var colors = __webpack_require__(1311);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/EllipsisHorizontalIcon.js
var EllipsisHorizontalIcon = __webpack_require__(3760);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/ArrowLeftIcon.js
var ArrowLeftIcon = __webpack_require__(8223);
// EXTERNAL MODULE: ./node_modules/react-dom/index.js
var react_dom = __webpack_require__(3935);
// EXTERNAL MODULE: ./src/mods/foreground/entities/wallets/card.tsx
var card = __webpack_require__(5007);
// EXTERNAL MODULE: ./node_modules/@hazae41/option/dist/esm/mods/option/option.mjs
var option_option = __webpack_require__(5316);
// EXTERNAL MODULE: ./src/mods/foreground/entities/seeds/data.tsx
var seeds_data = __webpack_require__(7866);
;// CONCATENATED MODULE: ./src/mods/foreground/entities/seeds/context.tsx




const SeedDataContext = /*#__PURE__*/ (0,react.createContext)(undefined);
function useSeedDataContext() {
    return option_option/* Option */.W.wrap((0,react.useContext)(SeedDataContext));
}
function SeedDataProvider(props) {
    const { uuid, children } = props;
    const seed = (0,seeds_data/* useSeed */.WJ)(uuid);
    if (seed.current == null) return null;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(SeedDataContext.Provider, {
        value: seed.current.get(),
        children: children
    });
}

;// CONCATENATED MODULE: ./src/mods/foreground/entities/seeds/card.tsx









function RawSeedDataCard(props) {
    const seed = useSeedDataContext().unwrap();
    const { href, index, flip, unflip } = props;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(RawSeedCard, {
        name: seed.name,
        emoji: seed.emoji,
        color: colors/* Color */.I.get(seed.color),
        flip: flip,
        unflip: unflip,
        index: index,
        href: href
    });
}
function RawSeedCard(props) {
    const path = (0,path_context/* usePathContext */.td)().unwrap();
    const { name, emoji, color, href, index, flip, unflip } = props;
    const subpath = (0,path_context/* useHashSubpath */.IL)(path);
    const genius = (0,all_page/* useGenius */.y6)(subpath, href);
    const [preflip = false, setPreflip] = (0,react.useState)(flip);
    const [postflip, setPostflip] = (0,react.useState)(false);
    const onFlipTransitionEnd = (0,react.useCallback)(()=>{
        (0,react_dom.flushSync)(()=>setPostflip(preflip));
    }, [
        preflip
    ]);
    (0,react.useEffect)(()=>{
        if (preflip) return;
        if (postflip) return;
        unflip === null || unflip === void 0 ? void 0 : unflip();
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        preflip,
        postflip
    ]);
    const First = /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "flex items-center",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "shrink-0 text-xl",
                children: emoji
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "w-2 grow"
            }),
            index == null && href != null && /*#__PURE__*/ (0,jsx_runtime.jsx)(card/* CircularWhiteAnchorInColoredCard */.ap, {
                onKeyDown: genius.onKeyDown,
                onClick: genius.onClick,
                href: genius.href,
                color: color,
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(EllipsisHorizontalIcon/* default */.Z, {
                    className: "size-4"
                })
            }),
            index != null && index !== -1 && /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "border-2 border-white flex items-center justify-center rounded-full overflow-hidden",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "bg-blue-600 flex items-center justify-center size-5 text-white font-medium",
                    children: index + 1
                })
            }),
            index != null && index === -1 && /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "border-2 border-contrast flex items-center justify-center rounded-full",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "size-5"
                })
            })
        ]
    });
    const Name = /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
        className: "flex items-center text-white font-medium",
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
            className: "truncate",
            children: name
        })
    });
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
        className: "w-full h-full",
        style: {
            perspective: "1000px"
        },
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "relative z-10 w-full h-full text-white bg-".concat(color, "-400 dark:bg-").concat(color, "-500 rounded-xl ").concat(preflip && !postflip ? "animate-flip-in" : "", " ").concat(!preflip && postflip ? "animate-flip-out" : ""),
            style: {
                transform: preflip && postflip ? "rotateY(180deg)" : "",
                transformStyle: "preserve-3d"
            },
            onAnimationEnd: onFlipTransitionEnd,
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                    className: "po-md absolute w-full h-full flex flex-col",
                    style: {
                        backfaceVisibility: "hidden"
                    },
                    onContextMenu: genius.onContextMenu,
                    children: [
                        First,
                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "grow"
                        }),
                        Name
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                    className: "po-md absolute w-full h-full flex flex-col",
                    style: {
                        backfaceVisibility: "hidden",
                        transform: "rotateY(180deg)"
                    },
                    onContextMenu: genius.onContextMenu,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "flex items-center",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    className: "w-2 grow"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)(card/* CircularWhiteButtonInColoredCard */.ew, {
                                    onClick: ()=>setPreflip === null || setPreflip === void 0 ? void 0 : setPreflip(false),
                                    color: color,
                                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)(ArrowLeftIcon/* default */.Z, {
                                        className: "size-4"
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "grow"
                        })
                    ]
                })
            ]
        })
    });
}

// EXTERNAL MODULE: ./src/libs/browser/browser.ts
var browser = __webpack_require__(2650);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/DocumentTextIcon.js
var DocumentTextIcon = __webpack_require__(3952);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/SwatchIcon.js
var SwatchIcon = __webpack_require__(9822);
;// CONCATENATED MODULE: ./src/mods/foreground/entities/seeds/all/create/index.tsx









function SeedCreatorMenu(props) {
    const close = (0,dialog/* useCloseContext */.gX)().unwrap();
    const path = (0,path_context/* usePathContext */.td)().unwrap();
    const mnemonic = (0,all_page/* useGenius */.y6)(path, "/create/mnemonic");
    const hardware = (0,all_page/* useGenius */.y6)(path, "/create/hardware");
    const openHardwareOrAlert = (0,callback/* useAsyncUniqueCallback */.T)((e)=>errors/* Errors */.D.runAndLogAndAlert(async ()=>{
            await browser/* BrowserError */.v.runOrThrow(()=>browser.browser.tabs.create({
                    url: "index.html?_=".concat(encodeURIComponent(path.go("/create/hardware").hash.slice(1)))
                }));
            close();
        }), [
        path,
        close
    ]);
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "flex flex-col text-left gap-2",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(send/* WideShrinkableNakedMenuAnchor */.s_, {
                onClick: mnemonic.onClick,
                onKeyDown: mnemonic.onKeyDown,
                href: mnemonic.href,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(DocumentTextIcon/* default */.Z, {
                        className: "size-4"
                    }),
                    "Mnemonic"
                ]
            }),
            location.pathname !== "/" && location.pathname !== "/index.html" && /*#__PURE__*/ (0,jsx_runtime.jsxs)(send/* WideShrinkableNakedMenuButton */.vD, {
                disabled: openHardwareOrAlert.loading,
                onClick: openHardwareOrAlert.run,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(SwatchIcon/* default */.Z, {
                        className: "size-4"
                    }),
                    "Hardware"
                ]
            }),
            (location.pathname === "/" || location.pathname === "/index.html") && /*#__PURE__*/ (0,jsx_runtime.jsxs)(send/* WideShrinkableNakedMenuAnchor */.s_, {
                onClick: hardware.onClick,
                onKeyDown: hardware.onKeyDown,
                href: hardware.href,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(SwatchIcon/* default */.Z, {
                        className: "size-4"
                    }),
                    "Hardware"
                ]
            })
        ]
    });
}

// EXTERNAL MODULE: ./src/libs/emojis/emojis.ts
var emojis = __webpack_require__(1792);
// EXTERNAL MODULE: ./src/libs/ledger/index.ts + 14 modules
var ledger = __webpack_require__(5625);
// EXTERNAL MODULE: ./src/libs/modhash/modhash.ts
var modhash_modhash = __webpack_require__(2637);
// EXTERNAL MODULE: ./src/libs/react/events.ts
var events = __webpack_require__(904);
// EXTERNAL MODULE: ./src/libs/react/ref.ts + 1 modules
var ref = __webpack_require__(9195);
// EXTERNAL MODULE: ./src/libs/uuid/uuid.ts
var uuid_uuid = __webpack_require__(6655);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/errors.mjs
var result_errors = __webpack_require__(2564);
;// CONCATENATED MODULE: ./src/mods/foreground/entities/seeds/all/create/hardware.tsx
/* eslint-disable @next/next/no-img-element */ 


















function LedgerSeedCreatorDialog(props) {
    const path = (0,path_context/* usePathContext */.td)().unwrap();
    const close = (0,dialog/* useCloseContext */.gX)().unwrap();
    const background = (0,context/* useBackgroundContext */.D_)().unwrap();
    const subpath = (0,path_context/* useHashSubpath */.IL)(path);
    const connect = (0,all_page/* useGenius */.y6)(subpath, "/connect");
    const uuid = (0,ref/* useConstant */.hS)(()=>(0,uuid_uuid/* randomUUID */.H)());
    const modhash = (0,modhash_modhash/* useModhash */.jR)(uuid);
    const color = colors/* Color */.I.get(modhash);
    const emoji = emojis/* Emojis */.A.get(modhash);
    const [rawNameInput = "", setRawNameInput] = (0,react.useState)();
    const defNameInput = (0,react.useDeferredValue)(rawNameInput);
    const onNameInputChange = (0,events/* useInputChange */.Xy)((e)=>{
        setRawNameInput(e.currentTarget.value);
    }, []);
    const finalNameInput = (0,react.useMemo)(()=>{
        return defNameInput || "Holder";
    }, [
        defNameInput
    ]);
    const addOrAlert = (0,callback/* useAsyncUniqueCallback */.T)(()=>errors/* Errors */.D.runAndLogAndAlert(async ()=>{
            if (!finalNameInput) return new result_err/* Err */.U(new result_errors/* Panic */.F());
            const device = await ledger/* Ledger.USB.tryConnect */.P.vB.tryConnect().then((r)=>r.unwrap());
            const { address } = await ledger/* Ledger.Ethereum.tryGetAddress */.P.kJ.tryGetAddress(device, "44'/60'/0'/0/0").then((r)=>r.unwrap());
            const seed = {
                type: "ledger",
                uuid,
                name: finalNameInput,
                color: colors/* Color */.I.all.indexOf(color),
                emoji,
                address
            };
            await background.requestOrThrow({
                method: "brume_createSeed",
                params: [
                    seed
                ]
            }).then((r)=>r.unwrap());
            close();
        }), [
        finalNameInput,
        uuid,
        color,
        emoji,
        background,
        close
    ]);
    const NameInput = /*#__PURE__*/ (0,jsx_runtime.jsxs)(send/* SimpleLabel */.JJ, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "shrink-0",
                children: "Name"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "w-4"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)(send/* SimpleInput */.Jc, {
                placeholder: "Holder",
                value: rawNameInput,
                onChange: onNameInputChange
            })
        ]
    });
    const canAdd = (0,react.useMemo)(()=>{
        if (!finalNameInput) return false;
        return true;
    }, [
        finalNameInput
    ]);
    const AddButton = /*#__PURE__*/ (0,jsx_runtime.jsxs)(send/* WideShrinkableGradientButton */.sz, {
        color: color,
        disabled: !canAdd,
        onClick: addOrAlert.run,
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(PlusIcon/* default */.Z, {
                className: "size-5"
            }),
            "Add"
        ]
    });
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(path_context/* HashSubpathProvider */.qd, {
                children: subpath.url.pathname === "/connect" && /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Dialog2 */.gP, {
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)(HardwareSelectDialog, {})
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Dialog */.Vq.Title, {
                children: "New seed"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-4"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "flex-1 flex flex-col items-center justify-center",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "w-full max-w-sm",
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-full aspect-video rounded-xl",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(RawSeedCard, {
                            name: finalNameInput,
                            emoji: emoji,
                            color: color
                        })
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-2"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "flex-1 flex flex-col",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "grow"
                    }),
                    NameInput,
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-4"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "flex items-center flex-wrap-reverse gap-2",
                        children: AddButton
                    })
                ]
            })
        ]
    });
}
function HardwareSelectDialog() {
    const [devices, setDevices] = (0,react.useState)([]);
    const getDevices = (0,react.useCallback)(()=>{
        navigator.usb.getDevices().then(setDevices);
    }, []);
    (0,react.useEffect)(()=>{
        const i = setInterval(getDevices, 1000);
        getDevices();
        return ()=>clearInterval(i);
    }, [
        getDevices
    ]);
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Dialog */.Vq.Title, {
                children: "Connect a hardware wallet"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-4"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "flex flex-col gap-2",
                children: [
                    devices.map((device)=>/*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "po-md bg-contrast rounded-xl flex items-center",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("img", {
                                    className: "h-16 w-auto",
                                    src: "/assets/devices/ledger_nano_s.png",
                                    alt: "Ledger Nano S"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    className: "w-4"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: "",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                            className: "",
                                            children: device.productName
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                            className: "text-contrast",
                                            children: [
                                                device.manufacturerName,
                                                ", ",
                                                device.deviceVersionMajor,
                                                ".",
                                                device.deviceVersionMinor,
                                                ".",
                                                device.deviceVersionSubminor
                                            ]
                                        })
                                    ]
                                })
                            ]
                        }, device.serialNumber)),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "po-md rounded-xl border border-contrast border-dashed flex items-center justify-center gap-2 h-[80px]",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(PlusIcon/* default */.Z, {
                                className: "size-5"
                            }),
                            "New device"
                        ]
                    })
                ]
            })
        ]
    });
}

// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/KeyIcon.js
var KeyIcon = __webpack_require__(4357);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/LockClosedIcon.js
var LockClosedIcon = __webpack_require__(651);
// EXTERNAL MODULE: ./src/libs/react/memo.ts + 1 modules
var memo = __webpack_require__(9210);
// EXTERNAL MODULE: ./src/libs/webauthn/webauthn.ts
var webauthn = __webpack_require__(789);
// EXTERNAL MODULE: ./node_modules/@hazae41/base64/dist/esm/src/mods/base64/adapter.mjs
var adapter = __webpack_require__(9467);
// EXTERNAL MODULE: ./node_modules/@hazae41/bytes/dist/esm/mods/bytes/bytes.mjs + 3 modules
var bytes = __webpack_require__(1694);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/result.mjs
var result = __webpack_require__(918);
// EXTERNAL MODULE: ./node_modules/@scure/bip39/esm/index.js + 9 modules
var esm = __webpack_require__(3575);
// EXTERNAL MODULE: ./node_modules/@scure/bip39/esm/wordlists/english.js
var english = __webpack_require__(5957);
;// CONCATENATED MODULE: ./src/mods/foreground/entities/seeds/all/create/mnemonic.tsx

var __addDisposableResource = undefined && undefined.__addDisposableResource || function(env, value, async) {
    if (value !== null && value !== void 0) {
        if (typeof value !== "object" && typeof value !== "function") throw new TypeError("Object expected.");
        var dispose;
        if (async) {
            if (!Symbol.asyncDispose) throw new TypeError("Symbol.asyncDispose is not defined.");
            dispose = value[Symbol.asyncDispose];
        }
        if (dispose === void 0) {
            if (!Symbol.dispose) throw new TypeError("Symbol.dispose is not defined.");
            dispose = value[Symbol.dispose];
        }
        if (typeof dispose !== "function") throw new TypeError("Object not disposable.");
        env.stack.push({
            value: value,
            dispose: dispose,
            async: async
        });
    } else if (async) {
        env.stack.push({
            async: true
        });
    }
    return value;
};
var __disposeResources = undefined && undefined.__disposeResources || function(SuppressedError1) {
    return function(env) {
        function fail(e) {
            env.error = env.hasError ? new SuppressedError1(e, env.error, "An error was suppressed during disposal.") : e;
            env.hasError = true;
        }
        function next() {
            while(env.stack.length){
                var rec = env.stack.pop();
                try {
                    var result = rec.dispose && rec.dispose.call(rec.value);
                    if (rec.async) return Promise.resolve(result).then(next, function(e) {
                        fail(e);
                        return next();
                    });
                } catch (e) {
                    fail(e);
                }
            }
            if (env.hasError) throw env.error;
        }
        return next();
    };
}(typeof SuppressedError === "function" ? SuppressedError : function(error, suppressed, message) {
    var e = new Error(message);
    return e.name = "SuppressedError", e.error = error, e.suppressed = suppressed, e;
});






















function StandaloneSeedCreatorDialog(props) {
    const close = (0,dialog/* useCloseContext */.gX)().unwrap();
    const background = (0,context/* useBackgroundContext */.D_)().unwrap();
    const uuid = (0,ref/* useConstant */.hS)(()=>(0,uuid_uuid/* randomUUID */.H)());
    const modhash = (0,modhash_modhash/* useModhash */.jR)(uuid);
    const color = colors/* Color */.I.get(modhash);
    const emoji = emojis/* Emojis */.A.get(modhash);
    const [rawNameInput = "", setRawNameInput] = (0,react.useState)();
    const defNameInput = (0,react.useDeferredValue)(rawNameInput);
    const onNameInputChange = (0,events/* useInputChange */.Xy)((e)=>{
        setRawNameInput(e.currentTarget.value);
    }, []);
    const finalNameInput = (0,react.useMemo)(()=>{
        return defNameInput || "Holder";
    }, [
        defNameInput
    ]);
    const [rawPhraseInput = "", setRawPhraseInput] = (0,react.useState)();
    const defPhraseInput = (0,react.useDeferredValue)(rawPhraseInput);
    const onPhraseInputChange = (0,events/* useTextAreaChange */.aN)((e)=>{
        setRawPhraseInput(e.currentTarget.value);
    }, []);
    const generate12OrAlert = (0,react.useCallback)(()=>errors/* Errors */.D.runAndLogAndAlertSync(()=>{
            setRawPhraseInput((0,esm/* generateMnemonic */.OF)(english/* wordlist */.U, 128));
        }), []);
    const generate24OrAlert = (0,react.useCallback)(()=>errors/* Errors */.D.runAndLogAndAlertSync(()=>{
            setRawPhraseInput((0,esm/* generateMnemonic */.OF)(english/* wordlist */.U, 256));
        }), []);
    const addUnauthenticatedOrAlert = (0,callback/* useAsyncUniqueCallback */.T)(()=>errors/* Errors */.D.runAndLogAndAlert(async ()=>{
            if (!finalNameInput) throw new result_errors/* Panic */.F();
            if (!defPhraseInput) throw new result_errors/* Panic */.F();
            if (!(0,platform/* isSafariExtension */.WB)() && confirm("Did you backup your seed phrase?") === false) return;
            const seed = {
                type: "mnemonic",
                uuid,
                name: finalNameInput,
                color: colors/* Color */.I.all.indexOf(color),
                emoji,
                mnemonic: defPhraseInput
            };
            await background.requestOrThrow({
                method: "brume_createSeed",
                params: [
                    seed
                ]
            }).then((r)=>r.unwrap());
            close();
        }), [
        finalNameInput,
        defPhraseInput,
        uuid,
        color,
        emoji,
        background,
        close
    ]);
    const triedEncryptedPhrase = (0,memo/* useAsyncReplaceMemo */.EY)(()=>result/* Result */.x.runAndWrap(async ()=>{
            if (!finalNameInput) throw new result_errors/* Panic */.F();
            if (!defPhraseInput) throw new result_errors/* Panic */.F();
            const entropyBytes = (0,esm/* mnemonicToEntropy */.oy)(defPhraseInput, english/* wordlist */.U);
            const entropyBase64 = adapter/* get */.U().encodePaddedOrThrow(entropyBytes);
            const [ivBase64, cipherBase64] = await background.requestOrThrow({
                method: "brume_encrypt",
                params: [
                    entropyBase64
                ]
            }).then((r)=>r.unwrap());
            return [
                ivBase64,
                cipherBase64
            ];
        }), [
        finalNameInput,
        defPhraseInput,
        background
    ]);
    const [id, setId] = (0,react.useState)();
    (0,react.useEffect)(()=>{
        setId(undefined);
    }, [
        defPhraseInput
    ]);
    const addAuthenticatedOrAlert1 = (0,callback/* useAsyncUniqueCallback */.T)(()=>errors/* Errors */.D.runAndLogAndAlert(async ()=>{
            if (!finalNameInput) throw new result_errors/* Panic */.F();
            if (triedEncryptedPhrase == null) throw new result_errors/* Panic */.F();
            if (!(0,platform/* isSafariExtension */.WB)() && confirm("Did you backup your seed phrase?") === false) return;
            const [_, cipherBase64] = triedEncryptedPhrase.unwrap();
            const cipher = adapter/* get */.U().decodePaddedOrThrow(cipherBase64).copyAndDispose();
            const id = await webauthn/* WebAuthnStorage */.g.createOrThrow(finalNameInput, cipher);
            setId(id);
        }), [
        finalNameInput,
        triedEncryptedPhrase
    ]);
    const addAuthenticatedOrAlert2 = (0,callback/* useAsyncUniqueCallback */.T)(()=>errors/* Errors */.D.runAndLogAndAlert(async ()=>{
            const env_1 = {
                stack: [],
                error: void 0,
                hasError: false
            };
            try {
                if (id == null) throw new result_errors/* Panic */.F();
                if (!finalNameInput) throw new result_errors/* Panic */.F();
                if (triedEncryptedPhrase == null) throw new result_errors/* Panic */.F();
                const [ivBase64, cipherBase64] = triedEncryptedPhrase.unwrap();
                const cipherMemory = __addDisposableResource(env_1, adapter/* get */.U().decodePaddedOrThrow(cipherBase64), false);
                const cipherBytes = await webauthn/* WebAuthnStorage */.g.getOrThrow(id);
                if (!bytes/* Bytes */.J.equals(cipherMemory.bytes, cipherBytes)) return new result_err/* Err */.U(new webauthn/* WebAuthnStorageError */.$());
                const idBase64 = adapter/* get */.U().encodePaddedOrThrow(id);
                const mnemonic = {
                    ivBase64,
                    idBase64
                };
                const seed = {
                    type: "authMnemonic",
                    uuid,
                    name: finalNameInput,
                    color: colors/* Color */.I.all.indexOf(color),
                    emoji,
                    mnemonic
                };
                await background.requestOrThrow({
                    method: "brume_createSeed",
                    params: [
                        seed
                    ]
                }).then((r)=>r.unwrap());
                close();
            } catch (e_1) {
                env_1.error = e_1;
                env_1.hasError = true;
            } finally{
                __disposeResources(env_1);
            }
        }), [
        id,
        finalNameInput,
        triedEncryptedPhrase,
        uuid,
        color,
        emoji,
        background,
        close
    ]);
    const NameInput = /*#__PURE__*/ (0,jsx_runtime.jsxs)(send/* SimpleLabel */.JJ, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "shrink-0",
                children: "Name"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "w-4"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)(send/* SimpleInput */.Jc, {
                placeholder: "Holder",
                value: rawNameInput,
                onChange: onNameInputChange
            })
        ]
    });
    const PhraseInput = /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "po-md flex flex-col bg-contrast rounded-xl",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "flex items-start",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "shrink-0",
                        children: "Seed phrase"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-4"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(send/* SimpleTextarea */.pm, {
                        placeholder: "candy climb cloth fetch crack miss gift direct then fork prevent already increase slam code",
                        value: rawPhraseInput,
                        onChange: onPhraseInputChange,
                        rows: 5
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-2"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "flex items-center flex-wrap-reverse gap-2",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(send/* WideShrinkableContrastButton */.pN, {
                        onClick: generate12OrAlert,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(KeyIcon/* default */.Z, {
                                className: "size-5"
                            }),
                            "Generate 12 words"
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(send/* WideShrinkableContrastButton */.pN, {
                        onClick: generate24OrAlert,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(KeyIcon/* default */.Z, {
                                className: "size-5"
                            }),
                            "Generate 24 words"
                        ]
                    })
                ]
            })
        ]
    });
    const disabled = (0,react.useMemo)(()=>{
        if (!(0,esm/* validateMnemonic */._I)(defPhraseInput, english/* wordlist */.U)) return "Please enter a valid seed phrase";
        return;
    }, [
        defPhraseInput
    ]);
    const AddUnauthButton = /*#__PURE__*/ (0,jsx_runtime.jsxs)(send/* WideShrinkableContrastButton */.pN, {
        disabled: Boolean(disabled) || addUnauthenticatedOrAlert.loading,
        onClick: addUnauthenticatedOrAlert.run,
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(PlusIcon/* default */.Z, {
                className: "size-5"
            }),
            disabled || "Add without authentication"
        ]
    });
    const AddAuthButton1 = /*#__PURE__*/ (0,jsx_runtime.jsxs)(send/* WideShrinkableGradientButton */.sz, {
        color: color,
        disabled: Boolean(disabled) || addAuthenticatedOrAlert1.loading,
        onClick: addAuthenticatedOrAlert1.run,
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(LockClosedIcon/* default */.Z, {
                className: "size-5"
            }),
            disabled || "Add with authentication"
        ]
    });
    const AddAuthButton2 = /*#__PURE__*/ (0,jsx_runtime.jsxs)(send/* WideShrinkableGradientButton */.sz, {
        color: color,
        disabled: Boolean(disabled) || addAuthenticatedOrAlert2.loading,
        onClick: addAuthenticatedOrAlert2.run,
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(LockClosedIcon/* default */.Z, {
                className: "size-5"
            }),
            disabled || "Add with authentication (1/2)"
        ]
    });
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Dialog */.Vq.Title, {
                children: "New seed"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-4"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "flex-1 flex flex-col items-center justify-center",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "w-full max-w-sm",
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-full aspect-video rounded-xl",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(RawSeedCard, {
                            name: finalNameInput,
                            emoji: emoji,
                            color: color
                        })
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-2"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "flex-1 flex flex-col",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "grow"
                    }),
                    NameInput,
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-2"
                    }),
                    PhraseInput,
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-4"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "flex items-center flex-wrap-reverse gap-2",
                        children: [
                            AddUnauthButton,
                            id == null ? AddAuthButton1 : AddAuthButton2
                        ]
                    })
                ]
            })
        ]
    });
}

;// CONCATENATED MODULE: ./src/mods/foreground/entities/seeds/all/page.tsx

















function SeedsPage() {
    var _seedsQuery_data;
    const path = (0,path_context/* usePathContext */.td)().unwrap();
    const seedsQuery = (0,seeds_data/* useSeeds */.Eu)();
    const maybeSeeds = (_seedsQuery_data = seedsQuery.data) === null || _seedsQuery_data === void 0 ? void 0 : _seedsQuery_data.get();
    const subpath = (0,path_context/* useHashSubpath */.IL)(path);
    const creator = (0,all_page/* useGenius */.y6)(subpath, "/create");
    const onSeedClick = (0,react.useCallback)((seed)=>{
        location.assign("#/seed/".concat(seed.uuid));
    }, []);
    const Body = /*#__PURE__*/ (0,jsx_runtime.jsx)(header/* PageBody */.xV, {
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(ClickableSeedGrid, {
            ok: onSeedClick,
            maybeSeeds: maybeSeeds
        })
    });
    const Header = /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(header/* UserPageHeader */.To, {
                title: "Seeds",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(send/* PaddedRoundedShrinkableNakedAnchor */.wW, {
                    onKeyDown: creator.onKeyDown,
                    onClick: creator.onClick,
                    href: creator.href,
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)(PlusIcon/* default */.Z, {
                        className: "size-5"
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "po-md flex items-center",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "text-contrast",
                    children: "Seeds allow you to generate wallets from a single secret. You can import a seed from a mnemonic phrase or connect a hardware wallet."
                })
            })
        ]
    });
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(page/* Page */.T, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(path_context/* HashSubpathProvider */.qd, {
                children: [
                    subpath.url.pathname === "/create" && /*#__PURE__*/ (0,jsx_runtime.jsx)(menu_menu/* Menu */.v, {
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(SeedCreatorMenu, {})
                    }),
                    subpath.url.pathname === "/create/mnemonic" && /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Dialog2 */.gP, {
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(StandaloneSeedCreatorDialog, {})
                    }),
                    subpath.url.pathname === "/create/hardware" && /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Dialog2 */.gP, {
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(LedgerSeedCreatorDialog, {})
                    })
                ]
            }),
            Header,
            Body
        ]
    });
}
function ClickableSeedGrid(props) {
    const { ok, maybeSeeds, disableNew } = props;
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "grid grow place-content-start gap-2 grid-cols-[repeat(auto-fill,minmax(10rem,1fr))]",
        children: [
            maybeSeeds === null || maybeSeeds === void 0 ? void 0 : maybeSeeds.map((seed)=>/*#__PURE__*/ (0,jsx_runtime.jsx)(ClickableSeedCard, {
                    seed: seed,
                    ok: ok
                }, seed.uuid)),
            !disableNew && /*#__PURE__*/ (0,jsx_runtime.jsx)(wallets_all_page/* NewRectangularAnchorCard */.Gn, {
                children: "New seed"
            })
        ]
    });
}
function ClickableSeedCard(props) {
    const { seed, ok } = props;
    const onClick = (0,react.useCallback)(()=>{
        ok(seed);
    }, [
        ok,
        seed
    ]);
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
        className: "w-full aspect-video rounded-xl overflow-hidden cursor-pointer hovered-or-clicked-or-focused:scale-105 !transition-transform",
        role: "button",
        onClick: onClick,
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(SeedDataProvider, {
            uuid: seed.uuid,
            children: /*#__PURE__*/ (0,jsx_runtime.jsx)(RawSeedDataCard, {})
        })
    });
}

// EXTERNAL MODULE: ./src/mods/background/service_worker/entities/seeds/data.tsx
var entities_seeds_data = __webpack_require__(1333);
// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/types/zerohex/index.mjs
var zerohex = __webpack_require__(6113);
// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/types/address/index.mjs
var types_address = __webpack_require__(7657);
// EXTERNAL MODULE: ./node_modules/@noble/curves/esm/secp256k1.js + 2 modules
var secp256k1 = __webpack_require__(9578);
// EXTERNAL MODULE: ./node_modules/@scure/bip32/lib/esm/index.js + 15 modules
var lib_esm = __webpack_require__(9638);
// EXTERNAL MODULE: ./src/mods/foreground/entities/seeds/all/helpers.tsx + 1 modules
var helpers = __webpack_require__(4877);
// EXTERNAL MODULE: ./src/mods/foreground/entities/wallets/all/create/standalone.tsx
var standalone = __webpack_require__(4925);
;// CONCATENATED MODULE: ./src/mods/foreground/entities/wallets/all/create/seeded.tsx

























function SeededWalletCreatorDialog(props) {
    const close = (0,dialog/* useCloseContext */.gX)().unwrap();
    const background = (0,context/* useBackgroundContext */.D_)().unwrap();
    const seedData = useSeedDataContext().unwrap();
    const uuid = (0,ref/* useConstant */.hS)(()=>(0,uuid_uuid/* randomUUID */.H)());
    const modhash = (0,modhash_modhash/* useModhash */.jR)(uuid);
    const color = colors/* Color */.I.get(modhash);
    const emoji = emojis/* Emojis */.A.get(modhash);
    const [rawNameInput = "", setRawNameInput] = (0,react.useState)();
    const defNameInput = (0,react.useDeferredValue)(rawNameInput);
    const onNameInputChange = (0,events/* useInputChange */.Xy)((e)=>{
        setRawNameInput(e.currentTarget.value);
    }, []);
    const finalNameInput = (0,react.useMemo)(()=>{
        return defNameInput || "Holder";
    }, [
        defNameInput
    ]);
    const [rawPathInput = "", setRawPathInput] = (0,react.useState)();
    const defPathInput = (0,react.useDeferredValue)(rawPathInput);
    const onPathInputChange = (0,events/* useInputChange */.Xy)((e)=>{
        setRawPathInput(e.currentTarget.value);
    }, []);
    const [rawDerivation, setRawDerivation] = (0,react.useState)("eth-metamask");
    const onDerivationChange = (0,react.useCallback)((e)=>{
        setRawDerivation(e.currentTarget.value);
    }, []);
    const [rawIndexInput = "", setRawIndexInput] = (0,react.useState)("0");
    const defIndexInput = (0,react.useDeferredValue)(rawIndexInput);
    const onIndexInputChange = (0,events/* useInputChange */.Xy)((e)=>{
        setRawIndexInput(e.currentTarget.value);
    }, []);
    (0,react.useEffect)(()=>{
        if (rawDerivation === "custom") return setRawPathInput(undefined);
        const i = Number(defIndexInput).toFixed();
        if (rawDerivation === "eth-metamask") return setRawPathInput("m/44'/60'/0'/0/".concat(i));
        if (rawDerivation === "eth-ledger") return setRawPathInput("m/44'/60'/".concat(i, "'/0/0"));
        if (rawDerivation === "etc-metamask") return setRawPathInput("m/44'/61'/0'/0/".concat(i));
        if (rawDerivation === "etc-ledger") return setRawPathInput("m/44'/61'/".concat(i, "'/0/0"));
    }, [
        rawDerivation,
        defIndexInput
    ]);
    const canAdd = (0,react.useMemo)(()=>{
        if (!finalNameInput) return false;
        if (!defPathInput) return false;
        return true;
    }, [
        finalNameInput,
        defPathInput
    ]);
    const addOrAlert = (0,callback/* useAsyncUniqueCallback */.T)(()=>errors/* Errors */.D.runAndLogAndAlert(async ()=>{
            if (!finalNameInput) throw new result_errors/* Panic */.F();
            if (seedData.type === "ledger") {
                const device = await ledger/* Ledger.USB.tryConnect */.P.vB.tryConnect().then((r)=>r.mapErrSync((cause)=>{
                        return new errors/* UIError */.m("Could not connect to the device", {
                            cause
                        });
                    }).unwrap());
                const { address } = await ledger/* Ledger.Ethereum.tryGetAddress */.P.kJ.tryGetAddress(device, defPathInput.slice(2)).then((r)=>r.mapErrSync((cause)=>{
                        return new errors/* UIError */.m("Could not get the address of the device", {
                            cause
                        });
                    }).unwrap());
                if (!zerohex/* ZeroHexString */.T.is(address)) throw new errors/* UIError */.m("Could not get the address of the device");
                const seed = entities_seeds_data/* SeedRef */.M.from(seedData);
                const wallet = {
                    coin: "ethereum",
                    type: "seeded",
                    uuid,
                    name: finalNameInput,
                    color: colors/* Color */.I.all.indexOf(color),
                    emoji,
                    address,
                    seed,
                    path: defPathInput
                };
                await background.requestOrThrow({
                    method: "brume_createWallet",
                    params: [
                        wallet
                    ]
                }).then((r)=>r.mapErrSync((cause)=>{
                        return new errors/* UIError */.m("Could not create the wallet", {
                            cause
                        });
                    }).unwrap());
            } else {
                const instance = await helpers/* SeedInstance */.Gz.tryFrom(seedData, background).then((r)=>r.get());
                const mnemonic = await instance.tryGetMnemonic(background).then((r)=>r.mapErrSync((cause)=>{
                        return new errors/* UIError */.m("Could not get mnemonic", {
                            cause
                        });
                    }).unwrap());
                const masterSeed = await result/* Result */.x.runAndWrap(async ()=>{
                    return await (0,esm/* mnemonicToSeed */.OI)(mnemonic);
                }).then((r)=>r.unwrap());
                const root = result/* Result */.x.runAndWrapSync(()=>{
                    return lib_esm/* HDKey */.B.fromMasterSeed(masterSeed);
                }).unwrap();
                const child = result/* Result */.x.runAndWrapSync(()=>{
                    return root.derive(defPathInput);
                }).mapErrSync((cause)=>{
                    return new errors/* UIError */.m("Invalid derivation path", {
                        cause
                    });
                }).unwrap();
                const privateKeyBytes = option_option/* Option */.W.unwrap(child.privateKey);
                const uncompressedPublicKeyBytes = secp256k1/* secp256k1 */.kA.getPublicKey(privateKeyBytes, false);
                const address = types_address/* Address */.k.compute(uncompressedPublicKeyBytes);
                const seed = entities_seeds_data/* SeedRef */.M.from(seedData);
                const wallet = {
                    coin: "ethereum",
                    type: "seeded",
                    uuid,
                    name: finalNameInput,
                    color: colors/* Color */.I.all.indexOf(color),
                    emoji,
                    address,
                    seed,
                    path: defPathInput
                };
                await background.requestOrThrow({
                    method: "brume_createWallet",
                    params: [
                        wallet
                    ]
                }).then((r)=>r.mapErrSync((cause)=>{
                        return new errors/* UIError */.m("Could not create the wallet", {
                            cause
                        });
                    }).unwrap());
            }
            close();
        }), [
        finalNameInput,
        defPathInput,
        seedData,
        defPathInput,
        uuid,
        color,
        emoji,
        background,
        close
    ]);
    const NameInput = /*#__PURE__*/ (0,jsx_runtime.jsxs)(send/* SimpleLabel */.JJ, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "shrink-0",
                children: "Name"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "w-4"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)(send/* SimpleInput */.Jc, {
                placeholder: "Holder",
                value: rawNameInput,
                onChange: onNameInputChange
            })
        ]
    });
    const PathInput = /*#__PURE__*/ (0,jsx_runtime.jsxs)(send/* SimpleLabel */.JJ, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "shrink-0",
                children: "Path"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "w-4"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)(send/* SimpleInput */.Jc, {
                placeholder: "m/44'/60'/0'/0/0",
                value: rawPathInput,
                onChange: onPathInputChange
            })
        ]
    });
    const IndexInput = /*#__PURE__*/ (0,jsx_runtime.jsxs)(send/* SimpleLabel */.JJ, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "shrink-0",
                children: "Index"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "w-4"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)(send/* SimpleInput */.Jc, {
                placeholder: "0",
                type: "number",
                min: 0,
                value: rawIndexInput,
                onChange: onIndexInputChange
            })
        ]
    });
    const AddButon = /*#__PURE__*/ (0,jsx_runtime.jsxs)(send/* WideShrinkableGradientButton */.sz, {
        color: color,
        disabled: !finalNameInput || !canAdd,
        onClick: addOrAlert.run,
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(PlusIcon/* default */.Z, {
                className: "size-5"
            }),
            "Add"
        ]
    });
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Dialog */.Vq.Title, {
                children: "New wallet"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-4"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "flex-1 flex flex-col items-center justify-center",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "w-full max-w-sm",
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)(standalone/* EmptyRectangularCard */.Y, {})
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-2"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "flex-1 flex flex-col",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "grow"
                    }),
                    NameInput,
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-2"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(send/* SimpleLabel */.JJ, {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "shrink-0",
                                children: "Derivation"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "w-4"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("select", {
                                className: "w-full bg-transparent outline-none overflow-ellipsis overflow-x-hidden appearance-none",
                                value: rawDerivation,
                                onChange: onDerivationChange,
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("option", {
                                        value: "eth-metamask",
                                        children: "Ethereum — MetaMask-like — m/44'/60'/0'/0/x"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("option", {
                                        value: "eth-ledger",
                                        children: "Ethereum — Ledger-like - m/44'/60'/x'/0/0"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("option", {
                                        value: "etc-metamask",
                                        children: "Ethereum Classic — MetaMask-like — m/44'/61'/0'/0/x"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("option", {
                                        value: "etc-metamask",
                                        children: "Ethereum Classic — Ledger-like - m/44'/61'/x'/0/0"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("option", {
                                        value: "custom",
                                        children: "Custom"
                                    })
                                ]
                            })
                        ]
                    }),
                    rawDerivation === "custom" && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "h-2"
                            }),
                            PathInput
                        ]
                    }),
                    rawDerivation !== "custom" && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "h-2"
                            }),
                            IndexInput
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-4"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "flex items-center flex-wrap-reverse gap-2",
                        children: AddButon
                    })
                ]
            })
        ]
    });
}

// EXTERNAL MODULE: ./src/mods/foreground/entities/wallets/data.ts
var wallets_data = __webpack_require__(4844);
;// CONCATENATED MODULE: ./src/mods/foreground/entities/seeds/page.tsx











function SeedPage(props) {
    const { uuid } = props;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(SeedDataProvider, {
        uuid: uuid,
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(SeedDataPage, {})
    });
}
function SeedDataPage() {
    var _walletsQuery_data;
    const path = (0,path_context/* usePathContext */.td)().unwrap();
    const seed = useSeedDataContext().unwrap();
    const walletsQuery = (0,wallets_data/* useWalletsBySeed */.QB)(seed.uuid);
    const maybeWallets = (_walletsQuery_data = walletsQuery.data) === null || _walletsQuery_data === void 0 ? void 0 : _walletsQuery_data.get();
    const subpath = (0,path_context/* useHashSubpath */.IL)(path);
    const onBackClick = (0,react.useCallback)(()=>{
        location.assign("#/seeds");
    }, []);
    const onWalletClick = (0,react.useCallback)((wallet)=>{
        location.assign("#/wallet/".concat(wallet.uuid));
    }, []);
    const Header = /*#__PURE__*/ (0,jsx_runtime.jsx)(header/* UserPageHeader */.To, {
        title: "Seed",
        back: onBackClick
    });
    const Card = /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
        className: "p-4 flex justify-center",
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
            className: "w-full max-w-sm",
            children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "w-full aspect-video rounded-xl",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(RawSeedDataCard, {})
            })
        })
    });
    const Body = /*#__PURE__*/ (0,jsx_runtime.jsx)(header/* PageBody */.xV, {
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(wallets_all_page/* ClickableWalletGrid */.oS, {
            ok: onWalletClick,
            wallets: maybeWallets
        })
    });
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(page/* Page */.T, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(path_context/* HashSubpathProvider */.qd, {
                children: subpath.url.pathname === "/create" && /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Dialog2 */.gP, {
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)(SeededWalletCreatorDialog, {})
                })
            }),
            Header,
            Card,
            Body
        ]
    });
}

// EXTERNAL MODULE: ./src/libs/ethereum/mods/chain.tsx
var mods_chain = __webpack_require__(3411);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/EllipsisVerticalIcon.js
var EllipsisVerticalIcon = __webpack_require__(4744);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/LinkIcon.js
var LinkIcon = __webpack_require__(7956);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/XMarkIcon.js
var XMarkIcon = __webpack_require__(9005);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/CheckIcon.js
var CheckIcon = __webpack_require__(2506);
// EXTERNAL MODULE: ./src/libs/glacier/mutators.ts
var mutators = __webpack_require__(7811);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/fetched/data.mjs
var fetched_data = __webpack_require__(8123);
;// CONCATENATED MODULE: ./src/mods/background/service_worker/entities/sessions/data.ts


var SessionRef;
(function(SessionRef) {
    function from(session) {
        return {
            ref: true,
            id: session.id,
            origin: session.origin
        };
    }
    SessionRef.from = from;
})(SessionRef || (SessionRef = {}));
class SessionStorage {
    getOrThrow(cacheKey) {
        return this.storage.getOrThrow(cacheKey);
    }
    setOrThrow(cacheKey, value) {
        var _value_data;
        if ((value === null || value === void 0 ? void 0 : (_value_data = value.data) === null || _value_data === void 0 ? void 0 : _value_data.data.persist) === false) return;
        return this.storage.setOrThrow(cacheKey, value);
    }
    constructor(storage){
        this.storage = storage;
    }
}
var BgSession;
(function(BgSession) {
    let All;
    (function(All) {
        let Temporary;
        (function(Temporary) {
            let ByWallet;
            (function(ByWallet) {
                function key(wallet) {
                    return "temporarySessionsByWallet/v2/".concat(wallet);
                }
                ByWallet.key = key;
                function schema(wallet) {
                    return (0,query/* createQuery */.rP)({
                        key: key(wallet)
                    });
                }
                ByWallet.schema = schema;
            })(ByWallet = Temporary.ByWallet || (Temporary.ByWallet = {}));
            Temporary.key = "temporarySessions/v2";
            function schema() {
                return (0,query/* createQuery */.rP)({
                    key: Temporary.key
                });
            }
            Temporary.schema = schema;
        })(Temporary = All.Temporary || (All.Temporary = {}));
        let Persistent;
        (function(Persistent) {
            let ByWallet;
            (function(ByWallet) {
                function key(wallet) {
                    return "persistentSessionsByWallet/v2/".concat(wallet);
                }
                ByWallet.key = key;
                function schema(wallet, storage) {
                    return (0,query/* createQuery */.rP)({
                        key: key(wallet),
                        storage
                    });
                }
                ByWallet.schema = schema;
            })(ByWallet = Persistent.ByWallet || (Persistent.ByWallet = {}));
            Persistent.key = "persistentSessions/v2";
            function schema(storage) {
                return (0,query/* createQuery */.rP)({
                    key: Persistent.key,
                    storage
                });
            }
            Persistent.schema = schema;
        })(Persistent = All.Persistent || (All.Persistent = {}));
    })(All = BgSession.All || (BgSession.All = {}));
    let ByOrigin;
    (function(ByOrigin) {
        function key(origin) {
            return "sessionByOrigin/".concat(origin);
        }
        ByOrigin.key = key;
        function schema(origin, storage) {
            return (0,query/* createQuery */.rP)({
                key: key(origin),
                storage
            });
        }
        ByOrigin.schema = schema;
    })(ByOrigin = BgSession.ByOrigin || (BgSession.ByOrigin = {}));
    function key(id) {
        return "session/v4/".concat(id);
    }
    BgSession.key = key;
    function schema(id, storage) {
        const indexer = async (states)=>{
            var _previous_real_current_ok, _previous_real, _current_real_current_ok, _current_real;
            const { current, previous } = states;
            const previousData = previous === null || previous === void 0 ? void 0 : (_previous_real = previous.real) === null || _previous_real === void 0 ? void 0 : (_previous_real_current_ok = _previous_real.current.ok()) === null || _previous_real_current_ok === void 0 ? void 0 : _previous_real_current_ok.get();
            const currentData = (_current_real = current.real) === null || _current_real === void 0 ? void 0 : (_current_real_current_ok = _current_real.current.ok()) === null || _current_real_current_ok === void 0 ? void 0 : _current_real_current_ok.get();
            if ((previousData === null || previousData === void 0 ? void 0 : previousData.id) === (currentData === null || currentData === void 0 ? void 0 : currentData.id)) return;
            if (previousData != null) {
                if (previousData.persist) {
                    const sessionByOrigin = ByOrigin.schema(previousData.origin, storage);
                    await sessionByOrigin.delete();
                }
                const sessionsQuery = previousData.persist ? All.Persistent.schema(storage) : All.Temporary.schema();
                await sessionsQuery.mutate(mutators/* Mutators */.g.mapData(function() {
                    let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : new fetched_data/* Data */.V([]);
                    return d.mapSync((p)=>p.filter((x)=>x.id !== previousData.id));
                }));
                const previousWallets = new Set(previousData.wallets);
                for (const wallet of previousWallets){
                    const sessionsByWalletQuery = previousData.persist ? All.Persistent.ByWallet.schema(wallet.uuid, storage) : All.Temporary.ByWallet.schema(wallet.uuid);
                    await sessionsByWalletQuery.mutate(mutators/* Mutators */.g.mapData(function() {
                        let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : new fetched_data/* Data */.V([]);
                        return d.mapSync((p)=>p.filter((x)=>x.id !== previousData.id));
                    }));
                }
            }
            if (currentData != null) {
                if (currentData.persist) {
                    const sessionByOrigin = ByOrigin.schema(currentData.origin, storage);
                    await sessionByOrigin.mutate(mutators/* Mutators */.g.data(SessionRef.from(currentData)));
                }
                const sessionsQuery = currentData.persist ? All.Persistent.schema(storage) : All.Temporary.schema();
                await sessionsQuery.mutate(mutators/* Mutators */.g.mapData(function() {
                    let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : new fetched_data/* Data */.V([]);
                    return d = d.mapSync((p)=>[
                            ...p,
                            SessionRef.from(currentData)
                        ]);
                }));
                const currentWallets = new Set(currentData.wallets);
                for (const wallet of currentWallets){
                    const sessionsByWalletQuery = currentData.persist ? All.Persistent.ByWallet.schema(wallet.uuid, storage) : All.Temporary.ByWallet.schema(wallet.uuid);
                    await sessionsByWalletQuery.mutate(mutators/* Mutators */.g.mapData(function() {
                        let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : new fetched_data/* Data */.V([]);
                        return d.mapSync((p)=>[
                                ...p,
                                SessionRef.from(currentData)
                            ]);
                    }));
                }
            }
        };
        return (0,query/* createQuery */.rP)({
            key: key(id),
            indexer,
            storage: new SessionStorage(storage)
        });
    }
    BgSession.schema = schema;
})(BgSession || (BgSession = {}));

;// CONCATENATED MODULE: ./src/mods/foreground/entities/sessions/data.ts




var FgSession;
(function(FgSession) {
    let All;
    (function(All) {
        let Temporary;
        (function(Temporary) {
            let ByWallet;
            (function(ByWallet) {
                ByWallet.key = BgSession.All.Temporary.ByWallet.key;
                function schema(wallet, storage) {
                    if (wallet == null) return;
                    return (0,query/* createQuery */.rP)({
                        key: ByWallet.key(wallet),
                        storage
                    });
                }
                ByWallet.schema = schema;
            })(ByWallet = Temporary.ByWallet || (Temporary.ByWallet = {}));
            Temporary.key = BgSession.All.Temporary.key;
            function schema(storage) {
                return (0,query/* createQuery */.rP)({
                    key: Temporary.key,
                    storage
                });
            }
            Temporary.schema = schema;
        })(Temporary = All.Temporary || (All.Temporary = {}));
        let Persistent;
        (function(Persistent) {
            let ByWallet;
            (function(ByWallet) {
                ByWallet.key = BgSession.All.Persistent.ByWallet.key;
                function schema(wallet, storage) {
                    if (wallet == null) return;
                    return (0,query/* createQuery */.rP)({
                        key: ByWallet.key(wallet),
                        storage
                    });
                }
                ByWallet.schema = schema;
            })(ByWallet = Persistent.ByWallet || (Persistent.ByWallet = {}));
            Persistent.key = BgSession.All.Persistent.key;
            function schema(storage) {
                return (0,query/* createQuery */.rP)({
                    key: Persistent.key,
                    storage
                });
            }
            Persistent.schema = schema;
        })(Persistent = All.Persistent || (All.Persistent = {}));
    })(All = FgSession.All || (FgSession.All = {}));
    let ByOrigin;
    (function(ByOrigin) {
        ByOrigin.key = BgSession.ByOrigin.key;
        function schema(origin, storage) {
            return (0,query/* createQuery */.rP)({
                key: ByOrigin.key(origin),
                storage
            });
        }
        ByOrigin.schema = schema;
    })(ByOrigin = FgSession.ByOrigin || (FgSession.ByOrigin = {}));
    FgSession.key = BgSession.key;
    function shema(id, storage) {
        if (id == null) return;
        const indexer = async (states)=>{
            var _previous_real_current_ok, _previous_real, _current_real_current_ok, _current_real;
            const { current, previous } = states;
            const previousData = previous === null || previous === void 0 ? void 0 : (_previous_real = previous.real) === null || _previous_real === void 0 ? void 0 : (_previous_real_current_ok = _previous_real.current.ok()) === null || _previous_real_current_ok === void 0 ? void 0 : _previous_real_current_ok.get();
            const currentData = (_current_real = current.real) === null || _current_real === void 0 ? void 0 : (_current_real_current_ok = _current_real.current.ok()) === null || _current_real_current_ok === void 0 ? void 0 : _current_real_current_ok.get();
            if (previousData != null) {
                if (previousData.persist) {
                    const sessionByOrigin = ByOrigin.schema(previousData.origin, storage);
                    await sessionByOrigin.delete();
                }
                const sessionsQuery = previousData.persist ? All.Persistent.schema(storage) : All.Temporary.schema(storage);
                await sessionsQuery.mutate(mutators/* Mutators */.g.mapData(function() {
                    let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : new fetched_data/* Data */.V([]);
                    return d.mapSync((p)=>p.filter((x)=>x.id !== previousData.id));
                }));
                const previousWallets = new Set(previousData.wallets);
                for (const wallet of previousWallets){
                    const sessionsByWalletQuery = previousData.persist ? All.Persistent.ByWallet.schema(wallet.uuid, storage) : All.Temporary.ByWallet.schema(wallet.uuid, storage);
                    await (sessionsByWalletQuery === null || sessionsByWalletQuery === void 0 ? void 0 : sessionsByWalletQuery.mutate(mutators/* Mutators */.g.mapData(function() {
                        let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : new fetched_data/* Data */.V([]);
                        return d.mapSync((p)=>p.filter((x)=>x.id !== previousData.id));
                    })));
                }
            }
            if (currentData != null) {
                if (currentData.persist) {
                    const sessionByOrigin = ByOrigin.schema(currentData.origin, storage);
                    await sessionByOrigin.mutate(mutators/* Mutators */.g.data(SessionRef.from(currentData)));
                }
                const sessionsQuery = currentData.persist ? All.Persistent.schema(storage) : All.Temporary.schema(storage);
                await sessionsQuery.mutate(mutators/* Mutators */.g.mapData(function() {
                    let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : new fetched_data/* Data */.V([]);
                    return d = d.mapSync((p)=>[
                            ...p,
                            SessionRef.from(currentData)
                        ]);
                }));
                const currentWallets = new Set(currentData.wallets);
                for (const wallet of currentWallets){
                    const sessionsByWalletQuery = currentData.persist ? All.Persistent.ByWallet.schema(wallet.uuid, storage) : All.Temporary.ByWallet.schema(wallet.uuid, storage);
                    await (sessionsByWalletQuery === null || sessionsByWalletQuery === void 0 ? void 0 : sessionsByWalletQuery.mutate(mutators/* Mutators */.g.mapData(function() {
                        let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : new fetched_data/* Data */.V([]);
                        return d.mapSync((p)=>[
                                ...p,
                                SessionRef.from(currentData)
                            ]);
                    })));
                }
            }
        };
        return (0,query/* createQuery */.rP)({
            key: FgSession.key(id),
            indexer,
            storage
        });
    }
    FgSession.shema = shema;
})(FgSession || (FgSession = {}));
function useSession(id) {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(FgSession.shema, [
        id,
        storage
    ]);
    return query;
}

;// CONCATENATED MODULE: ./src/mods/background/service_worker/entities/sessions/status/data.ts

var Status;
(function(Status) {
    function key(id) {
        return "session/status/v4/".concat(id);
    }
    Status.key = key;
    function schema(id) {
        return (0,query/* createQuery */.rP)({
            key: key(id)
        });
    }
    Status.schema = schema;
})(Status || (Status = {}));

;// CONCATENATED MODULE: ./src/mods/foreground/entities/sessions/status/data.ts



function getStatus(id, storage) {
    if (id == null) return undefined;
    return (0,query/* createQuery */.rP)({
        key: Status.key(id),
        storage
    });
}
function useStatus(id) {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(getStatus, [
        id,
        storage
    ]);
    return query;
}

;// CONCATENATED MODULE: ./src/mods/foreground/entities/sessions/all/data.ts


function getPersistentSessions(storage) {
    return (0,query/* createQuery */.rP)({
        key: "persistentSessions/v2",
        storage
    });
}
function usePersistentSessions() {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(getPersistentSessions, [
        storage
    ]);
    return query;
}
function getTemporarySessions(storage) {
    return (0,query/* createQuery */.rP)({
        key: "temporarySessions/v2",
        storage
    });
}
function useTemporarySessions() {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(getTemporarySessions, [
        storage
    ]);
    return query;
}

;// CONCATENATED MODULE: ./src/mods/foreground/entities/sessions/all/page.tsx
/* eslint-disable @next/next/no-img-element */ 





















function SessionsPage() {
    var _tempSessionsQuery_data, _persSessionsQuery_data;
    const background = (0,context/* useBackgroundContext */.D_)().unwrap();
    const tempSessionsQuery = useTemporarySessions();
    const maybeTempSessions = (_tempSessionsQuery_data = tempSessionsQuery.data) === null || _tempSessionsQuery_data === void 0 ? void 0 : _tempSessionsQuery_data.get();
    const persSessionsQuery = usePersistentSessions();
    const maybePersSessions = (_persSessionsQuery_data = persSessionsQuery.data) === null || _persSessionsQuery_data === void 0 ? void 0 : _persSessionsQuery_data.get();
    const length = (0,react.useMemo)(()=>{
        const temp = (maybeTempSessions === null || maybeTempSessions === void 0 ? void 0 : maybeTempSessions.length) || 0;
        const pers = (maybePersSessions === null || maybePersSessions === void 0 ? void 0 : maybePersSessions.length) || 0;
        return temp + pers;
    }, [
        maybeTempSessions,
        maybePersSessions
    ]);
    const disconnectAllOrAlert = (0,callback/* useAsyncUniqueCallback */.T)(()=>errors/* Errors */.D.runAndLogAndAlert(async ()=>{
            if (!(0,platform/* isSafariExtension */.WB)() && confirm("Do you want to disconnect all sessions?") === false) return;
            for (const session of option_option/* Option */.W.wrap(maybeTempSessions).unwrapOr([]))await background.requestOrThrow({
                method: "brume_disconnect",
                params: [
                    session.id
                ]
            }).then((r)=>r.unwrap());
            for (const session of option_option/* Option */.W.wrap(maybePersSessions).unwrapOr([]))await background.requestOrThrow({
                method: "brume_disconnect",
                params: [
                    session.id
                ]
            }).then((r)=>r.unwrap());
            return;
        }), [
        background,
        maybePersSessions
    ]);
    const Body = /*#__PURE__*/ (0,jsx_runtime.jsx)(header/* PageBody */.xV, {
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "flex flex-col gap-2",
            children: [
                maybeTempSessions === null || maybeTempSessions === void 0 ? void 0 : maybeTempSessions.map((session)=>/*#__PURE__*/ (0,jsx_runtime.jsx)(SessionRow, {
                        session: session
                    }, session.id)),
                maybePersSessions === null || maybePersSessions === void 0 ? void 0 : maybePersSessions.map((session)=>/*#__PURE__*/ (0,jsx_runtime.jsx)(SessionRow, {
                        session: session
                    }, session.id))
            ]
        })
    });
    const Header = /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(header/* UserPageHeader */.To, {
                title: "Sessions",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(send/* PaddedRoundedShrinkableNakedButton */.t5, {
                    disabled: disconnectAllOrAlert.loading || !length,
                    onClick: disconnectAllOrAlert.run,
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)(TrashIcon/* default */.Z, {
                        className: "size-5"
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "po-md flex items-center",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "text-contrast",
                    children: "Sessions allow you to connect to applications. These applications can then make requests for you to approve."
                })
            })
        ]
    });
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(page/* Page */.T, {
        children: [
            Header,
            Body
        ]
    });
}
function SessionRow(props) {
    var _sessionQuery_data, _originQuery_data, _statusQuery_data, _maybeOriginData_icons, _iconDatas_find;
    const { session } = props;
    const path = (0,path_context/* usePathContext */.td)().unwrap();
    const subpath = (0,path_context/* useHashSubpath */.IL)(path);
    const menu = (0,all_page/* useGenius */.y6)(subpath, "/".concat(session.id, "/menu"));
    const sessionQuery = useSession(session.id);
    const maybeSessionData = (_sessionQuery_data = sessionQuery.data) === null || _sessionQuery_data === void 0 ? void 0 : _sessionQuery_data.get();
    const originQuery = useOrigin(maybeSessionData === null || maybeSessionData === void 0 ? void 0 : maybeSessionData.origin);
    const maybeOriginData = (_originQuery_data = originQuery.data) === null || _originQuery_data === void 0 ? void 0 : _originQuery_data.get();
    const statusQuery = useStatus(session.id);
    const maybeStatusData = (_statusQuery_data = statusQuery.data) === null || _statusQuery_data === void 0 ? void 0 : _statusQuery_data.get();
    const [iconDatas, setIconDatas] = (0,react.useState)([]);
    const onIconData = (0,react.useCallback)((param)=>{
        let [index, data] = param;
        setIconDatas((iconDatas)=>{
            iconDatas[index] = data;
            return [
                ...iconDatas
            ];
        });
    }, []);
    if (maybeSessionData == null) return null;
    if (maybeOriginData == null) return null;
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        role: "button",
        className: "po-md rounded-xl flex items-center gap-4",
        onContextMenu: menu.onContextMenu,
        onKeyDown: menu.onKeyDown,
        onClick: menu.onClick,
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(path_context/* HashSubpathProvider */.qd, {
                children: [
                    subpath.url.pathname === "/".concat(session.id, "/menu") && /*#__PURE__*/ (0,jsx_runtime.jsx)(menu_menu/* Menu */.v, {
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(SessionMenu, {
                            sessionData: maybeSessionData
                        })
                    }),
                    subpath.url.pathname === "/".concat(session.id, "/chains") && maybeSessionData.type !== "wc" && /*#__PURE__*/ (0,jsx_runtime.jsx)(menu_menu/* Menu */.v, {
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(ChainsMenu, {
                            sessionData: maybeSessionData
                        })
                    })
                ]
            }),
            (_maybeOriginData_icons = maybeOriginData.icons) === null || _maybeOriginData_icons === void 0 ? void 0 : _maybeOriginData_icons.map((x, i)=>/*#__PURE__*/ (0,jsx_runtime.jsx)(page_IndexedBlobbyLoader, {
                    index: i,
                    id: x.id,
                    ok: onIconData
                }, x.id)),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "relative shrink-0",
                children: [
                    (()=>{
                        if (maybeStatusData == null) return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "absolute top-0 -right-2 bg-blue-400 rounded-full w-2 h-2"
                        });
                        if (maybeStatusData.error == null) return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "absolute top-0 -right-2 bg-green-400 rounded-full w-2 h-2"
                        });
                        return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "absolute top-0 -right-2 bg-red-400 rounded-full w-2 h-2"
                        });
                    })(),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(ImageWithFallback, {
                        className: "size-10",
                        alt: "icon",
                        src: (_iconDatas_find = iconDatas.find(Boolean)) === null || _iconDatas_find === void 0 ? void 0 : _iconDatas_find.data,
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(CubeTransparentIcon/* default */.Z, {
                            className: "size-10"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "grow",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "font-medium",
                        children: maybeOriginData.title
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "text-contrast",
                        children: maybeOriginData.origin
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)(send/* PaddedRoundedShrinkableNakedAnchor */.wW, {
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(EllipsisVerticalIcon/* default */.Z, {
                    className: "size-5"
                })
            })
        ]
    });
}
function page_IndexedBlobbyLoader(props) {
    const { index, id, ok } = props;
    const { data } = useBlobby(id);
    (0,react.useEffect)(()=>{
        ok([
            index,
            data === null || data === void 0 ? void 0 : data.inner
        ]);
    }, [
        index,
        data,
        ok
    ]);
    return null;
}
function SessionMenu(props) {
    const { sessionData } = props;
    const path = (0,path_context/* usePathContext */.td)().unwrap();
    const background = (0,context/* useBackgroundContext */.D_)().unwrap();
    const chains = (0,all_page/* useGenius */.y6)(path, "/".concat(sessionData.id, "/chains"));
    const disconnectOrAlert = (0,callback/* useAsyncUniqueCallback */.T)(()=>errors/* Errors */.D.runAndLogAndAlert(async ()=>{
            await background.requestOrThrow({
                method: "brume_disconnect",
                params: [
                    sessionData.id
                ]
            }).then((r)=>r.unwrap());
        }), [
        background,
        sessionData
    ]);
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "flex flex-col text-left gap-2 w-[160px] overflow-x-hidden",
        children: [
            sessionData.type !== "wc" && /*#__PURE__*/ (0,jsx_runtime.jsxs)(send/* WideShrinkableNakedMenuAnchor */.s_, {
                onClick: chains.onClick,
                onKeyDown: chains.onKeyDown,
                href: chains.href,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(LinkIcon/* default */.Z, {
                        className: "shrink-0 size-4"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "truncate",
                        children: sessionData.chain.name
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(send/* WideShrinkableNakedMenuButton */.vD, {
                disabled: disconnectOrAlert.loading,
                onClick: disconnectOrAlert.run,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(XMarkIcon/* default */.Z, {
                        className: "size-4"
                    }),
                    "Disconnect"
                ]
            })
        ]
    });
}
function ChainsMenu(props) {
    const { sessionData } = props;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
        className: "flex flex-col text-left gap-2 w-[160px] overflow-x-hidden",
        children: Object.values(mods_chain/* chainDataByChainId */.wz).map((chain)=>/*#__PURE__*/ (0,jsx_runtime.jsx)(ChainRow, {
                sessionData: sessionData,
                chainData: chain
            }, chain.chainId))
    });
}
function ChainRow(props) {
    const { sessionData, chainData } = props;
    const close = (0,dialog/* useCloseContext */.gX)().unwrap();
    const background = (0,context/* useBackgroundContext */.D_)().unwrap();
    const switchOrAlert = (0,callback/* useAsyncUniqueCallback */.T)(()=>errors/* Errors */.D.runAndLogAndAlert(async ()=>{
            await background.requestOrThrow({
                method: "brume_switchEthereumChain",
                params: [
                    sessionData.id,
                    chainData.chainId
                ]
            }).then((r)=>r.unwrap());
            close();
        }), [
        background,
        sessionData,
        chainData,
        close
    ]);
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(send/* WideShrinkableNakedMenuButton */.vD, {
        disabled: switchOrAlert.loading,
        onClick: switchOrAlert.run,
        children: [
            sessionData.chain.chainId === chainData.chainId && /*#__PURE__*/ (0,jsx_runtime.jsx)(CheckIcon/* default */.Z, {
                className: "shrink-0 size-4"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "truncate",
                children: chainData.name
            })
        ]
    });
}

;// CONCATENATED MODULE: ./src/libs/ui/anchor/anchor.tsx

function TextAnchor(props) {
    const { className, href, children = href, target = "_blank", rel = "noreferrer", ...others } = props;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("a", {
        className: "a ".concat(className),
        href: href,
        target: target,
        rel: rel,
        ...others,
        children: children
    });
}

// EXTERNAL MODULE: ./node_modules/@hazae41/option/dist/esm/mods/option/some.mjs
var some = __webpack_require__(8862);
;// CONCATENATED MODULE: ./src/mods/background/service_worker/entities/settings/data.ts

var BgSettings;
(function(BgSettings) {
    let Logs;
    (function(Logs) {
        Logs.key = "settings/logs";
        function schema(storage) {
            return (0,query/* createQuery */.rP)({
                key: Logs.key,
                storage
            });
        }
        Logs.schema = schema;
    })(Logs = BgSettings.Logs || (BgSettings.Logs = {}));
    let Chain;
    (function(Chain) {
        Chain.key = "settings/chain";
        function schema(storage) {
            return (0,query/* createQuery */.rP)({
                key: Chain.key,
                storage
            });
        }
        Chain.schema = schema;
    })(Chain = BgSettings.Chain || (BgSettings.Chain = {}));
})(BgSettings || (BgSettings = {}));

;// CONCATENATED MODULE: ./src/mods/foreground/entities/settings/data.ts



var FgSettings;
(function(FgSettings) {
    let Logs;
    (function(Logs) {
        Logs.key = BgSettings.Logs.key;
        function schema(storage) {
            return (0,query/* createQuery */.rP)({
                key: Logs.key,
                storage
            });
        }
        Logs.schema = schema;
    })(Logs = FgSettings.Logs || (FgSettings.Logs = {}));
    let Chain;
    (function(Chain) {
        Chain.key = BgSettings.Chain.key;
        function schema(storage) {
            return (0,query/* createQuery */.rP)({
                key: Chain.key,
                storage
            });
        }
        Chain.schema = schema;
    })(Chain = FgSettings.Chain || (FgSettings.Chain = {}));
})(FgSettings || (FgSettings = {}));
function useLogs() {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(FgSettings.Logs.schema, [
        storage
    ]);
    return query;
}
function useChain() {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(FgSettings.Chain.schema, [
        storage
    ]);
    return query;
}

;// CONCATENATED MODULE: ./src/mods/foreground/entities/settings/page.tsx











function SettingsPage() {
    var _chain_real, _logs_real;
    const logs = useLogs();
    const chain = useChain();
    const onLogsChange = (0,callback/* useAsyncUniqueCallback */.T)((e)=>errors/* Errors */.D.runAndLogAndAlert(async ()=>{
            const checked = e.currentTarget.checked;
            await logs.mutate(()=>new some/* Some */.b(new fetched_data/* Data */.V(checked)));
        }), []);
    const onChainChange = (0,callback/* useAsyncUniqueCallback */.T)((e)=>errors/* Errors */.D.runAndLogAndAlert(async ()=>{
            const chainId = Number(e.currentTarget.value);
            await chain.mutate(()=>new some/* Some */.b(new fetched_data/* Data */.V(chainId)));
        }), []);
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(page/* Page */.T, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(header/* UserPageHeader */.To, {
                title: "Settings"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(header/* PageBody */.xV, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "po-md text-sm text-contrast uppercase",
                        children: "Compatibility"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(send/* SimpleLabel */.JJ, {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "shrink-0",
                                children: "Default chain"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "w-4 grow"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("select", {
                                className: "text-right bg-transparent outline-none overflow-ellipsis overflow-x-hidden appearance-none",
                                value: (_chain_real = chain.real) === null || _chain_real === void 0 ? void 0 : _chain_real.current.get(),
                                onChange: onChainChange.run,
                                children: Object.values(mods_chain/* chainDataByChainId */.wz).map((x)=>/*#__PURE__*/ (0,jsx_runtime.jsx)("option", {
                                        value: x.chainId,
                                        children: x.name
                                    }, x.chainId))
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "po-md text-sm text-contrast",
                        children: "Use this parameter if some app requires a specific chain"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-4"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "po-md text-sm text-contrast uppercase",
                        children: "Debugging"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(send/* SimpleLabel */.JJ, {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "shrink-0",
                                children: "Enable logs"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "w-4 grow"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("input", {
                                className: "self-center",
                                type: "checkbox",
                                checked: Boolean((_logs_real = logs.real) === null || _logs_real === void 0 ? void 0 : _logs_real.current.get()),
                                onChange: onLogsChange.run
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "po-md text-sm text-contrast",
                        children: [
                            "All your requests will be seen on ",
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(TextAnchor, {
                                href: "https://logs.brume.money"
                            })
                        ]
                    })
                ]
            })
        ]
    });
}

// EXTERNAL MODULE: ./node_modules/@swc/helpers/esm/_class_private_field_get.js + 1 modules
var _class_private_field_get = __webpack_require__(7121);
// EXTERNAL MODULE: ./node_modules/@swc/helpers/esm/_class_private_field_init.js
var _class_private_field_init = __webpack_require__(9886);
// EXTERNAL MODULE: ./node_modules/@swc/helpers/esm/_class_private_field_set.js + 1 modules
var _class_private_field_set = __webpack_require__(5321);
;// CONCATENATED MODULE: ./src/mods/background/service_worker/entities/snaps/data.ts





var _a;




var SnapRef;
(function(SnapRef) {
    function create(uuid) {
        return {
            ref: true,
            uuid
        };
    }
    SnapRef.create = create;
    function from(snap) {
        return create(snap.uuid);
    }
    SnapRef.from = from;
})(SnapRef || (SnapRef = {}));
var BgSnap;
(function(BgSnap) {
    let All;
    (function(All) {
        All.key = "snaps";
        function schema(storage) {
            return (0,query/* createQuery */.rP)({
                key: All.key,
                storage
            });
        }
        All.schema = schema;
    })(All = BgSnap.All || (BgSnap.All = {}));
    function key(uuid) {
        return "snap/".concat(uuid);
    }
    BgSnap.key = key;
    function schema(id, storage) {
        return (0,query/* createQuery */.rP)({
            key: key(id),
            storage
        });
    }
    BgSnap.schema = schema;
})(BgSnap || (BgSnap = {}));
var _class = /*#__PURE__*/ new WeakMap();
class SnapError extends Error {
    static from(cause) {
        return new _a({
            cause
        });
    }
    constructor(options){
        super("Could not execute", options);
        (0,_class_private_field_init._)(this, _class, {
            writable: true,
            value: void 0
        });
        (0,_class_private_field_set._)(this, _class, _a);
        this.name = (0,_class_private_field_get._)(this, _class).name;
    }
}
_a = SnapError;
class RustSnapFactory {
    create(context) {
        const snap = new this.snap(context);
        return new RustSnapWrapper(snap);
    }
    constructor(bytecode){
        this.bytecode = bytecode;
        this.snap = createSnap(this.bytecode);
    }
}
var _onRequest = /*#__PURE__*/ new WeakSet();
class RustSnapContext {
    request(req) {
        const request = JSON.parse(req);
        const response = Result.runAndWrap(()=>{
            return _class_private_method_get(this, _onRequest, onRequest).call(this, request);
        }).then((r)=>RpcResponse.rewrap(null, r));
        return JSON.stringify(response);
    }
    constructor(){
        _class_private_method_init(this, _onRequest);
    }
}
function onRequest(request) {
    if (request.method === "log") {
        console.log(...request.params);
        return;
    }
    if (request.method === "brume_addChain") {
    // const [logo] = (request as RpcRequestInit<[]>).params
    }
    throw new Error("Unknown method ".concat(request.method));
}
class RustSnapWrapper {
    request(request) {
        try {
            const req = JSON.stringify(request);
            const ret = this.inner.on_request(req);
            const res = JSON.parse(ret);
            return new RpcOk(request.id, res);
        } catch (e) {
            return new RpcErr(request.id, RpcError.rewrap(e));
        }
    }
    constructor(/**
     * The WebAssembly module
     */ inner){
        this.inner = inner;
    }
}

;// CONCATENATED MODULE: ./src/mods/foreground/entities/snaps/data.tsx



var FgSnap;
(function(FgSnap) {
    let All;
    (function(All) {
        All.key = BgSnap.All.key;
        function schema(storage) {
            return (0,query/* createQuery */.rP)({
                key: All.key,
                storage
            });
        }
        All.schema = schema;
    })(All = FgSnap.All || (FgSnap.All = {}));
    FgSnap.key = BgSnap.key;
    function schema(uuid, storage) {
        if (uuid == null) return;
        return (0,query/* createQuery */.rP)({
            key: FgSnap.key(uuid),
            storage
        });
    }
    FgSnap.schema = schema;
})(FgSnap || (FgSnap = {}));
function useSnap(uuid) {
    const storage = useUserStorageContext().unwrap();
    const query = useQuery(FgSnap.schema, [
        uuid,
        storage
    ]);
    return query;
}
function useSnaps() {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(FgSnap.All.schema, [
        storage
    ]);
    return query;
}

;// CONCATENATED MODULE: ./src/mods/foreground/entities/snaps/all/page.tsx







function SnapsPage() {
    const snapsQuery = useSnaps();
    const onAdd = (0,react.useCallback)(()=>{}, []);
    const Body = /*#__PURE__*/ (0,jsx_runtime.jsx)(header/* PageBody */.xV, {
        children: "Coming soon..."
    });
    const Header = /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(header/* UserPageHeader */.To, {
                title: "Plugins",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(send/* PaddedRoundedShrinkableNakedButton */.t5, {
                    onClick: onAdd,
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)(PlusIcon/* default */.Z, {
                        className: "size-5"
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "po-md flex items-center",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "text-contrast",
                    children: "Plugins allow you to securely extend the features. These features can then be used by applications you connect to."
                })
            })
        ]
    });
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(page/* Page */.T, {
        children: [
            Header,
            Body
        ]
    });
}

// EXTERNAL MODULE: ./src/mods/foreground/entities/users/context.tsx
var users_context = __webpack_require__(1822);
;// CONCATENATED MODULE: ./src/mods/foreground/entities/wallets/all/trash/page.tsx
/* eslint-disable @next/next/no-img-element */ 












function TrashedWalletsPage() {
    var _walletsQuery_current;
    const path = (0,path_context/* usePathContext */.td)().unwrap();
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const walletsQuery = (0,wallets_data/* useTrashedWallets */.Pd)();
    const maybeWallets = (_walletsQuery_current = walletsQuery.current) === null || _walletsQuery_current === void 0 ? void 0 : _walletsQuery_current.ok().get();
    const onWalletClick = (0,react.useCallback)((wallet)=>{
        location.assign(path.go("/wallet/".concat(wallet.uuid)));
    }, [
        path
    ]);
    const trashAllOrAlert = (0,callback/* useAsyncUniqueCallback */.T)(()=>errors/* Errors */.D.runAndLogAndAlert(async ()=>{
            var _FgWallet_schema;
            if (!(0,platform/* isSafariExtension */.WB)() && confirm("Are you sure you want to delete all wallets in the trash?") === false) return;
            for (const wallet of maybeWallets !== null && maybeWallets !== void 0 ? maybeWallets : [])await ((_FgWallet_schema = wallets_data/* FgWallet */.KJ.schema(wallet.uuid, storage)) === null || _FgWallet_schema === void 0 ? void 0 : _FgWallet_schema.delete());
            return;
        }), [
        maybeWallets,
        storage
    ]);
    const Body = /*#__PURE__*/ (0,jsx_runtime.jsx)(header/* PageBody */.xV, {
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(wallets_all_page/* ClickableWalletGrid */.oS, {
            disableNew: true,
            ok: onWalletClick,
            wallets: maybeWallets
        })
    });
    const Header = /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(header/* UserPageHeader */.To, {
                title: "Trash",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(send/* PaddedRoundedShrinkableNakedButton */.t5, {
                    disabled: trashAllOrAlert.loading,
                    onClick: trashAllOrAlert.run,
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)(TrashIcon/* default */.Z, {
                        className: "size-5"
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "po-md flex items-center",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "text-contrast",
                    children: "Wallets in the trash are automatically deleted after 30 days."
                })
            })
        ]
    });
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(page/* Page */.T, {
        children: [
            Header,
            Body
        ]
    });
}

// EXTERNAL MODULE: ./node_modules/@nuintun/qrcode/esm/qrcode/decoder/Reader.js + 15 modules
var Reader = __webpack_require__(845);
// EXTERNAL MODULE: ./src/mods/foreground/entities/wallets/context.tsx
var wallets_context = __webpack_require__(3291);
;// CONCATENATED MODULE: ./src/mods/foreground/entities/wallets/camera/page.tsx
/* eslint-disable @next/next/no-img-element */ 






function WalletCameraPage(props) {
    const { uuid } = props;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(wallets_context/* WalletDataProvider */.lp, {
        uuid: uuid,
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(WalletDataCameraPage, {})
    });
}
function WalletDataCameraPage() {
    const wallet = (0,wallets_context/* useWalletDataContext */.zI)().unwrap();
    const background = (0,context/* useBackgroundContext */.D_)().unwrap();
    const mounted = (0,react.useRef)(true);
    (0,react.useEffect)(()=>()=>{
            mounted.current = false;
        }, []);
    const video = (0,react.useRef)(null);
    const sight = (0,react.useRef)(null);
    const [text, setText] = (0,react.useState)();
    const onStream = (0,react.useCallback)((stream)=>{
        if (!video.current) return;
        if (!sight.current) return;
        video.current.addEventListener("canplay", ()=>{
            if (!video.current) return;
            if (!sight.current) return;
            const yratio = video.current.videoHeight / video.current.clientHeight;
            const xratio = video.current.videoWidth / video.current.clientWidth;
            const ratio = Math.min(yratio, xratio);
            const cw = video.current.clientWidth * ratio;
            const ch = video.current.clientHeight * ratio;
            const cx = video.current.videoWidth / 2 - cw / 2;
            const cy = video.current.videoHeight / 2 - ch / 2;
            const sx = cx + sight.current.offsetLeft * ratio;
            const sy = cy + sight.current.offsetTop * ratio;
            const sw = sight.current.offsetWidth * ratio;
            const sh = sight.current.offsetHeight * ratio;
            const canvas = document.createElement("canvas");
            canvas.width = sw;
            canvas.height = sh;
            const canvasCtx = canvas.getContext("2d");
            if (!canvasCtx) return;
            function loop() {
                if (!mounted.current) return;
                if (!video.current) return;
                if (!sight.current) return;
                if (!canvasCtx) return;
                canvasCtx.drawImage(video.current, sx, sy, sw, sh, 0, 0, canvas.width, canvas.height);
                const image = canvasCtx.getImageData(0, 0, sw, sh);
                let result = null;
                try {
                    result = new Reader/* Decoder */.h().decode(image.data, canvas.width, canvas.height);
                } catch (e) {}
                if (result != null) setText(result.data);
                setTimeout(loop, 1000);
            }
            setTimeout(loop, 1000);
        });
        video.current.srcObject = stream;
        video.current.play();
    }, []);
    (0,react.useEffect)(()=>{
        const video = {
            width: {
                ideal: 1080
            },
            height: {
                ideal: 1080
            },
            facingMode: {
                exact: "environment"
            }
        };
        navigator.mediaDevices.getUserMedia({
            video
        }).then(onStream).catch(errors/* Errors */.D.logAndAlert);
    }, [
        onStream
    ]);
    const connectOrAlert = (0,callback/* useAsyncUniqueCallback */.T)((uri)=>errors/* Errors */.D.runAndLogAndAlert(async ()=>{
            alert("Connecting...");
            const metadata = await background.requestOrThrow({
                method: "brume_wc_connect",
                params: [
                    uri,
                    wallet.uuid
                ]
            }).then((r)=>r.unwrap());
            alert("Connected to ".concat(metadata.name));
        }), [
        background,
        wallet
    ]);
    (0,react.useEffect)(()=>{
        if (text) connectOrAlert.run(text);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        text
    ]);
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(jsx_runtime.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "grow relative flex flex-col",
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "absolute w-full h-full flex flex-col items-center justify-center",
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)("img", {
                        className: "h-16 w-16",
                        src: "/assets/wc.svg",
                        alt: "WalletConnect"
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "absolute w-full h-full flex flex-col items-center justify-center",
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)("img", {
                        className: "h-64 w-64",
                        ref: sight,
                        src: "/assets/sight.svg",
                        alt: "sight"
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("video", {
                    className: "grow w-full object-cover",
                    ref: video,
                    playsInline: true,
                    muted: true
                })
            ]
        })
    });
}

// EXTERNAL MODULE: ./src/mods/foreground/entities/wallets/page.tsx + 20 modules
var wallets_page = __webpack_require__(9579);
// EXTERNAL MODULE: ./src/mods/foreground/entities/unknown/data.ts
var unknown_data = __webpack_require__(717);
;// CONCATENATED MODULE: ./src/mods/foreground/home/page.tsx
/* eslint-disable @next/next/no-img-element */ 








function HomePage() {
    const userData = (0,users_context/* useUserContext */.SE)().unwrap();
    const background = (0,context/* useBackgroundContext */.D_)().unwrap();
    const totalPricedBalanceQuery = (0,unknown_data/* useTotalPricedBalance */.ZO)("usd");
    const totalPricedBalanceDisplay = (0,wallets_page/* useDisplayUsdOrZeroOrError */.zG)(totalPricedBalanceQuery.current);
    (0,react.useEffect)(()=>{
        background.requestOrThrow({
            method: "brume_log"
        }).then((r)=>r.unwrap()).catch(console.error);
    }, [
        background
    ]);
    const [persisted, setPersisted] = (0,react.useState)();
    const getPersisted = (0,react.useCallback)(async ()=>{
        setPersisted(await navigator.storage.persist());
    }, []);
    (0,react.useEffect)(()=>{
        if (!(0,platform/* isWebsite */.hC)()) return;
        getPersisted();
        if (navigator.userAgent.toLowerCase().includes("firefox")) return;
        const t = setInterval(getPersisted, 1000);
        return ()=>clearTimeout(t);
    }, [
        background,
        getPersisted
    ]);
    const Body = /*#__PURE__*/ (0,jsx_runtime.jsxs)(header/* PageBody */.xV, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "h-[min(32rem,90dvh)] shrink-0 grow flex flex-col items-center",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "grow"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("h1", {
                        className: "text-center text-6xl font-medium",
                        children: [
                            "Welcome back",
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("span", {
                                className: "text-contrast",
                                children: [
                                    ", ",
                                    userData.name
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "grow"
                    }),
                    persisted === false && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "h-4"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "p-4 bg-contrast rounded-xl max-w-xs",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("h3", {
                                        className: "text-lg font-medium",
                                        children: "Your storage is not persistent yet"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                                        className: "text-contrast",
                                        children: "Please add this website to your favorites or to your home screen"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "h-2"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "h-4"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "grow"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "grow"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "text-lg font-medium",
                children: "Total balance"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "text-2xl font-bold",
                children: totalPricedBalanceDisplay
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-4"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "p-4 bg-contrast shrink-0 h-[300px] rounded-xl flex flex-col items-center justify-center",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("img", {
                        src: "/favicon.png",
                        alt: "logo",
                        className: "h-24 w-auto"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "",
                        children: "Coming soon..."
                    })
                ]
            })
        ]
    });
    const Header = /*#__PURE__*/ (0,jsx_runtime.jsx)(header/* UserPageHeader */.To, {
        title: "Home"
    });
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(page/* Page */.T, {
        children: [
            Header,
            Body
        ]
    });
}

// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/HomeIcon.js
var HomeIcon = __webpack_require__(4201);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/WalletIcon.js
var WalletIcon = __webpack_require__(162);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/SparklesIcon.js
var SparklesIcon = __webpack_require__(5199);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/GlobeAltIcon.js
var GlobeAltIcon = __webpack_require__(9625);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/CogIcon.js
var CogIcon = __webpack_require__(4934);
;// CONCATENATED MODULE: ./src/libs/ui/anchor/shrinker.tsx
var Shrinker;
(function(Shrinker) {
    Shrinker.className = "h-full w-full flex justify-center items-center gap-2 group-active:scale-90 transition-transform";
})(Shrinker || (Shrinker = {}));

;// CONCATENATED MODULE: ./src/libs/ui/anchor/index.tsx



;// CONCATENATED MODULE: ./src/libs/ui/anchor.tsx



;// CONCATENATED MODULE: ./src/mods/foreground/overlay/bottom.tsx





function Bottom() {
    var _requestsQuery_data;
    const { url } = (0,path_context/* usePathContext */.td)().unwrap();
    const requestsQuery = (0,data/* useAppRequests */.fU)();
    const requests = (_requestsQuery_data = requestsQuery.data) === null || _requestsQuery_data === void 0 ? void 0 : _requestsQuery_data.get();
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("nav", {
        className: "h-16 w-full shrink-0 border-t border-t-contrast",
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "w-full h-16 px-4 m-auto max-w-3xl flex items-center",
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsx)("a", {
                    className: "group grow text-contrast data-[selected=true]:text-default",
                    "data-selected": url.pathname === "/home",
                    href: "#/home",
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "".concat(Shrinker.className),
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(HomeIcon/* default */.Z, {
                            className: "size-6"
                        })
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("a", {
                    className: "group grow text-contrast data-[selected=true]:text-default",
                    "data-selected": url.pathname === "/wallets",
                    href: "#/wallets",
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "".concat(Shrinker.className),
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(WalletIcon/* default */.Z, {
                            className: "size-6"
                        })
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("a", {
                    className: "group grow text-contrast data-[selected=true]:text-default",
                    "data-selected": url.pathname === "/seeds",
                    href: "#/seeds",
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "".concat(Shrinker.className),
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(SparklesIcon/* default */.Z, {
                            className: "size-6"
                        })
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("a", {
                    className: "group grow text-contrast data-[selected=true]:text-default",
                    "data-selected": url.pathname === "/sessions",
                    href: "#/sessions",
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "".concat(Shrinker.className),
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(GlobeAltIcon/* default */.Z, {
                            className: "size-6"
                        })
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("a", {
                    className: "group grow text-contrast data-[selected=true]:text-default",
                    "data-selected": url.pathname === "/requests",
                    href: "#/requests",
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "".concat(Shrinker.className),
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "relative",
                            children: [
                                Boolean(requests === null || requests === void 0 ? void 0 : requests.length) && /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    className: "absolute top-0 -right-2",
                                    children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("span", {
                                        className: "relative flex w-2 h-2",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                                className: "animate-ping absolute inline-flex h-full w-full rounded-full bg-purple-400 opacity-75"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                                className: "relative inline-flex rounded-full w-2 h-2 bg-purple-400"
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)(CheckIcon/* default */.Z, {
                                    className: "size-6"
                                })
                            ]
                        })
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("a", {
                    className: "group grow text-contrast data-[selected=true]:text-default",
                    "data-selected": url.pathname === "/settings",
                    href: "#/settings",
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "".concat(Shrinker.className),
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(CogIcon/* default */.Z, {
                            className: "size-6"
                        })
                    })
                })
            ]
        })
    });
}

;// CONCATENATED MODULE: ./src/mods/foreground/router/router.tsx


















function Layout(props) {
    const { children } = props;
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(users_context/* UserGuard */.ds, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "grow w-full flex flex-col overflow-y-scroll",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "grow w-full m-auto max-w-3xl flex flex-col",
                    children: children
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)(Bottom, {})
        ]
    });
}
function Router() {
    const { url } = (0,path_context/* usePathContext */.td)().unwrap();
    let matches;
    if ((matches = url.pathname.match(/^(\/)?$/)) && (0,platform/* isWebsite */.hC)()) return /*#__PURE__*/ (0,jsx_runtime.jsx)(all_page/* FullLandingPage */.sb, {
        next: "#/home"
    });
    if ((matches = url.pathname.match(/^(\/)?$/)) && !(0,platform/* isWebsite */.hC)()) return /*#__PURE__*/ (0,jsx_runtime.jsx)(all_page/* EmptyLandingPage */.aN, {
        next: "#/home"
    });
    if (matches = url.pathname.match(/^\/home(\/)?$/)) return /*#__PURE__*/ (0,jsx_runtime.jsx)(Layout, {
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(HomePage, {})
    });
    if (matches = url.pathname.match(/^\/wallets(\/)?$/)) return /*#__PURE__*/ (0,jsx_runtime.jsx)(Layout, {
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(wallets_all_page/* WalletsPage */.FU, {})
    });
    if (matches = url.pathname.match(/^\/wallets(\/)trash(\/)?$/)) return /*#__PURE__*/ (0,jsx_runtime.jsx)(Layout, {
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(TrashedWalletsPage, {})
    });
    if (matches = url.pathname.match(/^\/seeds(\/)?$/)) return /*#__PURE__*/ (0,jsx_runtime.jsx)(Layout, {
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(SeedsPage, {})
    });
    if (matches = url.pathname.match(/^\/sessions(\/)?$/)) return /*#__PURE__*/ (0,jsx_runtime.jsx)(Layout, {
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(SessionsPage, {})
    });
    if (matches = url.pathname.match(/^\/requests(\/)?$/)) return /*#__PURE__*/ (0,jsx_runtime.jsx)(Layout, {
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(RequestsPage, {})
    });
    if (matches = url.pathname.match(/^\/plugins(\/)?$/)) return /*#__PURE__*/ (0,jsx_runtime.jsx)(Layout, {
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(SnapsPage, {})
    });
    if (matches = url.pathname.match(/^\/wallet\/([^\/]+)(\/)?$/)) return /*#__PURE__*/ (0,jsx_runtime.jsx)(Layout, {
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(wallets_page/* WalletPage */.ds, {
            uuid: matches[1]
        })
    });
    if (matches = url.pathname.match(/^\/wallet\/([^\/]+)\/camera(\/)?$/)) return /*#__PURE__*/ (0,jsx_runtime.jsx)(Layout, {
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(WalletCameraPage, {
            uuid: matches[1]
        })
    });
    if (matches = url.pathname.match(/^\/seed\/([^\/]+)(\/)?$/)) return /*#__PURE__*/ (0,jsx_runtime.jsx)(Layout, {
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(SeedPage, {
            uuid: matches[1]
        })
    });
    if (matches = url.pathname.match(/^\/settings(\/)?$/)) return /*#__PURE__*/ (0,jsx_runtime.jsx)(Layout, {
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(SettingsPage, {})
    });
    if (matches = url.pathname.match(/^\/eth_requestAccounts(\/)?$/)) return /*#__PURE__*/ (0,jsx_runtime.jsx)(Layout, {
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(popup.WalletAndChainSelectPage, {})
    });
    if (matches = url.pathname.match(/^\/eth_sendTransaction(\/)?$/)) return /*#__PURE__*/ (0,jsx_runtime.jsx)(Layout, {
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(popup.TransactPage, {})
    });
    if (matches = url.pathname.match(/^\/personal_sign(\/)?$/)) return /*#__PURE__*/ (0,jsx_runtime.jsx)(Layout, {
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(popup.PersonalSignPage, {})
    });
    if (matches = url.pathname.match(/^\/eth_signTypedData_v4(\/)?$/)) return /*#__PURE__*/ (0,jsx_runtime.jsx)(Layout, {
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(popup.TypedSignPage, {})
    });
    if (matches = url.pathname.match(/^\/done(\/)?$/)) return /*#__PURE__*/ (0,jsx_runtime.jsx)(Layout, {
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(popup.DonePage, {})
    });
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(all_page/* FullLandingPage */.sb, {});
}


/***/ })

}]);