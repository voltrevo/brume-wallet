"use strict";
(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[376],{

/***/ 24:
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   _2: function() { return /* binding */ uintByName; },
/* harmony export */   bz: function() { return /* binding */ AbiUint8; },
/* harmony export */   cf: function() { return /* binding */ AbiUint32; },
/* harmony export */   jZ: function() { return /* binding */ AbiUint112; },
/* harmony export */   kq: function() { return /* binding */ AbiUint256; }
/* harmony export */ });
/* unused harmony exports AbiUint104, AbiUint112, AbiUint120, AbiUint128, AbiUint136, AbiUint144, AbiUint152, AbiUint16, AbiUint160, AbiUint168, AbiUint176, AbiUint184, AbiUint192, AbiUint200, AbiUint208, AbiUint216, AbiUint224, AbiUint232, AbiUint24, AbiUint240, AbiUint248, AbiUint256, AbiUint32, AbiUint40, AbiUint48, AbiUint56, AbiUint64, AbiUint72, AbiUint8, AbiUint80, AbiUint88, AbiUint96, BytesAbiUint104, BytesAbiUint112, BytesAbiUint120, BytesAbiUint128, BytesAbiUint136, BytesAbiUint144, BytesAbiUint152, BytesAbiUint16, BytesAbiUint160, BytesAbiUint168, BytesAbiUint176, BytesAbiUint184, BytesAbiUint192, BytesAbiUint200, BytesAbiUint208, BytesAbiUint216, BytesAbiUint224, BytesAbiUint232, BytesAbiUint24, BytesAbiUint240, BytesAbiUint248, BytesAbiUint256, BytesAbiUint32, BytesAbiUint40, BytesAbiUint48, BytesAbiUint56, BytesAbiUint64, BytesAbiUint72, BytesAbiUint8, BytesAbiUint80, BytesAbiUint88, BytesAbiUint96, NumberAbiUint16, NumberAbiUint24, NumberAbiUint32, NumberAbiUint8, Uint104, Uint120, Uint128, Uint136, Uint144, Uint152, Uint16, Uint160, Uint168, Uint176, Uint184, Uint192, Uint200, Uint208, Uint216, Uint224, Uint232, Uint24, Uint240, Uint248, Uint40, Uint48, Uint56, Uint64, Uint72, Uint80, Uint88, Uint96, ZeroHexAbiUint104, ZeroHexAbiUint112, ZeroHexAbiUint120, ZeroHexAbiUint128, ZeroHexAbiUint136, ZeroHexAbiUint144, ZeroHexAbiUint152, ZeroHexAbiUint16, ZeroHexAbiUint160, ZeroHexAbiUint168, ZeroHexAbiUint176, ZeroHexAbiUint184, ZeroHexAbiUint192, ZeroHexAbiUint200, ZeroHexAbiUint208, ZeroHexAbiUint216, ZeroHexAbiUint224, ZeroHexAbiUint232, ZeroHexAbiUint24, ZeroHexAbiUint240, ZeroHexAbiUint248, ZeroHexAbiUint256, ZeroHexAbiUint32, ZeroHexAbiUint40, ZeroHexAbiUint48, ZeroHexAbiUint56, ZeroHexAbiUint64, ZeroHexAbiUint72, ZeroHexAbiUint8, ZeroHexAbiUint80, ZeroHexAbiUint88, ZeroHexAbiUint96 */
/* harmony import */ var _node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1305);
/* harmony import */ var _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1694);
/* harmony import */ var _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2248);




var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _0, _1, _2, _3, _4, _5, _6, _7, _8, _9, _10, _11, _12, _13, _14, _15, _16, _17, _18, _19, _20, _21, _22, _23, _24, _25, _26, _27, _28, _29, _30, _31, _32, _33, _34, _35, _36, _37, _38, _39, _40, _41, _42, _43;
var AbiUint8;
(function (AbiUint8) {
    AbiUint8.dynamic = false;
    AbiUint8.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiUint8.create(value);
        if (typeof value === "number")
            return NumberAbiUint8.create(value);
        if (typeof value === "bigint")
            return NumberAbiUint8.create(Number(value));
        return ZeroHexAbiUint8.create(value);
    }
    AbiUint8.create = create;
    function from(value) {
        return AbiUint8.create(value);
    }
    AbiUint8.from = from;
    function fromNumber(value) {
        return NumberAbiUint8.fromNumber(value);
    }
    AbiUint8.fromNumber = fromNumber;
    function fromBigInt(value) {
        return NumberAbiUint8.fromBigInt(value);
    }
    AbiUint8.fromBigInt = fromBigInt;
    function codegen() {
        return `Abi.Int8`;
    }
    AbiUint8.codegen = codegen;
    function decodeOrThrow(cursor) {
        return NumberAbiUint8.decodeOrThrow(cursor);
    }
    AbiUint8.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return NumberAbiUint8.readOrThrow(cursor);
    }
    AbiUint8.readOrThrow = readOrThrow;
})(AbiUint8 || (AbiUint8 = {}));
class BytesAbiUint8 {
    value;
    #class = _a;
    name = this.#class.name;
    static bytes = 1;
    static nibbles = 2;
    static bits = 8;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _a(value);
    }
    static from(value) {
        return _a.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiUint8(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiUint8(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int8`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _a.nibbles;
        const content = cursor.readOrThrow(_a.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _a(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - this.value.length);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _a.bytes;
        const content = cursor.readOrThrow(_a.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _a(value);
    }
}
_a = BytesAbiUint8;
class NumberAbiUint8 {
    value;
    #class = _b;
    name = this.#class.name;
    static bytes = 1;
    static nibbles = 2;
    static bits = 8;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return new _b(value);
    }
    static fromBigInt(value) {
        return new _b(Number(value));
    }
    static create(value) {
        return new _b(value);
    }
    static from(value) {
        return _b.create(value);
    }
    intoOrThrow() {
        return BigInt(this.value);
    }
    toJSON() {
        return this.value.toString();
    }
    static codegen() {
        return `Abi.Int8`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.toString(16).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value.toString(16);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _b.nibbles;
        const content = cursor.readOrThrow(_b.nibbles);
        const value = parseInt(content, 16);
        return new _b(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - 4);
        cursor.writeUint32OrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - 4;
        const value = cursor.readUint32OrThrow();
        return new _b(value);
    }
}
_b = NumberAbiUint8;
class ZeroHexAbiUint8 {
    value;
    #class = _c;
    name = this.#class.name;
    static bytes = 1;
    static nibbles = 2;
    static bits = 8;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return new _c(value.toString(16));
    }
    static fromBigInt(value) {
        return new _c(value.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _c.fromBigInt(value);
        if (typeof value === "number")
            return _c.fromNumber(value);
        if (value.startsWith("0x"))
            return new _c(value.slice(2));
        return _c.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _c.create(value);
    }
    intoOrThrow() {
        return this.value.length ? BigInt("0x" + this.value) : 0n;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int8`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _c.nibbles;
        const content = cursor.readOrThrow(_c.nibbles);
        return new _c(content);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_1 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__addDisposableResource */ .b)(env_1, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_1) {
            env_1.error = e_1;
            env_1.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__disposeResources */ .f)(env_1);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _c.bytes;
        const content = cursor.readOrThrow(_c.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _c(value);
    }
}
_c = ZeroHexAbiUint8;
var AbiUint16;
(function (AbiUint16) {
    AbiUint16.dynamic = false;
    AbiUint16.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiUint16.create(value);
        if (typeof value === "number")
            return NumberAbiUint16.create(value);
        if (typeof value === "bigint")
            return NumberAbiUint16.create(Number(value));
        return ZeroHexAbiUint16.create(value);
    }
    AbiUint16.create = create;
    function from(value) {
        return AbiUint16.create(value);
    }
    AbiUint16.from = from;
    function fromNumber(value) {
        return NumberAbiUint16.fromNumber(value);
    }
    AbiUint16.fromNumber = fromNumber;
    function fromBigInt(value) {
        return NumberAbiUint16.fromBigInt(value);
    }
    AbiUint16.fromBigInt = fromBigInt;
    function codegen() {
        return `Abi.Int16`;
    }
    AbiUint16.codegen = codegen;
    function decodeOrThrow(cursor) {
        return NumberAbiUint16.decodeOrThrow(cursor);
    }
    AbiUint16.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return NumberAbiUint16.readOrThrow(cursor);
    }
    AbiUint16.readOrThrow = readOrThrow;
})(AbiUint16 || (AbiUint16 = {}));
class BytesAbiUint16 {
    value;
    #class = _d;
    name = this.#class.name;
    static bytes = 2;
    static nibbles = 4;
    static bits = 16;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _d(value);
    }
    static from(value) {
        return _d.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiUint16(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiUint16(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int16`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _d.nibbles;
        const content = cursor.readOrThrow(_d.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _d(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - this.value.length);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _d.bytes;
        const content = cursor.readOrThrow(_d.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _d(value);
    }
}
_d = BytesAbiUint16;
class NumberAbiUint16 {
    value;
    #class = _e;
    name = this.#class.name;
    static bytes = 2;
    static nibbles = 4;
    static bits = 16;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return new _e(value);
    }
    static fromBigInt(value) {
        return new _e(Number(value));
    }
    static create(value) {
        return new _e(value);
    }
    static from(value) {
        return _e.create(value);
    }
    intoOrThrow() {
        return BigInt(this.value);
    }
    toJSON() {
        return this.value.toString();
    }
    static codegen() {
        return `Abi.Int16`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.toString(16).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value.toString(16);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _e.nibbles;
        const content = cursor.readOrThrow(_e.nibbles);
        const value = parseInt(content, 16);
        return new _e(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - 4);
        cursor.writeUint32OrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - 4;
        const value = cursor.readUint32OrThrow();
        return new _e(value);
    }
}
_e = NumberAbiUint16;
class ZeroHexAbiUint16 {
    value;
    #class = _f;
    name = this.#class.name;
    static bytes = 2;
    static nibbles = 4;
    static bits = 16;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return new _f(value.toString(16));
    }
    static fromBigInt(value) {
        return new _f(value.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _f.fromBigInt(value);
        if (typeof value === "number")
            return _f.fromNumber(value);
        if (value.startsWith("0x"))
            return new _f(value.slice(2));
        return _f.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _f.create(value);
    }
    intoOrThrow() {
        return this.value.length ? BigInt("0x" + this.value) : 0n;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int16`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _f.nibbles;
        const content = cursor.readOrThrow(_f.nibbles);
        return new _f(content);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_2 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__addDisposableResource */ .b)(env_2, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_2) {
            env_2.error = e_2;
            env_2.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__disposeResources */ .f)(env_2);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _f.bytes;
        const content = cursor.readOrThrow(_f.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _f(value);
    }
}
_f = ZeroHexAbiUint16;
var AbiUint24;
(function (AbiUint24) {
    AbiUint24.dynamic = false;
    AbiUint24.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiUint24.create(value);
        if (typeof value === "number")
            return NumberAbiUint24.create(value);
        if (typeof value === "bigint")
            return NumberAbiUint24.create(Number(value));
        return ZeroHexAbiUint24.create(value);
    }
    AbiUint24.create = create;
    function from(value) {
        return AbiUint24.create(value);
    }
    AbiUint24.from = from;
    function fromNumber(value) {
        return NumberAbiUint24.fromNumber(value);
    }
    AbiUint24.fromNumber = fromNumber;
    function fromBigInt(value) {
        return NumberAbiUint24.fromBigInt(value);
    }
    AbiUint24.fromBigInt = fromBigInt;
    function codegen() {
        return `Abi.Int24`;
    }
    AbiUint24.codegen = codegen;
    function decodeOrThrow(cursor) {
        return NumberAbiUint24.decodeOrThrow(cursor);
    }
    AbiUint24.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return NumberAbiUint24.readOrThrow(cursor);
    }
    AbiUint24.readOrThrow = readOrThrow;
})(AbiUint24 || (AbiUint24 = {}));
class BytesAbiUint24 {
    value;
    #class = _g;
    name = this.#class.name;
    static bytes = 3;
    static nibbles = 6;
    static bits = 24;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _g(value);
    }
    static from(value) {
        return _g.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiUint24(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiUint24(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int24`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _g.nibbles;
        const content = cursor.readOrThrow(_g.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _g(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - this.value.length);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _g.bytes;
        const content = cursor.readOrThrow(_g.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _g(value);
    }
}
_g = BytesAbiUint24;
class NumberAbiUint24 {
    value;
    #class = _h;
    name = this.#class.name;
    static bytes = 3;
    static nibbles = 6;
    static bits = 24;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return new _h(value);
    }
    static fromBigInt(value) {
        return new _h(Number(value));
    }
    static create(value) {
        return new _h(value);
    }
    static from(value) {
        return _h.create(value);
    }
    intoOrThrow() {
        return BigInt(this.value);
    }
    toJSON() {
        return this.value.toString();
    }
    static codegen() {
        return `Abi.Int24`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.toString(16).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value.toString(16);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _h.nibbles;
        const content = cursor.readOrThrow(_h.nibbles);
        const value = parseInt(content, 16);
        return new _h(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - 4);
        cursor.writeUint32OrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - 4;
        const value = cursor.readUint32OrThrow();
        return new _h(value);
    }
}
_h = NumberAbiUint24;
class ZeroHexAbiUint24 {
    value;
    #class = _j;
    name = this.#class.name;
    static bytes = 3;
    static nibbles = 6;
    static bits = 24;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return new _j(value.toString(16));
    }
    static fromBigInt(value) {
        return new _j(value.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _j.fromBigInt(value);
        if (typeof value === "number")
            return _j.fromNumber(value);
        if (value.startsWith("0x"))
            return new _j(value.slice(2));
        return _j.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _j.create(value);
    }
    intoOrThrow() {
        return this.value.length ? BigInt("0x" + this.value) : 0n;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int24`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _j.nibbles;
        const content = cursor.readOrThrow(_j.nibbles);
        return new _j(content);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_3 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__addDisposableResource */ .b)(env_3, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_3) {
            env_3.error = e_3;
            env_3.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__disposeResources */ .f)(env_3);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _j.bytes;
        const content = cursor.readOrThrow(_j.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _j(value);
    }
}
_j = ZeroHexAbiUint24;
var AbiUint32;
(function (AbiUint32) {
    AbiUint32.dynamic = false;
    AbiUint32.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiUint32.create(value);
        if (typeof value === "number")
            return NumberAbiUint32.create(value);
        if (typeof value === "bigint")
            return NumberAbiUint32.create(Number(value));
        return ZeroHexAbiUint32.create(value);
    }
    AbiUint32.create = create;
    function from(value) {
        return AbiUint32.create(value);
    }
    AbiUint32.from = from;
    function fromNumber(value) {
        return NumberAbiUint32.fromNumber(value);
    }
    AbiUint32.fromNumber = fromNumber;
    function fromBigInt(value) {
        return NumberAbiUint32.fromBigInt(value);
    }
    AbiUint32.fromBigInt = fromBigInt;
    function codegen() {
        return `Abi.Int32`;
    }
    AbiUint32.codegen = codegen;
    function decodeOrThrow(cursor) {
        return NumberAbiUint32.decodeOrThrow(cursor);
    }
    AbiUint32.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return NumberAbiUint32.readOrThrow(cursor);
    }
    AbiUint32.readOrThrow = readOrThrow;
})(AbiUint32 || (AbiUint32 = {}));
class BytesAbiUint32 {
    value;
    #class = _k;
    name = this.#class.name;
    static bytes = 4;
    static nibbles = 8;
    static bits = 32;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _k(value);
    }
    static from(value) {
        return _k.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiUint32(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiUint32(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int32`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _k.nibbles;
        const content = cursor.readOrThrow(_k.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _k(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - this.value.length);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _k.bytes;
        const content = cursor.readOrThrow(_k.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _k(value);
    }
}
_k = BytesAbiUint32;
class NumberAbiUint32 {
    value;
    #class = _l;
    name = this.#class.name;
    static bytes = 4;
    static nibbles = 8;
    static bits = 32;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return new _l(value);
    }
    static fromBigInt(value) {
        return new _l(Number(value));
    }
    static create(value) {
        return new _l(value);
    }
    static from(value) {
        return _l.create(value);
    }
    intoOrThrow() {
        return BigInt(this.value);
    }
    toJSON() {
        return this.value.toString();
    }
    static codegen() {
        return `Abi.Int32`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.toString(16).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value.toString(16);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _l.nibbles;
        const content = cursor.readOrThrow(_l.nibbles);
        const value = parseInt(content, 16);
        return new _l(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - 4);
        cursor.writeUint32OrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - 4;
        const value = cursor.readUint32OrThrow();
        return new _l(value);
    }
}
_l = NumberAbiUint32;
class ZeroHexAbiUint32 {
    value;
    #class = _m;
    name = this.#class.name;
    static bytes = 4;
    static nibbles = 8;
    static bits = 32;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return new _m(value.toString(16));
    }
    static fromBigInt(value) {
        return new _m(value.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _m.fromBigInt(value);
        if (typeof value === "number")
            return _m.fromNumber(value);
        if (value.startsWith("0x"))
            return new _m(value.slice(2));
        return _m.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _m.create(value);
    }
    intoOrThrow() {
        return this.value.length ? BigInt("0x" + this.value) : 0n;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int32`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _m.nibbles;
        const content = cursor.readOrThrow(_m.nibbles);
        return new _m(content);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_4 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__addDisposableResource */ .b)(env_4, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_4) {
            env_4.error = e_4;
            env_4.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__disposeResources */ .f)(env_4);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _m.bytes;
        const content = cursor.readOrThrow(_m.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _m(value);
    }
}
_m = ZeroHexAbiUint32;
var AbiUint40;
(function (AbiUint40) {
    AbiUint40.dynamic = false;
    AbiUint40.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiUint40.create(value);
        return ZeroHexAbiUint40.create(value);
    }
    AbiUint40.create = create;
    function from(value) {
        return AbiUint40.create(value);
    }
    AbiUint40.from = from;
    function fromNumber(value) {
        return ZeroHexAbiUint40.fromNumber(value);
    }
    AbiUint40.fromNumber = fromNumber;
    function fromBigInt(value) {
        return ZeroHexAbiUint40.fromBigInt(value);
    }
    AbiUint40.fromBigInt = fromBigInt;
    function codegen() {
        return `Abi.Int40`;
    }
    AbiUint40.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiUint40.decodeOrThrow(cursor);
    }
    AbiUint40.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiUint40.readOrThrow(cursor);
    }
    AbiUint40.readOrThrow = readOrThrow;
})(AbiUint40 || (AbiUint40 = {}));
class BytesAbiUint40 {
    value;
    #class = _o;
    name = this.#class.name;
    static bytes = 5;
    static nibbles = 10;
    static bits = 40;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _o(value);
    }
    static from(value) {
        return _o.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiUint40(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiUint40(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int40`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _o.nibbles;
        const content = cursor.readOrThrow(_o.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _o(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - this.value.length);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _o.bytes;
        const content = cursor.readOrThrow(_o.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _o(value);
    }
}
_o = BytesAbiUint40;
class ZeroHexAbiUint40 {
    value;
    #class = _p;
    name = this.#class.name;
    static bytes = 5;
    static nibbles = 10;
    static bits = 40;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return new _p(value.toString(16));
    }
    static fromBigInt(value) {
        return new _p(value.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _p.fromBigInt(value);
        if (typeof value === "number")
            return _p.fromNumber(value);
        if (value.startsWith("0x"))
            return new _p(value.slice(2));
        return _p.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _p.create(value);
    }
    intoOrThrow() {
        return this.value.length ? BigInt("0x" + this.value) : 0n;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int40`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _p.nibbles;
        const content = cursor.readOrThrow(_p.nibbles);
        return new _p(content);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_5 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__addDisposableResource */ .b)(env_5, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_5) {
            env_5.error = e_5;
            env_5.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__disposeResources */ .f)(env_5);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _p.bytes;
        const content = cursor.readOrThrow(_p.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _p(value);
    }
}
_p = ZeroHexAbiUint40;
var AbiUint48;
(function (AbiUint48) {
    AbiUint48.dynamic = false;
    AbiUint48.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiUint48.create(value);
        return ZeroHexAbiUint48.create(value);
    }
    AbiUint48.create = create;
    function from(value) {
        return AbiUint48.create(value);
    }
    AbiUint48.from = from;
    function fromNumber(value) {
        return ZeroHexAbiUint48.fromNumber(value);
    }
    AbiUint48.fromNumber = fromNumber;
    function fromBigInt(value) {
        return ZeroHexAbiUint48.fromBigInt(value);
    }
    AbiUint48.fromBigInt = fromBigInt;
    function codegen() {
        return `Abi.Int48`;
    }
    AbiUint48.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiUint48.decodeOrThrow(cursor);
    }
    AbiUint48.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiUint48.readOrThrow(cursor);
    }
    AbiUint48.readOrThrow = readOrThrow;
})(AbiUint48 || (AbiUint48 = {}));
class BytesAbiUint48 {
    value;
    #class = _q;
    name = this.#class.name;
    static bytes = 6;
    static nibbles = 12;
    static bits = 48;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _q(value);
    }
    static from(value) {
        return _q.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiUint48(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiUint48(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int48`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _q.nibbles;
        const content = cursor.readOrThrow(_q.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _q(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - this.value.length);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _q.bytes;
        const content = cursor.readOrThrow(_q.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _q(value);
    }
}
_q = BytesAbiUint48;
class ZeroHexAbiUint48 {
    value;
    #class = _r;
    name = this.#class.name;
    static bytes = 6;
    static nibbles = 12;
    static bits = 48;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return new _r(value.toString(16));
    }
    static fromBigInt(value) {
        return new _r(value.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _r.fromBigInt(value);
        if (typeof value === "number")
            return _r.fromNumber(value);
        if (value.startsWith("0x"))
            return new _r(value.slice(2));
        return _r.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _r.create(value);
    }
    intoOrThrow() {
        return this.value.length ? BigInt("0x" + this.value) : 0n;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int48`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _r.nibbles;
        const content = cursor.readOrThrow(_r.nibbles);
        return new _r(content);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_6 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__addDisposableResource */ .b)(env_6, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_6) {
            env_6.error = e_6;
            env_6.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__disposeResources */ .f)(env_6);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _r.bytes;
        const content = cursor.readOrThrow(_r.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _r(value);
    }
}
_r = ZeroHexAbiUint48;
var AbiUint56;
(function (AbiUint56) {
    AbiUint56.dynamic = false;
    AbiUint56.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiUint56.create(value);
        return ZeroHexAbiUint56.create(value);
    }
    AbiUint56.create = create;
    function from(value) {
        return AbiUint56.create(value);
    }
    AbiUint56.from = from;
    function fromNumber(value) {
        return ZeroHexAbiUint56.fromNumber(value);
    }
    AbiUint56.fromNumber = fromNumber;
    function fromBigInt(value) {
        return ZeroHexAbiUint56.fromBigInt(value);
    }
    AbiUint56.fromBigInt = fromBigInt;
    function codegen() {
        return `Abi.Int56`;
    }
    AbiUint56.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiUint56.decodeOrThrow(cursor);
    }
    AbiUint56.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiUint56.readOrThrow(cursor);
    }
    AbiUint56.readOrThrow = readOrThrow;
})(AbiUint56 || (AbiUint56 = {}));
class BytesAbiUint56 {
    value;
    #class = _s;
    name = this.#class.name;
    static bytes = 7;
    static nibbles = 14;
    static bits = 56;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _s(value);
    }
    static from(value) {
        return _s.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiUint56(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiUint56(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int56`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _s.nibbles;
        const content = cursor.readOrThrow(_s.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _s(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - this.value.length);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _s.bytes;
        const content = cursor.readOrThrow(_s.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _s(value);
    }
}
_s = BytesAbiUint56;
class ZeroHexAbiUint56 {
    value;
    #class = _t;
    name = this.#class.name;
    static bytes = 7;
    static nibbles = 14;
    static bits = 56;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return new _t(value.toString(16));
    }
    static fromBigInt(value) {
        return new _t(value.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _t.fromBigInt(value);
        if (typeof value === "number")
            return _t.fromNumber(value);
        if (value.startsWith("0x"))
            return new _t(value.slice(2));
        return _t.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _t.create(value);
    }
    intoOrThrow() {
        return this.value.length ? BigInt("0x" + this.value) : 0n;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int56`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _t.nibbles;
        const content = cursor.readOrThrow(_t.nibbles);
        return new _t(content);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_7 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__addDisposableResource */ .b)(env_7, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_7) {
            env_7.error = e_7;
            env_7.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__disposeResources */ .f)(env_7);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _t.bytes;
        const content = cursor.readOrThrow(_t.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _t(value);
    }
}
_t = ZeroHexAbiUint56;
var AbiUint64;
(function (AbiUint64) {
    AbiUint64.dynamic = false;
    AbiUint64.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiUint64.create(value);
        return ZeroHexAbiUint64.create(value);
    }
    AbiUint64.create = create;
    function from(value) {
        return AbiUint64.create(value);
    }
    AbiUint64.from = from;
    function fromNumber(value) {
        return ZeroHexAbiUint64.fromNumber(value);
    }
    AbiUint64.fromNumber = fromNumber;
    function fromBigInt(value) {
        return ZeroHexAbiUint64.fromBigInt(value);
    }
    AbiUint64.fromBigInt = fromBigInt;
    function codegen() {
        return `Abi.Int64`;
    }
    AbiUint64.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiUint64.decodeOrThrow(cursor);
    }
    AbiUint64.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiUint64.readOrThrow(cursor);
    }
    AbiUint64.readOrThrow = readOrThrow;
})(AbiUint64 || (AbiUint64 = {}));
class BytesAbiUint64 {
    value;
    #class = _u;
    name = this.#class.name;
    static bytes = 8;
    static nibbles = 16;
    static bits = 64;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _u(value);
    }
    static from(value) {
        return _u.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiUint64(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiUint64(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int64`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _u.nibbles;
        const content = cursor.readOrThrow(_u.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _u(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - this.value.length);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _u.bytes;
        const content = cursor.readOrThrow(_u.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _u(value);
    }
}
_u = BytesAbiUint64;
class ZeroHexAbiUint64 {
    value;
    #class = _v;
    name = this.#class.name;
    static bytes = 8;
    static nibbles = 16;
    static bits = 64;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return new _v(value.toString(16));
    }
    static fromBigInt(value) {
        return new _v(value.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _v.fromBigInt(value);
        if (typeof value === "number")
            return _v.fromNumber(value);
        if (value.startsWith("0x"))
            return new _v(value.slice(2));
        return _v.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _v.create(value);
    }
    intoOrThrow() {
        return this.value.length ? BigInt("0x" + this.value) : 0n;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int64`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _v.nibbles;
        const content = cursor.readOrThrow(_v.nibbles);
        return new _v(content);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_8 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__addDisposableResource */ .b)(env_8, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_8) {
            env_8.error = e_8;
            env_8.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__disposeResources */ .f)(env_8);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _v.bytes;
        const content = cursor.readOrThrow(_v.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _v(value);
    }
}
_v = ZeroHexAbiUint64;
var AbiUint72;
(function (AbiUint72) {
    AbiUint72.dynamic = false;
    AbiUint72.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiUint72.create(value);
        return ZeroHexAbiUint72.create(value);
    }
    AbiUint72.create = create;
    function from(value) {
        return AbiUint72.create(value);
    }
    AbiUint72.from = from;
    function fromNumber(value) {
        return ZeroHexAbiUint72.fromNumber(value);
    }
    AbiUint72.fromNumber = fromNumber;
    function fromBigInt(value) {
        return ZeroHexAbiUint72.fromBigInt(value);
    }
    AbiUint72.fromBigInt = fromBigInt;
    function codegen() {
        return `Abi.Int72`;
    }
    AbiUint72.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiUint72.decodeOrThrow(cursor);
    }
    AbiUint72.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiUint72.readOrThrow(cursor);
    }
    AbiUint72.readOrThrow = readOrThrow;
})(AbiUint72 || (AbiUint72 = {}));
class BytesAbiUint72 {
    value;
    #class = _w;
    name = this.#class.name;
    static bytes = 9;
    static nibbles = 18;
    static bits = 72;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _w(value);
    }
    static from(value) {
        return _w.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiUint72(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiUint72(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int72`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _w.nibbles;
        const content = cursor.readOrThrow(_w.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _w(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - this.value.length);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _w.bytes;
        const content = cursor.readOrThrow(_w.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _w(value);
    }
}
_w = BytesAbiUint72;
class ZeroHexAbiUint72 {
    value;
    #class = _x;
    name = this.#class.name;
    static bytes = 9;
    static nibbles = 18;
    static bits = 72;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return new _x(value.toString(16));
    }
    static fromBigInt(value) {
        return new _x(value.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _x.fromBigInt(value);
        if (typeof value === "number")
            return _x.fromNumber(value);
        if (value.startsWith("0x"))
            return new _x(value.slice(2));
        return _x.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _x.create(value);
    }
    intoOrThrow() {
        return this.value.length ? BigInt("0x" + this.value) : 0n;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int72`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _x.nibbles;
        const content = cursor.readOrThrow(_x.nibbles);
        return new _x(content);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_9 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__addDisposableResource */ .b)(env_9, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_9) {
            env_9.error = e_9;
            env_9.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__disposeResources */ .f)(env_9);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _x.bytes;
        const content = cursor.readOrThrow(_x.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _x(value);
    }
}
_x = ZeroHexAbiUint72;
var AbiUint80;
(function (AbiUint80) {
    AbiUint80.dynamic = false;
    AbiUint80.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiUint80.create(value);
        return ZeroHexAbiUint80.create(value);
    }
    AbiUint80.create = create;
    function from(value) {
        return AbiUint80.create(value);
    }
    AbiUint80.from = from;
    function fromNumber(value) {
        return ZeroHexAbiUint80.fromNumber(value);
    }
    AbiUint80.fromNumber = fromNumber;
    function fromBigInt(value) {
        return ZeroHexAbiUint80.fromBigInt(value);
    }
    AbiUint80.fromBigInt = fromBigInt;
    function codegen() {
        return `Abi.Int80`;
    }
    AbiUint80.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiUint80.decodeOrThrow(cursor);
    }
    AbiUint80.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiUint80.readOrThrow(cursor);
    }
    AbiUint80.readOrThrow = readOrThrow;
})(AbiUint80 || (AbiUint80 = {}));
class BytesAbiUint80 {
    value;
    #class = _y;
    name = this.#class.name;
    static bytes = 10;
    static nibbles = 20;
    static bits = 80;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _y(value);
    }
    static from(value) {
        return _y.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiUint80(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiUint80(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int80`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _y.nibbles;
        const content = cursor.readOrThrow(_y.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _y(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - this.value.length);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _y.bytes;
        const content = cursor.readOrThrow(_y.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _y(value);
    }
}
_y = BytesAbiUint80;
class ZeroHexAbiUint80 {
    value;
    #class = _z;
    name = this.#class.name;
    static bytes = 10;
    static nibbles = 20;
    static bits = 80;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return new _z(value.toString(16));
    }
    static fromBigInt(value) {
        return new _z(value.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _z.fromBigInt(value);
        if (typeof value === "number")
            return _z.fromNumber(value);
        if (value.startsWith("0x"))
            return new _z(value.slice(2));
        return _z.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _z.create(value);
    }
    intoOrThrow() {
        return this.value.length ? BigInt("0x" + this.value) : 0n;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int80`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _z.nibbles;
        const content = cursor.readOrThrow(_z.nibbles);
        return new _z(content);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_10 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__addDisposableResource */ .b)(env_10, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_10) {
            env_10.error = e_10;
            env_10.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__disposeResources */ .f)(env_10);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _z.bytes;
        const content = cursor.readOrThrow(_z.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _z(value);
    }
}
_z = ZeroHexAbiUint80;
var AbiUint88;
(function (AbiUint88) {
    AbiUint88.dynamic = false;
    AbiUint88.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiUint88.create(value);
        return ZeroHexAbiUint88.create(value);
    }
    AbiUint88.create = create;
    function from(value) {
        return AbiUint88.create(value);
    }
    AbiUint88.from = from;
    function fromNumber(value) {
        return ZeroHexAbiUint88.fromNumber(value);
    }
    AbiUint88.fromNumber = fromNumber;
    function fromBigInt(value) {
        return ZeroHexAbiUint88.fromBigInt(value);
    }
    AbiUint88.fromBigInt = fromBigInt;
    function codegen() {
        return `Abi.Int88`;
    }
    AbiUint88.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiUint88.decodeOrThrow(cursor);
    }
    AbiUint88.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiUint88.readOrThrow(cursor);
    }
    AbiUint88.readOrThrow = readOrThrow;
})(AbiUint88 || (AbiUint88 = {}));
class BytesAbiUint88 {
    value;
    #class = _0;
    name = this.#class.name;
    static bytes = 11;
    static nibbles = 22;
    static bits = 88;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _0(value);
    }
    static from(value) {
        return _0.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiUint88(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiUint88(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int88`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _0.nibbles;
        const content = cursor.readOrThrow(_0.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _0(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - this.value.length);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _0.bytes;
        const content = cursor.readOrThrow(_0.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _0(value);
    }
}
_0 = BytesAbiUint88;
class ZeroHexAbiUint88 {
    value;
    #class = _1;
    name = this.#class.name;
    static bytes = 11;
    static nibbles = 22;
    static bits = 88;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return new _1(value.toString(16));
    }
    static fromBigInt(value) {
        return new _1(value.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _1.fromBigInt(value);
        if (typeof value === "number")
            return _1.fromNumber(value);
        if (value.startsWith("0x"))
            return new _1(value.slice(2));
        return _1.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _1.create(value);
    }
    intoOrThrow() {
        return this.value.length ? BigInt("0x" + this.value) : 0n;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int88`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _1.nibbles;
        const content = cursor.readOrThrow(_1.nibbles);
        return new _1(content);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_11 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__addDisposableResource */ .b)(env_11, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_11) {
            env_11.error = e_11;
            env_11.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__disposeResources */ .f)(env_11);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _1.bytes;
        const content = cursor.readOrThrow(_1.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _1(value);
    }
}
_1 = ZeroHexAbiUint88;
var AbiUint96;
(function (AbiUint96) {
    AbiUint96.dynamic = false;
    AbiUint96.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiUint96.create(value);
        return ZeroHexAbiUint96.create(value);
    }
    AbiUint96.create = create;
    function from(value) {
        return AbiUint96.create(value);
    }
    AbiUint96.from = from;
    function fromNumber(value) {
        return ZeroHexAbiUint96.fromNumber(value);
    }
    AbiUint96.fromNumber = fromNumber;
    function fromBigInt(value) {
        return ZeroHexAbiUint96.fromBigInt(value);
    }
    AbiUint96.fromBigInt = fromBigInt;
    function codegen() {
        return `Abi.Int96`;
    }
    AbiUint96.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiUint96.decodeOrThrow(cursor);
    }
    AbiUint96.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiUint96.readOrThrow(cursor);
    }
    AbiUint96.readOrThrow = readOrThrow;
})(AbiUint96 || (AbiUint96 = {}));
class BytesAbiUint96 {
    value;
    #class = _2;
    name = this.#class.name;
    static bytes = 12;
    static nibbles = 24;
    static bits = 96;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _2(value);
    }
    static from(value) {
        return _2.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiUint96(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiUint96(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int96`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _2.nibbles;
        const content = cursor.readOrThrow(_2.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _2(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - this.value.length);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _2.bytes;
        const content = cursor.readOrThrow(_2.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _2(value);
    }
}
_2 = BytesAbiUint96;
class ZeroHexAbiUint96 {
    value;
    #class = _3;
    name = this.#class.name;
    static bytes = 12;
    static nibbles = 24;
    static bits = 96;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return new _3(value.toString(16));
    }
    static fromBigInt(value) {
        return new _3(value.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _3.fromBigInt(value);
        if (typeof value === "number")
            return _3.fromNumber(value);
        if (value.startsWith("0x"))
            return new _3(value.slice(2));
        return _3.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _3.create(value);
    }
    intoOrThrow() {
        return this.value.length ? BigInt("0x" + this.value) : 0n;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int96`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _3.nibbles;
        const content = cursor.readOrThrow(_3.nibbles);
        return new _3(content);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_12 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__addDisposableResource */ .b)(env_12, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_12) {
            env_12.error = e_12;
            env_12.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__disposeResources */ .f)(env_12);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _3.bytes;
        const content = cursor.readOrThrow(_3.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _3(value);
    }
}
_3 = ZeroHexAbiUint96;
var AbiUint104;
(function (AbiUint104) {
    AbiUint104.dynamic = false;
    AbiUint104.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiUint104.create(value);
        return ZeroHexAbiUint104.create(value);
    }
    AbiUint104.create = create;
    function from(value) {
        return AbiUint104.create(value);
    }
    AbiUint104.from = from;
    function fromNumber(value) {
        return ZeroHexAbiUint104.fromNumber(value);
    }
    AbiUint104.fromNumber = fromNumber;
    function fromBigInt(value) {
        return ZeroHexAbiUint104.fromBigInt(value);
    }
    AbiUint104.fromBigInt = fromBigInt;
    function codegen() {
        return `Abi.Int104`;
    }
    AbiUint104.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiUint104.decodeOrThrow(cursor);
    }
    AbiUint104.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiUint104.readOrThrow(cursor);
    }
    AbiUint104.readOrThrow = readOrThrow;
})(AbiUint104 || (AbiUint104 = {}));
class BytesAbiUint104 {
    value;
    #class = _4;
    name = this.#class.name;
    static bytes = 13;
    static nibbles = 26;
    static bits = 104;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _4(value);
    }
    static from(value) {
        return _4.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiUint104(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiUint104(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int104`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _4.nibbles;
        const content = cursor.readOrThrow(_4.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _4(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - this.value.length);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _4.bytes;
        const content = cursor.readOrThrow(_4.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _4(value);
    }
}
_4 = BytesAbiUint104;
class ZeroHexAbiUint104 {
    value;
    #class = _5;
    name = this.#class.name;
    static bytes = 13;
    static nibbles = 26;
    static bits = 104;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return new _5(value.toString(16));
    }
    static fromBigInt(value) {
        return new _5(value.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _5.fromBigInt(value);
        if (typeof value === "number")
            return _5.fromNumber(value);
        if (value.startsWith("0x"))
            return new _5(value.slice(2));
        return _5.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _5.create(value);
    }
    intoOrThrow() {
        return this.value.length ? BigInt("0x" + this.value) : 0n;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int104`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _5.nibbles;
        const content = cursor.readOrThrow(_5.nibbles);
        return new _5(content);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_13 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__addDisposableResource */ .b)(env_13, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_13) {
            env_13.error = e_13;
            env_13.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__disposeResources */ .f)(env_13);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _5.bytes;
        const content = cursor.readOrThrow(_5.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _5(value);
    }
}
_5 = ZeroHexAbiUint104;
var AbiUint112;
(function (AbiUint112) {
    AbiUint112.dynamic = false;
    AbiUint112.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiUint112.create(value);
        return ZeroHexAbiUint112.create(value);
    }
    AbiUint112.create = create;
    function from(value) {
        return AbiUint112.create(value);
    }
    AbiUint112.from = from;
    function fromNumber(value) {
        return ZeroHexAbiUint112.fromNumber(value);
    }
    AbiUint112.fromNumber = fromNumber;
    function fromBigInt(value) {
        return ZeroHexAbiUint112.fromBigInt(value);
    }
    AbiUint112.fromBigInt = fromBigInt;
    function codegen() {
        return `Abi.Int112`;
    }
    AbiUint112.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiUint112.decodeOrThrow(cursor);
    }
    AbiUint112.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiUint112.readOrThrow(cursor);
    }
    AbiUint112.readOrThrow = readOrThrow;
})(AbiUint112 || (AbiUint112 = {}));
class BytesAbiUint112 {
    value;
    #class = _6;
    name = this.#class.name;
    static bytes = 14;
    static nibbles = 28;
    static bits = 112;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _6(value);
    }
    static from(value) {
        return _6.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiUint112(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiUint112(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int112`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _6.nibbles;
        const content = cursor.readOrThrow(_6.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _6(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - this.value.length);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _6.bytes;
        const content = cursor.readOrThrow(_6.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _6(value);
    }
}
_6 = BytesAbiUint112;
class ZeroHexAbiUint112 {
    value;
    #class = _7;
    name = this.#class.name;
    static bytes = 14;
    static nibbles = 28;
    static bits = 112;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return new _7(value.toString(16));
    }
    static fromBigInt(value) {
        return new _7(value.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _7.fromBigInt(value);
        if (typeof value === "number")
            return _7.fromNumber(value);
        if (value.startsWith("0x"))
            return new _7(value.slice(2));
        return _7.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _7.create(value);
    }
    intoOrThrow() {
        return this.value.length ? BigInt("0x" + this.value) : 0n;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int112`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _7.nibbles;
        const content = cursor.readOrThrow(_7.nibbles);
        return new _7(content);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_14 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__addDisposableResource */ .b)(env_14, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_14) {
            env_14.error = e_14;
            env_14.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__disposeResources */ .f)(env_14);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _7.bytes;
        const content = cursor.readOrThrow(_7.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _7(value);
    }
}
_7 = ZeroHexAbiUint112;
var AbiUint120;
(function (AbiUint120) {
    AbiUint120.dynamic = false;
    AbiUint120.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiUint120.create(value);
        return ZeroHexAbiUint120.create(value);
    }
    AbiUint120.create = create;
    function from(value) {
        return AbiUint120.create(value);
    }
    AbiUint120.from = from;
    function fromNumber(value) {
        return ZeroHexAbiUint120.fromNumber(value);
    }
    AbiUint120.fromNumber = fromNumber;
    function fromBigInt(value) {
        return ZeroHexAbiUint120.fromBigInt(value);
    }
    AbiUint120.fromBigInt = fromBigInt;
    function codegen() {
        return `Abi.Int120`;
    }
    AbiUint120.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiUint120.decodeOrThrow(cursor);
    }
    AbiUint120.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiUint120.readOrThrow(cursor);
    }
    AbiUint120.readOrThrow = readOrThrow;
})(AbiUint120 || (AbiUint120 = {}));
class BytesAbiUint120 {
    value;
    #class = _8;
    name = this.#class.name;
    static bytes = 15;
    static nibbles = 30;
    static bits = 120;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _8(value);
    }
    static from(value) {
        return _8.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiUint120(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiUint120(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int120`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _8.nibbles;
        const content = cursor.readOrThrow(_8.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _8(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - this.value.length);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _8.bytes;
        const content = cursor.readOrThrow(_8.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _8(value);
    }
}
_8 = BytesAbiUint120;
class ZeroHexAbiUint120 {
    value;
    #class = _9;
    name = this.#class.name;
    static bytes = 15;
    static nibbles = 30;
    static bits = 120;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return new _9(value.toString(16));
    }
    static fromBigInt(value) {
        return new _9(value.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _9.fromBigInt(value);
        if (typeof value === "number")
            return _9.fromNumber(value);
        if (value.startsWith("0x"))
            return new _9(value.slice(2));
        return _9.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _9.create(value);
    }
    intoOrThrow() {
        return this.value.length ? BigInt("0x" + this.value) : 0n;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int120`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _9.nibbles;
        const content = cursor.readOrThrow(_9.nibbles);
        return new _9(content);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_15 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__addDisposableResource */ .b)(env_15, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_15) {
            env_15.error = e_15;
            env_15.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__disposeResources */ .f)(env_15);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _9.bytes;
        const content = cursor.readOrThrow(_9.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _9(value);
    }
}
_9 = ZeroHexAbiUint120;
var AbiUint128;
(function (AbiUint128) {
    AbiUint128.dynamic = false;
    AbiUint128.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiUint128.create(value);
        return ZeroHexAbiUint128.create(value);
    }
    AbiUint128.create = create;
    function from(value) {
        return AbiUint128.create(value);
    }
    AbiUint128.from = from;
    function fromNumber(value) {
        return ZeroHexAbiUint128.fromNumber(value);
    }
    AbiUint128.fromNumber = fromNumber;
    function fromBigInt(value) {
        return ZeroHexAbiUint128.fromBigInt(value);
    }
    AbiUint128.fromBigInt = fromBigInt;
    function codegen() {
        return `Abi.Int128`;
    }
    AbiUint128.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiUint128.decodeOrThrow(cursor);
    }
    AbiUint128.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiUint128.readOrThrow(cursor);
    }
    AbiUint128.readOrThrow = readOrThrow;
})(AbiUint128 || (AbiUint128 = {}));
class BytesAbiUint128 {
    value;
    #class = _10;
    name = this.#class.name;
    static bytes = 16;
    static nibbles = 32;
    static bits = 128;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _10(value);
    }
    static from(value) {
        return _10.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiUint128(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiUint128(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int128`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _10.nibbles;
        const content = cursor.readOrThrow(_10.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _10(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - this.value.length);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _10.bytes;
        const content = cursor.readOrThrow(_10.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _10(value);
    }
}
_10 = BytesAbiUint128;
class ZeroHexAbiUint128 {
    value;
    #class = _11;
    name = this.#class.name;
    static bytes = 16;
    static nibbles = 32;
    static bits = 128;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return new _11(value.toString(16));
    }
    static fromBigInt(value) {
        return new _11(value.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _11.fromBigInt(value);
        if (typeof value === "number")
            return _11.fromNumber(value);
        if (value.startsWith("0x"))
            return new _11(value.slice(2));
        return _11.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _11.create(value);
    }
    intoOrThrow() {
        return this.value.length ? BigInt("0x" + this.value) : 0n;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int128`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _11.nibbles;
        const content = cursor.readOrThrow(_11.nibbles);
        return new _11(content);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_16 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__addDisposableResource */ .b)(env_16, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_16) {
            env_16.error = e_16;
            env_16.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__disposeResources */ .f)(env_16);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _11.bytes;
        const content = cursor.readOrThrow(_11.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _11(value);
    }
}
_11 = ZeroHexAbiUint128;
var AbiUint136;
(function (AbiUint136) {
    AbiUint136.dynamic = false;
    AbiUint136.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiUint136.create(value);
        return ZeroHexAbiUint136.create(value);
    }
    AbiUint136.create = create;
    function from(value) {
        return AbiUint136.create(value);
    }
    AbiUint136.from = from;
    function fromNumber(value) {
        return ZeroHexAbiUint136.fromNumber(value);
    }
    AbiUint136.fromNumber = fromNumber;
    function fromBigInt(value) {
        return ZeroHexAbiUint136.fromBigInt(value);
    }
    AbiUint136.fromBigInt = fromBigInt;
    function codegen() {
        return `Abi.Int136`;
    }
    AbiUint136.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiUint136.decodeOrThrow(cursor);
    }
    AbiUint136.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiUint136.readOrThrow(cursor);
    }
    AbiUint136.readOrThrow = readOrThrow;
})(AbiUint136 || (AbiUint136 = {}));
class BytesAbiUint136 {
    value;
    #class = _12;
    name = this.#class.name;
    static bytes = 17;
    static nibbles = 34;
    static bits = 136;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _12(value);
    }
    static from(value) {
        return _12.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiUint136(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiUint136(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int136`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _12.nibbles;
        const content = cursor.readOrThrow(_12.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _12(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - this.value.length);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _12.bytes;
        const content = cursor.readOrThrow(_12.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _12(value);
    }
}
_12 = BytesAbiUint136;
class ZeroHexAbiUint136 {
    value;
    #class = _13;
    name = this.#class.name;
    static bytes = 17;
    static nibbles = 34;
    static bits = 136;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return new _13(value.toString(16));
    }
    static fromBigInt(value) {
        return new _13(value.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _13.fromBigInt(value);
        if (typeof value === "number")
            return _13.fromNumber(value);
        if (value.startsWith("0x"))
            return new _13(value.slice(2));
        return _13.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _13.create(value);
    }
    intoOrThrow() {
        return this.value.length ? BigInt("0x" + this.value) : 0n;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int136`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _13.nibbles;
        const content = cursor.readOrThrow(_13.nibbles);
        return new _13(content);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_17 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__addDisposableResource */ .b)(env_17, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_17) {
            env_17.error = e_17;
            env_17.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__disposeResources */ .f)(env_17);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _13.bytes;
        const content = cursor.readOrThrow(_13.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _13(value);
    }
}
_13 = ZeroHexAbiUint136;
var AbiUint144;
(function (AbiUint144) {
    AbiUint144.dynamic = false;
    AbiUint144.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiUint144.create(value);
        return ZeroHexAbiUint144.create(value);
    }
    AbiUint144.create = create;
    function from(value) {
        return AbiUint144.create(value);
    }
    AbiUint144.from = from;
    function fromNumber(value) {
        return ZeroHexAbiUint144.fromNumber(value);
    }
    AbiUint144.fromNumber = fromNumber;
    function fromBigInt(value) {
        return ZeroHexAbiUint144.fromBigInt(value);
    }
    AbiUint144.fromBigInt = fromBigInt;
    function codegen() {
        return `Abi.Int144`;
    }
    AbiUint144.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiUint144.decodeOrThrow(cursor);
    }
    AbiUint144.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiUint144.readOrThrow(cursor);
    }
    AbiUint144.readOrThrow = readOrThrow;
})(AbiUint144 || (AbiUint144 = {}));
class BytesAbiUint144 {
    value;
    #class = _14;
    name = this.#class.name;
    static bytes = 18;
    static nibbles = 36;
    static bits = 144;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _14(value);
    }
    static from(value) {
        return _14.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiUint144(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiUint144(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int144`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _14.nibbles;
        const content = cursor.readOrThrow(_14.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _14(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - this.value.length);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _14.bytes;
        const content = cursor.readOrThrow(_14.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _14(value);
    }
}
_14 = BytesAbiUint144;
class ZeroHexAbiUint144 {
    value;
    #class = _15;
    name = this.#class.name;
    static bytes = 18;
    static nibbles = 36;
    static bits = 144;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return new _15(value.toString(16));
    }
    static fromBigInt(value) {
        return new _15(value.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _15.fromBigInt(value);
        if (typeof value === "number")
            return _15.fromNumber(value);
        if (value.startsWith("0x"))
            return new _15(value.slice(2));
        return _15.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _15.create(value);
    }
    intoOrThrow() {
        return this.value.length ? BigInt("0x" + this.value) : 0n;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int144`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _15.nibbles;
        const content = cursor.readOrThrow(_15.nibbles);
        return new _15(content);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_18 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__addDisposableResource */ .b)(env_18, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_18) {
            env_18.error = e_18;
            env_18.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__disposeResources */ .f)(env_18);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _15.bytes;
        const content = cursor.readOrThrow(_15.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _15(value);
    }
}
_15 = ZeroHexAbiUint144;
var AbiUint152;
(function (AbiUint152) {
    AbiUint152.dynamic = false;
    AbiUint152.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiUint152.create(value);
        return ZeroHexAbiUint152.create(value);
    }
    AbiUint152.create = create;
    function from(value) {
        return AbiUint152.create(value);
    }
    AbiUint152.from = from;
    function fromNumber(value) {
        return ZeroHexAbiUint152.fromNumber(value);
    }
    AbiUint152.fromNumber = fromNumber;
    function fromBigInt(value) {
        return ZeroHexAbiUint152.fromBigInt(value);
    }
    AbiUint152.fromBigInt = fromBigInt;
    function codegen() {
        return `Abi.Int152`;
    }
    AbiUint152.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiUint152.decodeOrThrow(cursor);
    }
    AbiUint152.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiUint152.readOrThrow(cursor);
    }
    AbiUint152.readOrThrow = readOrThrow;
})(AbiUint152 || (AbiUint152 = {}));
class BytesAbiUint152 {
    value;
    #class = _16;
    name = this.#class.name;
    static bytes = 19;
    static nibbles = 38;
    static bits = 152;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _16(value);
    }
    static from(value) {
        return _16.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiUint152(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiUint152(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int152`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _16.nibbles;
        const content = cursor.readOrThrow(_16.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _16(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - this.value.length);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _16.bytes;
        const content = cursor.readOrThrow(_16.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _16(value);
    }
}
_16 = BytesAbiUint152;
class ZeroHexAbiUint152 {
    value;
    #class = _17;
    name = this.#class.name;
    static bytes = 19;
    static nibbles = 38;
    static bits = 152;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return new _17(value.toString(16));
    }
    static fromBigInt(value) {
        return new _17(value.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _17.fromBigInt(value);
        if (typeof value === "number")
            return _17.fromNumber(value);
        if (value.startsWith("0x"))
            return new _17(value.slice(2));
        return _17.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _17.create(value);
    }
    intoOrThrow() {
        return this.value.length ? BigInt("0x" + this.value) : 0n;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int152`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _17.nibbles;
        const content = cursor.readOrThrow(_17.nibbles);
        return new _17(content);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_19 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__addDisposableResource */ .b)(env_19, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_19) {
            env_19.error = e_19;
            env_19.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__disposeResources */ .f)(env_19);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _17.bytes;
        const content = cursor.readOrThrow(_17.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _17(value);
    }
}
_17 = ZeroHexAbiUint152;
var AbiUint160;
(function (AbiUint160) {
    AbiUint160.dynamic = false;
    AbiUint160.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiUint160.create(value);
        return ZeroHexAbiUint160.create(value);
    }
    AbiUint160.create = create;
    function from(value) {
        return AbiUint160.create(value);
    }
    AbiUint160.from = from;
    function fromNumber(value) {
        return ZeroHexAbiUint160.fromNumber(value);
    }
    AbiUint160.fromNumber = fromNumber;
    function fromBigInt(value) {
        return ZeroHexAbiUint160.fromBigInt(value);
    }
    AbiUint160.fromBigInt = fromBigInt;
    function codegen() {
        return `Abi.Int160`;
    }
    AbiUint160.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiUint160.decodeOrThrow(cursor);
    }
    AbiUint160.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiUint160.readOrThrow(cursor);
    }
    AbiUint160.readOrThrow = readOrThrow;
})(AbiUint160 || (AbiUint160 = {}));
class BytesAbiUint160 {
    value;
    #class = _18;
    name = this.#class.name;
    static bytes = 20;
    static nibbles = 40;
    static bits = 160;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _18(value);
    }
    static from(value) {
        return _18.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiUint160(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiUint160(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int160`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _18.nibbles;
        const content = cursor.readOrThrow(_18.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _18(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - this.value.length);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _18.bytes;
        const content = cursor.readOrThrow(_18.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _18(value);
    }
}
_18 = BytesAbiUint160;
class ZeroHexAbiUint160 {
    value;
    #class = _19;
    name = this.#class.name;
    static bytes = 20;
    static nibbles = 40;
    static bits = 160;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return new _19(value.toString(16));
    }
    static fromBigInt(value) {
        return new _19(value.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _19.fromBigInt(value);
        if (typeof value === "number")
            return _19.fromNumber(value);
        if (value.startsWith("0x"))
            return new _19(value.slice(2));
        return _19.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _19.create(value);
    }
    intoOrThrow() {
        return this.value.length ? BigInt("0x" + this.value) : 0n;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int160`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _19.nibbles;
        const content = cursor.readOrThrow(_19.nibbles);
        return new _19(content);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_20 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__addDisposableResource */ .b)(env_20, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_20) {
            env_20.error = e_20;
            env_20.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__disposeResources */ .f)(env_20);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _19.bytes;
        const content = cursor.readOrThrow(_19.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _19(value);
    }
}
_19 = ZeroHexAbiUint160;
var AbiUint168;
(function (AbiUint168) {
    AbiUint168.dynamic = false;
    AbiUint168.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiUint168.create(value);
        return ZeroHexAbiUint168.create(value);
    }
    AbiUint168.create = create;
    function from(value) {
        return AbiUint168.create(value);
    }
    AbiUint168.from = from;
    function fromNumber(value) {
        return ZeroHexAbiUint168.fromNumber(value);
    }
    AbiUint168.fromNumber = fromNumber;
    function fromBigInt(value) {
        return ZeroHexAbiUint168.fromBigInt(value);
    }
    AbiUint168.fromBigInt = fromBigInt;
    function codegen() {
        return `Abi.Int168`;
    }
    AbiUint168.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiUint168.decodeOrThrow(cursor);
    }
    AbiUint168.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiUint168.readOrThrow(cursor);
    }
    AbiUint168.readOrThrow = readOrThrow;
})(AbiUint168 || (AbiUint168 = {}));
class BytesAbiUint168 {
    value;
    #class = _20;
    name = this.#class.name;
    static bytes = 21;
    static nibbles = 42;
    static bits = 168;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _20(value);
    }
    static from(value) {
        return _20.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiUint168(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiUint168(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int168`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _20.nibbles;
        const content = cursor.readOrThrow(_20.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _20(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - this.value.length);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _20.bytes;
        const content = cursor.readOrThrow(_20.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _20(value);
    }
}
_20 = BytesAbiUint168;
class ZeroHexAbiUint168 {
    value;
    #class = _21;
    name = this.#class.name;
    static bytes = 21;
    static nibbles = 42;
    static bits = 168;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return new _21(value.toString(16));
    }
    static fromBigInt(value) {
        return new _21(value.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _21.fromBigInt(value);
        if (typeof value === "number")
            return _21.fromNumber(value);
        if (value.startsWith("0x"))
            return new _21(value.slice(2));
        return _21.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _21.create(value);
    }
    intoOrThrow() {
        return this.value.length ? BigInt("0x" + this.value) : 0n;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int168`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _21.nibbles;
        const content = cursor.readOrThrow(_21.nibbles);
        return new _21(content);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_21 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__addDisposableResource */ .b)(env_21, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_21) {
            env_21.error = e_21;
            env_21.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__disposeResources */ .f)(env_21);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _21.bytes;
        const content = cursor.readOrThrow(_21.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _21(value);
    }
}
_21 = ZeroHexAbiUint168;
var AbiUint176;
(function (AbiUint176) {
    AbiUint176.dynamic = false;
    AbiUint176.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiUint176.create(value);
        return ZeroHexAbiUint176.create(value);
    }
    AbiUint176.create = create;
    function from(value) {
        return AbiUint176.create(value);
    }
    AbiUint176.from = from;
    function fromNumber(value) {
        return ZeroHexAbiUint176.fromNumber(value);
    }
    AbiUint176.fromNumber = fromNumber;
    function fromBigInt(value) {
        return ZeroHexAbiUint176.fromBigInt(value);
    }
    AbiUint176.fromBigInt = fromBigInt;
    function codegen() {
        return `Abi.Int176`;
    }
    AbiUint176.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiUint176.decodeOrThrow(cursor);
    }
    AbiUint176.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiUint176.readOrThrow(cursor);
    }
    AbiUint176.readOrThrow = readOrThrow;
})(AbiUint176 || (AbiUint176 = {}));
class BytesAbiUint176 {
    value;
    #class = _22;
    name = this.#class.name;
    static bytes = 22;
    static nibbles = 44;
    static bits = 176;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _22(value);
    }
    static from(value) {
        return _22.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiUint176(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiUint176(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int176`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _22.nibbles;
        const content = cursor.readOrThrow(_22.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _22(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - this.value.length);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _22.bytes;
        const content = cursor.readOrThrow(_22.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _22(value);
    }
}
_22 = BytesAbiUint176;
class ZeroHexAbiUint176 {
    value;
    #class = _23;
    name = this.#class.name;
    static bytes = 22;
    static nibbles = 44;
    static bits = 176;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return new _23(value.toString(16));
    }
    static fromBigInt(value) {
        return new _23(value.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _23.fromBigInt(value);
        if (typeof value === "number")
            return _23.fromNumber(value);
        if (value.startsWith("0x"))
            return new _23(value.slice(2));
        return _23.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _23.create(value);
    }
    intoOrThrow() {
        return this.value.length ? BigInt("0x" + this.value) : 0n;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int176`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _23.nibbles;
        const content = cursor.readOrThrow(_23.nibbles);
        return new _23(content);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_22 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__addDisposableResource */ .b)(env_22, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_22) {
            env_22.error = e_22;
            env_22.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__disposeResources */ .f)(env_22);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _23.bytes;
        const content = cursor.readOrThrow(_23.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _23(value);
    }
}
_23 = ZeroHexAbiUint176;
var AbiUint184;
(function (AbiUint184) {
    AbiUint184.dynamic = false;
    AbiUint184.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiUint184.create(value);
        return ZeroHexAbiUint184.create(value);
    }
    AbiUint184.create = create;
    function from(value) {
        return AbiUint184.create(value);
    }
    AbiUint184.from = from;
    function fromNumber(value) {
        return ZeroHexAbiUint184.fromNumber(value);
    }
    AbiUint184.fromNumber = fromNumber;
    function fromBigInt(value) {
        return ZeroHexAbiUint184.fromBigInt(value);
    }
    AbiUint184.fromBigInt = fromBigInt;
    function codegen() {
        return `Abi.Int184`;
    }
    AbiUint184.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiUint184.decodeOrThrow(cursor);
    }
    AbiUint184.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiUint184.readOrThrow(cursor);
    }
    AbiUint184.readOrThrow = readOrThrow;
})(AbiUint184 || (AbiUint184 = {}));
class BytesAbiUint184 {
    value;
    #class = _24;
    name = this.#class.name;
    static bytes = 23;
    static nibbles = 46;
    static bits = 184;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _24(value);
    }
    static from(value) {
        return _24.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiUint184(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiUint184(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int184`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _24.nibbles;
        const content = cursor.readOrThrow(_24.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _24(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - this.value.length);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _24.bytes;
        const content = cursor.readOrThrow(_24.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _24(value);
    }
}
_24 = BytesAbiUint184;
class ZeroHexAbiUint184 {
    value;
    #class = _25;
    name = this.#class.name;
    static bytes = 23;
    static nibbles = 46;
    static bits = 184;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return new _25(value.toString(16));
    }
    static fromBigInt(value) {
        return new _25(value.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _25.fromBigInt(value);
        if (typeof value === "number")
            return _25.fromNumber(value);
        if (value.startsWith("0x"))
            return new _25(value.slice(2));
        return _25.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _25.create(value);
    }
    intoOrThrow() {
        return this.value.length ? BigInt("0x" + this.value) : 0n;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int184`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _25.nibbles;
        const content = cursor.readOrThrow(_25.nibbles);
        return new _25(content);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_23 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__addDisposableResource */ .b)(env_23, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_23) {
            env_23.error = e_23;
            env_23.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__disposeResources */ .f)(env_23);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _25.bytes;
        const content = cursor.readOrThrow(_25.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _25(value);
    }
}
_25 = ZeroHexAbiUint184;
var AbiUint192;
(function (AbiUint192) {
    AbiUint192.dynamic = false;
    AbiUint192.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiUint192.create(value);
        return ZeroHexAbiUint192.create(value);
    }
    AbiUint192.create = create;
    function from(value) {
        return AbiUint192.create(value);
    }
    AbiUint192.from = from;
    function fromNumber(value) {
        return ZeroHexAbiUint192.fromNumber(value);
    }
    AbiUint192.fromNumber = fromNumber;
    function fromBigInt(value) {
        return ZeroHexAbiUint192.fromBigInt(value);
    }
    AbiUint192.fromBigInt = fromBigInt;
    function codegen() {
        return `Abi.Int192`;
    }
    AbiUint192.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiUint192.decodeOrThrow(cursor);
    }
    AbiUint192.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiUint192.readOrThrow(cursor);
    }
    AbiUint192.readOrThrow = readOrThrow;
})(AbiUint192 || (AbiUint192 = {}));
class BytesAbiUint192 {
    value;
    #class = _26;
    name = this.#class.name;
    static bytes = 24;
    static nibbles = 48;
    static bits = 192;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _26(value);
    }
    static from(value) {
        return _26.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiUint192(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiUint192(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int192`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _26.nibbles;
        const content = cursor.readOrThrow(_26.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _26(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - this.value.length);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _26.bytes;
        const content = cursor.readOrThrow(_26.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _26(value);
    }
}
_26 = BytesAbiUint192;
class ZeroHexAbiUint192 {
    value;
    #class = _27;
    name = this.#class.name;
    static bytes = 24;
    static nibbles = 48;
    static bits = 192;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return new _27(value.toString(16));
    }
    static fromBigInt(value) {
        return new _27(value.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _27.fromBigInt(value);
        if (typeof value === "number")
            return _27.fromNumber(value);
        if (value.startsWith("0x"))
            return new _27(value.slice(2));
        return _27.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _27.create(value);
    }
    intoOrThrow() {
        return this.value.length ? BigInt("0x" + this.value) : 0n;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int192`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _27.nibbles;
        const content = cursor.readOrThrow(_27.nibbles);
        return new _27(content);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_24 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__addDisposableResource */ .b)(env_24, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_24) {
            env_24.error = e_24;
            env_24.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__disposeResources */ .f)(env_24);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _27.bytes;
        const content = cursor.readOrThrow(_27.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _27(value);
    }
}
_27 = ZeroHexAbiUint192;
var AbiUint200;
(function (AbiUint200) {
    AbiUint200.dynamic = false;
    AbiUint200.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiUint200.create(value);
        return ZeroHexAbiUint200.create(value);
    }
    AbiUint200.create = create;
    function from(value) {
        return AbiUint200.create(value);
    }
    AbiUint200.from = from;
    function fromNumber(value) {
        return ZeroHexAbiUint200.fromNumber(value);
    }
    AbiUint200.fromNumber = fromNumber;
    function fromBigInt(value) {
        return ZeroHexAbiUint200.fromBigInt(value);
    }
    AbiUint200.fromBigInt = fromBigInt;
    function codegen() {
        return `Abi.Int200`;
    }
    AbiUint200.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiUint200.decodeOrThrow(cursor);
    }
    AbiUint200.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiUint200.readOrThrow(cursor);
    }
    AbiUint200.readOrThrow = readOrThrow;
})(AbiUint200 || (AbiUint200 = {}));
class BytesAbiUint200 {
    value;
    #class = _28;
    name = this.#class.name;
    static bytes = 25;
    static nibbles = 50;
    static bits = 200;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _28(value);
    }
    static from(value) {
        return _28.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiUint200(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiUint200(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int200`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _28.nibbles;
        const content = cursor.readOrThrow(_28.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _28(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - this.value.length);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _28.bytes;
        const content = cursor.readOrThrow(_28.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _28(value);
    }
}
_28 = BytesAbiUint200;
class ZeroHexAbiUint200 {
    value;
    #class = _29;
    name = this.#class.name;
    static bytes = 25;
    static nibbles = 50;
    static bits = 200;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return new _29(value.toString(16));
    }
    static fromBigInt(value) {
        return new _29(value.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _29.fromBigInt(value);
        if (typeof value === "number")
            return _29.fromNumber(value);
        if (value.startsWith("0x"))
            return new _29(value.slice(2));
        return _29.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _29.create(value);
    }
    intoOrThrow() {
        return this.value.length ? BigInt("0x" + this.value) : 0n;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int200`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _29.nibbles;
        const content = cursor.readOrThrow(_29.nibbles);
        return new _29(content);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_25 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__addDisposableResource */ .b)(env_25, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_25) {
            env_25.error = e_25;
            env_25.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__disposeResources */ .f)(env_25);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _29.bytes;
        const content = cursor.readOrThrow(_29.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _29(value);
    }
}
_29 = ZeroHexAbiUint200;
var AbiUint208;
(function (AbiUint208) {
    AbiUint208.dynamic = false;
    AbiUint208.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiUint208.create(value);
        return ZeroHexAbiUint208.create(value);
    }
    AbiUint208.create = create;
    function from(value) {
        return AbiUint208.create(value);
    }
    AbiUint208.from = from;
    function fromNumber(value) {
        return ZeroHexAbiUint208.fromNumber(value);
    }
    AbiUint208.fromNumber = fromNumber;
    function fromBigInt(value) {
        return ZeroHexAbiUint208.fromBigInt(value);
    }
    AbiUint208.fromBigInt = fromBigInt;
    function codegen() {
        return `Abi.Int208`;
    }
    AbiUint208.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiUint208.decodeOrThrow(cursor);
    }
    AbiUint208.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiUint208.readOrThrow(cursor);
    }
    AbiUint208.readOrThrow = readOrThrow;
})(AbiUint208 || (AbiUint208 = {}));
class BytesAbiUint208 {
    value;
    #class = _30;
    name = this.#class.name;
    static bytes = 26;
    static nibbles = 52;
    static bits = 208;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _30(value);
    }
    static from(value) {
        return _30.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiUint208(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiUint208(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int208`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _30.nibbles;
        const content = cursor.readOrThrow(_30.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _30(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - this.value.length);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _30.bytes;
        const content = cursor.readOrThrow(_30.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _30(value);
    }
}
_30 = BytesAbiUint208;
class ZeroHexAbiUint208 {
    value;
    #class = _31;
    name = this.#class.name;
    static bytes = 26;
    static nibbles = 52;
    static bits = 208;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return new _31(value.toString(16));
    }
    static fromBigInt(value) {
        return new _31(value.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _31.fromBigInt(value);
        if (typeof value === "number")
            return _31.fromNumber(value);
        if (value.startsWith("0x"))
            return new _31(value.slice(2));
        return _31.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _31.create(value);
    }
    intoOrThrow() {
        return this.value.length ? BigInt("0x" + this.value) : 0n;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int208`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _31.nibbles;
        const content = cursor.readOrThrow(_31.nibbles);
        return new _31(content);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_26 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__addDisposableResource */ .b)(env_26, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_26) {
            env_26.error = e_26;
            env_26.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__disposeResources */ .f)(env_26);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _31.bytes;
        const content = cursor.readOrThrow(_31.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _31(value);
    }
}
_31 = ZeroHexAbiUint208;
var AbiUint216;
(function (AbiUint216) {
    AbiUint216.dynamic = false;
    AbiUint216.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiUint216.create(value);
        return ZeroHexAbiUint216.create(value);
    }
    AbiUint216.create = create;
    function from(value) {
        return AbiUint216.create(value);
    }
    AbiUint216.from = from;
    function fromNumber(value) {
        return ZeroHexAbiUint216.fromNumber(value);
    }
    AbiUint216.fromNumber = fromNumber;
    function fromBigInt(value) {
        return ZeroHexAbiUint216.fromBigInt(value);
    }
    AbiUint216.fromBigInt = fromBigInt;
    function codegen() {
        return `Abi.Int216`;
    }
    AbiUint216.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiUint216.decodeOrThrow(cursor);
    }
    AbiUint216.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiUint216.readOrThrow(cursor);
    }
    AbiUint216.readOrThrow = readOrThrow;
})(AbiUint216 || (AbiUint216 = {}));
class BytesAbiUint216 {
    value;
    #class = _32;
    name = this.#class.name;
    static bytes = 27;
    static nibbles = 54;
    static bits = 216;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _32(value);
    }
    static from(value) {
        return _32.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiUint216(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiUint216(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int216`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _32.nibbles;
        const content = cursor.readOrThrow(_32.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _32(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - this.value.length);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _32.bytes;
        const content = cursor.readOrThrow(_32.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _32(value);
    }
}
_32 = BytesAbiUint216;
class ZeroHexAbiUint216 {
    value;
    #class = _33;
    name = this.#class.name;
    static bytes = 27;
    static nibbles = 54;
    static bits = 216;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return new _33(value.toString(16));
    }
    static fromBigInt(value) {
        return new _33(value.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _33.fromBigInt(value);
        if (typeof value === "number")
            return _33.fromNumber(value);
        if (value.startsWith("0x"))
            return new _33(value.slice(2));
        return _33.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _33.create(value);
    }
    intoOrThrow() {
        return this.value.length ? BigInt("0x" + this.value) : 0n;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int216`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _33.nibbles;
        const content = cursor.readOrThrow(_33.nibbles);
        return new _33(content);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_27 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__addDisposableResource */ .b)(env_27, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_27) {
            env_27.error = e_27;
            env_27.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__disposeResources */ .f)(env_27);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _33.bytes;
        const content = cursor.readOrThrow(_33.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _33(value);
    }
}
_33 = ZeroHexAbiUint216;
var AbiUint224;
(function (AbiUint224) {
    AbiUint224.dynamic = false;
    AbiUint224.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiUint224.create(value);
        return ZeroHexAbiUint224.create(value);
    }
    AbiUint224.create = create;
    function from(value) {
        return AbiUint224.create(value);
    }
    AbiUint224.from = from;
    function fromNumber(value) {
        return ZeroHexAbiUint224.fromNumber(value);
    }
    AbiUint224.fromNumber = fromNumber;
    function fromBigInt(value) {
        return ZeroHexAbiUint224.fromBigInt(value);
    }
    AbiUint224.fromBigInt = fromBigInt;
    function codegen() {
        return `Abi.Int224`;
    }
    AbiUint224.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiUint224.decodeOrThrow(cursor);
    }
    AbiUint224.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiUint224.readOrThrow(cursor);
    }
    AbiUint224.readOrThrow = readOrThrow;
})(AbiUint224 || (AbiUint224 = {}));
class BytesAbiUint224 {
    value;
    #class = _34;
    name = this.#class.name;
    static bytes = 28;
    static nibbles = 56;
    static bits = 224;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _34(value);
    }
    static from(value) {
        return _34.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiUint224(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiUint224(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int224`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _34.nibbles;
        const content = cursor.readOrThrow(_34.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _34(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - this.value.length);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _34.bytes;
        const content = cursor.readOrThrow(_34.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _34(value);
    }
}
_34 = BytesAbiUint224;
class ZeroHexAbiUint224 {
    value;
    #class = _35;
    name = this.#class.name;
    static bytes = 28;
    static nibbles = 56;
    static bits = 224;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return new _35(value.toString(16));
    }
    static fromBigInt(value) {
        return new _35(value.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _35.fromBigInt(value);
        if (typeof value === "number")
            return _35.fromNumber(value);
        if (value.startsWith("0x"))
            return new _35(value.slice(2));
        return _35.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _35.create(value);
    }
    intoOrThrow() {
        return this.value.length ? BigInt("0x" + this.value) : 0n;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int224`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _35.nibbles;
        const content = cursor.readOrThrow(_35.nibbles);
        return new _35(content);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_28 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__addDisposableResource */ .b)(env_28, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_28) {
            env_28.error = e_28;
            env_28.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__disposeResources */ .f)(env_28);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _35.bytes;
        const content = cursor.readOrThrow(_35.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _35(value);
    }
}
_35 = ZeroHexAbiUint224;
var AbiUint232;
(function (AbiUint232) {
    AbiUint232.dynamic = false;
    AbiUint232.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiUint232.create(value);
        return ZeroHexAbiUint232.create(value);
    }
    AbiUint232.create = create;
    function from(value) {
        return AbiUint232.create(value);
    }
    AbiUint232.from = from;
    function fromNumber(value) {
        return ZeroHexAbiUint232.fromNumber(value);
    }
    AbiUint232.fromNumber = fromNumber;
    function fromBigInt(value) {
        return ZeroHexAbiUint232.fromBigInt(value);
    }
    AbiUint232.fromBigInt = fromBigInt;
    function codegen() {
        return `Abi.Int232`;
    }
    AbiUint232.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiUint232.decodeOrThrow(cursor);
    }
    AbiUint232.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiUint232.readOrThrow(cursor);
    }
    AbiUint232.readOrThrow = readOrThrow;
})(AbiUint232 || (AbiUint232 = {}));
class BytesAbiUint232 {
    value;
    #class = _36;
    name = this.#class.name;
    static bytes = 29;
    static nibbles = 58;
    static bits = 232;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _36(value);
    }
    static from(value) {
        return _36.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiUint232(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiUint232(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int232`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _36.nibbles;
        const content = cursor.readOrThrow(_36.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _36(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - this.value.length);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _36.bytes;
        const content = cursor.readOrThrow(_36.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _36(value);
    }
}
_36 = BytesAbiUint232;
class ZeroHexAbiUint232 {
    value;
    #class = _37;
    name = this.#class.name;
    static bytes = 29;
    static nibbles = 58;
    static bits = 232;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return new _37(value.toString(16));
    }
    static fromBigInt(value) {
        return new _37(value.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _37.fromBigInt(value);
        if (typeof value === "number")
            return _37.fromNumber(value);
        if (value.startsWith("0x"))
            return new _37(value.slice(2));
        return _37.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _37.create(value);
    }
    intoOrThrow() {
        return this.value.length ? BigInt("0x" + this.value) : 0n;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int232`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _37.nibbles;
        const content = cursor.readOrThrow(_37.nibbles);
        return new _37(content);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_29 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__addDisposableResource */ .b)(env_29, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_29) {
            env_29.error = e_29;
            env_29.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__disposeResources */ .f)(env_29);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _37.bytes;
        const content = cursor.readOrThrow(_37.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _37(value);
    }
}
_37 = ZeroHexAbiUint232;
var AbiUint240;
(function (AbiUint240) {
    AbiUint240.dynamic = false;
    AbiUint240.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiUint240.create(value);
        return ZeroHexAbiUint240.create(value);
    }
    AbiUint240.create = create;
    function from(value) {
        return AbiUint240.create(value);
    }
    AbiUint240.from = from;
    function fromNumber(value) {
        return ZeroHexAbiUint240.fromNumber(value);
    }
    AbiUint240.fromNumber = fromNumber;
    function fromBigInt(value) {
        return ZeroHexAbiUint240.fromBigInt(value);
    }
    AbiUint240.fromBigInt = fromBigInt;
    function codegen() {
        return `Abi.Int240`;
    }
    AbiUint240.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiUint240.decodeOrThrow(cursor);
    }
    AbiUint240.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiUint240.readOrThrow(cursor);
    }
    AbiUint240.readOrThrow = readOrThrow;
})(AbiUint240 || (AbiUint240 = {}));
class BytesAbiUint240 {
    value;
    #class = _38;
    name = this.#class.name;
    static bytes = 30;
    static nibbles = 60;
    static bits = 240;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _38(value);
    }
    static from(value) {
        return _38.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiUint240(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiUint240(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int240`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _38.nibbles;
        const content = cursor.readOrThrow(_38.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _38(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - this.value.length);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _38.bytes;
        const content = cursor.readOrThrow(_38.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _38(value);
    }
}
_38 = BytesAbiUint240;
class ZeroHexAbiUint240 {
    value;
    #class = _39;
    name = this.#class.name;
    static bytes = 30;
    static nibbles = 60;
    static bits = 240;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return new _39(value.toString(16));
    }
    static fromBigInt(value) {
        return new _39(value.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _39.fromBigInt(value);
        if (typeof value === "number")
            return _39.fromNumber(value);
        if (value.startsWith("0x"))
            return new _39(value.slice(2));
        return _39.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _39.create(value);
    }
    intoOrThrow() {
        return this.value.length ? BigInt("0x" + this.value) : 0n;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int240`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _39.nibbles;
        const content = cursor.readOrThrow(_39.nibbles);
        return new _39(content);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_30 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__addDisposableResource */ .b)(env_30, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_30) {
            env_30.error = e_30;
            env_30.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__disposeResources */ .f)(env_30);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _39.bytes;
        const content = cursor.readOrThrow(_39.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _39(value);
    }
}
_39 = ZeroHexAbiUint240;
var AbiUint248;
(function (AbiUint248) {
    AbiUint248.dynamic = false;
    AbiUint248.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiUint248.create(value);
        return ZeroHexAbiUint248.create(value);
    }
    AbiUint248.create = create;
    function from(value) {
        return AbiUint248.create(value);
    }
    AbiUint248.from = from;
    function fromNumber(value) {
        return ZeroHexAbiUint248.fromNumber(value);
    }
    AbiUint248.fromNumber = fromNumber;
    function fromBigInt(value) {
        return ZeroHexAbiUint248.fromBigInt(value);
    }
    AbiUint248.fromBigInt = fromBigInt;
    function codegen() {
        return `Abi.Int248`;
    }
    AbiUint248.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiUint248.decodeOrThrow(cursor);
    }
    AbiUint248.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiUint248.readOrThrow(cursor);
    }
    AbiUint248.readOrThrow = readOrThrow;
})(AbiUint248 || (AbiUint248 = {}));
class BytesAbiUint248 {
    value;
    #class = _40;
    name = this.#class.name;
    static bytes = 31;
    static nibbles = 62;
    static bits = 248;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _40(value);
    }
    static from(value) {
        return _40.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiUint248(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiUint248(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int248`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _40.nibbles;
        const content = cursor.readOrThrow(_40.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _40(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - this.value.length);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _40.bytes;
        const content = cursor.readOrThrow(_40.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _40(value);
    }
}
_40 = BytesAbiUint248;
class ZeroHexAbiUint248 {
    value;
    #class = _41;
    name = this.#class.name;
    static bytes = 31;
    static nibbles = 62;
    static bits = 248;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return new _41(value.toString(16));
    }
    static fromBigInt(value) {
        return new _41(value.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _41.fromBigInt(value);
        if (typeof value === "number")
            return _41.fromNumber(value);
        if (value.startsWith("0x"))
            return new _41(value.slice(2));
        return _41.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _41.create(value);
    }
    intoOrThrow() {
        return this.value.length ? BigInt("0x" + this.value) : 0n;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int248`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _41.nibbles;
        const content = cursor.readOrThrow(_41.nibbles);
        return new _41(content);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_31 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__addDisposableResource */ .b)(env_31, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_31) {
            env_31.error = e_31;
            env_31.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__disposeResources */ .f)(env_31);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _41.bytes;
        const content = cursor.readOrThrow(_41.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _41(value);
    }
}
_41 = ZeroHexAbiUint248;
var AbiUint256;
(function (AbiUint256) {
    AbiUint256.dynamic = false;
    AbiUint256.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiUint256.create(value);
        return ZeroHexAbiUint256.create(value);
    }
    AbiUint256.create = create;
    function from(value) {
        return AbiUint256.create(value);
    }
    AbiUint256.from = from;
    function fromNumber(value) {
        return ZeroHexAbiUint256.fromNumber(value);
    }
    AbiUint256.fromNumber = fromNumber;
    function fromBigInt(value) {
        return ZeroHexAbiUint256.fromBigInt(value);
    }
    AbiUint256.fromBigInt = fromBigInt;
    function codegen() {
        return `Abi.Int256`;
    }
    AbiUint256.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiUint256.decodeOrThrow(cursor);
    }
    AbiUint256.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiUint256.readOrThrow(cursor);
    }
    AbiUint256.readOrThrow = readOrThrow;
})(AbiUint256 || (AbiUint256 = {}));
class BytesAbiUint256 {
    value;
    #class = _42;
    name = this.#class.name;
    static bytes = 32;
    static nibbles = 64;
    static bits = 256;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _42(value);
    }
    static from(value) {
        return _42.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiUint256(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiUint256(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int256`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _42.nibbles;
        const content = cursor.readOrThrow(_42.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _42(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - this.value.length);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _42.bytes;
        const content = cursor.readOrThrow(_42.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _42(value);
    }
}
_42 = BytesAbiUint256;
class ZeroHexAbiUint256 {
    value;
    #class = _43;
    name = this.#class.name;
    static bytes = 32;
    static nibbles = 64;
    static bits = 256;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return new _43(value.toString(16));
    }
    static fromBigInt(value) {
        return new _43(value.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _43.fromBigInt(value);
        if (typeof value === "number")
            return _43.fromNumber(value);
        if (value.startsWith("0x"))
            return new _43(value.slice(2));
        return _43.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _43.create(value);
    }
    intoOrThrow() {
        return this.value.length ? BigInt("0x" + this.value) : 0n;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int256`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _43.nibbles;
        const content = cursor.readOrThrow(_43.nibbles);
        return new _43(content);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_32 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__addDisposableResource */ .b)(env_32, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_32) {
            env_32.error = e_32;
            env_32.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_2__/* .__disposeResources */ .f)(env_32);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _43.bytes;
        const content = cursor.readOrThrow(_43.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _43(value);
    }
}
_43 = ZeroHexAbiUint256;
const uintByName = {
    uint8: AbiUint8,
    uint16: AbiUint16,
    uint24: AbiUint24,
    uint32: AbiUint32,
    uint40: AbiUint40,
    uint48: AbiUint48,
    uint56: AbiUint56,
    uint64: AbiUint64,
    uint72: AbiUint72,
    uint80: AbiUint80,
    uint88: AbiUint88,
    uint96: AbiUint96,
    uint104: AbiUint104,
    uint112: AbiUint112,
    uint120: AbiUint120,
    uint128: AbiUint128,
    uint136: AbiUint136,
    uint144: AbiUint144,
    uint152: AbiUint152,
    uint160: AbiUint160,
    uint168: AbiUint168,
    uint176: AbiUint176,
    uint184: AbiUint184,
    uint192: AbiUint192,
    uint200: AbiUint200,
    uint208: AbiUint208,
    uint216: AbiUint216,
    uint224: AbiUint224,
    uint232: AbiUint232,
    uint240: AbiUint240,
    uint248: AbiUint248,
    uint256: AbiUint256,
};


//# sourceMappingURL=uint.mjs.map


/***/ })

}]);