/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ 742:
/***/ ((__unused_webpack_module, exports) => {

"use strict";


exports.byteLength = byteLength
exports.toByteArray = toByteArray
exports.fromByteArray = fromByteArray

var lookup = []
var revLookup = []
var Arr = typeof Uint8Array !== 'undefined' ? Uint8Array : Array

var code = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
for (var i = 0, len = code.length; i < len; ++i) {
  lookup[i] = code[i]
  revLookup[code.charCodeAt(i)] = i
}

// Support decoding URL-safe base64 strings, as Node.js does.
// See: https://en.wikipedia.org/wiki/Base64#URL_applications
revLookup['-'.charCodeAt(0)] = 62
revLookup['_'.charCodeAt(0)] = 63

function getLens (b64) {
  var len = b64.length

  if (len % 4 > 0) {
    throw new Error('Invalid string. Length must be a multiple of 4')
  }

  // Trim off extra bytes after placeholder bytes are found
  // See: https://github.com/beatgammit/base64-js/issues/42
  var validLen = b64.indexOf('=')
  if (validLen === -1) validLen = len

  var placeHoldersLen = validLen === len
    ? 0
    : 4 - (validLen % 4)

  return [validLen, placeHoldersLen]
}

// base64 is 4/3 + up to two characters of the original data
function byteLength (b64) {
  var lens = getLens(b64)
  var validLen = lens[0]
  var placeHoldersLen = lens[1]
  return ((validLen + placeHoldersLen) * 3 / 4) - placeHoldersLen
}

function _byteLength (b64, validLen, placeHoldersLen) {
  return ((validLen + placeHoldersLen) * 3 / 4) - placeHoldersLen
}

function toByteArray (b64) {
  var tmp
  var lens = getLens(b64)
  var validLen = lens[0]
  var placeHoldersLen = lens[1]

  var arr = new Arr(_byteLength(b64, validLen, placeHoldersLen))

  var curByte = 0

  // if there are placeholders, only get up to the last complete 4 chars
  var len = placeHoldersLen > 0
    ? validLen - 4
    : validLen

  var i
  for (i = 0; i < len; i += 4) {
    tmp =
      (revLookup[b64.charCodeAt(i)] << 18) |
      (revLookup[b64.charCodeAt(i + 1)] << 12) |
      (revLookup[b64.charCodeAt(i + 2)] << 6) |
      revLookup[b64.charCodeAt(i + 3)]
    arr[curByte++] = (tmp >> 16) & 0xFF
    arr[curByte++] = (tmp >> 8) & 0xFF
    arr[curByte++] = tmp & 0xFF
  }

  if (placeHoldersLen === 2) {
    tmp =
      (revLookup[b64.charCodeAt(i)] << 2) |
      (revLookup[b64.charCodeAt(i + 1)] >> 4)
    arr[curByte++] = tmp & 0xFF
  }

  if (placeHoldersLen === 1) {
    tmp =
      (revLookup[b64.charCodeAt(i)] << 10) |
      (revLookup[b64.charCodeAt(i + 1)] << 4) |
      (revLookup[b64.charCodeAt(i + 2)] >> 2)
    arr[curByte++] = (tmp >> 8) & 0xFF
    arr[curByte++] = tmp & 0xFF
  }

  return arr
}

function tripletToBase64 (num) {
  return lookup[num >> 18 & 0x3F] +
    lookup[num >> 12 & 0x3F] +
    lookup[num >> 6 & 0x3F] +
    lookup[num & 0x3F]
}

function encodeChunk (uint8, start, end) {
  var tmp
  var output = []
  for (var i = start; i < end; i += 3) {
    tmp =
      ((uint8[i] << 16) & 0xFF0000) +
      ((uint8[i + 1] << 8) & 0xFF00) +
      (uint8[i + 2] & 0xFF)
    output.push(tripletToBase64(tmp))
  }
  return output.join('')
}

function fromByteArray (uint8) {
  var tmp
  var len = uint8.length
  var extraBytes = len % 3 // if we have 1 byte left, pad 2 bytes
  var parts = []
  var maxChunkLength = 16383 // must be multiple of 3

  // go through the array every three bytes, we'll deal with trailing stuff later
  for (var i = 0, len2 = len - extraBytes; i < len2; i += maxChunkLength) {
    parts.push(encodeChunk(uint8, i, (i + maxChunkLength) > len2 ? len2 : (i + maxChunkLength)))
  }

  // pad the end with zeros, but make sure to not forget the extra bytes
  if (extraBytes === 1) {
    tmp = uint8[len - 1]
    parts.push(
      lookup[tmp >> 2] +
      lookup[(tmp << 4) & 0x3F] +
      '=='
    )
  } else if (extraBytes === 2) {
    tmp = (uint8[len - 2] << 8) + uint8[len - 1]
    parts.push(
      lookup[tmp >> 10] +
      lookup[(tmp >> 4) & 0x3F] +
      lookup[(tmp << 2) & 0x3F] +
      '='
    )
  }

  return parts.join('')
}


/***/ }),

/***/ 764:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
var __webpack_unused_export__;
/*!
 * The buffer module from node.js, for the browser.
 *
 * @author   Feross Aboukhadijeh <https://feross.org>
 * @license  MIT
 */
/* eslint-disable no-proto */



const base64 = __webpack_require__(742)
const ieee754 = __webpack_require__(645)
const customInspectSymbol =
  (typeof Symbol === 'function' && typeof Symbol['for'] === 'function') // eslint-disable-line dot-notation
    ? Symbol['for']('nodejs.util.inspect.custom') // eslint-disable-line dot-notation
    : null

exports.lW = Buffer
__webpack_unused_export__ = SlowBuffer
exports.h2 = 50

const K_MAX_LENGTH = 0x7fffffff
__webpack_unused_export__ = K_MAX_LENGTH

/**
 * If `Buffer.TYPED_ARRAY_SUPPORT`:
 *   === true    Use Uint8Array implementation (fastest)
 *   === false   Print warning and recommend using `buffer` v4.x which has an Object
 *               implementation (most compatible, even IE6)
 *
 * Browsers that support typed arrays are IE 10+, Firefox 4+, Chrome 7+, Safari 5.1+,
 * Opera 11.6+, iOS 4.2+.
 *
 * We report that the browser does not support typed arrays if the are not subclassable
 * using __proto__. Firefox 4-29 lacks support for adding new properties to `Uint8Array`
 * (See: https://bugzilla.mozilla.org/show_bug.cgi?id=695438). IE 10 lacks support
 * for __proto__ and has a buggy typed array implementation.
 */
Buffer.TYPED_ARRAY_SUPPORT = typedArraySupport()

if (!Buffer.TYPED_ARRAY_SUPPORT && typeof console !== 'undefined' &&
    typeof console.error === 'function') {
  console.error(
    'This browser lacks typed array (Uint8Array) support which is required by ' +
    '`buffer` v5.x. Use `buffer` v4.x if you require old browser support.'
  )
}

function typedArraySupport () {
  // Can typed array instances can be augmented?
  try {
    const arr = new Uint8Array(1)
    const proto = { foo: function () { return 42 } }
    Object.setPrototypeOf(proto, Uint8Array.prototype)
    Object.setPrototypeOf(arr, proto)
    return arr.foo() === 42
  } catch (e) {
    return false
  }
}

Object.defineProperty(Buffer.prototype, 'parent', {
  enumerable: true,
  get: function () {
    if (!Buffer.isBuffer(this)) return undefined
    return this.buffer
  }
})

Object.defineProperty(Buffer.prototype, 'offset', {
  enumerable: true,
  get: function () {
    if (!Buffer.isBuffer(this)) return undefined
    return this.byteOffset
  }
})

function createBuffer (length) {
  if (length > K_MAX_LENGTH) {
    throw new RangeError('The value "' + length + '" is invalid for option "size"')
  }
  // Return an augmented `Uint8Array` instance
  const buf = new Uint8Array(length)
  Object.setPrototypeOf(buf, Buffer.prototype)
  return buf
}

/**
 * The Buffer constructor returns instances of `Uint8Array` that have their
 * prototype changed to `Buffer.prototype`. Furthermore, `Buffer` is a subclass of
 * `Uint8Array`, so the returned instances will have all the node `Buffer` methods
 * and the `Uint8Array` methods. Square bracket notation works as expected -- it
 * returns a single octet.
 *
 * The `Uint8Array` prototype remains unmodified.
 */

function Buffer (arg, encodingOrOffset, length) {
  // Common case.
  if (typeof arg === 'number') {
    if (typeof encodingOrOffset === 'string') {
      throw new TypeError(
        'The "string" argument must be of type string. Received type number'
      )
    }
    return allocUnsafe(arg)
  }
  return from(arg, encodingOrOffset, length)
}

Buffer.poolSize = 8192 // not used by this implementation

function from (value, encodingOrOffset, length) {
  if (typeof value === 'string') {
    return fromString(value, encodingOrOffset)
  }

  if (ArrayBuffer.isView(value)) {
    return fromArrayView(value)
  }

  if (value == null) {
    throw new TypeError(
      'The first argument must be one of type string, Buffer, ArrayBuffer, Array, ' +
      'or Array-like Object. Received type ' + (typeof value)
    )
  }

  if (isInstance(value, ArrayBuffer) ||
      (value && isInstance(value.buffer, ArrayBuffer))) {
    return fromArrayBuffer(value, encodingOrOffset, length)
  }

  if (typeof SharedArrayBuffer !== 'undefined' &&
      (isInstance(value, SharedArrayBuffer) ||
      (value && isInstance(value.buffer, SharedArrayBuffer)))) {
    return fromArrayBuffer(value, encodingOrOffset, length)
  }

  if (typeof value === 'number') {
    throw new TypeError(
      'The "value" argument must not be of type number. Received type number'
    )
  }

  const valueOf = value.valueOf && value.valueOf()
  if (valueOf != null && valueOf !== value) {
    return Buffer.from(valueOf, encodingOrOffset, length)
  }

  const b = fromObject(value)
  if (b) return b

  if (typeof Symbol !== 'undefined' && Symbol.toPrimitive != null &&
      typeof value[Symbol.toPrimitive] === 'function') {
    return Buffer.from(value[Symbol.toPrimitive]('string'), encodingOrOffset, length)
  }

  throw new TypeError(
    'The first argument must be one of type string, Buffer, ArrayBuffer, Array, ' +
    'or Array-like Object. Received type ' + (typeof value)
  )
}

/**
 * Functionally equivalent to Buffer(arg, encoding) but throws a TypeError
 * if value is a number.
 * Buffer.from(str[, encoding])
 * Buffer.from(array)
 * Buffer.from(buffer)
 * Buffer.from(arrayBuffer[, byteOffset[, length]])
 **/
Buffer.from = function (value, encodingOrOffset, length) {
  return from(value, encodingOrOffset, length)
}

// Note: Change prototype *after* Buffer.from is defined to workaround Chrome bug:
// https://github.com/feross/buffer/pull/148
Object.setPrototypeOf(Buffer.prototype, Uint8Array.prototype)
Object.setPrototypeOf(Buffer, Uint8Array)

function assertSize (size) {
  if (typeof size !== 'number') {
    throw new TypeError('"size" argument must be of type number')
  } else if (size < 0) {
    throw new RangeError('The value "' + size + '" is invalid for option "size"')
  }
}

function alloc (size, fill, encoding) {
  assertSize(size)
  if (size <= 0) {
    return createBuffer(size)
  }
  if (fill !== undefined) {
    // Only pay attention to encoding if it's a string. This
    // prevents accidentally sending in a number that would
    // be interpreted as a start offset.
    return typeof encoding === 'string'
      ? createBuffer(size).fill(fill, encoding)
      : createBuffer(size).fill(fill)
  }
  return createBuffer(size)
}

/**
 * Creates a new filled Buffer instance.
 * alloc(size[, fill[, encoding]])
 **/
Buffer.alloc = function (size, fill, encoding) {
  return alloc(size, fill, encoding)
}

function allocUnsafe (size) {
  assertSize(size)
  return createBuffer(size < 0 ? 0 : checked(size) | 0)
}

/**
 * Equivalent to Buffer(num), by default creates a non-zero-filled Buffer instance.
 * */
Buffer.allocUnsafe = function (size) {
  return allocUnsafe(size)
}
/**
 * Equivalent to SlowBuffer(num), by default creates a non-zero-filled Buffer instance.
 */
Buffer.allocUnsafeSlow = function (size) {
  return allocUnsafe(size)
}

function fromString (string, encoding) {
  if (typeof encoding !== 'string' || encoding === '') {
    encoding = 'utf8'
  }

  if (!Buffer.isEncoding(encoding)) {
    throw new TypeError('Unknown encoding: ' + encoding)
  }

  const length = byteLength(string, encoding) | 0
  let buf = createBuffer(length)

  const actual = buf.write(string, encoding)

  if (actual !== length) {
    // Writing a hex string, for example, that contains invalid characters will
    // cause everything after the first invalid character to be ignored. (e.g.
    // 'abxxcd' will be treated as 'ab')
    buf = buf.slice(0, actual)
  }

  return buf
}

function fromArrayLike (array) {
  const length = array.length < 0 ? 0 : checked(array.length) | 0
  const buf = createBuffer(length)
  for (let i = 0; i < length; i += 1) {
    buf[i] = array[i] & 255
  }
  return buf
}

function fromArrayView (arrayView) {
  if (isInstance(arrayView, Uint8Array)) {
    const copy = new Uint8Array(arrayView)
    return fromArrayBuffer(copy.buffer, copy.byteOffset, copy.byteLength)
  }
  return fromArrayLike(arrayView)
}

function fromArrayBuffer (array, byteOffset, length) {
  if (byteOffset < 0 || array.byteLength < byteOffset) {
    throw new RangeError('"offset" is outside of buffer bounds')
  }

  if (array.byteLength < byteOffset + (length || 0)) {
    throw new RangeError('"length" is outside of buffer bounds')
  }

  let buf
  if (byteOffset === undefined && length === undefined) {
    buf = new Uint8Array(array)
  } else if (length === undefined) {
    buf = new Uint8Array(array, byteOffset)
  } else {
    buf = new Uint8Array(array, byteOffset, length)
  }

  // Return an augmented `Uint8Array` instance
  Object.setPrototypeOf(buf, Buffer.prototype)

  return buf
}

function fromObject (obj) {
  if (Buffer.isBuffer(obj)) {
    const len = checked(obj.length) | 0
    const buf = createBuffer(len)

    if (buf.length === 0) {
      return buf
    }

    obj.copy(buf, 0, 0, len)
    return buf
  }

  if (obj.length !== undefined) {
    if (typeof obj.length !== 'number' || numberIsNaN(obj.length)) {
      return createBuffer(0)
    }
    return fromArrayLike(obj)
  }

  if (obj.type === 'Buffer' && Array.isArray(obj.data)) {
    return fromArrayLike(obj.data)
  }
}

function checked (length) {
  // Note: cannot use `length < K_MAX_LENGTH` here because that fails when
  // length is NaN (which is otherwise coerced to zero.)
  if (length >= K_MAX_LENGTH) {
    throw new RangeError('Attempt to allocate Buffer larger than maximum ' +
                         'size: 0x' + K_MAX_LENGTH.toString(16) + ' bytes')
  }
  return length | 0
}

function SlowBuffer (length) {
  if (+length != length) { // eslint-disable-line eqeqeq
    length = 0
  }
  return Buffer.alloc(+length)
}

Buffer.isBuffer = function isBuffer (b) {
  return b != null && b._isBuffer === true &&
    b !== Buffer.prototype // so Buffer.isBuffer(Buffer.prototype) will be false
}

Buffer.compare = function compare (a, b) {
  if (isInstance(a, Uint8Array)) a = Buffer.from(a, a.offset, a.byteLength)
  if (isInstance(b, Uint8Array)) b = Buffer.from(b, b.offset, b.byteLength)
  if (!Buffer.isBuffer(a) || !Buffer.isBuffer(b)) {
    throw new TypeError(
      'The "buf1", "buf2" arguments must be one of type Buffer or Uint8Array'
    )
  }

  if (a === b) return 0

  let x = a.length
  let y = b.length

  for (let i = 0, len = Math.min(x, y); i < len; ++i) {
    if (a[i] !== b[i]) {
      x = a[i]
      y = b[i]
      break
    }
  }

  if (x < y) return -1
  if (y < x) return 1
  return 0
}

Buffer.isEncoding = function isEncoding (encoding) {
  switch (String(encoding).toLowerCase()) {
    case 'hex':
    case 'utf8':
    case 'utf-8':
    case 'ascii':
    case 'latin1':
    case 'binary':
    case 'base64':
    case 'ucs2':
    case 'ucs-2':
    case 'utf16le':
    case 'utf-16le':
      return true
    default:
      return false
  }
}

Buffer.concat = function concat (list, length) {
  if (!Array.isArray(list)) {
    throw new TypeError('"list" argument must be an Array of Buffers')
  }

  if (list.length === 0) {
    return Buffer.alloc(0)
  }

  let i
  if (length === undefined) {
    length = 0
    for (i = 0; i < list.length; ++i) {
      length += list[i].length
    }
  }

  const buffer = Buffer.allocUnsafe(length)
  let pos = 0
  for (i = 0; i < list.length; ++i) {
    let buf = list[i]
    if (isInstance(buf, Uint8Array)) {
      if (pos + buf.length > buffer.length) {
        if (!Buffer.isBuffer(buf)) buf = Buffer.from(buf)
        buf.copy(buffer, pos)
      } else {
        Uint8Array.prototype.set.call(
          buffer,
          buf,
          pos
        )
      }
    } else if (!Buffer.isBuffer(buf)) {
      throw new TypeError('"list" argument must be an Array of Buffers')
    } else {
      buf.copy(buffer, pos)
    }
    pos += buf.length
  }
  return buffer
}

function byteLength (string, encoding) {
  if (Buffer.isBuffer(string)) {
    return string.length
  }
  if (ArrayBuffer.isView(string) || isInstance(string, ArrayBuffer)) {
    return string.byteLength
  }
  if (typeof string !== 'string') {
    throw new TypeError(
      'The "string" argument must be one of type string, Buffer, or ArrayBuffer. ' +
      'Received type ' + typeof string
    )
  }

  const len = string.length
  const mustMatch = (arguments.length > 2 && arguments[2] === true)
  if (!mustMatch && len === 0) return 0

  // Use a for loop to avoid recursion
  let loweredCase = false
  for (;;) {
    switch (encoding) {
      case 'ascii':
      case 'latin1':
      case 'binary':
        return len
      case 'utf8':
      case 'utf-8':
        return utf8ToBytes(string).length
      case 'ucs2':
      case 'ucs-2':
      case 'utf16le':
      case 'utf-16le':
        return len * 2
      case 'hex':
        return len >>> 1
      case 'base64':
        return base64ToBytes(string).length
      default:
        if (loweredCase) {
          return mustMatch ? -1 : utf8ToBytes(string).length // assume utf8
        }
        encoding = ('' + encoding).toLowerCase()
        loweredCase = true
    }
  }
}
Buffer.byteLength = byteLength

function slowToString (encoding, start, end) {
  let loweredCase = false

  // No need to verify that "this.length <= MAX_UINT32" since it's a read-only
  // property of a typed array.

  // This behaves neither like String nor Uint8Array in that we set start/end
  // to their upper/lower bounds if the value passed is out of range.
  // undefined is handled specially as per ECMA-262 6th Edition,
  // Section 13.3.3.7 Runtime Semantics: KeyedBindingInitialization.
  if (start === undefined || start < 0) {
    start = 0
  }
  // Return early if start > this.length. Done here to prevent potential uint32
  // coercion fail below.
  if (start > this.length) {
    return ''
  }

  if (end === undefined || end > this.length) {
    end = this.length
  }

  if (end <= 0) {
    return ''
  }

  // Force coercion to uint32. This will also coerce falsey/NaN values to 0.
  end >>>= 0
  start >>>= 0

  if (end <= start) {
    return ''
  }

  if (!encoding) encoding = 'utf8'

  while (true) {
    switch (encoding) {
      case 'hex':
        return hexSlice(this, start, end)

      case 'utf8':
      case 'utf-8':
        return utf8Slice(this, start, end)

      case 'ascii':
        return asciiSlice(this, start, end)

      case 'latin1':
      case 'binary':
        return latin1Slice(this, start, end)

      case 'base64':
        return base64Slice(this, start, end)

      case 'ucs2':
      case 'ucs-2':
      case 'utf16le':
      case 'utf-16le':
        return utf16leSlice(this, start, end)

      default:
        if (loweredCase) throw new TypeError('Unknown encoding: ' + encoding)
        encoding = (encoding + '').toLowerCase()
        loweredCase = true
    }
  }
}

// This property is used by `Buffer.isBuffer` (and the `is-buffer` npm package)
// to detect a Buffer instance. It's not possible to use `instanceof Buffer`
// reliably in a browserify context because there could be multiple different
// copies of the 'buffer' package in use. This method works even for Buffer
// instances that were created from another copy of the `buffer` package.
// See: https://github.com/feross/buffer/issues/154
Buffer.prototype._isBuffer = true

function swap (b, n, m) {
  const i = b[n]
  b[n] = b[m]
  b[m] = i
}

Buffer.prototype.swap16 = function swap16 () {
  const len = this.length
  if (len % 2 !== 0) {
    throw new RangeError('Buffer size must be a multiple of 16-bits')
  }
  for (let i = 0; i < len; i += 2) {
    swap(this, i, i + 1)
  }
  return this
}

Buffer.prototype.swap32 = function swap32 () {
  const len = this.length
  if (len % 4 !== 0) {
    throw new RangeError('Buffer size must be a multiple of 32-bits')
  }
  for (let i = 0; i < len; i += 4) {
    swap(this, i, i + 3)
    swap(this, i + 1, i + 2)
  }
  return this
}

Buffer.prototype.swap64 = function swap64 () {
  const len = this.length
  if (len % 8 !== 0) {
    throw new RangeError('Buffer size must be a multiple of 64-bits')
  }
  for (let i = 0; i < len; i += 8) {
    swap(this, i, i + 7)
    swap(this, i + 1, i + 6)
    swap(this, i + 2, i + 5)
    swap(this, i + 3, i + 4)
  }
  return this
}

Buffer.prototype.toString = function toString () {
  const length = this.length
  if (length === 0) return ''
  if (arguments.length === 0) return utf8Slice(this, 0, length)
  return slowToString.apply(this, arguments)
}

Buffer.prototype.toLocaleString = Buffer.prototype.toString

Buffer.prototype.equals = function equals (b) {
  if (!Buffer.isBuffer(b)) throw new TypeError('Argument must be a Buffer')
  if (this === b) return true
  return Buffer.compare(this, b) === 0
}

Buffer.prototype.inspect = function inspect () {
  let str = ''
  const max = exports.h2
  str = this.toString('hex', 0, max).replace(/(.{2})/g, '$1 ').trim()
  if (this.length > max) str += ' ... '
  return '<Buffer ' + str + '>'
}
if (customInspectSymbol) {
  Buffer.prototype[customInspectSymbol] = Buffer.prototype.inspect
}

Buffer.prototype.compare = function compare (target, start, end, thisStart, thisEnd) {
  if (isInstance(target, Uint8Array)) {
    target = Buffer.from(target, target.offset, target.byteLength)
  }
  if (!Buffer.isBuffer(target)) {
    throw new TypeError(
      'The "target" argument must be one of type Buffer or Uint8Array. ' +
      'Received type ' + (typeof target)
    )
  }

  if (start === undefined) {
    start = 0
  }
  if (end === undefined) {
    end = target ? target.length : 0
  }
  if (thisStart === undefined) {
    thisStart = 0
  }
  if (thisEnd === undefined) {
    thisEnd = this.length
  }

  if (start < 0 || end > target.length || thisStart < 0 || thisEnd > this.length) {
    throw new RangeError('out of range index')
  }

  if (thisStart >= thisEnd && start >= end) {
    return 0
  }
  if (thisStart >= thisEnd) {
    return -1
  }
  if (start >= end) {
    return 1
  }

  start >>>= 0
  end >>>= 0
  thisStart >>>= 0
  thisEnd >>>= 0

  if (this === target) return 0

  let x = thisEnd - thisStart
  let y = end - start
  const len = Math.min(x, y)

  const thisCopy = this.slice(thisStart, thisEnd)
  const targetCopy = target.slice(start, end)

  for (let i = 0; i < len; ++i) {
    if (thisCopy[i] !== targetCopy[i]) {
      x = thisCopy[i]
      y = targetCopy[i]
      break
    }
  }

  if (x < y) return -1
  if (y < x) return 1
  return 0
}

// Finds either the first index of `val` in `buffer` at offset >= `byteOffset`,
// OR the last index of `val` in `buffer` at offset <= `byteOffset`.
//
// Arguments:
// - buffer - a Buffer to search
// - val - a string, Buffer, or number
// - byteOffset - an index into `buffer`; will be clamped to an int32
// - encoding - an optional encoding, relevant is val is a string
// - dir - true for indexOf, false for lastIndexOf
function bidirectionalIndexOf (buffer, val, byteOffset, encoding, dir) {
  // Empty buffer means no match
  if (buffer.length === 0) return -1

  // Normalize byteOffset
  if (typeof byteOffset === 'string') {
    encoding = byteOffset
    byteOffset = 0
  } else if (byteOffset > 0x7fffffff) {
    byteOffset = 0x7fffffff
  } else if (byteOffset < -0x80000000) {
    byteOffset = -0x80000000
  }
  byteOffset = +byteOffset // Coerce to Number.
  if (numberIsNaN(byteOffset)) {
    // byteOffset: it it's undefined, null, NaN, "foo", etc, search whole buffer
    byteOffset = dir ? 0 : (buffer.length - 1)
  }

  // Normalize byteOffset: negative offsets start from the end of the buffer
  if (byteOffset < 0) byteOffset = buffer.length + byteOffset
  if (byteOffset >= buffer.length) {
    if (dir) return -1
    else byteOffset = buffer.length - 1
  } else if (byteOffset < 0) {
    if (dir) byteOffset = 0
    else return -1
  }

  // Normalize val
  if (typeof val === 'string') {
    val = Buffer.from(val, encoding)
  }

  // Finally, search either indexOf (if dir is true) or lastIndexOf
  if (Buffer.isBuffer(val)) {
    // Special case: looking for empty string/buffer always fails
    if (val.length === 0) {
      return -1
    }
    return arrayIndexOf(buffer, val, byteOffset, encoding, dir)
  } else if (typeof val === 'number') {
    val = val & 0xFF // Search for a byte value [0-255]
    if (typeof Uint8Array.prototype.indexOf === 'function') {
      if (dir) {
        return Uint8Array.prototype.indexOf.call(buffer, val, byteOffset)
      } else {
        return Uint8Array.prototype.lastIndexOf.call(buffer, val, byteOffset)
      }
    }
    return arrayIndexOf(buffer, [val], byteOffset, encoding, dir)
  }

  throw new TypeError('val must be string, number or Buffer')
}

function arrayIndexOf (arr, val, byteOffset, encoding, dir) {
  let indexSize = 1
  let arrLength = arr.length
  let valLength = val.length

  if (encoding !== undefined) {
    encoding = String(encoding).toLowerCase()
    if (encoding === 'ucs2' || encoding === 'ucs-2' ||
        encoding === 'utf16le' || encoding === 'utf-16le') {
      if (arr.length < 2 || val.length < 2) {
        return -1
      }
      indexSize = 2
      arrLength /= 2
      valLength /= 2
      byteOffset /= 2
    }
  }

  function read (buf, i) {
    if (indexSize === 1) {
      return buf[i]
    } else {
      return buf.readUInt16BE(i * indexSize)
    }
  }

  let i
  if (dir) {
    let foundIndex = -1
    for (i = byteOffset; i < arrLength; i++) {
      if (read(arr, i) === read(val, foundIndex === -1 ? 0 : i - foundIndex)) {
        if (foundIndex === -1) foundIndex = i
        if (i - foundIndex + 1 === valLength) return foundIndex * indexSize
      } else {
        if (foundIndex !== -1) i -= i - foundIndex
        foundIndex = -1
      }
    }
  } else {
    if (byteOffset + valLength > arrLength) byteOffset = arrLength - valLength
    for (i = byteOffset; i >= 0; i--) {
      let found = true
      for (let j = 0; j < valLength; j++) {
        if (read(arr, i + j) !== read(val, j)) {
          found = false
          break
        }
      }
      if (found) return i
    }
  }

  return -1
}

Buffer.prototype.includes = function includes (val, byteOffset, encoding) {
  return this.indexOf(val, byteOffset, encoding) !== -1
}

Buffer.prototype.indexOf = function indexOf (val, byteOffset, encoding) {
  return bidirectionalIndexOf(this, val, byteOffset, encoding, true)
}

Buffer.prototype.lastIndexOf = function lastIndexOf (val, byteOffset, encoding) {
  return bidirectionalIndexOf(this, val, byteOffset, encoding, false)
}

function hexWrite (buf, string, offset, length) {
  offset = Number(offset) || 0
  const remaining = buf.length - offset
  if (!length) {
    length = remaining
  } else {
    length = Number(length)
    if (length > remaining) {
      length = remaining
    }
  }

  const strLen = string.length

  if (length > strLen / 2) {
    length = strLen / 2
  }
  let i
  for (i = 0; i < length; ++i) {
    const parsed = parseInt(string.substr(i * 2, 2), 16)
    if (numberIsNaN(parsed)) return i
    buf[offset + i] = parsed
  }
  return i
}

function utf8Write (buf, string, offset, length) {
  return blitBuffer(utf8ToBytes(string, buf.length - offset), buf, offset, length)
}

function asciiWrite (buf, string, offset, length) {
  return blitBuffer(asciiToBytes(string), buf, offset, length)
}

function base64Write (buf, string, offset, length) {
  return blitBuffer(base64ToBytes(string), buf, offset, length)
}

function ucs2Write (buf, string, offset, length) {
  return blitBuffer(utf16leToBytes(string, buf.length - offset), buf, offset, length)
}

Buffer.prototype.write = function write (string, offset, length, encoding) {
  // Buffer#write(string)
  if (offset === undefined) {
    encoding = 'utf8'
    length = this.length
    offset = 0
  // Buffer#write(string, encoding)
  } else if (length === undefined && typeof offset === 'string') {
    encoding = offset
    length = this.length
    offset = 0
  // Buffer#write(string, offset[, length][, encoding])
  } else if (isFinite(offset)) {
    offset = offset >>> 0
    if (isFinite(length)) {
      length = length >>> 0
      if (encoding === undefined) encoding = 'utf8'
    } else {
      encoding = length
      length = undefined
    }
  } else {
    throw new Error(
      'Buffer.write(string, encoding, offset[, length]) is no longer supported'
    )
  }

  const remaining = this.length - offset
  if (length === undefined || length > remaining) length = remaining

  if ((string.length > 0 && (length < 0 || offset < 0)) || offset > this.length) {
    throw new RangeError('Attempt to write outside buffer bounds')
  }

  if (!encoding) encoding = 'utf8'

  let loweredCase = false
  for (;;) {
    switch (encoding) {
      case 'hex':
        return hexWrite(this, string, offset, length)

      case 'utf8':
      case 'utf-8':
        return utf8Write(this, string, offset, length)

      case 'ascii':
      case 'latin1':
      case 'binary':
        return asciiWrite(this, string, offset, length)

      case 'base64':
        // Warning: maxLength not taken into account in base64Write
        return base64Write(this, string, offset, length)

      case 'ucs2':
      case 'ucs-2':
      case 'utf16le':
      case 'utf-16le':
        return ucs2Write(this, string, offset, length)

      default:
        if (loweredCase) throw new TypeError('Unknown encoding: ' + encoding)
        encoding = ('' + encoding).toLowerCase()
        loweredCase = true
    }
  }
}

Buffer.prototype.toJSON = function toJSON () {
  return {
    type: 'Buffer',
    data: Array.prototype.slice.call(this._arr || this, 0)
  }
}

function base64Slice (buf, start, end) {
  if (start === 0 && end === buf.length) {
    return base64.fromByteArray(buf)
  } else {
    return base64.fromByteArray(buf.slice(start, end))
  }
}

function utf8Slice (buf, start, end) {
  end = Math.min(buf.length, end)
  const res = []

  let i = start
  while (i < end) {
    const firstByte = buf[i]
    let codePoint = null
    let bytesPerSequence = (firstByte > 0xEF)
      ? 4
      : (firstByte > 0xDF)
          ? 3
          : (firstByte > 0xBF)
              ? 2
              : 1

    if (i + bytesPerSequence <= end) {
      let secondByte, thirdByte, fourthByte, tempCodePoint

      switch (bytesPerSequence) {
        case 1:
          if (firstByte < 0x80) {
            codePoint = firstByte
          }
          break
        case 2:
          secondByte = buf[i + 1]
          if ((secondByte & 0xC0) === 0x80) {
            tempCodePoint = (firstByte & 0x1F) << 0x6 | (secondByte & 0x3F)
            if (tempCodePoint > 0x7F) {
              codePoint = tempCodePoint
            }
          }
          break
        case 3:
          secondByte = buf[i + 1]
          thirdByte = buf[i + 2]
          if ((secondByte & 0xC0) === 0x80 && (thirdByte & 0xC0) === 0x80) {
            tempCodePoint = (firstByte & 0xF) << 0xC | (secondByte & 0x3F) << 0x6 | (thirdByte & 0x3F)
            if (tempCodePoint > 0x7FF && (tempCodePoint < 0xD800 || tempCodePoint > 0xDFFF)) {
              codePoint = tempCodePoint
            }
          }
          break
        case 4:
          secondByte = buf[i + 1]
          thirdByte = buf[i + 2]
          fourthByte = buf[i + 3]
          if ((secondByte & 0xC0) === 0x80 && (thirdByte & 0xC0) === 0x80 && (fourthByte & 0xC0) === 0x80) {
            tempCodePoint = (firstByte & 0xF) << 0x12 | (secondByte & 0x3F) << 0xC | (thirdByte & 0x3F) << 0x6 | (fourthByte & 0x3F)
            if (tempCodePoint > 0xFFFF && tempCodePoint < 0x110000) {
              codePoint = tempCodePoint
            }
          }
      }
    }

    if (codePoint === null) {
      // we did not generate a valid codePoint so insert a
      // replacement char (U+FFFD) and advance only 1 byte
      codePoint = 0xFFFD
      bytesPerSequence = 1
    } else if (codePoint > 0xFFFF) {
      // encode to utf16 (surrogate pair dance)
      codePoint -= 0x10000
      res.push(codePoint >>> 10 & 0x3FF | 0xD800)
      codePoint = 0xDC00 | codePoint & 0x3FF
    }

    res.push(codePoint)
    i += bytesPerSequence
  }

  return decodeCodePointsArray(res)
}

// Based on http://stackoverflow.com/a/22747272/680742, the browser with
// the lowest limit is Chrome, with 0x10000 args.
// We go 1 magnitude less, for safety
const MAX_ARGUMENTS_LENGTH = 0x1000

function decodeCodePointsArray (codePoints) {
  const len = codePoints.length
  if (len <= MAX_ARGUMENTS_LENGTH) {
    return String.fromCharCode.apply(String, codePoints) // avoid extra slice()
  }

  // Decode in chunks to avoid "call stack size exceeded".
  let res = ''
  let i = 0
  while (i < len) {
    res += String.fromCharCode.apply(
      String,
      codePoints.slice(i, i += MAX_ARGUMENTS_LENGTH)
    )
  }
  return res
}

function asciiSlice (buf, start, end) {
  let ret = ''
  end = Math.min(buf.length, end)

  for (let i = start; i < end; ++i) {
    ret += String.fromCharCode(buf[i] & 0x7F)
  }
  return ret
}

function latin1Slice (buf, start, end) {
  let ret = ''
  end = Math.min(buf.length, end)

  for (let i = start; i < end; ++i) {
    ret += String.fromCharCode(buf[i])
  }
  return ret
}

function hexSlice (buf, start, end) {
  const len = buf.length

  if (!start || start < 0) start = 0
  if (!end || end < 0 || end > len) end = len

  let out = ''
  for (let i = start; i < end; ++i) {
    out += hexSliceLookupTable[buf[i]]
  }
  return out
}

function utf16leSlice (buf, start, end) {
  const bytes = buf.slice(start, end)
  let res = ''
  // If bytes.length is odd, the last 8 bits must be ignored (same as node.js)
  for (let i = 0; i < bytes.length - 1; i += 2) {
    res += String.fromCharCode(bytes[i] + (bytes[i + 1] * 256))
  }
  return res
}

Buffer.prototype.slice = function slice (start, end) {
  const len = this.length
  start = ~~start
  end = end === undefined ? len : ~~end

  if (start < 0) {
    start += len
    if (start < 0) start = 0
  } else if (start > len) {
    start = len
  }

  if (end < 0) {
    end += len
    if (end < 0) end = 0
  } else if (end > len) {
    end = len
  }

  if (end < start) end = start

  const newBuf = this.subarray(start, end)
  // Return an augmented `Uint8Array` instance
  Object.setPrototypeOf(newBuf, Buffer.prototype)

  return newBuf
}

/*
 * Need to make sure that buffer isn't trying to write out of bounds.
 */
function checkOffset (offset, ext, length) {
  if ((offset % 1) !== 0 || offset < 0) throw new RangeError('offset is not uint')
  if (offset + ext > length) throw new RangeError('Trying to access beyond buffer length')
}

Buffer.prototype.readUintLE =
Buffer.prototype.readUIntLE = function readUIntLE (offset, byteLength, noAssert) {
  offset = offset >>> 0
  byteLength = byteLength >>> 0
  if (!noAssert) checkOffset(offset, byteLength, this.length)

  let val = this[offset]
  let mul = 1
  let i = 0
  while (++i < byteLength && (mul *= 0x100)) {
    val += this[offset + i] * mul
  }

  return val
}

Buffer.prototype.readUintBE =
Buffer.prototype.readUIntBE = function readUIntBE (offset, byteLength, noAssert) {
  offset = offset >>> 0
  byteLength = byteLength >>> 0
  if (!noAssert) {
    checkOffset(offset, byteLength, this.length)
  }

  let val = this[offset + --byteLength]
  let mul = 1
  while (byteLength > 0 && (mul *= 0x100)) {
    val += this[offset + --byteLength] * mul
  }

  return val
}

Buffer.prototype.readUint8 =
Buffer.prototype.readUInt8 = function readUInt8 (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 1, this.length)
  return this[offset]
}

Buffer.prototype.readUint16LE =
Buffer.prototype.readUInt16LE = function readUInt16LE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 2, this.length)
  return this[offset] | (this[offset + 1] << 8)
}

Buffer.prototype.readUint16BE =
Buffer.prototype.readUInt16BE = function readUInt16BE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 2, this.length)
  return (this[offset] << 8) | this[offset + 1]
}

Buffer.prototype.readUint32LE =
Buffer.prototype.readUInt32LE = function readUInt32LE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 4, this.length)

  return ((this[offset]) |
      (this[offset + 1] << 8) |
      (this[offset + 2] << 16)) +
      (this[offset + 3] * 0x1000000)
}

Buffer.prototype.readUint32BE =
Buffer.prototype.readUInt32BE = function readUInt32BE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 4, this.length)

  return (this[offset] * 0x1000000) +
    ((this[offset + 1] << 16) |
    (this[offset + 2] << 8) |
    this[offset + 3])
}

Buffer.prototype.readBigUInt64LE = defineBigIntMethod(function readBigUInt64LE (offset) {
  offset = offset >>> 0
  validateNumber(offset, 'offset')
  const first = this[offset]
  const last = this[offset + 7]
  if (first === undefined || last === undefined) {
    boundsError(offset, this.length - 8)
  }

  const lo = first +
    this[++offset] * 2 ** 8 +
    this[++offset] * 2 ** 16 +
    this[++offset] * 2 ** 24

  const hi = this[++offset] +
    this[++offset] * 2 ** 8 +
    this[++offset] * 2 ** 16 +
    last * 2 ** 24

  return BigInt(lo) + (BigInt(hi) << BigInt(32))
})

Buffer.prototype.readBigUInt64BE = defineBigIntMethod(function readBigUInt64BE (offset) {
  offset = offset >>> 0
  validateNumber(offset, 'offset')
  const first = this[offset]
  const last = this[offset + 7]
  if (first === undefined || last === undefined) {
    boundsError(offset, this.length - 8)
  }

  const hi = first * 2 ** 24 +
    this[++offset] * 2 ** 16 +
    this[++offset] * 2 ** 8 +
    this[++offset]

  const lo = this[++offset] * 2 ** 24 +
    this[++offset] * 2 ** 16 +
    this[++offset] * 2 ** 8 +
    last

  return (BigInt(hi) << BigInt(32)) + BigInt(lo)
})

Buffer.prototype.readIntLE = function readIntLE (offset, byteLength, noAssert) {
  offset = offset >>> 0
  byteLength = byteLength >>> 0
  if (!noAssert) checkOffset(offset, byteLength, this.length)

  let val = this[offset]
  let mul = 1
  let i = 0
  while (++i < byteLength && (mul *= 0x100)) {
    val += this[offset + i] * mul
  }
  mul *= 0x80

  if (val >= mul) val -= Math.pow(2, 8 * byteLength)

  return val
}

Buffer.prototype.readIntBE = function readIntBE (offset, byteLength, noAssert) {
  offset = offset >>> 0
  byteLength = byteLength >>> 0
  if (!noAssert) checkOffset(offset, byteLength, this.length)

  let i = byteLength
  let mul = 1
  let val = this[offset + --i]
  while (i > 0 && (mul *= 0x100)) {
    val += this[offset + --i] * mul
  }
  mul *= 0x80

  if (val >= mul) val -= Math.pow(2, 8 * byteLength)

  return val
}

Buffer.prototype.readInt8 = function readInt8 (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 1, this.length)
  if (!(this[offset] & 0x80)) return (this[offset])
  return ((0xff - this[offset] + 1) * -1)
}

Buffer.prototype.readInt16LE = function readInt16LE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 2, this.length)
  const val = this[offset] | (this[offset + 1] << 8)
  return (val & 0x8000) ? val | 0xFFFF0000 : val
}

Buffer.prototype.readInt16BE = function readInt16BE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 2, this.length)
  const val = this[offset + 1] | (this[offset] << 8)
  return (val & 0x8000) ? val | 0xFFFF0000 : val
}

Buffer.prototype.readInt32LE = function readInt32LE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 4, this.length)

  return (this[offset]) |
    (this[offset + 1] << 8) |
    (this[offset + 2] << 16) |
    (this[offset + 3] << 24)
}

Buffer.prototype.readInt32BE = function readInt32BE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 4, this.length)

  return (this[offset] << 24) |
    (this[offset + 1] << 16) |
    (this[offset + 2] << 8) |
    (this[offset + 3])
}

Buffer.prototype.readBigInt64LE = defineBigIntMethod(function readBigInt64LE (offset) {
  offset = offset >>> 0
  validateNumber(offset, 'offset')
  const first = this[offset]
  const last = this[offset + 7]
  if (first === undefined || last === undefined) {
    boundsError(offset, this.length - 8)
  }

  const val = this[offset + 4] +
    this[offset + 5] * 2 ** 8 +
    this[offset + 6] * 2 ** 16 +
    (last << 24) // Overflow

  return (BigInt(val) << BigInt(32)) +
    BigInt(first +
    this[++offset] * 2 ** 8 +
    this[++offset] * 2 ** 16 +
    this[++offset] * 2 ** 24)
})

Buffer.prototype.readBigInt64BE = defineBigIntMethod(function readBigInt64BE (offset) {
  offset = offset >>> 0
  validateNumber(offset, 'offset')
  const first = this[offset]
  const last = this[offset + 7]
  if (first === undefined || last === undefined) {
    boundsError(offset, this.length - 8)
  }

  const val = (first << 24) + // Overflow
    this[++offset] * 2 ** 16 +
    this[++offset] * 2 ** 8 +
    this[++offset]

  return (BigInt(val) << BigInt(32)) +
    BigInt(this[++offset] * 2 ** 24 +
    this[++offset] * 2 ** 16 +
    this[++offset] * 2 ** 8 +
    last)
})

Buffer.prototype.readFloatLE = function readFloatLE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 4, this.length)
  return ieee754.read(this, offset, true, 23, 4)
}

Buffer.prototype.readFloatBE = function readFloatBE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 4, this.length)
  return ieee754.read(this, offset, false, 23, 4)
}

Buffer.prototype.readDoubleLE = function readDoubleLE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 8, this.length)
  return ieee754.read(this, offset, true, 52, 8)
}

Buffer.prototype.readDoubleBE = function readDoubleBE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 8, this.length)
  return ieee754.read(this, offset, false, 52, 8)
}

function checkInt (buf, value, offset, ext, max, min) {
  if (!Buffer.isBuffer(buf)) throw new TypeError('"buffer" argument must be a Buffer instance')
  if (value > max || value < min) throw new RangeError('"value" argument is out of bounds')
  if (offset + ext > buf.length) throw new RangeError('Index out of range')
}

Buffer.prototype.writeUintLE =
Buffer.prototype.writeUIntLE = function writeUIntLE (value, offset, byteLength, noAssert) {
  value = +value
  offset = offset >>> 0
  byteLength = byteLength >>> 0
  if (!noAssert) {
    const maxBytes = Math.pow(2, 8 * byteLength) - 1
    checkInt(this, value, offset, byteLength, maxBytes, 0)
  }

  let mul = 1
  let i = 0
  this[offset] = value & 0xFF
  while (++i < byteLength && (mul *= 0x100)) {
    this[offset + i] = (value / mul) & 0xFF
  }

  return offset + byteLength
}

Buffer.prototype.writeUintBE =
Buffer.prototype.writeUIntBE = function writeUIntBE (value, offset, byteLength, noAssert) {
  value = +value
  offset = offset >>> 0
  byteLength = byteLength >>> 0
  if (!noAssert) {
    const maxBytes = Math.pow(2, 8 * byteLength) - 1
    checkInt(this, value, offset, byteLength, maxBytes, 0)
  }

  let i = byteLength - 1
  let mul = 1
  this[offset + i] = value & 0xFF
  while (--i >= 0 && (mul *= 0x100)) {
    this[offset + i] = (value / mul) & 0xFF
  }

  return offset + byteLength
}

Buffer.prototype.writeUint8 =
Buffer.prototype.writeUInt8 = function writeUInt8 (value, offset, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) checkInt(this, value, offset, 1, 0xff, 0)
  this[offset] = (value & 0xff)
  return offset + 1
}

Buffer.prototype.writeUint16LE =
Buffer.prototype.writeUInt16LE = function writeUInt16LE (value, offset, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) checkInt(this, value, offset, 2, 0xffff, 0)
  this[offset] = (value & 0xff)
  this[offset + 1] = (value >>> 8)
  return offset + 2
}

Buffer.prototype.writeUint16BE =
Buffer.prototype.writeUInt16BE = function writeUInt16BE (value, offset, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) checkInt(this, value, offset, 2, 0xffff, 0)
  this[offset] = (value >>> 8)
  this[offset + 1] = (value & 0xff)
  return offset + 2
}

Buffer.prototype.writeUint32LE =
Buffer.prototype.writeUInt32LE = function writeUInt32LE (value, offset, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) checkInt(this, value, offset, 4, 0xffffffff, 0)
  this[offset + 3] = (value >>> 24)
  this[offset + 2] = (value >>> 16)
  this[offset + 1] = (value >>> 8)
  this[offset] = (value & 0xff)
  return offset + 4
}

Buffer.prototype.writeUint32BE =
Buffer.prototype.writeUInt32BE = function writeUInt32BE (value, offset, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) checkInt(this, value, offset, 4, 0xffffffff, 0)
  this[offset] = (value >>> 24)
  this[offset + 1] = (value >>> 16)
  this[offset + 2] = (value >>> 8)
  this[offset + 3] = (value & 0xff)
  return offset + 4
}

function wrtBigUInt64LE (buf, value, offset, min, max) {
  checkIntBI(value, min, max, buf, offset, 7)

  let lo = Number(value & BigInt(0xffffffff))
  buf[offset++] = lo
  lo = lo >> 8
  buf[offset++] = lo
  lo = lo >> 8
  buf[offset++] = lo
  lo = lo >> 8
  buf[offset++] = lo
  let hi = Number(value >> BigInt(32) & BigInt(0xffffffff))
  buf[offset++] = hi
  hi = hi >> 8
  buf[offset++] = hi
  hi = hi >> 8
  buf[offset++] = hi
  hi = hi >> 8
  buf[offset++] = hi
  return offset
}

function wrtBigUInt64BE (buf, value, offset, min, max) {
  checkIntBI(value, min, max, buf, offset, 7)

  let lo = Number(value & BigInt(0xffffffff))
  buf[offset + 7] = lo
  lo = lo >> 8
  buf[offset + 6] = lo
  lo = lo >> 8
  buf[offset + 5] = lo
  lo = lo >> 8
  buf[offset + 4] = lo
  let hi = Number(value >> BigInt(32) & BigInt(0xffffffff))
  buf[offset + 3] = hi
  hi = hi >> 8
  buf[offset + 2] = hi
  hi = hi >> 8
  buf[offset + 1] = hi
  hi = hi >> 8
  buf[offset] = hi
  return offset + 8
}

Buffer.prototype.writeBigUInt64LE = defineBigIntMethod(function writeBigUInt64LE (value, offset = 0) {
  return wrtBigUInt64LE(this, value, offset, BigInt(0), BigInt('0xffffffffffffffff'))
})

Buffer.prototype.writeBigUInt64BE = defineBigIntMethod(function writeBigUInt64BE (value, offset = 0) {
  return wrtBigUInt64BE(this, value, offset, BigInt(0), BigInt('0xffffffffffffffff'))
})

Buffer.prototype.writeIntLE = function writeIntLE (value, offset, byteLength, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) {
    const limit = Math.pow(2, (8 * byteLength) - 1)

    checkInt(this, value, offset, byteLength, limit - 1, -limit)
  }

  let i = 0
  let mul = 1
  let sub = 0
  this[offset] = value & 0xFF
  while (++i < byteLength && (mul *= 0x100)) {
    if (value < 0 && sub === 0 && this[offset + i - 1] !== 0) {
      sub = 1
    }
    this[offset + i] = ((value / mul) >> 0) - sub & 0xFF
  }

  return offset + byteLength
}

Buffer.prototype.writeIntBE = function writeIntBE (value, offset, byteLength, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) {
    const limit = Math.pow(2, (8 * byteLength) - 1)

    checkInt(this, value, offset, byteLength, limit - 1, -limit)
  }

  let i = byteLength - 1
  let mul = 1
  let sub = 0
  this[offset + i] = value & 0xFF
  while (--i >= 0 && (mul *= 0x100)) {
    if (value < 0 && sub === 0 && this[offset + i + 1] !== 0) {
      sub = 1
    }
    this[offset + i] = ((value / mul) >> 0) - sub & 0xFF
  }

  return offset + byteLength
}

Buffer.prototype.writeInt8 = function writeInt8 (value, offset, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) checkInt(this, value, offset, 1, 0x7f, -0x80)
  if (value < 0) value = 0xff + value + 1
  this[offset] = (value & 0xff)
  return offset + 1
}

Buffer.prototype.writeInt16LE = function writeInt16LE (value, offset, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) checkInt(this, value, offset, 2, 0x7fff, -0x8000)
  this[offset] = (value & 0xff)
  this[offset + 1] = (value >>> 8)
  return offset + 2
}

Buffer.prototype.writeInt16BE = function writeInt16BE (value, offset, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) checkInt(this, value, offset, 2, 0x7fff, -0x8000)
  this[offset] = (value >>> 8)
  this[offset + 1] = (value & 0xff)
  return offset + 2
}

Buffer.prototype.writeInt32LE = function writeInt32LE (value, offset, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) checkInt(this, value, offset, 4, 0x7fffffff, -0x80000000)
  this[offset] = (value & 0xff)
  this[offset + 1] = (value >>> 8)
  this[offset + 2] = (value >>> 16)
  this[offset + 3] = (value >>> 24)
  return offset + 4
}

Buffer.prototype.writeInt32BE = function writeInt32BE (value, offset, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) checkInt(this, value, offset, 4, 0x7fffffff, -0x80000000)
  if (value < 0) value = 0xffffffff + value + 1
  this[offset] = (value >>> 24)
  this[offset + 1] = (value >>> 16)
  this[offset + 2] = (value >>> 8)
  this[offset + 3] = (value & 0xff)
  return offset + 4
}

Buffer.prototype.writeBigInt64LE = defineBigIntMethod(function writeBigInt64LE (value, offset = 0) {
  return wrtBigUInt64LE(this, value, offset, -BigInt('0x8000000000000000'), BigInt('0x7fffffffffffffff'))
})

Buffer.prototype.writeBigInt64BE = defineBigIntMethod(function writeBigInt64BE (value, offset = 0) {
  return wrtBigUInt64BE(this, value, offset, -BigInt('0x8000000000000000'), BigInt('0x7fffffffffffffff'))
})

function checkIEEE754 (buf, value, offset, ext, max, min) {
  if (offset + ext > buf.length) throw new RangeError('Index out of range')
  if (offset < 0) throw new RangeError('Index out of range')
}

function writeFloat (buf, value, offset, littleEndian, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) {
    checkIEEE754(buf, value, offset, 4, 3.4028234663852886e+38, -3.4028234663852886e+38)
  }
  ieee754.write(buf, value, offset, littleEndian, 23, 4)
  return offset + 4
}

Buffer.prototype.writeFloatLE = function writeFloatLE (value, offset, noAssert) {
  return writeFloat(this, value, offset, true, noAssert)
}

Buffer.prototype.writeFloatBE = function writeFloatBE (value, offset, noAssert) {
  return writeFloat(this, value, offset, false, noAssert)
}

function writeDouble (buf, value, offset, littleEndian, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) {
    checkIEEE754(buf, value, offset, 8, 1.7976931348623157E+308, -1.7976931348623157E+308)
  }
  ieee754.write(buf, value, offset, littleEndian, 52, 8)
  return offset + 8
}

Buffer.prototype.writeDoubleLE = function writeDoubleLE (value, offset, noAssert) {
  return writeDouble(this, value, offset, true, noAssert)
}

Buffer.prototype.writeDoubleBE = function writeDoubleBE (value, offset, noAssert) {
  return writeDouble(this, value, offset, false, noAssert)
}

// copy(targetBuffer, targetStart=0, sourceStart=0, sourceEnd=buffer.length)
Buffer.prototype.copy = function copy (target, targetStart, start, end) {
  if (!Buffer.isBuffer(target)) throw new TypeError('argument should be a Buffer')
  if (!start) start = 0
  if (!end && end !== 0) end = this.length
  if (targetStart >= target.length) targetStart = target.length
  if (!targetStart) targetStart = 0
  if (end > 0 && end < start) end = start

  // Copy 0 bytes; we're done
  if (end === start) return 0
  if (target.length === 0 || this.length === 0) return 0

  // Fatal error conditions
  if (targetStart < 0) {
    throw new RangeError('targetStart out of bounds')
  }
  if (start < 0 || start >= this.length) throw new RangeError('Index out of range')
  if (end < 0) throw new RangeError('sourceEnd out of bounds')

  // Are we oob?
  if (end > this.length) end = this.length
  if (target.length - targetStart < end - start) {
    end = target.length - targetStart + start
  }

  const len = end - start

  if (this === target && typeof Uint8Array.prototype.copyWithin === 'function') {
    // Use built-in when available, missing from IE11
    this.copyWithin(targetStart, start, end)
  } else {
    Uint8Array.prototype.set.call(
      target,
      this.subarray(start, end),
      targetStart
    )
  }

  return len
}

// Usage:
//    buffer.fill(number[, offset[, end]])
//    buffer.fill(buffer[, offset[, end]])
//    buffer.fill(string[, offset[, end]][, encoding])
Buffer.prototype.fill = function fill (val, start, end, encoding) {
  // Handle string cases:
  if (typeof val === 'string') {
    if (typeof start === 'string') {
      encoding = start
      start = 0
      end = this.length
    } else if (typeof end === 'string') {
      encoding = end
      end = this.length
    }
    if (encoding !== undefined && typeof encoding !== 'string') {
      throw new TypeError('encoding must be a string')
    }
    if (typeof encoding === 'string' && !Buffer.isEncoding(encoding)) {
      throw new TypeError('Unknown encoding: ' + encoding)
    }
    if (val.length === 1) {
      const code = val.charCodeAt(0)
      if ((encoding === 'utf8' && code < 128) ||
          encoding === 'latin1') {
        // Fast path: If `val` fits into a single byte, use that numeric value.
        val = code
      }
    }
  } else if (typeof val === 'number') {
    val = val & 255
  } else if (typeof val === 'boolean') {
    val = Number(val)
  }

  // Invalid ranges are not set to a default, so can range check early.
  if (start < 0 || this.length < start || this.length < end) {
    throw new RangeError('Out of range index')
  }

  if (end <= start) {
    return this
  }

  start = start >>> 0
  end = end === undefined ? this.length : end >>> 0

  if (!val) val = 0

  let i
  if (typeof val === 'number') {
    for (i = start; i < end; ++i) {
      this[i] = val
    }
  } else {
    const bytes = Buffer.isBuffer(val)
      ? val
      : Buffer.from(val, encoding)
    const len = bytes.length
    if (len === 0) {
      throw new TypeError('The value "' + val +
        '" is invalid for argument "value"')
    }
    for (i = 0; i < end - start; ++i) {
      this[i + start] = bytes[i % len]
    }
  }

  return this
}

// CUSTOM ERRORS
// =============

// Simplified versions from Node, changed for Buffer-only usage
const errors = {}
function E (sym, getMessage, Base) {
  errors[sym] = class NodeError extends Base {
    constructor () {
      super()

      Object.defineProperty(this, 'message', {
        value: getMessage.apply(this, arguments),
        writable: true,
        configurable: true
      })

      // Add the error code to the name to include it in the stack trace.
      this.name = `${this.name} [${sym}]`
      // Access the stack to generate the error message including the error code
      // from the name.
      this.stack // eslint-disable-line no-unused-expressions
      // Reset the name to the actual name.
      delete this.name
    }

    get code () {
      return sym
    }

    set code (value) {
      Object.defineProperty(this, 'code', {
        configurable: true,
        enumerable: true,
        value,
        writable: true
      })
    }

    toString () {
      return `${this.name} [${sym}]: ${this.message}`
    }
  }
}

E('ERR_BUFFER_OUT_OF_BOUNDS',
  function (name) {
    if (name) {
      return `${name} is outside of buffer bounds`
    }

    return 'Attempt to access memory outside buffer bounds'
  }, RangeError)
E('ERR_INVALID_ARG_TYPE',
  function (name, actual) {
    return `The "${name}" argument must be of type number. Received type ${typeof actual}`
  }, TypeError)
E('ERR_OUT_OF_RANGE',
  function (str, range, input) {
    let msg = `The value of "${str}" is out of range.`
    let received = input
    if (Number.isInteger(input) && Math.abs(input) > 2 ** 32) {
      received = addNumericalSeparator(String(input))
    } else if (typeof input === 'bigint') {
      received = String(input)
      if (input > BigInt(2) ** BigInt(32) || input < -(BigInt(2) ** BigInt(32))) {
        received = addNumericalSeparator(received)
      }
      received += 'n'
    }
    msg += ` It must be ${range}. Received ${received}`
    return msg
  }, RangeError)

function addNumericalSeparator (val) {
  let res = ''
  let i = val.length
  const start = val[0] === '-' ? 1 : 0
  for (; i >= start + 4; i -= 3) {
    res = `_${val.slice(i - 3, i)}${res}`
  }
  return `${val.slice(0, i)}${res}`
}

// CHECK FUNCTIONS
// ===============

function checkBounds (buf, offset, byteLength) {
  validateNumber(offset, 'offset')
  if (buf[offset] === undefined || buf[offset + byteLength] === undefined) {
    boundsError(offset, buf.length - (byteLength + 1))
  }
}

function checkIntBI (value, min, max, buf, offset, byteLength) {
  if (value > max || value < min) {
    const n = typeof min === 'bigint' ? 'n' : ''
    let range
    if (byteLength > 3) {
      if (min === 0 || min === BigInt(0)) {
        range = `>= 0${n} and < 2${n} ** ${(byteLength + 1) * 8}${n}`
      } else {
        range = `>= -(2${n} ** ${(byteLength + 1) * 8 - 1}${n}) and < 2 ** ` +
                `${(byteLength + 1) * 8 - 1}${n}`
      }
    } else {
      range = `>= ${min}${n} and <= ${max}${n}`
    }
    throw new errors.ERR_OUT_OF_RANGE('value', range, value)
  }
  checkBounds(buf, offset, byteLength)
}

function validateNumber (value, name) {
  if (typeof value !== 'number') {
    throw new errors.ERR_INVALID_ARG_TYPE(name, 'number', value)
  }
}

function boundsError (value, length, type) {
  if (Math.floor(value) !== value) {
    validateNumber(value, type)
    throw new errors.ERR_OUT_OF_RANGE(type || 'offset', 'an integer', value)
  }

  if (length < 0) {
    throw new errors.ERR_BUFFER_OUT_OF_BOUNDS()
  }

  throw new errors.ERR_OUT_OF_RANGE(type || 'offset',
                                    `>= ${type ? 1 : 0} and <= ${length}`,
                                    value)
}

// HELPER FUNCTIONS
// ================

const INVALID_BASE64_RE = /[^+/0-9A-Za-z-_]/g

function base64clean (str) {
  // Node takes equal signs as end of the Base64 encoding
  str = str.split('=')[0]
  // Node strips out invalid characters like \n and \t from the string, base64-js does not
  str = str.trim().replace(INVALID_BASE64_RE, '')
  // Node converts strings with length < 2 to ''
  if (str.length < 2) return ''
  // Node allows for non-padded base64 strings (missing trailing ===), base64-js does not
  while (str.length % 4 !== 0) {
    str = str + '='
  }
  return str
}

function utf8ToBytes (string, units) {
  units = units || Infinity
  let codePoint
  const length = string.length
  let leadSurrogate = null
  const bytes = []

  for (let i = 0; i < length; ++i) {
    codePoint = string.charCodeAt(i)

    // is surrogate component
    if (codePoint > 0xD7FF && codePoint < 0xE000) {
      // last char was a lead
      if (!leadSurrogate) {
        // no lead yet
        if (codePoint > 0xDBFF) {
          // unexpected trail
          if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD)
          continue
        } else if (i + 1 === length) {
          // unpaired lead
          if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD)
          continue
        }

        // valid lead
        leadSurrogate = codePoint

        continue
      }

      // 2 leads in a row
      if (codePoint < 0xDC00) {
        if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD)
        leadSurrogate = codePoint
        continue
      }

      // valid surrogate pair
      codePoint = (leadSurrogate - 0xD800 << 10 | codePoint - 0xDC00) + 0x10000
    } else if (leadSurrogate) {
      // valid bmp char, but last char was a lead
      if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD)
    }

    leadSurrogate = null

    // encode utf8
    if (codePoint < 0x80) {
      if ((units -= 1) < 0) break
      bytes.push(codePoint)
    } else if (codePoint < 0x800) {
      if ((units -= 2) < 0) break
      bytes.push(
        codePoint >> 0x6 | 0xC0,
        codePoint & 0x3F | 0x80
      )
    } else if (codePoint < 0x10000) {
      if ((units -= 3) < 0) break
      bytes.push(
        codePoint >> 0xC | 0xE0,
        codePoint >> 0x6 & 0x3F | 0x80,
        codePoint & 0x3F | 0x80
      )
    } else if (codePoint < 0x110000) {
      if ((units -= 4) < 0) break
      bytes.push(
        codePoint >> 0x12 | 0xF0,
        codePoint >> 0xC & 0x3F | 0x80,
        codePoint >> 0x6 & 0x3F | 0x80,
        codePoint & 0x3F | 0x80
      )
    } else {
      throw new Error('Invalid code point')
    }
  }

  return bytes
}

function asciiToBytes (str) {
  const byteArray = []
  for (let i = 0; i < str.length; ++i) {
    // Node's code seems to be doing this and not & 0x7F..
    byteArray.push(str.charCodeAt(i) & 0xFF)
  }
  return byteArray
}

function utf16leToBytes (str, units) {
  let c, hi, lo
  const byteArray = []
  for (let i = 0; i < str.length; ++i) {
    if ((units -= 2) < 0) break

    c = str.charCodeAt(i)
    hi = c >> 8
    lo = c % 256
    byteArray.push(lo)
    byteArray.push(hi)
  }

  return byteArray
}

function base64ToBytes (str) {
  return base64.toByteArray(base64clean(str))
}

function blitBuffer (src, dst, offset, length) {
  let i
  for (i = 0; i < length; ++i) {
    if ((i + offset >= dst.length) || (i >= src.length)) break
    dst[i + offset] = src[i]
  }
  return i
}

// ArrayBuffer or Uint8Array objects from other contexts (i.e. iframes) do not pass
// the `instanceof` check but they should be treated as of that type.
// See: https://github.com/feross/buffer/issues/166
function isInstance (obj, type) {
  return obj instanceof type ||
    (obj != null && obj.constructor != null && obj.constructor.name != null &&
      obj.constructor.name === type.name)
}
function numberIsNaN (obj) {
  // For IE11 support
  return obj !== obj // eslint-disable-line no-self-compare
}

// Create lookup table for `toString('hex')`
// See: https://github.com/feross/buffer/issues/219
const hexSliceLookupTable = (function () {
  const alphabet = '0123456789abcdef'
  const table = new Array(256)
  for (let i = 0; i < 16; ++i) {
    const i16 = i * 16
    for (let j = 0; j < 16; ++j) {
      table[i16 + j] = alphabet[i] + alphabet[j]
    }
  }
  return table
})()

// Return not function with Error if BigInt not supported
function defineBigIntMethod (fn) {
  return typeof BigInt === 'undefined' ? BufferBigIntNotDefined : fn
}

function BufferBigIntNotDefined () {
  throw new Error('BigInt not supported')
}


/***/ }),

/***/ 645:
/***/ ((__unused_webpack_module, exports) => {

/*! ieee754. BSD-3-Clause License. Feross Aboukhadijeh <https://feross.org/opensource> */
exports.read = function (buffer, offset, isLE, mLen, nBytes) {
  var e, m
  var eLen = (nBytes * 8) - mLen - 1
  var eMax = (1 << eLen) - 1
  var eBias = eMax >> 1
  var nBits = -7
  var i = isLE ? (nBytes - 1) : 0
  var d = isLE ? -1 : 1
  var s = buffer[offset + i]

  i += d

  e = s & ((1 << (-nBits)) - 1)
  s >>= (-nBits)
  nBits += eLen
  for (; nBits > 0; e = (e * 256) + buffer[offset + i], i += d, nBits -= 8) {}

  m = e & ((1 << (-nBits)) - 1)
  e >>= (-nBits)
  nBits += mLen
  for (; nBits > 0; m = (m * 256) + buffer[offset + i], i += d, nBits -= 8) {}

  if (e === 0) {
    e = 1 - eBias
  } else if (e === eMax) {
    return m ? NaN : ((s ? -1 : 1) * Infinity)
  } else {
    m = m + Math.pow(2, mLen)
    e = e - eBias
  }
  return (s ? -1 : 1) * m * Math.pow(2, e - mLen)
}

exports.write = function (buffer, value, offset, isLE, mLen, nBytes) {
  var e, m, c
  var eLen = (nBytes * 8) - mLen - 1
  var eMax = (1 << eLen) - 1
  var eBias = eMax >> 1
  var rt = (mLen === 23 ? Math.pow(2, -24) - Math.pow(2, -77) : 0)
  var i = isLE ? 0 : (nBytes - 1)
  var d = isLE ? 1 : -1
  var s = value < 0 || (value === 0 && 1 / value < 0) ? 1 : 0

  value = Math.abs(value)

  if (isNaN(value) || value === Infinity) {
    m = isNaN(value) ? 1 : 0
    e = eMax
  } else {
    e = Math.floor(Math.log(value) / Math.LN2)
    if (value * (c = Math.pow(2, -e)) < 1) {
      e--
      c *= 2
    }
    if (e + eBias >= 1) {
      value += rt / c
    } else {
      value += rt * Math.pow(2, 1 - eBias)
    }
    if (value * c >= 2) {
      e++
      c /= 2
    }

    if (e + eBias >= eMax) {
      m = 0
      e = eMax
    } else if (e + eBias >= 1) {
      m = ((value * c) - 1) * Math.pow(2, mLen)
      e = e + eBias
    } else {
      m = value * Math.pow(2, eBias - 1) * Math.pow(2, mLen)
      e = 0
    }
  }

  for (; mLen >= 8; buffer[offset + i] = m & 0xff, i += d, m /= 256, mLen -= 8) {}

  e = (e << mLen) | m
  eLen += mLen
  for (; eLen > 0; buffer[offset + i] = e & 0xff, i += d, e /= 256, eLen -= 8) {}

  buffer[offset + i - d] |= s * 128
}


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be in strict mode.
(() => {
"use strict";

;// CONCATENATED MODULE: ./node_modules/@hazae41/symbol-dispose-polyfill/dist/esm/mods/symbol-dispose-polyfill/polyfill.mjs
if (typeof Symbol.dispose !== "symbol")
    Object.defineProperty(Symbol, "dispose", {
        configurable: false,
        enumerable: false,
        writable: false,
        value: Symbol.for("dispose")
    });
if (typeof Symbol.asyncDispose !== "symbol")
    Object.defineProperty(Symbol, "asyncDispose", {
        configurable: false,
        enumerable: false,
        writable: false,
        value: Symbol.for("asyncDispose")
    });
//# sourceMappingURL=polyfill.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/symbol-dispose-polyfill/dist/esm/index.mjs

//# sourceMappingURL=index.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/future/dist/esm/mods/future/future.mjs
class Future {
    #resolve;
    #reject;
    promise;
    /**
     * Just like a Promise but you can manually resolve or reject it
     */
    constructor() {
        this.promise = new Promise((subresolve, subreject) => {
            this.#resolve = subresolve;
            this.#reject = subreject;
        });
    }
    get resolve() {
        return this.#resolve;
    }
    get reject() {
        return this.#reject;
    }
}


//# sourceMappingURL=future.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/option/dist/esm/mods/option/option.mjs



var Option;
(function (Option) {
    function from(init) {
        if ("inner" in init)
            return new Some(init.inner);
        return new None();
    }
    Option.from = from;
    /**
     * Create an Option from a nullable value
     * @param inner
     * @returns `Some<T>` if `T`, `None` if `undefined`
     */
    function wrap(inner) {
        if (inner == null)
            return new None();
        return new Some(inner);
    }
    Option.wrap = wrap;
    async function map(inner, mapper) {
        return Option.wrap(inner).map(mapper).then(o => o.get());
    }
    Option.map = map;
    function mapSync(inner, mapper) {
        return Option.wrap(inner).mapSync(mapper).get();
    }
    Option.mapSync = mapSync;
    function unwrap(inner) {
        return Option.wrap(inner).unwrap();
    }
    Option.unwrap = unwrap;
})(Option || (Option = {}));


//# sourceMappingURL=option.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/result.mjs





var Result;
(function (Result) {
    Result.debug = false;
    /**
     * Create a Result from a maybe Error value
     * @param inner
     * @returns `Ok<T>` if `T`, `Err<Error>` if `Error`
     */
    function from(inner) {
        if (inner instanceof Error)
            return new err_Err(inner);
        else
            return new ok_Ok(inner);
    }
    Result.from = from;
    /**
     * Create a Result from a boolean
     * @param value
     * @returns
     */
    function assert(value) {
        return value ? ok_Ok.void() : new err_Err(new AssertError());
    }
    Result.assert = assert;
    function rewrap(wrapper) {
        try {
            return new ok_Ok(wrapper.unwrap());
        }
        catch (error) {
            return new err_Err(error);
        }
    }
    Result.rewrap = rewrap;
    /**
     * Catch an Err thrown from Err.throw
     * @param callback
     * @param type
     * @returns `Ok<T>` if no `Err` was thrown, `Err<E>` otherwise
     * @see Err.throw
     */
    async function unthrow(callback) {
        let ref;
        try {
            return await callback((e) => ref = e);
        }
        catch (e) {
            if (ref !== undefined)
                return ref;
            throw e;
        }
    }
    Result.unthrow = unthrow;
    /**
     * Catch an Err thrown from Err.throw
     * @param callback
     * @param type
     * @returns `Ok<T>` if no `Err` was thrown, `Err<E>` otherwise
     * @see Err.throw
     */
    function unthrowSync(callback) {
        let ref;
        try {
            return callback((e) => ref = e);
        }
        catch (e) {
            if (ref !== undefined)
                return ref;
            throw e;
        }
    }
    Result.unthrowSync = unthrowSync;
    /**
     * Convert try-catch to Result<T, unknown>
     * @param callback
     * @returns
     */
    async function runAndWrap(callback) {
        try {
            return new ok_Ok(await callback());
        }
        catch (e) {
            return new err_Err(e);
        }
    }
    Result.runAndWrap = runAndWrap;
    /**
     * Convert try-catch to Result<T, unknown>
     * @param callback
     * @returns
     */
    function runAndWrapSync(callback) {
        try {
            return new ok_Ok(callback());
        }
        catch (e) {
            return new err_Err(e);
        }
    }
    Result.runAndWrapSync = runAndWrapSync;
    /**
     * Convert try-catch to Result<T, Catched>
     * @param callback
     * @returns
     */
    async function runAndDoubleWrap(callback) {
        return runAndWrap(callback).then(r => r.mapErrSync(errors_Catched.from));
    }
    Result.runAndDoubleWrap = runAndDoubleWrap;
    /**
     * Convert try-catch to Result<T, Catched>
     * @param callback
     * @returns
     */
    function runAndDoubleWrapSync(callback) {
        return runAndWrapSync(callback).mapErrSync(errors_Catched.from);
    }
    Result.runAndDoubleWrapSync = runAndDoubleWrapSync;
    /**
     * Transform Result<Result<T, E1>, E2> into Result<T, E1 | E2>
     * @param result
     * @returns `this` if `Err`, `this.inner` if `Ok`
     */
    function flatten(result) {
        if (result.isErr())
            return result;
        return result.get();
    }
    Result.flatten = flatten;
    /**
     * Transform `Iterable<Result<T,E>` into `Result<Array<T>, E>`
     * @param iterable
     * @returns `Result<Array<T>, E>`
     */
    function all(iterable) {
        return collect(iterate(iterable));
    }
    Result.all = all;
    function maybeAll(iterable) {
        return maybeCollect(maybeIterate(iterable));
    }
    Result.maybeAll = maybeAll;
    /**
     * Transform `Iterable<Result<T,E>` into `Iterator<T, Result<void, E>>`
     * @param iterable
     * @returns `Iterator<T, Result<void, E>>`
     */
    function* iterate(iterable) {
        for (const result of iterable) {
            if (result.isOk())
                yield result.get();
            else
                return result;
        }
        return ok_Ok.void();
    }
    Result.iterate = iterate;
    function* maybeIterate(iterable) {
        for (const result of iterable) {
            if (result == null)
                return result;
            else if (result.isOk())
                yield result.get();
            else
                return result;
        }
        return ok_Ok.void();
    }
    Result.maybeIterate = maybeIterate;
    /**
     * Transform `Iterator<T, Result<void, E>>` into `Result<Array<T>, E>`
     * @param iterator `Result<Array<T>, E>`
     */
    function collect(iterator) {
        const array = new Array();
        let result = iterator.next();
        for (; !result.done; result = iterator.next())
            array.push(result.value);
        return result.value.set(array);
    }
    Result.collect = collect;
    function maybeCollect(iterator) {
        const array = new Array();
        let result = iterator.next();
        for (; !result.done; result = iterator.next())
            array.push(result.value);
        return Option.mapSync(result.value, result => result.set(array));
    }
    Result.maybeCollect = maybeCollect;
    /**
     * Unwrap the callback but wrap thrown errors in Catched
     * @param callback
     * @returns `T` if `Ok`
     * @throws `Catched` if `callback()` throws, `E` if `Err`
     */
    async function runAndUnwrap(callback) {
        let result;
        try {
            result = await callback();
        }
        catch (e) {
            throw errors_Catched.from(e);
        }
        return result.unwrap();
    }
    Result.runAndUnwrap = runAndUnwrap;
    /**
     * Unwrap the callback but wrap thrown errors in Catched
     * @param callback
     * @returns `T` if `Ok`
     * @throws `Catched` if `callback()` throws, `E` if `Err`
     */
    function runAndUnwrapSync(callback) {
        let result;
        try {
            result = callback();
        }
        catch (e) {
            throw errors_Catched.from(e);
        }
        return result.unwrap();
    }
    Result.runAndUnwrapSync = runAndUnwrapSync;
})(Result || (Result = {}));


//# sourceMappingURL=result.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/err.mjs




class err_Err {
    #inner;
    #timeout;
    /**
     * A failure
     * @param inner
     */
    constructor(inner) {
        this.#inner = inner;
        if (!Result.debug)
            return;
        const error = new Panic(`Unhandled`, { cause: this.inner });
        this.#timeout = setTimeout(() => { throw error; }, 1000);
    }
    /**
     * Create an empty `Err`
     * @returns `Err(void)`
     */
    static void() {
        return new err_Err(undefined);
    }
    /**
     * Create an `Err`
     * @param inner
     * @returns `Err(inner)`
     */
    static new(inner) {
        return new err_Err(inner);
    }
    /**
     * Create an `Err` with an `Error` inside
     * @param message
     * @param options
     * @returns `Err<Error>`
     */
    static error(message, options) {
        return new err_Err(new Error(message, options));
    }
    get inner() {
        return this.#inner;
    }
    /**
     * Set this result as handled
     */
    ignore() {
        if (!this.#timeout)
            return this;
        clearTimeout(this.#timeout);
        this.#timeout = undefined;
        return this;
    }
    /**
     * Type guard for `Ok`
     * @returns `true` if `Ok`, `false` if `Err`
     */
    isOk() {
        return false;
    }
    /**
     * Returns true if the result is `Ok` and the value inside of it matches a predicate
     * @param okPredicate
     * @returns `true` if `Ok` and `await okPredicate(this.inner)`, `false` otherwise
     */
    async isOkAnd(okPredicate) {
        return false;
    }
    /**
     * Returns true if the result is `Ok` and the value inside of it matches a predicate
     * @param okPredicate
     * @returns `true` if `Ok` and `await okPredicate(this.inner)`, `false` otherwise
     */
    isOkAndSync(okPredicate) {
        return false;
    }
    /**
     * Type guard for `Err`
     * @returns `true` if `Err`, `false` if `Ok`
     */
    isErr() {
        return true;
    }
    /**
     * Returns true if the result is `Err` and the value inside of it matches a predicate
     * @param errPredicate
     * @returns `true` if `Err` and `await errPredicate(this.inner)`, `false` otherwise
     */
    async isErrAnd(errPredicate) {
        return await errPredicate(this.inner);
    }
    /**
     * Returns true if the result is `Err` and the value inside of it matches a predicate
     * @param errPredicate
     * @returns `true` if `Err` and `await errPredicate(this.inner)`, `false` otherwise
     */
    isErrAndSync(errPredicate) {
        return errPredicate(this.inner);
    }
    /**
     * Compile-time safely get `this.inner`
     * @returns `this.inner`
     */
    get() {
        this.ignore();
        return this.inner;
    }
    /**
     * Transform `Result<T, E>` into `Option<T>`
     * @returns `Some(this.inner)` if `Ok`, `None` if `Err`
     */
    ok() {
        this.ignore();
        return new None();
    }
    /**
     * Transform `Result<T, E>` into `Option<E>`
     * @returns `Some(this.inner)` if `Err`, `None` if `Ok`
     */
    err() {
        this.ignore();
        return new Some(this.inner);
    }
    /**
     * Returns an iterator over the possibly contained value
     * @yields `this.inner` if `Ok`
     */
    *[Symbol.iterator]() {
        this.ignore();
        return;
    }
    /**
     * Transform `Result<T,E>` into `[T,E]`
     * @returns `[this.inner, undefined]` if `Ok`, `[undefined, this.inner]` if `Err`
     */
    split() {
        this.ignore();
        return [undefined, this.inner];
    }
    /**
     * Returns true if the result is an `Ok` value containing the given value
     * @param value
     * @returns `true` if `Ok` and `this.inner === value`, `false` otherwise
     */
    contains(value) {
        return false;
    }
    /**
     * Returns true if the result is an `Err` value containing the given value
     * @param value
     * @returns `true` if `Err` and `this.inner === value`, `false` otherwise
     */
    containsErr(value) {
        return this.inner === value;
    }
    /**
     * Get the inner value or throw to the closest `Result.unthrow`
     * @param thrower The thrower from `Result.unthrow`
     * @returns `this.inner` if `Ok`
     * @throws `undefined` if `Err`
     * @see Result.unthrow
     * @see Result.unthrowSync
     */
    throw(thrower) {
        thrower(this);
        throw new Panic(`Thrown`, { cause: this });
    }
    /**
     * Get the inner value or throw the inner error wrapped inside another Error
     * @param message
     * @returns `this.inner` if `Ok`, `Error(message, { cause: this.inner })` if `Err`
     */
    expect(message) {
        this.ignore();
        throw new Panic(message, { cause: this });
    }
    /**
     * Get the inner error or throw the inner value wrapped inside another Error
     * @param message
     * @returns `this.inner` if `Err`, `Error(message, { cause: this.inner })` if `Ok`
     */
    expectErr(message) {
        this.ignore();
        return this.inner;
    }
    /**
     * Get the inner value or panic
     * @returns `this.inner` if `Ok`
     * @throws `this.inner` if `Err`
     */
    unwrap() {
        this.ignore();
        throw new Panic(`Unwrapped`, { cause: this });
    }
    /**
     * Get the inner error or panic
     * @returns `this.inner` if `Err`
     * @throws `this.inner` if `Ok`
     */
    unwrapErr() {
        this.ignore();
        return this.inner;
    }
    /**
     * Get the inner value or a default one
     * @param value
     * @returns `this.inner` if `Ok`, `value` if `Err`
     */
    unwrapOr(value) {
        this.ignore();
        return value;
    }
    /**
     * Get the inner value or compute a default one from the inner error
     * @param errMapper
     * @returns `this.inner` if `Ok`, `await errMapper(this.inner)` if `Err`
     * @throws if `await errMapper(this.inner)` throws
     */
    async unwrapOrElse(errMapper) {
        this.ignore();
        return await errMapper(this.inner);
    }
    /**
     * Get the inner value or compute a default one from the inner error
     * @param errMapper
     * @returns `this.inner` if `Ok`, `errMapper(this.inner)` if `Err`
     * @throws if `errMapper(this.inner)` throws
     */
    unwrapOrElseSync(errMapper) {
        this.ignore();
        return errMapper(this.inner);
    }
    /**
     * Transform Result<Promise<T>, E> into Promise<Result<T, E>>
     * @returns `await this.inner` if `Ok`, `this` if `Err`
     */
    async await() {
        return this;
    }
    /**
     * Transform Result<T, Promise<E>> into Promise<Result<T, E>>
     * @returns `await this.inner` if `Err`, `this` if `Ok`
     */
    async awaitErr() {
        return new err_Err(await this.inner);
    }
    /**
     * Transform Result<Promise<T>, Promise<E>> into Promise<Result<T, E>>
     * @returns `await this.inner`
     */
    async awaitAll() {
        return await this.awaitErr();
    }
    /**
     * Transform `Result<T, E>` into `Result<void, E>`
     * @returns `Ok<void>` if `Ok<T>`, `Err<E>` if `E<E>`
     */
    clear() {
        return this;
    }
    /**
     * Transform `Result<T, E>` into `Result<T, void>`
     * @returns `Ok<T>` if `Ok<T>`, `Err<void>` if `E<E>`
     */
    clearErr() {
        this.ignore();
        return err_Err.void();
    }
    /**
     * Calls the given callback with the inner value if `Ok`
     * @param okCallback
     * @returns `this`
     */
    async inspect(okCallback) {
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Ok`
     * @param okCallback
     * @returns `this`
     */
    inspectSync(okCallback) {
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Err`
     * @param errCallback
     * @returns `this`
     */
    async inspectErr(errCallback) {
        await errCallback(this.inner);
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Err`
     * @param errCallback
     * @returns `this`
     */
    inspectErrSync(errCallback) {
        errCallback(this.inner);
        return this;
    }
    /**
     * Return a new `Ok` but with the given `inner`
     * @param inner
     * @returns `Ok(inner)` if `Ok`, `this` if `Err`
     */
    set(inner) {
        return this;
    }
    /**
     * Return a new `Err` but with the given `inner`
     * @param inner
     * @returns `Err(inner)` if `Err`, `this` if `Ok`
     */
    setErr(inner) {
        return new err_Err(inner);
    }
    /**
     * Map the inner value into another
     * @param okMapper
     * @returns `Ok(await okMapper(this.inner))` if `Ok`, `this` if `Err`
     * @throws if `await okMapper(this.inner)` throws
     */
    async map(okMapper) {
        return this;
    }
    /**
     * Map the inner value into another
     * @param okMapper
     * @returns `Ok(okMapper(this.inner))` if `Ok`, `this` if `Err`
     * @throws if `okMapper(this.inner)` throws
     */
    mapSync(okMapper) {
        return this;
    }
    /**
     * Map the inner error into another
     * @param errMapper
     * @returns `Err(await errMapper(this.inner))` if `Err`, `this` if `Ok`
     * @throws if `await errMapper(this.inner)` throws
     */
    async mapErr(errMapper) {
        this.ignore();
        return new err_Err(await errMapper(this.inner));
    }
    /**
     * Map the inner error into another
     * @param errMapper
     * @returns `Err(errMapper(this.inner))` if `Err`, `this` if `Ok`
     * @throws if `errMapper(this.inner)` throws
     */
    mapErrSync(errMapper) {
        this.ignore();
        return new err_Err(errMapper(this.inner));
    }
    /**
     * Map the inner value into another, or a default one
     * @param value
     * @param okMapper
     * @returns `await okMapper(this.inner)` if `Ok`, `value` if `Err`
     * @throws if `await okMapper(this.inner)` throws
     */
    async mapOr(value, okMapper) {
        this.ignore();
        return value;
    }
    /**
     * Map the inner value into another, or a default one
     * @param value
     * @param okMapper
     * @returns `okMapper(this.inner)` if `Ok`, `value` if `Err`
     * @throws if `okMapper(this.inner)` throws
     */
    mapOrSync(value, okMapper) {
        this.ignore();
        return value;
    }
    /**
     * Map the inner value into another, or a default one
     * @param errMapper
     * @param okMapper
     * @returns `await okMapper(this.inner)` if `Ok`, `await errMapper(this.inner)` if `Err`
     * @throws if `await okMapper(this.inner)` or `await errMapper(this.inner)` throws
     */
    async mapOrElse(errMapper, okMapper) {
        this.ignore();
        return await errMapper(this.inner);
    }
    /**
     * Map the inner value into another, or a default one
     * @param errMapper
     * @param okMapper
     * @returns `okMapper(this.inner)` if `Ok`, `errMapper(this.inner)` if `Err`
     * @throws if `okMapper(this.inner)` or `errMapper(this.inner)` throws
     */
    mapOrElseSync(errMapper, okMapper) {
        this.ignore();
        return errMapper(this.inner);
    }
    /**
     * Return `value` if `Ok`, return `this` if `Err`
     * @param value
     * @returns `value` if `Ok`, `this` if `Err`
     */
    and(value) {
        return this;
    }
    /**
     * Return `await okMapper(this.inner)` if `Ok`, return `this` if `Err`
     * @param okMapper
     * @returns `await okMapper(this.inner)` if `Ok`, `this` if `Err`
     * @throws if `await okMapper(this.inner)` throws
     */
    async andThen(okMapper) {
        return this;
    }
    /**
     * Return `okMapper(this.inner)` if `Ok`, return `this` if `Err`
     * @param okMapper
     * @returns `okMapper(this.inner)` if `Ok`, `this` if `Err`
     * @throws if `okMapper(this.inner)` throws
     */
    andThenSync(okMapper) {
        return this;
    }
    /**
     * Return `value` if `Err`, return `this` if `Ok`
     * @param value
     * @returns `value` if `Err`, `this` if `Ok`
     */
    or(value) {
        this.ignore();
        return value;
    }
    /**
     * Return `await errMapper(this.inner)` if `Err`, return `this` if `Ok`
     * @param errMapper
     * @returns `await errMapper(this.inner)` if `Err`, `this` if `Ok`
     * @throws if `await errMapper(this.inner)` throws
     */
    async orElse(errMapper) {
        this.ignore();
        return await errMapper(this.inner);
    }
    /**
     * Return `errMapper(this.inner)` if `Err`, return `this` if `Ok`
     * @param errMapper
     * @returns `errMapper(this.inner)` if `Err`, `this` if `Ok`
     * @throws if `errMapper(this.inner)` throws
     */
    orElseSync(errMapper) {
        this.ignore();
        return errMapper(this.inner);
    }
    /**
     * Transform Result<Result<T, E1>, E2> into Result<T, E1 | E2>
     * @param result
     * @returns `this` if `Err`, `this.inner` if `Ok`
     */
    flatten() {
        return this;
    }
}


//# sourceMappingURL=err.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/errors.mjs


class Unimplemented extends (/* unused pure expression or super */ null && (Error)) {
    #class = Unimplemented;
    name = this.#class.name;
}
class AssertError extends Error {
    #class = AssertError;
    name = this.#class.name;
    constructor() {
        super(`Assertion failed`);
    }
}
class Panic extends Error {
    #class = Panic;
    name = this.#class.name;
    static from(cause) {
        return new Panic(undefined, { cause });
    }
    static fromAndThrow(cause) {
        throw Panic.from(cause);
    }
}
class errors_Catched extends Error {
    #class = errors_Catched;
    name = this.#class.name;
    static from(cause) {
        return new errors_Catched(undefined, { cause });
    }
    static fromAndThrow(cause) {
        throw errors_Catched.from(cause);
    }
    /**
     * Throw if `Catched`, wrap in `Err` otherwise
     * @param error
     * @returns `Err(error)` if not `Catched`
     * @throws `error.cause` if `Catched`
     */
    static throwOrErr(error) {
        if (error instanceof errors_Catched)
            throw error.cause;
        return new err_Err(error);
    }
}


//# sourceMappingURL=errors.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/option/dist/esm/mods/option/none.mjs


class NoneError extends Error {
    constructor() {
        super(`Option is a None`);
    }
}
class None {
    inner;
    /**
     * An empty value
     */
    constructor(inner = undefined) {
        this.inner = inner;
    }
    /**
     * Create a `None`
     * @returns `None`
     */
    static new() {
        return new None();
    }
    static from(init) {
        return new None();
    }
    /**
     * Type guard for `Some`
     * @returns `true` if `Some`, `false` if `None`
     */
    isSome() {
        return false;
    }
    /**
     * Returns `true` if the option is a `Some` and the value inside of it matches a predicate
     * @param somePredicate
     * @returns `true` if `Some` and `await somePredicate(this.inner)`, `None` otherwise
     */
    async isSomeAnd(somePredicate) {
        return false;
    }
    /**
     * Returns `true` if the option is a `Some` and the value inside of it matches a predicate
     * @param somePredicate
     * @returns `true` if `Some` and `somePredicate(this.inner)`, `None` otherwise
     */
    isSomeAndSync(somePredicate) {
        return false;
    }
    /**
     * Type guard for `None`
     * @returns `true` if `None`, `false` if `Some`
     */
    isNone() {
        return true;
    }
    /**
     * Compile-time safely get `this.inner`
     * @returns `this.inner`
     */
    get() {
        return this.inner;
    }
    /**
     * Returns an iterator over the possibly contained value
     * @yields `this.inner` if `Some`
     */
    *[Symbol.iterator]() {
        return;
    }
    /**
     * Get the inner value if `Some`, throw `Error(message)` otherwise
     * @param message
     * @returns `this.inner` if `Some`
     * @throws `Error(message)` if `None`
     */
    expect(message) {
        throw new Panic(message, { cause: this });
    }
    /**
     * Get the inner value or throw a NoneError
     * @returns `this.inner` if `Some`
     * @throws `NoneError` if `None`
     */
    unwrap() {
        throw new Panic(`Unwrapped`, { cause: this });
    }
    /**
     * Get the inner value or a default one
     * @param value
     * @returns `this.inner` if `Some`, `value` if `None`
     */
    unwrapOr(value) {
        return value;
    }
    /**
     * Returns the contained `Some` value or computes it from a closure
     * @param noneCallback
     * @returns `this.inner` if `Some`, `await noneCallback()` if `None`
     */
    async unwrapOrElse(noneCallback) {
        return await noneCallback();
    }
    /**
     * Returns the contained `Some` value or computes it from a closure
     * @param noneCallback
     * @returns `this.inner` if `Some`, `noneCallback()` if `None`
     */
    unwrapOrElseSync(noneCallback) {
        return noneCallback();
    }
    /**
     * Transform `Option<T>` into `Result<T, NoneError>`
     * @returns `Ok(this.inner)` if `Some`, `Err(NoneError)` if `None`
     */
    ok() {
        return new err_Err(new NoneError());
    }
    /**
     * Transform `Option<T>` into `Result<T, E>`
     * @param error
     * @returns `Ok(this.inner)` if `Some`, `Err(error)` if `None`
     */
    okOr(error) {
        return new err_Err(error);
    }
    /**
     * Transforms the `Option<T>` into a `Result<T, E>`, mapping `Some(v)` to `Ok(v)` and `None` to `Err(err())`
     * @param noneCallback
     * @returns `Ok(this.inner)` if `Some`, `Err(await noneCallback())` is `None`
     */
    async okOrElse(noneCallback) {
        return new err_Err(await noneCallback());
    }
    /**
     * Transforms the `Option<T>` into a `Result<T, E>`, mapping `Some(v)` to `Ok(v)` and `None` to `Err(err())`
     * @param noneCallback
     * @returns `Ok(this.inner)` if `Some`, `Err(noneCallback())` is `None`
     */
    okOrElseSync(noneCallback) {
        return new err_Err(noneCallback());
    }
    /**
     * Returns `None` if the option is `None`, otherwise calls `somePredicate` with the wrapped value
     * @param somePredicate
     * @returns `Some` if `Some` and `await somePredicate(this.inner)`, `None` otherwise
     */
    async filter(somePredicate) {
        return this;
    }
    /**
     * Returns `None` if the option is `None`, otherwise calls `somePredicate` with the wrapped value
     * @param somePredicate
     * @returns `Some` if `Some` and `somePredicate(this.inner)`, `None` otherwise
     */
    filterSync(somePredicate) {
        return this;
    }
    /**
     * Transform `Option<Promise<T>>` into `Promise<Option<T>>`
     * @returns `Promise<Option<T>>`
     */
    async await() {
        return this;
    }
    /**
     * Returns `true` if the option is a `Some` value containing the given value
     * @param value
     * @returns `true` if `Some` and `this.inner === value`, `None` otherwise
     */
    contains(value) {
        return false;
    }
    /**
     * Calls the given callback with the inner value if `Ok`
     * @param someCallback
     * @returns `this`
     */
    async inspect(someCallback) {
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Ok`
     * @param someCallback
     * @returns `this`
     */
    inspectSync(someCallback) {
        return this;
    }
    /**
     * Maps an `Option<T>` to `Option<U>` by applying a function to a contained value (if `Some`) or returns `None` (if `None`)
     * @param someMapper
     * @returns `Some(await someMapper(this.inner))` if `Some`, `this` if `None`
     */
    async map(someMapper) {
        return this;
    }
    /**
     * Maps an `Option<T>` to `Option<U>` by applying a function to a contained value (if `Some`) or returns `None` (if `None`)
     * @param someMapper
     * @returns `Some(someMapper(this.inner))` if `Some`, `this` if `None`
     */
    mapSync(someMapper) {
        return this;
    }
    /**
     * Returns the provided default result (if none), or applies a function to the contained value (if any)
     * @param value
     * @param someMapper
     * @returns `value` if `None`, `await someMapper(this.inner)` if `Some`
     */
    async mapOr(value, someMapper) {
        return value;
    }
    /**
     * Returns the provided default result (if none), or applies a function to the contained value (if any)
     * @param value
     * @param someMapper
     * @returns `value` if `None`, `someMapper(this.inner)` if `Some`
     */
    mapOrSync(value, someMapper) {
        return value;
    }
    /**
     * Computes a default function result (if none), or applies a different function to the contained value (if any)
     * @param noneCallback
     * @param someMapper
     * @returns `await someMapper(this.inner)` if `Some`, `await noneCallback()` if `None`
     */
    async mapOrElse(noneCallback, someMapper) {
        return await noneCallback();
    }
    /**
     * Computes a default function result (if none), or applies a different function to the contained value (if any)
     * @param noneCallback
     * @param someMapper
     * @returns `someMapper(this.inner)` if `Some`, `noneCallback()` if `None`
     */
    mapOrElseSync(noneCallback, someMapper) {
        return noneCallback();
    }
    /**
     * Returns `None` if the option is `None`, otherwise returns `value`
     * @param value
     * @returns `None` if `None`, `value` if `Some`
     */
    and(value) {
        return this;
    }
    /**
     * Returns `None` if the option is `None`, otherwise calls `someMapper` with the wrapped value and returns the result
     * @param someMapper
     * @returns `None` if `None`, `await someMapper(this.inner)` if `Some`
     */
    async andThen(someMapper) {
        return this;
    }
    /**
     * Returns `None` if the option is `None`, otherwise calls `someMapper` with the wrapped value and returns the result
     * @param someMapper
     * @returns `None` if `None`, `someMapper(this.inner)` if `Some`
     */
    andThenSync(someMapper) {
        return this;
    }
    /**
     * Returns `this` if `Some`, otherwise returns `value`
     * @param value
     * @returns `this` if `Some`, `value` if `None`
     */
    or(value) {
        return value;
    }
    /**
     * Returns `this` if `Some`, otherwise calls `noneCallback` and returns the result
     * @param noneCallback
     * @returns `this` if `Some`, `await noneCallback()` if `None`
     */
    async orElse(noneCallback) {
        return await noneCallback();
    }
    /**
     * Returns `this` if `Some`, otherwise calls `noneCallback` and returns the result
     * @param noneCallback
     * @returns `this` if `Some`, `noneCallback()` if `None`
     */
    orElseSync(noneCallback) {
        return noneCallback();
    }
    /**
     * Returns `Some` if exactly one of the options is `Some`, otherwise returns `None`
     * @param value
     * @returns `None` if both are `Some` or both are `None`, the only `Some` otherwise
     */
    xor(value) {
        return value;
    }
    /**
     * Zips `this` with another `Option`
     * @param other
     * @returns `Some([this.inner, other.inner])` if both are `Some`, `None` if one of them is `None`
     */
    zip(other) {
        return this;
    }
}


//# sourceMappingURL=none.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/option/dist/esm/mods/option/some.mjs



class Some {
    inner;
    /**
     * An existing value
     * @param inner
     */
    constructor(inner) {
        this.inner = inner;
    }
    /**
     * Create a `Some`
     * @param inner
     * @returns `Some(inner)`
     */
    static new(inner) {
        return new this(inner);
    }
    static from(init) {
        return new Some(init.inner);
    }
    /**
     * Type guard for `Some`
     * @returns `true` if `Some`, `false` if `None`
     */
    isSome() {
        return true;
    }
    /**
     * Returns `true` if the option is a `Some` and the value inside of it matches a predicate
     * @param somePredicate
     * @returns `true` if `Some` and `await somePredicate(this.inner)`, `None` otherwise
     */
    async isSomeAnd(somePredicate) {
        return await somePredicate(this.inner);
    }
    /**
     * Returns `true` if the option is a `Some` and the value inside of it matches a predicate
     * @param somePredicate
     * @returns `true` if `Some` and `somePredicate(this.inner)`, `None` otherwise
     */
    isSomeAndSync(somePredicate) {
        return somePredicate(this.inner);
    }
    /**
     * Type guard for `None`
     * @returns `true` if `None`, `false` if `Some`
     */
    isNone() {
        return false;
    }
    /**
     * Compile-time safely get `this.inner`
     * @returns `this.inner`
     */
    get() {
        return this.inner;
    }
    /**
     * Returns an iterator over the possibly contained value
     * @yields `this.inner` if `Some`
     */
    *[Symbol.iterator]() {
        yield this.inner;
    }
    /**
     * Get the inner value if `Some`, throw `Error(message)` otherwise
     * @param message
     * @returns `this.inner` if `Some`
     * @throws `Error(message)` if `None`
     */
    expect(message) {
        return this.inner;
    }
    /**
     * Get the inner value or throw a NoneError
     * @returns `this.inner` if `Some`
     * @throws `NoneError` if `None`
     */
    unwrap() {
        return this.inner;
    }
    /**
     * Get the inner value or a default one
     * @param value
     * @returns `this.inner` if `Some`, `value` if `None`
     */
    unwrapOr(value) {
        return this.inner;
    }
    /**
     * Returns the contained `Some` value or computes it from a closure
     * @param noneCallback
     * @returns `this.inner` if `Some`, `await noneCallback()` if `None`
     */
    async unwrapOrElse(noneCallback) {
        return this.inner;
    }
    /**
     * Returns the contained `Some` value or computes it from a closure
     * @param noneCallback
     * @returns `this.inner` if `Some`, `noneCallback()` if `None`
     */
    unwrapOrElseSync(noneCallback) {
        return this.inner;
    }
    /**
     * Transform `Option<T>` into `Result<T, NoneError>`
     * @returns `Ok(this.inner)` if `Some`, `Err(NoneError)` if `None`
     */
    ok() {
        return new ok_Ok(this.inner);
    }
    /**
     * Transform `Option<T>` into `Result<T, E>`
     * @param error
     * @returns `Ok(this.inner)` if `Some`, `Err(error)` if `None`
     */
    okOr(error) {
        return new ok_Ok(this.inner);
    }
    /**
     * Transforms the `Option<T>` into a `Result<T, E>`, mapping `Some(v)` to `Ok(v)` and `None` to `Err(err())`
     * @param noneCallback
     * @returns `Ok(this.inner)` if `Some`, `Err(await noneCallback())` is `None`
     */
    async okOrElse(noneCallback) {
        return new ok_Ok(this.inner);
    }
    /**
     * Transforms the `Option<T>` into a `Result<T, E>`, mapping `Some(v)` to `Ok(v)` and `None` to `Err(err())`
     * @param noneCallback
     * @returns `Ok(this.inner)` if `Some`, `Err(noneCallback())` is `None`
     */
    okOrElseSync(noneCallback) {
        return new ok_Ok(this.inner);
    }
    /**
     * Returns `None` if the option is `None`, otherwise calls `somePredicate` with the wrapped value
     * @param somePredicate
     * @returns `Some` if `Some` and `await somePredicate(this.inner)`, `None` otherwise
     */
    async filter(somePredicate) {
        if (await somePredicate(this.inner))
            return this;
        else
            return new None();
    }
    /**
     * Returns `None` if the option is `None`, otherwise calls `somePredicate` with the wrapped value
     * @param somePredicate
     * @returns `Some` if `Some` and `somePredicate(this.inner)`, `None` otherwise
     */
    filterSync(somePredicate) {
        if (somePredicate(this.inner))
            return this;
        else
            return new None();
    }
    /**
     * Transform `Option<Promise<T>>` into `Promise<Option<T>>`
     * @returns `Promise<Option<T>>`
     */
    async await() {
        return new Some(await this.inner);
    }
    /**
     * Returns `true` if the option is a `Some` value containing the given value
     * @param value
     * @returns `true` if `Some` and `this.inner === value`, `None` otherwise
     */
    contains(value) {
        return this.inner === value;
    }
    /**
     * Calls the given callback with the inner value if `Ok`
     * @param someCallback
     * @returns `this`
     */
    async inspect(someCallback) {
        await someCallback(this.inner);
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Ok`
     * @param someCallback
     * @returns `this`
     */
    inspectSync(someCallback) {
        someCallback(this.inner);
        return this;
    }
    /**
     * Maps an `Option<T>` to `Option<U>` by applying a function to a contained value (if `Some`) or returns `None` (if `None`)
     * @param someMapper
     * @returns `Some(await someMapper(this.inner))` if `Some`, `this` if `None`
     */
    async map(someMapper) {
        return new Some(await someMapper(this.inner));
    }
    /**
     * Maps an `Option<T>` to `Option<U>` by applying a function to a contained value (if `Some`) or returns `None` (if `None`)
     * @param someMapper
     * @returns `Some(someMapper(this.inner))` if `Some`, `this` if `None`
     */
    mapSync(someMapper) {
        return new Some(someMapper(this.inner));
    }
    /**
     * Returns the provided default result (if none), or applies a function to the contained value (if any)
     * @param value
     * @param someMapper
     * @returns `value` if `None`, `await someMapper(this.inner)` if `Some`
     */
    async mapOr(value, someMapper) {
        return await someMapper(this.inner);
    }
    /**
     * Returns the provided default result (if none), or applies a function to the contained value (if any)
     * @param value
     * @param someMapper
     * @returns `value` if `None`, `someMapper(this.inner)` if `Some`
     */
    mapOrSync(value, someMapper) {
        return someMapper(this.inner);
    }
    /**
     * Computes a default function result (if none), or applies a different function to the contained value (if any)
     * @param noneCallback
     * @param someMapper
     * @returns `await someMapper(this.inner)` if `Some`, `await noneCallback()` if `None`
     */
    async mapOrElse(noneCallback, someMapper) {
        return await someMapper(this.inner);
    }
    /**
     * Computes a default function result (if none), or applies a different function to the contained value (if any)
     * @param noneCallback
     * @param someMapper
     * @returns `someMapper(this.inner)` if `Some`, `noneCallback()` if `None`
     */
    mapOrElseSync(noneCallback, someMapper) {
        return someMapper(this.inner);
    }
    /**
     * Returns `None` if the option is `None`, otherwise returns `value`
     * @param value
     * @returns `None` if `None`, `value` if `Some`
     */
    and(value) {
        return value;
    }
    /**
     * Returns `None` if the option is `None`, otherwise calls `someMapper` with the wrapped value and returns the result
     * @param someMapper
     * @returns `None` if `None`, `await someMapper(this.inner)` if `Some`
     */
    async andThen(someMapper) {
        return await someMapper(this.inner);
    }
    /**
     * Returns `None` if the option is `None`, otherwise calls `someMapper` with the wrapped value and returns the result
     * @param someMapper
     * @returns `None` if `None`, `someMapper(this.inner)` if `Some`
     */
    andThenSync(someMapper) {
        return someMapper(this.inner);
    }
    /**
     * Returns `this` if `Some`, otherwise returns `value`
     * @param value
     * @returns `this` if `Some`, `value` if `None`
     */
    or(value) {
        return this;
    }
    /**
     * Returns `this` if `Some`, otherwise calls `noneCallback` and returns the result
     * @param noneCallback
     * @returns `this` if `Some`, `await noneCallback()` if `None`
     */
    async orElse(noneCallback) {
        return this;
    }
    /**
     * Returns `this` if `Some`, otherwise calls `noneCallback` and returns the result
     * @param noneCallback
     * @returns `this` if `Some`, `noneCallback()` if `None`
     */
    orElseSync(noneCallback) {
        return this;
    }
    /**
     * Returns `Some` if exactly one of the options is `Some`, otherwise returns `None`
     * @param value
     * @returns `None` if both are `Some` or both are `None`, the only `Some` otherwise
     */
    xor(value) {
        if (value.isSome())
            return new None();
        else
            return this;
    }
    /**
     * Zips `this` with another `Option`
     * @param other
     * @returns `Some([this.inner, other.inner])` if both are `Some`, `None` if one of them is `None`
     */
    zip(other) {
        if (other.isSome())
            return new Some([this.inner, other.inner]);
        else
            return other;
    }
}


//# sourceMappingURL=some.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/ok.mjs




class ok_Ok {
    #inner;
    #timeout;
    /**
     * A success
     * @param inner
     */
    constructor(inner) {
        this.#inner = inner;
        if (!Result.debug)
            return;
        const error = new Panic(`Unhandled`, { cause: this });
        this.#timeout = setTimeout(() => { throw error; }, 1000);
    }
    /**
     * Create an empty `Ok`
     * @returns `Ok(void)`
     */
    static void() {
        return new ok_Ok(undefined);
    }
    /**
     * Create an `Ok`
     * @param inner
     * @returns `Ok(inner)`
     */
    static new(inner) {
        return new ok_Ok(inner);
    }
    get inner() {
        return this.#inner;
    }
    /**
     * Set this result as handled
     */
    ignore() {
        if (!this.#timeout)
            return this;
        clearTimeout(this.#timeout);
        this.#timeout = undefined;
        return this;
    }
    /**
     * Type guard for `Ok`
     * @returns `true` if `Ok`, `false` if `Err`
     */
    isOk() {
        return true;
    }
    /**
     * Returns true if the result is `Ok` and the value inside of it matches a predicate
     * @param okPredicate
     * @returns `true` if `Ok` and `await okPredicate(this.inner)`, `false` otherwise
     */
    async isOkAnd(okPredicate) {
        return await okPredicate(this.inner);
    }
    /**
     * Returns true if the result is `Ok` and the value inside of it matches a predicate
     * @param okPredicate
     * @returns `true` if `Ok` and `await okPredicate(this.inner)`, `false` otherwise
     */
    isOkAndSync(okPredicate) {
        return okPredicate(this.inner);
    }
    /**
     * Type guard for `Err`
     * @returns `true` if `Err`, `false` if `Ok`
     */
    isErr() {
        return false;
    }
    /**
     * Returns true if the result is `Err` and the value inside of it matches a predicate
     * @param errPredicate
     * @returns `true` if `Err` and `await errPredicate(this.inner)`, `false` otherwise
     */
    async isErrAnd(errPredicate) {
        return false;
    }
    /**
     * Returns true if the result is `Err` and the value inside of it matches a predicate
     * @param errPredicate
     * @returns `true` if `Err` and `await errPredicate(this.inner)`, `false` otherwise
     */
    isErrAndSync(errPredicate) {
        return false;
    }
    /**
     * Compile-time safely get `this.inner`
     * @returns `this.inner`
     */
    get() {
        this.ignore();
        return this.inner;
    }
    /**
     * Transform `Result<T, E>` into `Option<T>`
     * @returns `Some(this.inner)` if `Ok`, `None` if `Err`
     */
    ok() {
        this.ignore();
        return new Some(this.inner);
    }
    /**
     * Transform `Result<T, E>` into `Option<E>`
     * @returns `Some(this.inner)` if `Err`, `None` if `Ok`
     */
    err() {
        this.ignore();
        return new None();
    }
    /**
     * Returns an iterator over the possibly contained value
     * @yields `this.inner` if `Ok`
     */
    *[Symbol.iterator]() {
        this.ignore();
        yield this.inner;
    }
    /**
     * Transform `Result<T,E>` into `[T,E]`
     * @returns `[this.inner, undefined]` if `Ok`, `[undefined, this.inner]` if `Err`
     */
    split() {
        this.ignore();
        return [this.inner, undefined];
    }
    /**
     * Returns true if the result is an `Ok` value containing the given value
     * @param value
     * @returns `true` if `Ok` and `this.inner === value`, `false` otherwise
     */
    contains(value) {
        return this.inner === value;
    }
    /**
     * Returns true if the result is an `Err` value containing the given value
     * @param value
     * @returns `true` if `Err` and `this.inner === value`, `false` otherwise
     */
    containsErr(value) {
        return false;
    }
    /**
     * Just like `unwrap` but it throws to the closest `Result.unthrow`
     * @returns `this.inner` if `Ok`
     * @throws `this` if `Err`
     * @see Result.unthrow
     * @see Result.unthrowSync
     */
    throw(thrower) {
        this.ignore();
        return this.inner;
    }
    /**
     * Get the inner value or throw the inner error wrapped inside another Error
     * @param message
     * @returns `this.inner` if `Ok`, `Error(message, { cause: this.inner })` if `Err`
     */
    expect(message) {
        this.ignore();
        return this.inner;
    }
    /**
     * Get the inner error or throw the inner value wrapped inside another Error
     * @param message
     * @returns `this.inner` if `Err`, `Error(message, { cause: this.inner })` if `Ok`
     */
    expectErr(message) {
        this.ignore();
        throw new Panic(message, { cause: this });
    }
    /**
     * Get the inner value or panic
     * @returns `this.inner` if `Ok`
     * @throws `this.inner` if `Err`
     */
    unwrap() {
        this.ignore();
        return this.inner;
    }
    /**
     * Get the inner error or panic
     * @returns `this.inner` if `Err`
     * @throws `this.inner` if `Ok`
     */
    unwrapErr() {
        this.ignore();
        throw new Panic(`Unwrapped`, { cause: this });
    }
    /**
     * Get the inner value or a default one
     * @param value
     * @returns `this.inner` if `Ok`, `value` if `Err`
     */
    unwrapOr(value) {
        this.ignore();
        return this.inner;
    }
    /**
     * Get the inner value or compute a default one from the inner error
     * @param errMapper
     * @returns `this.inner` if `Ok`, `await errMapper(this.inner)` if `Err`
     * @throws if `await errMapper(this.inner)` throws
     */
    async unwrapOrElse(errMapper) {
        this.ignore();
        return this.inner;
    }
    /**
     * Get the inner value or compute a default one from the inner error
     * @param errMapper
     * @returns `this.inner` if `Ok`, `errMapper(this.inner)` if `Err`
     * @throws if `errMapper(this.inner)` throws
     */
    unwrapOrElseSync(errMapper) {
        this.ignore();
        return this.inner;
    }
    /**
     * Transform Result<Promise<T>, E> into Promise<Result<T, E>>
     * @returns `await this.inner` if `Ok`, `this` if `Err`
     */
    async await() {
        return new ok_Ok(await this.inner);
    }
    /**
     * Transform Result<T, Promise<E>> into Promise<Result<T, E>>
     * @returns `await this.inner` if `Err`, `this` if `Ok`
     */
    async awaitErr() {
        return this;
    }
    /**
     * Transform Result<Promise<T>, Promise<E>> into Promise<Result<T, E>>
     * @returns `await this.inner`
     */
    async awaitAll() {
        return await this.await();
    }
    /**
     * Transform `Result<T, E>` into `Result<void, E>`
     * @returns `Ok<void>` if `Ok<T>`, `Err<E>` if `E<E>`
     */
    clear() {
        this.ignore();
        return ok_Ok.void();
    }
    /**
     * Transform `Result<T, E>` into `Result<T, void>`
     * @returns `Ok<T>` if `Ok<T>`, `Err<void>` if `E<E>`
     */
    clearErr() {
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Ok`
     * @param okCallback
     * @returns `this`
     */
    async inspect(okCallback) {
        await okCallback(this.inner);
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Ok`
     * @param okCallback
     * @returns `this`
     */
    inspectSync(okCallback) {
        okCallback(this.inner);
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Err`
     * @param errCallback
     * @returns `this`
     */
    async inspectErr(errCallback) {
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Err`
     * @param errCallback
     * @returns `this`
     */
    inspectErrSync(errCallback) {
        return this;
    }
    /**
     * Return a new `Ok` but with the given `inner`
     * @param inner
     * @returns `Ok(inner)` if `Ok`, `this` if `Err`
     */
    set(inner) {
        return new ok_Ok(inner);
    }
    /**
     * Return a new `Err` but with the given `inner`
     * @param inner
     * @returns `Err(inner)` if `Err`, `this` if `Ok`
     */
    setErr(inner) {
        return this;
    }
    /**
     * Map the inner value into another
     * @param okMapper
     * @returns `Ok(await okMapper(this.inner))` if `Ok`, `this` if `Err`
     * @throws if `await okMapper(this.inner)` throws
     */
    async map(okMapper) {
        this.ignore();
        return new ok_Ok(await okMapper(this.inner));
    }
    /**
     * Map the inner value into another
     * @param okMapper
     * @returns `Ok(okMapper(this.inner))` if `Ok`, `this` if `Err`
     * @throws if `okMapper(this.inner)` throws
     */
    mapSync(okMapper) {
        this.ignore();
        return new ok_Ok(okMapper(this.inner));
    }
    /**
     * Map the inner error into another
     * @param errMapper
     * @returns `Err(await errMapper(this.inner))` if `Err`, `this` if `Ok`
     * @throws if `await errMapper(this.inner)` throws
     */
    async mapErr(errMapper) {
        return this;
    }
    /**
     * Map the inner error into another
     * @param errMapper
     * @returns `Err(errMapper(this.inner))` if `Err`, `this` if `Ok`
     * @throws if `errMapper(this.inner)` throws
     */
    mapErrSync(errMapper) {
        return this;
    }
    /**
     * Map the inner value into another, or a default one
     * @param value
     * @param okMapper
     * @returns `await okMapper(this.inner)` if `Ok`, `value` if `Err`
     * @throws if `await okMapper(this.inner)` throws
     */
    async mapOr(value, okMapper) {
        this.ignore();
        return await okMapper(this.inner);
    }
    /**
     * Map the inner value into another, or a default one
     * @param value
     * @param okMapper
     * @returns `okMapper(this.inner)` if `Ok`, `value` if `Err`
     * @throws if `okMapper(this.inner)` throws
     */
    mapOrSync(value, okMapper) {
        this.ignore();
        return okMapper(this.inner);
    }
    /**
     * Map the inner value into another, or a default one
     * @param errMapper
     * @param okMapper
     * @returns `await okMapper(this.inner)` if `Ok`, `await errMapper(this.inner)` if `Err`
     * @throws if `await okMapper(this.inner)` or `await errMapper(this.inner)` throws
     */
    async mapOrElse(errMapper, okMapper) {
        this.ignore();
        return await okMapper(this.inner);
    }
    /**
     * Map the inner value into another, or a default one
     * @param errMapper
     * @param okMapper
     * @returns `okMapper(this.inner)` if `Ok`, `errMapper(this.inner)` if `Err`
     * @throws if `okMapper(this.inner)` or `errMapper(this.inner)` throws
     */
    mapOrElseSync(errMapper, okMapper) {
        this.ignore();
        return okMapper(this.inner);
    }
    /**
     * Return `value` if `Ok`, return `this` if `Err`
     * @param value
     * @returns `value` if `Ok`, `this` if `Err`
     */
    and(value) {
        this.ignore();
        return value;
    }
    /**
     * Return `await okMapper(this.inner)` if `Ok`, return `this` if `Err`
     * @param okMapper
     * @returns `await okMapper(this.inner)` if `Ok`, `this` if `Err`
     * @throws if `await okMapper(this.inner)` throws
     */
    async andThen(okMapper) {
        this.ignore();
        return await okMapper(this.inner);
    }
    /**
     * Return `okMapper(this.inner)` if `Ok`, return `this` if `Err`
     * @param okMapper
     * @returns `okMapper(this.inner)` if `Ok`, `this` if `Err`
     * @throws if `okMapper(this.inner)` throws
     */
    andThenSync(okMapper) {
        this.ignore();
        return okMapper(this.inner);
    }
    /**
     * Return `value` if `Err`, return `this` if `Ok`
     * @param value
     * @returns `value` if `Err`, `this` if `Ok`
     */
    or(value) {
        return this;
    }
    /**
     * Return `await errMapper(this.inner)` if `Err`, return `this` if `Ok`
     * @param errMapper
     * @returns `await errMapper(this.inner)` if `Err`, `this` if `Ok`
     * @throws if `await errMapper(this.inner)` throws
     */
    async orElse(errMapper) {
        return this;
    }
    /**
     * Return `errMapper(this.inner)` if `Err`, return `this` if `Ok`
     * @param errMapper
     * @returns `errMapper(this.inner)` if `Err`, `this` if `Ok`
     * @throws if `errMapper(this.inner)` throws
     */
    orElseSync(errMapper) {
        return this;
    }
    /**
     * Transform Result<Result<T, E1>, E2> into Result<T, E1 | E2>
     * @param result
     * @returns `this` if `Err`, `this.inner` if `Ok`
     */
    flatten() {
        return this.inner;
    }
}


//# sourceMappingURL=ok.mjs.map

;// CONCATENATED MODULE: ./src/libs/blobs/blobs.ts


var Blobs;
(function(Blobs) {
    async function readAsDataURL(blob) {
        const future = new Future();
        const reader = new FileReader();
        const onLoad = ()=>{
            future.resolve(reader.result);
        };
        const onError = ()=>{
            future.reject(reader.error);
        };
        try {
            reader.addEventListener("load", onLoad, {
                passive: true
            });
            reader.addEventListener("error", onError, {
                passive: true
            });
            reader.readAsDataURL(blob);
            return await future.promise;
        } finally{
            reader.removeEventListener("load", onLoad);
            reader.removeEventListener("error", onError);
        }
    }
    Blobs.readAsDataURL = readAsDataURL;
    async function tryReadAsDataURL(blob) {
        const future = new Future();
        const reader = new FileReader();
        const onLoad = ()=>{
            future.resolve(new ok_Ok(reader.result));
        };
        const onError = ()=>{
            future.resolve(new err_Err(reader.error));
        };
        try {
            reader.addEventListener("load", onLoad, {
                passive: true
            });
            reader.addEventListener("error", onError, {
                passive: true
            });
            reader.readAsDataURL(blob);
            return await future.promise;
        } finally{
            reader.removeEventListener("load", onLoad);
            reader.removeEventListener("error", onError);
        }
    }
    Blobs.tryReadAsDataURL = tryReadAsDataURL;
})(Blobs || (Blobs = {}));

;// CONCATENATED MODULE: ./node_modules/@swc/helpers/esm/_class_apply_descriptor_get.js
function _class_apply_descriptor_get(receiver, descriptor) {
    if (descriptor.get) return descriptor.get.call(receiver);

    return descriptor.value;
}


;// CONCATENATED MODULE: ./node_modules/@swc/helpers/esm/_class_extract_field_descriptor.js
function _class_extract_field_descriptor(receiver, privateMap, action) {
    if (!privateMap.has(receiver)) throw new TypeError("attempted to " + action + " private field on non-instance");

    return privateMap.get(receiver);
}


;// CONCATENATED MODULE: ./node_modules/@swc/helpers/esm/_class_private_field_get.js



function _class_private_field_get(receiver, privateMap) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "get");
    return _class_apply_descriptor_get(receiver, descriptor);
}


;// CONCATENATED MODULE: ./node_modules/@swc/helpers/esm/_check_private_redeclaration.js
function _check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}


;// CONCATENATED MODULE: ./node_modules/@swc/helpers/esm/_class_private_field_init.js


function _class_private_field_init(obj, privateMap, value) {
    _check_private_redeclaration(obj, privateMap);
    privateMap.set(obj, value);
}


;// CONCATENATED MODULE: ./node_modules/@swc/helpers/esm/_class_apply_descriptor_set.js
function _class_apply_descriptor_set(receiver, descriptor, value) {
    if (descriptor.set) descriptor.set.call(receiver, value);
    else {
        if (!descriptor.writable) {
            // This should only throw in strict mode, but class bodies are
            // always strict and private fields can only be used inside
            // class bodies.
            throw new TypeError("attempted to set read only private field");
        }
        descriptor.value = value;
    }
}


;// CONCATENATED MODULE: ./node_modules/@swc/helpers/esm/_class_private_field_set.js



function _class_private_field_set(receiver, privateMap, value) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "set");
    _class_apply_descriptor_set(receiver, descriptor, value);
    return value;
}


;// CONCATENATED MODULE: ./src/libs/browser/browser.ts



var _a;

var _globalThis_browser;
const browser = (_globalThis_browser = globalThis.browser) !== null && _globalThis_browser !== void 0 ? _globalThis_browser : globalThis.chrome;
var _class = /*#__PURE__*/ new WeakMap();
class BrowserError extends Error {
    static from(cause) {
        return new _a(undefined, {
            cause
        });
    }
    constructor(...args){
        super(...args);
        _class_private_field_init(this, _class, {
            writable: true,
            value: void 0
        });
        _class_private_field_set(this, _class, _a);
        this.name = _class_private_field_get(this, _class).name;
    }
}
_a = BrowserError;
async function tryBrowser(callback) {
    try {
        const result = await callback();
        if (browser.runtime.lastError) return new err_Err(new BrowserError());
        return new ok_Ok(result);
    } catch (e) {
        return new err_Err(new BrowserError());
    }
}
function tryBrowserSync(callback) {
    try {
        const result = callback();
        const error = browser.runtime.lastError;
        if (error) return new err_Err(BrowserError.from(error));
        return new ok_Ok(result);
    } catch (e) {
        return new err_Err(BrowserError.from(e));
    }
}

;// CONCATENATED MODULE: ./node_modules/@hazae41/cleaner/dist/esm/libs/unpromise/unpromise.mjs
var Unpromise;
(function (Unpromise) {
    /**
     * Like Promise.all but sync
     * @param callbacks
     * @returns
     */
    function all(callbacks) {
        const results = new Array();
        let error = undefined;
        for (const callback of callbacks) {
            try {
                results.push(callback());
            }
            catch (e) {
                error = { e };
            }
        }
        if (error)
            throw error.e;
        return results;
    }
    Unpromise.all = all;
})(Unpromise || (Unpromise = {}));


//# sourceMappingURL=unpromise.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/cleaner/dist/esm/mods/dispose/dispose.mjs


class Disposer {
    inner;
    dispose;
    constructor(inner, dispose) {
        this.inner = inner;
        this.dispose = dispose;
    }
    static from(disposable) {
        return new Disposer(disposable, () => disposable[Symbol.dispose]());
    }
    [Symbol.dispose]() {
        this.dispose();
    }
}
class AsyncDisposer {
    inner;
    asyncDispose;
    constructor(inner, asyncDispose) {
        this.inner = inner;
        this.asyncDispose = asyncDispose;
    }
    static from(disposable) {
        return new AsyncDisposer(disposable, () => disposable[Symbol.asyncDispose]());
    }
    async [Symbol.asyncDispose]() {
        await this.asyncDispose();
    }
}
class PromiseDisposer {
    inner;
    dispose;
    constructor(inner, dispose) {
        this.inner = inner;
        this.dispose = dispose;
    }
    static from(disposable) {
        return new PromiseDisposer(disposable, () => disposable[Symbol.dispose]());
    }
    then(onfulfilled, onrejected) {
        return this.inner.then(onfulfilled, onrejected);
    }
    [Symbol.dispose]() {
        this.dispose();
    }
}
class AsyncPromiseDisposer {
    inner;
    asyncDispose;
    constructor(inner, asyncDispose) {
        this.inner = inner;
        this.asyncDispose = asyncDispose;
    }
    static from(disposable) {
        return new PromiseDisposer(disposable, () => disposable[Symbol.asyncDispose]());
    }
    then(onfulfilled, onrejected) {
        return this.inner.then(onfulfilled, onrejected);
    }
    async [Symbol.asyncDispose]() {
        await this.asyncDispose();
    }
}
var Disposable;
(function (Disposable) {
    async function dispose(disposable) {
        if (Symbol.dispose in disposable)
            disposable[Symbol.dispose]();
        else if (Symbol.asyncDispose)
            await disposable[Symbol.asyncDispose]();
    }
    Disposable.dispose = dispose;
    function disposeSync(disposable) {
        disposable[Symbol.dispose]();
    }
    Disposable.disposeSync = disposeSync;
    async function race(promises) {
        try {
            return await Promise.race(promises);
        }
        finally {
            await Promise.all(promises.map(dispose));
        }
    }
    Disposable.race = race;
    async function raceSync(promises) {
        try {
            return await Promise.race(promises);
        }
        finally {
            Unpromise.all(promises.map(it => () => disposeSync(it)));
        }
    }
    Disposable.raceSync = raceSync;
})(Disposable || (Disposable = {}));


//# sourceMappingURL=dispose.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/plume/dist/esm/mods/errors.mjs





class AbortedError extends Error {
    #class = AbortedError;
    name = this.#class.name;
    static from(cause) {
        return new AbortedError(`Aborted`, { cause });
    }
    static wait(signal) {
        const future = new Future();
        const onAbort = (event) => {
            future.resolve(new err_Err(AbortedError.from(event)));
        };
        signal.addEventListener("abort", onAbort, { passive: true });
        const off = () => signal.removeEventListener("abort", onAbort);
        return new PromiseDisposer(future.promise, off);
    }
}
class ErroredError extends Error {
    #class = ErroredError;
    name = this.#class.name;
    static from(cause) {
        return new ErroredError(`Errored`, { cause });
    }
    static wait(target) {
        return target.wait("error", (future, event) => {
            const error = ErroredError.from(event);
            future.resolve(new err_Err(error));
            return new None();
        });
    }
}
class ClosedError extends Error {
    #class = ClosedError;
    name = this.#class.name;
    static from(cause) {
        return new ClosedError(`Closed`, { cause });
    }
    static wait(target) {
        return target.wait("close", (future, event) => {
            const error = ClosedError.from(event);
            future.resolve(new err_Err(error));
            return new None();
        });
    }
}


//# sourceMappingURL=errors.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/plume/dist/esm/mods/waiters.mjs



async function tryWaitOrSignal(target, type, callback, signal) {
    const abort = AbortedError.wait(signal);
    const event = target.wait(type, callback);
    return await Disposable.raceSync([abort, event]);
}
async function tryWaitOrCloseOrError(target, type, callback) {
    const error = ErroredError.wait(target);
    const close = ClosedError.wait(target);
    const event = target.wait(type, callback);
    return await Disposable.raceSync([error, close, event]);
}
async function tryWaitOrCloseOrErrorOrSignal(target, type, callback, signal) {
    const abort = AbortedError.wait(signal);
    const error = ErroredError.wait(target);
    const close = ClosedError.wait(target);
    const event = target.wait(type, callback);
    return await Disposable.raceSync([abort, error, close, event]);
}


//# sourceMappingURL=waiters.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/plume/dist/esm/mods/target.mjs




class EventError extends (/* unused pure expression or super */ null && (Error)) {
    #class = EventError;
    name = this.#class.name;
    constructor(cause) {
        super(`Event failed`, { cause });
    }
    static new(cause) {
        return new EventError(cause);
    }
}
class SuperEventTarget {
    #listeners = new Map();
    get listeners() {
        return this.#listeners;
    }
    /**
     * Add a listener to an event
     * @param type Event type //  "abort", "error", "message", "close"
     * @param listener Event listener // (e) => new Some(123)
     * @param options Options // { passive: true }
     * @returns
     */
    on(type, listener, options = {}) {
        let listeners = this.#listeners.get(type);
        if (listeners === undefined) {
            listeners = new Map();
            this.#listeners.set(type, listeners);
        }
        const off = () => this.off(type, listener);
        const internalOptions = { ...options, off };
        internalOptions.signal?.addEventListener("abort", off, { passive: true });
        listeners.set(listener, internalOptions);
        return off;
    }
    /**
     * Remove a listener from an event
     * @param type Event type //  "abort", "error", "message", "close"
     * @param listener Event listener // (e) => console.log("hello")
     * @param options Just to look like DOM's EventTarget
     * @returns
     */
    off(type, listener) {
        const listeners = this.#listeners.get(type);
        if (!listeners)
            return;
        const options = listeners.get(listener);
        if (!options)
            return;
        options.signal?.removeEventListener("abort", options.off);
        listeners.delete(listener);
        if (listeners.size > 0)
            return;
        this.#listeners.delete(type);
    }
    /**
     * Dispatch an event to its listeners
     *
     * - Dispatch to active listeners sequencially
     * - Return if one of the listeners returned something
     * - Dispatch to passive listeners concurrently
     * - Return if one of the listeners returned something
     * - Return nothing
     * @param value The object to emit
     * @returns `Some` if the event
     */
    async emit(type, value) {
        const listeners = this.#listeners.get(type);
        if (!listeners)
            return new None();
        const promises = new Array();
        for (const [listener, options] of listeners) {
            if (options.passive)
                continue;
            if (options.once)
                this.off(type, listener);
            const returned = await listener(...value);
            if (returned.isNone())
                continue;
            return returned;
        }
        for (const [listener, options] of listeners) {
            if (!options.passive)
                continue;
            if (options.once)
                this.off(type, listener);
            const returned = listener(...value);
            if (returned instanceof Promise) {
                promises.push(returned);
                continue;
            }
            if (returned.isNone())
                continue;
            return returned;
        }
        const returneds = await Promise.all(promises);
        for (const returned of returneds)
            if (returned.isSome())
                return returned;
        return new None();
    }
    /**
     * Like `.on`, but instead of returning to the target, capture the returned value in a future, and return nothing to the target
     * @param type
     * @param callback
     * @returns
     */
    wait(type, callback) {
        const future = new Future();
        const onEvent = async (...params) => {
            try {
                return await callback(future, ...params);
            }
            catch (e) {
                future.reject(e);
                throw e;
            }
        };
        const off = this.on(type, onEvent, { passive: true });
        return new PromiseDisposer(future.promise, off);
    }
}


//# sourceMappingURL=target.mjs.map

;// CONCATENATED MODULE: ./src/libs/rpc/ok.ts

var RpcOkInit;
(function(RpcOkInit) {
    function from(response) {
        const { jsonrpc, id, result } = response;
        return {
            jsonrpc,
            id,
            result
        };
    }
    RpcOkInit.from = from;
})(RpcOkInit || (RpcOkInit = {}));
class RpcOk extends ok_Ok {
    static from(init) {
        return new RpcOk(init.id, init.result);
    }
    constructor(id, result){
        super(result);
        this.jsonrpc = "2.0";
        this.id = id;
        this.result = result;
    }
}

;// CONCATENATED MODULE: ./src/libs/rpc/err.ts

class RpcError extends Error {
    static from(error) {
        return new RpcError(error.message);
    }
    /**
     * Used by JSON.stringify
     */ toJSON() {
        const { message } = this;
        return {
            message
        };
    }
}
class RpcErr extends err_Err {
    static from(init) {
        return new RpcErr(init.id, new RpcError(init.error.message));
    }
    constructor(id, error){
        super(error);
        this.jsonrpc = "2.0";
        this.id = id;
        this.error = error;
    }
}

;// CONCATENATED MODULE: ./src/libs/rpc/response.ts


var RpcResponse;
(function(RpcResponse) {
    function from(init) {
        if ("error" in init) return RpcErr.from(init);
        return RpcOk.from(init);
    }
    RpcResponse.from = from;
    function rewrap(id, result) {
        result.ignore();
        if (result.isOk()) return new RpcOk(id, result.inner);
        if (result.inner instanceof Error) return new RpcErr(id, RpcError.from(result.inner));
        return new RpcErr(id, new RpcError());
    }
    RpcResponse.rewrap = rewrap;
})(RpcResponse || (RpcResponse = {}));

;// CONCATENATED MODULE: ./node_modules/@hazae41/bytes/dist/esm/libs/ascii/ascii.mjs
var Ascii;
(function (Ascii) {
    Ascii.encoder = new TextEncoder();
    Ascii.decoder = new TextDecoder("ascii");
})(Ascii || (Ascii = {}));


//# sourceMappingURL=ascii.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/bytes/dist/esm/libs/buffers/buffers.mjs
/* provided dependency */ var Buffer = __webpack_require__(764)["lW"];
var Buffers;
(function (Buffers) {
    function fromView(view) {
        return Buffer.from(view.buffer, view.byteOffset, view.byteLength);
    }
    Buffers.fromView = fromView;
})(Buffers || (Buffers = {}));


//# sourceMappingURL=buffers.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/bytes/dist/esm/libs/utf8/utf8.mjs
var Utf8;
(function (Utf8) {
    Utf8.encoder = new TextEncoder();
    Utf8.decoder = new TextDecoder();
})(Utf8 || (Utf8 = {}));


//# sourceMappingURL=utf8.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/bytes/dist/esm/mods/bytes/bytes.mjs
/* provided dependency */ var bytes_Buffer = __webpack_require__(764)["lW"];





class BytesFromError extends Error {
    #class = BytesFromError;
    name = this.#class.name;
    constructor() {
        super(`Could not convert to bytes`);
    }
}
class BytesAllocError extends Error {
    length;
    #class = BytesAllocError;
    name = this.#class.name;
    constructor(length) {
        super(`Could not allocate ${length}-sized bytes`);
        this.length = length;
    }
}
class BytesCastError extends Error {
    actualLength;
    expectedLength;
    #class = BytesCastError;
    name = this.#class.name;
    constructor(actualLength, expectedLength) {
        super(`Could not cast ${actualLength} bytes into ${expectedLength}-sized bytes`);
        this.actualLength = actualLength;
        this.expectedLength = expectedLength;
    }
}
var Bytes;
(function (Bytes) {
    /**
     * Alloc 0-lengthed Bytes using standard constructor
     * @deprecated
     * @returns `Bytes[]`
     */
    function empty() {
        return alloc(0);
    }
    Bytes.empty = empty;
    /**
     * Alloc 0-lengthed Bytes using standard constructor
     * @returns `Bytes[]`
     */
    function tryEmpty() {
        return tryAlloc(0);
    }
    Bytes.tryEmpty = tryEmpty;
    /**
     * Alloc Bytes with typed length using standard constructor
     * @deprecated
     * @param length
     * @returns `Bytes[0;N]`
     */
    function alloc(length) {
        return new Uint8Array(length);
    }
    Bytes.alloc = alloc;
    /**
     * Alloc Bytes with typed length using standard constructor
     * @param length
     * @returns `Bytes[0;N]`
     */
    function tryAlloc(length) {
        try {
            return new ok_Ok(new Uint8Array(length));
        }
        catch (e) {
            return new err_Err(new BytesAllocError(length));
        }
    }
    Bytes.tryAlloc = tryAlloc;
    /**
     * Alloc Bytes with typed length (using Buffer.allocUnsafe on Node, Uint8Array on others)
     * @deprecated
     * @param length
     * @returns `Bytes[number;N]`
     */
    function allocUnsafe(length) {
        if ("process" in globalThis)
            return fromView(bytes_Buffer.allocUnsafe(length));
        return new Uint8Array(length);
    }
    Bytes.allocUnsafe = allocUnsafe;
    /**
     * Alloc Bytes with typed length (using Buffer.allocUnsafe on Node, Uint8Array on others)
     * @param length
     * @returns `Bytes[number;N]`
     */
    function tryAllocUnsafe(length) {
        try {
            if ("process" in globalThis)
                return new ok_Ok(fromView(bytes_Buffer.allocUnsafe(length)));
            return new ok_Ok(new Uint8Array(length));
        }
        catch (e) {
            return new err_Err(new BytesAllocError(length));
        }
    }
    Bytes.tryAllocUnsafe = tryAllocUnsafe;
    /**
     * Create bytes from array
     * @deprecated
     * @param array
     * @returns `Bytes[number;N]`
     */
    function from(array) {
        return new Uint8Array(array);
    }
    Bytes.from = from;
    /**
     * Create bytes from array
     * @param array
     * @returns `Bytes[number;N]`
     */
    function tryFrom(array) {
        try {
            return new ok_Ok(new Uint8Array(array));
        }
        catch (e) {
            return new err_Err(new BytesFromError());
        }
    }
    Bytes.tryFrom = tryFrom;
    /**
     * Create bytes from sized of length N
     * @deprecated
     * @param sized
     * @returns `Bytes[number;N]`
     */
    function fromSized(sized) {
        return new Uint8Array(sized);
    }
    Bytes.fromSized = fromSized;
    /**
     * Create bytes from sized of length N
     * @param sized
     * @returns `Bytes[number;N]`
     */
    function tryFromSized(sized) {
        try {
            return new ok_Ok(new Uint8Array(sized));
        }
        catch (e) {
            return new err_Err(new BytesAllocError(sized.length));
        }
    }
    Bytes.tryFromSized = tryFromSized;
    /**
     * Alloc Bytes with typed length (using Bytes.allocUnsafe) and fill it with WebCrypto's CSPRNG
     * @deprecated
     * @param length
     * @returns `Bytes[number;N]`
     */
    function random(length) {
        const bytes = allocUnsafe(length);
        crypto.getRandomValues(bytes);
        return bytes;
    }
    Bytes.random = random;
    /**
     * Alloc Bytes with typed length (using Bytes.allocUnsafe) and fill it with WebCrypto's CSPRNG
     * @param length
     * @returns `Bytes[number;N]`
     */
    function tryRandom(length) {
        const result = tryAllocUnsafe(length);
        result.inspectSync(bytes => crypto.getRandomValues(bytes));
        return result;
    }
    Bytes.tryRandom = tryRandom;
    /**
     * Type guard bytes of N length into Bytes<N>
     * @param bytes
     * @param length
     * @returns
     */
    function is(bytes, length) {
        return bytes.length.valueOf() === length.valueOf();
    }
    Bytes.is = is;
    /**
     * Equality check (using indexedDB.cmp on browsers, Buffer.equals on Node)
     * @param a
     * @param b
     * @returns
     */
    function equals(a, b) {
        if ("indexedDB" in globalThis)
            return indexedDB.cmp(a, b) === 0;
        if ("process" in globalThis)
            return Buffers.fromView(a).equals(Buffers.fromView(b));
        throw new Panic(`Can't compare bytes`);
    }
    Bytes.equals = equals;
    /**
     * Equality check (using indexedDB.cmp on browsers, Buffer.equals on Node)
     * @param a
     * @param b
     * @returns
     */
    function equals2(a, b) {
        if ("indexedDB" in globalThis)
            return indexedDB.cmp(a, b) === 0;
        if ("process" in globalThis)
            return Buffers.fromView(a).equals(Buffers.fromView(b));
        throw new Panic(`Can't compare bytes`);
    }
    Bytes.equals2 = equals2;
    /**
     * Try to cast bytes of N length into Bytes<N>
     * @param view
     * @param length
     * @returns
     */
    function tryCast(bytes, length) {
        if (is(bytes, length))
            return new ok_Ok(bytes);
        return new err_Err(new BytesCastError(bytes.length, length));
    }
    Bytes.tryCast = tryCast;
    /**
     * Try to cast bytes of N length into Bytes<N>
     * @param view
     * @param length
     * @returns
     */
    function tryCastFrom(array, length) {
        return tryCast(new Uint8Array(array), length);
    }
    Bytes.tryCastFrom = tryCastFrom;
    /**
     * Zero-copy conversion from ArrayBufferView of N length into Bytes<N>
     * @param view
     * @param length
     * @returns
     */
    function tryCastFromView(view, length) {
        return tryCast(fromView(view), length);
    }
    Bytes.tryCastFromView = tryCastFromView;
    /**
     * Zero-copy conversion from ArrayBufferView into unknown-sized Bytes
     * @param view
     * @returns
     */
    function fromView(view) {
        return new Uint8Array(view.buffer, view.byteOffset, view.byteLength);
    }
    Bytes.fromView = fromView;
    /**
     * Utf8 encoding using TextEncoder
     * @param text
     * @returns
     */
    function fromUtf8(text) {
        return Utf8.encoder.encode(text);
    }
    Bytes.fromUtf8 = fromUtf8;
    /**
     * Utf8 decoding using TextDecoder
     * @param text
     * @returns
     */
    function toUtf8(bytes) {
        return Utf8.decoder.decode(bytes);
    }
    Bytes.toUtf8 = toUtf8;
    /**
     * Ascii decoding (using Buffer.from on Node, TextEncoder on others)
     * @param bytes
     * @returns
     */
    function fromAscii(text) {
        if ("process" in globalThis)
            return fromView(bytes_Buffer.from(text, "ascii"));
        return Ascii.encoder.encode(text);
    }
    Bytes.fromAscii = fromAscii;
    /**
     * Ascii encoding (using Buffer.toString on Node, TextDecoder on others)
     * @param bytes
     * @returns
     */
    function toAscii(bytes) {
        if ("process" in globalThis)
            return Buffers.fromView(bytes).toString("ascii");
        return Ascii.decoder.decode(bytes);
    }
    Bytes.toAscii = toAscii;
    /**
     * Slice or pad bytes to exact length by filling 0s at the start
     * @deprecated
     * @example sliceOrPadStart([1,2,3,4], 2) = [3,4]
     * @example sliceOrPadStart([1,2,3,4], 6) = [0,0,1,2,3,4]
     * @param bytes
     * @param length
     * @returns
     */
    function sliceOrPadStart(bytes, length) {
        if (bytes.length >= length) {
            const slice = bytes.slice(bytes.length - length, bytes.length);
            return fromView(slice);
        }
        const array = alloc(length);
        array.set(bytes, length - bytes.length);
        return array;
    }
    Bytes.sliceOrPadStart = sliceOrPadStart;
    /**
     * Slice or pad bytes to exact length by filling 0s at the start
     * @example sliceOrPadStart([1,2,3,4], 2) = [3,4]
     * @example sliceOrPadStart([1,2,3,4], 6) = [0,0,1,2,3,4]
     * @param bytes
     * @param length
     * @returns
     */
    function trySliceOrPadStart(bytes, length) {
        if (bytes.length >= length) {
            const slice = bytes.slice(bytes.length - length, bytes.length);
            return new ok_Ok(fromView(slice));
        }
        const result = tryAlloc(length);
        result.inspectSync(a => a.set(bytes, length - bytes.length));
        return result;
    }
    Bytes.trySliceOrPadStart = trySliceOrPadStart;
    /**
     * Pad bytes to minimum length by filling 0s at the start
     * @deprecated
     * @example padStart([1,2,3,4], 2) = [1,2,3,4]
     * @example padStart([1,2,3,4], 6) = [0,0,1,2,3,4]
     * @param bytes
     * @param length
     * @returns
     */
    function padStart(bytes, length) {
        if (bytes.length >= length)
            return bytes;
        const array = alloc(length);
        array.set(bytes, length - bytes.length);
        return array;
    }
    Bytes.padStart = padStart;
    /**
     * Pad bytes to minimum length by filling 0s at the start
     * @example padStart([1,2,3,4], 2) = [1,2,3,4]
     * @example padStart([1,2,3,4], 6) = [0,0,1,2,3,4]
     * @param bytes
     * @param length
     * @returns
     */
    function tryPadStart(bytes, length) {
        if (bytes.length >= length)
            return new ok_Ok(bytes);
        const result = tryAlloc(length).inspectSync(r => r.set(bytes, length - bytes.length));
        result.inspectSync(a => a.set(bytes, length - bytes.length));
        return result;
    }
    Bytes.tryPadStart = tryPadStart;
    /**
     * Concatenation (using Buffer.concat on Node, home-made on others)
     * @param list
     * @returns
     */
    function concat(list) {
        if ("process" in globalThis)
            return fromView(bytes_Buffer.concat(list));
        const length = list.reduce((p, c) => p + c.length, 0);
        const result = allocUnsafe(length);
        let offset = 0;
        for (const bytes of list) {
            result.set(bytes, offset);
            offset += bytes.length;
        }
        return result;
    }
    Bytes.concat = concat;
})(Bytes || (Bytes = {}));


//# sourceMappingURL=bytes.mjs.map

;// CONCATENATED MODULE: ./src/libs/rpc/request.ts
class RpcRequest {
    static from(init) {
        const { id, method, params } = init;
        return new RpcRequest(id, method, params);
    }
    toJSON() {
        const { jsonrpc, id, method, params } = this;
        return {
            jsonrpc,
            id,
            method,
            params
        };
    }
    constructor(id, method, params){
        this.jsonrpc = "2.0";
        this.id = id;
        this.method = method;
        this.params = params;
    }
}

;// CONCATENATED MODULE: ./src/libs/rpc/rpc.ts






class RpcClient {
    prepare(init) {
        return new RpcRequest(this.id++, init.method, init.params);
    }
    constructor(){
        this.id = 0;
    }
}
var TorRpc;
(function(TorRpc) {
    async function tryFetchWithCircuit(input, init) {
        const { id, method, params, circuit, ...rest } = init;
        const request = new RpcRequest(id, method, params);
        const body = Bytes.fromUtf8(JSON.stringify(request));
        const headers = new Headers(rest.headers);
        headers.set("Content-Type", "application/json");
        headers.set("Content-Length", "".concat(body.length));
        const res = await circuit.tryFetch(input, {
            ...rest,
            method: "POST",
            headers,
            body
        });
        if (!res.isOk()) return res;
        if (!res.inner.ok) return new err_Err(new Error(await res.inner.text()));
        const response = RpcResponse.from(await res.inner.json());
        if (response.id !== request.id) console.warn("Invalid response ID", response.id, "expected", request.id);
        return new ok_Ok(response);
    }
    TorRpc.tryFetchWithCircuit = tryFetchWithCircuit;
    async function tryFetchWithSocket(socket, request, signal) {
        const { id, method, params = [] } = request;
        socket.send(JSON.stringify(new RpcRequest(id, method, params)));
        const future = new Future();
        const onMessage = async (event)=>{
            if (typeof event.data !== "string") return;
            const response = RpcResponse.from(JSON.parse(event.data));
            if (response.id !== request.id) return;
            future.resolve(new ok_Ok(response));
        };
        const onError = (e)=>{
            future.resolve(new err_Err(ErroredError.from(e)));
        };
        const onClose = (e)=>{
            future.resolve(new err_Err(ClosedError.from(e)));
        };
        const onAbort = ()=>{
            future.resolve(new err_Err(AbortedError.from(signal.reason)));
        };
        try {
            socket.addEventListener("message", onMessage, {
                passive: true
            });
            socket.addEventListener("close", onClose, {
                passive: true
            });
            socket.addEventListener("error", onError, {
                passive: true
            });
            signal.addEventListener("abort", onAbort, {
                passive: true
            });
            return await future.promise;
        } finally{
            socket.removeEventListener("message", onMessage);
            socket.removeEventListener("close", onClose);
            socket.removeEventListener("error", onError);
            signal.removeEventListener("abort", onAbort);
        }
    }
    TorRpc.tryFetchWithSocket = tryFetchWithSocket;
})(TorRpc || (TorRpc = {}));

;// CONCATENATED MODULE: ./src/libs/rpc/index.ts






;// CONCATENATED MODULE: ./src/libs/channel/channel.ts





class WebsitePort {
    [Symbol.dispose]() {
        this.clean();
    }
    async runPingLoop() {
        let count = 0;
        while(true){
            await new Promise((ok)=>setTimeout(ok, 1000));
            const result = await this.tryPingOrSignal(AbortSignal.timeout(1000)).then((r)=>r.flatten());
            if (result.isErr()) count++;
            else count = 0;
            if (count === 2) {
                await this.events.emit("close", [
                    undefined
                ]);
                return;
            }
        }
    }
    async tryRouteRequest(request) {
        if (request.method === "brume_ping") return ok_Ok.void();
        const returned = await this.events.emit("request", [
            request
        ]);
        if (returned.isSome()) return returned.inner;
        return new err_Err(new Error("Unhandled JSON-RPC request ".concat(JSON.stringify(request))));
    }
    async onRequest(request) {
        // if (request.id !== "ping")
        //   console.debug(this.name, "->", request)
        const result = await this.tryRouteRequest(request);
        const response = RpcResponse.rewrap(request.id, result);
        // if (request.id !== "ping")
        //   console.debug(this.name, "<-", response)
        this.port.postMessage(JSON.stringify(response));
    }
    async onResponse(response) {
        // if (response.id !== "ping")
        //   console.debug(this.name, "<-", response)
        const returned = await this.events.emit("response", [
            response
        ]);
        if (returned.isSome()) return returned.inner;
        return new err_Err(new Error("Unhandled JSON-RPC response ".concat(JSON.stringify(response))));
    }
    async onMessage(message) {
        const data = JSON.parse(message.data);
        if ("method" in data) return await this.onRequest(data);
        return await this.onResponse(data);
    }
    async tryRequest(init) {
        const request = this.client.prepare(init);
        this.port.postMessage(JSON.stringify(request));
        return tryWaitOrCloseOrError(this.events, "response", (future, init)=>{
            if (init.id !== request.id) return new None();
            const response = RpcResponse.from(init);
            future.resolve(new ok_Ok(response));
            return new Some(undefined);
        });
    }
    async tryPingOrSignal(signal) {
        const request = {
            id: "ping",
            method: "brume_ping"
        };
        this.port.postMessage(JSON.stringify(request));
        return tryWaitOrCloseOrErrorOrSignal(this.events, "response", (future, init)=>{
            if (init.id !== request.id) return new None();
            const response = RpcResponse.from(init);
            future.resolve(new ok_Ok(response));
            return new Some(undefined);
        }, signal);
    }
    constructor(name, port){
        this.client = new RpcClient();
        this.uuid = crypto.randomUUID();
        this.events = new SuperEventTarget();
        this.name = name;
        this.port = port;
        const onMessage = this.onMessage.bind(this);
        this.port.addEventListener("message", onMessage, {
            passive: true
        });
        this.clean = ()=>{
            this.port.removeEventListener("message", onMessage);
        };
    }
}
class ExtensionPort {
    [Symbol.dispose]() {
        this.clean();
    }
    async tryRouteRequest(request) {
        if (request.method === "brume_ping") return ok_Ok.void();
        const returned = await this.events.emit("request", [
            request
        ]);
        if (returned.isSome()) return returned.inner;
        return new err_Err(new Error("Unhandled JSON-RPC request ".concat(JSON.stringify(request))));
    }
    async onRequest(request) {
        if (request.id !== "ping") console.debug(this.name, "->", request);
        const result = await this.tryRouteRequest(request);
        const response = RpcResponse.rewrap(request.id, result);
        if (request.id !== "ping") console.debug(this.name, "<-", response);
        tryBrowserSync(()=>{
            this.port.postMessage(JSON.stringify(response));
        }).ignore();
    }
    async onResponse(response) {
        if (response.id !== "ping") console.debug(this.name, "<-", response);
        const returned = await this.events.emit("response", [
            response
        ]);
        if (returned.isSome()) return returned.inner;
        return new err_Err(new Error("Unhandled JSON-RPC response ".concat(JSON.stringify(response))));
    }
    async onMessage(message) {
        const data = JSON.parse(message);
        if ("method" in data) return await this.onRequest(data);
        return await this.onResponse(data);
    }
    async onDisconnect() {
        await this.events.emit("close", [
            undefined
        ]);
    }
    async tryRequest(init) {
        return await Result.unthrow(async (t)=>{
            const request = this.client.prepare(init);
            tryBrowserSync(()=>{
                this.port.postMessage(JSON.stringify(request));
            }).throw(t);
            return tryWaitOrCloseOrError(this.events, "response", (future, init)=>{
                if (init.id !== request.id) return new None();
                const response = RpcResponse.from(init);
                future.resolve(new ok_Ok(response));
                return new Some(undefined);
            });
        });
    }
    constructor(name, port){
        this.client = new RpcClient();
        this.uuid = crypto.randomUUID();
        this.events = new SuperEventTarget();
        this.name = name;
        this.port = port;
        const onMessage = this.onMessage.bind(this);
        const onDisconnect = this.onDisconnect.bind(this);
        this.port.onMessage.addListener(onMessage);
        this.port.onDisconnect.addListener(onDisconnect);
        this.clean = ()=>{
            this.port.onMessage.removeListener(onMessage);
            this.port.onDisconnect.removeListener(onDisconnect);
        };
    }
}

;// CONCATENATED MODULE: ./src/libs/fetch/fetch.ts

async function tryFetch(input, init) {
    try {
        const res = await fetch(input, init);
        if (!res.ok) return new Err(new Error(await res.text()));
        return new Ok(res);
    } catch (e) {
        return new Err(Catched.from(e));
    }
}
async function tryFetchAsJson(input, init) {
    try {
        const res = await fetch(input, init);
        if (!res.ok) return new err_Err(new Error(await res.text()));
        return new ok_Ok(await res.json());
    } catch (e) {
        return new err_Err(errors_Catched.from(e));
    }
}
async function tryFetchAsBlob(input, init) {
    try {
        const res = await fetch(input, init);
        if (!res.ok) return new err_Err(new Error(await res.text()));
        return new ok_Ok(await res.blob());
    } catch (e) {
        return new err_Err(errors_Catched.from(e));
    }
}

;// CONCATENATED MODULE: ./node_modules/@hazae41/arrays/dist/esm/mods/arrays/arrays.mjs
/**
 * Get the last value
 * @param array
 * @returns
 */
function last(array) {
    if (array.length === 0)
        return undefined;
    return array[lastIndex(array)];
}
/**
 * Get the last index
 * @param array
 * @returns
 */
function lastIndex(array) {
    return array.length - 1;
}
/**
 * Get a random value using Math's PRNG
 * @param array
 * @returns
 */
function random(array) {
    if (array.length === 0)
        return undefined;
    return array[randomIndex(array)];
}
/**
 * Get a random index using Math's PRNG
 * @param array
 * @returns
 */
function randomIndex(array) {
    return Math.floor(Math.random() * array.length);
}
/**
 * Get a random value using WebCrypto's CSPRNG
 * @param array
 * @returns
 */
function cryptoRandom(array) {
    if (array.length === 0)
        return undefined;
    return array[cryptoRandomIndex(array)];
}
/**
 * Get a random value using WebCrypto's CSPRNG
 * @param array
 * @returns
 */
function cryptoRandomIndex(array) {
    const values = new Uint32Array(1);
    crypto.getRandomValues(values);
    return values[0] % array.length;
}
/**
 * Get a random value using Math's PRNG and delete it from the array
 * @param array
 * @returns
 */
function takeRandom(array) {
    if (array.length === 0)
        return undefined;
    const index = randomIndex(array);
    const element = array[index];
    array.splice(index, 1);
    return element;
}
/**
 * Get a random value using WebCrypto's CSPRNG and delete it from the array
 * @param array
 * @returns
 */
function takeCryptoRandom(array) {
    if (array.length === 0)
        return undefined;
    const index = cryptoRandomIndex(array);
    const element = array[index];
    array.splice(index, 1);
    return element;
}


//# sourceMappingURL=arrays.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/mutex/dist/esm/mods/mutex/mutex.mjs



class MutexLockError extends Error {
    #class = MutexLockError;
    name = this.#class.name;
    constructor() {
        super(`Could not lock mutex`);
    }
}
class Mutex {
    inner;
    promise;
    /**
     * Just a mutex
     */
    constructor(inner) {
        this.inner = inner;
    }
    get locked() {
        return Boolean(this.promise);
    }
    acquire() {
        const future = new Future();
        const promise = this.promise;
        this.lock(() => future.promise);
        const release = () => future.resolve();
        const access = new Lock(this.inner, release);
        return promise
            ? promise.then(() => access)
            : access;
    }
    /**
     * Lock this mutex
     * @param callback
     * @returns
     */
    lock(callback) {
        const promise = this.promise
            ? this.promise.then(() => callback(this.inner))
            : callback(this.inner);
        this.promise = promise
            .then(() => { })
            .catch(() => { })
            .finally(() => this.promise = undefined);
        return promise;
    }
    /**
     * Try to lock this mutex
     * @param callback
     * @returns
     */
    tryLock(callback) {
        if (this.promise)
            return new err_Err(new MutexLockError());
        const promise = callback(this.inner);
        this.promise = promise
            .then(() => { })
            .catch(() => { })
            .finally(() => this.promise = undefined);
        return new ok_Ok(promise);
    }
}
class Lock {
    inner;
    release;
    constructor(inner, release) {
        this.inner = inner;
        this.release = release;
    }
    [Symbol.dispose]() {
        this.release();
    }
}


//# sourceMappingURL=mutex.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/piscine/dist/esm/libs/signals/signals.mjs
var AbortSignals;
(function (AbortSignals) {
    function never() {
        return new AbortController().signal;
    }
    AbortSignals.never = never;
    function timeout(delay, parent) {
        return merge(AbortSignal.timeout(delay), parent);
    }
    AbortSignals.timeout = timeout;
    function merge(a, b) {
        if (b === undefined)
            return a;
        const c = new AbortController();
        const onAbort = (reason) => {
            c.abort(reason);
            a.removeEventListener("abort", onAbort);
            b.removeEventListener("abort", onAbort);
        };
        a.addEventListener("abort", onAbort, { passive: true });
        b.addEventListener("abort", onAbort, { passive: true });
        return c.signal;
    }
    AbortSignals.merge = merge;
})(AbortSignals || (AbortSignals = {}));


//# sourceMappingURL=signals.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/piscine/dist/esm/mods/pool/pool.mjs








var PoolOkEntry;
(function (PoolOkEntry) {
    function is(x) {
        return x.result.isOk();
    }
    PoolOkEntry.is = is;
})(PoolOkEntry || (PoolOkEntry = {}));
class EmptyPoolError extends Error {
    #class = EmptyPoolError;
    name = this.#class.name;
    constructor() {
        super(`Empty pool`);
    }
}
class EmptySlotError extends Error {
    #class = EmptySlotError;
    name = this.#class.name;
    constructor() {
        super(`Empty pool slot`);
    }
}
class Pool {
    creator;
    params;
    #capacity;
    events = new SuperEventTarget();
    signal;
    #controller;
    mutex = new Mutex(undefined);
    /**
     * Entry by index, can be sparse
     */
    #allEntries;
    /**
     * Promise by index, can be sparse
     */
    #allPromises;
    /**
     * Entries that are ok
     */
    #okEntries = new Set();
    /**
     * Promises that are started (running or settled)
     */
    #okPromises = new Set();
    /**
     * A pool of circuits
     * @param tor
     * @param params
     */
    constructor(creator, params = {}) {
        this.creator = creator;
        this.params = params;
        const { capacity = 3 } = params;
        this.#capacity = capacity;
        this.#controller = new AbortController();
        this.signal = AbortSignals.merge(this.#controller.signal, params.signal);
        this.#allEntries = new Array(capacity);
        this.#allPromises = new Array(capacity);
        for (let index = 0; index < capacity; index++)
            this.#start(index).catch(console.warn);
    }
    /**
     * Whether all entries are errored
     */
    get stagnant() {
        return this.#allEntries.every(entry => entry.result.isErr());
    }
    abort(reason) {
        this.#controller.abort(reason);
    }
    async #start(index) {
        const promise = this.#createAndUnwrap(index);
        this.#allPromises[index] = promise;
        this.#okPromises.add(promise);
        /**
         * Set promise as handled
         */
        promise.catch(() => { });
        await this.events.emit("started", [index]);
    }
    async #tryCreate(index) {
        const { signal } = this;
        if (signal.aborted)
            return new err_Err(AbortedError.from(signal.reason));
        return await this.creator({ pool: this, index, signal });
    }
    async #createAndUnwrap(index) {
        const result = await Result.runAndDoubleWrap(() => {
            return this.#tryCreate(index);
        }).then(Result.flatten);
        if (result.isOk()) {
            const entry = { index, result };
            this.#allEntries[index] = entry;
            this.#okEntries.add(entry);
            await this.events.emit("created", [entry]);
            return entry;
        }
        else {
            const entry = { index, result };
            this.#allEntries[index] = entry;
            await this.events.emit("created", [entry]);
            throw result.inner;
        }
    }
    async #delete(index) {
        const entry = this.#allEntries.at(index);
        if (entry == null)
            return undefined;
        const promise = this.#allPromises.at(index);
        if (promise == null)
            throw new Panic(`Promise is null`);
        this.#okPromises.delete(promise);
        delete this.#allPromises[index];
        if (PoolOkEntry.is(entry)) {
            await Disposable.dispose(entry.result.inner);
            this.#okEntries.delete(entry);
        }
        delete this.#allEntries[index];
        await this.events.emit("deleted", [entry]);
        return entry;
    }
    /**
     * Restart the index and return the previous entry
     * @param element
     * @returns
     */
    async restart(index) {
        return await this.mutex.lock(async () => {
            const entry = await this.#delete(index);
            await this.#start(index);
            return entry;
        });
    }
    /**
     * Modify capacity
     * @param capacity
     * @returns
     */
    async growOrShrink(capacity) {
        return await this.mutex.lock(async () => {
            if (capacity > this.#capacity) {
                const previous = this.#capacity;
                this.#capacity = capacity;
                for (let i = previous; i < capacity; i++)
                    await this.#start(i);
                return previous;
            }
            else if (capacity < this.#capacity) {
                const previous = this.#capacity;
                this.#capacity = capacity;
                for (let i = capacity; i < previous; i++)
                    await this.#delete(i);
                return previous;
            }
            return this.#capacity;
        });
    }
    /**
     * Number of open elements
     */
    get size() {
        return this.#okEntries.size;
    }
    /**
     * Number of slots
     */
    get capacity() {
        return this.#capacity;
    }
    /**
     * Iterator on open elements
     * @returns
     */
    [Symbol.iterator]() {
        return this.#okEntries.values();
    }
    /**
     * Get the element at index, if still loading, wait for it, if not started, wait for started until signal, and wait for it
     * @param index
     * @param signal
     * @returns
     */
    async tryGetOrWait(index, signal = AbortSignals.never()) {
        const current = await this.tryGet(index);
        if (current.isOk())
            return current.inner;
        const aborted = await tryWaitOrSignal(this.events, "started", (future, i) => {
            if (i !== index)
                return new None();
            future.resolve(ok_Ok.void());
            return new None();
        }, signal);
        if (aborted.isErr())
            return aborted;
        return await this.tryGet(index).then(r => r.unwrap());
    }
    /**
     * Get the element at index, if still loading, wait for it, err if not started
     * @param index
     * @returns
     */
    async tryGet(index) {
        await this.mutex.promise;
        const slot = this.#allPromises.at(index);
        if (slot === undefined)
            return new err_Err(new EmptySlotError());
        try {
            return new ok_Ok(await slot.then(r => r.result));
        }
        catch (e) {
            return new ok_Ok(new err_Err(e));
        }
    }
    /**
     * Get the element at index, err if empty
     * @param index
     * @returns
     */
    async tryGetSync(index) {
        await this.mutex.promise;
        const slot = this.#allEntries.at(index);
        if (slot === undefined)
            return new err_Err(new EmptySlotError());
        return new ok_Ok(slot.result);
    }
    /**
     * Wait for any element to be created, then get a random one using Math's PRNG
     * @returns
     */
    async tryGetRandom() {
        await this.mutex.promise;
        const first = await Result
            .runAndWrap(() => Promise.any(this.#okPromises))
            .then(r => r.mapErrSync(e => e));
        if (first.isErr())
            return first;
        const random = await this.tryGetRandomSync();
        if (random.isOk())
            return random;
        /**
         * The element has been deleted already?
         */
        console.error(`Could not get random element`, { first });
        throw new Panic(`Could not get random element`);
    }
    /**
     * Get a random element from the pool using Math's PRNG, throws if none available
     * @returns
     */
    async tryGetRandomSync() {
        await this.mutex.promise;
        if (this.#okEntries.size === 0)
            return new err_Err(new EmptyPoolError());
        const entries = [...this.#okEntries];
        const entry = random(entries);
        return new ok_Ok(entry);
    }
    /**
     * Wait for any element to be created, then get a random one using WebCrypto's CSPRNG
     * @returns
     */
    async tryGetCryptoRandom() {
        await this.mutex.promise;
        const first = await Result
            .runAndWrap(() => Promise.any(this.#okPromises))
            .then(r => r.mapErrSync(e => e));
        if (first.isErr())
            return first;
        const random = await this.tryGetCryptoRandomSync();
        if (random.isOk())
            return random;
        /**
         * The element has been deleted already?
         */
        console.error(`Could not get random element`, { first });
        throw new Panic(`Could not get random element`);
    }
    /**
     * Get a random element from the pool using WebCrypto's CSPRNG, throws if none available
     * @returns
     */
    async tryGetCryptoRandomSync() {
        await this.mutex.promise;
        if (this.#okEntries.size === 0)
            return new err_Err(new EmptyPoolError());
        const entries = [...this.#okEntries];
        const entry = cryptoRandom(entries);
        return new ok_Ok(entry);
    }
    static async takeRandom(pool) {
        return await pool.lock(async (pool) => {
            const result = await pool.tryGetRandom();
            if (result.isOk())
                pool.restart(result.inner.index);
            return result;
        });
    }
    static async takeCryptoRandom(pool) {
        return await pool.lock(async (pool) => {
            const result = await pool.tryGetCryptoRandom();
            if (result.isOk())
                pool.restart(result.inner.index);
            return result;
        });
    }
}


//# sourceMappingURL=pool.mjs.map

;// CONCATENATED MODULE: ./src/mods/background/content_script/index.ts










const mouse = {
    x: window.screen.width / 2,
    y: window.screen.height / 2
};
addEventListener("mousemove", (e)=>{
    mouse.x = e.screenX;
    mouse.y = e.screenY;
}, {
    passive: true
});
if (IS_FIREFOX || IS_SAFARI) {
    const container = document.documentElement;
    const scriptBody = atob("LyoqKioqKi8gKCgpID0+IHsgLy8gd2VicGFja0Jvb3RzdHJhcAovKioqKioqLyAJdmFyIF9fd2VicGFja19tb2R1bGVzX18gPSAoewoKLyoqKi8gNzQyOgovKioqLyAoKF9fdW51c2VkX3dlYnBhY2tfbW9kdWxlLCBleHBvcnRzKSA9PiB7CgoidXNlIHN0cmljdCI7CgoKZXhwb3J0cy5ieXRlTGVuZ3RoID0gYnl0ZUxlbmd0aApleHBvcnRzLnRvQnl0ZUFycmF5ID0gdG9CeXRlQXJyYXkKZXhwb3J0cy5mcm9tQnl0ZUFycmF5ID0gZnJvbUJ5dGVBcnJheQoKdmFyIGxvb2t1cCA9IFtdCnZhciByZXZMb29rdXAgPSBbXQp2YXIgQXJyID0gdHlwZW9mIFVpbnQ4QXJyYXkgIT09ICd1bmRlZmluZWQnID8gVWludDhBcnJheSA6IEFycmF5Cgp2YXIgY29kZSA9ICdBQkNERUZHSElKS0xNTk9QUVJTVFVWV1hZWmFiY2RlZmdoaWprbG1ub3BxcnN0dXZ3eHl6MDEyMzQ1Njc4OSsvJwpmb3IgKHZhciBpID0gMCwgbGVuID0gY29kZS5sZW5ndGg7IGkgPCBsZW47ICsraSkgewogIGxvb2t1cFtpXSA9IGNvZGVbaV0KICByZXZMb29rdXBbY29kZS5jaGFyQ29kZUF0KGkpXSA9IGkKfQoKLy8gU3VwcG9ydCBkZWNvZGluZyBVUkwtc2FmZSBiYXNlNjQgc3RyaW5ncywgYXMgTm9kZS5qcyBkb2VzLgovLyBTZWU6IGh0dHBzOi8vZW4ud2lraXBlZGlhLm9yZy93aWtpL0Jhc2U2NCNVUkxfYXBwbGljYXRpb25zCnJldkxvb2t1cFsnLScuY2hhckNvZGVBdCgwKV0gPSA2MgpyZXZMb29rdXBbJ18nLmNoYXJDb2RlQXQoMCldID0gNjMKCmZ1bmN0aW9uIGdldExlbnMgKGI2NCkgewogIHZhciBsZW4gPSBiNjQubGVuZ3RoCgogIGlmIChsZW4gJSA0ID4gMCkgewogICAgdGhyb3cgbmV3IEVycm9yKCdJbnZhbGlkIHN0cmluZy4gTGVuZ3RoIG11c3QgYmUgYSBtdWx0aXBsZSBvZiA0JykKICB9CgogIC8vIFRyaW0gb2ZmIGV4dHJhIGJ5dGVzIGFmdGVyIHBsYWNlaG9sZGVyIGJ5dGVzIGFyZSBmb3VuZAogIC8vIFNlZTogaHR0cHM6Ly9naXRodWIuY29tL2JlYXRnYW1taXQvYmFzZTY0LWpzL2lzc3Vlcy80MgogIHZhciB2YWxpZExlbiA9IGI2NC5pbmRleE9mKCc9JykKICBpZiAodmFsaWRMZW4gPT09IC0xKSB2YWxpZExlbiA9IGxlbgoKICB2YXIgcGxhY2VIb2xkZXJzTGVuID0gdmFsaWRMZW4gPT09IGxlbgogICAgPyAwCiAgICA6IDQgLSAodmFsaWRMZW4gJSA0KQoKICByZXR1cm4gW3ZhbGlkTGVuLCBwbGFjZUhvbGRlcnNMZW5dCn0KCi8vIGJhc2U2NCBpcyA0LzMgKyB1cCB0byB0d28gY2hhcmFjdGVycyBvZiB0aGUgb3JpZ2luYWwgZGF0YQpmdW5jdGlvbiBieXRlTGVuZ3RoIChiNjQpIHsKICB2YXIgbGVucyA9IGdldExlbnMoYjY0KQogIHZhciB2YWxpZExlbiA9IGxlbnNbMF0KICB2YXIgcGxhY2VIb2xkZXJzTGVuID0gbGVuc1sxXQogIHJldHVybiAoKHZhbGlkTGVuICsgcGxhY2VIb2xkZXJzTGVuKSAqIDMgLyA0KSAtIHBsYWNlSG9sZGVyc0xlbgp9CgpmdW5jdGlvbiBfYnl0ZUxlbmd0aCAoYjY0LCB2YWxpZExlbiwgcGxhY2VIb2xkZXJzTGVuKSB7CiAgcmV0dXJuICgodmFsaWRMZW4gKyBwbGFjZUhvbGRlcnNMZW4pICogMyAvIDQpIC0gcGxhY2VIb2xkZXJzTGVuCn0KCmZ1bmN0aW9uIHRvQnl0ZUFycmF5IChiNjQpIHsKICB2YXIgdG1wCiAgdmFyIGxlbnMgPSBnZXRMZW5zKGI2NCkKICB2YXIgdmFsaWRMZW4gPSBsZW5zWzBdCiAgdmFyIHBsYWNlSG9sZGVyc0xlbiA9IGxlbnNbMV0KCiAgdmFyIGFyciA9IG5ldyBBcnIoX2J5dGVMZW5ndGgoYjY0LCB2YWxpZExlbiwgcGxhY2VIb2xkZXJzTGVuKSkKCiAgdmFyIGN1ckJ5dGUgPSAwCgogIC8vIGlmIHRoZXJlIGFyZSBwbGFjZWhvbGRlcnMsIG9ubHkgZ2V0IHVwIHRvIHRoZSBsYXN0IGNvbXBsZXRlIDQgY2hhcnMKICB2YXIgbGVuID0gcGxhY2VIb2xkZXJzTGVuID4gMAogICAgPyB2YWxpZExlbiAtIDQKICAgIDogdmFsaWRMZW4KCiAgdmFyIGkKICBmb3IgKGkgPSAwOyBpIDwgbGVuOyBpICs9IDQpIHsKICAgIHRtcCA9CiAgICAgIChyZXZMb29rdXBbYjY0LmNoYXJDb2RlQXQoaSldIDw8IDE4KSB8CiAgICAgIChyZXZMb29rdXBbYjY0LmNoYXJDb2RlQXQoaSArIDEpXSA8PCAxMikgfAogICAgICAocmV2TG9va3VwW2I2NC5jaGFyQ29kZUF0KGkgKyAyKV0gPDwgNikgfAogICAgICByZXZMb29rdXBbYjY0LmNoYXJDb2RlQXQoaSArIDMpXQogICAgYXJyW2N1ckJ5dGUrK10gPSAodG1wID4+IDE2KSAmIDB4RkYKICAgIGFycltjdXJCeXRlKytdID0gKHRtcCA+PiA4KSAmIDB4RkYKICAgIGFycltjdXJCeXRlKytdID0gdG1wICYgMHhGRgogIH0KCiAgaWYgKHBsYWNlSG9sZGVyc0xlbiA9PT0gMikgewogICAgdG1wID0KICAgICAgKHJldkxvb2t1cFtiNjQuY2hhckNvZGVBdChpKV0gPDwgMikgfAogICAgICAocmV2TG9va3VwW2I2NC5jaGFyQ29kZUF0KGkgKyAxKV0gPj4gNCkKICAgIGFycltjdXJCeXRlKytdID0gdG1wICYgMHhGRgogIH0KCiAgaWYgKHBsYWNlSG9sZGVyc0xlbiA9PT0gMSkgewogICAgdG1wID0KICAgICAgKHJldkxvb2t1cFtiNjQuY2hhckNvZGVBdChpKV0gPDwgMTApIHwKICAgICAgKHJldkxvb2t1cFtiNjQuY2hhckNvZGVBdChpICsgMSldIDw8IDQpIHwKICAgICAgKHJldkxvb2t1cFtiNjQuY2hhckNvZGVBdChpICsgMildID4+IDIpCiAgICBhcnJbY3VyQnl0ZSsrXSA9ICh0bXAgPj4gOCkgJiAweEZGCiAgICBhcnJbY3VyQnl0ZSsrXSA9IHRtcCAmIDB4RkYKICB9CgogIHJldHVybiBhcnIKfQoKZnVuY3Rpb24gdHJpcGxldFRvQmFzZTY0IChudW0pIHsKICByZXR1cm4gbG9va3VwW251bSA+PiAxOCAmIDB4M0ZdICsKICAgIGxvb2t1cFtudW0gPj4gMTIgJiAweDNGXSArCiAgICBsb29rdXBbbnVtID4+IDYgJiAweDNGXSArCiAgICBsb29rdXBbbnVtICYgMHgzRl0KfQoKZnVuY3Rpb24gZW5jb2RlQ2h1bmsgKHVpbnQ4LCBzdGFydCwgZW5kKSB7CiAgdmFyIHRtcAogIHZhciBvdXRwdXQgPSBbXQogIGZvciAodmFyIGkgPSBzdGFydDsgaSA8IGVuZDsgaSArPSAzKSB7CiAgICB0bXAgPQogICAgICAoKHVpbnQ4W2ldIDw8IDE2KSAmIDB4RkYwMDAwKSArCiAgICAgICgodWludDhbaSArIDFdIDw8IDgpICYgMHhGRjAwKSArCiAgICAgICh1aW50OFtpICsgMl0gJiAweEZGKQogICAgb3V0cHV0LnB1c2godHJpcGxldFRvQmFzZTY0KHRtcCkpCiAgfQogIHJldHVybiBvdXRwdXQuam9pbignJykKfQoKZnVuY3Rpb24gZnJvbUJ5dGVBcnJheSAodWludDgpIHsKICB2YXIgdG1wCiAgdmFyIGxlbiA9IHVpbnQ4Lmxlbmd0aAogIHZhciBleHRyYUJ5dGVzID0gbGVuICUgMyAvLyBpZiB3ZSBoYXZlIDEgYnl0ZSBsZWZ0LCBwYWQgMiBieXRlcwogIHZhciBwYXJ0cyA9IFtdCiAgdmFyIG1heENodW5rTGVuZ3RoID0gMTYzODMgLy8gbXVzdCBiZSBtdWx0aXBsZSBvZiAzCgogIC8vIGdvIHRocm91Z2ggdGhlIGFycmF5IGV2ZXJ5IHRocmVlIGJ5dGVzLCB3ZSdsbCBkZWFsIHdpdGggdHJhaWxpbmcgc3R1ZmYgbGF0ZXIKICBmb3IgKHZhciBpID0gMCwgbGVuMiA9IGxlbiAtIGV4dHJhQnl0ZXM7IGkgPCBsZW4yOyBpICs9IG1heENodW5rTGVuZ3RoKSB7CiAgICBwYXJ0cy5wdXNoKGVuY29kZUNodW5rKHVpbnQ4LCBpLCAoaSArIG1heENodW5rTGVuZ3RoKSA+IGxlbjIgPyBsZW4yIDogKGkgKyBtYXhDaHVua0xlbmd0aCkpKQogIH0KCiAgLy8gcGFkIHRoZSBlbmQgd2l0aCB6ZXJvcywgYnV0IG1ha2Ugc3VyZSB0byBub3QgZm9yZ2V0IHRoZSBleHRyYSBieXRlcwogIGlmIChleHRyYUJ5dGVzID09PSAxKSB7CiAgICB0bXAgPSB1aW50OFtsZW4gLSAxXQogICAgcGFydHMucHVzaCgKICAgICAgbG9va3VwW3RtcCA+PiAyXSArCiAgICAgIGxvb2t1cFsodG1wIDw8IDQpICYgMHgzRl0gKwogICAgICAnPT0nCiAgICApCiAgfSBlbHNlIGlmIChleHRyYUJ5dGVzID09PSAyKSB7CiAgICB0bXAgPSAodWludDhbbGVuIC0gMl0gPDwgOCkgKyB1aW50OFtsZW4gLSAxXQogICAgcGFydHMucHVzaCgKICAgICAgbG9va3VwW3RtcCA+PiAxMF0gKwogICAgICBsb29rdXBbKHRtcCA+PiA0KSAmIDB4M0ZdICsKICAgICAgbG9va3VwWyh0bXAgPDwgMikgJiAweDNGXSArCiAgICAgICc9JwogICAgKQogIH0KCiAgcmV0dXJuIHBhcnRzLmpvaW4oJycpCn0KCgovKioqLyB9KSwKCi8qKiovIDc2NDoKLyoqKi8gKChfX3VudXNlZF93ZWJwYWNrX21vZHVsZSwgZXhwb3J0cywgX193ZWJwYWNrX3JlcXVpcmVfXykgPT4gewoKInVzZSBzdHJpY3QiOwp2YXIgX193ZWJwYWNrX3VudXNlZF9leHBvcnRfXzsKLyohCiAqIFRoZSBidWZmZXIgbW9kdWxlIGZyb20gbm9kZS5qcywgZm9yIHRoZSBicm93c2VyLgogKgogKiBAYXV0aG9yICAgRmVyb3NzIEFib3VraGFkaWplaCA8aHR0cHM6Ly9mZXJvc3Mub3JnPgogKiBAbGljZW5zZSAgTUlUCiAqLwovKiBlc2xpbnQtZGlzYWJsZSBuby1wcm90byAqLwoKCgpjb25zdCBiYXNlNjQgPSBfX3dlYnBhY2tfcmVxdWlyZV9fKDc0MikKY29uc3QgaWVlZTc1NCA9IF9fd2VicGFja19yZXF1aXJlX18oNjQ1KQpjb25zdCBjdXN0b21JbnNwZWN0U3ltYm9sID0KICAodHlwZW9mIFN5bWJvbCA9PT0gJ2Z1bmN0aW9uJyAmJiB0eXBlb2YgU3ltYm9sWydmb3InXSA9PT0gJ2Z1bmN0aW9uJykgLy8gZXNsaW50LWRpc2FibGUtbGluZSBkb3Qtbm90YXRpb24KICAgID8gU3ltYm9sWydmb3InXSgnbm9kZWpzLnV0aWwuaW5zcGVjdC5jdXN0b20nKSAvLyBlc2xpbnQtZGlzYWJsZS1saW5lIGRvdC1ub3RhdGlvbgogICAgOiBudWxsCgpleHBvcnRzLmxXID0gQnVmZmVyCl9fd2VicGFja191bnVzZWRfZXhwb3J0X18gPSBTbG93QnVmZmVyCmV4cG9ydHMuaDIgPSA1MAoKY29uc3QgS19NQVhfTEVOR1RIID0gMHg3ZmZmZmZmZgpfX3dlYnBhY2tfdW51c2VkX2V4cG9ydF9fID0gS19NQVhfTEVOR1RICgovKioKICogSWYgYEJ1ZmZlci5UWVBFRF9BUlJBWV9TVVBQT1JUYDoKICogICA9PT0gdHJ1ZSAgICBVc2UgVWludDhBcnJheSBpbXBsZW1lbnRhdGlvbiAoZmFzdGVzdCkKICogICA9PT0gZmFsc2UgICBQcmludCB3YXJuaW5nIGFuZCByZWNvbW1lbmQgdXNpbmcgYGJ1ZmZlcmAgdjQueCB3aGljaCBoYXMgYW4gT2JqZWN0CiAqICAgICAgICAgICAgICAgaW1wbGVtZW50YXRpb24gKG1vc3QgY29tcGF0aWJsZSwgZXZlbiBJRTYpCiAqCiAqIEJyb3dzZXJzIHRoYXQgc3VwcG9ydCB0eXBlZCBhcnJheXMgYXJlIElFIDEwKywgRmlyZWZveCA0KywgQ2hyb21lIDcrLCBTYWZhcmkgNS4xKywKICogT3BlcmEgMTEuNissIGlPUyA0LjIrLgogKgogKiBXZSByZXBvcnQgdGhhdCB0aGUgYnJvd3NlciBkb2VzIG5vdCBzdXBwb3J0IHR5cGVkIGFycmF5cyBpZiB0aGUgYXJlIG5vdCBzdWJjbGFzc2FibGUKICogdXNpbmcgX19wcm90b19fLiBGaXJlZm94IDQtMjkgbGFja3Mgc3VwcG9ydCBmb3IgYWRkaW5nIG5ldyBwcm9wZXJ0aWVzIHRvIGBVaW50OEFycmF5YAogKiAoU2VlOiBodHRwczovL2J1Z3ppbGxhLm1vemlsbGEub3JnL3Nob3dfYnVnLmNnaT9pZD02OTU0MzgpLiBJRSAxMCBsYWNrcyBzdXBwb3J0CiAqIGZvciBfX3Byb3RvX18gYW5kIGhhcyBhIGJ1Z2d5IHR5cGVkIGFycmF5IGltcGxlbWVudGF0aW9uLgogKi8KQnVmZmVyLlRZUEVEX0FSUkFZX1NVUFBPUlQgPSB0eXBlZEFycmF5U3VwcG9ydCgpCgppZiAoIUJ1ZmZlci5UWVBFRF9BUlJBWV9TVVBQT1JUICYmIHR5cGVvZiBjb25zb2xlICE9PSAndW5kZWZpbmVkJyAmJgogICAgdHlwZW9mIGNvbnNvbGUuZXJyb3IgPT09ICdmdW5jdGlvbicpIHsKICBjb25zb2xlLmVycm9yKAogICAgJ1RoaXMgYnJvd3NlciBsYWNrcyB0eXBlZCBhcnJheSAoVWludDhBcnJheSkgc3VwcG9ydCB3aGljaCBpcyByZXF1aXJlZCBieSAnICsKICAgICdgYnVmZmVyYCB2NS54LiBVc2UgYGJ1ZmZlcmAgdjQueCBpZiB5b3UgcmVxdWlyZSBvbGQgYnJvd3NlciBzdXBwb3J0LicKICApCn0KCmZ1bmN0aW9uIHR5cGVkQXJyYXlTdXBwb3J0ICgpIHsKICAvLyBDYW4gdHlwZWQgYXJyYXkgaW5zdGFuY2VzIGNhbiBiZSBhdWdtZW50ZWQ/CiAgdHJ5IHsKICAgIGNvbnN0IGFyciA9IG5ldyBVaW50OEFycmF5KDEpCiAgICBjb25zdCBwcm90byA9IHsgZm9vOiBmdW5jdGlvbiAoKSB7IHJldHVybiA0MiB9IH0KICAgIE9iamVjdC5zZXRQcm90b3R5cGVPZihwcm90bywgVWludDhBcnJheS5wcm90b3R5cGUpCiAgICBPYmplY3Quc2V0UHJvdG90eXBlT2YoYXJyLCBwcm90bykKICAgIHJldHVybiBhcnIuZm9vKCkgPT09IDQyCiAgfSBjYXRjaCAoZSkgewogICAgcmV0dXJuIGZhbHNlCiAgfQp9CgpPYmplY3QuZGVmaW5lUHJvcGVydHkoQnVmZmVyLnByb3RvdHlwZSwgJ3BhcmVudCcsIHsKICBlbnVtZXJhYmxlOiB0cnVlLAogIGdldDogZnVuY3Rpb24gKCkgewogICAgaWYgKCFCdWZmZXIuaXNCdWZmZXIodGhpcykpIHJldHVybiB1bmRlZmluZWQKICAgIHJldHVybiB0aGlzLmJ1ZmZlcgogIH0KfSkKCk9iamVjdC5kZWZpbmVQcm9wZXJ0eShCdWZmZXIucHJvdG90eXBlLCAnb2Zmc2V0JywgewogIGVudW1lcmFibGU6IHRydWUsCiAgZ2V0OiBmdW5jdGlvbiAoKSB7CiAgICBpZiAoIUJ1ZmZlci5pc0J1ZmZlcih0aGlzKSkgcmV0dXJuIHVuZGVmaW5lZAogICAgcmV0dXJuIHRoaXMuYnl0ZU9mZnNldAogIH0KfSkKCmZ1bmN0aW9uIGNyZWF0ZUJ1ZmZlciAobGVuZ3RoKSB7CiAgaWYgKGxlbmd0aCA+IEtfTUFYX0xFTkdUSCkgewogICAgdGhyb3cgbmV3IFJhbmdlRXJyb3IoJ1RoZSB2YWx1ZSAiJyArIGxlbmd0aCArICciIGlzIGludmFsaWQgZm9yIG9wdGlvbiAic2l6ZSInKQogIH0KICAvLyBSZXR1cm4gYW4gYXVnbWVudGVkIGBVaW50OEFycmF5YCBpbnN0YW5jZQogIGNvbnN0IGJ1ZiA9IG5ldyBVaW50OEFycmF5KGxlbmd0aCkKICBPYmplY3Quc2V0UHJvdG90eXBlT2YoYnVmLCBCdWZmZXIucHJvdG90eXBlKQogIHJldHVybiBidWYKfQoKLyoqCiAqIFRoZSBCdWZmZXIgY29uc3RydWN0b3IgcmV0dXJucyBpbnN0YW5jZXMgb2YgYFVpbnQ4QXJyYXlgIHRoYXQgaGF2ZSB0aGVpcgogKiBwcm90b3R5cGUgY2hhbmdlZCB0byBgQnVmZmVyLnByb3RvdHlwZWAuIEZ1cnRoZXJtb3JlLCBgQnVmZmVyYCBpcyBhIHN1YmNsYXNzIG9mCiAqIGBVaW50OEFycmF5YCwgc28gdGhlIHJldHVybmVkIGluc3RhbmNlcyB3aWxsIGhhdmUgYWxsIHRoZSBub2RlIGBCdWZmZXJgIG1ldGhvZHMKICogYW5kIHRoZSBgVWludDhBcnJheWAgbWV0aG9kcy4gU3F1YXJlIGJyYWNrZXQgbm90YXRpb24gd29ya3MgYXMgZXhwZWN0ZWQgLS0gaXQKICogcmV0dXJucyBhIHNpbmdsZSBvY3RldC4KICoKICogVGhlIGBVaW50OEFycmF5YCBwcm90b3R5cGUgcmVtYWlucyB1bm1vZGlmaWVkLgogKi8KCmZ1bmN0aW9uIEJ1ZmZlciAoYXJnLCBlbmNvZGluZ09yT2Zmc2V0LCBsZW5ndGgpIHsKICAvLyBDb21tb24gY2FzZS4KICBpZiAodHlwZW9mIGFyZyA9PT0gJ251bWJlcicpIHsKICAgIGlmICh0eXBlb2YgZW5jb2RpbmdPck9mZnNldCA9PT0gJ3N0cmluZycpIHsKICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcigKICAgICAgICAnVGhlICJzdHJpbmciIGFyZ3VtZW50IG11c3QgYmUgb2YgdHlwZSBzdHJpbmcuIFJlY2VpdmVkIHR5cGUgbnVtYmVyJwogICAgICApCiAgICB9CiAgICByZXR1cm4gYWxsb2NVbnNhZmUoYXJnKQogIH0KICByZXR1cm4gZnJvbShhcmcsIGVuY29kaW5nT3JPZmZzZXQsIGxlbmd0aCkKfQoKQnVmZmVyLnBvb2xTaXplID0gODE5MiAvLyBub3QgdXNlZCBieSB0aGlzIGltcGxlbWVudGF0aW9uCgpmdW5jdGlvbiBmcm9tICh2YWx1ZSwgZW5jb2RpbmdPck9mZnNldCwgbGVuZ3RoKSB7CiAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ3N0cmluZycpIHsKICAgIHJldHVybiBmcm9tU3RyaW5nKHZhbHVlLCBlbmNvZGluZ09yT2Zmc2V0KQogIH0KCiAgaWYgKEFycmF5QnVmZmVyLmlzVmlldyh2YWx1ZSkpIHsKICAgIHJldHVybiBmcm9tQXJyYXlWaWV3KHZhbHVlKQogIH0KCiAgaWYgKHZhbHVlID09IG51bGwpIHsKICAgIHRocm93IG5ldyBUeXBlRXJyb3IoCiAgICAgICdUaGUgZmlyc3QgYXJndW1lbnQgbXVzdCBiZSBvbmUgb2YgdHlwZSBzdHJpbmcsIEJ1ZmZlciwgQXJyYXlCdWZmZXIsIEFycmF5LCAnICsKICAgICAgJ29yIEFycmF5LWxpa2UgT2JqZWN0LiBSZWNlaXZlZCB0eXBlICcgKyAodHlwZW9mIHZhbHVlKQogICAgKQogIH0KCiAgaWYgKGlzSW5zdGFuY2UodmFsdWUsIEFycmF5QnVmZmVyKSB8fAogICAgICAodmFsdWUgJiYgaXNJbnN0YW5jZSh2YWx1ZS5idWZmZXIsIEFycmF5QnVmZmVyKSkpIHsKICAgIHJldHVybiBmcm9tQXJyYXlCdWZmZXIodmFsdWUsIGVuY29kaW5nT3JPZmZzZXQsIGxlbmd0aCkKICB9CgogIGlmICh0eXBlb2YgU2hhcmVkQXJyYXlCdWZmZXIgIT09ICd1bmRlZmluZWQnICYmCiAgICAgIChpc0luc3RhbmNlKHZhbHVlLCBTaGFyZWRBcnJheUJ1ZmZlcikgfHwKICAgICAgKHZhbHVlICYmIGlzSW5zdGFuY2UodmFsdWUuYnVmZmVyLCBTaGFyZWRBcnJheUJ1ZmZlcikpKSkgewogICAgcmV0dXJuIGZyb21BcnJheUJ1ZmZlcih2YWx1ZSwgZW5jb2RpbmdPck9mZnNldCwgbGVuZ3RoKQogIH0KCiAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ251bWJlcicpIHsKICAgIHRocm93IG5ldyBUeXBlRXJyb3IoCiAgICAgICdUaGUgInZhbHVlIiBhcmd1bWVudCBtdXN0IG5vdCBiZSBvZiB0eXBlIG51bWJlci4gUmVjZWl2ZWQgdHlwZSBudW1iZXInCiAgICApCiAgfQoKICBjb25zdCB2YWx1ZU9mID0gdmFsdWUudmFsdWVPZiAmJiB2YWx1ZS52YWx1ZU9mKCkKICBpZiAodmFsdWVPZiAhPSBudWxsICYmIHZhbHVlT2YgIT09IHZhbHVlKSB7CiAgICByZXR1cm4gQnVmZmVyLmZyb20odmFsdWVPZiwgZW5jb2RpbmdPck9mZnNldCwgbGVuZ3RoKQogIH0KCiAgY29uc3QgYiA9IGZyb21PYmplY3QodmFsdWUpCiAgaWYgKGIpIHJldHVybiBiCgogIGlmICh0eXBlb2YgU3ltYm9sICE9PSAndW5kZWZpbmVkJyAmJiBTeW1ib2wudG9QcmltaXRpdmUgIT0gbnVsbCAmJgogICAgICB0eXBlb2YgdmFsdWVbU3ltYm9sLnRvUHJpbWl0aXZlXSA9PT0gJ2Z1bmN0aW9uJykgewogICAgcmV0dXJuIEJ1ZmZlci5mcm9tKHZhbHVlW1N5bWJvbC50b1ByaW1pdGl2ZV0oJ3N0cmluZycpLCBlbmNvZGluZ09yT2Zmc2V0LCBsZW5ndGgpCiAgfQoKICB0aHJvdyBuZXcgVHlwZUVycm9yKAogICAgJ1RoZSBmaXJzdCBhcmd1bWVudCBtdXN0IGJlIG9uZSBvZiB0eXBlIHN0cmluZywgQnVmZmVyLCBBcnJheUJ1ZmZlciwgQXJyYXksICcgKwogICAgJ29yIEFycmF5LWxpa2UgT2JqZWN0LiBSZWNlaXZlZCB0eXBlICcgKyAodHlwZW9mIHZhbHVlKQogICkKfQoKLyoqCiAqIEZ1bmN0aW9uYWxseSBlcXVpdmFsZW50IHRvIEJ1ZmZlcihhcmcsIGVuY29kaW5nKSBidXQgdGhyb3dzIGEgVHlwZUVycm9yCiAqIGlmIHZhbHVlIGlzIGEgbnVtYmVyLgogKiBCdWZmZXIuZnJvbShzdHJbLCBlbmNvZGluZ10pCiAqIEJ1ZmZlci5mcm9tKGFycmF5KQogKiBCdWZmZXIuZnJvbShidWZmZXIpCiAqIEJ1ZmZlci5mcm9tKGFycmF5QnVmZmVyWywgYnl0ZU9mZnNldFssIGxlbmd0aF1dKQogKiovCkJ1ZmZlci5mcm9tID0gZnVuY3Rpb24gKHZhbHVlLCBlbmNvZGluZ09yT2Zmc2V0LCBsZW5ndGgpIHsKICByZXR1cm4gZnJvbSh2YWx1ZSwgZW5jb2RpbmdPck9mZnNldCwgbGVuZ3RoKQp9CgovLyBOb3RlOiBDaGFuZ2UgcHJvdG90eXBlICphZnRlciogQnVmZmVyLmZyb20gaXMgZGVmaW5lZCB0byB3b3JrYXJvdW5kIENocm9tZSBidWc6Ci8vIGh0dHBzOi8vZ2l0aHViLmNvbS9mZXJvc3MvYnVmZmVyL3B1bGwvMTQ4Ck9iamVjdC5zZXRQcm90b3R5cGVPZihCdWZmZXIucHJvdG90eXBlLCBVaW50OEFycmF5LnByb3RvdHlwZSkKT2JqZWN0LnNldFByb3RvdHlwZU9mKEJ1ZmZlciwgVWludDhBcnJheSkKCmZ1bmN0aW9uIGFzc2VydFNpemUgKHNpemUpIHsKICBpZiAodHlwZW9mIHNpemUgIT09ICdudW1iZXInKSB7CiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCcic2l6ZSIgYXJndW1lbnQgbXVzdCBiZSBvZiB0eXBlIG51bWJlcicpCiAgfSBlbHNlIGlmIChzaXplIDwgMCkgewogICAgdGhyb3cgbmV3IFJhbmdlRXJyb3IoJ1RoZSB2YWx1ZSAiJyArIHNpemUgKyAnIiBpcyBpbnZhbGlkIGZvciBvcHRpb24gInNpemUiJykKICB9Cn0KCmZ1bmN0aW9uIGFsbG9jIChzaXplLCBmaWxsLCBlbmNvZGluZykgewogIGFzc2VydFNpemUoc2l6ZSkKICBpZiAoc2l6ZSA8PSAwKSB7CiAgICByZXR1cm4gY3JlYXRlQnVmZmVyKHNpemUpCiAgfQogIGlmIChmaWxsICE9PSB1bmRlZmluZWQpIHsKICAgIC8vIE9ubHkgcGF5IGF0dGVudGlvbiB0byBlbmNvZGluZyBpZiBpdCdzIGEgc3RyaW5nLiBUaGlzCiAgICAvLyBwcmV2ZW50cyBhY2NpZGVudGFsbHkgc2VuZGluZyBpbiBhIG51bWJlciB0aGF0IHdvdWxkCiAgICAvLyBiZSBpbnRlcnByZXRlZCBhcyBhIHN0YXJ0IG9mZnNldC4KICAgIHJldHVybiB0eXBlb2YgZW5jb2RpbmcgPT09ICdzdHJpbmcnCiAgICAgID8gY3JlYXRlQnVmZmVyKHNpemUpLmZpbGwoZmlsbCwgZW5jb2RpbmcpCiAgICAgIDogY3JlYXRlQnVmZmVyKHNpemUpLmZpbGwoZmlsbCkKICB9CiAgcmV0dXJuIGNyZWF0ZUJ1ZmZlcihzaXplKQp9CgovKioKICogQ3JlYXRlcyBhIG5ldyBmaWxsZWQgQnVmZmVyIGluc3RhbmNlLgogKiBhbGxvYyhzaXplWywgZmlsbFssIGVuY29kaW5nXV0pCiAqKi8KQnVmZmVyLmFsbG9jID0gZnVuY3Rpb24gKHNpemUsIGZpbGwsIGVuY29kaW5nKSB7CiAgcmV0dXJuIGFsbG9jKHNpemUsIGZpbGwsIGVuY29kaW5nKQp9CgpmdW5jdGlvbiBhbGxvY1Vuc2FmZSAoc2l6ZSkgewogIGFzc2VydFNpemUoc2l6ZSkKICByZXR1cm4gY3JlYXRlQnVmZmVyKHNpemUgPCAwID8gMCA6IGNoZWNrZWQoc2l6ZSkgfCAwKQp9CgovKioKICogRXF1aXZhbGVudCB0byBCdWZmZXIobnVtKSwgYnkgZGVmYXVsdCBjcmVhdGVzIGEgbm9uLXplcm8tZmlsbGVkIEJ1ZmZlciBpbnN0YW5jZS4KICogKi8KQnVmZmVyLmFsbG9jVW5zYWZlID0gZnVuY3Rpb24gKHNpemUpIHsKICByZXR1cm4gYWxsb2NVbnNhZmUoc2l6ZSkKfQovKioKICogRXF1aXZhbGVudCB0byBTbG93QnVmZmVyKG51bSksIGJ5IGRlZmF1bHQgY3JlYXRlcyBhIG5vbi16ZXJvLWZpbGxlZCBCdWZmZXIgaW5zdGFuY2UuCiAqLwpCdWZmZXIuYWxsb2NVbnNhZmVTbG93ID0gZnVuY3Rpb24gKHNpemUpIHsKICByZXR1cm4gYWxsb2NVbnNhZmUoc2l6ZSkKfQoKZnVuY3Rpb24gZnJvbVN0cmluZyAoc3RyaW5nLCBlbmNvZGluZykgewogIGlmICh0eXBlb2YgZW5jb2RpbmcgIT09ICdzdHJpbmcnIHx8IGVuY29kaW5nID09PSAnJykgewogICAgZW5jb2RpbmcgPSAndXRmOCcKICB9CgogIGlmICghQnVmZmVyLmlzRW5jb2RpbmcoZW5jb2RpbmcpKSB7CiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdVbmtub3duIGVuY29kaW5nOiAnICsgZW5jb2RpbmcpCiAgfQoKICBjb25zdCBsZW5ndGggPSBieXRlTGVuZ3RoKHN0cmluZywgZW5jb2RpbmcpIHwgMAogIGxldCBidWYgPSBjcmVhdGVCdWZmZXIobGVuZ3RoKQoKICBjb25zdCBhY3R1YWwgPSBidWYud3JpdGUoc3RyaW5nLCBlbmNvZGluZykKCiAgaWYgKGFjdHVhbCAhPT0gbGVuZ3RoKSB7CiAgICAvLyBXcml0aW5nIGEgaGV4IHN0cmluZywgZm9yIGV4YW1wbGUsIHRoYXQgY29udGFpbnMgaW52YWxpZCBjaGFyYWN0ZXJzIHdpbGwKICAgIC8vIGNhdXNlIGV2ZXJ5dGhpbmcgYWZ0ZXIgdGhlIGZpcnN0IGludmFsaWQgY2hhcmFjdGVyIHRvIGJlIGlnbm9yZWQuIChlLmcuCiAgICAvLyAnYWJ4eGNkJyB3aWxsIGJlIHRyZWF0ZWQgYXMgJ2FiJykKICAgIGJ1ZiA9IGJ1Zi5zbGljZSgwLCBhY3R1YWwpCiAgfQoKICByZXR1cm4gYnVmCn0KCmZ1bmN0aW9uIGZyb21BcnJheUxpa2UgKGFycmF5KSB7CiAgY29uc3QgbGVuZ3RoID0gYXJyYXkubGVuZ3RoIDwgMCA/IDAgOiBjaGVja2VkKGFycmF5Lmxlbmd0aCkgfCAwCiAgY29uc3QgYnVmID0gY3JlYXRlQnVmZmVyKGxlbmd0aCkKICBmb3IgKGxldCBpID0gMDsgaSA8IGxlbmd0aDsgaSArPSAxKSB7CiAgICBidWZbaV0gPSBhcnJheVtpXSAmIDI1NQogIH0KICByZXR1cm4gYnVmCn0KCmZ1bmN0aW9uIGZyb21BcnJheVZpZXcgKGFycmF5VmlldykgewogIGlmIChpc0luc3RhbmNlKGFycmF5VmlldywgVWludDhBcnJheSkpIHsKICAgIGNvbnN0IGNvcHkgPSBuZXcgVWludDhBcnJheShhcnJheVZpZXcpCiAgICByZXR1cm4gZnJvbUFycmF5QnVmZmVyKGNvcHkuYnVmZmVyLCBjb3B5LmJ5dGVPZmZzZXQsIGNvcHkuYnl0ZUxlbmd0aCkKICB9CiAgcmV0dXJuIGZyb21BcnJheUxpa2UoYXJyYXlWaWV3KQp9CgpmdW5jdGlvbiBmcm9tQXJyYXlCdWZmZXIgKGFycmF5LCBieXRlT2Zmc2V0LCBsZW5ndGgpIHsKICBpZiAoYnl0ZU9mZnNldCA8IDAgfHwgYXJyYXkuYnl0ZUxlbmd0aCA8IGJ5dGVPZmZzZXQpIHsKICAgIHRocm93IG5ldyBSYW5nZUVycm9yKCcib2Zmc2V0IiBpcyBvdXRzaWRlIG9mIGJ1ZmZlciBib3VuZHMnKQogIH0KCiAgaWYgKGFycmF5LmJ5dGVMZW5ndGggPCBieXRlT2Zmc2V0ICsgKGxlbmd0aCB8fCAwKSkgewogICAgdGhyb3cgbmV3IFJhbmdlRXJyb3IoJyJsZW5ndGgiIGlzIG91dHNpZGUgb2YgYnVmZmVyIGJvdW5kcycpCiAgfQoKICBsZXQgYnVmCiAgaWYgKGJ5dGVPZmZzZXQgPT09IHVuZGVmaW5lZCAmJiBsZW5ndGggPT09IHVuZGVmaW5lZCkgewogICAgYnVmID0gbmV3IFVpbnQ4QXJyYXkoYXJyYXkpCiAgfSBlbHNlIGlmIChsZW5ndGggPT09IHVuZGVmaW5lZCkgewogICAgYnVmID0gbmV3IFVpbnQ4QXJyYXkoYXJyYXksIGJ5dGVPZmZzZXQpCiAgfSBlbHNlIHsKICAgIGJ1ZiA9IG5ldyBVaW50OEFycmF5KGFycmF5LCBieXRlT2Zmc2V0LCBsZW5ndGgpCiAgfQoKICAvLyBSZXR1cm4gYW4gYXVnbWVudGVkIGBVaW50OEFycmF5YCBpbnN0YW5jZQogIE9iamVjdC5zZXRQcm90b3R5cGVPZihidWYsIEJ1ZmZlci5wcm90b3R5cGUpCgogIHJldHVybiBidWYKfQoKZnVuY3Rpb24gZnJvbU9iamVjdCAob2JqKSB7CiAgaWYgKEJ1ZmZlci5pc0J1ZmZlcihvYmopKSB7CiAgICBjb25zdCBsZW4gPSBjaGVja2VkKG9iai5sZW5ndGgpIHwgMAogICAgY29uc3QgYnVmID0gY3JlYXRlQnVmZmVyKGxlbikKCiAgICBpZiAoYnVmLmxlbmd0aCA9PT0gMCkgewogICAgICByZXR1cm4gYnVmCiAgICB9CgogICAgb2JqLmNvcHkoYnVmLCAwLCAwLCBsZW4pCiAgICByZXR1cm4gYnVmCiAgfQoKICBpZiAob2JqLmxlbmd0aCAhPT0gdW5kZWZpbmVkKSB7CiAgICBpZiAodHlwZW9mIG9iai5sZW5ndGggIT09ICdudW1iZXInIHx8IG51bWJlcklzTmFOKG9iai5sZW5ndGgpKSB7CiAgICAgIHJldHVybiBjcmVhdGVCdWZmZXIoMCkKICAgIH0KICAgIHJldHVybiBmcm9tQXJyYXlMaWtlKG9iaikKICB9CgogIGlmIChvYmoudHlwZSA9PT0gJ0J1ZmZlcicgJiYgQXJyYXkuaXNBcnJheShvYmouZGF0YSkpIHsKICAgIHJldHVybiBmcm9tQXJyYXlMaWtlKG9iai5kYXRhKQogIH0KfQoKZnVuY3Rpb24gY2hlY2tlZCAobGVuZ3RoKSB7CiAgLy8gTm90ZTogY2Fubm90IHVzZSBgbGVuZ3RoIDwgS19NQVhfTEVOR1RIYCBoZXJlIGJlY2F1c2UgdGhhdCBmYWlscyB3aGVuCiAgLy8gbGVuZ3RoIGlzIE5hTiAod2hpY2ggaXMgb3RoZXJ3aXNlIGNvZXJjZWQgdG8gemVyby4pCiAgaWYgKGxlbmd0aCA+PSBLX01BWF9MRU5HVEgpIHsKICAgIHRocm93IG5ldyBSYW5nZUVycm9yKCdBdHRlbXB0IHRvIGFsbG9jYXRlIEJ1ZmZlciBsYXJnZXIgdGhhbiBtYXhpbXVtICcgKwogICAgICAgICAgICAgICAgICAgICAgICAgJ3NpemU6IDB4JyArIEtfTUFYX0xFTkdUSC50b1N0cmluZygxNikgKyAnIGJ5dGVzJykKICB9CiAgcmV0dXJuIGxlbmd0aCB8IDAKfQoKZnVuY3Rpb24gU2xvd0J1ZmZlciAobGVuZ3RoKSB7CiAgaWYgKCtsZW5ndGggIT0gbGVuZ3RoKSB7IC8vIGVzbGludC1kaXNhYmxlLWxpbmUgZXFlcWVxCiAgICBsZW5ndGggPSAwCiAgfQogIHJldHVybiBCdWZmZXIuYWxsb2MoK2xlbmd0aCkKfQoKQnVmZmVyLmlzQnVmZmVyID0gZnVuY3Rpb24gaXNCdWZmZXIgKGIpIHsKICByZXR1cm4gYiAhPSBudWxsICYmIGIuX2lzQnVmZmVyID09PSB0cnVlICYmCiAgICBiICE9PSBCdWZmZXIucHJvdG90eXBlIC8vIHNvIEJ1ZmZlci5pc0J1ZmZlcihCdWZmZXIucHJvdG90eXBlKSB3aWxsIGJlIGZhbHNlCn0KCkJ1ZmZlci5jb21wYXJlID0gZnVuY3Rpb24gY29tcGFyZSAoYSwgYikgewogIGlmIChpc0luc3RhbmNlKGEsIFVpbnQ4QXJyYXkpKSBhID0gQnVmZmVyLmZyb20oYSwgYS5vZmZzZXQsIGEuYnl0ZUxlbmd0aCkKICBpZiAoaXNJbnN0YW5jZShiLCBVaW50OEFycmF5KSkgYiA9IEJ1ZmZlci5mcm9tKGIsIGIub2Zmc2V0LCBiLmJ5dGVMZW5ndGgpCiAgaWYgKCFCdWZmZXIuaXNCdWZmZXIoYSkgfHwgIUJ1ZmZlci5pc0J1ZmZlcihiKSkgewogICAgdGhyb3cgbmV3IFR5cGVFcnJvcigKICAgICAgJ1RoZSAiYnVmMSIsICJidWYyIiBhcmd1bWVudHMgbXVzdCBiZSBvbmUgb2YgdHlwZSBCdWZmZXIgb3IgVWludDhBcnJheScKICAgICkKICB9CgogIGlmIChhID09PSBiKSByZXR1cm4gMAoKICBsZXQgeCA9IGEubGVuZ3RoCiAgbGV0IHkgPSBiLmxlbmd0aAoKICBmb3IgKGxldCBpID0gMCwgbGVuID0gTWF0aC5taW4oeCwgeSk7IGkgPCBsZW47ICsraSkgewogICAgaWYgKGFbaV0gIT09IGJbaV0pIHsKICAgICAgeCA9IGFbaV0KICAgICAgeSA9IGJbaV0KICAgICAgYnJlYWsKICAgIH0KICB9CgogIGlmICh4IDwgeSkgcmV0dXJuIC0xCiAgaWYgKHkgPCB4KSByZXR1cm4gMQogIHJldHVybiAwCn0KCkJ1ZmZlci5pc0VuY29kaW5nID0gZnVuY3Rpb24gaXNFbmNvZGluZyAoZW5jb2RpbmcpIHsKICBzd2l0Y2ggKFN0cmluZyhlbmNvZGluZykudG9Mb3dlckNhc2UoKSkgewogICAgY2FzZSAnaGV4JzoKICAgIGNhc2UgJ3V0ZjgnOgogICAgY2FzZSAndXRmLTgnOgogICAgY2FzZSAnYXNjaWknOgogICAgY2FzZSAnbGF0aW4xJzoKICAgIGNhc2UgJ2JpbmFyeSc6CiAgICBjYXNlICdiYXNlNjQnOgogICAgY2FzZSAndWNzMic6CiAgICBjYXNlICd1Y3MtMic6CiAgICBjYXNlICd1dGYxNmxlJzoKICAgIGNhc2UgJ3V0Zi0xNmxlJzoKICAgICAgcmV0dXJuIHRydWUKICAgIGRlZmF1bHQ6CiAgICAgIHJldHVybiBmYWxzZQogIH0KfQoKQnVmZmVyLmNvbmNhdCA9IGZ1bmN0aW9uIGNvbmNhdCAobGlzdCwgbGVuZ3RoKSB7CiAgaWYgKCFBcnJheS5pc0FycmF5KGxpc3QpKSB7CiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCcibGlzdCIgYXJndW1lbnQgbXVzdCBiZSBhbiBBcnJheSBvZiBCdWZmZXJzJykKICB9CgogIGlmIChsaXN0Lmxlbmd0aCA9PT0gMCkgewogICAgcmV0dXJuIEJ1ZmZlci5hbGxvYygwKQogIH0KCiAgbGV0IGkKICBpZiAobGVuZ3RoID09PSB1bmRlZmluZWQpIHsKICAgIGxlbmd0aCA9IDAKICAgIGZvciAoaSA9IDA7IGkgPCBsaXN0Lmxlbmd0aDsgKytpKSB7CiAgICAgIGxlbmd0aCArPSBsaXN0W2ldLmxlbmd0aAogICAgfQogIH0KCiAgY29uc3QgYnVmZmVyID0gQnVmZmVyLmFsbG9jVW5zYWZlKGxlbmd0aCkKICBsZXQgcG9zID0gMAogIGZvciAoaSA9IDA7IGkgPCBsaXN0Lmxlbmd0aDsgKytpKSB7CiAgICBsZXQgYnVmID0gbGlzdFtpXQogICAgaWYgKGlzSW5zdGFuY2UoYnVmLCBVaW50OEFycmF5KSkgewogICAgICBpZiAocG9zICsgYnVmLmxlbmd0aCA+IGJ1ZmZlci5sZW5ndGgpIHsKICAgICAgICBpZiAoIUJ1ZmZlci5pc0J1ZmZlcihidWYpKSBidWYgPSBCdWZmZXIuZnJvbShidWYpCiAgICAgICAgYnVmLmNvcHkoYnVmZmVyLCBwb3MpCiAgICAgIH0gZWxzZSB7CiAgICAgICAgVWludDhBcnJheS5wcm90b3R5cGUuc2V0LmNhbGwoCiAgICAgICAgICBidWZmZXIsCiAgICAgICAgICBidWYsCiAgICAgICAgICBwb3MKICAgICAgICApCiAgICAgIH0KICAgIH0gZWxzZSBpZiAoIUJ1ZmZlci5pc0J1ZmZlcihidWYpKSB7CiAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJyJsaXN0IiBhcmd1bWVudCBtdXN0IGJlIGFuIEFycmF5IG9mIEJ1ZmZlcnMnKQogICAgfSBlbHNlIHsKICAgICAgYnVmLmNvcHkoYnVmZmVyLCBwb3MpCiAgICB9CiAgICBwb3MgKz0gYnVmLmxlbmd0aAogIH0KICByZXR1cm4gYnVmZmVyCn0KCmZ1bmN0aW9uIGJ5dGVMZW5ndGggKHN0cmluZywgZW5jb2RpbmcpIHsKICBpZiAoQnVmZmVyLmlzQnVmZmVyKHN0cmluZykpIHsKICAgIHJldHVybiBzdHJpbmcubGVuZ3RoCiAgfQogIGlmIChBcnJheUJ1ZmZlci5pc1ZpZXcoc3RyaW5nKSB8fCBpc0luc3RhbmNlKHN0cmluZywgQXJyYXlCdWZmZXIpKSB7CiAgICByZXR1cm4gc3RyaW5nLmJ5dGVMZW5ndGgKICB9CiAgaWYgKHR5cGVvZiBzdHJpbmcgIT09ICdzdHJpbmcnKSB7CiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKAogICAgICAnVGhlICJzdHJpbmciIGFyZ3VtZW50IG11c3QgYmUgb25lIG9mIHR5cGUgc3RyaW5nLCBCdWZmZXIsIG9yIEFycmF5QnVmZmVyLiAnICsKICAgICAgJ1JlY2VpdmVkIHR5cGUgJyArIHR5cGVvZiBzdHJpbmcKICAgICkKICB9CgogIGNvbnN0IGxlbiA9IHN0cmluZy5sZW5ndGgKICBjb25zdCBtdXN0TWF0Y2ggPSAoYXJndW1lbnRzLmxlbmd0aCA+IDIgJiYgYXJndW1lbnRzWzJdID09PSB0cnVlKQogIGlmICghbXVzdE1hdGNoICYmIGxlbiA9PT0gMCkgcmV0dXJuIDAKCiAgLy8gVXNlIGEgZm9yIGxvb3AgdG8gYXZvaWQgcmVjdXJzaW9uCiAgbGV0IGxvd2VyZWRDYXNlID0gZmFsc2UKICBmb3IgKDs7KSB7CiAgICBzd2l0Y2ggKGVuY29kaW5nKSB7CiAgICAgIGNhc2UgJ2FzY2lpJzoKICAgICAgY2FzZSAnbGF0aW4xJzoKICAgICAgY2FzZSAnYmluYXJ5JzoKICAgICAgICByZXR1cm4gbGVuCiAgICAgIGNhc2UgJ3V0ZjgnOgogICAgICBjYXNlICd1dGYtOCc6CiAgICAgICAgcmV0dXJuIHV0ZjhUb0J5dGVzKHN0cmluZykubGVuZ3RoCiAgICAgIGNhc2UgJ3VjczInOgogICAgICBjYXNlICd1Y3MtMic6CiAgICAgIGNhc2UgJ3V0ZjE2bGUnOgogICAgICBjYXNlICd1dGYtMTZsZSc6CiAgICAgICAgcmV0dXJuIGxlbiAqIDIKICAgICAgY2FzZSAnaGV4JzoKICAgICAgICByZXR1cm4gbGVuID4+PiAxCiAgICAgIGNhc2UgJ2Jhc2U2NCc6CiAgICAgICAgcmV0dXJuIGJhc2U2NFRvQnl0ZXMoc3RyaW5nKS5sZW5ndGgKICAgICAgZGVmYXVsdDoKICAgICAgICBpZiAobG93ZXJlZENhc2UpIHsKICAgICAgICAgIHJldHVybiBtdXN0TWF0Y2ggPyAtMSA6IHV0ZjhUb0J5dGVzKHN0cmluZykubGVuZ3RoIC8vIGFzc3VtZSB1dGY4CiAgICAgICAgfQogICAgICAgIGVuY29kaW5nID0gKCcnICsgZW5jb2RpbmcpLnRvTG93ZXJDYXNlKCkKICAgICAgICBsb3dlcmVkQ2FzZSA9IHRydWUKICAgIH0KICB9Cn0KQnVmZmVyLmJ5dGVMZW5ndGggPSBieXRlTGVuZ3RoCgpmdW5jdGlvbiBzbG93VG9TdHJpbmcgKGVuY29kaW5nLCBzdGFydCwgZW5kKSB7CiAgbGV0IGxvd2VyZWRDYXNlID0gZmFsc2UKCiAgLy8gTm8gbmVlZCB0byB2ZXJpZnkgdGhhdCAidGhpcy5sZW5ndGggPD0gTUFYX1VJTlQzMiIgc2luY2UgaXQncyBhIHJlYWQtb25seQogIC8vIHByb3BlcnR5IG9mIGEgdHlwZWQgYXJyYXkuCgogIC8vIFRoaXMgYmVoYXZlcyBuZWl0aGVyIGxpa2UgU3RyaW5nIG5vciBVaW50OEFycmF5IGluIHRoYXQgd2Ugc2V0IHN0YXJ0L2VuZAogIC8vIHRvIHRoZWlyIHVwcGVyL2xvd2VyIGJvdW5kcyBpZiB0aGUgdmFsdWUgcGFzc2VkIGlzIG91dCBvZiByYW5nZS4KICAvLyB1bmRlZmluZWQgaXMgaGFuZGxlZCBzcGVjaWFsbHkgYXMgcGVyIEVDTUEtMjYyIDZ0aCBFZGl0aW9uLAogIC8vIFNlY3Rpb24gMTMuMy4zLjcgUnVudGltZSBTZW1hbnRpY3M6IEtleWVkQmluZGluZ0luaXRpYWxpemF0aW9uLgogIGlmIChzdGFydCA9PT0gdW5kZWZpbmVkIHx8IHN0YXJ0IDwgMCkgewogICAgc3RhcnQgPSAwCiAgfQogIC8vIFJldHVybiBlYXJseSBpZiBzdGFydCA+IHRoaXMubGVuZ3RoLiBEb25lIGhlcmUgdG8gcHJldmVudCBwb3RlbnRpYWwgdWludDMyCiAgLy8gY29lcmNpb24gZmFpbCBiZWxvdy4KICBpZiAoc3RhcnQgPiB0aGlzLmxlbmd0aCkgewogICAgcmV0dXJuICcnCiAgfQoKICBpZiAoZW5kID09PSB1bmRlZmluZWQgfHwgZW5kID4gdGhpcy5sZW5ndGgpIHsKICAgIGVuZCA9IHRoaXMubGVuZ3RoCiAgfQoKICBpZiAoZW5kIDw9IDApIHsKICAgIHJldHVybiAnJwogIH0KCiAgLy8gRm9yY2UgY29lcmNpb24gdG8gdWludDMyLiBUaGlzIHdpbGwgYWxzbyBjb2VyY2UgZmFsc2V5L05hTiB2YWx1ZXMgdG8gMC4KICBlbmQgPj4+PSAwCiAgc3RhcnQgPj4+PSAwCgogIGlmIChlbmQgPD0gc3RhcnQpIHsKICAgIHJldHVybiAnJwogIH0KCiAgaWYgKCFlbmNvZGluZykgZW5jb2RpbmcgPSAndXRmOCcKCiAgd2hpbGUgKHRydWUpIHsKICAgIHN3aXRjaCAoZW5jb2RpbmcpIHsKICAgICAgY2FzZSAnaGV4JzoKICAgICAgICByZXR1cm4gaGV4U2xpY2UodGhpcywgc3RhcnQsIGVuZCkKCiAgICAgIGNhc2UgJ3V0ZjgnOgogICAgICBjYXNlICd1dGYtOCc6CiAgICAgICAgcmV0dXJuIHV0ZjhTbGljZSh0aGlzLCBzdGFydCwgZW5kKQoKICAgICAgY2FzZSAnYXNjaWknOgogICAgICAgIHJldHVybiBhc2NpaVNsaWNlKHRoaXMsIHN0YXJ0LCBlbmQpCgogICAgICBjYXNlICdsYXRpbjEnOgogICAgICBjYXNlICdiaW5hcnknOgogICAgICAgIHJldHVybiBsYXRpbjFTbGljZSh0aGlzLCBzdGFydCwgZW5kKQoKICAgICAgY2FzZSAnYmFzZTY0JzoKICAgICAgICByZXR1cm4gYmFzZTY0U2xpY2UodGhpcywgc3RhcnQsIGVuZCkKCiAgICAgIGNhc2UgJ3VjczInOgogICAgICBjYXNlICd1Y3MtMic6CiAgICAgIGNhc2UgJ3V0ZjE2bGUnOgogICAgICBjYXNlICd1dGYtMTZsZSc6CiAgICAgICAgcmV0dXJuIHV0ZjE2bGVTbGljZSh0aGlzLCBzdGFydCwgZW5kKQoKICAgICAgZGVmYXVsdDoKICAgICAgICBpZiAobG93ZXJlZENhc2UpIHRocm93IG5ldyBUeXBlRXJyb3IoJ1Vua25vd24gZW5jb2Rpbmc6ICcgKyBlbmNvZGluZykKICAgICAgICBlbmNvZGluZyA9IChlbmNvZGluZyArICcnKS50b0xvd2VyQ2FzZSgpCiAgICAgICAgbG93ZXJlZENhc2UgPSB0cnVlCiAgICB9CiAgfQp9CgovLyBUaGlzIHByb3BlcnR5IGlzIHVzZWQgYnkgYEJ1ZmZlci5pc0J1ZmZlcmAgKGFuZCB0aGUgYGlzLWJ1ZmZlcmAgbnBtIHBhY2thZ2UpCi8vIHRvIGRldGVjdCBhIEJ1ZmZlciBpbnN0YW5jZS4gSXQncyBub3QgcG9zc2libGUgdG8gdXNlIGBpbnN0YW5jZW9mIEJ1ZmZlcmAKLy8gcmVsaWFibHkgaW4gYSBicm93c2VyaWZ5IGNvbnRleHQgYmVjYXVzZSB0aGVyZSBjb3VsZCBiZSBtdWx0aXBsZSBkaWZmZXJlbnQKLy8gY29waWVzIG9mIHRoZSAnYnVmZmVyJyBwYWNrYWdlIGluIHVzZS4gVGhpcyBtZXRob2Qgd29ya3MgZXZlbiBmb3IgQnVmZmVyCi8vIGluc3RhbmNlcyB0aGF0IHdlcmUgY3JlYXRlZCBmcm9tIGFub3RoZXIgY29weSBvZiB0aGUgYGJ1ZmZlcmAgcGFja2FnZS4KLy8gU2VlOiBodHRwczovL2dpdGh1Yi5jb20vZmVyb3NzL2J1ZmZlci9pc3N1ZXMvMTU0CkJ1ZmZlci5wcm90b3R5cGUuX2lzQnVmZmVyID0gdHJ1ZQoKZnVuY3Rpb24gc3dhcCAoYiwgbiwgbSkgewogIGNvbnN0IGkgPSBiW25dCiAgYltuXSA9IGJbbV0KICBiW21dID0gaQp9CgpCdWZmZXIucHJvdG90eXBlLnN3YXAxNiA9IGZ1bmN0aW9uIHN3YXAxNiAoKSB7CiAgY29uc3QgbGVuID0gdGhpcy5sZW5ndGgKICBpZiAobGVuICUgMiAhPT0gMCkgewogICAgdGhyb3cgbmV3IFJhbmdlRXJyb3IoJ0J1ZmZlciBzaXplIG11c3QgYmUgYSBtdWx0aXBsZSBvZiAxNi1iaXRzJykKICB9CiAgZm9yIChsZXQgaSA9IDA7IGkgPCBsZW47IGkgKz0gMikgewogICAgc3dhcCh0aGlzLCBpLCBpICsgMSkKICB9CiAgcmV0dXJuIHRoaXMKfQoKQnVmZmVyLnByb3RvdHlwZS5zd2FwMzIgPSBmdW5jdGlvbiBzd2FwMzIgKCkgewogIGNvbnN0IGxlbiA9IHRoaXMubGVuZ3RoCiAgaWYgKGxlbiAlIDQgIT09IDApIHsKICAgIHRocm93IG5ldyBSYW5nZUVycm9yKCdCdWZmZXIgc2l6ZSBtdXN0IGJlIGEgbXVsdGlwbGUgb2YgMzItYml0cycpCiAgfQogIGZvciAobGV0IGkgPSAwOyBpIDwgbGVuOyBpICs9IDQpIHsKICAgIHN3YXAodGhpcywgaSwgaSArIDMpCiAgICBzd2FwKHRoaXMsIGkgKyAxLCBpICsgMikKICB9CiAgcmV0dXJuIHRoaXMKfQoKQnVmZmVyLnByb3RvdHlwZS5zd2FwNjQgPSBmdW5jdGlvbiBzd2FwNjQgKCkgewogIGNvbnN0IGxlbiA9IHRoaXMubGVuZ3RoCiAgaWYgKGxlbiAlIDggIT09IDApIHsKICAgIHRocm93IG5ldyBSYW5nZUVycm9yKCdCdWZmZXIgc2l6ZSBtdXN0IGJlIGEgbXVsdGlwbGUgb2YgNjQtYml0cycpCiAgfQogIGZvciAobGV0IGkgPSAwOyBpIDwgbGVuOyBpICs9IDgpIHsKICAgIHN3YXAodGhpcywgaSwgaSArIDcpCiAgICBzd2FwKHRoaXMsIGkgKyAxLCBpICsgNikKICAgIHN3YXAodGhpcywgaSArIDIsIGkgKyA1KQogICAgc3dhcCh0aGlzLCBpICsgMywgaSArIDQpCiAgfQogIHJldHVybiB0aGlzCn0KCkJ1ZmZlci5wcm90b3R5cGUudG9TdHJpbmcgPSBmdW5jdGlvbiB0b1N0cmluZyAoKSB7CiAgY29uc3QgbGVuZ3RoID0gdGhpcy5sZW5ndGgKICBpZiAobGVuZ3RoID09PSAwKSByZXR1cm4gJycKICBpZiAoYXJndW1lbnRzLmxlbmd0aCA9PT0gMCkgcmV0dXJuIHV0ZjhTbGljZSh0aGlzLCAwLCBsZW5ndGgpCiAgcmV0dXJuIHNsb3dUb1N0cmluZy5hcHBseSh0aGlzLCBhcmd1bWVudHMpCn0KCkJ1ZmZlci5wcm90b3R5cGUudG9Mb2NhbGVTdHJpbmcgPSBCdWZmZXIucHJvdG90eXBlLnRvU3RyaW5nCgpCdWZmZXIucHJvdG90eXBlLmVxdWFscyA9IGZ1bmN0aW9uIGVxdWFscyAoYikgewogIGlmICghQnVmZmVyLmlzQnVmZmVyKGIpKSB0aHJvdyBuZXcgVHlwZUVycm9yKCdBcmd1bWVudCBtdXN0IGJlIGEgQnVmZmVyJykKICBpZiAodGhpcyA9PT0gYikgcmV0dXJuIHRydWUKICByZXR1cm4gQnVmZmVyLmNvbXBhcmUodGhpcywgYikgPT09IDAKfQoKQnVmZmVyLnByb3RvdHlwZS5pbnNwZWN0ID0gZnVuY3Rpb24gaW5zcGVjdCAoKSB7CiAgbGV0IHN0ciA9ICcnCiAgY29uc3QgbWF4ID0gZXhwb3J0cy5oMgogIHN0ciA9IHRoaXMudG9TdHJpbmcoJ2hleCcsIDAsIG1heCkucmVwbGFjZSgvKC57Mn0pL2csICckMSAnKS50cmltKCkKICBpZiAodGhpcy5sZW5ndGggPiBtYXgpIHN0ciArPSAnIC4uLiAnCiAgcmV0dXJuICc8QnVmZmVyICcgKyBzdHIgKyAnPicKfQppZiAoY3VzdG9tSW5zcGVjdFN5bWJvbCkgewogIEJ1ZmZlci5wcm90b3R5cGVbY3VzdG9tSW5zcGVjdFN5bWJvbF0gPSBCdWZmZXIucHJvdG90eXBlLmluc3BlY3QKfQoKQnVmZmVyLnByb3RvdHlwZS5jb21wYXJlID0gZnVuY3Rpb24gY29tcGFyZSAodGFyZ2V0LCBzdGFydCwgZW5kLCB0aGlzU3RhcnQsIHRoaXNFbmQpIHsKICBpZiAoaXNJbnN0YW5jZSh0YXJnZXQsIFVpbnQ4QXJyYXkpKSB7CiAgICB0YXJnZXQgPSBCdWZmZXIuZnJvbSh0YXJnZXQsIHRhcmdldC5vZmZzZXQsIHRhcmdldC5ieXRlTGVuZ3RoKQogIH0KICBpZiAoIUJ1ZmZlci5pc0J1ZmZlcih0YXJnZXQpKSB7CiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKAogICAgICAnVGhlICJ0YXJnZXQiIGFyZ3VtZW50IG11c3QgYmUgb25lIG9mIHR5cGUgQnVmZmVyIG9yIFVpbnQ4QXJyYXkuICcgKwogICAgICAnUmVjZWl2ZWQgdHlwZSAnICsgKHR5cGVvZiB0YXJnZXQpCiAgICApCiAgfQoKICBpZiAoc3RhcnQgPT09IHVuZGVmaW5lZCkgewogICAgc3RhcnQgPSAwCiAgfQogIGlmIChlbmQgPT09IHVuZGVmaW5lZCkgewogICAgZW5kID0gdGFyZ2V0ID8gdGFyZ2V0Lmxlbmd0aCA6IDAKICB9CiAgaWYgKHRoaXNTdGFydCA9PT0gdW5kZWZpbmVkKSB7CiAgICB0aGlzU3RhcnQgPSAwCiAgfQogIGlmICh0aGlzRW5kID09PSB1bmRlZmluZWQpIHsKICAgIHRoaXNFbmQgPSB0aGlzLmxlbmd0aAogIH0KCiAgaWYgKHN0YXJ0IDwgMCB8fCBlbmQgPiB0YXJnZXQubGVuZ3RoIHx8IHRoaXNTdGFydCA8IDAgfHwgdGhpc0VuZCA+IHRoaXMubGVuZ3RoKSB7CiAgICB0aHJvdyBuZXcgUmFuZ2VFcnJvcignb3V0IG9mIHJhbmdlIGluZGV4JykKICB9CgogIGlmICh0aGlzU3RhcnQgPj0gdGhpc0VuZCAmJiBzdGFydCA+PSBlbmQpIHsKICAgIHJldHVybiAwCiAgfQogIGlmICh0aGlzU3RhcnQgPj0gdGhpc0VuZCkgewogICAgcmV0dXJuIC0xCiAgfQogIGlmIChzdGFydCA+PSBlbmQpIHsKICAgIHJldHVybiAxCiAgfQoKICBzdGFydCA+Pj49IDAKICBlbmQgPj4+PSAwCiAgdGhpc1N0YXJ0ID4+Pj0gMAogIHRoaXNFbmQgPj4+PSAwCgogIGlmICh0aGlzID09PSB0YXJnZXQpIHJldHVybiAwCgogIGxldCB4ID0gdGhpc0VuZCAtIHRoaXNTdGFydAogIGxldCB5ID0gZW5kIC0gc3RhcnQKICBjb25zdCBsZW4gPSBNYXRoLm1pbih4LCB5KQoKICBjb25zdCB0aGlzQ29weSA9IHRoaXMuc2xpY2UodGhpc1N0YXJ0LCB0aGlzRW5kKQogIGNvbnN0IHRhcmdldENvcHkgPSB0YXJnZXQuc2xpY2Uoc3RhcnQsIGVuZCkKCiAgZm9yIChsZXQgaSA9IDA7IGkgPCBsZW47ICsraSkgewogICAgaWYgKHRoaXNDb3B5W2ldICE9PSB0YXJnZXRDb3B5W2ldKSB7CiAgICAgIHggPSB0aGlzQ29weVtpXQogICAgICB5ID0gdGFyZ2V0Q29weVtpXQogICAgICBicmVhawogICAgfQogIH0KCiAgaWYgKHggPCB5KSByZXR1cm4gLTEKICBpZiAoeSA8IHgpIHJldHVybiAxCiAgcmV0dXJuIDAKfQoKLy8gRmluZHMgZWl0aGVyIHRoZSBmaXJzdCBpbmRleCBvZiBgdmFsYCBpbiBgYnVmZmVyYCBhdCBvZmZzZXQgPj0gYGJ5dGVPZmZzZXRgLAovLyBPUiB0aGUgbGFzdCBpbmRleCBvZiBgdmFsYCBpbiBgYnVmZmVyYCBhdCBvZmZzZXQgPD0gYGJ5dGVPZmZzZXRgLgovLwovLyBBcmd1bWVudHM6Ci8vIC0gYnVmZmVyIC0gYSBCdWZmZXIgdG8gc2VhcmNoCi8vIC0gdmFsIC0gYSBzdHJpbmcsIEJ1ZmZlciwgb3IgbnVtYmVyCi8vIC0gYnl0ZU9mZnNldCAtIGFuIGluZGV4IGludG8gYGJ1ZmZlcmA7IHdpbGwgYmUgY2xhbXBlZCB0byBhbiBpbnQzMgovLyAtIGVuY29kaW5nIC0gYW4gb3B0aW9uYWwgZW5jb2RpbmcsIHJlbGV2YW50IGlzIHZhbCBpcyBhIHN0cmluZwovLyAtIGRpciAtIHRydWUgZm9yIGluZGV4T2YsIGZhbHNlIGZvciBsYXN0SW5kZXhPZgpmdW5jdGlvbiBiaWRpcmVjdGlvbmFsSW5kZXhPZiAoYnVmZmVyLCB2YWwsIGJ5dGVPZmZzZXQsIGVuY29kaW5nLCBkaXIpIHsKICAvLyBFbXB0eSBidWZmZXIgbWVhbnMgbm8gbWF0Y2gKICBpZiAoYnVmZmVyLmxlbmd0aCA9PT0gMCkgcmV0dXJuIC0xCgogIC8vIE5vcm1hbGl6ZSBieXRlT2Zmc2V0CiAgaWYgKHR5cGVvZiBieXRlT2Zmc2V0ID09PSAnc3RyaW5nJykgewogICAgZW5jb2RpbmcgPSBieXRlT2Zmc2V0CiAgICBieXRlT2Zmc2V0ID0gMAogIH0gZWxzZSBpZiAoYnl0ZU9mZnNldCA+IDB4N2ZmZmZmZmYpIHsKICAgIGJ5dGVPZmZzZXQgPSAweDdmZmZmZmZmCiAgfSBlbHNlIGlmIChieXRlT2Zmc2V0IDwgLTB4ODAwMDAwMDApIHsKICAgIGJ5dGVPZmZzZXQgPSAtMHg4MDAwMDAwMAogIH0KICBieXRlT2Zmc2V0ID0gK2J5dGVPZmZzZXQgLy8gQ29lcmNlIHRvIE51bWJlci4KICBpZiAobnVtYmVySXNOYU4oYnl0ZU9mZnNldCkpIHsKICAgIC8vIGJ5dGVPZmZzZXQ6IGl0IGl0J3MgdW5kZWZpbmVkLCBudWxsLCBOYU4sICJmb28iLCBldGMsIHNlYXJjaCB3aG9sZSBidWZmZXIKICAgIGJ5dGVPZmZzZXQgPSBkaXIgPyAwIDogKGJ1ZmZlci5sZW5ndGggLSAxKQogIH0KCiAgLy8gTm9ybWFsaXplIGJ5dGVPZmZzZXQ6IG5lZ2F0aXZlIG9mZnNldHMgc3RhcnQgZnJvbSB0aGUgZW5kIG9mIHRoZSBidWZmZXIKICBpZiAoYnl0ZU9mZnNldCA8IDApIGJ5dGVPZmZzZXQgPSBidWZmZXIubGVuZ3RoICsgYnl0ZU9mZnNldAogIGlmIChieXRlT2Zmc2V0ID49IGJ1ZmZlci5sZW5ndGgpIHsKICAgIGlmIChkaXIpIHJldHVybiAtMQogICAgZWxzZSBieXRlT2Zmc2V0ID0gYnVmZmVyLmxlbmd0aCAtIDEKICB9IGVsc2UgaWYgKGJ5dGVPZmZzZXQgPCAwKSB7CiAgICBpZiAoZGlyKSBieXRlT2Zmc2V0ID0gMAogICAgZWxzZSByZXR1cm4gLTEKICB9CgogIC8vIE5vcm1hbGl6ZSB2YWwKICBpZiAodHlwZW9mIHZhbCA9PT0gJ3N0cmluZycpIHsKICAgIHZhbCA9IEJ1ZmZlci5mcm9tKHZhbCwgZW5jb2RpbmcpCiAgfQoKICAvLyBGaW5hbGx5LCBzZWFyY2ggZWl0aGVyIGluZGV4T2YgKGlmIGRpciBpcyB0cnVlKSBvciBsYXN0SW5kZXhPZgogIGlmIChCdWZmZXIuaXNCdWZmZXIodmFsKSkgewogICAgLy8gU3BlY2lhbCBjYXNlOiBsb29raW5nIGZvciBlbXB0eSBzdHJpbmcvYnVmZmVyIGFsd2F5cyBmYWlscwogICAgaWYgKHZhbC5sZW5ndGggPT09IDApIHsKICAgICAgcmV0dXJuIC0xCiAgICB9CiAgICByZXR1cm4gYXJyYXlJbmRleE9mKGJ1ZmZlciwgdmFsLCBieXRlT2Zmc2V0LCBlbmNvZGluZywgZGlyKQogIH0gZWxzZSBpZiAodHlwZW9mIHZhbCA9PT0gJ251bWJlcicpIHsKICAgIHZhbCA9IHZhbCAmIDB4RkYgLy8gU2VhcmNoIGZvciBhIGJ5dGUgdmFsdWUgWzAtMjU1XQogICAgaWYgKHR5cGVvZiBVaW50OEFycmF5LnByb3RvdHlwZS5pbmRleE9mID09PSAnZnVuY3Rpb24nKSB7CiAgICAgIGlmIChkaXIpIHsKICAgICAgICByZXR1cm4gVWludDhBcnJheS5wcm90b3R5cGUuaW5kZXhPZi5jYWxsKGJ1ZmZlciwgdmFsLCBieXRlT2Zmc2V0KQogICAgICB9IGVsc2UgewogICAgICAgIHJldHVybiBVaW50OEFycmF5LnByb3RvdHlwZS5sYXN0SW5kZXhPZi5jYWxsKGJ1ZmZlciwgdmFsLCBieXRlT2Zmc2V0KQogICAgICB9CiAgICB9CiAgICByZXR1cm4gYXJyYXlJbmRleE9mKGJ1ZmZlciwgW3ZhbF0sIGJ5dGVPZmZzZXQsIGVuY29kaW5nLCBkaXIpCiAgfQoKICB0aHJvdyBuZXcgVHlwZUVycm9yKCd2YWwgbXVzdCBiZSBzdHJpbmcsIG51bWJlciBvciBCdWZmZXInKQp9CgpmdW5jdGlvbiBhcnJheUluZGV4T2YgKGFyciwgdmFsLCBieXRlT2Zmc2V0LCBlbmNvZGluZywgZGlyKSB7CiAgbGV0IGluZGV4U2l6ZSA9IDEKICBsZXQgYXJyTGVuZ3RoID0gYXJyLmxlbmd0aAogIGxldCB2YWxMZW5ndGggPSB2YWwubGVuZ3RoCgogIGlmIChlbmNvZGluZyAhPT0gdW5kZWZpbmVkKSB7CiAgICBlbmNvZGluZyA9IFN0cmluZyhlbmNvZGluZykudG9Mb3dlckNhc2UoKQogICAgaWYgKGVuY29kaW5nID09PSAndWNzMicgfHwgZW5jb2RpbmcgPT09ICd1Y3MtMicgfHwKICAgICAgICBlbmNvZGluZyA9PT0gJ3V0ZjE2bGUnIHx8IGVuY29kaW5nID09PSAndXRmLTE2bGUnKSB7CiAgICAgIGlmIChhcnIubGVuZ3RoIDwgMiB8fCB2YWwubGVuZ3RoIDwgMikgewogICAgICAgIHJldHVybiAtMQogICAgICB9CiAgICAgIGluZGV4U2l6ZSA9IDIKICAgICAgYXJyTGVuZ3RoIC89IDIKICAgICAgdmFsTGVuZ3RoIC89IDIKICAgICAgYnl0ZU9mZnNldCAvPSAyCiAgICB9CiAgfQoKICBmdW5jdGlvbiByZWFkIChidWYsIGkpIHsKICAgIGlmIChpbmRleFNpemUgPT09IDEpIHsKICAgICAgcmV0dXJuIGJ1ZltpXQogICAgfSBlbHNlIHsKICAgICAgcmV0dXJuIGJ1Zi5yZWFkVUludDE2QkUoaSAqIGluZGV4U2l6ZSkKICAgIH0KICB9CgogIGxldCBpCiAgaWYgKGRpcikgewogICAgbGV0IGZvdW5kSW5kZXggPSAtMQogICAgZm9yIChpID0gYnl0ZU9mZnNldDsgaSA8IGFyckxlbmd0aDsgaSsrKSB7CiAgICAgIGlmIChyZWFkKGFyciwgaSkgPT09IHJlYWQodmFsLCBmb3VuZEluZGV4ID09PSAtMSA/IDAgOiBpIC0gZm91bmRJbmRleCkpIHsKICAgICAgICBpZiAoZm91bmRJbmRleCA9PT0gLTEpIGZvdW5kSW5kZXggPSBpCiAgICAgICAgaWYgKGkgLSBmb3VuZEluZGV4ICsgMSA9PT0gdmFsTGVuZ3RoKSByZXR1cm4gZm91bmRJbmRleCAqIGluZGV4U2l6ZQogICAgICB9IGVsc2UgewogICAgICAgIGlmIChmb3VuZEluZGV4ICE9PSAtMSkgaSAtPSBpIC0gZm91bmRJbmRleAogICAgICAgIGZvdW5kSW5kZXggPSAtMQogICAgICB9CiAgICB9CiAgfSBlbHNlIHsKICAgIGlmIChieXRlT2Zmc2V0ICsgdmFsTGVuZ3RoID4gYXJyTGVuZ3RoKSBieXRlT2Zmc2V0ID0gYXJyTGVuZ3RoIC0gdmFsTGVuZ3RoCiAgICBmb3IgKGkgPSBieXRlT2Zmc2V0OyBpID49IDA7IGktLSkgewogICAgICBsZXQgZm91bmQgPSB0cnVlCiAgICAgIGZvciAobGV0IGogPSAwOyBqIDwgdmFsTGVuZ3RoOyBqKyspIHsKICAgICAgICBpZiAocmVhZChhcnIsIGkgKyBqKSAhPT0gcmVhZCh2YWwsIGopKSB7CiAgICAgICAgICBmb3VuZCA9IGZhbHNlCiAgICAgICAgICBicmVhawogICAgICAgIH0KICAgICAgfQogICAgICBpZiAoZm91bmQpIHJldHVybiBpCiAgICB9CiAgfQoKICByZXR1cm4gLTEKfQoKQnVmZmVyLnByb3RvdHlwZS5pbmNsdWRlcyA9IGZ1bmN0aW9uIGluY2x1ZGVzICh2YWwsIGJ5dGVPZmZzZXQsIGVuY29kaW5nKSB7CiAgcmV0dXJuIHRoaXMuaW5kZXhPZih2YWwsIGJ5dGVPZmZzZXQsIGVuY29kaW5nKSAhPT0gLTEKfQoKQnVmZmVyLnByb3RvdHlwZS5pbmRleE9mID0gZnVuY3Rpb24gaW5kZXhPZiAodmFsLCBieXRlT2Zmc2V0LCBlbmNvZGluZykgewogIHJldHVybiBiaWRpcmVjdGlvbmFsSW5kZXhPZih0aGlzLCB2YWwsIGJ5dGVPZmZzZXQsIGVuY29kaW5nLCB0cnVlKQp9CgpCdWZmZXIucHJvdG90eXBlLmxhc3RJbmRleE9mID0gZnVuY3Rpb24gbGFzdEluZGV4T2YgKHZhbCwgYnl0ZU9mZnNldCwgZW5jb2RpbmcpIHsKICByZXR1cm4gYmlkaXJlY3Rpb25hbEluZGV4T2YodGhpcywgdmFsLCBieXRlT2Zmc2V0LCBlbmNvZGluZywgZmFsc2UpCn0KCmZ1bmN0aW9uIGhleFdyaXRlIChidWYsIHN0cmluZywgb2Zmc2V0LCBsZW5ndGgpIHsKICBvZmZzZXQgPSBOdW1iZXIob2Zmc2V0KSB8fCAwCiAgY29uc3QgcmVtYWluaW5nID0gYnVmLmxlbmd0aCAtIG9mZnNldAogIGlmICghbGVuZ3RoKSB7CiAgICBsZW5ndGggPSByZW1haW5pbmcKICB9IGVsc2UgewogICAgbGVuZ3RoID0gTnVtYmVyKGxlbmd0aCkKICAgIGlmIChsZW5ndGggPiByZW1haW5pbmcpIHsKICAgICAgbGVuZ3RoID0gcmVtYWluaW5nCiAgICB9CiAgfQoKICBjb25zdCBzdHJMZW4gPSBzdHJpbmcubGVuZ3RoCgogIGlmIChsZW5ndGggPiBzdHJMZW4gLyAyKSB7CiAgICBsZW5ndGggPSBzdHJMZW4gLyAyCiAgfQogIGxldCBpCiAgZm9yIChpID0gMDsgaSA8IGxlbmd0aDsgKytpKSB7CiAgICBjb25zdCBwYXJzZWQgPSBwYXJzZUludChzdHJpbmcuc3Vic3RyKGkgKiAyLCAyKSwgMTYpCiAgICBpZiAobnVtYmVySXNOYU4ocGFyc2VkKSkgcmV0dXJuIGkKICAgIGJ1ZltvZmZzZXQgKyBpXSA9IHBhcnNlZAogIH0KICByZXR1cm4gaQp9CgpmdW5jdGlvbiB1dGY4V3JpdGUgKGJ1Ziwgc3RyaW5nLCBvZmZzZXQsIGxlbmd0aCkgewogIHJldHVybiBibGl0QnVmZmVyKHV0ZjhUb0J5dGVzKHN0cmluZywgYnVmLmxlbmd0aCAtIG9mZnNldCksIGJ1Ziwgb2Zmc2V0LCBsZW5ndGgpCn0KCmZ1bmN0aW9uIGFzY2lpV3JpdGUgKGJ1Ziwgc3RyaW5nLCBvZmZzZXQsIGxlbmd0aCkgewogIHJldHVybiBibGl0QnVmZmVyKGFzY2lpVG9CeXRlcyhzdHJpbmcpLCBidWYsIG9mZnNldCwgbGVuZ3RoKQp9CgpmdW5jdGlvbiBiYXNlNjRXcml0ZSAoYnVmLCBzdHJpbmcsIG9mZnNldCwgbGVuZ3RoKSB7CiAgcmV0dXJuIGJsaXRCdWZmZXIoYmFzZTY0VG9CeXRlcyhzdHJpbmcpLCBidWYsIG9mZnNldCwgbGVuZ3RoKQp9CgpmdW5jdGlvbiB1Y3MyV3JpdGUgKGJ1Ziwgc3RyaW5nLCBvZmZzZXQsIGxlbmd0aCkgewogIHJldHVybiBibGl0QnVmZmVyKHV0ZjE2bGVUb0J5dGVzKHN0cmluZywgYnVmLmxlbmd0aCAtIG9mZnNldCksIGJ1Ziwgb2Zmc2V0LCBsZW5ndGgpCn0KCkJ1ZmZlci5wcm90b3R5cGUud3JpdGUgPSBmdW5jdGlvbiB3cml0ZSAoc3RyaW5nLCBvZmZzZXQsIGxlbmd0aCwgZW5jb2RpbmcpIHsKICAvLyBCdWZmZXIjd3JpdGUoc3RyaW5nKQogIGlmIChvZmZzZXQgPT09IHVuZGVmaW5lZCkgewogICAgZW5jb2RpbmcgPSAndXRmOCcKICAgIGxlbmd0aCA9IHRoaXMubGVuZ3RoCiAgICBvZmZzZXQgPSAwCiAgLy8gQnVmZmVyI3dyaXRlKHN0cmluZywgZW5jb2RpbmcpCiAgfSBlbHNlIGlmIChsZW5ndGggPT09IHVuZGVmaW5lZCAmJiB0eXBlb2Ygb2Zmc2V0ID09PSAnc3RyaW5nJykgewogICAgZW5jb2RpbmcgPSBvZmZzZXQKICAgIGxlbmd0aCA9IHRoaXMubGVuZ3RoCiAgICBvZmZzZXQgPSAwCiAgLy8gQnVmZmVyI3dyaXRlKHN0cmluZywgb2Zmc2V0WywgbGVuZ3RoXVssIGVuY29kaW5nXSkKICB9IGVsc2UgaWYgKGlzRmluaXRlKG9mZnNldCkpIHsKICAgIG9mZnNldCA9IG9mZnNldCA+Pj4gMAogICAgaWYgKGlzRmluaXRlKGxlbmd0aCkpIHsKICAgICAgbGVuZ3RoID0gbGVuZ3RoID4+PiAwCiAgICAgIGlmIChlbmNvZGluZyA9PT0gdW5kZWZpbmVkKSBlbmNvZGluZyA9ICd1dGY4JwogICAgfSBlbHNlIHsKICAgICAgZW5jb2RpbmcgPSBsZW5ndGgKICAgICAgbGVuZ3RoID0gdW5kZWZpbmVkCiAgICB9CiAgfSBlbHNlIHsKICAgIHRocm93IG5ldyBFcnJvcigKICAgICAgJ0J1ZmZlci53cml0ZShzdHJpbmcsIGVuY29kaW5nLCBvZmZzZXRbLCBsZW5ndGhdKSBpcyBubyBsb25nZXIgc3VwcG9ydGVkJwogICAgKQogIH0KCiAgY29uc3QgcmVtYWluaW5nID0gdGhpcy5sZW5ndGggLSBvZmZzZXQKICBpZiAobGVuZ3RoID09PSB1bmRlZmluZWQgfHwgbGVuZ3RoID4gcmVtYWluaW5nKSBsZW5ndGggPSByZW1haW5pbmcKCiAgaWYgKChzdHJpbmcubGVuZ3RoID4gMCAmJiAobGVuZ3RoIDwgMCB8fCBvZmZzZXQgPCAwKSkgfHwgb2Zmc2V0ID4gdGhpcy5sZW5ndGgpIHsKICAgIHRocm93IG5ldyBSYW5nZUVycm9yKCdBdHRlbXB0IHRvIHdyaXRlIG91dHNpZGUgYnVmZmVyIGJvdW5kcycpCiAgfQoKICBpZiAoIWVuY29kaW5nKSBlbmNvZGluZyA9ICd1dGY4JwoKICBsZXQgbG93ZXJlZENhc2UgPSBmYWxzZQogIGZvciAoOzspIHsKICAgIHN3aXRjaCAoZW5jb2RpbmcpIHsKICAgICAgY2FzZSAnaGV4JzoKICAgICAgICByZXR1cm4gaGV4V3JpdGUodGhpcywgc3RyaW5nLCBvZmZzZXQsIGxlbmd0aCkKCiAgICAgIGNhc2UgJ3V0ZjgnOgogICAgICBjYXNlICd1dGYtOCc6CiAgICAgICAgcmV0dXJuIHV0ZjhXcml0ZSh0aGlzLCBzdHJpbmcsIG9mZnNldCwgbGVuZ3RoKQoKICAgICAgY2FzZSAnYXNjaWknOgogICAgICBjYXNlICdsYXRpbjEnOgogICAgICBjYXNlICdiaW5hcnknOgogICAgICAgIHJldHVybiBhc2NpaVdyaXRlKHRoaXMsIHN0cmluZywgb2Zmc2V0LCBsZW5ndGgpCgogICAgICBjYXNlICdiYXNlNjQnOgogICAgICAgIC8vIFdhcm5pbmc6IG1heExlbmd0aCBub3QgdGFrZW4gaW50byBhY2NvdW50IGluIGJhc2U2NFdyaXRlCiAgICAgICAgcmV0dXJuIGJhc2U2NFdyaXRlKHRoaXMsIHN0cmluZywgb2Zmc2V0LCBsZW5ndGgpCgogICAgICBjYXNlICd1Y3MyJzoKICAgICAgY2FzZSAndWNzLTInOgogICAgICBjYXNlICd1dGYxNmxlJzoKICAgICAgY2FzZSAndXRmLTE2bGUnOgogICAgICAgIHJldHVybiB1Y3MyV3JpdGUodGhpcywgc3RyaW5nLCBvZmZzZXQsIGxlbmd0aCkKCiAgICAgIGRlZmF1bHQ6CiAgICAgICAgaWYgKGxvd2VyZWRDYXNlKSB0aHJvdyBuZXcgVHlwZUVycm9yKCdVbmtub3duIGVuY29kaW5nOiAnICsgZW5jb2RpbmcpCiAgICAgICAgZW5jb2RpbmcgPSAoJycgKyBlbmNvZGluZykudG9Mb3dlckNhc2UoKQogICAgICAgIGxvd2VyZWRDYXNlID0gdHJ1ZQogICAgfQogIH0KfQoKQnVmZmVyLnByb3RvdHlwZS50b0pTT04gPSBmdW5jdGlvbiB0b0pTT04gKCkgewogIHJldHVybiB7CiAgICB0eXBlOiAnQnVmZmVyJywKICAgIGRhdGE6IEFycmF5LnByb3RvdHlwZS5zbGljZS5jYWxsKHRoaXMuX2FyciB8fCB0aGlzLCAwKQogIH0KfQoKZnVuY3Rpb24gYmFzZTY0U2xpY2UgKGJ1Ziwgc3RhcnQsIGVuZCkgewogIGlmIChzdGFydCA9PT0gMCAmJiBlbmQgPT09IGJ1Zi5sZW5ndGgpIHsKICAgIHJldHVybiBiYXNlNjQuZnJvbUJ5dGVBcnJheShidWYpCiAgfSBlbHNlIHsKICAgIHJldHVybiBiYXNlNjQuZnJvbUJ5dGVBcnJheShidWYuc2xpY2Uoc3RhcnQsIGVuZCkpCiAgfQp9CgpmdW5jdGlvbiB1dGY4U2xpY2UgKGJ1Ziwgc3RhcnQsIGVuZCkgewogIGVuZCA9IE1hdGgubWluKGJ1Zi5sZW5ndGgsIGVuZCkKICBjb25zdCByZXMgPSBbXQoKICBsZXQgaSA9IHN0YXJ0CiAgd2hpbGUgKGkgPCBlbmQpIHsKICAgIGNvbnN0IGZpcnN0Qnl0ZSA9IGJ1ZltpXQogICAgbGV0IGNvZGVQb2ludCA9IG51bGwKICAgIGxldCBieXRlc1BlclNlcXVlbmNlID0gKGZpcnN0Qnl0ZSA+IDB4RUYpCiAgICAgID8gNAogICAgICA6IChmaXJzdEJ5dGUgPiAweERGKQogICAgICAgICAgPyAzCiAgICAgICAgICA6IChmaXJzdEJ5dGUgPiAweEJGKQogICAgICAgICAgICAgID8gMgogICAgICAgICAgICAgIDogMQoKICAgIGlmIChpICsgYnl0ZXNQZXJTZXF1ZW5jZSA8PSBlbmQpIHsKICAgICAgbGV0IHNlY29uZEJ5dGUsIHRoaXJkQnl0ZSwgZm91cnRoQnl0ZSwgdGVtcENvZGVQb2ludAoKICAgICAgc3dpdGNoIChieXRlc1BlclNlcXVlbmNlKSB7CiAgICAgICAgY2FzZSAxOgogICAgICAgICAgaWYgKGZpcnN0Qnl0ZSA8IDB4ODApIHsKICAgICAgICAgICAgY29kZVBvaW50ID0gZmlyc3RCeXRlCiAgICAgICAgICB9CiAgICAgICAgICBicmVhawogICAgICAgIGNhc2UgMjoKICAgICAgICAgIHNlY29uZEJ5dGUgPSBidWZbaSArIDFdCiAgICAgICAgICBpZiAoKHNlY29uZEJ5dGUgJiAweEMwKSA9PT0gMHg4MCkgewogICAgICAgICAgICB0ZW1wQ29kZVBvaW50ID0gKGZpcnN0Qnl0ZSAmIDB4MUYpIDw8IDB4NiB8IChzZWNvbmRCeXRlICYgMHgzRikKICAgICAgICAgICAgaWYgKHRlbXBDb2RlUG9pbnQgPiAweDdGKSB7CiAgICAgICAgICAgICAgY29kZVBvaW50ID0gdGVtcENvZGVQb2ludAogICAgICAgICAgICB9CiAgICAgICAgICB9CiAgICAgICAgICBicmVhawogICAgICAgIGNhc2UgMzoKICAgICAgICAgIHNlY29uZEJ5dGUgPSBidWZbaSArIDFdCiAgICAgICAgICB0aGlyZEJ5dGUgPSBidWZbaSArIDJdCiAgICAgICAgICBpZiAoKHNlY29uZEJ5dGUgJiAweEMwKSA9PT0gMHg4MCAmJiAodGhpcmRCeXRlICYgMHhDMCkgPT09IDB4ODApIHsKICAgICAgICAgICAgdGVtcENvZGVQb2ludCA9IChmaXJzdEJ5dGUgJiAweEYpIDw8IDB4QyB8IChzZWNvbmRCeXRlICYgMHgzRikgPDwgMHg2IHwgKHRoaXJkQnl0ZSAmIDB4M0YpCiAgICAgICAgICAgIGlmICh0ZW1wQ29kZVBvaW50ID4gMHg3RkYgJiYgKHRlbXBDb2RlUG9pbnQgPCAweEQ4MDAgfHwgdGVtcENvZGVQb2ludCA+IDB4REZGRikpIHsKICAgICAgICAgICAgICBjb2RlUG9pbnQgPSB0ZW1wQ29kZVBvaW50CiAgICAgICAgICAgIH0KICAgICAgICAgIH0KICAgICAgICAgIGJyZWFrCiAgICAgICAgY2FzZSA0OgogICAgICAgICAgc2Vjb25kQnl0ZSA9IGJ1ZltpICsgMV0KICAgICAgICAgIHRoaXJkQnl0ZSA9IGJ1ZltpICsgMl0KICAgICAgICAgIGZvdXJ0aEJ5dGUgPSBidWZbaSArIDNdCiAgICAgICAgICBpZiAoKHNlY29uZEJ5dGUgJiAweEMwKSA9PT0gMHg4MCAmJiAodGhpcmRCeXRlICYgMHhDMCkgPT09IDB4ODAgJiYgKGZvdXJ0aEJ5dGUgJiAweEMwKSA9PT0gMHg4MCkgewogICAgICAgICAgICB0ZW1wQ29kZVBvaW50ID0gKGZpcnN0Qnl0ZSAmIDB4RikgPDwgMHgxMiB8IChzZWNvbmRCeXRlICYgMHgzRikgPDwgMHhDIHwgKHRoaXJkQnl0ZSAmIDB4M0YpIDw8IDB4NiB8IChmb3VydGhCeXRlICYgMHgzRikKICAgICAgICAgICAgaWYgKHRlbXBDb2RlUG9pbnQgPiAweEZGRkYgJiYgdGVtcENvZGVQb2ludCA8IDB4MTEwMDAwKSB7CiAgICAgICAgICAgICAgY29kZVBvaW50ID0gdGVtcENvZGVQb2ludAogICAgICAgICAgICB9CiAgICAgICAgICB9CiAgICAgIH0KICAgIH0KCiAgICBpZiAoY29kZVBvaW50ID09PSBudWxsKSB7CiAgICAgIC8vIHdlIGRpZCBub3QgZ2VuZXJhdGUgYSB2YWxpZCBjb2RlUG9pbnQgc28gaW5zZXJ0IGEKICAgICAgLy8gcmVwbGFjZW1lbnQgY2hhciAoVStGRkZEKSBhbmQgYWR2YW5jZSBvbmx5IDEgYnl0ZQogICAgICBjb2RlUG9pbnQgPSAweEZGRkQKICAgICAgYnl0ZXNQZXJTZXF1ZW5jZSA9IDEKICAgIH0gZWxzZSBpZiAoY29kZVBvaW50ID4gMHhGRkZGKSB7CiAgICAgIC8vIGVuY29kZSB0byB1dGYxNiAoc3Vycm9nYXRlIHBhaXIgZGFuY2UpCiAgICAgIGNvZGVQb2ludCAtPSAweDEwMDAwCiAgICAgIHJlcy5wdXNoKGNvZGVQb2ludCA+Pj4gMTAgJiAweDNGRiB8IDB4RDgwMCkKICAgICAgY29kZVBvaW50ID0gMHhEQzAwIHwgY29kZVBvaW50ICYgMHgzRkYKICAgIH0KCiAgICByZXMucHVzaChjb2RlUG9pbnQpCiAgICBpICs9IGJ5dGVzUGVyU2VxdWVuY2UKICB9CgogIHJldHVybiBkZWNvZGVDb2RlUG9pbnRzQXJyYXkocmVzKQp9CgovLyBCYXNlZCBvbiBodHRwOi8vc3RhY2tvdmVyZmxvdy5jb20vYS8yMjc0NzI3Mi82ODA3NDIsIHRoZSBicm93c2VyIHdpdGgKLy8gdGhlIGxvd2VzdCBsaW1pdCBpcyBDaHJvbWUsIHdpdGggMHgxMDAwMCBhcmdzLgovLyBXZSBnbyAxIG1hZ25pdHVkZSBsZXNzLCBmb3Igc2FmZXR5CmNvbnN0IE1BWF9BUkdVTUVOVFNfTEVOR1RIID0gMHgxMDAwCgpmdW5jdGlvbiBkZWNvZGVDb2RlUG9pbnRzQXJyYXkgKGNvZGVQb2ludHMpIHsKICBjb25zdCBsZW4gPSBjb2RlUG9pbnRzLmxlbmd0aAogIGlmIChsZW4gPD0gTUFYX0FSR1VNRU5UU19MRU5HVEgpIHsKICAgIHJldHVybiBTdHJpbmcuZnJvbUNoYXJDb2RlLmFwcGx5KFN0cmluZywgY29kZVBvaW50cykgLy8gYXZvaWQgZXh0cmEgc2xpY2UoKQogIH0KCiAgLy8gRGVjb2RlIGluIGNodW5rcyB0byBhdm9pZCAiY2FsbCBzdGFjayBzaXplIGV4Y2VlZGVkIi4KICBsZXQgcmVzID0gJycKICBsZXQgaSA9IDAKICB3aGlsZSAoaSA8IGxlbikgewogICAgcmVzICs9IFN0cmluZy5mcm9tQ2hhckNvZGUuYXBwbHkoCiAgICAgIFN0cmluZywKICAgICAgY29kZVBvaW50cy5zbGljZShpLCBpICs9IE1BWF9BUkdVTUVOVFNfTEVOR1RIKQogICAgKQogIH0KICByZXR1cm4gcmVzCn0KCmZ1bmN0aW9uIGFzY2lpU2xpY2UgKGJ1Ziwgc3RhcnQsIGVuZCkgewogIGxldCByZXQgPSAnJwogIGVuZCA9IE1hdGgubWluKGJ1Zi5sZW5ndGgsIGVuZCkKCiAgZm9yIChsZXQgaSA9IHN0YXJ0OyBpIDwgZW5kOyArK2kpIHsKICAgIHJldCArPSBTdHJpbmcuZnJvbUNoYXJDb2RlKGJ1ZltpXSAmIDB4N0YpCiAgfQogIHJldHVybiByZXQKfQoKZnVuY3Rpb24gbGF0aW4xU2xpY2UgKGJ1Ziwgc3RhcnQsIGVuZCkgewogIGxldCByZXQgPSAnJwogIGVuZCA9IE1hdGgubWluKGJ1Zi5sZW5ndGgsIGVuZCkKCiAgZm9yIChsZXQgaSA9IHN0YXJ0OyBpIDwgZW5kOyArK2kpIHsKICAgIHJldCArPSBTdHJpbmcuZnJvbUNoYXJDb2RlKGJ1ZltpXSkKICB9CiAgcmV0dXJuIHJldAp9CgpmdW5jdGlvbiBoZXhTbGljZSAoYnVmLCBzdGFydCwgZW5kKSB7CiAgY29uc3QgbGVuID0gYnVmLmxlbmd0aAoKICBpZiAoIXN0YXJ0IHx8IHN0YXJ0IDwgMCkgc3RhcnQgPSAwCiAgaWYgKCFlbmQgfHwgZW5kIDwgMCB8fCBlbmQgPiBsZW4pIGVuZCA9IGxlbgoKICBsZXQgb3V0ID0gJycKICBmb3IgKGxldCBpID0gc3RhcnQ7IGkgPCBlbmQ7ICsraSkgewogICAgb3V0ICs9IGhleFNsaWNlTG9va3VwVGFibGVbYnVmW2ldXQogIH0KICByZXR1cm4gb3V0Cn0KCmZ1bmN0aW9uIHV0ZjE2bGVTbGljZSAoYnVmLCBzdGFydCwgZW5kKSB7CiAgY29uc3QgYnl0ZXMgPSBidWYuc2xpY2Uoc3RhcnQsIGVuZCkKICBsZXQgcmVzID0gJycKICAvLyBJZiBieXRlcy5sZW5ndGggaXMgb2RkLCB0aGUgbGFzdCA4IGJpdHMgbXVzdCBiZSBpZ25vcmVkIChzYW1lIGFzIG5vZGUuanMpCiAgZm9yIChsZXQgaSA9IDA7IGkgPCBieXRlcy5sZW5ndGggLSAxOyBpICs9IDIpIHsKICAgIHJlcyArPSBTdHJpbmcuZnJvbUNoYXJDb2RlKGJ5dGVzW2ldICsgKGJ5dGVzW2kgKyAxXSAqIDI1NikpCiAgfQogIHJldHVybiByZXMKfQoKQnVmZmVyLnByb3RvdHlwZS5zbGljZSA9IGZ1bmN0aW9uIHNsaWNlIChzdGFydCwgZW5kKSB7CiAgY29uc3QgbGVuID0gdGhpcy5sZW5ndGgKICBzdGFydCA9IH5+c3RhcnQKICBlbmQgPSBlbmQgPT09IHVuZGVmaW5lZCA/IGxlbiA6IH5+ZW5kCgogIGlmIChzdGFydCA8IDApIHsKICAgIHN0YXJ0ICs9IGxlbgogICAgaWYgKHN0YXJ0IDwgMCkgc3RhcnQgPSAwCiAgfSBlbHNlIGlmIChzdGFydCA+IGxlbikgewogICAgc3RhcnQgPSBsZW4KICB9CgogIGlmIChlbmQgPCAwKSB7CiAgICBlbmQgKz0gbGVuCiAgICBpZiAoZW5kIDwgMCkgZW5kID0gMAogIH0gZWxzZSBpZiAoZW5kID4gbGVuKSB7CiAgICBlbmQgPSBsZW4KICB9CgogIGlmIChlbmQgPCBzdGFydCkgZW5kID0gc3RhcnQKCiAgY29uc3QgbmV3QnVmID0gdGhpcy5zdWJhcnJheShzdGFydCwgZW5kKQogIC8vIFJldHVybiBhbiBhdWdtZW50ZWQgYFVpbnQ4QXJyYXlgIGluc3RhbmNlCiAgT2JqZWN0LnNldFByb3RvdHlwZU9mKG5ld0J1ZiwgQnVmZmVyLnByb3RvdHlwZSkKCiAgcmV0dXJuIG5ld0J1Zgp9CgovKgogKiBOZWVkIHRvIG1ha2Ugc3VyZSB0aGF0IGJ1ZmZlciBpc24ndCB0cnlpbmcgdG8gd3JpdGUgb3V0IG9mIGJvdW5kcy4KICovCmZ1bmN0aW9uIGNoZWNrT2Zmc2V0IChvZmZzZXQsIGV4dCwgbGVuZ3RoKSB7CiAgaWYgKChvZmZzZXQgJSAxKSAhPT0gMCB8fCBvZmZzZXQgPCAwKSB0aHJvdyBuZXcgUmFuZ2VFcnJvcignb2Zmc2V0IGlzIG5vdCB1aW50JykKICBpZiAob2Zmc2V0ICsgZXh0ID4gbGVuZ3RoKSB0aHJvdyBuZXcgUmFuZ2VFcnJvcignVHJ5aW5nIHRvIGFjY2VzcyBiZXlvbmQgYnVmZmVyIGxlbmd0aCcpCn0KCkJ1ZmZlci5wcm90b3R5cGUucmVhZFVpbnRMRSA9CkJ1ZmZlci5wcm90b3R5cGUucmVhZFVJbnRMRSA9IGZ1bmN0aW9uIHJlYWRVSW50TEUgKG9mZnNldCwgYnl0ZUxlbmd0aCwgbm9Bc3NlcnQpIHsKICBvZmZzZXQgPSBvZmZzZXQgPj4+IDAKICBieXRlTGVuZ3RoID0gYnl0ZUxlbmd0aCA+Pj4gMAogIGlmICghbm9Bc3NlcnQpIGNoZWNrT2Zmc2V0KG9mZnNldCwgYnl0ZUxlbmd0aCwgdGhpcy5sZW5ndGgpCgogIGxldCB2YWwgPSB0aGlzW29mZnNldF0KICBsZXQgbXVsID0gMQogIGxldCBpID0gMAogIHdoaWxlICgrK2kgPCBieXRlTGVuZ3RoICYmIChtdWwgKj0gMHgxMDApKSB7CiAgICB2YWwgKz0gdGhpc1tvZmZzZXQgKyBpXSAqIG11bAogIH0KCiAgcmV0dXJuIHZhbAp9CgpCdWZmZXIucHJvdG90eXBlLnJlYWRVaW50QkUgPQpCdWZmZXIucHJvdG90eXBlLnJlYWRVSW50QkUgPSBmdW5jdGlvbiByZWFkVUludEJFIChvZmZzZXQsIGJ5dGVMZW5ndGgsIG5vQXNzZXJ0KSB7CiAgb2Zmc2V0ID0gb2Zmc2V0ID4+PiAwCiAgYnl0ZUxlbmd0aCA9IGJ5dGVMZW5ndGggPj4+IDAKICBpZiAoIW5vQXNzZXJ0KSB7CiAgICBjaGVja09mZnNldChvZmZzZXQsIGJ5dGVMZW5ndGgsIHRoaXMubGVuZ3RoKQogIH0KCiAgbGV0IHZhbCA9IHRoaXNbb2Zmc2V0ICsgLS1ieXRlTGVuZ3RoXQogIGxldCBtdWwgPSAxCiAgd2hpbGUgKGJ5dGVMZW5ndGggPiAwICYmIChtdWwgKj0gMHgxMDApKSB7CiAgICB2YWwgKz0gdGhpc1tvZmZzZXQgKyAtLWJ5dGVMZW5ndGhdICogbXVsCiAgfQoKICByZXR1cm4gdmFsCn0KCkJ1ZmZlci5wcm90b3R5cGUucmVhZFVpbnQ4ID0KQnVmZmVyLnByb3RvdHlwZS5yZWFkVUludDggPSBmdW5jdGlvbiByZWFkVUludDggKG9mZnNldCwgbm9Bc3NlcnQpIHsKICBvZmZzZXQgPSBvZmZzZXQgPj4+IDAKICBpZiAoIW5vQXNzZXJ0KSBjaGVja09mZnNldChvZmZzZXQsIDEsIHRoaXMubGVuZ3RoKQogIHJldHVybiB0aGlzW29mZnNldF0KfQoKQnVmZmVyLnByb3RvdHlwZS5yZWFkVWludDE2TEUgPQpCdWZmZXIucHJvdG90eXBlLnJlYWRVSW50MTZMRSA9IGZ1bmN0aW9uIHJlYWRVSW50MTZMRSAob2Zmc2V0LCBub0Fzc2VydCkgewogIG9mZnNldCA9IG9mZnNldCA+Pj4gMAogIGlmICghbm9Bc3NlcnQpIGNoZWNrT2Zmc2V0KG9mZnNldCwgMiwgdGhpcy5sZW5ndGgpCiAgcmV0dXJuIHRoaXNbb2Zmc2V0XSB8ICh0aGlzW29mZnNldCArIDFdIDw8IDgpCn0KCkJ1ZmZlci5wcm90b3R5cGUucmVhZFVpbnQxNkJFID0KQnVmZmVyLnByb3RvdHlwZS5yZWFkVUludDE2QkUgPSBmdW5jdGlvbiByZWFkVUludDE2QkUgKG9mZnNldCwgbm9Bc3NlcnQpIHsKICBvZmZzZXQgPSBvZmZzZXQgPj4+IDAKICBpZiAoIW5vQXNzZXJ0KSBjaGVja09mZnNldChvZmZzZXQsIDIsIHRoaXMubGVuZ3RoKQogIHJldHVybiAodGhpc1tvZmZzZXRdIDw8IDgpIHwgdGhpc1tvZmZzZXQgKyAxXQp9CgpCdWZmZXIucHJvdG90eXBlLnJlYWRVaW50MzJMRSA9CkJ1ZmZlci5wcm90b3R5cGUucmVhZFVJbnQzMkxFID0gZnVuY3Rpb24gcmVhZFVJbnQzMkxFIChvZmZzZXQsIG5vQXNzZXJ0KSB7CiAgb2Zmc2V0ID0gb2Zmc2V0ID4+PiAwCiAgaWYgKCFub0Fzc2VydCkgY2hlY2tPZmZzZXQob2Zmc2V0LCA0LCB0aGlzLmxlbmd0aCkKCiAgcmV0dXJuICgodGhpc1tvZmZzZXRdKSB8CiAgICAgICh0aGlzW29mZnNldCArIDFdIDw8IDgpIHwKICAgICAgKHRoaXNbb2Zmc2V0ICsgMl0gPDwgMTYpKSArCiAgICAgICh0aGlzW29mZnNldCArIDNdICogMHgxMDAwMDAwKQp9CgpCdWZmZXIucHJvdG90eXBlLnJlYWRVaW50MzJCRSA9CkJ1ZmZlci5wcm90b3R5cGUucmVhZFVJbnQzMkJFID0gZnVuY3Rpb24gcmVhZFVJbnQzMkJFIChvZmZzZXQsIG5vQXNzZXJ0KSB7CiAgb2Zmc2V0ID0gb2Zmc2V0ID4+PiAwCiAgaWYgKCFub0Fzc2VydCkgY2hlY2tPZmZzZXQob2Zmc2V0LCA0LCB0aGlzLmxlbmd0aCkKCiAgcmV0dXJuICh0aGlzW29mZnNldF0gKiAweDEwMDAwMDApICsKICAgICgodGhpc1tvZmZzZXQgKyAxXSA8PCAxNikgfAogICAgKHRoaXNbb2Zmc2V0ICsgMl0gPDwgOCkgfAogICAgdGhpc1tvZmZzZXQgKyAzXSkKfQoKQnVmZmVyLnByb3RvdHlwZS5yZWFkQmlnVUludDY0TEUgPSBkZWZpbmVCaWdJbnRNZXRob2QoZnVuY3Rpb24gcmVhZEJpZ1VJbnQ2NExFIChvZmZzZXQpIHsKICBvZmZzZXQgPSBvZmZzZXQgPj4+IDAKICB2YWxpZGF0ZU51bWJlcihvZmZzZXQsICdvZmZzZXQnKQogIGNvbnN0IGZpcnN0ID0gdGhpc1tvZmZzZXRdCiAgY29uc3QgbGFzdCA9IHRoaXNbb2Zmc2V0ICsgN10KICBpZiAoZmlyc3QgPT09IHVuZGVmaW5lZCB8fCBsYXN0ID09PSB1bmRlZmluZWQpIHsKICAgIGJvdW5kc0Vycm9yKG9mZnNldCwgdGhpcy5sZW5ndGggLSA4KQogIH0KCiAgY29uc3QgbG8gPSBmaXJzdCArCiAgICB0aGlzWysrb2Zmc2V0XSAqIDIgKiogOCArCiAgICB0aGlzWysrb2Zmc2V0XSAqIDIgKiogMTYgKwogICAgdGhpc1srK29mZnNldF0gKiAyICoqIDI0CgogIGNvbnN0IGhpID0gdGhpc1srK29mZnNldF0gKwogICAgdGhpc1srK29mZnNldF0gKiAyICoqIDggKwogICAgdGhpc1srK29mZnNldF0gKiAyICoqIDE2ICsKICAgIGxhc3QgKiAyICoqIDI0CgogIHJldHVybiBCaWdJbnQobG8pICsgKEJpZ0ludChoaSkgPDwgQmlnSW50KDMyKSkKfSkKCkJ1ZmZlci5wcm90b3R5cGUucmVhZEJpZ1VJbnQ2NEJFID0gZGVmaW5lQmlnSW50TWV0aG9kKGZ1bmN0aW9uIHJlYWRCaWdVSW50NjRCRSAob2Zmc2V0KSB7CiAgb2Zmc2V0ID0gb2Zmc2V0ID4+PiAwCiAgdmFsaWRhdGVOdW1iZXIob2Zmc2V0LCAnb2Zmc2V0JykKICBjb25zdCBmaXJzdCA9IHRoaXNbb2Zmc2V0XQogIGNvbnN0IGxhc3QgPSB0aGlzW29mZnNldCArIDddCiAgaWYgKGZpcnN0ID09PSB1bmRlZmluZWQgfHwgbGFzdCA9PT0gdW5kZWZpbmVkKSB7CiAgICBib3VuZHNFcnJvcihvZmZzZXQsIHRoaXMubGVuZ3RoIC0gOCkKICB9CgogIGNvbnN0IGhpID0gZmlyc3QgKiAyICoqIDI0ICsKICAgIHRoaXNbKytvZmZzZXRdICogMiAqKiAxNiArCiAgICB0aGlzWysrb2Zmc2V0XSAqIDIgKiogOCArCiAgICB0aGlzWysrb2Zmc2V0XQoKICBjb25zdCBsbyA9IHRoaXNbKytvZmZzZXRdICogMiAqKiAyNCArCiAgICB0aGlzWysrb2Zmc2V0XSAqIDIgKiogMTYgKwogICAgdGhpc1srK29mZnNldF0gKiAyICoqIDggKwogICAgbGFzdAoKICByZXR1cm4gKEJpZ0ludChoaSkgPDwgQmlnSW50KDMyKSkgKyBCaWdJbnQobG8pCn0pCgpCdWZmZXIucHJvdG90eXBlLnJlYWRJbnRMRSA9IGZ1bmN0aW9uIHJlYWRJbnRMRSAob2Zmc2V0LCBieXRlTGVuZ3RoLCBub0Fzc2VydCkgewogIG9mZnNldCA9IG9mZnNldCA+Pj4gMAogIGJ5dGVMZW5ndGggPSBieXRlTGVuZ3RoID4+PiAwCiAgaWYgKCFub0Fzc2VydCkgY2hlY2tPZmZzZXQob2Zmc2V0LCBieXRlTGVuZ3RoLCB0aGlzLmxlbmd0aCkKCiAgbGV0IHZhbCA9IHRoaXNbb2Zmc2V0XQogIGxldCBtdWwgPSAxCiAgbGV0IGkgPSAwCiAgd2hpbGUgKCsraSA8IGJ5dGVMZW5ndGggJiYgKG11bCAqPSAweDEwMCkpIHsKICAgIHZhbCArPSB0aGlzW29mZnNldCArIGldICogbXVsCiAgfQogIG11bCAqPSAweDgwCgogIGlmICh2YWwgPj0gbXVsKSB2YWwgLT0gTWF0aC5wb3coMiwgOCAqIGJ5dGVMZW5ndGgpCgogIHJldHVybiB2YWwKfQoKQnVmZmVyLnByb3RvdHlwZS5yZWFkSW50QkUgPSBmdW5jdGlvbiByZWFkSW50QkUgKG9mZnNldCwgYnl0ZUxlbmd0aCwgbm9Bc3NlcnQpIHsKICBvZmZzZXQgPSBvZmZzZXQgPj4+IDAKICBieXRlTGVuZ3RoID0gYnl0ZUxlbmd0aCA+Pj4gMAogIGlmICghbm9Bc3NlcnQpIGNoZWNrT2Zmc2V0KG9mZnNldCwgYnl0ZUxlbmd0aCwgdGhpcy5sZW5ndGgpCgogIGxldCBpID0gYnl0ZUxlbmd0aAogIGxldCBtdWwgPSAxCiAgbGV0IHZhbCA9IHRoaXNbb2Zmc2V0ICsgLS1pXQogIHdoaWxlIChpID4gMCAmJiAobXVsICo9IDB4MTAwKSkgewogICAgdmFsICs9IHRoaXNbb2Zmc2V0ICsgLS1pXSAqIG11bAogIH0KICBtdWwgKj0gMHg4MAoKICBpZiAodmFsID49IG11bCkgdmFsIC09IE1hdGgucG93KDIsIDggKiBieXRlTGVuZ3RoKQoKICByZXR1cm4gdmFsCn0KCkJ1ZmZlci5wcm90b3R5cGUucmVhZEludDggPSBmdW5jdGlvbiByZWFkSW50OCAob2Zmc2V0LCBub0Fzc2VydCkgewogIG9mZnNldCA9IG9mZnNldCA+Pj4gMAogIGlmICghbm9Bc3NlcnQpIGNoZWNrT2Zmc2V0KG9mZnNldCwgMSwgdGhpcy5sZW5ndGgpCiAgaWYgKCEodGhpc1tvZmZzZXRdICYgMHg4MCkpIHJldHVybiAodGhpc1tvZmZzZXRdKQogIHJldHVybiAoKDB4ZmYgLSB0aGlzW29mZnNldF0gKyAxKSAqIC0xKQp9CgpCdWZmZXIucHJvdG90eXBlLnJlYWRJbnQxNkxFID0gZnVuY3Rpb24gcmVhZEludDE2TEUgKG9mZnNldCwgbm9Bc3NlcnQpIHsKICBvZmZzZXQgPSBvZmZzZXQgPj4+IDAKICBpZiAoIW5vQXNzZXJ0KSBjaGVja09mZnNldChvZmZzZXQsIDIsIHRoaXMubGVuZ3RoKQogIGNvbnN0IHZhbCA9IHRoaXNbb2Zmc2V0XSB8ICh0aGlzW29mZnNldCArIDFdIDw8IDgpCiAgcmV0dXJuICh2YWwgJiAweDgwMDApID8gdmFsIHwgMHhGRkZGMDAwMCA6IHZhbAp9CgpCdWZmZXIucHJvdG90eXBlLnJlYWRJbnQxNkJFID0gZnVuY3Rpb24gcmVhZEludDE2QkUgKG9mZnNldCwgbm9Bc3NlcnQpIHsKICBvZmZzZXQgPSBvZmZzZXQgPj4+IDAKICBpZiAoIW5vQXNzZXJ0KSBjaGVja09mZnNldChvZmZzZXQsIDIsIHRoaXMubGVuZ3RoKQogIGNvbnN0IHZhbCA9IHRoaXNbb2Zmc2V0ICsgMV0gfCAodGhpc1tvZmZzZXRdIDw8IDgpCiAgcmV0dXJuICh2YWwgJiAweDgwMDApID8gdmFsIHwgMHhGRkZGMDAwMCA6IHZhbAp9CgpCdWZmZXIucHJvdG90eXBlLnJlYWRJbnQzMkxFID0gZnVuY3Rpb24gcmVhZEludDMyTEUgKG9mZnNldCwgbm9Bc3NlcnQpIHsKICBvZmZzZXQgPSBvZmZzZXQgPj4+IDAKICBpZiAoIW5vQXNzZXJ0KSBjaGVja09mZnNldChvZmZzZXQsIDQsIHRoaXMubGVuZ3RoKQoKICByZXR1cm4gKHRoaXNbb2Zmc2V0XSkgfAogICAgKHRoaXNbb2Zmc2V0ICsgMV0gPDwgOCkgfAogICAgKHRoaXNbb2Zmc2V0ICsgMl0gPDwgMTYpIHwKICAgICh0aGlzW29mZnNldCArIDNdIDw8IDI0KQp9CgpCdWZmZXIucHJvdG90eXBlLnJlYWRJbnQzMkJFID0gZnVuY3Rpb24gcmVhZEludDMyQkUgKG9mZnNldCwgbm9Bc3NlcnQpIHsKICBvZmZzZXQgPSBvZmZzZXQgPj4+IDAKICBpZiAoIW5vQXNzZXJ0KSBjaGVja09mZnNldChvZmZzZXQsIDQsIHRoaXMubGVuZ3RoKQoKICByZXR1cm4gKHRoaXNbb2Zmc2V0XSA8PCAyNCkgfAogICAgKHRoaXNbb2Zmc2V0ICsgMV0gPDwgMTYpIHwKICAgICh0aGlzW29mZnNldCArIDJdIDw8IDgpIHwKICAgICh0aGlzW29mZnNldCArIDNdKQp9CgpCdWZmZXIucHJvdG90eXBlLnJlYWRCaWdJbnQ2NExFID0gZGVmaW5lQmlnSW50TWV0aG9kKGZ1bmN0aW9uIHJlYWRCaWdJbnQ2NExFIChvZmZzZXQpIHsKICBvZmZzZXQgPSBvZmZzZXQgPj4+IDAKICB2YWxpZGF0ZU51bWJlcihvZmZzZXQsICdvZmZzZXQnKQogIGNvbnN0IGZpcnN0ID0gdGhpc1tvZmZzZXRdCiAgY29uc3QgbGFzdCA9IHRoaXNbb2Zmc2V0ICsgN10KICBpZiAoZmlyc3QgPT09IHVuZGVmaW5lZCB8fCBsYXN0ID09PSB1bmRlZmluZWQpIHsKICAgIGJvdW5kc0Vycm9yKG9mZnNldCwgdGhpcy5sZW5ndGggLSA4KQogIH0KCiAgY29uc3QgdmFsID0gdGhpc1tvZmZzZXQgKyA0XSArCiAgICB0aGlzW29mZnNldCArIDVdICogMiAqKiA4ICsKICAgIHRoaXNbb2Zmc2V0ICsgNl0gKiAyICoqIDE2ICsKICAgIChsYXN0IDw8IDI0KSAvLyBPdmVyZmxvdwoKICByZXR1cm4gKEJpZ0ludCh2YWwpIDw8IEJpZ0ludCgzMikpICsKICAgIEJpZ0ludChmaXJzdCArCiAgICB0aGlzWysrb2Zmc2V0XSAqIDIgKiogOCArCiAgICB0aGlzWysrb2Zmc2V0XSAqIDIgKiogMTYgKwogICAgdGhpc1srK29mZnNldF0gKiAyICoqIDI0KQp9KQoKQnVmZmVyLnByb3RvdHlwZS5yZWFkQmlnSW50NjRCRSA9IGRlZmluZUJpZ0ludE1ldGhvZChmdW5jdGlvbiByZWFkQmlnSW50NjRCRSAob2Zmc2V0KSB7CiAgb2Zmc2V0ID0gb2Zmc2V0ID4+PiAwCiAgdmFsaWRhdGVOdW1iZXIob2Zmc2V0LCAnb2Zmc2V0JykKICBjb25zdCBmaXJzdCA9IHRoaXNbb2Zmc2V0XQogIGNvbnN0IGxhc3QgPSB0aGlzW29mZnNldCArIDddCiAgaWYgKGZpcnN0ID09PSB1bmRlZmluZWQgfHwgbGFzdCA9PT0gdW5kZWZpbmVkKSB7CiAgICBib3VuZHNFcnJvcihvZmZzZXQsIHRoaXMubGVuZ3RoIC0gOCkKICB9CgogIGNvbnN0IHZhbCA9IChmaXJzdCA8PCAyNCkgKyAvLyBPdmVyZmxvdwogICAgdGhpc1srK29mZnNldF0gKiAyICoqIDE2ICsKICAgIHRoaXNbKytvZmZzZXRdICogMiAqKiA4ICsKICAgIHRoaXNbKytvZmZzZXRdCgogIHJldHVybiAoQmlnSW50KHZhbCkgPDwgQmlnSW50KDMyKSkgKwogICAgQmlnSW50KHRoaXNbKytvZmZzZXRdICogMiAqKiAyNCArCiAgICB0aGlzWysrb2Zmc2V0XSAqIDIgKiogMTYgKwogICAgdGhpc1srK29mZnNldF0gKiAyICoqIDggKwogICAgbGFzdCkKfSkKCkJ1ZmZlci5wcm90b3R5cGUucmVhZEZsb2F0TEUgPSBmdW5jdGlvbiByZWFkRmxvYXRMRSAob2Zmc2V0LCBub0Fzc2VydCkgewogIG9mZnNldCA9IG9mZnNldCA+Pj4gMAogIGlmICghbm9Bc3NlcnQpIGNoZWNrT2Zmc2V0KG9mZnNldCwgNCwgdGhpcy5sZW5ndGgpCiAgcmV0dXJuIGllZWU3NTQucmVhZCh0aGlzLCBvZmZzZXQsIHRydWUsIDIzLCA0KQp9CgpCdWZmZXIucHJvdG90eXBlLnJlYWRGbG9hdEJFID0gZnVuY3Rpb24gcmVhZEZsb2F0QkUgKG9mZnNldCwgbm9Bc3NlcnQpIHsKICBvZmZzZXQgPSBvZmZzZXQgPj4+IDAKICBpZiAoIW5vQXNzZXJ0KSBjaGVja09mZnNldChvZmZzZXQsIDQsIHRoaXMubGVuZ3RoKQogIHJldHVybiBpZWVlNzU0LnJlYWQodGhpcywgb2Zmc2V0LCBmYWxzZSwgMjMsIDQpCn0KCkJ1ZmZlci5wcm90b3R5cGUucmVhZERvdWJsZUxFID0gZnVuY3Rpb24gcmVhZERvdWJsZUxFIChvZmZzZXQsIG5vQXNzZXJ0KSB7CiAgb2Zmc2V0ID0gb2Zmc2V0ID4+PiAwCiAgaWYgKCFub0Fzc2VydCkgY2hlY2tPZmZzZXQob2Zmc2V0LCA4LCB0aGlzLmxlbmd0aCkKICByZXR1cm4gaWVlZTc1NC5yZWFkKHRoaXMsIG9mZnNldCwgdHJ1ZSwgNTIsIDgpCn0KCkJ1ZmZlci5wcm90b3R5cGUucmVhZERvdWJsZUJFID0gZnVuY3Rpb24gcmVhZERvdWJsZUJFIChvZmZzZXQsIG5vQXNzZXJ0KSB7CiAgb2Zmc2V0ID0gb2Zmc2V0ID4+PiAwCiAgaWYgKCFub0Fzc2VydCkgY2hlY2tPZmZzZXQob2Zmc2V0LCA4LCB0aGlzLmxlbmd0aCkKICByZXR1cm4gaWVlZTc1NC5yZWFkKHRoaXMsIG9mZnNldCwgZmFsc2UsIDUyLCA4KQp9CgpmdW5jdGlvbiBjaGVja0ludCAoYnVmLCB2YWx1ZSwgb2Zmc2V0LCBleHQsIG1heCwgbWluKSB7CiAgaWYgKCFCdWZmZXIuaXNCdWZmZXIoYnVmKSkgdGhyb3cgbmV3IFR5cGVFcnJvcignImJ1ZmZlciIgYXJndW1lbnQgbXVzdCBiZSBhIEJ1ZmZlciBpbnN0YW5jZScpCiAgaWYgKHZhbHVlID4gbWF4IHx8IHZhbHVlIDwgbWluKSB0aHJvdyBuZXcgUmFuZ2VFcnJvcignInZhbHVlIiBhcmd1bWVudCBpcyBvdXQgb2YgYm91bmRzJykKICBpZiAob2Zmc2V0ICsgZXh0ID4gYnVmLmxlbmd0aCkgdGhyb3cgbmV3IFJhbmdlRXJyb3IoJ0luZGV4IG91dCBvZiByYW5nZScpCn0KCkJ1ZmZlci5wcm90b3R5cGUud3JpdGVVaW50TEUgPQpCdWZmZXIucHJvdG90eXBlLndyaXRlVUludExFID0gZnVuY3Rpb24gd3JpdGVVSW50TEUgKHZhbHVlLCBvZmZzZXQsIGJ5dGVMZW5ndGgsIG5vQXNzZXJ0KSB7CiAgdmFsdWUgPSArdmFsdWUKICBvZmZzZXQgPSBvZmZzZXQgPj4+IDAKICBieXRlTGVuZ3RoID0gYnl0ZUxlbmd0aCA+Pj4gMAogIGlmICghbm9Bc3NlcnQpIHsKICAgIGNvbnN0IG1heEJ5dGVzID0gTWF0aC5wb3coMiwgOCAqIGJ5dGVMZW5ndGgpIC0gMQogICAgY2hlY2tJbnQodGhpcywgdmFsdWUsIG9mZnNldCwgYnl0ZUxlbmd0aCwgbWF4Qnl0ZXMsIDApCiAgfQoKICBsZXQgbXVsID0gMQogIGxldCBpID0gMAogIHRoaXNbb2Zmc2V0XSA9IHZhbHVlICYgMHhGRgogIHdoaWxlICgrK2kgPCBieXRlTGVuZ3RoICYmIChtdWwgKj0gMHgxMDApKSB7CiAgICB0aGlzW29mZnNldCArIGldID0gKHZhbHVlIC8gbXVsKSAmIDB4RkYKICB9CgogIHJldHVybiBvZmZzZXQgKyBieXRlTGVuZ3RoCn0KCkJ1ZmZlci5wcm90b3R5cGUud3JpdGVVaW50QkUgPQpCdWZmZXIucHJvdG90eXBlLndyaXRlVUludEJFID0gZnVuY3Rpb24gd3JpdGVVSW50QkUgKHZhbHVlLCBvZmZzZXQsIGJ5dGVMZW5ndGgsIG5vQXNzZXJ0KSB7CiAgdmFsdWUgPSArdmFsdWUKICBvZmZzZXQgPSBvZmZzZXQgPj4+IDAKICBieXRlTGVuZ3RoID0gYnl0ZUxlbmd0aCA+Pj4gMAogIGlmICghbm9Bc3NlcnQpIHsKICAgIGNvbnN0IG1heEJ5dGVzID0gTWF0aC5wb3coMiwgOCAqIGJ5dGVMZW5ndGgpIC0gMQogICAgY2hlY2tJbnQodGhpcywgdmFsdWUsIG9mZnNldCwgYnl0ZUxlbmd0aCwgbWF4Qnl0ZXMsIDApCiAgfQoKICBsZXQgaSA9IGJ5dGVMZW5ndGggLSAxCiAgbGV0IG11bCA9IDEKICB0aGlzW29mZnNldCArIGldID0gdmFsdWUgJiAweEZGCiAgd2hpbGUgKC0taSA+PSAwICYmIChtdWwgKj0gMHgxMDApKSB7CiAgICB0aGlzW29mZnNldCArIGldID0gKHZhbHVlIC8gbXVsKSAmIDB4RkYKICB9CgogIHJldHVybiBvZmZzZXQgKyBieXRlTGVuZ3RoCn0KCkJ1ZmZlci5wcm90b3R5cGUud3JpdGVVaW50OCA9CkJ1ZmZlci5wcm90b3R5cGUud3JpdGVVSW50OCA9IGZ1bmN0aW9uIHdyaXRlVUludDggKHZhbHVlLCBvZmZzZXQsIG5vQXNzZXJ0KSB7CiAgdmFsdWUgPSArdmFsdWUKICBvZmZzZXQgPSBvZmZzZXQgPj4+IDAKICBpZiAoIW5vQXNzZXJ0KSBjaGVja0ludCh0aGlzLCB2YWx1ZSwgb2Zmc2V0LCAxLCAweGZmLCAwKQogIHRoaXNbb2Zmc2V0XSA9ICh2YWx1ZSAmIDB4ZmYpCiAgcmV0dXJuIG9mZnNldCArIDEKfQoKQnVmZmVyLnByb3RvdHlwZS53cml0ZVVpbnQxNkxFID0KQnVmZmVyLnByb3RvdHlwZS53cml0ZVVJbnQxNkxFID0gZnVuY3Rpb24gd3JpdGVVSW50MTZMRSAodmFsdWUsIG9mZnNldCwgbm9Bc3NlcnQpIHsKICB2YWx1ZSA9ICt2YWx1ZQogIG9mZnNldCA9IG9mZnNldCA+Pj4gMAogIGlmICghbm9Bc3NlcnQpIGNoZWNrSW50KHRoaXMsIHZhbHVlLCBvZmZzZXQsIDIsIDB4ZmZmZiwgMCkKICB0aGlzW29mZnNldF0gPSAodmFsdWUgJiAweGZmKQogIHRoaXNbb2Zmc2V0ICsgMV0gPSAodmFsdWUgPj4+IDgpCiAgcmV0dXJuIG9mZnNldCArIDIKfQoKQnVmZmVyLnByb3RvdHlwZS53cml0ZVVpbnQxNkJFID0KQnVmZmVyLnByb3RvdHlwZS53cml0ZVVJbnQxNkJFID0gZnVuY3Rpb24gd3JpdGVVSW50MTZCRSAodmFsdWUsIG9mZnNldCwgbm9Bc3NlcnQpIHsKICB2YWx1ZSA9ICt2YWx1ZQogIG9mZnNldCA9IG9mZnNldCA+Pj4gMAogIGlmICghbm9Bc3NlcnQpIGNoZWNrSW50KHRoaXMsIHZhbHVlLCBvZmZzZXQsIDIsIDB4ZmZmZiwgMCkKICB0aGlzW29mZnNldF0gPSAodmFsdWUgPj4+IDgpCiAgdGhpc1tvZmZzZXQgKyAxXSA9ICh2YWx1ZSAmIDB4ZmYpCiAgcmV0dXJuIG9mZnNldCArIDIKfQoKQnVmZmVyLnByb3RvdHlwZS53cml0ZVVpbnQzMkxFID0KQnVmZmVyLnByb3RvdHlwZS53cml0ZVVJbnQzMkxFID0gZnVuY3Rpb24gd3JpdGVVSW50MzJMRSAodmFsdWUsIG9mZnNldCwgbm9Bc3NlcnQpIHsKICB2YWx1ZSA9ICt2YWx1ZQogIG9mZnNldCA9IG9mZnNldCA+Pj4gMAogIGlmICghbm9Bc3NlcnQpIGNoZWNrSW50KHRoaXMsIHZhbHVlLCBvZmZzZXQsIDQsIDB4ZmZmZmZmZmYsIDApCiAgdGhpc1tvZmZzZXQgKyAzXSA9ICh2YWx1ZSA+Pj4gMjQpCiAgdGhpc1tvZmZzZXQgKyAyXSA9ICh2YWx1ZSA+Pj4gMTYpCiAgdGhpc1tvZmZzZXQgKyAxXSA9ICh2YWx1ZSA+Pj4gOCkKICB0aGlzW29mZnNldF0gPSAodmFsdWUgJiAweGZmKQogIHJldHVybiBvZmZzZXQgKyA0Cn0KCkJ1ZmZlci5wcm90b3R5cGUud3JpdGVVaW50MzJCRSA9CkJ1ZmZlci5wcm90b3R5cGUud3JpdGVVSW50MzJCRSA9IGZ1bmN0aW9uIHdyaXRlVUludDMyQkUgKHZhbHVlLCBvZmZzZXQsIG5vQXNzZXJ0KSB7CiAgdmFsdWUgPSArdmFsdWUKICBvZmZzZXQgPSBvZmZzZXQgPj4+IDAKICBpZiAoIW5vQXNzZXJ0KSBjaGVja0ludCh0aGlzLCB2YWx1ZSwgb2Zmc2V0LCA0LCAweGZmZmZmZmZmLCAwKQogIHRoaXNbb2Zmc2V0XSA9ICh2YWx1ZSA+Pj4gMjQpCiAgdGhpc1tvZmZzZXQgKyAxXSA9ICh2YWx1ZSA+Pj4gMTYpCiAgdGhpc1tvZmZzZXQgKyAyXSA9ICh2YWx1ZSA+Pj4gOCkKICB0aGlzW29mZnNldCArIDNdID0gKHZhbHVlICYgMHhmZikKICByZXR1cm4gb2Zmc2V0ICsgNAp9CgpmdW5jdGlvbiB3cnRCaWdVSW50NjRMRSAoYnVmLCB2YWx1ZSwgb2Zmc2V0LCBtaW4sIG1heCkgewogIGNoZWNrSW50QkkodmFsdWUsIG1pbiwgbWF4LCBidWYsIG9mZnNldCwgNykKCiAgbGV0IGxvID0gTnVtYmVyKHZhbHVlICYgQmlnSW50KDB4ZmZmZmZmZmYpKQogIGJ1ZltvZmZzZXQrK10gPSBsbwogIGxvID0gbG8gPj4gOAogIGJ1ZltvZmZzZXQrK10gPSBsbwogIGxvID0gbG8gPj4gOAogIGJ1ZltvZmZzZXQrK10gPSBsbwogIGxvID0gbG8gPj4gOAogIGJ1ZltvZmZzZXQrK10gPSBsbwogIGxldCBoaSA9IE51bWJlcih2YWx1ZSA+PiBCaWdJbnQoMzIpICYgQmlnSW50KDB4ZmZmZmZmZmYpKQogIGJ1ZltvZmZzZXQrK10gPSBoaQogIGhpID0gaGkgPj4gOAogIGJ1ZltvZmZzZXQrK10gPSBoaQogIGhpID0gaGkgPj4gOAogIGJ1ZltvZmZzZXQrK10gPSBoaQogIGhpID0gaGkgPj4gOAogIGJ1ZltvZmZzZXQrK10gPSBoaQogIHJldHVybiBvZmZzZXQKfQoKZnVuY3Rpb24gd3J0QmlnVUludDY0QkUgKGJ1ZiwgdmFsdWUsIG9mZnNldCwgbWluLCBtYXgpIHsKICBjaGVja0ludEJJKHZhbHVlLCBtaW4sIG1heCwgYnVmLCBvZmZzZXQsIDcpCgogIGxldCBsbyA9IE51bWJlcih2YWx1ZSAmIEJpZ0ludCgweGZmZmZmZmZmKSkKICBidWZbb2Zmc2V0ICsgN10gPSBsbwogIGxvID0gbG8gPj4gOAogIGJ1ZltvZmZzZXQgKyA2XSA9IGxvCiAgbG8gPSBsbyA+PiA4CiAgYnVmW29mZnNldCArIDVdID0gbG8KICBsbyA9IGxvID4+IDgKICBidWZbb2Zmc2V0ICsgNF0gPSBsbwogIGxldCBoaSA9IE51bWJlcih2YWx1ZSA+PiBCaWdJbnQoMzIpICYgQmlnSW50KDB4ZmZmZmZmZmYpKQogIGJ1ZltvZmZzZXQgKyAzXSA9IGhpCiAgaGkgPSBoaSA+PiA4CiAgYnVmW29mZnNldCArIDJdID0gaGkKICBoaSA9IGhpID4+IDgKICBidWZbb2Zmc2V0ICsgMV0gPSBoaQogIGhpID0gaGkgPj4gOAogIGJ1ZltvZmZzZXRdID0gaGkKICByZXR1cm4gb2Zmc2V0ICsgOAp9CgpCdWZmZXIucHJvdG90eXBlLndyaXRlQmlnVUludDY0TEUgPSBkZWZpbmVCaWdJbnRNZXRob2QoZnVuY3Rpb24gd3JpdGVCaWdVSW50NjRMRSAodmFsdWUsIG9mZnNldCA9IDApIHsKICByZXR1cm4gd3J0QmlnVUludDY0TEUodGhpcywgdmFsdWUsIG9mZnNldCwgQmlnSW50KDApLCBCaWdJbnQoJzB4ZmZmZmZmZmZmZmZmZmZmZicpKQp9KQoKQnVmZmVyLnByb3RvdHlwZS53cml0ZUJpZ1VJbnQ2NEJFID0gZGVmaW5lQmlnSW50TWV0aG9kKGZ1bmN0aW9uIHdyaXRlQmlnVUludDY0QkUgKHZhbHVlLCBvZmZzZXQgPSAwKSB7CiAgcmV0dXJuIHdydEJpZ1VJbnQ2NEJFKHRoaXMsIHZhbHVlLCBvZmZzZXQsIEJpZ0ludCgwKSwgQmlnSW50KCcweGZmZmZmZmZmZmZmZmZmZmYnKSkKfSkKCkJ1ZmZlci5wcm90b3R5cGUud3JpdGVJbnRMRSA9IGZ1bmN0aW9uIHdyaXRlSW50TEUgKHZhbHVlLCBvZmZzZXQsIGJ5dGVMZW5ndGgsIG5vQXNzZXJ0KSB7CiAgdmFsdWUgPSArdmFsdWUKICBvZmZzZXQgPSBvZmZzZXQgPj4+IDAKICBpZiAoIW5vQXNzZXJ0KSB7CiAgICBjb25zdCBsaW1pdCA9IE1hdGgucG93KDIsICg4ICogYnl0ZUxlbmd0aCkgLSAxKQoKICAgIGNoZWNrSW50KHRoaXMsIHZhbHVlLCBvZmZzZXQsIGJ5dGVMZW5ndGgsIGxpbWl0IC0gMSwgLWxpbWl0KQogIH0KCiAgbGV0IGkgPSAwCiAgbGV0IG11bCA9IDEKICBsZXQgc3ViID0gMAogIHRoaXNbb2Zmc2V0XSA9IHZhbHVlICYgMHhGRgogIHdoaWxlICgrK2kgPCBieXRlTGVuZ3RoICYmIChtdWwgKj0gMHgxMDApKSB7CiAgICBpZiAodmFsdWUgPCAwICYmIHN1YiA9PT0gMCAmJiB0aGlzW29mZnNldCArIGkgLSAxXSAhPT0gMCkgewogICAgICBzdWIgPSAxCiAgICB9CiAgICB0aGlzW29mZnNldCArIGldID0gKCh2YWx1ZSAvIG11bCkgPj4gMCkgLSBzdWIgJiAweEZGCiAgfQoKICByZXR1cm4gb2Zmc2V0ICsgYnl0ZUxlbmd0aAp9CgpCdWZmZXIucHJvdG90eXBlLndyaXRlSW50QkUgPSBmdW5jdGlvbiB3cml0ZUludEJFICh2YWx1ZSwgb2Zmc2V0LCBieXRlTGVuZ3RoLCBub0Fzc2VydCkgewogIHZhbHVlID0gK3ZhbHVlCiAgb2Zmc2V0ID0gb2Zmc2V0ID4+PiAwCiAgaWYgKCFub0Fzc2VydCkgewogICAgY29uc3QgbGltaXQgPSBNYXRoLnBvdygyLCAoOCAqIGJ5dGVMZW5ndGgpIC0gMSkKCiAgICBjaGVja0ludCh0aGlzLCB2YWx1ZSwgb2Zmc2V0LCBieXRlTGVuZ3RoLCBsaW1pdCAtIDEsIC1saW1pdCkKICB9CgogIGxldCBpID0gYnl0ZUxlbmd0aCAtIDEKICBsZXQgbXVsID0gMQogIGxldCBzdWIgPSAwCiAgdGhpc1tvZmZzZXQgKyBpXSA9IHZhbHVlICYgMHhGRgogIHdoaWxlICgtLWkgPj0gMCAmJiAobXVsICo9IDB4MTAwKSkgewogICAgaWYgKHZhbHVlIDwgMCAmJiBzdWIgPT09IDAgJiYgdGhpc1tvZmZzZXQgKyBpICsgMV0gIT09IDApIHsKICAgICAgc3ViID0gMQogICAgfQogICAgdGhpc1tvZmZzZXQgKyBpXSA9ICgodmFsdWUgLyBtdWwpID4+IDApIC0gc3ViICYgMHhGRgogIH0KCiAgcmV0dXJuIG9mZnNldCArIGJ5dGVMZW5ndGgKfQoKQnVmZmVyLnByb3RvdHlwZS53cml0ZUludDggPSBmdW5jdGlvbiB3cml0ZUludDggKHZhbHVlLCBvZmZzZXQsIG5vQXNzZXJ0KSB7CiAgdmFsdWUgPSArdmFsdWUKICBvZmZzZXQgPSBvZmZzZXQgPj4+IDAKICBpZiAoIW5vQXNzZXJ0KSBjaGVja0ludCh0aGlzLCB2YWx1ZSwgb2Zmc2V0LCAxLCAweDdmLCAtMHg4MCkKICBpZiAodmFsdWUgPCAwKSB2YWx1ZSA9IDB4ZmYgKyB2YWx1ZSArIDEKICB0aGlzW29mZnNldF0gPSAodmFsdWUgJiAweGZmKQogIHJldHVybiBvZmZzZXQgKyAxCn0KCkJ1ZmZlci5wcm90b3R5cGUud3JpdGVJbnQxNkxFID0gZnVuY3Rpb24gd3JpdGVJbnQxNkxFICh2YWx1ZSwgb2Zmc2V0LCBub0Fzc2VydCkgewogIHZhbHVlID0gK3ZhbHVlCiAgb2Zmc2V0ID0gb2Zmc2V0ID4+PiAwCiAgaWYgKCFub0Fzc2VydCkgY2hlY2tJbnQodGhpcywgdmFsdWUsIG9mZnNldCwgMiwgMHg3ZmZmLCAtMHg4MDAwKQogIHRoaXNbb2Zmc2V0XSA9ICh2YWx1ZSAmIDB4ZmYpCiAgdGhpc1tvZmZzZXQgKyAxXSA9ICh2YWx1ZSA+Pj4gOCkKICByZXR1cm4gb2Zmc2V0ICsgMgp9CgpCdWZmZXIucHJvdG90eXBlLndyaXRlSW50MTZCRSA9IGZ1bmN0aW9uIHdyaXRlSW50MTZCRSAodmFsdWUsIG9mZnNldCwgbm9Bc3NlcnQpIHsKICB2YWx1ZSA9ICt2YWx1ZQogIG9mZnNldCA9IG9mZnNldCA+Pj4gMAogIGlmICghbm9Bc3NlcnQpIGNoZWNrSW50KHRoaXMsIHZhbHVlLCBvZmZzZXQsIDIsIDB4N2ZmZiwgLTB4ODAwMCkKICB0aGlzW29mZnNldF0gPSAodmFsdWUgPj4+IDgpCiAgdGhpc1tvZmZzZXQgKyAxXSA9ICh2YWx1ZSAmIDB4ZmYpCiAgcmV0dXJuIG9mZnNldCArIDIKfQoKQnVmZmVyLnByb3RvdHlwZS53cml0ZUludDMyTEUgPSBmdW5jdGlvbiB3cml0ZUludDMyTEUgKHZhbHVlLCBvZmZzZXQsIG5vQXNzZXJ0KSB7CiAgdmFsdWUgPSArdmFsdWUKICBvZmZzZXQgPSBvZmZzZXQgPj4+IDAKICBpZiAoIW5vQXNzZXJ0KSBjaGVja0ludCh0aGlzLCB2YWx1ZSwgb2Zmc2V0LCA0LCAweDdmZmZmZmZmLCAtMHg4MDAwMDAwMCkKICB0aGlzW29mZnNldF0gPSAodmFsdWUgJiAweGZmKQogIHRoaXNbb2Zmc2V0ICsgMV0gPSAodmFsdWUgPj4+IDgpCiAgdGhpc1tvZmZzZXQgKyAyXSA9ICh2YWx1ZSA+Pj4gMTYpCiAgdGhpc1tvZmZzZXQgKyAzXSA9ICh2YWx1ZSA+Pj4gMjQpCiAgcmV0dXJuIG9mZnNldCArIDQKfQoKQnVmZmVyLnByb3RvdHlwZS53cml0ZUludDMyQkUgPSBmdW5jdGlvbiB3cml0ZUludDMyQkUgKHZhbHVlLCBvZmZzZXQsIG5vQXNzZXJ0KSB7CiAgdmFsdWUgPSArdmFsdWUKICBvZmZzZXQgPSBvZmZzZXQgPj4+IDAKICBpZiAoIW5vQXNzZXJ0KSBjaGVja0ludCh0aGlzLCB2YWx1ZSwgb2Zmc2V0LCA0LCAweDdmZmZmZmZmLCAtMHg4MDAwMDAwMCkKICBpZiAodmFsdWUgPCAwKSB2YWx1ZSA9IDB4ZmZmZmZmZmYgKyB2YWx1ZSArIDEKICB0aGlzW29mZnNldF0gPSAodmFsdWUgPj4+IDI0KQogIHRoaXNbb2Zmc2V0ICsgMV0gPSAodmFsdWUgPj4+IDE2KQogIHRoaXNbb2Zmc2V0ICsgMl0gPSAodmFsdWUgPj4+IDgpCiAgdGhpc1tvZmZzZXQgKyAzXSA9ICh2YWx1ZSAmIDB4ZmYpCiAgcmV0dXJuIG9mZnNldCArIDQKfQoKQnVmZmVyLnByb3RvdHlwZS53cml0ZUJpZ0ludDY0TEUgPSBkZWZpbmVCaWdJbnRNZXRob2QoZnVuY3Rpb24gd3JpdGVCaWdJbnQ2NExFICh2YWx1ZSwgb2Zmc2V0ID0gMCkgewogIHJldHVybiB3cnRCaWdVSW50NjRMRSh0aGlzLCB2YWx1ZSwgb2Zmc2V0LCAtQmlnSW50KCcweDgwMDAwMDAwMDAwMDAwMDAnKSwgQmlnSW50KCcweDdmZmZmZmZmZmZmZmZmZmYnKSkKfSkKCkJ1ZmZlci5wcm90b3R5cGUud3JpdGVCaWdJbnQ2NEJFID0gZGVmaW5lQmlnSW50TWV0aG9kKGZ1bmN0aW9uIHdyaXRlQmlnSW50NjRCRSAodmFsdWUsIG9mZnNldCA9IDApIHsKICByZXR1cm4gd3J0QmlnVUludDY0QkUodGhpcywgdmFsdWUsIG9mZnNldCwgLUJpZ0ludCgnMHg4MDAwMDAwMDAwMDAwMDAwJyksIEJpZ0ludCgnMHg3ZmZmZmZmZmZmZmZmZmZmJykpCn0pCgpmdW5jdGlvbiBjaGVja0lFRUU3NTQgKGJ1ZiwgdmFsdWUsIG9mZnNldCwgZXh0LCBtYXgsIG1pbikgewogIGlmIChvZmZzZXQgKyBleHQgPiBidWYubGVuZ3RoKSB0aHJvdyBuZXcgUmFuZ2VFcnJvcignSW5kZXggb3V0IG9mIHJhbmdlJykKICBpZiAob2Zmc2V0IDwgMCkgdGhyb3cgbmV3IFJhbmdlRXJyb3IoJ0luZGV4IG91dCBvZiByYW5nZScpCn0KCmZ1bmN0aW9uIHdyaXRlRmxvYXQgKGJ1ZiwgdmFsdWUsIG9mZnNldCwgbGl0dGxlRW5kaWFuLCBub0Fzc2VydCkgewogIHZhbHVlID0gK3ZhbHVlCiAgb2Zmc2V0ID0gb2Zmc2V0ID4+PiAwCiAgaWYgKCFub0Fzc2VydCkgewogICAgY2hlY2tJRUVFNzU0KGJ1ZiwgdmFsdWUsIG9mZnNldCwgNCwgMy40MDI4MjM0NjYzODUyODg2ZSszOCwgLTMuNDAyODIzNDY2Mzg1Mjg4NmUrMzgpCiAgfQogIGllZWU3NTQud3JpdGUoYnVmLCB2YWx1ZSwgb2Zmc2V0LCBsaXR0bGVFbmRpYW4sIDIzLCA0KQogIHJldHVybiBvZmZzZXQgKyA0Cn0KCkJ1ZmZlci5wcm90b3R5cGUud3JpdGVGbG9hdExFID0gZnVuY3Rpb24gd3JpdGVGbG9hdExFICh2YWx1ZSwgb2Zmc2V0LCBub0Fzc2VydCkgewogIHJldHVybiB3cml0ZUZsb2F0KHRoaXMsIHZhbHVlLCBvZmZzZXQsIHRydWUsIG5vQXNzZXJ0KQp9CgpCdWZmZXIucHJvdG90eXBlLndyaXRlRmxvYXRCRSA9IGZ1bmN0aW9uIHdyaXRlRmxvYXRCRSAodmFsdWUsIG9mZnNldCwgbm9Bc3NlcnQpIHsKICByZXR1cm4gd3JpdGVGbG9hdCh0aGlzLCB2YWx1ZSwgb2Zmc2V0LCBmYWxzZSwgbm9Bc3NlcnQpCn0KCmZ1bmN0aW9uIHdyaXRlRG91YmxlIChidWYsIHZhbHVlLCBvZmZzZXQsIGxpdHRsZUVuZGlhbiwgbm9Bc3NlcnQpIHsKICB2YWx1ZSA9ICt2YWx1ZQogIG9mZnNldCA9IG9mZnNldCA+Pj4gMAogIGlmICghbm9Bc3NlcnQpIHsKICAgIGNoZWNrSUVFRTc1NChidWYsIHZhbHVlLCBvZmZzZXQsIDgsIDEuNzk3NjkzMTM0ODYyMzE1N0UrMzA4LCAtMS43OTc2OTMxMzQ4NjIzMTU3RSszMDgpCiAgfQogIGllZWU3NTQud3JpdGUoYnVmLCB2YWx1ZSwgb2Zmc2V0LCBsaXR0bGVFbmRpYW4sIDUyLCA4KQogIHJldHVybiBvZmZzZXQgKyA4Cn0KCkJ1ZmZlci5wcm90b3R5cGUud3JpdGVEb3VibGVMRSA9IGZ1bmN0aW9uIHdyaXRlRG91YmxlTEUgKHZhbHVlLCBvZmZzZXQsIG5vQXNzZXJ0KSB7CiAgcmV0dXJuIHdyaXRlRG91YmxlKHRoaXMsIHZhbHVlLCBvZmZzZXQsIHRydWUsIG5vQXNzZXJ0KQp9CgpCdWZmZXIucHJvdG90eXBlLndyaXRlRG91YmxlQkUgPSBmdW5jdGlvbiB3cml0ZURvdWJsZUJFICh2YWx1ZSwgb2Zmc2V0LCBub0Fzc2VydCkgewogIHJldHVybiB3cml0ZURvdWJsZSh0aGlzLCB2YWx1ZSwgb2Zmc2V0LCBmYWxzZSwgbm9Bc3NlcnQpCn0KCi8vIGNvcHkodGFyZ2V0QnVmZmVyLCB0YXJnZXRTdGFydD0wLCBzb3VyY2VTdGFydD0wLCBzb3VyY2VFbmQ9YnVmZmVyLmxlbmd0aCkKQnVmZmVyLnByb3RvdHlwZS5jb3B5ID0gZnVuY3Rpb24gY29weSAodGFyZ2V0LCB0YXJnZXRTdGFydCwgc3RhcnQsIGVuZCkgewogIGlmICghQnVmZmVyLmlzQnVmZmVyKHRhcmdldCkpIHRocm93IG5ldyBUeXBlRXJyb3IoJ2FyZ3VtZW50IHNob3VsZCBiZSBhIEJ1ZmZlcicpCiAgaWYgKCFzdGFydCkgc3RhcnQgPSAwCiAgaWYgKCFlbmQgJiYgZW5kICE9PSAwKSBlbmQgPSB0aGlzLmxlbmd0aAogIGlmICh0YXJnZXRTdGFydCA+PSB0YXJnZXQubGVuZ3RoKSB0YXJnZXRTdGFydCA9IHRhcmdldC5sZW5ndGgKICBpZiAoIXRhcmdldFN0YXJ0KSB0YXJnZXRTdGFydCA9IDAKICBpZiAoZW5kID4gMCAmJiBlbmQgPCBzdGFydCkgZW5kID0gc3RhcnQKCiAgLy8gQ29weSAwIGJ5dGVzOyB3ZSdyZSBkb25lCiAgaWYgKGVuZCA9PT0gc3RhcnQpIHJldHVybiAwCiAgaWYgKHRhcmdldC5sZW5ndGggPT09IDAgfHwgdGhpcy5sZW5ndGggPT09IDApIHJldHVybiAwCgogIC8vIEZhdGFsIGVycm9yIGNvbmRpdGlvbnMKICBpZiAodGFyZ2V0U3RhcnQgPCAwKSB7CiAgICB0aHJvdyBuZXcgUmFuZ2VFcnJvcigndGFyZ2V0U3RhcnQgb3V0IG9mIGJvdW5kcycpCiAgfQogIGlmIChzdGFydCA8IDAgfHwgc3RhcnQgPj0gdGhpcy5sZW5ndGgpIHRocm93IG5ldyBSYW5nZUVycm9yKCdJbmRleCBvdXQgb2YgcmFuZ2UnKQogIGlmIChlbmQgPCAwKSB0aHJvdyBuZXcgUmFuZ2VFcnJvcignc291cmNlRW5kIG91dCBvZiBib3VuZHMnKQoKICAvLyBBcmUgd2Ugb29iPwogIGlmIChlbmQgPiB0aGlzLmxlbmd0aCkgZW5kID0gdGhpcy5sZW5ndGgKICBpZiAodGFyZ2V0Lmxlbmd0aCAtIHRhcmdldFN0YXJ0IDwgZW5kIC0gc3RhcnQpIHsKICAgIGVuZCA9IHRhcmdldC5sZW5ndGggLSB0YXJnZXRTdGFydCArIHN0YXJ0CiAgfQoKICBjb25zdCBsZW4gPSBlbmQgLSBzdGFydAoKICBpZiAodGhpcyA9PT0gdGFyZ2V0ICYmIHR5cGVvZiBVaW50OEFycmF5LnByb3RvdHlwZS5jb3B5V2l0aGluID09PSAnZnVuY3Rpb24nKSB7CiAgICAvLyBVc2UgYnVpbHQtaW4gd2hlbiBhdmFpbGFibGUsIG1pc3NpbmcgZnJvbSBJRTExCiAgICB0aGlzLmNvcHlXaXRoaW4odGFyZ2V0U3RhcnQsIHN0YXJ0LCBlbmQpCiAgfSBlbHNlIHsKICAgIFVpbnQ4QXJyYXkucHJvdG90eXBlLnNldC5jYWxsKAogICAgICB0YXJnZXQsCiAgICAgIHRoaXMuc3ViYXJyYXkoc3RhcnQsIGVuZCksCiAgICAgIHRhcmdldFN0YXJ0CiAgICApCiAgfQoKICByZXR1cm4gbGVuCn0KCi8vIFVzYWdlOgovLyAgICBidWZmZXIuZmlsbChudW1iZXJbLCBvZmZzZXRbLCBlbmRdXSkKLy8gICAgYnVmZmVyLmZpbGwoYnVmZmVyWywgb2Zmc2V0WywgZW5kXV0pCi8vICAgIGJ1ZmZlci5maWxsKHN0cmluZ1ssIG9mZnNldFssIGVuZF1dWywgZW5jb2RpbmddKQpCdWZmZXIucHJvdG90eXBlLmZpbGwgPSBmdW5jdGlvbiBmaWxsICh2YWwsIHN0YXJ0LCBlbmQsIGVuY29kaW5nKSB7CiAgLy8gSGFuZGxlIHN0cmluZyBjYXNlczoKICBpZiAodHlwZW9mIHZhbCA9PT0gJ3N0cmluZycpIHsKICAgIGlmICh0eXBlb2Ygc3RhcnQgPT09ICdzdHJpbmcnKSB7CiAgICAgIGVuY29kaW5nID0gc3RhcnQKICAgICAgc3RhcnQgPSAwCiAgICAgIGVuZCA9IHRoaXMubGVuZ3RoCiAgICB9IGVsc2UgaWYgKHR5cGVvZiBlbmQgPT09ICdzdHJpbmcnKSB7CiAgICAgIGVuY29kaW5nID0gZW5kCiAgICAgIGVuZCA9IHRoaXMubGVuZ3RoCiAgICB9CiAgICBpZiAoZW5jb2RpbmcgIT09IHVuZGVmaW5lZCAmJiB0eXBlb2YgZW5jb2RpbmcgIT09ICdzdHJpbmcnKSB7CiAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ2VuY29kaW5nIG11c3QgYmUgYSBzdHJpbmcnKQogICAgfQogICAgaWYgKHR5cGVvZiBlbmNvZGluZyA9PT0gJ3N0cmluZycgJiYgIUJ1ZmZlci5pc0VuY29kaW5nKGVuY29kaW5nKSkgewogICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdVbmtub3duIGVuY29kaW5nOiAnICsgZW5jb2RpbmcpCiAgICB9CiAgICBpZiAodmFsLmxlbmd0aCA9PT0gMSkgewogICAgICBjb25zdCBjb2RlID0gdmFsLmNoYXJDb2RlQXQoMCkKICAgICAgaWYgKChlbmNvZGluZyA9PT0gJ3V0ZjgnICYmIGNvZGUgPCAxMjgpIHx8CiAgICAgICAgICBlbmNvZGluZyA9PT0gJ2xhdGluMScpIHsKICAgICAgICAvLyBGYXN0IHBhdGg6IElmIGB2YWxgIGZpdHMgaW50byBhIHNpbmdsZSBieXRlLCB1c2UgdGhhdCBudW1lcmljIHZhbHVlLgogICAgICAgIHZhbCA9IGNvZGUKICAgICAgfQogICAgfQogIH0gZWxzZSBpZiAodHlwZW9mIHZhbCA9PT0gJ251bWJlcicpIHsKICAgIHZhbCA9IHZhbCAmIDI1NQogIH0gZWxzZSBpZiAodHlwZW9mIHZhbCA9PT0gJ2Jvb2xlYW4nKSB7CiAgICB2YWwgPSBOdW1iZXIodmFsKQogIH0KCiAgLy8gSW52YWxpZCByYW5nZXMgYXJlIG5vdCBzZXQgdG8gYSBkZWZhdWx0LCBzbyBjYW4gcmFuZ2UgY2hlY2sgZWFybHkuCiAgaWYgKHN0YXJ0IDwgMCB8fCB0aGlzLmxlbmd0aCA8IHN0YXJ0IHx8IHRoaXMubGVuZ3RoIDwgZW5kKSB7CiAgICB0aHJvdyBuZXcgUmFuZ2VFcnJvcignT3V0IG9mIHJhbmdlIGluZGV4JykKICB9CgogIGlmIChlbmQgPD0gc3RhcnQpIHsKICAgIHJldHVybiB0aGlzCiAgfQoKICBzdGFydCA9IHN0YXJ0ID4+PiAwCiAgZW5kID0gZW5kID09PSB1bmRlZmluZWQgPyB0aGlzLmxlbmd0aCA6IGVuZCA+Pj4gMAoKICBpZiAoIXZhbCkgdmFsID0gMAoKICBsZXQgaQogIGlmICh0eXBlb2YgdmFsID09PSAnbnVtYmVyJykgewogICAgZm9yIChpID0gc3RhcnQ7IGkgPCBlbmQ7ICsraSkgewogICAgICB0aGlzW2ldID0gdmFsCiAgICB9CiAgfSBlbHNlIHsKICAgIGNvbnN0IGJ5dGVzID0gQnVmZmVyLmlzQnVmZmVyKHZhbCkKICAgICAgPyB2YWwKICAgICAgOiBCdWZmZXIuZnJvbSh2YWwsIGVuY29kaW5nKQogICAgY29uc3QgbGVuID0gYnl0ZXMubGVuZ3RoCiAgICBpZiAobGVuID09PSAwKSB7CiAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ1RoZSB2YWx1ZSAiJyArIHZhbCArCiAgICAgICAgJyIgaXMgaW52YWxpZCBmb3IgYXJndW1lbnQgInZhbHVlIicpCiAgICB9CiAgICBmb3IgKGkgPSAwOyBpIDwgZW5kIC0gc3RhcnQ7ICsraSkgewogICAgICB0aGlzW2kgKyBzdGFydF0gPSBieXRlc1tpICUgbGVuXQogICAgfQogIH0KCiAgcmV0dXJuIHRoaXMKfQoKLy8gQ1VTVE9NIEVSUk9SUwovLyA9PT09PT09PT09PT09CgovLyBTaW1wbGlmaWVkIHZlcnNpb25zIGZyb20gTm9kZSwgY2hhbmdlZCBmb3IgQnVmZmVyLW9ubHkgdXNhZ2UKY29uc3QgZXJyb3JzID0ge30KZnVuY3Rpb24gRSAoc3ltLCBnZXRNZXNzYWdlLCBCYXNlKSB7CiAgZXJyb3JzW3N5bV0gPSBjbGFzcyBOb2RlRXJyb3IgZXh0ZW5kcyBCYXNlIHsKICAgIGNvbnN0cnVjdG9yICgpIHsKICAgICAgc3VwZXIoKQoKICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRoaXMsICdtZXNzYWdlJywgewogICAgICAgIHZhbHVlOiBnZXRNZXNzYWdlLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyksCiAgICAgICAgd3JpdGFibGU6IHRydWUsCiAgICAgICAgY29uZmlndXJhYmxlOiB0cnVlCiAgICAgIH0pCgogICAgICAvLyBBZGQgdGhlIGVycm9yIGNvZGUgdG8gdGhlIG5hbWUgdG8gaW5jbHVkZSBpdCBpbiB0aGUgc3RhY2sgdHJhY2UuCiAgICAgIHRoaXMubmFtZSA9IGAke3RoaXMubmFtZX0gWyR7c3ltfV1gCiAgICAgIC8vIEFjY2VzcyB0aGUgc3RhY2sgdG8gZ2VuZXJhdGUgdGhlIGVycm9yIG1lc3NhZ2UgaW5jbHVkaW5nIHRoZSBlcnJvciBjb2RlCiAgICAgIC8vIGZyb20gdGhlIG5hbWUuCiAgICAgIHRoaXMuc3RhY2sgLy8gZXNsaW50LWRpc2FibGUtbGluZSBuby11bnVzZWQtZXhwcmVzc2lvbnMKICAgICAgLy8gUmVzZXQgdGhlIG5hbWUgdG8gdGhlIGFjdHVhbCBuYW1lLgogICAgICBkZWxldGUgdGhpcy5uYW1lCiAgICB9CgogICAgZ2V0IGNvZGUgKCkgewogICAgICByZXR1cm4gc3ltCiAgICB9CgogICAgc2V0IGNvZGUgKHZhbHVlKSB7CiAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCAnY29kZScsIHsKICAgICAgICBjb25maWd1cmFibGU6IHRydWUsCiAgICAgICAgZW51bWVyYWJsZTogdHJ1ZSwKICAgICAgICB2YWx1ZSwKICAgICAgICB3cml0YWJsZTogdHJ1ZQogICAgICB9KQogICAgfQoKICAgIHRvU3RyaW5nICgpIHsKICAgICAgcmV0dXJuIGAke3RoaXMubmFtZX0gWyR7c3ltfV06ICR7dGhpcy5tZXNzYWdlfWAKICAgIH0KICB9Cn0KCkUoJ0VSUl9CVUZGRVJfT1VUX09GX0JPVU5EUycsCiAgZnVuY3Rpb24gKG5hbWUpIHsKICAgIGlmIChuYW1lKSB7CiAgICAgIHJldHVybiBgJHtuYW1lfSBpcyBvdXRzaWRlIG9mIGJ1ZmZlciBib3VuZHNgCiAgICB9CgogICAgcmV0dXJuICdBdHRlbXB0IHRvIGFjY2VzcyBtZW1vcnkgb3V0c2lkZSBidWZmZXIgYm91bmRzJwogIH0sIFJhbmdlRXJyb3IpCkUoJ0VSUl9JTlZBTElEX0FSR19UWVBFJywKICBmdW5jdGlvbiAobmFtZSwgYWN0dWFsKSB7CiAgICByZXR1cm4gYFRoZSAiJHtuYW1lfSIgYXJndW1lbnQgbXVzdCBiZSBvZiB0eXBlIG51bWJlci4gUmVjZWl2ZWQgdHlwZSAke3R5cGVvZiBhY3R1YWx9YAogIH0sIFR5cGVFcnJvcikKRSgnRVJSX09VVF9PRl9SQU5HRScsCiAgZnVuY3Rpb24gKHN0ciwgcmFuZ2UsIGlucHV0KSB7CiAgICBsZXQgbXNnID0gYFRoZSB2YWx1ZSBvZiAiJHtzdHJ9IiBpcyBvdXQgb2YgcmFuZ2UuYAogICAgbGV0IHJlY2VpdmVkID0gaW5wdXQKICAgIGlmIChOdW1iZXIuaXNJbnRlZ2VyKGlucHV0KSAmJiBNYXRoLmFicyhpbnB1dCkgPiAyICoqIDMyKSB7CiAgICAgIHJlY2VpdmVkID0gYWRkTnVtZXJpY2FsU2VwYXJhdG9yKFN0cmluZyhpbnB1dCkpCiAgICB9IGVsc2UgaWYgKHR5cGVvZiBpbnB1dCA9PT0gJ2JpZ2ludCcpIHsKICAgICAgcmVjZWl2ZWQgPSBTdHJpbmcoaW5wdXQpCiAgICAgIGlmIChpbnB1dCA+IEJpZ0ludCgyKSAqKiBCaWdJbnQoMzIpIHx8IGlucHV0IDwgLShCaWdJbnQoMikgKiogQmlnSW50KDMyKSkpIHsKICAgICAgICByZWNlaXZlZCA9IGFkZE51bWVyaWNhbFNlcGFyYXRvcihyZWNlaXZlZCkKICAgICAgfQogICAgICByZWNlaXZlZCArPSAnbicKICAgIH0KICAgIG1zZyArPSBgIEl0IG11c3QgYmUgJHtyYW5nZX0uIFJlY2VpdmVkICR7cmVjZWl2ZWR9YAogICAgcmV0dXJuIG1zZwogIH0sIFJhbmdlRXJyb3IpCgpmdW5jdGlvbiBhZGROdW1lcmljYWxTZXBhcmF0b3IgKHZhbCkgewogIGxldCByZXMgPSAnJwogIGxldCBpID0gdmFsLmxlbmd0aAogIGNvbnN0IHN0YXJ0ID0gdmFsWzBdID09PSAnLScgPyAxIDogMAogIGZvciAoOyBpID49IHN0YXJ0ICsgNDsgaSAtPSAzKSB7CiAgICByZXMgPSBgXyR7dmFsLnNsaWNlKGkgLSAzLCBpKX0ke3Jlc31gCiAgfQogIHJldHVybiBgJHt2YWwuc2xpY2UoMCwgaSl9JHtyZXN9YAp9CgovLyBDSEVDSyBGVU5DVElPTlMKLy8gPT09PT09PT09PT09PT09CgpmdW5jdGlvbiBjaGVja0JvdW5kcyAoYnVmLCBvZmZzZXQsIGJ5dGVMZW5ndGgpIHsKICB2YWxpZGF0ZU51bWJlcihvZmZzZXQsICdvZmZzZXQnKQogIGlmIChidWZbb2Zmc2V0XSA9PT0gdW5kZWZpbmVkIHx8IGJ1ZltvZmZzZXQgKyBieXRlTGVuZ3RoXSA9PT0gdW5kZWZpbmVkKSB7CiAgICBib3VuZHNFcnJvcihvZmZzZXQsIGJ1Zi5sZW5ndGggLSAoYnl0ZUxlbmd0aCArIDEpKQogIH0KfQoKZnVuY3Rpb24gY2hlY2tJbnRCSSAodmFsdWUsIG1pbiwgbWF4LCBidWYsIG9mZnNldCwgYnl0ZUxlbmd0aCkgewogIGlmICh2YWx1ZSA+IG1heCB8fCB2YWx1ZSA8IG1pbikgewogICAgY29uc3QgbiA9IHR5cGVvZiBtaW4gPT09ICdiaWdpbnQnID8gJ24nIDogJycKICAgIGxldCByYW5nZQogICAgaWYgKGJ5dGVMZW5ndGggPiAzKSB7CiAgICAgIGlmIChtaW4gPT09IDAgfHwgbWluID09PSBCaWdJbnQoMCkpIHsKICAgICAgICByYW5nZSA9IGA+PSAwJHtufSBhbmQgPCAyJHtufSAqKiAkeyhieXRlTGVuZ3RoICsgMSkgKiA4fSR7bn1gCiAgICAgIH0gZWxzZSB7CiAgICAgICAgcmFuZ2UgPSBgPj0gLSgyJHtufSAqKiAkeyhieXRlTGVuZ3RoICsgMSkgKiA4IC0gMX0ke259KSBhbmQgPCAyICoqIGAgKwogICAgICAgICAgICAgICAgYCR7KGJ5dGVMZW5ndGggKyAxKSAqIDggLSAxfSR7bn1gCiAgICAgIH0KICAgIH0gZWxzZSB7CiAgICAgIHJhbmdlID0gYD49ICR7bWlufSR7bn0gYW5kIDw9ICR7bWF4fSR7bn1gCiAgICB9CiAgICB0aHJvdyBuZXcgZXJyb3JzLkVSUl9PVVRfT0ZfUkFOR0UoJ3ZhbHVlJywgcmFuZ2UsIHZhbHVlKQogIH0KICBjaGVja0JvdW5kcyhidWYsIG9mZnNldCwgYnl0ZUxlbmd0aCkKfQoKZnVuY3Rpb24gdmFsaWRhdGVOdW1iZXIgKHZhbHVlLCBuYW1lKSB7CiAgaWYgKHR5cGVvZiB2YWx1ZSAhPT0gJ251bWJlcicpIHsKICAgIHRocm93IG5ldyBlcnJvcnMuRVJSX0lOVkFMSURfQVJHX1RZUEUobmFtZSwgJ251bWJlcicsIHZhbHVlKQogIH0KfQoKZnVuY3Rpb24gYm91bmRzRXJyb3IgKHZhbHVlLCBsZW5ndGgsIHR5cGUpIHsKICBpZiAoTWF0aC5mbG9vcih2YWx1ZSkgIT09IHZhbHVlKSB7CiAgICB2YWxpZGF0ZU51bWJlcih2YWx1ZSwgdHlwZSkKICAgIHRocm93IG5ldyBlcnJvcnMuRVJSX09VVF9PRl9SQU5HRSh0eXBlIHx8ICdvZmZzZXQnLCAnYW4gaW50ZWdlcicsIHZhbHVlKQogIH0KCiAgaWYgKGxlbmd0aCA8IDApIHsKICAgIHRocm93IG5ldyBlcnJvcnMuRVJSX0JVRkZFUl9PVVRfT0ZfQk9VTkRTKCkKICB9CgogIHRocm93IG5ldyBlcnJvcnMuRVJSX09VVF9PRl9SQU5HRSh0eXBlIHx8ICdvZmZzZXQnLAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBgPj0gJHt0eXBlID8gMSA6IDB9IGFuZCA8PSAke2xlbmd0aH1gLAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZSkKfQoKLy8gSEVMUEVSIEZVTkNUSU9OUwovLyA9PT09PT09PT09PT09PT09Cgpjb25zdCBJTlZBTElEX0JBU0U2NF9SRSA9IC9bXisvMC05QS1aYS16LV9dL2cKCmZ1bmN0aW9uIGJhc2U2NGNsZWFuIChzdHIpIHsKICAvLyBOb2RlIHRha2VzIGVxdWFsIHNpZ25zIGFzIGVuZCBvZiB0aGUgQmFzZTY0IGVuY29kaW5nCiAgc3RyID0gc3RyLnNwbGl0KCc9JylbMF0KICAvLyBOb2RlIHN0cmlwcyBvdXQgaW52YWxpZCBjaGFyYWN0ZXJzIGxpa2UgXG4gYW5kIFx0IGZyb20gdGhlIHN0cmluZywgYmFzZTY0LWpzIGRvZXMgbm90CiAgc3RyID0gc3RyLnRyaW0oKS5yZXBsYWNlKElOVkFMSURfQkFTRTY0X1JFLCAnJykKICAvLyBOb2RlIGNvbnZlcnRzIHN0cmluZ3Mgd2l0aCBsZW5ndGggPCAyIHRvICcnCiAgaWYgKHN0ci5sZW5ndGggPCAyKSByZXR1cm4gJycKICAvLyBOb2RlIGFsbG93cyBmb3Igbm9uLXBhZGRlZCBiYXNlNjQgc3RyaW5ncyAobWlzc2luZyB0cmFpbGluZyA9PT0pLCBiYXNlNjQtanMgZG9lcyBub3QKICB3aGlsZSAoc3RyLmxlbmd0aCAlIDQgIT09IDApIHsKICAgIHN0ciA9IHN0ciArICc9JwogIH0KICByZXR1cm4gc3RyCn0KCmZ1bmN0aW9uIHV0ZjhUb0J5dGVzIChzdHJpbmcsIHVuaXRzKSB7CiAgdW5pdHMgPSB1bml0cyB8fCBJbmZpbml0eQogIGxldCBjb2RlUG9pbnQKICBjb25zdCBsZW5ndGggPSBzdHJpbmcubGVuZ3RoCiAgbGV0IGxlYWRTdXJyb2dhdGUgPSBudWxsCiAgY29uc3QgYnl0ZXMgPSBbXQoKICBmb3IgKGxldCBpID0gMDsgaSA8IGxlbmd0aDsgKytpKSB7CiAgICBjb2RlUG9pbnQgPSBzdHJpbmcuY2hhckNvZGVBdChpKQoKICAgIC8vIGlzIHN1cnJvZ2F0ZSBjb21wb25lbnQKICAgIGlmIChjb2RlUG9pbnQgPiAweEQ3RkYgJiYgY29kZVBvaW50IDwgMHhFMDAwKSB7CiAgICAgIC8vIGxhc3QgY2hhciB3YXMgYSBsZWFkCiAgICAgIGlmICghbGVhZFN1cnJvZ2F0ZSkgewogICAgICAgIC8vIG5vIGxlYWQgeWV0CiAgICAgICAgaWYgKGNvZGVQb2ludCA+IDB4REJGRikgewogICAgICAgICAgLy8gdW5leHBlY3RlZCB0cmFpbAogICAgICAgICAgaWYgKCh1bml0cyAtPSAzKSA+IC0xKSBieXRlcy5wdXNoKDB4RUYsIDB4QkYsIDB4QkQpCiAgICAgICAgICBjb250aW51ZQogICAgICAgIH0gZWxzZSBpZiAoaSArIDEgPT09IGxlbmd0aCkgewogICAgICAgICAgLy8gdW5wYWlyZWQgbGVhZAogICAgICAgICAgaWYgKCh1bml0cyAtPSAzKSA+IC0xKSBieXRlcy5wdXNoKDB4RUYsIDB4QkYsIDB4QkQpCiAgICAgICAgICBjb250aW51ZQogICAgICAgIH0KCiAgICAgICAgLy8gdmFsaWQgbGVhZAogICAgICAgIGxlYWRTdXJyb2dhdGUgPSBjb2RlUG9pbnQKCiAgICAgICAgY29udGludWUKICAgICAgfQoKICAgICAgLy8gMiBsZWFkcyBpbiBhIHJvdwogICAgICBpZiAoY29kZVBvaW50IDwgMHhEQzAwKSB7CiAgICAgICAgaWYgKCh1bml0cyAtPSAzKSA+IC0xKSBieXRlcy5wdXNoKDB4RUYsIDB4QkYsIDB4QkQpCiAgICAgICAgbGVhZFN1cnJvZ2F0ZSA9IGNvZGVQb2ludAogICAgICAgIGNvbnRpbnVlCiAgICAgIH0KCiAgICAgIC8vIHZhbGlkIHN1cnJvZ2F0ZSBwYWlyCiAgICAgIGNvZGVQb2ludCA9IChsZWFkU3Vycm9nYXRlIC0gMHhEODAwIDw8IDEwIHwgY29kZVBvaW50IC0gMHhEQzAwKSArIDB4MTAwMDAKICAgIH0gZWxzZSBpZiAobGVhZFN1cnJvZ2F0ZSkgewogICAgICAvLyB2YWxpZCBibXAgY2hhciwgYnV0IGxhc3QgY2hhciB3YXMgYSBsZWFkCiAgICAgIGlmICgodW5pdHMgLT0gMykgPiAtMSkgYnl0ZXMucHVzaCgweEVGLCAweEJGLCAweEJEKQogICAgfQoKICAgIGxlYWRTdXJyb2dhdGUgPSBudWxsCgogICAgLy8gZW5jb2RlIHV0ZjgKICAgIGlmIChjb2RlUG9pbnQgPCAweDgwKSB7CiAgICAgIGlmICgodW5pdHMgLT0gMSkgPCAwKSBicmVhawogICAgICBieXRlcy5wdXNoKGNvZGVQb2ludCkKICAgIH0gZWxzZSBpZiAoY29kZVBvaW50IDwgMHg4MDApIHsKICAgICAgaWYgKCh1bml0cyAtPSAyKSA8IDApIGJyZWFrCiAgICAgIGJ5dGVzLnB1c2goCiAgICAgICAgY29kZVBvaW50ID4+IDB4NiB8IDB4QzAsCiAgICAgICAgY29kZVBvaW50ICYgMHgzRiB8IDB4ODAKICAgICAgKQogICAgfSBlbHNlIGlmIChjb2RlUG9pbnQgPCAweDEwMDAwKSB7CiAgICAgIGlmICgodW5pdHMgLT0gMykgPCAwKSBicmVhawogICAgICBieXRlcy5wdXNoKAogICAgICAgIGNvZGVQb2ludCA+PiAweEMgfCAweEUwLAogICAgICAgIGNvZGVQb2ludCA+PiAweDYgJiAweDNGIHwgMHg4MCwKICAgICAgICBjb2RlUG9pbnQgJiAweDNGIHwgMHg4MAogICAgICApCiAgICB9IGVsc2UgaWYgKGNvZGVQb2ludCA8IDB4MTEwMDAwKSB7CiAgICAgIGlmICgodW5pdHMgLT0gNCkgPCAwKSBicmVhawogICAgICBieXRlcy5wdXNoKAogICAgICAgIGNvZGVQb2ludCA+PiAweDEyIHwgMHhGMCwKICAgICAgICBjb2RlUG9pbnQgPj4gMHhDICYgMHgzRiB8IDB4ODAsCiAgICAgICAgY29kZVBvaW50ID4+IDB4NiAmIDB4M0YgfCAweDgwLAogICAgICAgIGNvZGVQb2ludCAmIDB4M0YgfCAweDgwCiAgICAgICkKICAgIH0gZWxzZSB7CiAgICAgIHRocm93IG5ldyBFcnJvcignSW52YWxpZCBjb2RlIHBvaW50JykKICAgIH0KICB9CgogIHJldHVybiBieXRlcwp9CgpmdW5jdGlvbiBhc2NpaVRvQnl0ZXMgKHN0cikgewogIGNvbnN0IGJ5dGVBcnJheSA9IFtdCiAgZm9yIChsZXQgaSA9IDA7IGkgPCBzdHIubGVuZ3RoOyArK2kpIHsKICAgIC8vIE5vZGUncyBjb2RlIHNlZW1zIHRvIGJlIGRvaW5nIHRoaXMgYW5kIG5vdCAmIDB4N0YuLgogICAgYnl0ZUFycmF5LnB1c2goc3RyLmNoYXJDb2RlQXQoaSkgJiAweEZGKQogIH0KICByZXR1cm4gYnl0ZUFycmF5Cn0KCmZ1bmN0aW9uIHV0ZjE2bGVUb0J5dGVzIChzdHIsIHVuaXRzKSB7CiAgbGV0IGMsIGhpLCBsbwogIGNvbnN0IGJ5dGVBcnJheSA9IFtdCiAgZm9yIChsZXQgaSA9IDA7IGkgPCBzdHIubGVuZ3RoOyArK2kpIHsKICAgIGlmICgodW5pdHMgLT0gMikgPCAwKSBicmVhawoKICAgIGMgPSBzdHIuY2hhckNvZGVBdChpKQogICAgaGkgPSBjID4+IDgKICAgIGxvID0gYyAlIDI1NgogICAgYnl0ZUFycmF5LnB1c2gobG8pCiAgICBieXRlQXJyYXkucHVzaChoaSkKICB9CgogIHJldHVybiBieXRlQXJyYXkKfQoKZnVuY3Rpb24gYmFzZTY0VG9CeXRlcyAoc3RyKSB7CiAgcmV0dXJuIGJhc2U2NC50b0J5dGVBcnJheShiYXNlNjRjbGVhbihzdHIpKQp9CgpmdW5jdGlvbiBibGl0QnVmZmVyIChzcmMsIGRzdCwgb2Zmc2V0LCBsZW5ndGgpIHsKICBsZXQgaQogIGZvciAoaSA9IDA7IGkgPCBsZW5ndGg7ICsraSkgewogICAgaWYgKChpICsgb2Zmc2V0ID49IGRzdC5sZW5ndGgpIHx8IChpID49IHNyYy5sZW5ndGgpKSBicmVhawogICAgZHN0W2kgKyBvZmZzZXRdID0gc3JjW2ldCiAgfQogIHJldHVybiBpCn0KCi8vIEFycmF5QnVmZmVyIG9yIFVpbnQ4QXJyYXkgb2JqZWN0cyBmcm9tIG90aGVyIGNvbnRleHRzIChpLmUuIGlmcmFtZXMpIGRvIG5vdCBwYXNzCi8vIHRoZSBgaW5zdGFuY2VvZmAgY2hlY2sgYnV0IHRoZXkgc2hvdWxkIGJlIHRyZWF0ZWQgYXMgb2YgdGhhdCB0eXBlLgovLyBTZWU6IGh0dHBzOi8vZ2l0aHViLmNvbS9mZXJvc3MvYnVmZmVyL2lzc3Vlcy8xNjYKZnVuY3Rpb24gaXNJbnN0YW5jZSAob2JqLCB0eXBlKSB7CiAgcmV0dXJuIG9iaiBpbnN0YW5jZW9mIHR5cGUgfHwKICAgIChvYmogIT0gbnVsbCAmJiBvYmouY29uc3RydWN0b3IgIT0gbnVsbCAmJiBvYmouY29uc3RydWN0b3IubmFtZSAhPSBudWxsICYmCiAgICAgIG9iai5jb25zdHJ1Y3Rvci5uYW1lID09PSB0eXBlLm5hbWUpCn0KZnVuY3Rpb24gbnVtYmVySXNOYU4gKG9iaikgewogIC8vIEZvciBJRTExIHN1cHBvcnQKICByZXR1cm4gb2JqICE9PSBvYmogLy8gZXNsaW50LWRpc2FibGUtbGluZSBuby1zZWxmLWNvbXBhcmUKfQoKLy8gQ3JlYXRlIGxvb2t1cCB0YWJsZSBmb3IgYHRvU3RyaW5nKCdoZXgnKWAKLy8gU2VlOiBodHRwczovL2dpdGh1Yi5jb20vZmVyb3NzL2J1ZmZlci9pc3N1ZXMvMjE5CmNvbnN0IGhleFNsaWNlTG9va3VwVGFibGUgPSAoZnVuY3Rpb24gKCkgewogIGNvbnN0IGFscGhhYmV0ID0gJzAxMjM0NTY3ODlhYmNkZWYnCiAgY29uc3QgdGFibGUgPSBuZXcgQXJyYXkoMjU2KQogIGZvciAobGV0IGkgPSAwOyBpIDwgMTY7ICsraSkgewogICAgY29uc3QgaTE2ID0gaSAqIDE2CiAgICBmb3IgKGxldCBqID0gMDsgaiA8IDE2OyArK2opIHsKICAgICAgdGFibGVbaTE2ICsgal0gPSBhbHBoYWJldFtpXSArIGFscGhhYmV0W2pdCiAgICB9CiAgfQogIHJldHVybiB0YWJsZQp9KSgpCgovLyBSZXR1cm4gbm90IGZ1bmN0aW9uIHdpdGggRXJyb3IgaWYgQmlnSW50IG5vdCBzdXBwb3J0ZWQKZnVuY3Rpb24gZGVmaW5lQmlnSW50TWV0aG9kIChmbikgewogIHJldHVybiB0eXBlb2YgQmlnSW50ID09PSAndW5kZWZpbmVkJyA/IEJ1ZmZlckJpZ0ludE5vdERlZmluZWQgOiBmbgp9CgpmdW5jdGlvbiBCdWZmZXJCaWdJbnROb3REZWZpbmVkICgpIHsKICB0aHJvdyBuZXcgRXJyb3IoJ0JpZ0ludCBub3Qgc3VwcG9ydGVkJykKfQoKCi8qKiovIH0pLAoKLyoqKi8gNjQ1OgovKioqLyAoKF9fdW51c2VkX3dlYnBhY2tfbW9kdWxlLCBleHBvcnRzKSA9PiB7CgovKiEgaWVlZTc1NC4gQlNELTMtQ2xhdXNlIExpY2Vuc2UuIEZlcm9zcyBBYm91a2hhZGlqZWggPGh0dHBzOi8vZmVyb3NzLm9yZy9vcGVuc291cmNlPiAqLwpleHBvcnRzLnJlYWQgPSBmdW5jdGlvbiAoYnVmZmVyLCBvZmZzZXQsIGlzTEUsIG1MZW4sIG5CeXRlcykgewogIHZhciBlLCBtCiAgdmFyIGVMZW4gPSAobkJ5dGVzICogOCkgLSBtTGVuIC0gMQogIHZhciBlTWF4ID0gKDEgPDwgZUxlbikgLSAxCiAgdmFyIGVCaWFzID0gZU1heCA+PiAxCiAgdmFyIG5CaXRzID0gLTcKICB2YXIgaSA9IGlzTEUgPyAobkJ5dGVzIC0gMSkgOiAwCiAgdmFyIGQgPSBpc0xFID8gLTEgOiAxCiAgdmFyIHMgPSBidWZmZXJbb2Zmc2V0ICsgaV0KCiAgaSArPSBkCgogIGUgPSBzICYgKCgxIDw8ICgtbkJpdHMpKSAtIDEpCiAgcyA+Pj0gKC1uQml0cykKICBuQml0cyArPSBlTGVuCiAgZm9yICg7IG5CaXRzID4gMDsgZSA9IChlICogMjU2KSArIGJ1ZmZlcltvZmZzZXQgKyBpXSwgaSArPSBkLCBuQml0cyAtPSA4KSB7fQoKICBtID0gZSAmICgoMSA8PCAoLW5CaXRzKSkgLSAxKQogIGUgPj49ICgtbkJpdHMpCiAgbkJpdHMgKz0gbUxlbgogIGZvciAoOyBuQml0cyA+IDA7IG0gPSAobSAqIDI1NikgKyBidWZmZXJbb2Zmc2V0ICsgaV0sIGkgKz0gZCwgbkJpdHMgLT0gOCkge30KCiAgaWYgKGUgPT09IDApIHsKICAgIGUgPSAxIC0gZUJpYXMKICB9IGVsc2UgaWYgKGUgPT09IGVNYXgpIHsKICAgIHJldHVybiBtID8gTmFOIDogKChzID8gLTEgOiAxKSAqIEluZmluaXR5KQogIH0gZWxzZSB7CiAgICBtID0gbSArIE1hdGgucG93KDIsIG1MZW4pCiAgICBlID0gZSAtIGVCaWFzCiAgfQogIHJldHVybiAocyA/IC0xIDogMSkgKiBtICogTWF0aC5wb3coMiwgZSAtIG1MZW4pCn0KCmV4cG9ydHMud3JpdGUgPSBmdW5jdGlvbiAoYnVmZmVyLCB2YWx1ZSwgb2Zmc2V0LCBpc0xFLCBtTGVuLCBuQnl0ZXMpIHsKICB2YXIgZSwgbSwgYwogIHZhciBlTGVuID0gKG5CeXRlcyAqIDgpIC0gbUxlbiAtIDEKICB2YXIgZU1heCA9ICgxIDw8IGVMZW4pIC0gMQogIHZhciBlQmlhcyA9IGVNYXggPj4gMQogIHZhciBydCA9IChtTGVuID09PSAyMyA/IE1hdGgucG93KDIsIC0yNCkgLSBNYXRoLnBvdygyLCAtNzcpIDogMCkKICB2YXIgaSA9IGlzTEUgPyAwIDogKG5CeXRlcyAtIDEpCiAgdmFyIGQgPSBpc0xFID8gMSA6IC0xCiAgdmFyIHMgPSB2YWx1ZSA8IDAgfHwgKHZhbHVlID09PSAwICYmIDEgLyB2YWx1ZSA8IDApID8gMSA6IDAKCiAgdmFsdWUgPSBNYXRoLmFicyh2YWx1ZSkKCiAgaWYgKGlzTmFOKHZhbHVlKSB8fCB2YWx1ZSA9PT0gSW5maW5pdHkpIHsKICAgIG0gPSBpc05hTih2YWx1ZSkgPyAxIDogMAogICAgZSA9IGVNYXgKICB9IGVsc2UgewogICAgZSA9IE1hdGguZmxvb3IoTWF0aC5sb2codmFsdWUpIC8gTWF0aC5MTjIpCiAgICBpZiAodmFsdWUgKiAoYyA9IE1hdGgucG93KDIsIC1lKSkgPCAxKSB7CiAgICAgIGUtLQogICAgICBjICo9IDIKICAgIH0KICAgIGlmIChlICsgZUJpYXMgPj0gMSkgewogICAgICB2YWx1ZSArPSBydCAvIGMKICAgIH0gZWxzZSB7CiAgICAgIHZhbHVlICs9IHJ0ICogTWF0aC5wb3coMiwgMSAtIGVCaWFzKQogICAgfQogICAgaWYgKHZhbHVlICogYyA+PSAyKSB7CiAgICAgIGUrKwogICAgICBjIC89IDIKICAgIH0KCiAgICBpZiAoZSArIGVCaWFzID49IGVNYXgpIHsKICAgICAgbSA9IDAKICAgICAgZSA9IGVNYXgKICAgIH0gZWxzZSBpZiAoZSArIGVCaWFzID49IDEpIHsKICAgICAgbSA9ICgodmFsdWUgKiBjKSAtIDEpICogTWF0aC5wb3coMiwgbUxlbikKICAgICAgZSA9IGUgKyBlQmlhcwogICAgfSBlbHNlIHsKICAgICAgbSA9IHZhbHVlICogTWF0aC5wb3coMiwgZUJpYXMgLSAxKSAqIE1hdGgucG93KDIsIG1MZW4pCiAgICAgIGUgPSAwCiAgICB9CiAgfQoKICBmb3IgKDsgbUxlbiA+PSA4OyBidWZmZXJbb2Zmc2V0ICsgaV0gPSBtICYgMHhmZiwgaSArPSBkLCBtIC89IDI1NiwgbUxlbiAtPSA4KSB7fQoKICBlID0gKGUgPDwgbUxlbikgfCBtCiAgZUxlbiArPSBtTGVuCiAgZm9yICg7IGVMZW4gPiAwOyBidWZmZXJbb2Zmc2V0ICsgaV0gPSBlICYgMHhmZiwgaSArPSBkLCBlIC89IDI1NiwgZUxlbiAtPSA4KSB7fQoKICBidWZmZXJbb2Zmc2V0ICsgaSAtIGRdIHw9IHMgKiAxMjgKfQoKCi8qKiovIH0pCgovKioqKioqLyAJfSk7Ci8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovCi8qKioqKiovIAkvLyBUaGUgbW9kdWxlIGNhY2hlCi8qKioqKiovIAl2YXIgX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fID0ge307Ci8qKioqKiovIAkKLyoqKioqKi8gCS8vIFRoZSByZXF1aXJlIGZ1bmN0aW9uCi8qKioqKiovIAlmdW5jdGlvbiBfX3dlYnBhY2tfcmVxdWlyZV9fKG1vZHVsZUlkKSB7Ci8qKioqKiovIAkJLy8gQ2hlY2sgaWYgbW9kdWxlIGlzIGluIGNhY2hlCi8qKioqKiovIAkJdmFyIGNhY2hlZE1vZHVsZSA9IF9fd2VicGFja19tb2R1bGVfY2FjaGVfX1ttb2R1bGVJZF07Ci8qKioqKiovIAkJaWYgKGNhY2hlZE1vZHVsZSAhPT0gdW5kZWZpbmVkKSB7Ci8qKioqKiovIAkJCXJldHVybiBjYWNoZWRNb2R1bGUuZXhwb3J0czsKLyoqKioqKi8gCQl9Ci8qKioqKiovIAkJLy8gQ3JlYXRlIGEgbmV3IG1vZHVsZSAoYW5kIHB1dCBpdCBpbnRvIHRoZSBjYWNoZSkKLyoqKioqKi8gCQl2YXIgbW9kdWxlID0gX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fW21vZHVsZUlkXSA9IHsKLyoqKioqKi8gCQkJLy8gbm8gbW9kdWxlLmlkIG5lZWRlZAovKioqKioqLyAJCQkvLyBubyBtb2R1bGUubG9hZGVkIG5lZWRlZAovKioqKioqLyAJCQlleHBvcnRzOiB7fQovKioqKioqLyAJCX07Ci8qKioqKiovIAkKLyoqKioqKi8gCQkvLyBFeGVjdXRlIHRoZSBtb2R1bGUgZnVuY3Rpb24KLyoqKioqKi8gCQlfX3dlYnBhY2tfbW9kdWxlc19fW21vZHVsZUlkXShtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTsKLyoqKioqKi8gCQovKioqKioqLyAJCS8vIFJldHVybiB0aGUgZXhwb3J0cyBvZiB0aGUgbW9kdWxlCi8qKioqKiovIAkJcmV0dXJuIG1vZHVsZS5leHBvcnRzOwovKioqKioqLyAJfQovKioqKioqLyAJCi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovCnZhciBfX3dlYnBhY2tfZXhwb3J0c19fID0ge307Ci8vIFRoaXMgZW50cnkgbmVlZCB0byBiZSB3cmFwcGVkIGluIGFuIElJRkUgYmVjYXVzZSBpdCBuZWVkIHRvIGJlIGluIHN0cmljdCBtb2RlLgooKCkgPT4gewoidXNlIHN0cmljdCI7Cgo7Ly8gQ09OQ0FURU5BVEVEIE1PRFVMRTogLi9ub2RlX21vZHVsZXMvQGhhemFlNDEvc3ltYm9sLWRpc3Bvc2UtcG9seWZpbGwvZGlzdC9lc20vbW9kcy9zeW1ib2wtZGlzcG9zZS1wb2x5ZmlsbC9wb2x5ZmlsbC5tanMKaWYgKHR5cGVvZiBTeW1ib2wuZGlzcG9zZSAhPT0gInN5bWJvbCIpCiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoU3ltYm9sLCAiZGlzcG9zZSIsIHsKICAgICAgICBjb25maWd1cmFibGU6IGZhbHNlLAogICAgICAgIGVudW1lcmFibGU6IGZhbHNlLAogICAgICAgIHdyaXRhYmxlOiBmYWxzZSwKICAgICAgICB2YWx1ZTogU3ltYm9sLmZvcigiZGlzcG9zZSIpCiAgICB9KTsKaWYgKHR5cGVvZiBTeW1ib2wuYXN5bmNEaXNwb3NlICE9PSAic3ltYm9sIikKICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShTeW1ib2wsICJhc3luY0Rpc3Bvc2UiLCB7CiAgICAgICAgY29uZmlndXJhYmxlOiBmYWxzZSwKICAgICAgICBlbnVtZXJhYmxlOiBmYWxzZSwKICAgICAgICB3cml0YWJsZTogZmFsc2UsCiAgICAgICAgdmFsdWU6IFN5bWJvbC5mb3IoImFzeW5jRGlzcG9zZSIpCiAgICB9KTsKLy8jIHNvdXJjZU1hcHBpbmdVUkw9cG9seWZpbGwubWpzLm1hcAoKOy8vIENPTkNBVEVOQVRFRCBNT0RVTEU6IC4vbm9kZV9tb2R1bGVzL0BoYXphZTQxL3N5bWJvbC1kaXNwb3NlLXBvbHlmaWxsL2Rpc3QvZXNtL2luZGV4Lm1qcwoKLy8jIHNvdXJjZU1hcHBpbmdVUkw9aW5kZXgubWpzLm1hcAoKOy8vIENPTkNBVEVOQVRFRCBNT0RVTEU6IC4vbm9kZV9tb2R1bGVzL0BoYXphZTQxL29wdGlvbi9kaXN0L2VzbS9tb2RzL29wdGlvbi9vcHRpb24ubWpzCgoKCnZhciBPcHRpb247CihmdW5jdGlvbiAoT3B0aW9uKSB7CiAgICBmdW5jdGlvbiBmcm9tKGluaXQpIHsKICAgICAgICBpZiAoImlubmVyIiBpbiBpbml0KQogICAgICAgICAgICByZXR1cm4gbmV3IFNvbWUoaW5pdC5pbm5lcik7CiAgICAgICAgcmV0dXJuIG5ldyBOb25lKCk7CiAgICB9CiAgICBPcHRpb24uZnJvbSA9IGZyb207CiAgICAvKioKICAgICAqIENyZWF0ZSBhbiBPcHRpb24gZnJvbSBhIG51bGxhYmxlIHZhbHVlCiAgICAgKiBAcGFyYW0gaW5uZXIKICAgICAqIEByZXR1cm5zIGBTb21lPFQ+YCBpZiBgVGAsIGBOb25lYCBpZiBgdW5kZWZpbmVkYAogICAgICovCiAgICBmdW5jdGlvbiB3cmFwKGlubmVyKSB7CiAgICAgICAgaWYgKGlubmVyID09IG51bGwpCiAgICAgICAgICAgIHJldHVybiBuZXcgTm9uZSgpOwogICAgICAgIHJldHVybiBuZXcgU29tZShpbm5lcik7CiAgICB9CiAgICBPcHRpb24ud3JhcCA9IHdyYXA7CiAgICBhc3luYyBmdW5jdGlvbiBtYXAoaW5uZXIsIG1hcHBlcikgewogICAgICAgIHJldHVybiBPcHRpb24ud3JhcChpbm5lcikubWFwKG1hcHBlcikudGhlbihvID0+IG8uZ2V0KCkpOwogICAgfQogICAgT3B0aW9uLm1hcCA9IG1hcDsKICAgIGZ1bmN0aW9uIG1hcFN5bmMoaW5uZXIsIG1hcHBlcikgewogICAgICAgIHJldHVybiBPcHRpb24ud3JhcChpbm5lcikubWFwU3luYyhtYXBwZXIpLmdldCgpOwogICAgfQogICAgT3B0aW9uLm1hcFN5bmMgPSBtYXBTeW5jOwogICAgZnVuY3Rpb24gdW53cmFwKGlubmVyKSB7CiAgICAgICAgcmV0dXJuIE9wdGlvbi53cmFwKGlubmVyKS51bndyYXAoKTsKICAgIH0KICAgIE9wdGlvbi51bndyYXAgPSB1bndyYXA7Cn0pKE9wdGlvbiB8fCAoT3B0aW9uID0ge30pKTsKCgovLyMgc291cmNlTWFwcGluZ1VSTD1vcHRpb24ubWpzLm1hcAoKOy8vIENPTkNBVEVOQVRFRCBNT0RVTEU6IC4vbm9kZV9tb2R1bGVzL0BoYXphZTQxL3Jlc3VsdC9kaXN0L2VzbS9tb2RzL3Jlc3VsdC9yZXN1bHQubWpzCgoKCgoKdmFyIFJlc3VsdDsKKGZ1bmN0aW9uIChSZXN1bHQpIHsKICAgIFJlc3VsdC5kZWJ1ZyA9IGZhbHNlOwogICAgLyoqCiAgICAgKiBDcmVhdGUgYSBSZXN1bHQgZnJvbSBhIG1heWJlIEVycm9yIHZhbHVlCiAgICAgKiBAcGFyYW0gaW5uZXIKICAgICAqIEByZXR1cm5zIGBPazxUPmAgaWYgYFRgLCBgRXJyPEVycm9yPmAgaWYgYEVycm9yYAogICAgICovCiAgICBmdW5jdGlvbiBmcm9tKGlubmVyKSB7CiAgICAgICAgaWYgKGlubmVyIGluc3RhbmNlb2YgRXJyb3IpCiAgICAgICAgICAgIHJldHVybiBuZXcgRXJyKGlubmVyKTsKICAgICAgICBlbHNlCiAgICAgICAgICAgIHJldHVybiBuZXcgT2soaW5uZXIpOwogICAgfQogICAgUmVzdWx0LmZyb20gPSBmcm9tOwogICAgLyoqCiAgICAgKiBDcmVhdGUgYSBSZXN1bHQgZnJvbSBhIGJvb2xlYW4KICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHJldHVybnMKICAgICAqLwogICAgZnVuY3Rpb24gYXNzZXJ0KHZhbHVlKSB7CiAgICAgICAgcmV0dXJuIHZhbHVlID8gT2sudm9pZCgpIDogbmV3IEVycihuZXcgQXNzZXJ0RXJyb3IoKSk7CiAgICB9CiAgICBSZXN1bHQuYXNzZXJ0ID0gYXNzZXJ0OwogICAgZnVuY3Rpb24gcmV3cmFwKHdyYXBwZXIpIHsKICAgICAgICB0cnkgewogICAgICAgICAgICByZXR1cm4gbmV3IE9rKHdyYXBwZXIudW53cmFwKCkpOwogICAgICAgIH0KICAgICAgICBjYXRjaCAoZXJyb3IpIHsKICAgICAgICAgICAgcmV0dXJuIG5ldyBFcnIoZXJyb3IpOwogICAgICAgIH0KICAgIH0KICAgIFJlc3VsdC5yZXdyYXAgPSByZXdyYXA7CiAgICAvKioKICAgICAqIENhdGNoIGFuIEVyciB0aHJvd24gZnJvbSBFcnIudGhyb3cKICAgICAqIEBwYXJhbSBjYWxsYmFjawogICAgICogQHBhcmFtIHR5cGUKICAgICAqIEByZXR1cm5zIGBPazxUPmAgaWYgbm8gYEVycmAgd2FzIHRocm93biwgYEVycjxFPmAgb3RoZXJ3aXNlCiAgICAgKiBAc2VlIEVyci50aHJvdwogICAgICovCiAgICBhc3luYyBmdW5jdGlvbiB1bnRocm93KGNhbGxiYWNrKSB7CiAgICAgICAgbGV0IHJlZjsKICAgICAgICB0cnkgewogICAgICAgICAgICByZXR1cm4gYXdhaXQgY2FsbGJhY2soKGUpID0+IHJlZiA9IGUpOwogICAgICAgIH0KICAgICAgICBjYXRjaCAoZSkgewogICAgICAgICAgICBpZiAocmVmICE9PSB1bmRlZmluZWQpCiAgICAgICAgICAgICAgICByZXR1cm4gcmVmOwogICAgICAgICAgICB0aHJvdyBlOwogICAgICAgIH0KICAgIH0KICAgIFJlc3VsdC51bnRocm93ID0gdW50aHJvdzsKICAgIC8qKgogICAgICogQ2F0Y2ggYW4gRXJyIHRocm93biBmcm9tIEVyci50aHJvdwogICAgICogQHBhcmFtIGNhbGxiYWNrCiAgICAgKiBAcGFyYW0gdHlwZQogICAgICogQHJldHVybnMgYE9rPFQ+YCBpZiBubyBgRXJyYCB3YXMgdGhyb3duLCBgRXJyPEU+YCBvdGhlcndpc2UKICAgICAqIEBzZWUgRXJyLnRocm93CiAgICAgKi8KICAgIGZ1bmN0aW9uIHVudGhyb3dTeW5jKGNhbGxiYWNrKSB7CiAgICAgICAgbGV0IHJlZjsKICAgICAgICB0cnkgewogICAgICAgICAgICByZXR1cm4gY2FsbGJhY2soKGUpID0+IHJlZiA9IGUpOwogICAgICAgIH0KICAgICAgICBjYXRjaCAoZSkgewogICAgICAgICAgICBpZiAocmVmICE9PSB1bmRlZmluZWQpCiAgICAgICAgICAgICAgICByZXR1cm4gcmVmOwogICAgICAgICAgICB0aHJvdyBlOwogICAgICAgIH0KICAgIH0KICAgIFJlc3VsdC51bnRocm93U3luYyA9IHVudGhyb3dTeW5jOwogICAgLyoqCiAgICAgKiBDb252ZXJ0IHRyeS1jYXRjaCB0byBSZXN1bHQ8VCwgdW5rbm93bj4KICAgICAqIEBwYXJhbSBjYWxsYmFjawogICAgICogQHJldHVybnMKICAgICAqLwogICAgYXN5bmMgZnVuY3Rpb24gcnVuQW5kV3JhcChjYWxsYmFjaykgewogICAgICAgIHRyeSB7CiAgICAgICAgICAgIHJldHVybiBuZXcgT2soYXdhaXQgY2FsbGJhY2soKSk7CiAgICAgICAgfQogICAgICAgIGNhdGNoIChlKSB7CiAgICAgICAgICAgIHJldHVybiBuZXcgRXJyKGUpOwogICAgICAgIH0KICAgIH0KICAgIFJlc3VsdC5ydW5BbmRXcmFwID0gcnVuQW5kV3JhcDsKICAgIC8qKgogICAgICogQ29udmVydCB0cnktY2F0Y2ggdG8gUmVzdWx0PFQsIHVua25vd24+CiAgICAgKiBAcGFyYW0gY2FsbGJhY2sKICAgICAqIEByZXR1cm5zCiAgICAgKi8KICAgIGZ1bmN0aW9uIHJ1bkFuZFdyYXBTeW5jKGNhbGxiYWNrKSB7CiAgICAgICAgdHJ5IHsKICAgICAgICAgICAgcmV0dXJuIG5ldyBPayhjYWxsYmFjaygpKTsKICAgICAgICB9CiAgICAgICAgY2F0Y2ggKGUpIHsKICAgICAgICAgICAgcmV0dXJuIG5ldyBFcnIoZSk7CiAgICAgICAgfQogICAgfQogICAgUmVzdWx0LnJ1bkFuZFdyYXBTeW5jID0gcnVuQW5kV3JhcFN5bmM7CiAgICAvKioKICAgICAqIENvbnZlcnQgdHJ5LWNhdGNoIHRvIFJlc3VsdDxULCBDYXRjaGVkPgogICAgICogQHBhcmFtIGNhbGxiYWNrCiAgICAgKiBAcmV0dXJucwogICAgICovCiAgICBhc3luYyBmdW5jdGlvbiBydW5BbmREb3VibGVXcmFwKGNhbGxiYWNrKSB7CiAgICAgICAgcmV0dXJuIHJ1bkFuZFdyYXAoY2FsbGJhY2spLnRoZW4ociA9PiByLm1hcEVyclN5bmMoQ2F0Y2hlZC5mcm9tKSk7CiAgICB9CiAgICBSZXN1bHQucnVuQW5kRG91YmxlV3JhcCA9IHJ1bkFuZERvdWJsZVdyYXA7CiAgICAvKioKICAgICAqIENvbnZlcnQgdHJ5LWNhdGNoIHRvIFJlc3VsdDxULCBDYXRjaGVkPgogICAgICogQHBhcmFtIGNhbGxiYWNrCiAgICAgKiBAcmV0dXJucwogICAgICovCiAgICBmdW5jdGlvbiBydW5BbmREb3VibGVXcmFwU3luYyhjYWxsYmFjaykgewogICAgICAgIHJldHVybiBydW5BbmRXcmFwU3luYyhjYWxsYmFjaykubWFwRXJyU3luYyhDYXRjaGVkLmZyb20pOwogICAgfQogICAgUmVzdWx0LnJ1bkFuZERvdWJsZVdyYXBTeW5jID0gcnVuQW5kRG91YmxlV3JhcFN5bmM7CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBSZXN1bHQ8UmVzdWx0PFQsIEUxPiwgRTI+IGludG8gUmVzdWx0PFQsIEUxIHwgRTI+CiAgICAgKiBAcGFyYW0gcmVzdWx0CiAgICAgKiBAcmV0dXJucyBgdGhpc2AgaWYgYEVycmAsIGB0aGlzLmlubmVyYCBpZiBgT2tgCiAgICAgKi8KICAgIGZ1bmN0aW9uIGZsYXR0ZW4ocmVzdWx0KSB7CiAgICAgICAgaWYgKHJlc3VsdC5pc0VycigpKQogICAgICAgICAgICByZXR1cm4gcmVzdWx0OwogICAgICAgIHJldHVybiByZXN1bHQuZ2V0KCk7CiAgICB9CiAgICBSZXN1bHQuZmxhdHRlbiA9IGZsYXR0ZW47CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBgSXRlcmFibGU8UmVzdWx0PFQsRT5gIGludG8gYFJlc3VsdDxBcnJheTxUPiwgRT5gCiAgICAgKiBAcGFyYW0gaXRlcmFibGUKICAgICAqIEByZXR1cm5zIGBSZXN1bHQ8QXJyYXk8VD4sIEU+YAogICAgICovCiAgICBmdW5jdGlvbiBhbGwoaXRlcmFibGUpIHsKICAgICAgICByZXR1cm4gY29sbGVjdChpdGVyYXRlKGl0ZXJhYmxlKSk7CiAgICB9CiAgICBSZXN1bHQuYWxsID0gYWxsOwogICAgZnVuY3Rpb24gbWF5YmVBbGwoaXRlcmFibGUpIHsKICAgICAgICByZXR1cm4gbWF5YmVDb2xsZWN0KG1heWJlSXRlcmF0ZShpdGVyYWJsZSkpOwogICAgfQogICAgUmVzdWx0Lm1heWJlQWxsID0gbWF5YmVBbGw7CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBgSXRlcmFibGU8UmVzdWx0PFQsRT5gIGludG8gYEl0ZXJhdG9yPFQsIFJlc3VsdDx2b2lkLCBFPj5gCiAgICAgKiBAcGFyYW0gaXRlcmFibGUKICAgICAqIEByZXR1cm5zIGBJdGVyYXRvcjxULCBSZXN1bHQ8dm9pZCwgRT4+YAogICAgICovCiAgICBmdW5jdGlvbiogaXRlcmF0ZShpdGVyYWJsZSkgewogICAgICAgIGZvciAoY29uc3QgcmVzdWx0IG9mIGl0ZXJhYmxlKSB7CiAgICAgICAgICAgIGlmIChyZXN1bHQuaXNPaygpKQogICAgICAgICAgICAgICAgeWllbGQgcmVzdWx0LmdldCgpOwogICAgICAgICAgICBlbHNlCiAgICAgICAgICAgICAgICByZXR1cm4gcmVzdWx0OwogICAgICAgIH0KICAgICAgICByZXR1cm4gT2sudm9pZCgpOwogICAgfQogICAgUmVzdWx0Lml0ZXJhdGUgPSBpdGVyYXRlOwogICAgZnVuY3Rpb24qIG1heWJlSXRlcmF0ZShpdGVyYWJsZSkgewogICAgICAgIGZvciAoY29uc3QgcmVzdWx0IG9mIGl0ZXJhYmxlKSB7CiAgICAgICAgICAgIGlmIChyZXN1bHQgPT0gbnVsbCkKICAgICAgICAgICAgICAgIHJldHVybiByZXN1bHQ7CiAgICAgICAgICAgIGVsc2UgaWYgKHJlc3VsdC5pc09rKCkpCiAgICAgICAgICAgICAgICB5aWVsZCByZXN1bHQuZ2V0KCk7CiAgICAgICAgICAgIGVsc2UKICAgICAgICAgICAgICAgIHJldHVybiByZXN1bHQ7CiAgICAgICAgfQogICAgICAgIHJldHVybiBPay52b2lkKCk7CiAgICB9CiAgICBSZXN1bHQubWF5YmVJdGVyYXRlID0gbWF5YmVJdGVyYXRlOwogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm0gYEl0ZXJhdG9yPFQsIFJlc3VsdDx2b2lkLCBFPj5gIGludG8gYFJlc3VsdDxBcnJheTxUPiwgRT5gCiAgICAgKiBAcGFyYW0gaXRlcmF0b3IgYFJlc3VsdDxBcnJheTxUPiwgRT5gCiAgICAgKi8KICAgIGZ1bmN0aW9uIGNvbGxlY3QoaXRlcmF0b3IpIHsKICAgICAgICBjb25zdCBhcnJheSA9IG5ldyBBcnJheSgpOwogICAgICAgIGxldCByZXN1bHQgPSBpdGVyYXRvci5uZXh0KCk7CiAgICAgICAgZm9yICg7ICFyZXN1bHQuZG9uZTsgcmVzdWx0ID0gaXRlcmF0b3IubmV4dCgpKQogICAgICAgICAgICBhcnJheS5wdXNoKHJlc3VsdC52YWx1ZSk7CiAgICAgICAgcmV0dXJuIHJlc3VsdC52YWx1ZS5zZXQoYXJyYXkpOwogICAgfQogICAgUmVzdWx0LmNvbGxlY3QgPSBjb2xsZWN0OwogICAgZnVuY3Rpb24gbWF5YmVDb2xsZWN0KGl0ZXJhdG9yKSB7CiAgICAgICAgY29uc3QgYXJyYXkgPSBuZXcgQXJyYXkoKTsKICAgICAgICBsZXQgcmVzdWx0ID0gaXRlcmF0b3IubmV4dCgpOwogICAgICAgIGZvciAoOyAhcmVzdWx0LmRvbmU7IHJlc3VsdCA9IGl0ZXJhdG9yLm5leHQoKSkKICAgICAgICAgICAgYXJyYXkucHVzaChyZXN1bHQudmFsdWUpOwogICAgICAgIHJldHVybiBPcHRpb24ubWFwU3luYyhyZXN1bHQudmFsdWUsIHJlc3VsdCA9PiByZXN1bHQuc2V0KGFycmF5KSk7CiAgICB9CiAgICBSZXN1bHQubWF5YmVDb2xsZWN0ID0gbWF5YmVDb2xsZWN0OwogICAgLyoqCiAgICAgKiBVbndyYXAgdGhlIGNhbGxiYWNrIGJ1dCB3cmFwIHRocm93biBlcnJvcnMgaW4gQ2F0Y2hlZAogICAgICogQHBhcmFtIGNhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgVGAgaWYgYE9rYAogICAgICogQHRocm93cyBgQ2F0Y2hlZGAgaWYgYGNhbGxiYWNrKClgIHRocm93cywgYEVgIGlmIGBFcnJgCiAgICAgKi8KICAgIGFzeW5jIGZ1bmN0aW9uIHJ1bkFuZFVud3JhcChjYWxsYmFjaykgewogICAgICAgIGxldCByZXN1bHQ7CiAgICAgICAgdHJ5IHsKICAgICAgICAgICAgcmVzdWx0ID0gYXdhaXQgY2FsbGJhY2soKTsKICAgICAgICB9CiAgICAgICAgY2F0Y2ggKGUpIHsKICAgICAgICAgICAgdGhyb3cgQ2F0Y2hlZC5mcm9tKGUpOwogICAgICAgIH0KICAgICAgICByZXR1cm4gcmVzdWx0LnVud3JhcCgpOwogICAgfQogICAgUmVzdWx0LnJ1bkFuZFVud3JhcCA9IHJ1bkFuZFVud3JhcDsKICAgIC8qKgogICAgICogVW53cmFwIHRoZSBjYWxsYmFjayBidXQgd3JhcCB0aHJvd24gZXJyb3JzIGluIENhdGNoZWQKICAgICAqIEBwYXJhbSBjYWxsYmFjawogICAgICogQHJldHVybnMgYFRgIGlmIGBPa2AKICAgICAqIEB0aHJvd3MgYENhdGNoZWRgIGlmIGBjYWxsYmFjaygpYCB0aHJvd3MsIGBFYCBpZiBgRXJyYAogICAgICovCiAgICBmdW5jdGlvbiBydW5BbmRVbndyYXBTeW5jKGNhbGxiYWNrKSB7CiAgICAgICAgbGV0IHJlc3VsdDsKICAgICAgICB0cnkgewogICAgICAgICAgICByZXN1bHQgPSBjYWxsYmFjaygpOwogICAgICAgIH0KICAgICAgICBjYXRjaCAoZSkgewogICAgICAgICAgICB0aHJvdyBDYXRjaGVkLmZyb20oZSk7CiAgICAgICAgfQogICAgICAgIHJldHVybiByZXN1bHQudW53cmFwKCk7CiAgICB9CiAgICBSZXN1bHQucnVuQW5kVW53cmFwU3luYyA9IHJ1bkFuZFVud3JhcFN5bmM7Cn0pKFJlc3VsdCB8fCAoUmVzdWx0ID0ge30pKTsKCgovLyMgc291cmNlTWFwcGluZ1VSTD1yZXN1bHQubWpzLm1hcAoKOy8vIENPTkNBVEVOQVRFRCBNT0RVTEU6IC4vbm9kZV9tb2R1bGVzL0BoYXphZTQxL3Jlc3VsdC9kaXN0L2VzbS9tb2RzL3Jlc3VsdC9lcnIubWpzCgoKCgpjbGFzcyBFcnIgewogICAgI2lubmVyOwogICAgI3RpbWVvdXQ7CiAgICAvKioKICAgICAqIEEgZmFpbHVyZQogICAgICogQHBhcmFtIGlubmVyCiAgICAgKi8KICAgIGNvbnN0cnVjdG9yKGlubmVyKSB7CiAgICAgICAgdGhpcy4jaW5uZXIgPSBpbm5lcjsKICAgICAgICBpZiAoIVJlc3VsdC5kZWJ1ZykKICAgICAgICAgICAgcmV0dXJuOwogICAgICAgIGNvbnN0IGVycm9yID0gbmV3IFBhbmljKGBVbmhhbmRsZWRgLCB7IGNhdXNlOiB0aGlzLmlubmVyIH0pOwogICAgICAgIHRoaXMuI3RpbWVvdXQgPSBzZXRUaW1lb3V0KCgpID0+IHsgdGhyb3cgZXJyb3I7IH0sIDEwMDApOwogICAgfQogICAgLyoqCiAgICAgKiBDcmVhdGUgYW4gZW1wdHkgYEVycmAKICAgICAqIEByZXR1cm5zIGBFcnIodm9pZClgCiAgICAgKi8KICAgIHN0YXRpYyB2b2lkKCkgewogICAgICAgIHJldHVybiBuZXcgRXJyKHVuZGVmaW5lZCk7CiAgICB9CiAgICAvKioKICAgICAqIENyZWF0ZSBhbiBgRXJyYAogICAgICogQHBhcmFtIGlubmVyCiAgICAgKiBAcmV0dXJucyBgRXJyKGlubmVyKWAKICAgICAqLwogICAgc3RhdGljIG5ldyhpbm5lcikgewogICAgICAgIHJldHVybiBuZXcgRXJyKGlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogQ3JlYXRlIGFuIGBFcnJgIHdpdGggYW4gYEVycm9yYCBpbnNpZGUKICAgICAqIEBwYXJhbSBtZXNzYWdlCiAgICAgKiBAcGFyYW0gb3B0aW9ucwogICAgICogQHJldHVybnMgYEVycjxFcnJvcj5gCiAgICAgKi8KICAgIHN0YXRpYyBlcnJvcihtZXNzYWdlLCBvcHRpb25zKSB7CiAgICAgICAgcmV0dXJuIG5ldyBFcnIobmV3IEVycm9yKG1lc3NhZ2UsIG9wdGlvbnMpKTsKICAgIH0KICAgIGdldCBpbm5lcigpIHsKICAgICAgICByZXR1cm4gdGhpcy4jaW5uZXI7CiAgICB9CiAgICAvKioKICAgICAqIFNldCB0aGlzIHJlc3VsdCBhcyBoYW5kbGVkCiAgICAgKi8KICAgIGlnbm9yZSgpIHsKICAgICAgICBpZiAoIXRoaXMuI3RpbWVvdXQpCiAgICAgICAgICAgIHJldHVybiB0aGlzOwogICAgICAgIGNsZWFyVGltZW91dCh0aGlzLiN0aW1lb3V0KTsKICAgICAgICB0aGlzLiN0aW1lb3V0ID0gdW5kZWZpbmVkOwogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBUeXBlIGd1YXJkIGZvciBgT2tgCiAgICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYE9rYCwgYGZhbHNlYCBpZiBgRXJyYAogICAgICovCiAgICBpc09rKCkgewogICAgICAgIHJldHVybiBmYWxzZTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyB0cnVlIGlmIHRoZSByZXN1bHQgaXMgYE9rYCBhbmQgdGhlIHZhbHVlIGluc2lkZSBvZiBpdCBtYXRjaGVzIGEgcHJlZGljYXRlCiAgICAgKiBAcGFyYW0gb2tQcmVkaWNhdGUKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgT2tgIGFuZCBgYXdhaXQgb2tQcmVkaWNhdGUodGhpcy5pbm5lcilgLCBgZmFsc2VgIG90aGVyd2lzZQogICAgICovCiAgICBhc3luYyBpc09rQW5kKG9rUHJlZGljYXRlKSB7CiAgICAgICAgcmV0dXJuIGZhbHNlOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIHRydWUgaWYgdGhlIHJlc3VsdCBpcyBgT2tgIGFuZCB0aGUgdmFsdWUgaW5zaWRlIG9mIGl0IG1hdGNoZXMgYSBwcmVkaWNhdGUKICAgICAqIEBwYXJhbSBva1ByZWRpY2F0ZQogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBPa2AgYW5kIGBhd2FpdCBva1ByZWRpY2F0ZSh0aGlzLmlubmVyKWAsIGBmYWxzZWAgb3RoZXJ3aXNlCiAgICAgKi8KICAgIGlzT2tBbmRTeW5jKG9rUHJlZGljYXRlKSB7CiAgICAgICAgcmV0dXJuIGZhbHNlOwogICAgfQogICAgLyoqCiAgICAgKiBUeXBlIGd1YXJkIGZvciBgRXJyYAogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBFcnJgLCBgZmFsc2VgIGlmIGBPa2AKICAgICAqLwogICAgaXNFcnIoKSB7CiAgICAgICAgcmV0dXJuIHRydWU7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgdHJ1ZSBpZiB0aGUgcmVzdWx0IGlzIGBFcnJgIGFuZCB0aGUgdmFsdWUgaW5zaWRlIG9mIGl0IG1hdGNoZXMgYSBwcmVkaWNhdGUKICAgICAqIEBwYXJhbSBlcnJQcmVkaWNhdGUKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgRXJyYCBhbmQgYGF3YWl0IGVyclByZWRpY2F0ZSh0aGlzLmlubmVyKWAsIGBmYWxzZWAgb3RoZXJ3aXNlCiAgICAgKi8KICAgIGFzeW5jIGlzRXJyQW5kKGVyclByZWRpY2F0ZSkgewogICAgICAgIHJldHVybiBhd2FpdCBlcnJQcmVkaWNhdGUodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgdHJ1ZSBpZiB0aGUgcmVzdWx0IGlzIGBFcnJgIGFuZCB0aGUgdmFsdWUgaW5zaWRlIG9mIGl0IG1hdGNoZXMgYSBwcmVkaWNhdGUKICAgICAqIEBwYXJhbSBlcnJQcmVkaWNhdGUKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgRXJyYCBhbmQgYGF3YWl0IGVyclByZWRpY2F0ZSh0aGlzLmlubmVyKWAsIGBmYWxzZWAgb3RoZXJ3aXNlCiAgICAgKi8KICAgIGlzRXJyQW5kU3luYyhlcnJQcmVkaWNhdGUpIHsKICAgICAgICByZXR1cm4gZXJyUHJlZGljYXRlKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBDb21waWxlLXRpbWUgc2FmZWx5IGdldCBgdGhpcy5pbm5lcmAKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYAogICAgICovCiAgICBnZXQoKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gdGhpcy5pbm5lcjsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtIGBSZXN1bHQ8VCwgRT5gIGludG8gYE9wdGlvbjxUPmAKICAgICAqIEByZXR1cm5zIGBTb21lKHRoaXMuaW5uZXIpYCBpZiBgT2tgLCBgTm9uZWAgaWYgYEVycmAKICAgICAqLwogICAgb2soKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gbmV3IE5vbmUoKTsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtIGBSZXN1bHQ8VCwgRT5gIGludG8gYE9wdGlvbjxFPmAKICAgICAqIEByZXR1cm5zIGBTb21lKHRoaXMuaW5uZXIpYCBpZiBgRXJyYCwgYE5vbmVgIGlmIGBPa2AKICAgICAqLwogICAgZXJyKCkgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIG5ldyBTb21lKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGFuIGl0ZXJhdG9yIG92ZXIgdGhlIHBvc3NpYmx5IGNvbnRhaW5lZCB2YWx1ZQogICAgICogQHlpZWxkcyBgdGhpcy5pbm5lcmAgaWYgYE9rYAogICAgICovCiAgICAqW1N5bWJvbC5pdGVyYXRvcl0oKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm47CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBgUmVzdWx0PFQsRT5gIGludG8gYFtULEVdYAogICAgICogQHJldHVybnMgYFt0aGlzLmlubmVyLCB1bmRlZmluZWRdYCBpZiBgT2tgLCBgW3VuZGVmaW5lZCwgdGhpcy5pbm5lcl1gIGlmIGBFcnJgCiAgICAgKi8KICAgIHNwbGl0KCkgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIFt1bmRlZmluZWQsIHRoaXMuaW5uZXJdOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIHRydWUgaWYgdGhlIHJlc3VsdCBpcyBhbiBgT2tgIHZhbHVlIGNvbnRhaW5pbmcgdGhlIGdpdmVuIHZhbHVlCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgT2tgIGFuZCBgdGhpcy5pbm5lciA9PT0gdmFsdWVgLCBgZmFsc2VgIG90aGVyd2lzZQogICAgICovCiAgICBjb250YWlucyh2YWx1ZSkgewogICAgICAgIHJldHVybiBmYWxzZTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyB0cnVlIGlmIHRoZSByZXN1bHQgaXMgYW4gYEVycmAgdmFsdWUgY29udGFpbmluZyB0aGUgZ2l2ZW4gdmFsdWUKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBFcnJgIGFuZCBgdGhpcy5pbm5lciA9PT0gdmFsdWVgLCBgZmFsc2VgIG90aGVyd2lzZQogICAgICovCiAgICBjb250YWluc0Vycih2YWx1ZSkgewogICAgICAgIHJldHVybiB0aGlzLmlubmVyID09PSB2YWx1ZTsKICAgIH0KICAgIC8qKgogICAgICogR2V0IHRoZSBpbm5lciB2YWx1ZSBvciB0aHJvdyB0byB0aGUgY2xvc2VzdCBgUmVzdWx0LnVudGhyb3dgCiAgICAgKiBAcGFyYW0gdGhyb3dlciBUaGUgdGhyb3dlciBmcm9tIGBSZXN1bHQudW50aHJvd2AKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgT2tgCiAgICAgKiBAdGhyb3dzIGB1bmRlZmluZWRgIGlmIGBFcnJgCiAgICAgKiBAc2VlIFJlc3VsdC51bnRocm93CiAgICAgKiBAc2VlIFJlc3VsdC51bnRocm93U3luYwogICAgICovCiAgICB0aHJvdyh0aHJvd2VyKSB7CiAgICAgICAgdGhyb3dlcih0aGlzKTsKICAgICAgICB0aHJvdyBuZXcgUGFuaWMoYFRocm93bmAsIHsgY2F1c2U6IHRoaXMgfSk7CiAgICB9CiAgICAvKioKICAgICAqIEdldCB0aGUgaW5uZXIgdmFsdWUgb3IgdGhyb3cgdGhlIGlubmVyIGVycm9yIHdyYXBwZWQgaW5zaWRlIGFub3RoZXIgRXJyb3IKICAgICAqIEBwYXJhbSBtZXNzYWdlCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAgaWYgYE9rYCwgYEVycm9yKG1lc3NhZ2UsIHsgY2F1c2U6IHRoaXMuaW5uZXIgfSlgIGlmIGBFcnJgCiAgICAgKi8KICAgIGV4cGVjdChtZXNzYWdlKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICB0aHJvdyBuZXcgUGFuaWMobWVzc2FnZSwgeyBjYXVzZTogdGhpcyB9KTsKICAgIH0KICAgIC8qKgogICAgICogR2V0IHRoZSBpbm5lciBlcnJvciBvciB0aHJvdyB0aGUgaW5uZXIgdmFsdWUgd3JhcHBlZCBpbnNpZGUgYW5vdGhlciBFcnJvcgogICAgICogQHBhcmFtIG1lc3NhZ2UKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgRXJyYCwgYEVycm9yKG1lc3NhZ2UsIHsgY2F1c2U6IHRoaXMuaW5uZXIgfSlgIGlmIGBPa2AKICAgICAqLwogICAgZXhwZWN0RXJyKG1lc3NhZ2UpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiB0aGlzLmlubmVyOwogICAgfQogICAgLyoqCiAgICAgKiBHZXQgdGhlIGlubmVyIHZhbHVlIG9yIHBhbmljCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAgaWYgYE9rYAogICAgICogQHRocm93cyBgdGhpcy5pbm5lcmAgaWYgYEVycmAKICAgICAqLwogICAgdW53cmFwKCkgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgdGhyb3cgbmV3IFBhbmljKGBVbndyYXBwZWRgLCB7IGNhdXNlOiB0aGlzIH0pOwogICAgfQogICAgLyoqCiAgICAgKiBHZXQgdGhlIGlubmVyIGVycm9yIG9yIHBhbmljCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAgaWYgYEVycmAKICAgICAqIEB0aHJvd3MgYHRoaXMuaW5uZXJgIGlmIGBPa2AKICAgICAqLwogICAgdW53cmFwRXJyKCkgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIHRoaXMuaW5uZXI7CiAgICB9CiAgICAvKioKICAgICAqIEdldCB0aGUgaW5uZXIgdmFsdWUgb3IgYSBkZWZhdWx0IG9uZQogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAgaWYgYE9rYCwgYHZhbHVlYCBpZiBgRXJyYAogICAgICovCiAgICB1bndyYXBPcih2YWx1ZSkgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIHZhbHVlOwogICAgfQogICAgLyoqCiAgICAgKiBHZXQgdGhlIGlubmVyIHZhbHVlIG9yIGNvbXB1dGUgYSBkZWZhdWx0IG9uZSBmcm9tIHRoZSBpbm5lciBlcnJvcgogICAgICogQHBhcmFtIGVyck1hcHBlcgogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBPa2AsIGBhd2FpdCBlcnJNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBFcnJgCiAgICAgKiBAdGhyb3dzIGlmIGBhd2FpdCBlcnJNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICBhc3luYyB1bndyYXBPckVsc2UoZXJyTWFwcGVyKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gYXdhaXQgZXJyTWFwcGVyKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBHZXQgdGhlIGlubmVyIHZhbHVlIG9yIGNvbXB1dGUgYSBkZWZhdWx0IG9uZSBmcm9tIHRoZSBpbm5lciBlcnJvcgogICAgICogQHBhcmFtIGVyck1hcHBlcgogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBPa2AsIGBlcnJNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBFcnJgCiAgICAgKiBAdGhyb3dzIGlmIGBlcnJNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICB1bndyYXBPckVsc2VTeW5jKGVyck1hcHBlcikgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIGVyck1hcHBlcih0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtIFJlc3VsdDxQcm9taXNlPFQ+LCBFPiBpbnRvIFByb21pc2U8UmVzdWx0PFQsIEU+PgogICAgICogQHJldHVybnMgYGF3YWl0IHRoaXMuaW5uZXJgIGlmIGBPa2AsIGB0aGlzYCBpZiBgRXJyYAogICAgICovCiAgICBhc3luYyBhd2FpdCgpIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtIFJlc3VsdDxULCBQcm9taXNlPEU+PiBpbnRvIFByb21pc2U8UmVzdWx0PFQsIEU+PgogICAgICogQHJldHVybnMgYGF3YWl0IHRoaXMuaW5uZXJgIGlmIGBFcnJgLCBgdGhpc2AgaWYgYE9rYAogICAgICovCiAgICBhc3luYyBhd2FpdEVycigpIHsKICAgICAgICByZXR1cm4gbmV3IEVycihhd2FpdCB0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtIFJlc3VsdDxQcm9taXNlPFQ+LCBQcm9taXNlPEU+PiBpbnRvIFByb21pc2U8UmVzdWx0PFQsIEU+PgogICAgICogQHJldHVybnMgYGF3YWl0IHRoaXMuaW5uZXJgCiAgICAgKi8KICAgIGFzeW5jIGF3YWl0QWxsKCkgewogICAgICAgIHJldHVybiBhd2FpdCB0aGlzLmF3YWl0RXJyKCk7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBgUmVzdWx0PFQsIEU+YCBpbnRvIGBSZXN1bHQ8dm9pZCwgRT5gCiAgICAgKiBAcmV0dXJucyBgT2s8dm9pZD5gIGlmIGBPazxUPmAsIGBFcnI8RT5gIGlmIGBFPEU+YAogICAgICovCiAgICBjbGVhcigpIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtIGBSZXN1bHQ8VCwgRT5gIGludG8gYFJlc3VsdDxULCB2b2lkPmAKICAgICAqIEByZXR1cm5zIGBPazxUPmAgaWYgYE9rPFQ+YCwgYEVycjx2b2lkPmAgaWYgYEU8RT5gCiAgICAgKi8KICAgIGNsZWFyRXJyKCkgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIEVyci52b2lkKCk7CiAgICB9CiAgICAvKioKICAgICAqIENhbGxzIHRoZSBnaXZlbiBjYWxsYmFjayB3aXRoIHRoZSBpbm5lciB2YWx1ZSBpZiBgT2tgCiAgICAgKiBAcGFyYW0gb2tDYWxsYmFjawogICAgICogQHJldHVybnMgYHRoaXNgCiAgICAgKi8KICAgIGFzeW5jIGluc3BlY3Qob2tDYWxsYmFjaykgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBDYWxscyB0aGUgZ2l2ZW4gY2FsbGJhY2sgd2l0aCB0aGUgaW5uZXIgdmFsdWUgaWYgYE9rYAogICAgICogQHBhcmFtIG9rQ2FsbGJhY2sKICAgICAqIEByZXR1cm5zIGB0aGlzYAogICAgICovCiAgICBpbnNwZWN0U3luYyhva0NhbGxiYWNrKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIENhbGxzIHRoZSBnaXZlbiBjYWxsYmFjayB3aXRoIHRoZSBpbm5lciB2YWx1ZSBpZiBgRXJyYAogICAgICogQHBhcmFtIGVyckNhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgdGhpc2AKICAgICAqLwogICAgYXN5bmMgaW5zcGVjdEVycihlcnJDYWxsYmFjaykgewogICAgICAgIGF3YWl0IGVyckNhbGxiYWNrKHRoaXMuaW5uZXIpOwogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBDYWxscyB0aGUgZ2l2ZW4gY2FsbGJhY2sgd2l0aCB0aGUgaW5uZXIgdmFsdWUgaWYgYEVycmAKICAgICAqIEBwYXJhbSBlcnJDYWxsYmFjawogICAgICogQHJldHVybnMgYHRoaXNgCiAgICAgKi8KICAgIGluc3BlY3RFcnJTeW5jKGVyckNhbGxiYWNrKSB7CiAgICAgICAgZXJyQ2FsbGJhY2sodGhpcy5pbm5lcik7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybiBhIG5ldyBgT2tgIGJ1dCB3aXRoIHRoZSBnaXZlbiBgaW5uZXJgCiAgICAgKiBAcGFyYW0gaW5uZXIKICAgICAqIEByZXR1cm5zIGBPayhpbm5lcilgIGlmIGBPa2AsIGB0aGlzYCBpZiBgRXJyYAogICAgICovCiAgICBzZXQoaW5uZXIpIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJuIGEgbmV3IGBFcnJgIGJ1dCB3aXRoIHRoZSBnaXZlbiBgaW5uZXJgCiAgICAgKiBAcGFyYW0gaW5uZXIKICAgICAqIEByZXR1cm5zIGBFcnIoaW5uZXIpYCBpZiBgRXJyYCwgYHRoaXNgIGlmIGBPa2AKICAgICAqLwogICAgc2V0RXJyKGlubmVyKSB7CiAgICAgICAgcmV0dXJuIG5ldyBFcnIoaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBNYXAgdGhlIGlubmVyIHZhbHVlIGludG8gYW5vdGhlcgogICAgICogQHBhcmFtIG9rTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgT2soYXdhaXQgb2tNYXBwZXIodGhpcy5pbm5lcikpYCBpZiBgT2tgLCBgdGhpc2AgaWYgYEVycmAKICAgICAqIEB0aHJvd3MgaWYgYGF3YWl0IG9rTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgYXN5bmMgbWFwKG9rTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIE1hcCB0aGUgaW5uZXIgdmFsdWUgaW50byBhbm90aGVyCiAgICAgKiBAcGFyYW0gb2tNYXBwZXIKICAgICAqIEByZXR1cm5zIGBPayhva01hcHBlcih0aGlzLmlubmVyKSlgIGlmIGBPa2AsIGB0aGlzYCBpZiBgRXJyYAogICAgICogQHRocm93cyBpZiBgb2tNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICBtYXBTeW5jKG9rTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIE1hcCB0aGUgaW5uZXIgZXJyb3IgaW50byBhbm90aGVyCiAgICAgKiBAcGFyYW0gZXJyTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgRXJyKGF3YWl0IGVyck1hcHBlcih0aGlzLmlubmVyKSlgIGlmIGBFcnJgLCBgdGhpc2AgaWYgYE9rYAogICAgICogQHRocm93cyBpZiBgYXdhaXQgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgYXN5bmMgbWFwRXJyKGVyck1hcHBlcikgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIG5ldyBFcnIoYXdhaXQgZXJyTWFwcGVyKHRoaXMuaW5uZXIpKTsKICAgIH0KICAgIC8qKgogICAgICogTWFwIHRoZSBpbm5lciBlcnJvciBpbnRvIGFub3RoZXIKICAgICAqIEBwYXJhbSBlcnJNYXBwZXIKICAgICAqIEByZXR1cm5zIGBFcnIoZXJyTWFwcGVyKHRoaXMuaW5uZXIpKWAgaWYgYEVycmAsIGB0aGlzYCBpZiBgT2tgCiAgICAgKiBAdGhyb3dzIGlmIGBlcnJNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICBtYXBFcnJTeW5jKGVyck1hcHBlcikgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIG5ldyBFcnIoZXJyTWFwcGVyKHRoaXMuaW5uZXIpKTsKICAgIH0KICAgIC8qKgogICAgICogTWFwIHRoZSBpbm5lciB2YWx1ZSBpbnRvIGFub3RoZXIsIG9yIGEgZGVmYXVsdCBvbmUKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHBhcmFtIG9rTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgYXdhaXQgb2tNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBPa2AsIGB2YWx1ZWAgaWYgYEVycmAKICAgICAqIEB0aHJvd3MgaWYgYGF3YWl0IG9rTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgYXN5bmMgbWFwT3IodmFsdWUsIG9rTWFwcGVyKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gdmFsdWU7CiAgICB9CiAgICAvKioKICAgICAqIE1hcCB0aGUgaW5uZXIgdmFsdWUgaW50byBhbm90aGVyLCBvciBhIGRlZmF1bHQgb25lCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEBwYXJhbSBva01hcHBlcgogICAgICogQHJldHVybnMgYG9rTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgT2tgLCBgdmFsdWVgIGlmIGBFcnJgCiAgICAgKiBAdGhyb3dzIGlmIGBva01hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIG1hcE9yU3luYyh2YWx1ZSwgb2tNYXBwZXIpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiB2YWx1ZTsKICAgIH0KICAgIC8qKgogICAgICogTWFwIHRoZSBpbm5lciB2YWx1ZSBpbnRvIGFub3RoZXIsIG9yIGEgZGVmYXVsdCBvbmUKICAgICAqIEBwYXJhbSBlcnJNYXBwZXIKICAgICAqIEBwYXJhbSBva01hcHBlcgogICAgICogQHJldHVybnMgYGF3YWl0IG9rTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgT2tgLCBgYXdhaXQgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgRXJyYAogICAgICogQHRocm93cyBpZiBgYXdhaXQgb2tNYXBwZXIodGhpcy5pbm5lcilgIG9yIGBhd2FpdCBlcnJNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICBhc3luYyBtYXBPckVsc2UoZXJyTWFwcGVyLCBva01hcHBlcikgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIGF3YWl0IGVyck1hcHBlcih0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogTWFwIHRoZSBpbm5lciB2YWx1ZSBpbnRvIGFub3RoZXIsIG9yIGEgZGVmYXVsdCBvbmUKICAgICAqIEBwYXJhbSBlcnJNYXBwZXIKICAgICAqIEBwYXJhbSBva01hcHBlcgogICAgICogQHJldHVybnMgYG9rTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgT2tgLCBgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgRXJyYAogICAgICogQHRocm93cyBpZiBgb2tNYXBwZXIodGhpcy5pbm5lcilgIG9yIGBlcnJNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICBtYXBPckVsc2VTeW5jKGVyck1hcHBlciwgb2tNYXBwZXIpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiBlcnJNYXBwZXIodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybiBgdmFsdWVgIGlmIGBPa2AsIHJldHVybiBgdGhpc2AgaWYgYEVycmAKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHJldHVybnMgYHZhbHVlYCBpZiBgT2tgLCBgdGhpc2AgaWYgYEVycmAKICAgICAqLwogICAgYW5kKHZhbHVlKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybiBgYXdhaXQgb2tNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBPa2AsIHJldHVybiBgdGhpc2AgaWYgYEVycmAKICAgICAqIEBwYXJhbSBva01hcHBlcgogICAgICogQHJldHVybnMgYGF3YWl0IG9rTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgT2tgLCBgdGhpc2AgaWYgYEVycmAKICAgICAqIEB0aHJvd3MgaWYgYGF3YWl0IG9rTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgYXN5bmMgYW5kVGhlbihva01hcHBlcikgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm4gYG9rTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgT2tgLCByZXR1cm4gYHRoaXNgIGlmIGBFcnJgCiAgICAgKiBAcGFyYW0gb2tNYXBwZXIKICAgICAqIEByZXR1cm5zIGBva01hcHBlcih0aGlzLmlubmVyKWAgaWYgYE9rYCwgYHRoaXNgIGlmIGBFcnJgCiAgICAgKiBAdGhyb3dzIGlmIGBva01hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIGFuZFRoZW5TeW5jKG9rTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybiBgdmFsdWVgIGlmIGBFcnJgLCByZXR1cm4gYHRoaXNgIGlmIGBPa2AKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHJldHVybnMgYHZhbHVlYCBpZiBgRXJyYCwgYHRoaXNgIGlmIGBPa2AKICAgICAqLwogICAgb3IodmFsdWUpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiB2YWx1ZTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJuIGBhd2FpdCBlcnJNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBFcnJgLCByZXR1cm4gYHRoaXNgIGlmIGBPa2AKICAgICAqIEBwYXJhbSBlcnJNYXBwZXIKICAgICAqIEByZXR1cm5zIGBhd2FpdCBlcnJNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBFcnJgLCBgdGhpc2AgaWYgYE9rYAogICAgICogQHRocm93cyBpZiBgYXdhaXQgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgYXN5bmMgb3JFbHNlKGVyck1hcHBlcikgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIGF3YWl0IGVyck1hcHBlcih0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJuIGBlcnJNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBFcnJgLCByZXR1cm4gYHRoaXNgIGlmIGBPa2AKICAgICAqIEBwYXJhbSBlcnJNYXBwZXIKICAgICAqIEByZXR1cm5zIGBlcnJNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBFcnJgLCBgdGhpc2AgaWYgYE9rYAogICAgICogQHRocm93cyBpZiBgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgb3JFbHNlU3luYyhlcnJNYXBwZXIpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiBlcnJNYXBwZXIodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBSZXN1bHQ8UmVzdWx0PFQsIEUxPiwgRTI+IGludG8gUmVzdWx0PFQsIEUxIHwgRTI+CiAgICAgKiBAcGFyYW0gcmVzdWx0CiAgICAgKiBAcmV0dXJucyBgdGhpc2AgaWYgYEVycmAsIGB0aGlzLmlubmVyYCBpZiBgT2tgCiAgICAgKi8KICAgIGZsYXR0ZW4oKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9Cn0KCgovLyMgc291cmNlTWFwcGluZ1VSTD1lcnIubWpzLm1hcAoKOy8vIENPTkNBVEVOQVRFRCBNT0RVTEU6IC4vbm9kZV9tb2R1bGVzL0BoYXphZTQxL3Jlc3VsdC9kaXN0L2VzbS9tb2RzL3Jlc3VsdC9lcnJvcnMubWpzCgoKY2xhc3MgVW5pbXBsZW1lbnRlZCBleHRlbmRzICgvKiB1bnVzZWQgcHVyZSBleHByZXNzaW9uIG9yIHN1cGVyICovIG51bGwgJiYgKEVycm9yKSkgewogICAgI2NsYXNzID0gVW5pbXBsZW1lbnRlZDsKICAgIG5hbWUgPSB0aGlzLiNjbGFzcy5uYW1lOwp9CmNsYXNzIEFzc2VydEVycm9yIGV4dGVuZHMgRXJyb3IgewogICAgI2NsYXNzID0gQXNzZXJ0RXJyb3I7CiAgICBuYW1lID0gdGhpcy4jY2xhc3MubmFtZTsKICAgIGNvbnN0cnVjdG9yKCkgewogICAgICAgIHN1cGVyKGBBc3NlcnRpb24gZmFpbGVkYCk7CiAgICB9Cn0KY2xhc3MgUGFuaWMgZXh0ZW5kcyBFcnJvciB7CiAgICAjY2xhc3MgPSBQYW5pYzsKICAgIG5hbWUgPSB0aGlzLiNjbGFzcy5uYW1lOwogICAgc3RhdGljIGZyb20oY2F1c2UpIHsKICAgICAgICByZXR1cm4gbmV3IFBhbmljKHVuZGVmaW5lZCwgeyBjYXVzZSB9KTsKICAgIH0KICAgIHN0YXRpYyBmcm9tQW5kVGhyb3coY2F1c2UpIHsKICAgICAgICB0aHJvdyBQYW5pYy5mcm9tKGNhdXNlKTsKICAgIH0KfQpjbGFzcyBDYXRjaGVkIGV4dGVuZHMgRXJyb3IgewogICAgI2NsYXNzID0gQ2F0Y2hlZDsKICAgIG5hbWUgPSB0aGlzLiNjbGFzcy5uYW1lOwogICAgc3RhdGljIGZyb20oY2F1c2UpIHsKICAgICAgICByZXR1cm4gbmV3IENhdGNoZWQodW5kZWZpbmVkLCB7IGNhdXNlIH0pOwogICAgfQogICAgc3RhdGljIGZyb21BbmRUaHJvdyhjYXVzZSkgewogICAgICAgIHRocm93IENhdGNoZWQuZnJvbShjYXVzZSk7CiAgICB9CiAgICAvKioKICAgICAqIFRocm93IGlmIGBDYXRjaGVkYCwgd3JhcCBpbiBgRXJyYCBvdGhlcndpc2UKICAgICAqIEBwYXJhbSBlcnJvcgogICAgICogQHJldHVybnMgYEVycihlcnJvcilgIGlmIG5vdCBgQ2F0Y2hlZGAKICAgICAqIEB0aHJvd3MgYGVycm9yLmNhdXNlYCBpZiBgQ2F0Y2hlZGAKICAgICAqLwogICAgc3RhdGljIHRocm93T3JFcnIoZXJyb3IpIHsKICAgICAgICBpZiAoZXJyb3IgaW5zdGFuY2VvZiBDYXRjaGVkKQogICAgICAgICAgICB0aHJvdyBlcnJvci5jYXVzZTsKICAgICAgICByZXR1cm4gbmV3IEVycihlcnJvcik7CiAgICB9Cn0KCgovLyMgc291cmNlTWFwcGluZ1VSTD1lcnJvcnMubWpzLm1hcAoKOy8vIENPTkNBVEVOQVRFRCBNT0RVTEU6IC4vbm9kZV9tb2R1bGVzL0BoYXphZTQxL29wdGlvbi9kaXN0L2VzbS9tb2RzL29wdGlvbi9ub25lLm1qcwoKCmNsYXNzIE5vbmVFcnJvciBleHRlbmRzIEVycm9yIHsKICAgIGNvbnN0cnVjdG9yKCkgewogICAgICAgIHN1cGVyKGBPcHRpb24gaXMgYSBOb25lYCk7CiAgICB9Cn0KY2xhc3MgTm9uZSB7CiAgICBpbm5lcjsKICAgIC8qKgogICAgICogQW4gZW1wdHkgdmFsdWUKICAgICAqLwogICAgY29uc3RydWN0b3IoaW5uZXIgPSB1bmRlZmluZWQpIHsKICAgICAgICB0aGlzLmlubmVyID0gaW5uZXI7CiAgICB9CiAgICAvKioKICAgICAqIENyZWF0ZSBhIGBOb25lYAogICAgICogQHJldHVybnMgYE5vbmVgCiAgICAgKi8KICAgIHN0YXRpYyBuZXcoKSB7CiAgICAgICAgcmV0dXJuIG5ldyBOb25lKCk7CiAgICB9CiAgICBzdGF0aWMgZnJvbShpbml0KSB7CiAgICAgICAgcmV0dXJuIG5ldyBOb25lKCk7CiAgICB9CiAgICAvKioKICAgICAqIFR5cGUgZ3VhcmQgZm9yIGBTb21lYAogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBTb21lYCwgYGZhbHNlYCBpZiBgTm9uZWAKICAgICAqLwogICAgaXNTb21lKCkgewogICAgICAgIHJldHVybiBmYWxzZTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBgdHJ1ZWAgaWYgdGhlIG9wdGlvbiBpcyBhIGBTb21lYCBhbmQgdGhlIHZhbHVlIGluc2lkZSBvZiBpdCBtYXRjaGVzIGEgcHJlZGljYXRlCiAgICAgKiBAcGFyYW0gc29tZVByZWRpY2F0ZQogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBTb21lYCBhbmQgYGF3YWl0IHNvbWVQcmVkaWNhdGUodGhpcy5pbm5lcilgLCBgTm9uZWAgb3RoZXJ3aXNlCiAgICAgKi8KICAgIGFzeW5jIGlzU29tZUFuZChzb21lUHJlZGljYXRlKSB7CiAgICAgICAgcmV0dXJuIGZhbHNlOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGB0cnVlYCBpZiB0aGUgb3B0aW9uIGlzIGEgYFNvbWVgIGFuZCB0aGUgdmFsdWUgaW5zaWRlIG9mIGl0IG1hdGNoZXMgYSBwcmVkaWNhdGUKICAgICAqIEBwYXJhbSBzb21lUHJlZGljYXRlCiAgICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYFNvbWVgIGFuZCBgc29tZVByZWRpY2F0ZSh0aGlzLmlubmVyKWAsIGBOb25lYCBvdGhlcndpc2UKICAgICAqLwogICAgaXNTb21lQW5kU3luYyhzb21lUHJlZGljYXRlKSB7CiAgICAgICAgcmV0dXJuIGZhbHNlOwogICAgfQogICAgLyoqCiAgICAgKiBUeXBlIGd1YXJkIGZvciBgTm9uZWAKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgTm9uZWAsIGBmYWxzZWAgaWYgYFNvbWVgCiAgICAgKi8KICAgIGlzTm9uZSgpIHsKICAgICAgICByZXR1cm4gdHJ1ZTsKICAgIH0KICAgIC8qKgogICAgICogQ29tcGlsZS10aW1lIHNhZmVseSBnZXQgYHRoaXMuaW5uZXJgCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAKICAgICAqLwogICAgZ2V0KCkgewogICAgICAgIHJldHVybiB0aGlzLmlubmVyOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGFuIGl0ZXJhdG9yIG92ZXIgdGhlIHBvc3NpYmx5IGNvbnRhaW5lZCB2YWx1ZQogICAgICogQHlpZWxkcyBgdGhpcy5pbm5lcmAgaWYgYFNvbWVgCiAgICAgKi8KICAgICpbU3ltYm9sLml0ZXJhdG9yXSgpIHsKICAgICAgICByZXR1cm47CiAgICB9CiAgICAvKioKICAgICAqIEdldCB0aGUgaW5uZXIgdmFsdWUgaWYgYFNvbWVgLCB0aHJvdyBgRXJyb3IobWVzc2FnZSlgIG90aGVyd2lzZQogICAgICogQHBhcmFtIG1lc3NhZ2UKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgU29tZWAKICAgICAqIEB0aHJvd3MgYEVycm9yKG1lc3NhZ2UpYCBpZiBgTm9uZWAKICAgICAqLwogICAgZXhwZWN0KG1lc3NhZ2UpIHsKICAgICAgICB0aHJvdyBuZXcgUGFuaWMobWVzc2FnZSwgeyBjYXVzZTogdGhpcyB9KTsKICAgIH0KICAgIC8qKgogICAgICogR2V0IHRoZSBpbm5lciB2YWx1ZSBvciB0aHJvdyBhIE5vbmVFcnJvcgogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBTb21lYAogICAgICogQHRocm93cyBgTm9uZUVycm9yYCBpZiBgTm9uZWAKICAgICAqLwogICAgdW53cmFwKCkgewogICAgICAgIHRocm93IG5ldyBQYW5pYyhgVW53cmFwcGVkYCwgeyBjYXVzZTogdGhpcyB9KTsKICAgIH0KICAgIC8qKgogICAgICogR2V0IHRoZSBpbm5lciB2YWx1ZSBvciBhIGRlZmF1bHQgb25lCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgU29tZWAsIGB2YWx1ZWAgaWYgYE5vbmVgCiAgICAgKi8KICAgIHVud3JhcE9yKHZhbHVlKSB7CiAgICAgICAgcmV0dXJuIHZhbHVlOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIHRoZSBjb250YWluZWQgYFNvbWVgIHZhbHVlIG9yIGNvbXB1dGVzIGl0IGZyb20gYSBjbG9zdXJlCiAgICAgKiBAcGFyYW0gbm9uZUNhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAgaWYgYFNvbWVgLCBgYXdhaXQgbm9uZUNhbGxiYWNrKClgIGlmIGBOb25lYAogICAgICovCiAgICBhc3luYyB1bndyYXBPckVsc2Uobm9uZUNhbGxiYWNrKSB7CiAgICAgICAgcmV0dXJuIGF3YWl0IG5vbmVDYWxsYmFjaygpOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIHRoZSBjb250YWluZWQgYFNvbWVgIHZhbHVlIG9yIGNvbXB1dGVzIGl0IGZyb20gYSBjbG9zdXJlCiAgICAgKiBAcGFyYW0gbm9uZUNhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAgaWYgYFNvbWVgLCBgbm9uZUNhbGxiYWNrKClgIGlmIGBOb25lYAogICAgICovCiAgICB1bndyYXBPckVsc2VTeW5jKG5vbmVDYWxsYmFjaykgewogICAgICAgIHJldHVybiBub25lQ2FsbGJhY2soKTsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtIGBPcHRpb248VD5gIGludG8gYFJlc3VsdDxULCBOb25lRXJyb3I+YAogICAgICogQHJldHVybnMgYE9rKHRoaXMuaW5uZXIpYCBpZiBgU29tZWAsIGBFcnIoTm9uZUVycm9yKWAgaWYgYE5vbmVgCiAgICAgKi8KICAgIG9rKCkgewogICAgICAgIHJldHVybiBuZXcgRXJyKG5ldyBOb25lRXJyb3IoKSk7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBgT3B0aW9uPFQ+YCBpbnRvIGBSZXN1bHQ8VCwgRT5gCiAgICAgKiBAcGFyYW0gZXJyb3IKICAgICAqIEByZXR1cm5zIGBPayh0aGlzLmlubmVyKWAgaWYgYFNvbWVgLCBgRXJyKGVycm9yKWAgaWYgYE5vbmVgCiAgICAgKi8KICAgIG9rT3IoZXJyb3IpIHsKICAgICAgICByZXR1cm4gbmV3IEVycihlcnJvcik7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybXMgdGhlIGBPcHRpb248VD5gIGludG8gYSBgUmVzdWx0PFQsIEU+YCwgbWFwcGluZyBgU29tZSh2KWAgdG8gYE9rKHYpYCBhbmQgYE5vbmVgIHRvIGBFcnIoZXJyKCkpYAogICAgICogQHBhcmFtIG5vbmVDYWxsYmFjawogICAgICogQHJldHVybnMgYE9rKHRoaXMuaW5uZXIpYCBpZiBgU29tZWAsIGBFcnIoYXdhaXQgbm9uZUNhbGxiYWNrKCkpYCBpcyBgTm9uZWAKICAgICAqLwogICAgYXN5bmMgb2tPckVsc2Uobm9uZUNhbGxiYWNrKSB7CiAgICAgICAgcmV0dXJuIG5ldyBFcnIoYXdhaXQgbm9uZUNhbGxiYWNrKCkpOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm1zIHRoZSBgT3B0aW9uPFQ+YCBpbnRvIGEgYFJlc3VsdDxULCBFPmAsIG1hcHBpbmcgYFNvbWUodilgIHRvIGBPayh2KWAgYW5kIGBOb25lYCB0byBgRXJyKGVycigpKWAKICAgICAqIEBwYXJhbSBub25lQ2FsbGJhY2sKICAgICAqIEByZXR1cm5zIGBPayh0aGlzLmlubmVyKWAgaWYgYFNvbWVgLCBgRXJyKG5vbmVDYWxsYmFjaygpKWAgaXMgYE5vbmVgCiAgICAgKi8KICAgIG9rT3JFbHNlU3luYyhub25lQ2FsbGJhY2spIHsKICAgICAgICByZXR1cm4gbmV3IEVycihub25lQ2FsbGJhY2soKSk7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYE5vbmVgIGlmIHRoZSBvcHRpb24gaXMgYE5vbmVgLCBvdGhlcndpc2UgY2FsbHMgYHNvbWVQcmVkaWNhdGVgIHdpdGggdGhlIHdyYXBwZWQgdmFsdWUKICAgICAqIEBwYXJhbSBzb21lUHJlZGljYXRlCiAgICAgKiBAcmV0dXJucyBgU29tZWAgaWYgYFNvbWVgIGFuZCBgYXdhaXQgc29tZVByZWRpY2F0ZSh0aGlzLmlubmVyKWAsIGBOb25lYCBvdGhlcndpc2UKICAgICAqLwogICAgYXN5bmMgZmlsdGVyKHNvbWVQcmVkaWNhdGUpIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBgTm9uZWAgaWYgdGhlIG9wdGlvbiBpcyBgTm9uZWAsIG90aGVyd2lzZSBjYWxscyBgc29tZVByZWRpY2F0ZWAgd2l0aCB0aGUgd3JhcHBlZCB2YWx1ZQogICAgICogQHBhcmFtIHNvbWVQcmVkaWNhdGUKICAgICAqIEByZXR1cm5zIGBTb21lYCBpZiBgU29tZWAgYW5kIGBzb21lUHJlZGljYXRlKHRoaXMuaW5uZXIpYCwgYE5vbmVgIG90aGVyd2lzZQogICAgICovCiAgICBmaWx0ZXJTeW5jKHNvbWVQcmVkaWNhdGUpIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtIGBPcHRpb248UHJvbWlzZTxUPj5gIGludG8gYFByb21pc2U8T3B0aW9uPFQ+PmAKICAgICAqIEByZXR1cm5zIGBQcm9taXNlPE9wdGlvbjxUPj5gCiAgICAgKi8KICAgIGFzeW5jIGF3YWl0KCkgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGB0cnVlYCBpZiB0aGUgb3B0aW9uIGlzIGEgYFNvbWVgIHZhbHVlIGNvbnRhaW5pbmcgdGhlIGdpdmVuIHZhbHVlCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgU29tZWAgYW5kIGB0aGlzLmlubmVyID09PSB2YWx1ZWAsIGBOb25lYCBvdGhlcndpc2UKICAgICAqLwogICAgY29udGFpbnModmFsdWUpIHsKICAgICAgICByZXR1cm4gZmFsc2U7CiAgICB9CiAgICAvKioKICAgICAqIENhbGxzIHRoZSBnaXZlbiBjYWxsYmFjayB3aXRoIHRoZSBpbm5lciB2YWx1ZSBpZiBgT2tgCiAgICAgKiBAcGFyYW0gc29tZUNhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgdGhpc2AKICAgICAqLwogICAgYXN5bmMgaW5zcGVjdChzb21lQ2FsbGJhY2spIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogQ2FsbHMgdGhlIGdpdmVuIGNhbGxiYWNrIHdpdGggdGhlIGlubmVyIHZhbHVlIGlmIGBPa2AKICAgICAqIEBwYXJhbSBzb21lQ2FsbGJhY2sKICAgICAqIEByZXR1cm5zIGB0aGlzYAogICAgICovCiAgICBpbnNwZWN0U3luYyhzb21lQ2FsbGJhY2spIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogTWFwcyBhbiBgT3B0aW9uPFQ+YCB0byBgT3B0aW9uPFU+YCBieSBhcHBseWluZyBhIGZ1bmN0aW9uIHRvIGEgY29udGFpbmVkIHZhbHVlIChpZiBgU29tZWApIG9yIHJldHVybnMgYE5vbmVgIChpZiBgTm9uZWApCiAgICAgKiBAcGFyYW0gc29tZU1hcHBlcgogICAgICogQHJldHVybnMgYFNvbWUoYXdhaXQgc29tZU1hcHBlcih0aGlzLmlubmVyKSlgIGlmIGBTb21lYCwgYHRoaXNgIGlmIGBOb25lYAogICAgICovCiAgICBhc3luYyBtYXAoc29tZU1hcHBlcikgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBNYXBzIGFuIGBPcHRpb248VD5gIHRvIGBPcHRpb248VT5gIGJ5IGFwcGx5aW5nIGEgZnVuY3Rpb24gdG8gYSBjb250YWluZWQgdmFsdWUgKGlmIGBTb21lYCkgb3IgcmV0dXJucyBgTm9uZWAgKGlmIGBOb25lYCkKICAgICAqIEBwYXJhbSBzb21lTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgU29tZShzb21lTWFwcGVyKHRoaXMuaW5uZXIpKWAgaWYgYFNvbWVgLCBgdGhpc2AgaWYgYE5vbmVgCiAgICAgKi8KICAgIG1hcFN5bmMoc29tZU1hcHBlcikgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIHRoZSBwcm92aWRlZCBkZWZhdWx0IHJlc3VsdCAoaWYgbm9uZSksIG9yIGFwcGxpZXMgYSBmdW5jdGlvbiB0byB0aGUgY29udGFpbmVkIHZhbHVlIChpZiBhbnkpCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEBwYXJhbSBzb21lTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgdmFsdWVgIGlmIGBOb25lYCwgYGF3YWl0IHNvbWVNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBTb21lYAogICAgICovCiAgICBhc3luYyBtYXBPcih2YWx1ZSwgc29tZU1hcHBlcikgewogICAgICAgIHJldHVybiB2YWx1ZTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyB0aGUgcHJvdmlkZWQgZGVmYXVsdCByZXN1bHQgKGlmIG5vbmUpLCBvciBhcHBsaWVzIGEgZnVuY3Rpb24gdG8gdGhlIGNvbnRhaW5lZCB2YWx1ZSAoaWYgYW55KQogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcGFyYW0gc29tZU1hcHBlcgogICAgICogQHJldHVybnMgYHZhbHVlYCBpZiBgTm9uZWAsIGBzb21lTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgU29tZWAKICAgICAqLwogICAgbWFwT3JTeW5jKHZhbHVlLCBzb21lTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIHZhbHVlOwogICAgfQogICAgLyoqCiAgICAgKiBDb21wdXRlcyBhIGRlZmF1bHQgZnVuY3Rpb24gcmVzdWx0IChpZiBub25lKSwgb3IgYXBwbGllcyBhIGRpZmZlcmVudCBmdW5jdGlvbiB0byB0aGUgY29udGFpbmVkIHZhbHVlIChpZiBhbnkpCiAgICAgKiBAcGFyYW0gbm9uZUNhbGxiYWNrCiAgICAgKiBAcGFyYW0gc29tZU1hcHBlcgogICAgICogQHJldHVybnMgYGF3YWl0IHNvbWVNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBTb21lYCwgYGF3YWl0IG5vbmVDYWxsYmFjaygpYCBpZiBgTm9uZWAKICAgICAqLwogICAgYXN5bmMgbWFwT3JFbHNlKG5vbmVDYWxsYmFjaywgc29tZU1hcHBlcikgewogICAgICAgIHJldHVybiBhd2FpdCBub25lQ2FsbGJhY2soKTsKICAgIH0KICAgIC8qKgogICAgICogQ29tcHV0ZXMgYSBkZWZhdWx0IGZ1bmN0aW9uIHJlc3VsdCAoaWYgbm9uZSksIG9yIGFwcGxpZXMgYSBkaWZmZXJlbnQgZnVuY3Rpb24gdG8gdGhlIGNvbnRhaW5lZCB2YWx1ZSAoaWYgYW55KQogICAgICogQHBhcmFtIG5vbmVDYWxsYmFjawogICAgICogQHBhcmFtIHNvbWVNYXBwZXIKICAgICAqIEByZXR1cm5zIGBzb21lTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgU29tZWAsIGBub25lQ2FsbGJhY2soKWAgaWYgYE5vbmVgCiAgICAgKi8KICAgIG1hcE9yRWxzZVN5bmMobm9uZUNhbGxiYWNrLCBzb21lTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIG5vbmVDYWxsYmFjaygpOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGBOb25lYCBpZiB0aGUgb3B0aW9uIGlzIGBOb25lYCwgb3RoZXJ3aXNlIHJldHVybnMgYHZhbHVlYAogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcmV0dXJucyBgTm9uZWAgaWYgYE5vbmVgLCBgdmFsdWVgIGlmIGBTb21lYAogICAgICovCiAgICBhbmQodmFsdWUpIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBgTm9uZWAgaWYgdGhlIG9wdGlvbiBpcyBgTm9uZWAsIG90aGVyd2lzZSBjYWxscyBgc29tZU1hcHBlcmAgd2l0aCB0aGUgd3JhcHBlZCB2YWx1ZSBhbmQgcmV0dXJucyB0aGUgcmVzdWx0CiAgICAgKiBAcGFyYW0gc29tZU1hcHBlcgogICAgICogQHJldHVybnMgYE5vbmVgIGlmIGBOb25lYCwgYGF3YWl0IHNvbWVNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBTb21lYAogICAgICovCiAgICBhc3luYyBhbmRUaGVuKHNvbWVNYXBwZXIpIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBgTm9uZWAgaWYgdGhlIG9wdGlvbiBpcyBgTm9uZWAsIG90aGVyd2lzZSBjYWxscyBgc29tZU1hcHBlcmAgd2l0aCB0aGUgd3JhcHBlZCB2YWx1ZSBhbmQgcmV0dXJucyB0aGUgcmVzdWx0CiAgICAgKiBAcGFyYW0gc29tZU1hcHBlcgogICAgICogQHJldHVybnMgYE5vbmVgIGlmIGBOb25lYCwgYHNvbWVNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBTb21lYAogICAgICovCiAgICBhbmRUaGVuU3luYyhzb21lTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYHRoaXNgIGlmIGBTb21lYCwgb3RoZXJ3aXNlIHJldHVybnMgYHZhbHVlYAogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcmV0dXJucyBgdGhpc2AgaWYgYFNvbWVgLCBgdmFsdWVgIGlmIGBOb25lYAogICAgICovCiAgICBvcih2YWx1ZSkgewogICAgICAgIHJldHVybiB2YWx1ZTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBgdGhpc2AgaWYgYFNvbWVgLCBvdGhlcndpc2UgY2FsbHMgYG5vbmVDYWxsYmFja2AgYW5kIHJldHVybnMgdGhlIHJlc3VsdAogICAgICogQHBhcmFtIG5vbmVDYWxsYmFjawogICAgICogQHJldHVybnMgYHRoaXNgIGlmIGBTb21lYCwgYGF3YWl0IG5vbmVDYWxsYmFjaygpYCBpZiBgTm9uZWAKICAgICAqLwogICAgYXN5bmMgb3JFbHNlKG5vbmVDYWxsYmFjaykgewogICAgICAgIHJldHVybiBhd2FpdCBub25lQ2FsbGJhY2soKTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBgdGhpc2AgaWYgYFNvbWVgLCBvdGhlcndpc2UgY2FsbHMgYG5vbmVDYWxsYmFja2AgYW5kIHJldHVybnMgdGhlIHJlc3VsdAogICAgICogQHBhcmFtIG5vbmVDYWxsYmFjawogICAgICogQHJldHVybnMgYHRoaXNgIGlmIGBTb21lYCwgYG5vbmVDYWxsYmFjaygpYCBpZiBgTm9uZWAKICAgICAqLwogICAgb3JFbHNlU3luYyhub25lQ2FsbGJhY2spIHsKICAgICAgICByZXR1cm4gbm9uZUNhbGxiYWNrKCk7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYFNvbWVgIGlmIGV4YWN0bHkgb25lIG9mIHRoZSBvcHRpb25zIGlzIGBTb21lYCwgb3RoZXJ3aXNlIHJldHVybnMgYE5vbmVgCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEByZXR1cm5zIGBOb25lYCBpZiBib3RoIGFyZSBgU29tZWAgb3IgYm90aCBhcmUgYE5vbmVgLCB0aGUgb25seSBgU29tZWAgb3RoZXJ3aXNlCiAgICAgKi8KICAgIHhvcih2YWx1ZSkgewogICAgICAgIHJldHVybiB2YWx1ZTsKICAgIH0KICAgIC8qKgogICAgICogWmlwcyBgdGhpc2Agd2l0aCBhbm90aGVyIGBPcHRpb25gCiAgICAgKiBAcGFyYW0gb3RoZXIKICAgICAqIEByZXR1cm5zIGBTb21lKFt0aGlzLmlubmVyLCBvdGhlci5pbm5lcl0pYCBpZiBib3RoIGFyZSBgU29tZWAsIGBOb25lYCBpZiBvbmUgb2YgdGhlbSBpcyBgTm9uZWAKICAgICAqLwogICAgemlwKG90aGVyKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9Cn0KCgovLyMgc291cmNlTWFwcGluZ1VSTD1ub25lLm1qcy5tYXAKCjsvLyBDT05DQVRFTkFURUQgTU9EVUxFOiAuL25vZGVfbW9kdWxlcy9AaGF6YWU0MS9vcHRpb24vZGlzdC9lc20vbW9kcy9vcHRpb24vc29tZS5tanMKCgoKY2xhc3MgU29tZSB7CiAgICBpbm5lcjsKICAgIC8qKgogICAgICogQW4gZXhpc3RpbmcgdmFsdWUKICAgICAqIEBwYXJhbSBpbm5lcgogICAgICovCiAgICBjb25zdHJ1Y3Rvcihpbm5lcikgewogICAgICAgIHRoaXMuaW5uZXIgPSBpbm5lcjsKICAgIH0KICAgIC8qKgogICAgICogQ3JlYXRlIGEgYFNvbWVgCiAgICAgKiBAcGFyYW0gaW5uZXIKICAgICAqIEByZXR1cm5zIGBTb21lKGlubmVyKWAKICAgICAqLwogICAgc3RhdGljIG5ldyhpbm5lcikgewogICAgICAgIHJldHVybiBuZXcgdGhpcyhpbm5lcik7CiAgICB9CiAgICBzdGF0aWMgZnJvbShpbml0KSB7CiAgICAgICAgcmV0dXJuIG5ldyBTb21lKGluaXQuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBUeXBlIGd1YXJkIGZvciBgU29tZWAKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgU29tZWAsIGBmYWxzZWAgaWYgYE5vbmVgCiAgICAgKi8KICAgIGlzU29tZSgpIHsKICAgICAgICByZXR1cm4gdHJ1ZTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBgdHJ1ZWAgaWYgdGhlIG9wdGlvbiBpcyBhIGBTb21lYCBhbmQgdGhlIHZhbHVlIGluc2lkZSBvZiBpdCBtYXRjaGVzIGEgcHJlZGljYXRlCiAgICAgKiBAcGFyYW0gc29tZVByZWRpY2F0ZQogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBTb21lYCBhbmQgYGF3YWl0IHNvbWVQcmVkaWNhdGUodGhpcy5pbm5lcilgLCBgTm9uZWAgb3RoZXJ3aXNlCiAgICAgKi8KICAgIGFzeW5jIGlzU29tZUFuZChzb21lUHJlZGljYXRlKSB7CiAgICAgICAgcmV0dXJuIGF3YWl0IHNvbWVQcmVkaWNhdGUodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYHRydWVgIGlmIHRoZSBvcHRpb24gaXMgYSBgU29tZWAgYW5kIHRoZSB2YWx1ZSBpbnNpZGUgb2YgaXQgbWF0Y2hlcyBhIHByZWRpY2F0ZQogICAgICogQHBhcmFtIHNvbWVQcmVkaWNhdGUKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgU29tZWAgYW5kIGBzb21lUHJlZGljYXRlKHRoaXMuaW5uZXIpYCwgYE5vbmVgIG90aGVyd2lzZQogICAgICovCiAgICBpc1NvbWVBbmRTeW5jKHNvbWVQcmVkaWNhdGUpIHsKICAgICAgICByZXR1cm4gc29tZVByZWRpY2F0ZSh0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogVHlwZSBndWFyZCBmb3IgYE5vbmVgCiAgICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYE5vbmVgLCBgZmFsc2VgIGlmIGBTb21lYAogICAgICovCiAgICBpc05vbmUoKSB7CiAgICAgICAgcmV0dXJuIGZhbHNlOwogICAgfQogICAgLyoqCiAgICAgKiBDb21waWxlLXRpbWUgc2FmZWx5IGdldCBgdGhpcy5pbm5lcmAKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYAogICAgICovCiAgICBnZXQoKSB7CiAgICAgICAgcmV0dXJuIHRoaXMuaW5uZXI7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYW4gaXRlcmF0b3Igb3ZlciB0aGUgcG9zc2libHkgY29udGFpbmVkIHZhbHVlCiAgICAgKiBAeWllbGRzIGB0aGlzLmlubmVyYCBpZiBgU29tZWAKICAgICAqLwogICAgKltTeW1ib2wuaXRlcmF0b3JdKCkgewogICAgICAgIHlpZWxkIHRoaXMuaW5uZXI7CiAgICB9CiAgICAvKioKICAgICAqIEdldCB0aGUgaW5uZXIgdmFsdWUgaWYgYFNvbWVgLCB0aHJvdyBgRXJyb3IobWVzc2FnZSlgIG90aGVyd2lzZQogICAgICogQHBhcmFtIG1lc3NhZ2UKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgU29tZWAKICAgICAqIEB0aHJvd3MgYEVycm9yKG1lc3NhZ2UpYCBpZiBgTm9uZWAKICAgICAqLwogICAgZXhwZWN0KG1lc3NhZ2UpIHsKICAgICAgICByZXR1cm4gdGhpcy5pbm5lcjsKICAgIH0KICAgIC8qKgogICAgICogR2V0IHRoZSBpbm5lciB2YWx1ZSBvciB0aHJvdyBhIE5vbmVFcnJvcgogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBTb21lYAogICAgICogQHRocm93cyBgTm9uZUVycm9yYCBpZiBgTm9uZWAKICAgICAqLwogICAgdW53cmFwKCkgewogICAgICAgIHJldHVybiB0aGlzLmlubmVyOwogICAgfQogICAgLyoqCiAgICAgKiBHZXQgdGhlIGlubmVyIHZhbHVlIG9yIGEgZGVmYXVsdCBvbmUKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBTb21lYCwgYHZhbHVlYCBpZiBgTm9uZWAKICAgICAqLwogICAgdW53cmFwT3IodmFsdWUpIHsKICAgICAgICByZXR1cm4gdGhpcy5pbm5lcjsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyB0aGUgY29udGFpbmVkIGBTb21lYCB2YWx1ZSBvciBjb21wdXRlcyBpdCBmcm9tIGEgY2xvc3VyZQogICAgICogQHBhcmFtIG5vbmVDYWxsYmFjawogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBTb21lYCwgYGF3YWl0IG5vbmVDYWxsYmFjaygpYCBpZiBgTm9uZWAKICAgICAqLwogICAgYXN5bmMgdW53cmFwT3JFbHNlKG5vbmVDYWxsYmFjaykgewogICAgICAgIHJldHVybiB0aGlzLmlubmVyOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIHRoZSBjb250YWluZWQgYFNvbWVgIHZhbHVlIG9yIGNvbXB1dGVzIGl0IGZyb20gYSBjbG9zdXJlCiAgICAgKiBAcGFyYW0gbm9uZUNhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAgaWYgYFNvbWVgLCBgbm9uZUNhbGxiYWNrKClgIGlmIGBOb25lYAogICAgICovCiAgICB1bndyYXBPckVsc2VTeW5jKG5vbmVDYWxsYmFjaykgewogICAgICAgIHJldHVybiB0aGlzLmlubmVyOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm0gYE9wdGlvbjxUPmAgaW50byBgUmVzdWx0PFQsIE5vbmVFcnJvcj5gCiAgICAgKiBAcmV0dXJucyBgT2sodGhpcy5pbm5lcilgIGlmIGBTb21lYCwgYEVycihOb25lRXJyb3IpYCBpZiBgTm9uZWAKICAgICAqLwogICAgb2soKSB7CiAgICAgICAgcmV0dXJuIG5ldyBPayh0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtIGBPcHRpb248VD5gIGludG8gYFJlc3VsdDxULCBFPmAKICAgICAqIEBwYXJhbSBlcnJvcgogICAgICogQHJldHVybnMgYE9rKHRoaXMuaW5uZXIpYCBpZiBgU29tZWAsIGBFcnIoZXJyb3IpYCBpZiBgTm9uZWAKICAgICAqLwogICAgb2tPcihlcnJvcikgewogICAgICAgIHJldHVybiBuZXcgT2sodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybXMgdGhlIGBPcHRpb248VD5gIGludG8gYSBgUmVzdWx0PFQsIEU+YCwgbWFwcGluZyBgU29tZSh2KWAgdG8gYE9rKHYpYCBhbmQgYE5vbmVgIHRvIGBFcnIoZXJyKCkpYAogICAgICogQHBhcmFtIG5vbmVDYWxsYmFjawogICAgICogQHJldHVybnMgYE9rKHRoaXMuaW5uZXIpYCBpZiBgU29tZWAsIGBFcnIoYXdhaXQgbm9uZUNhbGxiYWNrKCkpYCBpcyBgTm9uZWAKICAgICAqLwogICAgYXN5bmMgb2tPckVsc2Uobm9uZUNhbGxiYWNrKSB7CiAgICAgICAgcmV0dXJuIG5ldyBPayh0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtcyB0aGUgYE9wdGlvbjxUPmAgaW50byBhIGBSZXN1bHQ8VCwgRT5gLCBtYXBwaW5nIGBTb21lKHYpYCB0byBgT2sodilgIGFuZCBgTm9uZWAgdG8gYEVycihlcnIoKSlgCiAgICAgKiBAcGFyYW0gbm9uZUNhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgT2sodGhpcy5pbm5lcilgIGlmIGBTb21lYCwgYEVycihub25lQ2FsbGJhY2soKSlgIGlzIGBOb25lYAogICAgICovCiAgICBva09yRWxzZVN5bmMobm9uZUNhbGxiYWNrKSB7CiAgICAgICAgcmV0dXJuIG5ldyBPayh0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBgTm9uZWAgaWYgdGhlIG9wdGlvbiBpcyBgTm9uZWAsIG90aGVyd2lzZSBjYWxscyBgc29tZVByZWRpY2F0ZWAgd2l0aCB0aGUgd3JhcHBlZCB2YWx1ZQogICAgICogQHBhcmFtIHNvbWVQcmVkaWNhdGUKICAgICAqIEByZXR1cm5zIGBTb21lYCBpZiBgU29tZWAgYW5kIGBhd2FpdCBzb21lUHJlZGljYXRlKHRoaXMuaW5uZXIpYCwgYE5vbmVgIG90aGVyd2lzZQogICAgICovCiAgICBhc3luYyBmaWx0ZXIoc29tZVByZWRpY2F0ZSkgewogICAgICAgIGlmIChhd2FpdCBzb21lUHJlZGljYXRlKHRoaXMuaW5uZXIpKQogICAgICAgICAgICByZXR1cm4gdGhpczsKICAgICAgICBlbHNlCiAgICAgICAgICAgIHJldHVybiBuZXcgTm9uZSgpOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGBOb25lYCBpZiB0aGUgb3B0aW9uIGlzIGBOb25lYCwgb3RoZXJ3aXNlIGNhbGxzIGBzb21lUHJlZGljYXRlYCB3aXRoIHRoZSB3cmFwcGVkIHZhbHVlCiAgICAgKiBAcGFyYW0gc29tZVByZWRpY2F0ZQogICAgICogQHJldHVybnMgYFNvbWVgIGlmIGBTb21lYCBhbmQgYHNvbWVQcmVkaWNhdGUodGhpcy5pbm5lcilgLCBgTm9uZWAgb3RoZXJ3aXNlCiAgICAgKi8KICAgIGZpbHRlclN5bmMoc29tZVByZWRpY2F0ZSkgewogICAgICAgIGlmIChzb21lUHJlZGljYXRlKHRoaXMuaW5uZXIpKQogICAgICAgICAgICByZXR1cm4gdGhpczsKICAgICAgICBlbHNlCiAgICAgICAgICAgIHJldHVybiBuZXcgTm9uZSgpOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm0gYE9wdGlvbjxQcm9taXNlPFQ+PmAgaW50byBgUHJvbWlzZTxPcHRpb248VD4+YAogICAgICogQHJldHVybnMgYFByb21pc2U8T3B0aW9uPFQ+PmAKICAgICAqLwogICAgYXN5bmMgYXdhaXQoKSB7CiAgICAgICAgcmV0dXJuIG5ldyBTb21lKGF3YWl0IHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGB0cnVlYCBpZiB0aGUgb3B0aW9uIGlzIGEgYFNvbWVgIHZhbHVlIGNvbnRhaW5pbmcgdGhlIGdpdmVuIHZhbHVlCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgU29tZWAgYW5kIGB0aGlzLmlubmVyID09PSB2YWx1ZWAsIGBOb25lYCBvdGhlcndpc2UKICAgICAqLwogICAgY29udGFpbnModmFsdWUpIHsKICAgICAgICByZXR1cm4gdGhpcy5pbm5lciA9PT0gdmFsdWU7CiAgICB9CiAgICAvKioKICAgICAqIENhbGxzIHRoZSBnaXZlbiBjYWxsYmFjayB3aXRoIHRoZSBpbm5lciB2YWx1ZSBpZiBgT2tgCiAgICAgKiBAcGFyYW0gc29tZUNhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgdGhpc2AKICAgICAqLwogICAgYXN5bmMgaW5zcGVjdChzb21lQ2FsbGJhY2spIHsKICAgICAgICBhd2FpdCBzb21lQ2FsbGJhY2sodGhpcy5pbm5lcik7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIENhbGxzIHRoZSBnaXZlbiBjYWxsYmFjayB3aXRoIHRoZSBpbm5lciB2YWx1ZSBpZiBgT2tgCiAgICAgKiBAcGFyYW0gc29tZUNhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgdGhpc2AKICAgICAqLwogICAgaW5zcGVjdFN5bmMoc29tZUNhbGxiYWNrKSB7CiAgICAgICAgc29tZUNhbGxiYWNrKHRoaXMuaW5uZXIpOwogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBNYXBzIGFuIGBPcHRpb248VD5gIHRvIGBPcHRpb248VT5gIGJ5IGFwcGx5aW5nIGEgZnVuY3Rpb24gdG8gYSBjb250YWluZWQgdmFsdWUgKGlmIGBTb21lYCkgb3IgcmV0dXJucyBgTm9uZWAgKGlmIGBOb25lYCkKICAgICAqIEBwYXJhbSBzb21lTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgU29tZShhd2FpdCBzb21lTWFwcGVyKHRoaXMuaW5uZXIpKWAgaWYgYFNvbWVgLCBgdGhpc2AgaWYgYE5vbmVgCiAgICAgKi8KICAgIGFzeW5jIG1hcChzb21lTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIG5ldyBTb21lKGF3YWl0IHNvbWVNYXBwZXIodGhpcy5pbm5lcikpOwogICAgfQogICAgLyoqCiAgICAgKiBNYXBzIGFuIGBPcHRpb248VD5gIHRvIGBPcHRpb248VT5gIGJ5IGFwcGx5aW5nIGEgZnVuY3Rpb24gdG8gYSBjb250YWluZWQgdmFsdWUgKGlmIGBTb21lYCkgb3IgcmV0dXJucyBgTm9uZWAgKGlmIGBOb25lYCkKICAgICAqIEBwYXJhbSBzb21lTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgU29tZShzb21lTWFwcGVyKHRoaXMuaW5uZXIpKWAgaWYgYFNvbWVgLCBgdGhpc2AgaWYgYE5vbmVgCiAgICAgKi8KICAgIG1hcFN5bmMoc29tZU1hcHBlcikgewogICAgICAgIHJldHVybiBuZXcgU29tZShzb21lTWFwcGVyKHRoaXMuaW5uZXIpKTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyB0aGUgcHJvdmlkZWQgZGVmYXVsdCByZXN1bHQgKGlmIG5vbmUpLCBvciBhcHBsaWVzIGEgZnVuY3Rpb24gdG8gdGhlIGNvbnRhaW5lZCB2YWx1ZSAoaWYgYW55KQogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcGFyYW0gc29tZU1hcHBlcgogICAgICogQHJldHVybnMgYHZhbHVlYCBpZiBgTm9uZWAsIGBhd2FpdCBzb21lTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgU29tZWAKICAgICAqLwogICAgYXN5bmMgbWFwT3IodmFsdWUsIHNvbWVNYXBwZXIpIHsKICAgICAgICByZXR1cm4gYXdhaXQgc29tZU1hcHBlcih0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyB0aGUgcHJvdmlkZWQgZGVmYXVsdCByZXN1bHQgKGlmIG5vbmUpLCBvciBhcHBsaWVzIGEgZnVuY3Rpb24gdG8gdGhlIGNvbnRhaW5lZCB2YWx1ZSAoaWYgYW55KQogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcGFyYW0gc29tZU1hcHBlcgogICAgICogQHJldHVybnMgYHZhbHVlYCBpZiBgTm9uZWAsIGBzb21lTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgU29tZWAKICAgICAqLwogICAgbWFwT3JTeW5jKHZhbHVlLCBzb21lTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIHNvbWVNYXBwZXIodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIENvbXB1dGVzIGEgZGVmYXVsdCBmdW5jdGlvbiByZXN1bHQgKGlmIG5vbmUpLCBvciBhcHBsaWVzIGEgZGlmZmVyZW50IGZ1bmN0aW9uIHRvIHRoZSBjb250YWluZWQgdmFsdWUgKGlmIGFueSkKICAgICAqIEBwYXJhbSBub25lQ2FsbGJhY2sKICAgICAqIEBwYXJhbSBzb21lTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgYXdhaXQgc29tZU1hcHBlcih0aGlzLmlubmVyKWAgaWYgYFNvbWVgLCBgYXdhaXQgbm9uZUNhbGxiYWNrKClgIGlmIGBOb25lYAogICAgICovCiAgICBhc3luYyBtYXBPckVsc2Uobm9uZUNhbGxiYWNrLCBzb21lTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIGF3YWl0IHNvbWVNYXBwZXIodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIENvbXB1dGVzIGEgZGVmYXVsdCBmdW5jdGlvbiByZXN1bHQgKGlmIG5vbmUpLCBvciBhcHBsaWVzIGEgZGlmZmVyZW50IGZ1bmN0aW9uIHRvIHRoZSBjb250YWluZWQgdmFsdWUgKGlmIGFueSkKICAgICAqIEBwYXJhbSBub25lQ2FsbGJhY2sKICAgICAqIEBwYXJhbSBzb21lTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgc29tZU1hcHBlcih0aGlzLmlubmVyKWAgaWYgYFNvbWVgLCBgbm9uZUNhbGxiYWNrKClgIGlmIGBOb25lYAogICAgICovCiAgICBtYXBPckVsc2VTeW5jKG5vbmVDYWxsYmFjaywgc29tZU1hcHBlcikgewogICAgICAgIHJldHVybiBzb21lTWFwcGVyKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGBOb25lYCBpZiB0aGUgb3B0aW9uIGlzIGBOb25lYCwgb3RoZXJ3aXNlIHJldHVybnMgYHZhbHVlYAogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcmV0dXJucyBgTm9uZWAgaWYgYE5vbmVgLCBgdmFsdWVgIGlmIGBTb21lYAogICAgICovCiAgICBhbmQodmFsdWUpIHsKICAgICAgICByZXR1cm4gdmFsdWU7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYE5vbmVgIGlmIHRoZSBvcHRpb24gaXMgYE5vbmVgLCBvdGhlcndpc2UgY2FsbHMgYHNvbWVNYXBwZXJgIHdpdGggdGhlIHdyYXBwZWQgdmFsdWUgYW5kIHJldHVybnMgdGhlIHJlc3VsdAogICAgICogQHBhcmFtIHNvbWVNYXBwZXIKICAgICAqIEByZXR1cm5zIGBOb25lYCBpZiBgTm9uZWAsIGBhd2FpdCBzb21lTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgU29tZWAKICAgICAqLwogICAgYXN5bmMgYW5kVGhlbihzb21lTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIGF3YWl0IHNvbWVNYXBwZXIodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYE5vbmVgIGlmIHRoZSBvcHRpb24gaXMgYE5vbmVgLCBvdGhlcndpc2UgY2FsbHMgYHNvbWVNYXBwZXJgIHdpdGggdGhlIHdyYXBwZWQgdmFsdWUgYW5kIHJldHVybnMgdGhlIHJlc3VsdAogICAgICogQHBhcmFtIHNvbWVNYXBwZXIKICAgICAqIEByZXR1cm5zIGBOb25lYCBpZiBgTm9uZWAsIGBzb21lTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgU29tZWAKICAgICAqLwogICAgYW5kVGhlblN5bmMoc29tZU1hcHBlcikgewogICAgICAgIHJldHVybiBzb21lTWFwcGVyKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGB0aGlzYCBpZiBgU29tZWAsIG90aGVyd2lzZSByZXR1cm5zIGB2YWx1ZWAKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHJldHVybnMgYHRoaXNgIGlmIGBTb21lYCwgYHZhbHVlYCBpZiBgTm9uZWAKICAgICAqLwogICAgb3IodmFsdWUpIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBgdGhpc2AgaWYgYFNvbWVgLCBvdGhlcndpc2UgY2FsbHMgYG5vbmVDYWxsYmFja2AgYW5kIHJldHVybnMgdGhlIHJlc3VsdAogICAgICogQHBhcmFtIG5vbmVDYWxsYmFjawogICAgICogQHJldHVybnMgYHRoaXNgIGlmIGBTb21lYCwgYGF3YWl0IG5vbmVDYWxsYmFjaygpYCBpZiBgTm9uZWAKICAgICAqLwogICAgYXN5bmMgb3JFbHNlKG5vbmVDYWxsYmFjaykgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGB0aGlzYCBpZiBgU29tZWAsIG90aGVyd2lzZSBjYWxscyBgbm9uZUNhbGxiYWNrYCBhbmQgcmV0dXJucyB0aGUgcmVzdWx0CiAgICAgKiBAcGFyYW0gbm9uZUNhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgdGhpc2AgaWYgYFNvbWVgLCBgbm9uZUNhbGxiYWNrKClgIGlmIGBOb25lYAogICAgICovCiAgICBvckVsc2VTeW5jKG5vbmVDYWxsYmFjaykgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGBTb21lYCBpZiBleGFjdGx5IG9uZSBvZiB0aGUgb3B0aW9ucyBpcyBgU29tZWAsIG90aGVyd2lzZSByZXR1cm5zIGBOb25lYAogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcmV0dXJucyBgTm9uZWAgaWYgYm90aCBhcmUgYFNvbWVgIG9yIGJvdGggYXJlIGBOb25lYCwgdGhlIG9ubHkgYFNvbWVgIG90aGVyd2lzZQogICAgICovCiAgICB4b3IodmFsdWUpIHsKICAgICAgICBpZiAodmFsdWUuaXNTb21lKCkpCiAgICAgICAgICAgIHJldHVybiBuZXcgTm9uZSgpOwogICAgICAgIGVsc2UKICAgICAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIFppcHMgYHRoaXNgIHdpdGggYW5vdGhlciBgT3B0aW9uYAogICAgICogQHBhcmFtIG90aGVyCiAgICAgKiBAcmV0dXJucyBgU29tZShbdGhpcy5pbm5lciwgb3RoZXIuaW5uZXJdKWAgaWYgYm90aCBhcmUgYFNvbWVgLCBgTm9uZWAgaWYgb25lIG9mIHRoZW0gaXMgYE5vbmVgCiAgICAgKi8KICAgIHppcChvdGhlcikgewogICAgICAgIGlmIChvdGhlci5pc1NvbWUoKSkKICAgICAgICAgICAgcmV0dXJuIG5ldyBTb21lKFt0aGlzLmlubmVyLCBvdGhlci5pbm5lcl0pOwogICAgICAgIGVsc2UKICAgICAgICAgICAgcmV0dXJuIG90aGVyOwogICAgfQp9CgoKLy8jIHNvdXJjZU1hcHBpbmdVUkw9c29tZS5tanMubWFwCgo7Ly8gQ09OQ0FURU5BVEVEIE1PRFVMRTogLi9ub2RlX21vZHVsZXMvQGhhemFlNDEvcmVzdWx0L2Rpc3QvZXNtL21vZHMvcmVzdWx0L29rLm1qcwoKCgoKY2xhc3MgT2sgewogICAgI2lubmVyOwogICAgI3RpbWVvdXQ7CiAgICAvKioKICAgICAqIEEgc3VjY2VzcwogICAgICogQHBhcmFtIGlubmVyCiAgICAgKi8KICAgIGNvbnN0cnVjdG9yKGlubmVyKSB7CiAgICAgICAgdGhpcy4jaW5uZXIgPSBpbm5lcjsKICAgICAgICBpZiAoIVJlc3VsdC5kZWJ1ZykKICAgICAgICAgICAgcmV0dXJuOwogICAgICAgIGNvbnN0IGVycm9yID0gbmV3IFBhbmljKGBVbmhhbmRsZWRgLCB7IGNhdXNlOiB0aGlzIH0pOwogICAgICAgIHRoaXMuI3RpbWVvdXQgPSBzZXRUaW1lb3V0KCgpID0+IHsgdGhyb3cgZXJyb3I7IH0sIDEwMDApOwogICAgfQogICAgLyoqCiAgICAgKiBDcmVhdGUgYW4gZW1wdHkgYE9rYAogICAgICogQHJldHVybnMgYE9rKHZvaWQpYAogICAgICovCiAgICBzdGF0aWMgdm9pZCgpIHsKICAgICAgICByZXR1cm4gbmV3IE9rKHVuZGVmaW5lZCk7CiAgICB9CiAgICAvKioKICAgICAqIENyZWF0ZSBhbiBgT2tgCiAgICAgKiBAcGFyYW0gaW5uZXIKICAgICAqIEByZXR1cm5zIGBPayhpbm5lcilgCiAgICAgKi8KICAgIHN0YXRpYyBuZXcoaW5uZXIpIHsKICAgICAgICByZXR1cm4gbmV3IE9rKGlubmVyKTsKICAgIH0KICAgIGdldCBpbm5lcigpIHsKICAgICAgICByZXR1cm4gdGhpcy4jaW5uZXI7CiAgICB9CiAgICAvKioKICAgICAqIFNldCB0aGlzIHJlc3VsdCBhcyBoYW5kbGVkCiAgICAgKi8KICAgIGlnbm9yZSgpIHsKICAgICAgICBpZiAoIXRoaXMuI3RpbWVvdXQpCiAgICAgICAgICAgIHJldHVybiB0aGlzOwogICAgICAgIGNsZWFyVGltZW91dCh0aGlzLiN0aW1lb3V0KTsKICAgICAgICB0aGlzLiN0aW1lb3V0ID0gdW5kZWZpbmVkOwogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBUeXBlIGd1YXJkIGZvciBgT2tgCiAgICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYE9rYCwgYGZhbHNlYCBpZiBgRXJyYAogICAgICovCiAgICBpc09rKCkgewogICAgICAgIHJldHVybiB0cnVlOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIHRydWUgaWYgdGhlIHJlc3VsdCBpcyBgT2tgIGFuZCB0aGUgdmFsdWUgaW5zaWRlIG9mIGl0IG1hdGNoZXMgYSBwcmVkaWNhdGUKICAgICAqIEBwYXJhbSBva1ByZWRpY2F0ZQogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBPa2AgYW5kIGBhd2FpdCBva1ByZWRpY2F0ZSh0aGlzLmlubmVyKWAsIGBmYWxzZWAgb3RoZXJ3aXNlCiAgICAgKi8KICAgIGFzeW5jIGlzT2tBbmQob2tQcmVkaWNhdGUpIHsKICAgICAgICByZXR1cm4gYXdhaXQgb2tQcmVkaWNhdGUodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgdHJ1ZSBpZiB0aGUgcmVzdWx0IGlzIGBPa2AgYW5kIHRoZSB2YWx1ZSBpbnNpZGUgb2YgaXQgbWF0Y2hlcyBhIHByZWRpY2F0ZQogICAgICogQHBhcmFtIG9rUHJlZGljYXRlCiAgICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYE9rYCBhbmQgYGF3YWl0IG9rUHJlZGljYXRlKHRoaXMuaW5uZXIpYCwgYGZhbHNlYCBvdGhlcndpc2UKICAgICAqLwogICAgaXNPa0FuZFN5bmMob2tQcmVkaWNhdGUpIHsKICAgICAgICByZXR1cm4gb2tQcmVkaWNhdGUodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFR5cGUgZ3VhcmQgZm9yIGBFcnJgCiAgICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYEVycmAsIGBmYWxzZWAgaWYgYE9rYAogICAgICovCiAgICBpc0VycigpIHsKICAgICAgICByZXR1cm4gZmFsc2U7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgdHJ1ZSBpZiB0aGUgcmVzdWx0IGlzIGBFcnJgIGFuZCB0aGUgdmFsdWUgaW5zaWRlIG9mIGl0IG1hdGNoZXMgYSBwcmVkaWNhdGUKICAgICAqIEBwYXJhbSBlcnJQcmVkaWNhdGUKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgRXJyYCBhbmQgYGF3YWl0IGVyclByZWRpY2F0ZSh0aGlzLmlubmVyKWAsIGBmYWxzZWAgb3RoZXJ3aXNlCiAgICAgKi8KICAgIGFzeW5jIGlzRXJyQW5kKGVyclByZWRpY2F0ZSkgewogICAgICAgIHJldHVybiBmYWxzZTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyB0cnVlIGlmIHRoZSByZXN1bHQgaXMgYEVycmAgYW5kIHRoZSB2YWx1ZSBpbnNpZGUgb2YgaXQgbWF0Y2hlcyBhIHByZWRpY2F0ZQogICAgICogQHBhcmFtIGVyclByZWRpY2F0ZQogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBFcnJgIGFuZCBgYXdhaXQgZXJyUHJlZGljYXRlKHRoaXMuaW5uZXIpYCwgYGZhbHNlYCBvdGhlcndpc2UKICAgICAqLwogICAgaXNFcnJBbmRTeW5jKGVyclByZWRpY2F0ZSkgewogICAgICAgIHJldHVybiBmYWxzZTsKICAgIH0KICAgIC8qKgogICAgICogQ29tcGlsZS10aW1lIHNhZmVseSBnZXQgYHRoaXMuaW5uZXJgCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAKICAgICAqLwogICAgZ2V0KCkgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIHRoaXMuaW5uZXI7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBgUmVzdWx0PFQsIEU+YCBpbnRvIGBPcHRpb248VD5gCiAgICAgKiBAcmV0dXJucyBgU29tZSh0aGlzLmlubmVyKWAgaWYgYE9rYCwgYE5vbmVgIGlmIGBFcnJgCiAgICAgKi8KICAgIG9rKCkgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIG5ldyBTb21lKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm0gYFJlc3VsdDxULCBFPmAgaW50byBgT3B0aW9uPEU+YAogICAgICogQHJldHVybnMgYFNvbWUodGhpcy5pbm5lcilgIGlmIGBFcnJgLCBgTm9uZWAgaWYgYE9rYAogICAgICovCiAgICBlcnIoKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gbmV3IE5vbmUoKTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBhbiBpdGVyYXRvciBvdmVyIHRoZSBwb3NzaWJseSBjb250YWluZWQgdmFsdWUKICAgICAqIEB5aWVsZHMgYHRoaXMuaW5uZXJgIGlmIGBPa2AKICAgICAqLwogICAgKltTeW1ib2wuaXRlcmF0b3JdKCkgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgeWllbGQgdGhpcy5pbm5lcjsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtIGBSZXN1bHQ8VCxFPmAgaW50byBgW1QsRV1gCiAgICAgKiBAcmV0dXJucyBgW3RoaXMuaW5uZXIsIHVuZGVmaW5lZF1gIGlmIGBPa2AsIGBbdW5kZWZpbmVkLCB0aGlzLmlubmVyXWAgaWYgYEVycmAKICAgICAqLwogICAgc3BsaXQoKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gW3RoaXMuaW5uZXIsIHVuZGVmaW5lZF07CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgdHJ1ZSBpZiB0aGUgcmVzdWx0IGlzIGFuIGBPa2AgdmFsdWUgY29udGFpbmluZyB0aGUgZ2l2ZW4gdmFsdWUKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBPa2AgYW5kIGB0aGlzLmlubmVyID09PSB2YWx1ZWAsIGBmYWxzZWAgb3RoZXJ3aXNlCiAgICAgKi8KICAgIGNvbnRhaW5zKHZhbHVlKSB7CiAgICAgICAgcmV0dXJuIHRoaXMuaW5uZXIgPT09IHZhbHVlOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIHRydWUgaWYgdGhlIHJlc3VsdCBpcyBhbiBgRXJyYCB2YWx1ZSBjb250YWluaW5nIHRoZSBnaXZlbiB2YWx1ZQogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYEVycmAgYW5kIGB0aGlzLmlubmVyID09PSB2YWx1ZWAsIGBmYWxzZWAgb3RoZXJ3aXNlCiAgICAgKi8KICAgIGNvbnRhaW5zRXJyKHZhbHVlKSB7CiAgICAgICAgcmV0dXJuIGZhbHNlOwogICAgfQogICAgLyoqCiAgICAgKiBKdXN0IGxpa2UgYHVud3JhcGAgYnV0IGl0IHRocm93cyB0byB0aGUgY2xvc2VzdCBgUmVzdWx0LnVudGhyb3dgCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAgaWYgYE9rYAogICAgICogQHRocm93cyBgdGhpc2AgaWYgYEVycmAKICAgICAqIEBzZWUgUmVzdWx0LnVudGhyb3cKICAgICAqIEBzZWUgUmVzdWx0LnVudGhyb3dTeW5jCiAgICAgKi8KICAgIHRocm93KHRocm93ZXIpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiB0aGlzLmlubmVyOwogICAgfQogICAgLyoqCiAgICAgKiBHZXQgdGhlIGlubmVyIHZhbHVlIG9yIHRocm93IHRoZSBpbm5lciBlcnJvciB3cmFwcGVkIGluc2lkZSBhbm90aGVyIEVycm9yCiAgICAgKiBAcGFyYW0gbWVzc2FnZQogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBPa2AsIGBFcnJvcihtZXNzYWdlLCB7IGNhdXNlOiB0aGlzLmlubmVyIH0pYCBpZiBgRXJyYAogICAgICovCiAgICBleHBlY3QobWVzc2FnZSkgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIHRoaXMuaW5uZXI7CiAgICB9CiAgICAvKioKICAgICAqIEdldCB0aGUgaW5uZXIgZXJyb3Igb3IgdGhyb3cgdGhlIGlubmVyIHZhbHVlIHdyYXBwZWQgaW5zaWRlIGFub3RoZXIgRXJyb3IKICAgICAqIEBwYXJhbSBtZXNzYWdlCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAgaWYgYEVycmAsIGBFcnJvcihtZXNzYWdlLCB7IGNhdXNlOiB0aGlzLmlubmVyIH0pYCBpZiBgT2tgCiAgICAgKi8KICAgIGV4cGVjdEVycihtZXNzYWdlKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICB0aHJvdyBuZXcgUGFuaWMobWVzc2FnZSwgeyBjYXVzZTogdGhpcyB9KTsKICAgIH0KICAgIC8qKgogICAgICogR2V0IHRoZSBpbm5lciB2YWx1ZSBvciBwYW5pYwogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBPa2AKICAgICAqIEB0aHJvd3MgYHRoaXMuaW5uZXJgIGlmIGBFcnJgCiAgICAgKi8KICAgIHVud3JhcCgpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiB0aGlzLmlubmVyOwogICAgfQogICAgLyoqCiAgICAgKiBHZXQgdGhlIGlubmVyIGVycm9yIG9yIHBhbmljCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAgaWYgYEVycmAKICAgICAqIEB0aHJvd3MgYHRoaXMuaW5uZXJgIGlmIGBPa2AKICAgICAqLwogICAgdW53cmFwRXJyKCkgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgdGhyb3cgbmV3IFBhbmljKGBVbndyYXBwZWRgLCB7IGNhdXNlOiB0aGlzIH0pOwogICAgfQogICAgLyoqCiAgICAgKiBHZXQgdGhlIGlubmVyIHZhbHVlIG9yIGEgZGVmYXVsdCBvbmUKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBPa2AsIGB2YWx1ZWAgaWYgYEVycmAKICAgICAqLwogICAgdW53cmFwT3IodmFsdWUpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiB0aGlzLmlubmVyOwogICAgfQogICAgLyoqCiAgICAgKiBHZXQgdGhlIGlubmVyIHZhbHVlIG9yIGNvbXB1dGUgYSBkZWZhdWx0IG9uZSBmcm9tIHRoZSBpbm5lciBlcnJvcgogICAgICogQHBhcmFtIGVyck1hcHBlcgogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBPa2AsIGBhd2FpdCBlcnJNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBFcnJgCiAgICAgKiBAdGhyb3dzIGlmIGBhd2FpdCBlcnJNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICBhc3luYyB1bndyYXBPckVsc2UoZXJyTWFwcGVyKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gdGhpcy5pbm5lcjsKICAgIH0KICAgIC8qKgogICAgICogR2V0IHRoZSBpbm5lciB2YWx1ZSBvciBjb21wdXRlIGEgZGVmYXVsdCBvbmUgZnJvbSB0aGUgaW5uZXIgZXJyb3IKICAgICAqIEBwYXJhbSBlcnJNYXBwZXIKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgT2tgLCBgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgRXJyYAogICAgICogQHRocm93cyBpZiBgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgdW53cmFwT3JFbHNlU3luYyhlcnJNYXBwZXIpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiB0aGlzLmlubmVyOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm0gUmVzdWx0PFByb21pc2U8VD4sIEU+IGludG8gUHJvbWlzZTxSZXN1bHQ8VCwgRT4+CiAgICAgKiBAcmV0dXJucyBgYXdhaXQgdGhpcy5pbm5lcmAgaWYgYE9rYCwgYHRoaXNgIGlmIGBFcnJgCiAgICAgKi8KICAgIGFzeW5jIGF3YWl0KCkgewogICAgICAgIHJldHVybiBuZXcgT2soYXdhaXQgdGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBSZXN1bHQ8VCwgUHJvbWlzZTxFPj4gaW50byBQcm9taXNlPFJlc3VsdDxULCBFPj4KICAgICAqIEByZXR1cm5zIGBhd2FpdCB0aGlzLmlubmVyYCBpZiBgRXJyYCwgYHRoaXNgIGlmIGBPa2AKICAgICAqLwogICAgYXN5bmMgYXdhaXRFcnIoKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBSZXN1bHQ8UHJvbWlzZTxUPiwgUHJvbWlzZTxFPj4gaW50byBQcm9taXNlPFJlc3VsdDxULCBFPj4KICAgICAqIEByZXR1cm5zIGBhd2FpdCB0aGlzLmlubmVyYAogICAgICovCiAgICBhc3luYyBhd2FpdEFsbCgpIHsKICAgICAgICByZXR1cm4gYXdhaXQgdGhpcy5hd2FpdCgpOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm0gYFJlc3VsdDxULCBFPmAgaW50byBgUmVzdWx0PHZvaWQsIEU+YAogICAgICogQHJldHVybnMgYE9rPHZvaWQ+YCBpZiBgT2s8VD5gLCBgRXJyPEU+YCBpZiBgRTxFPmAKICAgICAqLwogICAgY2xlYXIoKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gT2sudm9pZCgpOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm0gYFJlc3VsdDxULCBFPmAgaW50byBgUmVzdWx0PFQsIHZvaWQ+YAogICAgICogQHJldHVybnMgYE9rPFQ+YCBpZiBgT2s8VD5gLCBgRXJyPHZvaWQ+YCBpZiBgRTxFPmAKICAgICAqLwogICAgY2xlYXJFcnIoKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIENhbGxzIHRoZSBnaXZlbiBjYWxsYmFjayB3aXRoIHRoZSBpbm5lciB2YWx1ZSBpZiBgT2tgCiAgICAgKiBAcGFyYW0gb2tDYWxsYmFjawogICAgICogQHJldHVybnMgYHRoaXNgCiAgICAgKi8KICAgIGFzeW5jIGluc3BlY3Qob2tDYWxsYmFjaykgewogICAgICAgIGF3YWl0IG9rQ2FsbGJhY2sodGhpcy5pbm5lcik7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIENhbGxzIHRoZSBnaXZlbiBjYWxsYmFjayB3aXRoIHRoZSBpbm5lciB2YWx1ZSBpZiBgT2tgCiAgICAgKiBAcGFyYW0gb2tDYWxsYmFjawogICAgICogQHJldHVybnMgYHRoaXNgCiAgICAgKi8KICAgIGluc3BlY3RTeW5jKG9rQ2FsbGJhY2spIHsKICAgICAgICBva0NhbGxiYWNrKHRoaXMuaW5uZXIpOwogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBDYWxscyB0aGUgZ2l2ZW4gY2FsbGJhY2sgd2l0aCB0aGUgaW5uZXIgdmFsdWUgaWYgYEVycmAKICAgICAqIEBwYXJhbSBlcnJDYWxsYmFjawogICAgICogQHJldHVybnMgYHRoaXNgCiAgICAgKi8KICAgIGFzeW5jIGluc3BlY3RFcnIoZXJyQ2FsbGJhY2spIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogQ2FsbHMgdGhlIGdpdmVuIGNhbGxiYWNrIHdpdGggdGhlIGlubmVyIHZhbHVlIGlmIGBFcnJgCiAgICAgKiBAcGFyYW0gZXJyQ2FsbGJhY2sKICAgICAqIEByZXR1cm5zIGB0aGlzYAogICAgICovCiAgICBpbnNwZWN0RXJyU3luYyhlcnJDYWxsYmFjaykgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm4gYSBuZXcgYE9rYCBidXQgd2l0aCB0aGUgZ2l2ZW4gYGlubmVyYAogICAgICogQHBhcmFtIGlubmVyCiAgICAgKiBAcmV0dXJucyBgT2soaW5uZXIpYCBpZiBgT2tgLCBgdGhpc2AgaWYgYEVycmAKICAgICAqLwogICAgc2V0KGlubmVyKSB7CiAgICAgICAgcmV0dXJuIG5ldyBPayhpbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybiBhIG5ldyBgRXJyYCBidXQgd2l0aCB0aGUgZ2l2ZW4gYGlubmVyYAogICAgICogQHBhcmFtIGlubmVyCiAgICAgKiBAcmV0dXJucyBgRXJyKGlubmVyKWAgaWYgYEVycmAsIGB0aGlzYCBpZiBgT2tgCiAgICAgKi8KICAgIHNldEVycihpbm5lcikgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBNYXAgdGhlIGlubmVyIHZhbHVlIGludG8gYW5vdGhlcgogICAgICogQHBhcmFtIG9rTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgT2soYXdhaXQgb2tNYXBwZXIodGhpcy5pbm5lcikpYCBpZiBgT2tgLCBgdGhpc2AgaWYgYEVycmAKICAgICAqIEB0aHJvd3MgaWYgYGF3YWl0IG9rTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgYXN5bmMgbWFwKG9rTWFwcGVyKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gbmV3IE9rKGF3YWl0IG9rTWFwcGVyKHRoaXMuaW5uZXIpKTsKICAgIH0KICAgIC8qKgogICAgICogTWFwIHRoZSBpbm5lciB2YWx1ZSBpbnRvIGFub3RoZXIKICAgICAqIEBwYXJhbSBva01hcHBlcgogICAgICogQHJldHVybnMgYE9rKG9rTWFwcGVyKHRoaXMuaW5uZXIpKWAgaWYgYE9rYCwgYHRoaXNgIGlmIGBFcnJgCiAgICAgKiBAdGhyb3dzIGlmIGBva01hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIG1hcFN5bmMob2tNYXBwZXIpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiBuZXcgT2sob2tNYXBwZXIodGhpcy5pbm5lcikpOwogICAgfQogICAgLyoqCiAgICAgKiBNYXAgdGhlIGlubmVyIGVycm9yIGludG8gYW5vdGhlcgogICAgICogQHBhcmFtIGVyck1hcHBlcgogICAgICogQHJldHVybnMgYEVycihhd2FpdCBlcnJNYXBwZXIodGhpcy5pbm5lcikpYCBpZiBgRXJyYCwgYHRoaXNgIGlmIGBPa2AKICAgICAqIEB0aHJvd3MgaWYgYGF3YWl0IGVyck1hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIGFzeW5jIG1hcEVycihlcnJNYXBwZXIpIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogTWFwIHRoZSBpbm5lciBlcnJvciBpbnRvIGFub3RoZXIKICAgICAqIEBwYXJhbSBlcnJNYXBwZXIKICAgICAqIEByZXR1cm5zIGBFcnIoZXJyTWFwcGVyKHRoaXMuaW5uZXIpKWAgaWYgYEVycmAsIGB0aGlzYCBpZiBgT2tgCiAgICAgKiBAdGhyb3dzIGlmIGBlcnJNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICBtYXBFcnJTeW5jKGVyck1hcHBlcikgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBNYXAgdGhlIGlubmVyIHZhbHVlIGludG8gYW5vdGhlciwgb3IgYSBkZWZhdWx0IG9uZQogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcGFyYW0gb2tNYXBwZXIKICAgICAqIEByZXR1cm5zIGBhd2FpdCBva01hcHBlcih0aGlzLmlubmVyKWAgaWYgYE9rYCwgYHZhbHVlYCBpZiBgRXJyYAogICAgICogQHRocm93cyBpZiBgYXdhaXQgb2tNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICBhc3luYyBtYXBPcih2YWx1ZSwgb2tNYXBwZXIpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiBhd2FpdCBva01hcHBlcih0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogTWFwIHRoZSBpbm5lciB2YWx1ZSBpbnRvIGFub3RoZXIsIG9yIGEgZGVmYXVsdCBvbmUKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHBhcmFtIG9rTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgb2tNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBPa2AsIGB2YWx1ZWAgaWYgYEVycmAKICAgICAqIEB0aHJvd3MgaWYgYG9rTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgbWFwT3JTeW5jKHZhbHVlLCBva01hcHBlcikgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIG9rTWFwcGVyKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBNYXAgdGhlIGlubmVyIHZhbHVlIGludG8gYW5vdGhlciwgb3IgYSBkZWZhdWx0IG9uZQogICAgICogQHBhcmFtIGVyck1hcHBlcgogICAgICogQHBhcmFtIG9rTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgYXdhaXQgb2tNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBPa2AsIGBhd2FpdCBlcnJNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBFcnJgCiAgICAgKiBAdGhyb3dzIGlmIGBhd2FpdCBva01hcHBlcih0aGlzLmlubmVyKWAgb3IgYGF3YWl0IGVyck1hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIGFzeW5jIG1hcE9yRWxzZShlcnJNYXBwZXIsIG9rTWFwcGVyKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gYXdhaXQgb2tNYXBwZXIodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIE1hcCB0aGUgaW5uZXIgdmFsdWUgaW50byBhbm90aGVyLCBvciBhIGRlZmF1bHQgb25lCiAgICAgKiBAcGFyYW0gZXJyTWFwcGVyCiAgICAgKiBAcGFyYW0gb2tNYXBwZXIKICAgICAqIEByZXR1cm5zIGBva01hcHBlcih0aGlzLmlubmVyKWAgaWYgYE9rYCwgYGVyck1hcHBlcih0aGlzLmlubmVyKWAgaWYgYEVycmAKICAgICAqIEB0aHJvd3MgaWYgYG9rTWFwcGVyKHRoaXMuaW5uZXIpYCBvciBgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgbWFwT3JFbHNlU3luYyhlcnJNYXBwZXIsIG9rTWFwcGVyKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gb2tNYXBwZXIodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybiBgdmFsdWVgIGlmIGBPa2AsIHJldHVybiBgdGhpc2AgaWYgYEVycmAKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHJldHVybnMgYHZhbHVlYCBpZiBgT2tgLCBgdGhpc2AgaWYgYEVycmAKICAgICAqLwogICAgYW5kKHZhbHVlKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gdmFsdWU7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybiBgYXdhaXQgb2tNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBPa2AsIHJldHVybiBgdGhpc2AgaWYgYEVycmAKICAgICAqIEBwYXJhbSBva01hcHBlcgogICAgICogQHJldHVybnMgYGF3YWl0IG9rTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgT2tgLCBgdGhpc2AgaWYgYEVycmAKICAgICAqIEB0aHJvd3MgaWYgYGF3YWl0IG9rTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgYXN5bmMgYW5kVGhlbihva01hcHBlcikgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIGF3YWl0IG9rTWFwcGVyKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm4gYG9rTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgT2tgLCByZXR1cm4gYHRoaXNgIGlmIGBFcnJgCiAgICAgKiBAcGFyYW0gb2tNYXBwZXIKICAgICAqIEByZXR1cm5zIGBva01hcHBlcih0aGlzLmlubmVyKWAgaWYgYE9rYCwgYHRoaXNgIGlmIGBFcnJgCiAgICAgKiBAdGhyb3dzIGlmIGBva01hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIGFuZFRoZW5TeW5jKG9rTWFwcGVyKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gb2tNYXBwZXIodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybiBgdmFsdWVgIGlmIGBFcnJgLCByZXR1cm4gYHRoaXNgIGlmIGBPa2AKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHJldHVybnMgYHZhbHVlYCBpZiBgRXJyYCwgYHRoaXNgIGlmIGBPa2AKICAgICAqLwogICAgb3IodmFsdWUpIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJuIGBhd2FpdCBlcnJNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBFcnJgLCByZXR1cm4gYHRoaXNgIGlmIGBPa2AKICAgICAqIEBwYXJhbSBlcnJNYXBwZXIKICAgICAqIEByZXR1cm5zIGBhd2FpdCBlcnJNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBFcnJgLCBgdGhpc2AgaWYgYE9rYAogICAgICogQHRocm93cyBpZiBgYXdhaXQgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgYXN5bmMgb3JFbHNlKGVyck1hcHBlcikgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm4gYGVyck1hcHBlcih0aGlzLmlubmVyKWAgaWYgYEVycmAsIHJldHVybiBgdGhpc2AgaWYgYE9rYAogICAgICogQHBhcmFtIGVyck1hcHBlcgogICAgICogQHJldHVybnMgYGVyck1hcHBlcih0aGlzLmlubmVyKWAgaWYgYEVycmAsIGB0aGlzYCBpZiBgT2tgCiAgICAgKiBAdGhyb3dzIGlmIGBlcnJNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICBvckVsc2VTeW5jKGVyck1hcHBlcikgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm0gUmVzdWx0PFJlc3VsdDxULCBFMT4sIEUyPiBpbnRvIFJlc3VsdDxULCBFMSB8IEUyPgogICAgICogQHBhcmFtIHJlc3VsdAogICAgICogQHJldHVybnMgYHRoaXNgIGlmIGBFcnJgLCBgdGhpcy5pbm5lcmAgaWYgYE9rYAogICAgICovCiAgICBmbGF0dGVuKCkgewogICAgICAgIHJldHVybiB0aGlzLmlubmVyOwogICAgfQp9CgoKLy8jIHNvdXJjZU1hcHBpbmdVUkw9b2subWpzLm1hcAoKOy8vIENPTkNBVEVOQVRFRCBNT0RVTEU6IC4vc3JjL2xpYnMvcnBjL29rLnRzCgp2YXIgUnBjT2tJbml0OwooZnVuY3Rpb24oUnBjT2tJbml0KSB7CiAgICBmdW5jdGlvbiBmcm9tKHJlc3BvbnNlKSB7CiAgICAgICAgY29uc3QgeyBqc29ucnBjLCBpZCwgcmVzdWx0IH0gPSByZXNwb25zZTsKICAgICAgICByZXR1cm4gewogICAgICAgICAgICBqc29ucnBjLAogICAgICAgICAgICBpZCwKICAgICAgICAgICAgcmVzdWx0CiAgICAgICAgfTsKICAgIH0KICAgIFJwY09rSW5pdC5mcm9tID0gZnJvbTsKfSkoUnBjT2tJbml0IHx8IChScGNPa0luaXQgPSB7fSkpOwpjbGFzcyBScGNPayBleHRlbmRzIE9rIHsKICAgIHN0YXRpYyBmcm9tKGluaXQpIHsKICAgICAgICByZXR1cm4gbmV3IFJwY09rKGluaXQuaWQsIGluaXQucmVzdWx0KTsKICAgIH0KICAgIGNvbnN0cnVjdG9yKGlkLCByZXN1bHQpewogICAgICAgIHN1cGVyKHJlc3VsdCk7CiAgICAgICAgdGhpcy5qc29ucnBjID0gIjIuMCI7CiAgICAgICAgdGhpcy5pZCA9IGlkOwogICAgICAgIHRoaXMucmVzdWx0ID0gcmVzdWx0OwogICAgfQp9Cgo7Ly8gQ09OQ0FURU5BVEVEIE1PRFVMRTogLi9zcmMvbGlicy9ycGMvZXJyLnRzCgpjbGFzcyBScGNFcnJvciBleHRlbmRzIEVycm9yIHsKICAgIHN0YXRpYyBmcm9tKGVycm9yKSB7CiAgICAgICAgcmV0dXJuIG5ldyBScGNFcnJvcihlcnJvci5tZXNzYWdlKTsKICAgIH0KICAgIC8qKgogICAgICogVXNlZCBieSBKU09OLnN0cmluZ2lmeQogICAgICovIHRvSlNPTigpIHsKICAgICAgICBjb25zdCB7IG1lc3NhZ2UgfSA9IHRoaXM7CiAgICAgICAgcmV0dXJuIHsKICAgICAgICAgICAgbWVzc2FnZQogICAgICAgIH07CiAgICB9Cn0KY2xhc3MgUnBjRXJyIGV4dGVuZHMgRXJyIHsKICAgIHN0YXRpYyBmcm9tKGluaXQpIHsKICAgICAgICByZXR1cm4gbmV3IFJwY0Vycihpbml0LmlkLCBuZXcgUnBjRXJyb3IoaW5pdC5lcnJvci5tZXNzYWdlKSk7CiAgICB9CiAgICBjb25zdHJ1Y3RvcihpZCwgZXJyb3IpewogICAgICAgIHN1cGVyKGVycm9yKTsKICAgICAgICB0aGlzLmpzb25ycGMgPSAiMi4wIjsKICAgICAgICB0aGlzLmlkID0gaWQ7CiAgICAgICAgdGhpcy5lcnJvciA9IGVycm9yOwogICAgfQp9Cgo7Ly8gQ09OQ0FURU5BVEVEIE1PRFVMRTogLi9zcmMvbGlicy9ycGMvcmVzcG9uc2UudHMKCgp2YXIgUnBjUmVzcG9uc2U7CihmdW5jdGlvbihScGNSZXNwb25zZSkgewogICAgZnVuY3Rpb24gZnJvbShpbml0KSB7CiAgICAgICAgaWYgKCJlcnJvciIgaW4gaW5pdCkgcmV0dXJuIFJwY0Vyci5mcm9tKGluaXQpOwogICAgICAgIHJldHVybiBScGNPay5mcm9tKGluaXQpOwogICAgfQogICAgUnBjUmVzcG9uc2UuZnJvbSA9IGZyb207CiAgICBmdW5jdGlvbiByZXdyYXAoaWQsIHJlc3VsdCkgewogICAgICAgIHJlc3VsdC5pZ25vcmUoKTsKICAgICAgICBpZiAocmVzdWx0LmlzT2soKSkgcmV0dXJuIG5ldyBScGNPayhpZCwgcmVzdWx0LmlubmVyKTsKICAgICAgICBpZiAocmVzdWx0LmlubmVyIGluc3RhbmNlb2YgRXJyb3IpIHJldHVybiBuZXcgUnBjRXJyKGlkLCBScGNFcnJvci5mcm9tKHJlc3VsdC5pbm5lcikpOwogICAgICAgIHJldHVybiBuZXcgUnBjRXJyKGlkLCBuZXcgUnBjRXJyb3IoKSk7CiAgICB9CiAgICBScGNSZXNwb25zZS5yZXdyYXAgPSByZXdyYXA7Cn0pKFJwY1Jlc3BvbnNlIHx8IChScGNSZXNwb25zZSA9IHt9KSk7Cgo7Ly8gQ09OQ0FURU5BVEVEIE1PRFVMRTogLi9ub2RlX21vZHVsZXMvQGhhemFlNDEvYnl0ZXMvZGlzdC9lc20vbGlicy9hc2NpaS9hc2NpaS5tanMKdmFyIEFzY2lpOwooZnVuY3Rpb24gKEFzY2lpKSB7CiAgICBBc2NpaS5lbmNvZGVyID0gbmV3IFRleHRFbmNvZGVyKCk7CiAgICBBc2NpaS5kZWNvZGVyID0gbmV3IFRleHREZWNvZGVyKCJhc2NpaSIpOwp9KShBc2NpaSB8fCAoQXNjaWkgPSB7fSkpOwoKCi8vIyBzb3VyY2VNYXBwaW5nVVJMPWFzY2lpLm1qcy5tYXAKCjsvLyBDT05DQVRFTkFURUQgTU9EVUxFOiAuL25vZGVfbW9kdWxlcy9AaGF6YWU0MS9ieXRlcy9kaXN0L2VzbS9saWJzL2J1ZmZlcnMvYnVmZmVycy5tanMKLyogcHJvdmlkZWQgZGVwZW5kZW5jeSAqLyB2YXIgQnVmZmVyID0gX193ZWJwYWNrX3JlcXVpcmVfXyg3NjQpWyJsVyJdOwp2YXIgQnVmZmVyczsKKGZ1bmN0aW9uIChCdWZmZXJzKSB7CiAgICBmdW5jdGlvbiBmcm9tVmlldyh2aWV3KSB7CiAgICAgICAgcmV0dXJuIEJ1ZmZlci5mcm9tKHZpZXcuYnVmZmVyLCB2aWV3LmJ5dGVPZmZzZXQsIHZpZXcuYnl0ZUxlbmd0aCk7CiAgICB9CiAgICBCdWZmZXJzLmZyb21WaWV3ID0gZnJvbVZpZXc7Cn0pKEJ1ZmZlcnMgfHwgKEJ1ZmZlcnMgPSB7fSkpOwoKCi8vIyBzb3VyY2VNYXBwaW5nVVJMPWJ1ZmZlcnMubWpzLm1hcAoKOy8vIENPTkNBVEVOQVRFRCBNT0RVTEU6IC4vbm9kZV9tb2R1bGVzL0BoYXphZTQxL2J5dGVzL2Rpc3QvZXNtL2xpYnMvdXRmOC91dGY4Lm1qcwp2YXIgVXRmODsKKGZ1bmN0aW9uIChVdGY4KSB7CiAgICBVdGY4LmVuY29kZXIgPSBuZXcgVGV4dEVuY29kZXIoKTsKICAgIFV0ZjguZGVjb2RlciA9IG5ldyBUZXh0RGVjb2RlcigpOwp9KShVdGY4IHx8IChVdGY4ID0ge30pKTsKCgovLyMgc291cmNlTWFwcGluZ1VSTD11dGY4Lm1qcy5tYXAKCjsvLyBDT05DQVRFTkFURUQgTU9EVUxFOiAuL25vZGVfbW9kdWxlcy9AaGF6YWU0MS9ieXRlcy9kaXN0L2VzbS9tb2RzL2J5dGVzL2J5dGVzLm1qcwovKiBwcm92aWRlZCBkZXBlbmRlbmN5ICovIHZhciBieXRlc19CdWZmZXIgPSBfX3dlYnBhY2tfcmVxdWlyZV9fKDc2NClbImxXIl07CgoKCgoKY2xhc3MgQnl0ZXNGcm9tRXJyb3IgZXh0ZW5kcyBFcnJvciB7CiAgICAjY2xhc3MgPSBCeXRlc0Zyb21FcnJvcjsKICAgIG5hbWUgPSB0aGlzLiNjbGFzcy5uYW1lOwogICAgY29uc3RydWN0b3IoKSB7CiAgICAgICAgc3VwZXIoYENvdWxkIG5vdCBjb252ZXJ0IHRvIGJ5dGVzYCk7CiAgICB9Cn0KY2xhc3MgQnl0ZXNBbGxvY0Vycm9yIGV4dGVuZHMgRXJyb3IgewogICAgbGVuZ3RoOwogICAgI2NsYXNzID0gQnl0ZXNBbGxvY0Vycm9yOwogICAgbmFtZSA9IHRoaXMuI2NsYXNzLm5hbWU7CiAgICBjb25zdHJ1Y3RvcihsZW5ndGgpIHsKICAgICAgICBzdXBlcihgQ291bGQgbm90IGFsbG9jYXRlICR7bGVuZ3RofS1zaXplZCBieXRlc2ApOwogICAgICAgIHRoaXMubGVuZ3RoID0gbGVuZ3RoOwogICAgfQp9CmNsYXNzIEJ5dGVzQ2FzdEVycm9yIGV4dGVuZHMgRXJyb3IgewogICAgYWN0dWFsTGVuZ3RoOwogICAgZXhwZWN0ZWRMZW5ndGg7CiAgICAjY2xhc3MgPSBCeXRlc0Nhc3RFcnJvcjsKICAgIG5hbWUgPSB0aGlzLiNjbGFzcy5uYW1lOwogICAgY29uc3RydWN0b3IoYWN0dWFsTGVuZ3RoLCBleHBlY3RlZExlbmd0aCkgewogICAgICAgIHN1cGVyKGBDb3VsZCBub3QgY2FzdCAke2FjdHVhbExlbmd0aH0gYnl0ZXMgaW50byAke2V4cGVjdGVkTGVuZ3RofS1zaXplZCBieXRlc2ApOwogICAgICAgIHRoaXMuYWN0dWFsTGVuZ3RoID0gYWN0dWFsTGVuZ3RoOwogICAgICAgIHRoaXMuZXhwZWN0ZWRMZW5ndGggPSBleHBlY3RlZExlbmd0aDsKICAgIH0KfQp2YXIgQnl0ZXM7CihmdW5jdGlvbiAoQnl0ZXMpIHsKICAgIC8qKgogICAgICogQWxsb2MgMC1sZW5ndGhlZCBCeXRlcyB1c2luZyBzdGFuZGFyZCBjb25zdHJ1Y3RvcgogICAgICogQGRlcHJlY2F0ZWQKICAgICAqIEByZXR1cm5zIGBCeXRlc1tdYAogICAgICovCiAgICBmdW5jdGlvbiBlbXB0eSgpIHsKICAgICAgICByZXR1cm4gYWxsb2MoMCk7CiAgICB9CiAgICBCeXRlcy5lbXB0eSA9IGVtcHR5OwogICAgLyoqCiAgICAgKiBBbGxvYyAwLWxlbmd0aGVkIEJ5dGVzIHVzaW5nIHN0YW5kYXJkIGNvbnN0cnVjdG9yCiAgICAgKiBAcmV0dXJucyBgQnl0ZXNbXWAKICAgICAqLwogICAgZnVuY3Rpb24gdHJ5RW1wdHkoKSB7CiAgICAgICAgcmV0dXJuIHRyeUFsbG9jKDApOwogICAgfQogICAgQnl0ZXMudHJ5RW1wdHkgPSB0cnlFbXB0eTsKICAgIC8qKgogICAgICogQWxsb2MgQnl0ZXMgd2l0aCB0eXBlZCBsZW5ndGggdXNpbmcgc3RhbmRhcmQgY29uc3RydWN0b3IKICAgICAqIEBkZXByZWNhdGVkCiAgICAgKiBAcGFyYW0gbGVuZ3RoCiAgICAgKiBAcmV0dXJucyBgQnl0ZXNbMDtOXWAKICAgICAqLwogICAgZnVuY3Rpb24gYWxsb2MobGVuZ3RoKSB7CiAgICAgICAgcmV0dXJuIG5ldyBVaW50OEFycmF5KGxlbmd0aCk7CiAgICB9CiAgICBCeXRlcy5hbGxvYyA9IGFsbG9jOwogICAgLyoqCiAgICAgKiBBbGxvYyBCeXRlcyB3aXRoIHR5cGVkIGxlbmd0aCB1c2luZyBzdGFuZGFyZCBjb25zdHJ1Y3RvcgogICAgICogQHBhcmFtIGxlbmd0aAogICAgICogQHJldHVybnMgYEJ5dGVzWzA7Tl1gCiAgICAgKi8KICAgIGZ1bmN0aW9uIHRyeUFsbG9jKGxlbmd0aCkgewogICAgICAgIHRyeSB7CiAgICAgICAgICAgIHJldHVybiBuZXcgT2sobmV3IFVpbnQ4QXJyYXkobGVuZ3RoKSk7CiAgICAgICAgfQogICAgICAgIGNhdGNoIChlKSB7CiAgICAgICAgICAgIHJldHVybiBuZXcgRXJyKG5ldyBCeXRlc0FsbG9jRXJyb3IobGVuZ3RoKSk7CiAgICAgICAgfQogICAgfQogICAgQnl0ZXMudHJ5QWxsb2MgPSB0cnlBbGxvYzsKICAgIC8qKgogICAgICogQWxsb2MgQnl0ZXMgd2l0aCB0eXBlZCBsZW5ndGggKHVzaW5nIEJ1ZmZlci5hbGxvY1Vuc2FmZSBvbiBOb2RlLCBVaW50OEFycmF5IG9uIG90aGVycykKICAgICAqIEBkZXByZWNhdGVkCiAgICAgKiBAcGFyYW0gbGVuZ3RoCiAgICAgKiBAcmV0dXJucyBgQnl0ZXNbbnVtYmVyO05dYAogICAgICovCiAgICBmdW5jdGlvbiBhbGxvY1Vuc2FmZShsZW5ndGgpIHsKICAgICAgICBpZiAoInByb2Nlc3MiIGluIGdsb2JhbFRoaXMpCiAgICAgICAgICAgIHJldHVybiBmcm9tVmlldyhieXRlc19CdWZmZXIuYWxsb2NVbnNhZmUobGVuZ3RoKSk7CiAgICAgICAgcmV0dXJuIG5ldyBVaW50OEFycmF5KGxlbmd0aCk7CiAgICB9CiAgICBCeXRlcy5hbGxvY1Vuc2FmZSA9IGFsbG9jVW5zYWZlOwogICAgLyoqCiAgICAgKiBBbGxvYyBCeXRlcyB3aXRoIHR5cGVkIGxlbmd0aCAodXNpbmcgQnVmZmVyLmFsbG9jVW5zYWZlIG9uIE5vZGUsIFVpbnQ4QXJyYXkgb24gb3RoZXJzKQogICAgICogQHBhcmFtIGxlbmd0aAogICAgICogQHJldHVybnMgYEJ5dGVzW251bWJlcjtOXWAKICAgICAqLwogICAgZnVuY3Rpb24gdHJ5QWxsb2NVbnNhZmUobGVuZ3RoKSB7CiAgICAgICAgdHJ5IHsKICAgICAgICAgICAgaWYgKCJwcm9jZXNzIiBpbiBnbG9iYWxUaGlzKQogICAgICAgICAgICAgICAgcmV0dXJuIG5ldyBPayhmcm9tVmlldyhieXRlc19CdWZmZXIuYWxsb2NVbnNhZmUobGVuZ3RoKSkpOwogICAgICAgICAgICByZXR1cm4gbmV3IE9rKG5ldyBVaW50OEFycmF5KGxlbmd0aCkpOwogICAgICAgIH0KICAgICAgICBjYXRjaCAoZSkgewogICAgICAgICAgICByZXR1cm4gbmV3IEVycihuZXcgQnl0ZXNBbGxvY0Vycm9yKGxlbmd0aCkpOwogICAgICAgIH0KICAgIH0KICAgIEJ5dGVzLnRyeUFsbG9jVW5zYWZlID0gdHJ5QWxsb2NVbnNhZmU7CiAgICAvKioKICAgICAqIENyZWF0ZSBieXRlcyBmcm9tIGFycmF5CiAgICAgKiBAZGVwcmVjYXRlZAogICAgICogQHBhcmFtIGFycmF5CiAgICAgKiBAcmV0dXJucyBgQnl0ZXNbbnVtYmVyO05dYAogICAgICovCiAgICBmdW5jdGlvbiBmcm9tKGFycmF5KSB7CiAgICAgICAgcmV0dXJuIG5ldyBVaW50OEFycmF5KGFycmF5KTsKICAgIH0KICAgIEJ5dGVzLmZyb20gPSBmcm9tOwogICAgLyoqCiAgICAgKiBDcmVhdGUgYnl0ZXMgZnJvbSBhcnJheQogICAgICogQHBhcmFtIGFycmF5CiAgICAgKiBAcmV0dXJucyBgQnl0ZXNbbnVtYmVyO05dYAogICAgICovCiAgICBmdW5jdGlvbiB0cnlGcm9tKGFycmF5KSB7CiAgICAgICAgdHJ5IHsKICAgICAgICAgICAgcmV0dXJuIG5ldyBPayhuZXcgVWludDhBcnJheShhcnJheSkpOwogICAgICAgIH0KICAgICAgICBjYXRjaCAoZSkgewogICAgICAgICAgICByZXR1cm4gbmV3IEVycihuZXcgQnl0ZXNGcm9tRXJyb3IoKSk7CiAgICAgICAgfQogICAgfQogICAgQnl0ZXMudHJ5RnJvbSA9IHRyeUZyb207CiAgICAvKioKICAgICAqIENyZWF0ZSBieXRlcyBmcm9tIHNpemVkIG9mIGxlbmd0aCBOCiAgICAgKiBAZGVwcmVjYXRlZAogICAgICogQHBhcmFtIHNpemVkCiAgICAgKiBAcmV0dXJucyBgQnl0ZXNbbnVtYmVyO05dYAogICAgICovCiAgICBmdW5jdGlvbiBmcm9tU2l6ZWQoc2l6ZWQpIHsKICAgICAgICByZXR1cm4gbmV3IFVpbnQ4QXJyYXkoc2l6ZWQpOwogICAgfQogICAgQnl0ZXMuZnJvbVNpemVkID0gZnJvbVNpemVkOwogICAgLyoqCiAgICAgKiBDcmVhdGUgYnl0ZXMgZnJvbSBzaXplZCBvZiBsZW5ndGggTgogICAgICogQHBhcmFtIHNpemVkCiAgICAgKiBAcmV0dXJucyBgQnl0ZXNbbnVtYmVyO05dYAogICAgICovCiAgICBmdW5jdGlvbiB0cnlGcm9tU2l6ZWQoc2l6ZWQpIHsKICAgICAgICB0cnkgewogICAgICAgICAgICByZXR1cm4gbmV3IE9rKG5ldyBVaW50OEFycmF5KHNpemVkKSk7CiAgICAgICAgfQogICAgICAgIGNhdGNoIChlKSB7CiAgICAgICAgICAgIHJldHVybiBuZXcgRXJyKG5ldyBCeXRlc0FsbG9jRXJyb3Ioc2l6ZWQubGVuZ3RoKSk7CiAgICAgICAgfQogICAgfQogICAgQnl0ZXMudHJ5RnJvbVNpemVkID0gdHJ5RnJvbVNpemVkOwogICAgLyoqCiAgICAgKiBBbGxvYyBCeXRlcyB3aXRoIHR5cGVkIGxlbmd0aCAodXNpbmcgQnl0ZXMuYWxsb2NVbnNhZmUpIGFuZCBmaWxsIGl0IHdpdGggV2ViQ3J5cHRvJ3MgQ1NQUk5HCiAgICAgKiBAZGVwcmVjYXRlZAogICAgICogQHBhcmFtIGxlbmd0aAogICAgICogQHJldHVybnMgYEJ5dGVzW251bWJlcjtOXWAKICAgICAqLwogICAgZnVuY3Rpb24gcmFuZG9tKGxlbmd0aCkgewogICAgICAgIGNvbnN0IGJ5dGVzID0gYWxsb2NVbnNhZmUobGVuZ3RoKTsKICAgICAgICBjcnlwdG8uZ2V0UmFuZG9tVmFsdWVzKGJ5dGVzKTsKICAgICAgICByZXR1cm4gYnl0ZXM7CiAgICB9CiAgICBCeXRlcy5yYW5kb20gPSByYW5kb207CiAgICAvKioKICAgICAqIEFsbG9jIEJ5dGVzIHdpdGggdHlwZWQgbGVuZ3RoICh1c2luZyBCeXRlcy5hbGxvY1Vuc2FmZSkgYW5kIGZpbGwgaXQgd2l0aCBXZWJDcnlwdG8ncyBDU1BSTkcKICAgICAqIEBwYXJhbSBsZW5ndGgKICAgICAqIEByZXR1cm5zIGBCeXRlc1tudW1iZXI7Tl1gCiAgICAgKi8KICAgIGZ1bmN0aW9uIHRyeVJhbmRvbShsZW5ndGgpIHsKICAgICAgICBjb25zdCByZXN1bHQgPSB0cnlBbGxvY1Vuc2FmZShsZW5ndGgpOwogICAgICAgIHJlc3VsdC5pbnNwZWN0U3luYyhieXRlcyA9PiBjcnlwdG8uZ2V0UmFuZG9tVmFsdWVzKGJ5dGVzKSk7CiAgICAgICAgcmV0dXJuIHJlc3VsdDsKICAgIH0KICAgIEJ5dGVzLnRyeVJhbmRvbSA9IHRyeVJhbmRvbTsKICAgIC8qKgogICAgICogVHlwZSBndWFyZCBieXRlcyBvZiBOIGxlbmd0aCBpbnRvIEJ5dGVzPE4+CiAgICAgKiBAcGFyYW0gYnl0ZXMKICAgICAqIEBwYXJhbSBsZW5ndGgKICAgICAqIEByZXR1cm5zCiAgICAgKi8KICAgIGZ1bmN0aW9uIGlzKGJ5dGVzLCBsZW5ndGgpIHsKICAgICAgICByZXR1cm4gYnl0ZXMubGVuZ3RoLnZhbHVlT2YoKSA9PT0gbGVuZ3RoLnZhbHVlT2YoKTsKICAgIH0KICAgIEJ5dGVzLmlzID0gaXM7CiAgICAvKioKICAgICAqIEVxdWFsaXR5IGNoZWNrICh1c2luZyBpbmRleGVkREIuY21wIG9uIGJyb3dzZXJzLCBCdWZmZXIuZXF1YWxzIG9uIE5vZGUpCiAgICAgKiBAcGFyYW0gYQogICAgICogQHBhcmFtIGIKICAgICAqIEByZXR1cm5zCiAgICAgKi8KICAgIGZ1bmN0aW9uIGVxdWFscyhhLCBiKSB7CiAgICAgICAgaWYgKCJpbmRleGVkREIiIGluIGdsb2JhbFRoaXMpCiAgICAgICAgICAgIHJldHVybiBpbmRleGVkREIuY21wKGEsIGIpID09PSAwOwogICAgICAgIGlmICgicHJvY2VzcyIgaW4gZ2xvYmFsVGhpcykKICAgICAgICAgICAgcmV0dXJuIEJ1ZmZlcnMuZnJvbVZpZXcoYSkuZXF1YWxzKEJ1ZmZlcnMuZnJvbVZpZXcoYikpOwogICAgICAgIHRocm93IG5ldyBQYW5pYyhgQ2FuJ3QgY29tcGFyZSBieXRlc2ApOwogICAgfQogICAgQnl0ZXMuZXF1YWxzID0gZXF1YWxzOwogICAgLyoqCiAgICAgKiBFcXVhbGl0eSBjaGVjayAodXNpbmcgaW5kZXhlZERCLmNtcCBvbiBicm93c2VycywgQnVmZmVyLmVxdWFscyBvbiBOb2RlKQogICAgICogQHBhcmFtIGEKICAgICAqIEBwYXJhbSBiCiAgICAgKiBAcmV0dXJucwogICAgICovCiAgICBmdW5jdGlvbiBlcXVhbHMyKGEsIGIpIHsKICAgICAgICBpZiAoImluZGV4ZWREQiIgaW4gZ2xvYmFsVGhpcykKICAgICAgICAgICAgcmV0dXJuIGluZGV4ZWREQi5jbXAoYSwgYikgPT09IDA7CiAgICAgICAgaWYgKCJwcm9jZXNzIiBpbiBnbG9iYWxUaGlzKQogICAgICAgICAgICByZXR1cm4gQnVmZmVycy5mcm9tVmlldyhhKS5lcXVhbHMoQnVmZmVycy5mcm9tVmlldyhiKSk7CiAgICAgICAgdGhyb3cgbmV3IFBhbmljKGBDYW4ndCBjb21wYXJlIGJ5dGVzYCk7CiAgICB9CiAgICBCeXRlcy5lcXVhbHMyID0gZXF1YWxzMjsKICAgIC8qKgogICAgICogVHJ5IHRvIGNhc3QgYnl0ZXMgb2YgTiBsZW5ndGggaW50byBCeXRlczxOPgogICAgICogQHBhcmFtIHZpZXcKICAgICAqIEBwYXJhbSBsZW5ndGgKICAgICAqIEByZXR1cm5zCiAgICAgKi8KICAgIGZ1bmN0aW9uIHRyeUNhc3QoYnl0ZXMsIGxlbmd0aCkgewogICAgICAgIGlmIChpcyhieXRlcywgbGVuZ3RoKSkKICAgICAgICAgICAgcmV0dXJuIG5ldyBPayhieXRlcyk7CiAgICAgICAgcmV0dXJuIG5ldyBFcnIobmV3IEJ5dGVzQ2FzdEVycm9yKGJ5dGVzLmxlbmd0aCwgbGVuZ3RoKSk7CiAgICB9CiAgICBCeXRlcy50cnlDYXN0ID0gdHJ5Q2FzdDsKICAgIC8qKgogICAgICogVHJ5IHRvIGNhc3QgYnl0ZXMgb2YgTiBsZW5ndGggaW50byBCeXRlczxOPgogICAgICogQHBhcmFtIHZpZXcKICAgICAqIEBwYXJhbSBsZW5ndGgKICAgICAqIEByZXR1cm5zCiAgICAgKi8KICAgIGZ1bmN0aW9uIHRyeUNhc3RGcm9tKGFycmF5LCBsZW5ndGgpIHsKICAgICAgICByZXR1cm4gdHJ5Q2FzdChuZXcgVWludDhBcnJheShhcnJheSksIGxlbmd0aCk7CiAgICB9CiAgICBCeXRlcy50cnlDYXN0RnJvbSA9IHRyeUNhc3RGcm9tOwogICAgLyoqCiAgICAgKiBaZXJvLWNvcHkgY29udmVyc2lvbiBmcm9tIEFycmF5QnVmZmVyVmlldyBvZiBOIGxlbmd0aCBpbnRvIEJ5dGVzPE4+CiAgICAgKiBAcGFyYW0gdmlldwogICAgICogQHBhcmFtIGxlbmd0aAogICAgICogQHJldHVybnMKICAgICAqLwogICAgZnVuY3Rpb24gdHJ5Q2FzdEZyb21WaWV3KHZpZXcsIGxlbmd0aCkgewogICAgICAgIHJldHVybiB0cnlDYXN0KGZyb21WaWV3KHZpZXcpLCBsZW5ndGgpOwogICAgfQogICAgQnl0ZXMudHJ5Q2FzdEZyb21WaWV3ID0gdHJ5Q2FzdEZyb21WaWV3OwogICAgLyoqCiAgICAgKiBaZXJvLWNvcHkgY29udmVyc2lvbiBmcm9tIEFycmF5QnVmZmVyVmlldyBpbnRvIHVua25vd24tc2l6ZWQgQnl0ZXMKICAgICAqIEBwYXJhbSB2aWV3CiAgICAgKiBAcmV0dXJucwogICAgICovCiAgICBmdW5jdGlvbiBmcm9tVmlldyh2aWV3KSB7CiAgICAgICAgcmV0dXJuIG5ldyBVaW50OEFycmF5KHZpZXcuYnVmZmVyLCB2aWV3LmJ5dGVPZmZzZXQsIHZpZXcuYnl0ZUxlbmd0aCk7CiAgICB9CiAgICBCeXRlcy5mcm9tVmlldyA9IGZyb21WaWV3OwogICAgLyoqCiAgICAgKiBVdGY4IGVuY29kaW5nIHVzaW5nIFRleHRFbmNvZGVyCiAgICAgKiBAcGFyYW0gdGV4dAogICAgICogQHJldHVybnMKICAgICAqLwogICAgZnVuY3Rpb24gZnJvbVV0ZjgodGV4dCkgewogICAgICAgIHJldHVybiBVdGY4LmVuY29kZXIuZW5jb2RlKHRleHQpOwogICAgfQogICAgQnl0ZXMuZnJvbVV0ZjggPSBmcm9tVXRmODsKICAgIC8qKgogICAgICogVXRmOCBkZWNvZGluZyB1c2luZyBUZXh0RGVjb2RlcgogICAgICogQHBhcmFtIHRleHQKICAgICAqIEByZXR1cm5zCiAgICAgKi8KICAgIGZ1bmN0aW9uIHRvVXRmOChieXRlcykgewogICAgICAgIHJldHVybiBVdGY4LmRlY29kZXIuZGVjb2RlKGJ5dGVzKTsKICAgIH0KICAgIEJ5dGVzLnRvVXRmOCA9IHRvVXRmODsKICAgIC8qKgogICAgICogQXNjaWkgZGVjb2RpbmcgKHVzaW5nIEJ1ZmZlci5mcm9tIG9uIE5vZGUsIFRleHRFbmNvZGVyIG9uIG90aGVycykKICAgICAqIEBwYXJhbSBieXRlcwogICAgICogQHJldHVybnMKICAgICAqLwogICAgZnVuY3Rpb24gZnJvbUFzY2lpKHRleHQpIHsKICAgICAgICBpZiAoInByb2Nlc3MiIGluIGdsb2JhbFRoaXMpCiAgICAgICAgICAgIHJldHVybiBmcm9tVmlldyhieXRlc19CdWZmZXIuZnJvbSh0ZXh0LCAiYXNjaWkiKSk7CiAgICAgICAgcmV0dXJuIEFzY2lpLmVuY29kZXIuZW5jb2RlKHRleHQpOwogICAgfQogICAgQnl0ZXMuZnJvbUFzY2lpID0gZnJvbUFzY2lpOwogICAgLyoqCiAgICAgKiBBc2NpaSBlbmNvZGluZyAodXNpbmcgQnVmZmVyLnRvU3RyaW5nIG9uIE5vZGUsIFRleHREZWNvZGVyIG9uIG90aGVycykKICAgICAqIEBwYXJhbSBieXRlcwogICAgICogQHJldHVybnMKICAgICAqLwogICAgZnVuY3Rpb24gdG9Bc2NpaShieXRlcykgewogICAgICAgIGlmICgicHJvY2VzcyIgaW4gZ2xvYmFsVGhpcykKICAgICAgICAgICAgcmV0dXJuIEJ1ZmZlcnMuZnJvbVZpZXcoYnl0ZXMpLnRvU3RyaW5nKCJhc2NpaSIpOwogICAgICAgIHJldHVybiBBc2NpaS5kZWNvZGVyLmRlY29kZShieXRlcyk7CiAgICB9CiAgICBCeXRlcy50b0FzY2lpID0gdG9Bc2NpaTsKICAgIC8qKgogICAgICogU2xpY2Ugb3IgcGFkIGJ5dGVzIHRvIGV4YWN0IGxlbmd0aCBieSBmaWxsaW5nIDBzIGF0IHRoZSBzdGFydAogICAgICogQGRlcHJlY2F0ZWQKICAgICAqIEBleGFtcGxlIHNsaWNlT3JQYWRTdGFydChbMSwyLDMsNF0sIDIpID0gWzMsNF0KICAgICAqIEBleGFtcGxlIHNsaWNlT3JQYWRTdGFydChbMSwyLDMsNF0sIDYpID0gWzAsMCwxLDIsMyw0XQogICAgICogQHBhcmFtIGJ5dGVzCiAgICAgKiBAcGFyYW0gbGVuZ3RoCiAgICAgKiBAcmV0dXJucwogICAgICovCiAgICBmdW5jdGlvbiBzbGljZU9yUGFkU3RhcnQoYnl0ZXMsIGxlbmd0aCkgewogICAgICAgIGlmIChieXRlcy5sZW5ndGggPj0gbGVuZ3RoKSB7CiAgICAgICAgICAgIGNvbnN0IHNsaWNlID0gYnl0ZXMuc2xpY2UoYnl0ZXMubGVuZ3RoIC0gbGVuZ3RoLCBieXRlcy5sZW5ndGgpOwogICAgICAgICAgICByZXR1cm4gZnJvbVZpZXcoc2xpY2UpOwogICAgICAgIH0KICAgICAgICBjb25zdCBhcnJheSA9IGFsbG9jKGxlbmd0aCk7CiAgICAgICAgYXJyYXkuc2V0KGJ5dGVzLCBsZW5ndGggLSBieXRlcy5sZW5ndGgpOwogICAgICAgIHJldHVybiBhcnJheTsKICAgIH0KICAgIEJ5dGVzLnNsaWNlT3JQYWRTdGFydCA9IHNsaWNlT3JQYWRTdGFydDsKICAgIC8qKgogICAgICogU2xpY2Ugb3IgcGFkIGJ5dGVzIHRvIGV4YWN0IGxlbmd0aCBieSBmaWxsaW5nIDBzIGF0IHRoZSBzdGFydAogICAgICogQGV4YW1wbGUgc2xpY2VPclBhZFN0YXJ0KFsxLDIsMyw0XSwgMikgPSBbMyw0XQogICAgICogQGV4YW1wbGUgc2xpY2VPclBhZFN0YXJ0KFsxLDIsMyw0XSwgNikgPSBbMCwwLDEsMiwzLDRdCiAgICAgKiBAcGFyYW0gYnl0ZXMKICAgICAqIEBwYXJhbSBsZW5ndGgKICAgICAqIEByZXR1cm5zCiAgICAgKi8KICAgIGZ1bmN0aW9uIHRyeVNsaWNlT3JQYWRTdGFydChieXRlcywgbGVuZ3RoKSB7CiAgICAgICAgaWYgKGJ5dGVzLmxlbmd0aCA+PSBsZW5ndGgpIHsKICAgICAgICAgICAgY29uc3Qgc2xpY2UgPSBieXRlcy5zbGljZShieXRlcy5sZW5ndGggLSBsZW5ndGgsIGJ5dGVzLmxlbmd0aCk7CiAgICAgICAgICAgIHJldHVybiBuZXcgT2soZnJvbVZpZXcoc2xpY2UpKTsKICAgICAgICB9CiAgICAgICAgY29uc3QgcmVzdWx0ID0gdHJ5QWxsb2MobGVuZ3RoKTsKICAgICAgICByZXN1bHQuaW5zcGVjdFN5bmMoYSA9PiBhLnNldChieXRlcywgbGVuZ3RoIC0gYnl0ZXMubGVuZ3RoKSk7CiAgICAgICAgcmV0dXJuIHJlc3VsdDsKICAgIH0KICAgIEJ5dGVzLnRyeVNsaWNlT3JQYWRTdGFydCA9IHRyeVNsaWNlT3JQYWRTdGFydDsKICAgIC8qKgogICAgICogUGFkIGJ5dGVzIHRvIG1pbmltdW0gbGVuZ3RoIGJ5IGZpbGxpbmcgMHMgYXQgdGhlIHN0YXJ0CiAgICAgKiBAZGVwcmVjYXRlZAogICAgICogQGV4YW1wbGUgcGFkU3RhcnQoWzEsMiwzLDRdLCAyKSA9IFsxLDIsMyw0XQogICAgICogQGV4YW1wbGUgcGFkU3RhcnQoWzEsMiwzLDRdLCA2KSA9IFswLDAsMSwyLDMsNF0KICAgICAqIEBwYXJhbSBieXRlcwogICAgICogQHBhcmFtIGxlbmd0aAogICAgICogQHJldHVybnMKICAgICAqLwogICAgZnVuY3Rpb24gcGFkU3RhcnQoYnl0ZXMsIGxlbmd0aCkgewogICAgICAgIGlmIChieXRlcy5sZW5ndGggPj0gbGVuZ3RoKQogICAgICAgICAgICByZXR1cm4gYnl0ZXM7CiAgICAgICAgY29uc3QgYXJyYXkgPSBhbGxvYyhsZW5ndGgpOwogICAgICAgIGFycmF5LnNldChieXRlcywgbGVuZ3RoIC0gYnl0ZXMubGVuZ3RoKTsKICAgICAgICByZXR1cm4gYXJyYXk7CiAgICB9CiAgICBCeXRlcy5wYWRTdGFydCA9IHBhZFN0YXJ0OwogICAgLyoqCiAgICAgKiBQYWQgYnl0ZXMgdG8gbWluaW11bSBsZW5ndGggYnkgZmlsbGluZyAwcyBhdCB0aGUgc3RhcnQKICAgICAqIEBleGFtcGxlIHBhZFN0YXJ0KFsxLDIsMyw0XSwgMikgPSBbMSwyLDMsNF0KICAgICAqIEBleGFtcGxlIHBhZFN0YXJ0KFsxLDIsMyw0XSwgNikgPSBbMCwwLDEsMiwzLDRdCiAgICAgKiBAcGFyYW0gYnl0ZXMKICAgICAqIEBwYXJhbSBsZW5ndGgKICAgICAqIEByZXR1cm5zCiAgICAgKi8KICAgIGZ1bmN0aW9uIHRyeVBhZFN0YXJ0KGJ5dGVzLCBsZW5ndGgpIHsKICAgICAgICBpZiAoYnl0ZXMubGVuZ3RoID49IGxlbmd0aCkKICAgICAgICAgICAgcmV0dXJuIG5ldyBPayhieXRlcyk7CiAgICAgICAgY29uc3QgcmVzdWx0ID0gdHJ5QWxsb2MobGVuZ3RoKS5pbnNwZWN0U3luYyhyID0+IHIuc2V0KGJ5dGVzLCBsZW5ndGggLSBieXRlcy5sZW5ndGgpKTsKICAgICAgICByZXN1bHQuaW5zcGVjdFN5bmMoYSA9PiBhLnNldChieXRlcywgbGVuZ3RoIC0gYnl0ZXMubGVuZ3RoKSk7CiAgICAgICAgcmV0dXJuIHJlc3VsdDsKICAgIH0KICAgIEJ5dGVzLnRyeVBhZFN0YXJ0ID0gdHJ5UGFkU3RhcnQ7CiAgICAvKioKICAgICAqIENvbmNhdGVuYXRpb24gKHVzaW5nIEJ1ZmZlci5jb25jYXQgb24gTm9kZSwgaG9tZS1tYWRlIG9uIG90aGVycykKICAgICAqIEBwYXJhbSBsaXN0CiAgICAgKiBAcmV0dXJucwogICAgICovCiAgICBmdW5jdGlvbiBjb25jYXQobGlzdCkgewogICAgICAgIGlmICgicHJvY2VzcyIgaW4gZ2xvYmFsVGhpcykKICAgICAgICAgICAgcmV0dXJuIGZyb21WaWV3KGJ5dGVzX0J1ZmZlci5jb25jYXQobGlzdCkpOwogICAgICAgIGNvbnN0IGxlbmd0aCA9IGxpc3QucmVkdWNlKChwLCBjKSA9PiBwICsgYy5sZW5ndGgsIDApOwogICAgICAgIGNvbnN0IHJlc3VsdCA9IGFsbG9jVW5zYWZlKGxlbmd0aCk7CiAgICAgICAgbGV0IG9mZnNldCA9IDA7CiAgICAgICAgZm9yIChjb25zdCBieXRlcyBvZiBsaXN0KSB7CiAgICAgICAgICAgIHJlc3VsdC5zZXQoYnl0ZXMsIG9mZnNldCk7CiAgICAgICAgICAgIG9mZnNldCArPSBieXRlcy5sZW5ndGg7CiAgICAgICAgfQogICAgICAgIHJldHVybiByZXN1bHQ7CiAgICB9CiAgICBCeXRlcy5jb25jYXQgPSBjb25jYXQ7Cn0pKEJ5dGVzIHx8IChCeXRlcyA9IHt9KSk7CgoKLy8jIHNvdXJjZU1hcHBpbmdVUkw9Ynl0ZXMubWpzLm1hcAoKOy8vIENPTkNBVEVOQVRFRCBNT0RVTEU6IC4vbm9kZV9tb2R1bGVzL0BoYXphZTQxL2Z1dHVyZS9kaXN0L2VzbS9tb2RzL2Z1dHVyZS9mdXR1cmUubWpzCmNsYXNzIEZ1dHVyZSB7CiAgICAjcmVzb2x2ZTsKICAgICNyZWplY3Q7CiAgICBwcm9taXNlOwogICAgLyoqCiAgICAgKiBKdXN0IGxpa2UgYSBQcm9taXNlIGJ1dCB5b3UgY2FuIG1hbnVhbGx5IHJlc29sdmUgb3IgcmVqZWN0IGl0CiAgICAgKi8KICAgIGNvbnN0cnVjdG9yKCkgewogICAgICAgIHRoaXMucHJvbWlzZSA9IG5ldyBQcm9taXNlKChzdWJyZXNvbHZlLCBzdWJyZWplY3QpID0+IHsKICAgICAgICAgICAgdGhpcy4jcmVzb2x2ZSA9IHN1YnJlc29sdmU7CiAgICAgICAgICAgIHRoaXMuI3JlamVjdCA9IHN1YnJlamVjdDsKICAgICAgICB9KTsKICAgIH0KICAgIGdldCByZXNvbHZlKCkgewogICAgICAgIHJldHVybiB0aGlzLiNyZXNvbHZlOwogICAgfQogICAgZ2V0IHJlamVjdCgpIHsKICAgICAgICByZXR1cm4gdGhpcy4jcmVqZWN0OwogICAgfQp9CgoKLy8jIHNvdXJjZU1hcHBpbmdVUkw9ZnV0dXJlLm1qcy5tYXAKCjsvLyBDT05DQVRFTkFURUQgTU9EVUxFOiAuL25vZGVfbW9kdWxlcy9AaGF6YWU0MS9jbGVhbmVyL2Rpc3QvZXNtL2xpYnMvdW5wcm9taXNlL3VucHJvbWlzZS5tanMKdmFyIFVucHJvbWlzZTsKKGZ1bmN0aW9uIChVbnByb21pc2UpIHsKICAgIC8qKgogICAgICogTGlrZSBQcm9taXNlLmFsbCBidXQgc3luYwogICAgICogQHBhcmFtIGNhbGxiYWNrcwogICAgICogQHJldHVybnMKICAgICAqLwogICAgZnVuY3Rpb24gYWxsKGNhbGxiYWNrcykgewogICAgICAgIGNvbnN0IHJlc3VsdHMgPSBuZXcgQXJyYXkoKTsKICAgICAgICBsZXQgZXJyb3IgPSB1bmRlZmluZWQ7CiAgICAgICAgZm9yIChjb25zdCBjYWxsYmFjayBvZiBjYWxsYmFja3MpIHsKICAgICAgICAgICAgdHJ5IHsKICAgICAgICAgICAgICAgIHJlc3VsdHMucHVzaChjYWxsYmFjaygpKTsKICAgICAgICAgICAgfQogICAgICAgICAgICBjYXRjaCAoZSkgewogICAgICAgICAgICAgICAgZXJyb3IgPSB7IGUgfTsKICAgICAgICAgICAgfQogICAgICAgIH0KICAgICAgICBpZiAoZXJyb3IpCiAgICAgICAgICAgIHRocm93IGVycm9yLmU7CiAgICAgICAgcmV0dXJuIHJlc3VsdHM7CiAgICB9CiAgICBVbnByb21pc2UuYWxsID0gYWxsOwp9KShVbnByb21pc2UgfHwgKFVucHJvbWlzZSA9IHt9KSk7CgoKLy8jIHNvdXJjZU1hcHBpbmdVUkw9dW5wcm9taXNlLm1qcy5tYXAKCjsvLyBDT05DQVRFTkFURUQgTU9EVUxFOiAuL25vZGVfbW9kdWxlcy9AaGF6YWU0MS9jbGVhbmVyL2Rpc3QvZXNtL21vZHMvZGlzcG9zZS9kaXNwb3NlLm1qcwoKCmNsYXNzIERpc3Bvc2VyIHsKICAgIGlubmVyOwogICAgZGlzcG9zZTsKICAgIGNvbnN0cnVjdG9yKGlubmVyLCBkaXNwb3NlKSB7CiAgICAgICAgdGhpcy5pbm5lciA9IGlubmVyOwogICAgICAgIHRoaXMuZGlzcG9zZSA9IGRpc3Bvc2U7CiAgICB9CiAgICBzdGF0aWMgZnJvbShkaXNwb3NhYmxlKSB7CiAgICAgICAgcmV0dXJuIG5ldyBEaXNwb3NlcihkaXNwb3NhYmxlLCAoKSA9PiBkaXNwb3NhYmxlW1N5bWJvbC5kaXNwb3NlXSgpKTsKICAgIH0KICAgIFtTeW1ib2wuZGlzcG9zZV0oKSB7CiAgICAgICAgdGhpcy5kaXNwb3NlKCk7CiAgICB9Cn0KY2xhc3MgQXN5bmNEaXNwb3NlciB7CiAgICBpbm5lcjsKICAgIGFzeW5jRGlzcG9zZTsKICAgIGNvbnN0cnVjdG9yKGlubmVyLCBhc3luY0Rpc3Bvc2UpIHsKICAgICAgICB0aGlzLmlubmVyID0gaW5uZXI7CiAgICAgICAgdGhpcy5hc3luY0Rpc3Bvc2UgPSBhc3luY0Rpc3Bvc2U7CiAgICB9CiAgICBzdGF0aWMgZnJvbShkaXNwb3NhYmxlKSB7CiAgICAgICAgcmV0dXJuIG5ldyBBc3luY0Rpc3Bvc2VyKGRpc3Bvc2FibGUsICgpID0+IGRpc3Bvc2FibGVbU3ltYm9sLmFzeW5jRGlzcG9zZV0oKSk7CiAgICB9CiAgICBhc3luYyBbU3ltYm9sLmFzeW5jRGlzcG9zZV0oKSB7CiAgICAgICAgYXdhaXQgdGhpcy5hc3luY0Rpc3Bvc2UoKTsKICAgIH0KfQpjbGFzcyBQcm9taXNlRGlzcG9zZXIgewogICAgaW5uZXI7CiAgICBkaXNwb3NlOwogICAgY29uc3RydWN0b3IoaW5uZXIsIGRpc3Bvc2UpIHsKICAgICAgICB0aGlzLmlubmVyID0gaW5uZXI7CiAgICAgICAgdGhpcy5kaXNwb3NlID0gZGlzcG9zZTsKICAgIH0KICAgIHN0YXRpYyBmcm9tKGRpc3Bvc2FibGUpIHsKICAgICAgICByZXR1cm4gbmV3IFByb21pc2VEaXNwb3NlcihkaXNwb3NhYmxlLCAoKSA9PiBkaXNwb3NhYmxlW1N5bWJvbC5kaXNwb3NlXSgpKTsKICAgIH0KICAgIHRoZW4ob25mdWxmaWxsZWQsIG9ucmVqZWN0ZWQpIHsKICAgICAgICByZXR1cm4gdGhpcy5pbm5lci50aGVuKG9uZnVsZmlsbGVkLCBvbnJlamVjdGVkKTsKICAgIH0KICAgIFtTeW1ib2wuZGlzcG9zZV0oKSB7CiAgICAgICAgdGhpcy5kaXNwb3NlKCk7CiAgICB9Cn0KY2xhc3MgQXN5bmNQcm9taXNlRGlzcG9zZXIgewogICAgaW5uZXI7CiAgICBhc3luY0Rpc3Bvc2U7CiAgICBjb25zdHJ1Y3Rvcihpbm5lciwgYXN5bmNEaXNwb3NlKSB7CiAgICAgICAgdGhpcy5pbm5lciA9IGlubmVyOwogICAgICAgIHRoaXMuYXN5bmNEaXNwb3NlID0gYXN5bmNEaXNwb3NlOwogICAgfQogICAgc3RhdGljIGZyb20oZGlzcG9zYWJsZSkgewogICAgICAgIHJldHVybiBuZXcgUHJvbWlzZURpc3Bvc2VyKGRpc3Bvc2FibGUsICgpID0+IGRpc3Bvc2FibGVbU3ltYm9sLmFzeW5jRGlzcG9zZV0oKSk7CiAgICB9CiAgICB0aGVuKG9uZnVsZmlsbGVkLCBvbnJlamVjdGVkKSB7CiAgICAgICAgcmV0dXJuIHRoaXMuaW5uZXIudGhlbihvbmZ1bGZpbGxlZCwgb25yZWplY3RlZCk7CiAgICB9CiAgICBhc3luYyBbU3ltYm9sLmFzeW5jRGlzcG9zZV0oKSB7CiAgICAgICAgYXdhaXQgdGhpcy5hc3luY0Rpc3Bvc2UoKTsKICAgIH0KfQp2YXIgRGlzcG9zYWJsZTsKKGZ1bmN0aW9uIChEaXNwb3NhYmxlKSB7CiAgICBhc3luYyBmdW5jdGlvbiBkaXNwb3NlKGRpc3Bvc2FibGUpIHsKICAgICAgICBpZiAoU3ltYm9sLmRpc3Bvc2UgaW4gZGlzcG9zYWJsZSkKICAgICAgICAgICAgZGlzcG9zYWJsZVtTeW1ib2wuZGlzcG9zZV0oKTsKICAgICAgICBlbHNlIGlmIChTeW1ib2wuYXN5bmNEaXNwb3NlKQogICAgICAgICAgICBhd2FpdCBkaXNwb3NhYmxlW1N5bWJvbC5hc3luY0Rpc3Bvc2VdKCk7CiAgICB9CiAgICBEaXNwb3NhYmxlLmRpc3Bvc2UgPSBkaXNwb3NlOwogICAgZnVuY3Rpb24gZGlzcG9zZVN5bmMoZGlzcG9zYWJsZSkgewogICAgICAgIGRpc3Bvc2FibGVbU3ltYm9sLmRpc3Bvc2VdKCk7CiAgICB9CiAgICBEaXNwb3NhYmxlLmRpc3Bvc2VTeW5jID0gZGlzcG9zZVN5bmM7CiAgICBhc3luYyBmdW5jdGlvbiByYWNlKHByb21pc2VzKSB7CiAgICAgICAgdHJ5IHsKICAgICAgICAgICAgcmV0dXJuIGF3YWl0IFByb21pc2UucmFjZShwcm9taXNlcyk7CiAgICAgICAgfQogICAgICAgIGZpbmFsbHkgewogICAgICAgICAgICBhd2FpdCBQcm9taXNlLmFsbChwcm9taXNlcy5tYXAoZGlzcG9zZSkpOwogICAgICAgIH0KICAgIH0KICAgIERpc3Bvc2FibGUucmFjZSA9IHJhY2U7CiAgICBhc3luYyBmdW5jdGlvbiByYWNlU3luYyhwcm9taXNlcykgewogICAgICAgIHRyeSB7CiAgICAgICAgICAgIHJldHVybiBhd2FpdCBQcm9taXNlLnJhY2UocHJvbWlzZXMpOwogICAgICAgIH0KICAgICAgICBmaW5hbGx5IHsKICAgICAgICAgICAgVW5wcm9taXNlLmFsbChwcm9taXNlcy5tYXAoaXQgPT4gKCkgPT4gZGlzcG9zZVN5bmMoaXQpKSk7CiAgICAgICAgfQogICAgfQogICAgRGlzcG9zYWJsZS5yYWNlU3luYyA9IHJhY2VTeW5jOwp9KShEaXNwb3NhYmxlIHx8IChEaXNwb3NhYmxlID0ge30pKTsKCgovLyMgc291cmNlTWFwcGluZ1VSTD1kaXNwb3NlLm1qcy5tYXAKCjsvLyBDT05DQVRFTkFURUQgTU9EVUxFOiAuL25vZGVfbW9kdWxlcy9AaGF6YWU0MS9wbHVtZS9kaXN0L2VzbS9tb2RzL2Vycm9ycy5tanMKCgoKCgpjbGFzcyBBYm9ydGVkRXJyb3IgZXh0ZW5kcyBFcnJvciB7CiAgICAjY2xhc3MgPSBBYm9ydGVkRXJyb3I7CiAgICBuYW1lID0gdGhpcy4jY2xhc3MubmFtZTsKICAgIHN0YXRpYyBmcm9tKGNhdXNlKSB7CiAgICAgICAgcmV0dXJuIG5ldyBBYm9ydGVkRXJyb3IoYEFib3J0ZWRgLCB7IGNhdXNlIH0pOwogICAgfQogICAgc3RhdGljIHdhaXQoc2lnbmFsKSB7CiAgICAgICAgY29uc3QgZnV0dXJlID0gbmV3IEZ1dHVyZSgpOwogICAgICAgIGNvbnN0IG9uQWJvcnQgPSAoZXZlbnQpID0+IHsKICAgICAgICAgICAgZnV0dXJlLnJlc29sdmUobmV3IEVycihBYm9ydGVkRXJyb3IuZnJvbShldmVudCkpKTsKICAgICAgICB9OwogICAgICAgIHNpZ25hbC5hZGRFdmVudExpc3RlbmVyKCJhYm9ydCIsIG9uQWJvcnQsIHsgcGFzc2l2ZTogdHJ1ZSB9KTsKICAgICAgICBjb25zdCBvZmYgPSAoKSA9PiBzaWduYWwucmVtb3ZlRXZlbnRMaXN0ZW5lcigiYWJvcnQiLCBvbkFib3J0KTsKICAgICAgICByZXR1cm4gbmV3IFByb21pc2VEaXNwb3NlcihmdXR1cmUucHJvbWlzZSwgb2ZmKTsKICAgIH0KfQpjbGFzcyBFcnJvcmVkRXJyb3IgZXh0ZW5kcyBFcnJvciB7CiAgICAjY2xhc3MgPSBFcnJvcmVkRXJyb3I7CiAgICBuYW1lID0gdGhpcy4jY2xhc3MubmFtZTsKICAgIHN0YXRpYyBmcm9tKGNhdXNlKSB7CiAgICAgICAgcmV0dXJuIG5ldyBFcnJvcmVkRXJyb3IoYEVycm9yZWRgLCB7IGNhdXNlIH0pOwogICAgfQogICAgc3RhdGljIHdhaXQodGFyZ2V0KSB7CiAgICAgICAgcmV0dXJuIHRhcmdldC53YWl0KCJlcnJvciIsIChmdXR1cmUsIGV2ZW50KSA9PiB7CiAgICAgICAgICAgIGNvbnN0IGVycm9yID0gRXJyb3JlZEVycm9yLmZyb20oZXZlbnQpOwogICAgICAgICAgICBmdXR1cmUucmVzb2x2ZShuZXcgRXJyKGVycm9yKSk7CiAgICAgICAgICAgIHJldHVybiBuZXcgTm9uZSgpOwogICAgICAgIH0pOwogICAgfQp9CmNsYXNzIENsb3NlZEVycm9yIGV4dGVuZHMgRXJyb3IgewogICAgI2NsYXNzID0gQ2xvc2VkRXJyb3I7CiAgICBuYW1lID0gdGhpcy4jY2xhc3MubmFtZTsKICAgIHN0YXRpYyBmcm9tKGNhdXNlKSB7CiAgICAgICAgcmV0dXJuIG5ldyBDbG9zZWRFcnJvcihgQ2xvc2VkYCwgeyBjYXVzZSB9KTsKICAgIH0KICAgIHN0YXRpYyB3YWl0KHRhcmdldCkgewogICAgICAgIHJldHVybiB0YXJnZXQud2FpdCgiY2xvc2UiLCAoZnV0dXJlLCBldmVudCkgPT4gewogICAgICAgICAgICBjb25zdCBlcnJvciA9IENsb3NlZEVycm9yLmZyb20oZXZlbnQpOwogICAgICAgICAgICBmdXR1cmUucmVzb2x2ZShuZXcgRXJyKGVycm9yKSk7CiAgICAgICAgICAgIHJldHVybiBuZXcgTm9uZSgpOwogICAgICAgIH0pOwogICAgfQp9CgoKLy8jIHNvdXJjZU1hcHBpbmdVUkw9ZXJyb3JzLm1qcy5tYXAKCjsvLyBDT05DQVRFTkFURUQgTU9EVUxFOiAuL3NyYy9saWJzL3JwYy9yZXF1ZXN0LnRzCmNsYXNzIFJwY1JlcXVlc3QgewogICAgc3RhdGljIGZyb20oaW5pdCkgewogICAgICAgIGNvbnN0IHsgaWQsIG1ldGhvZCwgcGFyYW1zIH0gPSBpbml0OwogICAgICAgIHJldHVybiBuZXcgUnBjUmVxdWVzdChpZCwgbWV0aG9kLCBwYXJhbXMpOwogICAgfQogICAgdG9KU09OKCkgewogICAgICAgIGNvbnN0IHsganNvbnJwYywgaWQsIG1ldGhvZCwgcGFyYW1zIH0gPSB0aGlzOwogICAgICAgIHJldHVybiB7CiAgICAgICAgICAgIGpzb25ycGMsCiAgICAgICAgICAgIGlkLAogICAgICAgICAgICBtZXRob2QsCiAgICAgICAgICAgIHBhcmFtcwogICAgICAgIH07CiAgICB9CiAgICBjb25zdHJ1Y3RvcihpZCwgbWV0aG9kLCBwYXJhbXMpewogICAgICAgIHRoaXMuanNvbnJwYyA9ICIyLjAiOwogICAgICAgIHRoaXMuaWQgPSBpZDsKICAgICAgICB0aGlzLm1ldGhvZCA9IG1ldGhvZDsKICAgICAgICB0aGlzLnBhcmFtcyA9IHBhcmFtczsKICAgIH0KfQoKOy8vIENPTkNBVEVOQVRFRCBNT0RVTEU6IC4vc3JjL2xpYnMvcnBjL3JwYy50cwoKCgoKCgpjbGFzcyBScGNDbGllbnQgewogICAgcHJlcGFyZShpbml0KSB7CiAgICAgICAgcmV0dXJuIG5ldyBScGNSZXF1ZXN0KHRoaXMuaWQrKywgaW5pdC5tZXRob2QsIGluaXQucGFyYW1zKTsKICAgIH0KICAgIGNvbnN0cnVjdG9yKCl7CiAgICAgICAgdGhpcy5pZCA9IDA7CiAgICB9Cn0KdmFyIFRvclJwYzsKKGZ1bmN0aW9uKFRvclJwYykgewogICAgYXN5bmMgZnVuY3Rpb24gdHJ5RmV0Y2hXaXRoQ2lyY3VpdChpbnB1dCwgaW5pdCkgewogICAgICAgIGNvbnN0IHsgaWQsIG1ldGhvZCwgcGFyYW1zLCBjaXJjdWl0LCAuLi5yZXN0IH0gPSBpbml0OwogICAgICAgIGNvbnN0IHJlcXVlc3QgPSBuZXcgUnBjUmVxdWVzdChpZCwgbWV0aG9kLCBwYXJhbXMpOwogICAgICAgIGNvbnN0IGJvZHkgPSBCeXRlcy5mcm9tVXRmOChKU09OLnN0cmluZ2lmeShyZXF1ZXN0KSk7CiAgICAgICAgY29uc3QgaGVhZGVycyA9IG5ldyBIZWFkZXJzKHJlc3QuaGVhZGVycyk7CiAgICAgICAgaGVhZGVycy5zZXQoIkNvbnRlbnQtVHlwZSIsICJhcHBsaWNhdGlvbi9qc29uIik7CiAgICAgICAgaGVhZGVycy5zZXQoIkNvbnRlbnQtTGVuZ3RoIiwgIiIuY29uY2F0KGJvZHkubGVuZ3RoKSk7CiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgY2lyY3VpdC50cnlGZXRjaChpbnB1dCwgewogICAgICAgICAgICAuLi5yZXN0LAogICAgICAgICAgICBtZXRob2Q6ICJQT1NUIiwKICAgICAgICAgICAgaGVhZGVycywKICAgICAgICAgICAgYm9keQogICAgICAgIH0pOwogICAgICAgIGlmICghcmVzLmlzT2soKSkgcmV0dXJuIHJlczsKICAgICAgICBpZiAoIXJlcy5pbm5lci5vaykgcmV0dXJuIG5ldyBFcnIobmV3IEVycm9yKGF3YWl0IHJlcy5pbm5lci50ZXh0KCkpKTsKICAgICAgICBjb25zdCByZXNwb25zZSA9IFJwY1Jlc3BvbnNlLmZyb20oYXdhaXQgcmVzLmlubmVyLmpzb24oKSk7CiAgICAgICAgaWYgKHJlc3BvbnNlLmlkICE9PSByZXF1ZXN0LmlkKSBjb25zb2xlLndhcm4oIkludmFsaWQgcmVzcG9uc2UgSUQiLCByZXNwb25zZS5pZCwgImV4cGVjdGVkIiwgcmVxdWVzdC5pZCk7CiAgICAgICAgcmV0dXJuIG5ldyBPayhyZXNwb25zZSk7CiAgICB9CiAgICBUb3JScGMudHJ5RmV0Y2hXaXRoQ2lyY3VpdCA9IHRyeUZldGNoV2l0aENpcmN1aXQ7CiAgICBhc3luYyBmdW5jdGlvbiB0cnlGZXRjaFdpdGhTb2NrZXQoc29ja2V0LCByZXF1ZXN0LCBzaWduYWwpIHsKICAgICAgICBjb25zdCB7IGlkLCBtZXRob2QsIHBhcmFtcyA9IFtdIH0gPSByZXF1ZXN0OwogICAgICAgIHNvY2tldC5zZW5kKEpTT04uc3RyaW5naWZ5KG5ldyBScGNSZXF1ZXN0KGlkLCBtZXRob2QsIHBhcmFtcykpKTsKICAgICAgICBjb25zdCBmdXR1cmUgPSBuZXcgRnV0dXJlKCk7CiAgICAgICAgY29uc3Qgb25NZXNzYWdlID0gYXN5bmMgKGV2ZW50KT0+ewogICAgICAgICAgICBpZiAodHlwZW9mIGV2ZW50LmRhdGEgIT09ICJzdHJpbmciKSByZXR1cm47CiAgICAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gUnBjUmVzcG9uc2UuZnJvbShKU09OLnBhcnNlKGV2ZW50LmRhdGEpKTsKICAgICAgICAgICAgaWYgKHJlc3BvbnNlLmlkICE9PSByZXF1ZXN0LmlkKSByZXR1cm47CiAgICAgICAgICAgIGZ1dHVyZS5yZXNvbHZlKG5ldyBPayhyZXNwb25zZSkpOwogICAgICAgIH07CiAgICAgICAgY29uc3Qgb25FcnJvciA9IChlKT0+ewogICAgICAgICAgICBmdXR1cmUucmVzb2x2ZShuZXcgRXJyKEVycm9yZWRFcnJvci5mcm9tKGUpKSk7CiAgICAgICAgfTsKICAgICAgICBjb25zdCBvbkNsb3NlID0gKGUpPT57CiAgICAgICAgICAgIGZ1dHVyZS5yZXNvbHZlKG5ldyBFcnIoQ2xvc2VkRXJyb3IuZnJvbShlKSkpOwogICAgICAgIH07CiAgICAgICAgY29uc3Qgb25BYm9ydCA9ICgpPT57CiAgICAgICAgICAgIGZ1dHVyZS5yZXNvbHZlKG5ldyBFcnIoQWJvcnRlZEVycm9yLmZyb20oc2lnbmFsLnJlYXNvbikpKTsKICAgICAgICB9OwogICAgICAgIHRyeSB7CiAgICAgICAgICAgIHNvY2tldC5hZGRFdmVudExpc3RlbmVyKCJtZXNzYWdlIiwgb25NZXNzYWdlLCB7CiAgICAgICAgICAgICAgICBwYXNzaXZlOiB0cnVlCiAgICAgICAgICAgIH0pOwogICAgICAgICAgICBzb2NrZXQuYWRkRXZlbnRMaXN0ZW5lcigiY2xvc2UiLCBvbkNsb3NlLCB7CiAgICAgICAgICAgICAgICBwYXNzaXZlOiB0cnVlCiAgICAgICAgICAgIH0pOwogICAgICAgICAgICBzb2NrZXQuYWRkRXZlbnRMaXN0ZW5lcigiZXJyb3IiLCBvbkVycm9yLCB7CiAgICAgICAgICAgICAgICBwYXNzaXZlOiB0cnVlCiAgICAgICAgICAgIH0pOwogICAgICAgICAgICBzaWduYWwuYWRkRXZlbnRMaXN0ZW5lcigiYWJvcnQiLCBvbkFib3J0LCB7CiAgICAgICAgICAgICAgICBwYXNzaXZlOiB0cnVlCiAgICAgICAgICAgIH0pOwogICAgICAgICAgICByZXR1cm4gYXdhaXQgZnV0dXJlLnByb21pc2U7CiAgICAgICAgfSBmaW5hbGx5ewogICAgICAgICAgICBzb2NrZXQucmVtb3ZlRXZlbnRMaXN0ZW5lcigibWVzc2FnZSIsIG9uTWVzc2FnZSk7CiAgICAgICAgICAgIHNvY2tldC5yZW1vdmVFdmVudExpc3RlbmVyKCJjbG9zZSIsIG9uQ2xvc2UpOwogICAgICAgICAgICBzb2NrZXQucmVtb3ZlRXZlbnRMaXN0ZW5lcigiZXJyb3IiLCBvbkVycm9yKTsKICAgICAgICAgICAgc2lnbmFsLnJlbW92ZUV2ZW50TGlzdGVuZXIoImFib3J0Iiwgb25BYm9ydCk7CiAgICAgICAgfQogICAgfQogICAgVG9yUnBjLnRyeUZldGNoV2l0aFNvY2tldCA9IHRyeUZldGNoV2l0aFNvY2tldDsKfSkoVG9yUnBjIHx8IChUb3JScGMgPSB7fSkpOwoKOy8vIENPTkNBVEVOQVRFRCBNT0RVTEU6IC4vc3JjL2xpYnMvcnBjL2luZGV4LnRzCgoKCgoKCjsvLyBDT05DQVRFTkFURUQgTU9EVUxFOiAuL3NyYy9tb2RzL2JhY2tncm91bmQvaW5qZWN0ZWRfc2NyaXB0L2luZGV4LnRzCgoKCmNsYXNzIFByb3ZpZGVyIHsKICAgIGdldCBpc0JydW1lKCkgewogICAgICAgIHJldHVybiB0cnVlOwogICAgfQogICAgaXNDb25uZWN0ZWQoKSB7CiAgICAgICAgcmV0dXJuIHRydWU7CiAgICB9CiAgICBhc3luYyB0cnlSZXF1ZXN0KGluaXQpIHsKICAgICAgICBjb25zdCByZXF1ZXN0ID0gdGhpcy5jbGllbnQucHJlcGFyZShpbml0KTsKICAgICAgICBjb25zdCBmdXR1cmUgPSBuZXcgRnV0dXJlKCk7CiAgICAgICAgY29uc3Qgb25SZXNwb25zZSA9IChlKT0+ewogICAgICAgICAgICBjb25zdCBpbml0ID0gSlNPTi5wYXJzZShlLmRldGFpbCk7CiAgICAgICAgICAgIGlmIChpbml0LmlkICE9PSByZXF1ZXN0LmlkKSByZXR1cm47CiAgICAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gUnBjUmVzcG9uc2UuZnJvbShpbml0KTsKICAgICAgICAgICAgZnV0dXJlLnJlc29sdmUocmVzcG9uc2UpOwogICAgICAgIH07CiAgICAgICAgdHJ5IHsKICAgICAgICAgICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoImV0aGVyZXVtI3Jlc3BvbnNlIiwgb25SZXNwb25zZSk7CiAgICAgICAgICAgIGNvbnN0IGRldGFpbCA9IEpTT04uc3RyaW5naWZ5KHJlcXVlc3QpOwogICAgICAgICAgICBjb25zdCBldmVudCA9IG5ldyBDdXN0b21FdmVudCgiZXRoZXJldW0jcmVxdWVzdCIsIHsKICAgICAgICAgICAgICAgIGRldGFpbAogICAgICAgICAgICB9KTsKICAgICAgICAgICAgd2luZG93LmRpc3BhdGNoRXZlbnQoZXZlbnQpOwogICAgICAgICAgICByZXR1cm4gYXdhaXQgZnV0dXJlLnByb21pc2U7CiAgICAgICAgfSBmaW5hbGx5ewogICAgICAgICAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcigiZXRoZXJldW0jcmVzcG9uc2UiLCBvblJlc3BvbnNlKTsKICAgICAgICB9CiAgICB9CiAgICBhc3luYyByZXF1ZXN0KGluaXQpIHsKICAgICAgICByZXR1cm4gYXdhaXQgdGhpcy50cnlSZXF1ZXN0KGluaXQpLnRoZW4oKHIpPT5yLnVud3JhcCgpKTsKICAgIH0KICAgIG9uKGtleSwgc3VibGlzdGVuZXIpIHsKICAgICAgICBsZXQgbGlzdGVuZXJzID0gdGhpcy5saXN0ZW5lcnMuZ2V0KGtleSk7CiAgICAgICAgaWYgKGxpc3RlbmVycyA9PSBudWxsKSB7CiAgICAgICAgICAgIGxpc3RlbmVycyA9IG5ldyBNYXAoKTsKICAgICAgICAgICAgdGhpcy5saXN0ZW5lcnMuc2V0KGtleSwgbGlzdGVuZXJzKTsKICAgICAgICB9CiAgICAgICAgbGV0IHN1cGxpc3RlbmVyID0gbGlzdGVuZXJzLmdldChzdWJsaXN0ZW5lcik7CiAgICAgICAgaWYgKHN1cGxpc3RlbmVyID09IG51bGwpIHsKICAgICAgICAgICAgc3VwbGlzdGVuZXIgPSAoZSk9PnZvaWQgc3VibGlzdGVuZXIoSlNPTi5wYXJzZShlLmRldGFpbCkpOwogICAgICAgICAgICBsaXN0ZW5lcnMuc2V0KHN1Ymxpc3RlbmVyLCBzdXBsaXN0ZW5lcik7CiAgICAgICAgfQogICAgICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCJldGhlcmV1bSMiLmNvbmNhdChrZXkpLCBzdXBsaXN0ZW5lciwgewogICAgICAgICAgICBwYXNzaXZlOiB0cnVlCiAgICAgICAgfSk7CiAgICB9CiAgICBvZmYoa2V5LCBzdWJsaXN0ZW5lcikgewogICAgICAgIGNvbnN0IGxpc3RlbmVycyA9IHRoaXMubGlzdGVuZXJzLmdldChrZXkpOwogICAgICAgIGlmIChsaXN0ZW5lcnMgPT0gbnVsbCkgcmV0dXJuOwogICAgICAgIGNvbnN0IHN1cGxpc3RlbmVyID0gbGlzdGVuZXJzLmdldChzdWJsaXN0ZW5lcik7CiAgICAgICAgaWYgKHN1cGxpc3RlbmVyID09IG51bGwpIHJldHVybjsKICAgICAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcigiZXRoZXJldW0jIi5jb25jYXQoa2V5KSwgc3VwbGlzdGVuZXIpOwogICAgICAgIGxpc3RlbmVycy5kZWxldGUoc3VibGlzdGVuZXIpOwogICAgICAgIGlmIChsaXN0ZW5lcnMuc2l6ZSAhPT0gMCkgcmV0dXJuOwogICAgICAgIHRoaXMubGlzdGVuZXJzLmRlbGV0ZShrZXkpOwogICAgfQogICAgY29uc3RydWN0b3IoKXsKICAgICAgICB0aGlzLmNsaWVudCA9IG5ldyBScGNDbGllbnQoKTsKICAgICAgICB0aGlzLmxpc3RlbmVycyA9IG5ldyBNYXAoKTsKICAgIH0KfQpjb25zdCBwcm92aWRlciA9IG5ldyBQcm92aWRlcigpOwp3aW5kb3cuZXRoZXJldW0gPSBwcm92aWRlcjsKCn0pKCk7CgovKioqKioqLyB9KSgpCjs=");
    const scriptUrl = browser.runtime.getURL("injected_script.js");
    const element = document.createElement("script");
    element.type = "text/javascript";
    element.textContent = "".concat(scriptBody, "\n//# sourceURL=").concat(scriptUrl);
    container.insertBefore(element, container.children[0]);
    container.removeChild(element);
}
async function tryGetOrigin() {
    const origin = {
        origin: location.origin,
        title: document.title
    };
    for (const meta of document.getElementsByTagName("meta")){
        if (meta.name === "application-name") {
            origin.title = meta.content;
            continue;
        }
    }
    for (const link of document.getElementsByTagName("link")){
        if ([
            "icon",
            "shortcut icon",
            "icon shortcut"
        ].includes(link.rel)) {
            const blob = await tryFetchAsBlob(link.href);
            if (blob.isErr()) continue;
            const data = await Blobs.tryReadAsDataURL(blob.inner);
            if (data.isErr()) continue;
            origin.icon = data.inner;
            continue;
        }
        if (link.rel === "manifest") {
            const manifest = await tryFetchAsJson(link.href);
            if (manifest.isErr()) continue;
            if (manifest.inner.name) origin.title = manifest.inner.name;
            if (manifest.inner.short_name) origin.title = manifest.inner.short_name;
            if (manifest.inner.description) origin.description = manifest.inner.description;
            continue;
        }
    }
    if (!origin.icon) {
        await (async ()=>{
            const blob = await tryFetchAsBlob("/favicon.ico");
            if (blob.isErr()) return;
            const data = await Blobs.tryReadAsDataURL(blob.inner);
            if (data.isErr()) return;
            origin.icon = data.inner;
        })();
    }
    return new ok_Ok(origin);
}
new Pool(async (params)=>{
    return Result.unthrow(async (t)=>{
        const { index, pool } = params;
        await new Promise((ok)=>setTimeout(ok, 1));
        const raw = await tryBrowser(async ()=>{
            const port = browser.runtime.connect({
                name: location.origin
            });
            port.onDisconnect.addListener(()=>void chrome.runtime.lastError);
            return port;
        }).then((r)=>r.throw(t));
        const port = new ExtensionPort("background", raw);
        const onScriptRequest = async (input)=>{
            const request = JSON.parse(input.detail);
            const result = await port.tryRequest({
                method: "brume_run",
                params: [
                    request,
                    mouse
                ]
            });
            const response = RpcResponse.rewrap(request.id, result.andThenSync((r)=>r));
            const detail = JSON.stringify(response);
            const output = new CustomEvent("ethereum#response", {
                detail
            });
            window.dispatchEvent(output);
        };
        window.addEventListener("ethereum#request", onScriptRequest, {
            passive: true
        });
        const onAccountsChanged = async (request)=>{
            const [accounts] = request.params;
            const detail = JSON.stringify(accounts);
            const output = new CustomEvent("ethereum#accountsChanged", {
                detail
            });
            window.dispatchEvent(output);
            return ok_Ok.void();
        };
        const onChainChanged = async (request)=>{
            const [chainId] = request.params;
            const detail = JSON.stringify(chainId);
            const output = new CustomEvent("ethereum#chainChanged", {
                detail
            });
            window.dispatchEvent(output);
            return ok_Ok.void();
        };
        const onBackgroundRequest = async (request)=>{
            if (request.method === "brume_origin") return new Some(await tryGetOrigin());
            if (request.method === "accountsChanged") return new Some(await onAccountsChanged(request));
            if (request.method === "chainChanged") return new Some(await onChainChanged(request));
            return new None();
        };
        port.events.on("request", onBackgroundRequest, {
            passive: true
        });
        const onClose = async ()=>{
            const output = new CustomEvent("ethereum#disconnect", {});
            window.dispatchEvent(output);
            await pool.restart(index);
            return new None();
        };
        port.events.on("close", onClose, {
            passive: true
        });
        const output = new CustomEvent("ethereum#connect", {});
        window.dispatchEvent(output);
        const onClean = ()=>{
            window.removeEventListener("ethereum#request", onScriptRequest);
            port.events.off("close", onClose);
            port.clean();
            raw.disconnect();
        };
        return new ok_Ok(new Disposer(raw, onClean));
    });
}, {
    capacity: 1
});

})();

/******/ })()
;