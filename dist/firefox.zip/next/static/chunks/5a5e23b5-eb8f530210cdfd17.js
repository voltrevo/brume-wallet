"use strict";
(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[570],{

/***/ 5790:
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   R4: function() { return /* binding */ AbiInt256; },
/* harmony export */   t1: function() { return /* binding */ intByName; }
/* harmony export */ });
/* unused harmony exports AbiInt104, AbiInt112, AbiInt120, AbiInt128, AbiInt136, AbiInt144, AbiInt152, AbiInt16, AbiInt160, AbiInt168, AbiInt176, AbiInt184, AbiInt192, AbiInt200, AbiInt208, AbiInt216, AbiInt224, AbiInt232, AbiInt24, AbiInt240, AbiInt248, AbiInt256, AbiInt32, AbiInt40, AbiInt48, AbiInt56, AbiInt64, AbiInt72, AbiInt8, AbiInt80, AbiInt88, AbiInt96, BytesAbiInt104, BytesAbiInt112, BytesAbiInt120, BytesAbiInt128, BytesAbiInt136, BytesAbiInt144, BytesAbiInt152, BytesAbiInt16, BytesAbiInt160, BytesAbiInt168, BytesAbiInt176, BytesAbiInt184, BytesAbiInt192, BytesAbiInt200, BytesAbiInt208, BytesAbiInt216, BytesAbiInt224, BytesAbiInt232, BytesAbiInt24, BytesAbiInt240, BytesAbiInt248, BytesAbiInt256, BytesAbiInt32, BytesAbiInt40, BytesAbiInt48, BytesAbiInt56, BytesAbiInt64, BytesAbiInt72, BytesAbiInt8, BytesAbiInt80, BytesAbiInt88, BytesAbiInt96, Int104, Int112, Int120, Int128, Int136, Int144, Int152, Int16, Int160, Int168, Int176, Int184, Int192, Int200, Int208, Int216, Int224, Int232, Int24, Int240, Int248, Int32, Int40, Int48, Int56, Int64, Int72, Int8, Int80, Int88, Int96, ZeroHexAbiInt104, ZeroHexAbiInt112, ZeroHexAbiInt120, ZeroHexAbiInt128, ZeroHexAbiInt136, ZeroHexAbiInt144, ZeroHexAbiInt152, ZeroHexAbiInt16, ZeroHexAbiInt160, ZeroHexAbiInt168, ZeroHexAbiInt176, ZeroHexAbiInt184, ZeroHexAbiInt192, ZeroHexAbiInt200, ZeroHexAbiInt208, ZeroHexAbiInt216, ZeroHexAbiInt224, ZeroHexAbiInt232, ZeroHexAbiInt24, ZeroHexAbiInt240, ZeroHexAbiInt248, ZeroHexAbiInt256, ZeroHexAbiInt32, ZeroHexAbiInt40, ZeroHexAbiInt48, ZeroHexAbiInt56, ZeroHexAbiInt64, ZeroHexAbiInt72, ZeroHexAbiInt8, ZeroHexAbiInt80, ZeroHexAbiInt88, ZeroHexAbiInt96 */
/* harmony import */ var _node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1305);
/* harmony import */ var _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2248);
/* harmony import */ var _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1694);
/* harmony import */ var _libs_bigint_bigint_mjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3168);





var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _0, _1, _2, _3, _4, _5, _6, _7, _8, _9, _10, _11, _12, _13, _14, _15, _16, _17, _18, _19, _20, _21, _22, _23, _24, _25, _26, _27, _28, _29, _30, _31, _32, _33, _34, _35, _36, _37, _38, _39;
const BN_0 = 0n;
const BN_1 = 1n;
var AbiInt8;
(function (AbiInt8) {
    AbiInt8.dynamic = false;
    AbiInt8.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiInt8.create(value);
        return ZeroHexAbiInt8.create(value);
    }
    AbiInt8.create = create;
    function from(value) {
        return AbiInt8.create(value);
    }
    AbiInt8.from = from;
    function codegen() {
        return `Abi.Int8`;
    }
    AbiInt8.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiInt8.decodeOrThrow(cursor);
    }
    AbiInt8.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiInt8.readOrThrow(cursor);
    }
    AbiInt8.readOrThrow = readOrThrow;
})(AbiInt8 || (AbiInt8 = {}));
class BytesAbiInt8 {
    value;
    #class = _a;
    name = this.#class.name;
    static bytes = 1;
    static nibbles = 2;
    static bits = 8;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _a(value);
    }
    static from(value) {
        return _a.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiInt8(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiInt8(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int8`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _a.nibbles;
        const content = cursor.readOrThrow(_a.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _a(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - _a.bytes);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _a.bytes;
        const content = cursor.readOrThrow(_a.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _a(value);
    }
}
_a = BytesAbiInt8;
class ZeroHexAbiInt8 {
    value;
    #class = _b;
    name = this.#class.name;
    static bytes = 1;
    static nibbles = 2;
    static bits = 8;
    static bitsn = BigInt(8);
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    bitsn = this.#class.bitsn;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return _b.fromBigInt(BigInt(value));
    }
    static fromBigInt(value) {
        if (value >= BN_0)
            return new _b(value.toString(16));
        const mask = (BN_1 << 256n) - BN_1;
        const value2 = ((~(-value)) & mask) + BN_1;
        return new _b(value2.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _b.fromBigInt(value);
        if (typeof value === "number")
            return _b.fromNumber(value);
        if (value.startsWith("0x"))
            return new _b(value.slice(2));
        return _b.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _b.create(value);
    }
    intoOrThrow() {
        const mask = (BN_1 << this.bitsn) - BN_1;
        const value = _libs_bigint_bigint_mjs__WEBPACK_IMPORTED_MODULE_2__/* .BigInts */ .l.decodeRaw(this.value);
        if ((value & mask) >> (this.bitsn - BN_1))
            return -(((~value) & mask) + BN_1);
        return value;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int8`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        return new _b(cursor.readOrThrow(64));
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_1 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__addDisposableResource */ .b)(env_1, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_1) {
            env_1.error = e_1;
            env_1.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__disposeResources */ .f)(env_1);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _b.bytes;
        const content = cursor.readOrThrow(_b.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _b(value);
    }
}
_b = ZeroHexAbiInt8;
var AbiInt16;
(function (AbiInt16) {
    AbiInt16.dynamic = false;
    AbiInt16.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiInt16.create(value);
        return ZeroHexAbiInt16.create(value);
    }
    AbiInt16.create = create;
    function from(value) {
        return AbiInt16.create(value);
    }
    AbiInt16.from = from;
    function codegen() {
        return `Abi.Int16`;
    }
    AbiInt16.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiInt16.decodeOrThrow(cursor);
    }
    AbiInt16.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiInt16.readOrThrow(cursor);
    }
    AbiInt16.readOrThrow = readOrThrow;
})(AbiInt16 || (AbiInt16 = {}));
class BytesAbiInt16 {
    value;
    #class = _c;
    name = this.#class.name;
    static bytes = 2;
    static nibbles = 4;
    static bits = 16;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _c(value);
    }
    static from(value) {
        return _c.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiInt16(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiInt16(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int16`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _c.nibbles;
        const content = cursor.readOrThrow(_c.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _c(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - _c.bytes);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _c.bytes;
        const content = cursor.readOrThrow(_c.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _c(value);
    }
}
_c = BytesAbiInt16;
class ZeroHexAbiInt16 {
    value;
    #class = _d;
    name = this.#class.name;
    static bytes = 2;
    static nibbles = 4;
    static bits = 16;
    static bitsn = BigInt(16);
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    bitsn = this.#class.bitsn;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return _d.fromBigInt(BigInt(value));
    }
    static fromBigInt(value) {
        if (value >= BN_0)
            return new _d(value.toString(16));
        const mask = (BN_1 << 256n) - BN_1;
        const value2 = ((~(-value)) & mask) + BN_1;
        return new _d(value2.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _d.fromBigInt(value);
        if (typeof value === "number")
            return _d.fromNumber(value);
        if (value.startsWith("0x"))
            return new _d(value.slice(2));
        return _d.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _d.create(value);
    }
    intoOrThrow() {
        const mask = (BN_1 << this.bitsn) - BN_1;
        const value = _libs_bigint_bigint_mjs__WEBPACK_IMPORTED_MODULE_2__/* .BigInts */ .l.decodeRaw(this.value);
        if ((value & mask) >> (this.bitsn - BN_1))
            return -(((~value) & mask) + BN_1);
        return value;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int16`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        return new _d(cursor.readOrThrow(64));
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_2 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__addDisposableResource */ .b)(env_2, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_2) {
            env_2.error = e_2;
            env_2.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__disposeResources */ .f)(env_2);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _d.bytes;
        const content = cursor.readOrThrow(_d.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _d(value);
    }
}
_d = ZeroHexAbiInt16;
var AbiInt24;
(function (AbiInt24) {
    AbiInt24.dynamic = false;
    AbiInt24.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiInt24.create(value);
        return ZeroHexAbiInt24.create(value);
    }
    AbiInt24.create = create;
    function from(value) {
        return AbiInt24.create(value);
    }
    AbiInt24.from = from;
    function codegen() {
        return `Abi.Int24`;
    }
    AbiInt24.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiInt24.decodeOrThrow(cursor);
    }
    AbiInt24.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiInt24.readOrThrow(cursor);
    }
    AbiInt24.readOrThrow = readOrThrow;
})(AbiInt24 || (AbiInt24 = {}));
class BytesAbiInt24 {
    value;
    #class = _e;
    name = this.#class.name;
    static bytes = 3;
    static nibbles = 6;
    static bits = 24;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _e(value);
    }
    static from(value) {
        return _e.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiInt24(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiInt24(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int24`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _e.nibbles;
        const content = cursor.readOrThrow(_e.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _e(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - _e.bytes);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _e.bytes;
        const content = cursor.readOrThrow(_e.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _e(value);
    }
}
_e = BytesAbiInt24;
class ZeroHexAbiInt24 {
    value;
    #class = _f;
    name = this.#class.name;
    static bytes = 3;
    static nibbles = 6;
    static bits = 24;
    static bitsn = BigInt(24);
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    bitsn = this.#class.bitsn;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return _f.fromBigInt(BigInt(value));
    }
    static fromBigInt(value) {
        if (value >= BN_0)
            return new _f(value.toString(16));
        const mask = (BN_1 << 256n) - BN_1;
        const value2 = ((~(-value)) & mask) + BN_1;
        return new _f(value2.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _f.fromBigInt(value);
        if (typeof value === "number")
            return _f.fromNumber(value);
        if (value.startsWith("0x"))
            return new _f(value.slice(2));
        return _f.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _f.create(value);
    }
    intoOrThrow() {
        const mask = (BN_1 << this.bitsn) - BN_1;
        const value = _libs_bigint_bigint_mjs__WEBPACK_IMPORTED_MODULE_2__/* .BigInts */ .l.decodeRaw(this.value);
        if ((value & mask) >> (this.bitsn - BN_1))
            return -(((~value) & mask) + BN_1);
        return value;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int24`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        return new _f(cursor.readOrThrow(64));
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_3 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__addDisposableResource */ .b)(env_3, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_3) {
            env_3.error = e_3;
            env_3.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__disposeResources */ .f)(env_3);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _f.bytes;
        const content = cursor.readOrThrow(_f.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _f(value);
    }
}
_f = ZeroHexAbiInt24;
var AbiInt32;
(function (AbiInt32) {
    AbiInt32.dynamic = false;
    AbiInt32.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiInt32.create(value);
        return ZeroHexAbiInt32.create(value);
    }
    AbiInt32.create = create;
    function from(value) {
        return AbiInt32.create(value);
    }
    AbiInt32.from = from;
    function codegen() {
        return `Abi.Int32`;
    }
    AbiInt32.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiInt32.decodeOrThrow(cursor);
    }
    AbiInt32.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiInt32.readOrThrow(cursor);
    }
    AbiInt32.readOrThrow = readOrThrow;
})(AbiInt32 || (AbiInt32 = {}));
class BytesAbiInt32 {
    value;
    #class = _g;
    name = this.#class.name;
    static bytes = 4;
    static nibbles = 8;
    static bits = 32;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _g(value);
    }
    static from(value) {
        return _g.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiInt32(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiInt32(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int32`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _g.nibbles;
        const content = cursor.readOrThrow(_g.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _g(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - _g.bytes);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _g.bytes;
        const content = cursor.readOrThrow(_g.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _g(value);
    }
}
_g = BytesAbiInt32;
class ZeroHexAbiInt32 {
    value;
    #class = _h;
    name = this.#class.name;
    static bytes = 4;
    static nibbles = 8;
    static bits = 32;
    static bitsn = BigInt(32);
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    bitsn = this.#class.bitsn;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return _h.fromBigInt(BigInt(value));
    }
    static fromBigInt(value) {
        if (value >= BN_0)
            return new _h(value.toString(16));
        const mask = (BN_1 << 256n) - BN_1;
        const value2 = ((~(-value)) & mask) + BN_1;
        return new _h(value2.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _h.fromBigInt(value);
        if (typeof value === "number")
            return _h.fromNumber(value);
        if (value.startsWith("0x"))
            return new _h(value.slice(2));
        return _h.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _h.create(value);
    }
    intoOrThrow() {
        const mask = (BN_1 << this.bitsn) - BN_1;
        const value = _libs_bigint_bigint_mjs__WEBPACK_IMPORTED_MODULE_2__/* .BigInts */ .l.decodeRaw(this.value);
        if ((value & mask) >> (this.bitsn - BN_1))
            return -(((~value) & mask) + BN_1);
        return value;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int32`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        return new _h(cursor.readOrThrow(64));
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_4 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__addDisposableResource */ .b)(env_4, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_4) {
            env_4.error = e_4;
            env_4.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__disposeResources */ .f)(env_4);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _h.bytes;
        const content = cursor.readOrThrow(_h.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _h(value);
    }
}
_h = ZeroHexAbiInt32;
var AbiInt40;
(function (AbiInt40) {
    AbiInt40.dynamic = false;
    AbiInt40.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiInt40.create(value);
        return ZeroHexAbiInt40.create(value);
    }
    AbiInt40.create = create;
    function from(value) {
        return AbiInt40.create(value);
    }
    AbiInt40.from = from;
    function codegen() {
        return `Abi.Int40`;
    }
    AbiInt40.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiInt40.decodeOrThrow(cursor);
    }
    AbiInt40.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiInt40.readOrThrow(cursor);
    }
    AbiInt40.readOrThrow = readOrThrow;
})(AbiInt40 || (AbiInt40 = {}));
class BytesAbiInt40 {
    value;
    #class = _j;
    name = this.#class.name;
    static bytes = 5;
    static nibbles = 10;
    static bits = 40;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _j(value);
    }
    static from(value) {
        return _j.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiInt40(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiInt40(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int40`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _j.nibbles;
        const content = cursor.readOrThrow(_j.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _j(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - _j.bytes);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _j.bytes;
        const content = cursor.readOrThrow(_j.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _j(value);
    }
}
_j = BytesAbiInt40;
class ZeroHexAbiInt40 {
    value;
    #class = _k;
    name = this.#class.name;
    static bytes = 5;
    static nibbles = 10;
    static bits = 40;
    static bitsn = BigInt(40);
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    bitsn = this.#class.bitsn;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return _k.fromBigInt(BigInt(value));
    }
    static fromBigInt(value) {
        if (value >= BN_0)
            return new _k(value.toString(16));
        const mask = (BN_1 << 256n) - BN_1;
        const value2 = ((~(-value)) & mask) + BN_1;
        return new _k(value2.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _k.fromBigInt(value);
        if (typeof value === "number")
            return _k.fromNumber(value);
        if (value.startsWith("0x"))
            return new _k(value.slice(2));
        return _k.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _k.create(value);
    }
    intoOrThrow() {
        const mask = (BN_1 << this.bitsn) - BN_1;
        const value = _libs_bigint_bigint_mjs__WEBPACK_IMPORTED_MODULE_2__/* .BigInts */ .l.decodeRaw(this.value);
        if ((value & mask) >> (this.bitsn - BN_1))
            return -(((~value) & mask) + BN_1);
        return value;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int40`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        return new _k(cursor.readOrThrow(64));
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_5 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__addDisposableResource */ .b)(env_5, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_5) {
            env_5.error = e_5;
            env_5.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__disposeResources */ .f)(env_5);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _k.bytes;
        const content = cursor.readOrThrow(_k.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _k(value);
    }
}
_k = ZeroHexAbiInt40;
var AbiInt48;
(function (AbiInt48) {
    AbiInt48.dynamic = false;
    AbiInt48.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiInt48.create(value);
        return ZeroHexAbiInt48.create(value);
    }
    AbiInt48.create = create;
    function from(value) {
        return AbiInt48.create(value);
    }
    AbiInt48.from = from;
    function codegen() {
        return `Abi.Int48`;
    }
    AbiInt48.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiInt48.decodeOrThrow(cursor);
    }
    AbiInt48.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiInt48.readOrThrow(cursor);
    }
    AbiInt48.readOrThrow = readOrThrow;
})(AbiInt48 || (AbiInt48 = {}));
class BytesAbiInt48 {
    value;
    #class = _l;
    name = this.#class.name;
    static bytes = 6;
    static nibbles = 12;
    static bits = 48;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _l(value);
    }
    static from(value) {
        return _l.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiInt48(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiInt48(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int48`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _l.nibbles;
        const content = cursor.readOrThrow(_l.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _l(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - _l.bytes);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _l.bytes;
        const content = cursor.readOrThrow(_l.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _l(value);
    }
}
_l = BytesAbiInt48;
class ZeroHexAbiInt48 {
    value;
    #class = _m;
    name = this.#class.name;
    static bytes = 6;
    static nibbles = 12;
    static bits = 48;
    static bitsn = BigInt(48);
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    bitsn = this.#class.bitsn;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return _m.fromBigInt(BigInt(value));
    }
    static fromBigInt(value) {
        if (value >= BN_0)
            return new _m(value.toString(16));
        const mask = (BN_1 << 256n) - BN_1;
        const value2 = ((~(-value)) & mask) + BN_1;
        return new _m(value2.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _m.fromBigInt(value);
        if (typeof value === "number")
            return _m.fromNumber(value);
        if (value.startsWith("0x"))
            return new _m(value.slice(2));
        return _m.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _m.create(value);
    }
    intoOrThrow() {
        const mask = (BN_1 << this.bitsn) - BN_1;
        const value = _libs_bigint_bigint_mjs__WEBPACK_IMPORTED_MODULE_2__/* .BigInts */ .l.decodeRaw(this.value);
        if ((value & mask) >> (this.bitsn - BN_1))
            return -(((~value) & mask) + BN_1);
        return value;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int48`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        return new _m(cursor.readOrThrow(64));
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_6 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__addDisposableResource */ .b)(env_6, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_6) {
            env_6.error = e_6;
            env_6.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__disposeResources */ .f)(env_6);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _m.bytes;
        const content = cursor.readOrThrow(_m.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _m(value);
    }
}
_m = ZeroHexAbiInt48;
var AbiInt56;
(function (AbiInt56) {
    AbiInt56.dynamic = false;
    AbiInt56.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiInt56.create(value);
        return ZeroHexAbiInt56.create(value);
    }
    AbiInt56.create = create;
    function from(value) {
        return AbiInt56.create(value);
    }
    AbiInt56.from = from;
    function codegen() {
        return `Abi.Int56`;
    }
    AbiInt56.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiInt56.decodeOrThrow(cursor);
    }
    AbiInt56.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiInt56.readOrThrow(cursor);
    }
    AbiInt56.readOrThrow = readOrThrow;
})(AbiInt56 || (AbiInt56 = {}));
class BytesAbiInt56 {
    value;
    #class = _o;
    name = this.#class.name;
    static bytes = 7;
    static nibbles = 14;
    static bits = 56;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _o(value);
    }
    static from(value) {
        return _o.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiInt56(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiInt56(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int56`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _o.nibbles;
        const content = cursor.readOrThrow(_o.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _o(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - _o.bytes);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _o.bytes;
        const content = cursor.readOrThrow(_o.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _o(value);
    }
}
_o = BytesAbiInt56;
class ZeroHexAbiInt56 {
    value;
    #class = _p;
    name = this.#class.name;
    static bytes = 7;
    static nibbles = 14;
    static bits = 56;
    static bitsn = BigInt(56);
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    bitsn = this.#class.bitsn;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return _p.fromBigInt(BigInt(value));
    }
    static fromBigInt(value) {
        if (value >= BN_0)
            return new _p(value.toString(16));
        const mask = (BN_1 << 256n) - BN_1;
        const value2 = ((~(-value)) & mask) + BN_1;
        return new _p(value2.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _p.fromBigInt(value);
        if (typeof value === "number")
            return _p.fromNumber(value);
        if (value.startsWith("0x"))
            return new _p(value.slice(2));
        return _p.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _p.create(value);
    }
    intoOrThrow() {
        const mask = (BN_1 << this.bitsn) - BN_1;
        const value = _libs_bigint_bigint_mjs__WEBPACK_IMPORTED_MODULE_2__/* .BigInts */ .l.decodeRaw(this.value);
        if ((value & mask) >> (this.bitsn - BN_1))
            return -(((~value) & mask) + BN_1);
        return value;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int56`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        return new _p(cursor.readOrThrow(64));
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_7 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__addDisposableResource */ .b)(env_7, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_7) {
            env_7.error = e_7;
            env_7.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__disposeResources */ .f)(env_7);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _p.bytes;
        const content = cursor.readOrThrow(_p.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _p(value);
    }
}
_p = ZeroHexAbiInt56;
var AbiInt64;
(function (AbiInt64) {
    AbiInt64.dynamic = false;
    AbiInt64.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiInt64.create(value);
        return ZeroHexAbiInt64.create(value);
    }
    AbiInt64.create = create;
    function from(value) {
        return AbiInt64.create(value);
    }
    AbiInt64.from = from;
    function codegen() {
        return `Abi.Int64`;
    }
    AbiInt64.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiInt64.decodeOrThrow(cursor);
    }
    AbiInt64.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiInt64.readOrThrow(cursor);
    }
    AbiInt64.readOrThrow = readOrThrow;
})(AbiInt64 || (AbiInt64 = {}));
class BytesAbiInt64 {
    value;
    #class = _q;
    name = this.#class.name;
    static bytes = 8;
    static nibbles = 16;
    static bits = 64;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _q(value);
    }
    static from(value) {
        return _q.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiInt64(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiInt64(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int64`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _q.nibbles;
        const content = cursor.readOrThrow(_q.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _q(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - _q.bytes);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _q.bytes;
        const content = cursor.readOrThrow(_q.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _q(value);
    }
}
_q = BytesAbiInt64;
class ZeroHexAbiInt64 {
    value;
    #class = _r;
    name = this.#class.name;
    static bytes = 8;
    static nibbles = 16;
    static bits = 64;
    static bitsn = BigInt(64);
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    bitsn = this.#class.bitsn;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return _r.fromBigInt(BigInt(value));
    }
    static fromBigInt(value) {
        if (value >= BN_0)
            return new _r(value.toString(16));
        const mask = (BN_1 << 256n) - BN_1;
        const value2 = ((~(-value)) & mask) + BN_1;
        return new _r(value2.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _r.fromBigInt(value);
        if (typeof value === "number")
            return _r.fromNumber(value);
        if (value.startsWith("0x"))
            return new _r(value.slice(2));
        return _r.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _r.create(value);
    }
    intoOrThrow() {
        const mask = (BN_1 << this.bitsn) - BN_1;
        const value = _libs_bigint_bigint_mjs__WEBPACK_IMPORTED_MODULE_2__/* .BigInts */ .l.decodeRaw(this.value);
        if ((value & mask) >> (this.bitsn - BN_1))
            return -(((~value) & mask) + BN_1);
        return value;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int64`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        return new _r(cursor.readOrThrow(64));
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_8 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__addDisposableResource */ .b)(env_8, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_8) {
            env_8.error = e_8;
            env_8.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__disposeResources */ .f)(env_8);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _r.bytes;
        const content = cursor.readOrThrow(_r.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _r(value);
    }
}
_r = ZeroHexAbiInt64;
var AbiInt72;
(function (AbiInt72) {
    AbiInt72.dynamic = false;
    AbiInt72.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiInt72.create(value);
        return ZeroHexAbiInt72.create(value);
    }
    AbiInt72.create = create;
    function from(value) {
        return AbiInt72.create(value);
    }
    AbiInt72.from = from;
    function codegen() {
        return `Abi.Int72`;
    }
    AbiInt72.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiInt72.decodeOrThrow(cursor);
    }
    AbiInt72.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiInt72.readOrThrow(cursor);
    }
    AbiInt72.readOrThrow = readOrThrow;
})(AbiInt72 || (AbiInt72 = {}));
class BytesAbiInt72 {
    value;
    #class = _s;
    name = this.#class.name;
    static bytes = 9;
    static nibbles = 18;
    static bits = 72;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _s(value);
    }
    static from(value) {
        return _s.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiInt72(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiInt72(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int72`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _s.nibbles;
        const content = cursor.readOrThrow(_s.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _s(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - _s.bytes);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _s.bytes;
        const content = cursor.readOrThrow(_s.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _s(value);
    }
}
_s = BytesAbiInt72;
class ZeroHexAbiInt72 {
    value;
    #class = _t;
    name = this.#class.name;
    static bytes = 9;
    static nibbles = 18;
    static bits = 72;
    static bitsn = BigInt(72);
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    bitsn = this.#class.bitsn;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return _t.fromBigInt(BigInt(value));
    }
    static fromBigInt(value) {
        if (value >= BN_0)
            return new _t(value.toString(16));
        const mask = (BN_1 << 256n) - BN_1;
        const value2 = ((~(-value)) & mask) + BN_1;
        return new _t(value2.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _t.fromBigInt(value);
        if (typeof value === "number")
            return _t.fromNumber(value);
        if (value.startsWith("0x"))
            return new _t(value.slice(2));
        return _t.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _t.create(value);
    }
    intoOrThrow() {
        const mask = (BN_1 << this.bitsn) - BN_1;
        const value = _libs_bigint_bigint_mjs__WEBPACK_IMPORTED_MODULE_2__/* .BigInts */ .l.decodeRaw(this.value);
        if ((value & mask) >> (this.bitsn - BN_1))
            return -(((~value) & mask) + BN_1);
        return value;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int72`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        return new _t(cursor.readOrThrow(64));
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_9 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__addDisposableResource */ .b)(env_9, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_9) {
            env_9.error = e_9;
            env_9.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__disposeResources */ .f)(env_9);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _t.bytes;
        const content = cursor.readOrThrow(_t.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _t(value);
    }
}
_t = ZeroHexAbiInt72;
var AbiInt80;
(function (AbiInt80) {
    AbiInt80.dynamic = false;
    AbiInt80.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiInt80.create(value);
        return ZeroHexAbiInt80.create(value);
    }
    AbiInt80.create = create;
    function from(value) {
        return AbiInt80.create(value);
    }
    AbiInt80.from = from;
    function codegen() {
        return `Abi.Int80`;
    }
    AbiInt80.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiInt80.decodeOrThrow(cursor);
    }
    AbiInt80.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiInt80.readOrThrow(cursor);
    }
    AbiInt80.readOrThrow = readOrThrow;
})(AbiInt80 || (AbiInt80 = {}));
class BytesAbiInt80 {
    value;
    #class = _u;
    name = this.#class.name;
    static bytes = 10;
    static nibbles = 20;
    static bits = 80;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _u(value);
    }
    static from(value) {
        return _u.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiInt80(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiInt80(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int80`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _u.nibbles;
        const content = cursor.readOrThrow(_u.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _u(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - _u.bytes);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _u.bytes;
        const content = cursor.readOrThrow(_u.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _u(value);
    }
}
_u = BytesAbiInt80;
class ZeroHexAbiInt80 {
    value;
    #class = _v;
    name = this.#class.name;
    static bytes = 10;
    static nibbles = 20;
    static bits = 80;
    static bitsn = BigInt(80);
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    bitsn = this.#class.bitsn;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return _v.fromBigInt(BigInt(value));
    }
    static fromBigInt(value) {
        if (value >= BN_0)
            return new _v(value.toString(16));
        const mask = (BN_1 << 256n) - BN_1;
        const value2 = ((~(-value)) & mask) + BN_1;
        return new _v(value2.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _v.fromBigInt(value);
        if (typeof value === "number")
            return _v.fromNumber(value);
        if (value.startsWith("0x"))
            return new _v(value.slice(2));
        return _v.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _v.create(value);
    }
    intoOrThrow() {
        const mask = (BN_1 << this.bitsn) - BN_1;
        const value = _libs_bigint_bigint_mjs__WEBPACK_IMPORTED_MODULE_2__/* .BigInts */ .l.decodeRaw(this.value);
        if ((value & mask) >> (this.bitsn - BN_1))
            return -(((~value) & mask) + BN_1);
        return value;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int80`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        return new _v(cursor.readOrThrow(64));
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_10 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__addDisposableResource */ .b)(env_10, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_10) {
            env_10.error = e_10;
            env_10.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__disposeResources */ .f)(env_10);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _v.bytes;
        const content = cursor.readOrThrow(_v.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _v(value);
    }
}
_v = ZeroHexAbiInt80;
var AbiInt88;
(function (AbiInt88) {
    AbiInt88.dynamic = false;
    AbiInt88.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiInt88.create(value);
        return ZeroHexAbiInt88.create(value);
    }
    AbiInt88.create = create;
    function from(value) {
        return AbiInt88.create(value);
    }
    AbiInt88.from = from;
    function codegen() {
        return `Abi.Int88`;
    }
    AbiInt88.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiInt88.decodeOrThrow(cursor);
    }
    AbiInt88.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiInt88.readOrThrow(cursor);
    }
    AbiInt88.readOrThrow = readOrThrow;
})(AbiInt88 || (AbiInt88 = {}));
class BytesAbiInt88 {
    value;
    #class = _w;
    name = this.#class.name;
    static bytes = 11;
    static nibbles = 22;
    static bits = 88;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _w(value);
    }
    static from(value) {
        return _w.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiInt88(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiInt88(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int88`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _w.nibbles;
        const content = cursor.readOrThrow(_w.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _w(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - _w.bytes);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _w.bytes;
        const content = cursor.readOrThrow(_w.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _w(value);
    }
}
_w = BytesAbiInt88;
class ZeroHexAbiInt88 {
    value;
    #class = _x;
    name = this.#class.name;
    static bytes = 11;
    static nibbles = 22;
    static bits = 88;
    static bitsn = BigInt(88);
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    bitsn = this.#class.bitsn;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return _x.fromBigInt(BigInt(value));
    }
    static fromBigInt(value) {
        if (value >= BN_0)
            return new _x(value.toString(16));
        const mask = (BN_1 << 256n) - BN_1;
        const value2 = ((~(-value)) & mask) + BN_1;
        return new _x(value2.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _x.fromBigInt(value);
        if (typeof value === "number")
            return _x.fromNumber(value);
        if (value.startsWith("0x"))
            return new _x(value.slice(2));
        return _x.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _x.create(value);
    }
    intoOrThrow() {
        const mask = (BN_1 << this.bitsn) - BN_1;
        const value = _libs_bigint_bigint_mjs__WEBPACK_IMPORTED_MODULE_2__/* .BigInts */ .l.decodeRaw(this.value);
        if ((value & mask) >> (this.bitsn - BN_1))
            return -(((~value) & mask) + BN_1);
        return value;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int88`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        return new _x(cursor.readOrThrow(64));
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_11 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__addDisposableResource */ .b)(env_11, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_11) {
            env_11.error = e_11;
            env_11.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__disposeResources */ .f)(env_11);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _x.bytes;
        const content = cursor.readOrThrow(_x.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _x(value);
    }
}
_x = ZeroHexAbiInt88;
var AbiInt96;
(function (AbiInt96) {
    AbiInt96.dynamic = false;
    AbiInt96.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiInt96.create(value);
        return ZeroHexAbiInt96.create(value);
    }
    AbiInt96.create = create;
    function from(value) {
        return AbiInt96.create(value);
    }
    AbiInt96.from = from;
    function codegen() {
        return `Abi.Int96`;
    }
    AbiInt96.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiInt96.decodeOrThrow(cursor);
    }
    AbiInt96.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiInt96.readOrThrow(cursor);
    }
    AbiInt96.readOrThrow = readOrThrow;
})(AbiInt96 || (AbiInt96 = {}));
class BytesAbiInt96 {
    value;
    #class = _y;
    name = this.#class.name;
    static bytes = 12;
    static nibbles = 24;
    static bits = 96;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _y(value);
    }
    static from(value) {
        return _y.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiInt96(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiInt96(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int96`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _y.nibbles;
        const content = cursor.readOrThrow(_y.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _y(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - _y.bytes);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _y.bytes;
        const content = cursor.readOrThrow(_y.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _y(value);
    }
}
_y = BytesAbiInt96;
class ZeroHexAbiInt96 {
    value;
    #class = _z;
    name = this.#class.name;
    static bytes = 12;
    static nibbles = 24;
    static bits = 96;
    static bitsn = BigInt(96);
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    bitsn = this.#class.bitsn;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return _z.fromBigInt(BigInt(value));
    }
    static fromBigInt(value) {
        if (value >= BN_0)
            return new _z(value.toString(16));
        const mask = (BN_1 << 256n) - BN_1;
        const value2 = ((~(-value)) & mask) + BN_1;
        return new _z(value2.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _z.fromBigInt(value);
        if (typeof value === "number")
            return _z.fromNumber(value);
        if (value.startsWith("0x"))
            return new _z(value.slice(2));
        return _z.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _z.create(value);
    }
    intoOrThrow() {
        const mask = (BN_1 << this.bitsn) - BN_1;
        const value = _libs_bigint_bigint_mjs__WEBPACK_IMPORTED_MODULE_2__/* .BigInts */ .l.decodeRaw(this.value);
        if ((value & mask) >> (this.bitsn - BN_1))
            return -(((~value) & mask) + BN_1);
        return value;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int96`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        return new _z(cursor.readOrThrow(64));
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_12 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__addDisposableResource */ .b)(env_12, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_12) {
            env_12.error = e_12;
            env_12.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__disposeResources */ .f)(env_12);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _z.bytes;
        const content = cursor.readOrThrow(_z.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _z(value);
    }
}
_z = ZeroHexAbiInt96;
var AbiInt104;
(function (AbiInt104) {
    AbiInt104.dynamic = false;
    AbiInt104.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiInt104.create(value);
        return ZeroHexAbiInt104.create(value);
    }
    AbiInt104.create = create;
    function from(value) {
        return AbiInt104.create(value);
    }
    AbiInt104.from = from;
    function codegen() {
        return `Abi.Int104`;
    }
    AbiInt104.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiInt104.decodeOrThrow(cursor);
    }
    AbiInt104.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiInt104.readOrThrow(cursor);
    }
    AbiInt104.readOrThrow = readOrThrow;
})(AbiInt104 || (AbiInt104 = {}));
class BytesAbiInt104 {
    value;
    #class = _0;
    name = this.#class.name;
    static bytes = 13;
    static nibbles = 26;
    static bits = 104;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _0(value);
    }
    static from(value) {
        return _0.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiInt104(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiInt104(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int104`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _0.nibbles;
        const content = cursor.readOrThrow(_0.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _0(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - _0.bytes);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _0.bytes;
        const content = cursor.readOrThrow(_0.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _0(value);
    }
}
_0 = BytesAbiInt104;
class ZeroHexAbiInt104 {
    value;
    #class = _1;
    name = this.#class.name;
    static bytes = 13;
    static nibbles = 26;
    static bits = 104;
    static bitsn = BigInt(104);
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    bitsn = this.#class.bitsn;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return _1.fromBigInt(BigInt(value));
    }
    static fromBigInt(value) {
        if (value >= BN_0)
            return new _1(value.toString(16));
        const mask = (BN_1 << 256n) - BN_1;
        const value2 = ((~(-value)) & mask) + BN_1;
        return new _1(value2.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _1.fromBigInt(value);
        if (typeof value === "number")
            return _1.fromNumber(value);
        if (value.startsWith("0x"))
            return new _1(value.slice(2));
        return _1.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _1.create(value);
    }
    intoOrThrow() {
        const mask = (BN_1 << this.bitsn) - BN_1;
        const value = _libs_bigint_bigint_mjs__WEBPACK_IMPORTED_MODULE_2__/* .BigInts */ .l.decodeRaw(this.value);
        if ((value & mask) >> (this.bitsn - BN_1))
            return -(((~value) & mask) + BN_1);
        return value;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int104`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        return new _1(cursor.readOrThrow(64));
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_13 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__addDisposableResource */ .b)(env_13, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_13) {
            env_13.error = e_13;
            env_13.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__disposeResources */ .f)(env_13);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _1.bytes;
        const content = cursor.readOrThrow(_1.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _1(value);
    }
}
_1 = ZeroHexAbiInt104;
var AbiInt112;
(function (AbiInt112) {
    AbiInt112.dynamic = false;
    AbiInt112.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiInt112.create(value);
        return ZeroHexAbiInt112.create(value);
    }
    AbiInt112.create = create;
    function from(value) {
        return AbiInt112.create(value);
    }
    AbiInt112.from = from;
    function codegen() {
        return `Abi.Int112`;
    }
    AbiInt112.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiInt112.decodeOrThrow(cursor);
    }
    AbiInt112.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiInt112.readOrThrow(cursor);
    }
    AbiInt112.readOrThrow = readOrThrow;
})(AbiInt112 || (AbiInt112 = {}));
class BytesAbiInt112 {
    value;
    #class = _2;
    name = this.#class.name;
    static bytes = 14;
    static nibbles = 28;
    static bits = 112;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _2(value);
    }
    static from(value) {
        return _2.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiInt112(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiInt112(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int112`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _2.nibbles;
        const content = cursor.readOrThrow(_2.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _2(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - _2.bytes);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _2.bytes;
        const content = cursor.readOrThrow(_2.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _2(value);
    }
}
_2 = BytesAbiInt112;
class ZeroHexAbiInt112 {
    value;
    #class = _3;
    name = this.#class.name;
    static bytes = 14;
    static nibbles = 28;
    static bits = 112;
    static bitsn = BigInt(112);
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    bitsn = this.#class.bitsn;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return _3.fromBigInt(BigInt(value));
    }
    static fromBigInt(value) {
        if (value >= BN_0)
            return new _3(value.toString(16));
        const mask = (BN_1 << 256n) - BN_1;
        const value2 = ((~(-value)) & mask) + BN_1;
        return new _3(value2.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _3.fromBigInt(value);
        if (typeof value === "number")
            return _3.fromNumber(value);
        if (value.startsWith("0x"))
            return new _3(value.slice(2));
        return _3.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _3.create(value);
    }
    intoOrThrow() {
        const mask = (BN_1 << this.bitsn) - BN_1;
        const value = _libs_bigint_bigint_mjs__WEBPACK_IMPORTED_MODULE_2__/* .BigInts */ .l.decodeRaw(this.value);
        if ((value & mask) >> (this.bitsn - BN_1))
            return -(((~value) & mask) + BN_1);
        return value;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int112`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        return new _3(cursor.readOrThrow(64));
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_14 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__addDisposableResource */ .b)(env_14, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_14) {
            env_14.error = e_14;
            env_14.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__disposeResources */ .f)(env_14);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _3.bytes;
        const content = cursor.readOrThrow(_3.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _3(value);
    }
}
_3 = ZeroHexAbiInt112;
var AbiInt120;
(function (AbiInt120) {
    AbiInt120.dynamic = false;
    AbiInt120.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiInt120.create(value);
        return ZeroHexAbiInt120.create(value);
    }
    AbiInt120.create = create;
    function from(value) {
        return AbiInt120.create(value);
    }
    AbiInt120.from = from;
    function codegen() {
        return `Abi.Int120`;
    }
    AbiInt120.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiInt120.decodeOrThrow(cursor);
    }
    AbiInt120.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiInt120.readOrThrow(cursor);
    }
    AbiInt120.readOrThrow = readOrThrow;
})(AbiInt120 || (AbiInt120 = {}));
class BytesAbiInt120 {
    value;
    #class = _4;
    name = this.#class.name;
    static bytes = 15;
    static nibbles = 30;
    static bits = 120;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _4(value);
    }
    static from(value) {
        return _4.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiInt120(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiInt120(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int120`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _4.nibbles;
        const content = cursor.readOrThrow(_4.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _4(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - _4.bytes);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _4.bytes;
        const content = cursor.readOrThrow(_4.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _4(value);
    }
}
_4 = BytesAbiInt120;
class ZeroHexAbiInt120 {
    value;
    #class = _5;
    name = this.#class.name;
    static bytes = 15;
    static nibbles = 30;
    static bits = 120;
    static bitsn = BigInt(120);
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    bitsn = this.#class.bitsn;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return _5.fromBigInt(BigInt(value));
    }
    static fromBigInt(value) {
        if (value >= BN_0)
            return new _5(value.toString(16));
        const mask = (BN_1 << 256n) - BN_1;
        const value2 = ((~(-value)) & mask) + BN_1;
        return new _5(value2.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _5.fromBigInt(value);
        if (typeof value === "number")
            return _5.fromNumber(value);
        if (value.startsWith("0x"))
            return new _5(value.slice(2));
        return _5.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _5.create(value);
    }
    intoOrThrow() {
        const mask = (BN_1 << this.bitsn) - BN_1;
        const value = _libs_bigint_bigint_mjs__WEBPACK_IMPORTED_MODULE_2__/* .BigInts */ .l.decodeRaw(this.value);
        if ((value & mask) >> (this.bitsn - BN_1))
            return -(((~value) & mask) + BN_1);
        return value;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int120`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        return new _5(cursor.readOrThrow(64));
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_15 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__addDisposableResource */ .b)(env_15, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_15) {
            env_15.error = e_15;
            env_15.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__disposeResources */ .f)(env_15);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _5.bytes;
        const content = cursor.readOrThrow(_5.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _5(value);
    }
}
_5 = ZeroHexAbiInt120;
var AbiInt128;
(function (AbiInt128) {
    AbiInt128.dynamic = false;
    AbiInt128.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiInt128.create(value);
        return ZeroHexAbiInt128.create(value);
    }
    AbiInt128.create = create;
    function from(value) {
        return AbiInt128.create(value);
    }
    AbiInt128.from = from;
    function codegen() {
        return `Abi.Int128`;
    }
    AbiInt128.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiInt128.decodeOrThrow(cursor);
    }
    AbiInt128.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiInt128.readOrThrow(cursor);
    }
    AbiInt128.readOrThrow = readOrThrow;
})(AbiInt128 || (AbiInt128 = {}));
class BytesAbiInt128 {
    value;
    #class = _6;
    name = this.#class.name;
    static bytes = 16;
    static nibbles = 32;
    static bits = 128;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _6(value);
    }
    static from(value) {
        return _6.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiInt128(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiInt128(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int128`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _6.nibbles;
        const content = cursor.readOrThrow(_6.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _6(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - _6.bytes);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _6.bytes;
        const content = cursor.readOrThrow(_6.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _6(value);
    }
}
_6 = BytesAbiInt128;
class ZeroHexAbiInt128 {
    value;
    #class = _7;
    name = this.#class.name;
    static bytes = 16;
    static nibbles = 32;
    static bits = 128;
    static bitsn = BigInt(128);
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    bitsn = this.#class.bitsn;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return _7.fromBigInt(BigInt(value));
    }
    static fromBigInt(value) {
        if (value >= BN_0)
            return new _7(value.toString(16));
        const mask = (BN_1 << 256n) - BN_1;
        const value2 = ((~(-value)) & mask) + BN_1;
        return new _7(value2.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _7.fromBigInt(value);
        if (typeof value === "number")
            return _7.fromNumber(value);
        if (value.startsWith("0x"))
            return new _7(value.slice(2));
        return _7.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _7.create(value);
    }
    intoOrThrow() {
        const mask = (BN_1 << this.bitsn) - BN_1;
        const value = _libs_bigint_bigint_mjs__WEBPACK_IMPORTED_MODULE_2__/* .BigInts */ .l.decodeRaw(this.value);
        if ((value & mask) >> (this.bitsn - BN_1))
            return -(((~value) & mask) + BN_1);
        return value;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int128`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        return new _7(cursor.readOrThrow(64));
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_16 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__addDisposableResource */ .b)(env_16, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_16) {
            env_16.error = e_16;
            env_16.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__disposeResources */ .f)(env_16);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _7.bytes;
        const content = cursor.readOrThrow(_7.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _7(value);
    }
}
_7 = ZeroHexAbiInt128;
var AbiInt136;
(function (AbiInt136) {
    AbiInt136.dynamic = false;
    AbiInt136.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiInt136.create(value);
        return ZeroHexAbiInt136.create(value);
    }
    AbiInt136.create = create;
    function from(value) {
        return AbiInt136.create(value);
    }
    AbiInt136.from = from;
    function codegen() {
        return `Abi.Int136`;
    }
    AbiInt136.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiInt136.decodeOrThrow(cursor);
    }
    AbiInt136.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiInt136.readOrThrow(cursor);
    }
    AbiInt136.readOrThrow = readOrThrow;
})(AbiInt136 || (AbiInt136 = {}));
class BytesAbiInt136 {
    value;
    #class = _8;
    name = this.#class.name;
    static bytes = 17;
    static nibbles = 34;
    static bits = 136;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _8(value);
    }
    static from(value) {
        return _8.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiInt136(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiInt136(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int136`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _8.nibbles;
        const content = cursor.readOrThrow(_8.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _8(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - _8.bytes);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _8.bytes;
        const content = cursor.readOrThrow(_8.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _8(value);
    }
}
_8 = BytesAbiInt136;
class ZeroHexAbiInt136 {
    value;
    #class = _9;
    name = this.#class.name;
    static bytes = 17;
    static nibbles = 34;
    static bits = 136;
    static bitsn = BigInt(136);
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    bitsn = this.#class.bitsn;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return _9.fromBigInt(BigInt(value));
    }
    static fromBigInt(value) {
        if (value >= BN_0)
            return new _9(value.toString(16));
        const mask = (BN_1 << 256n) - BN_1;
        const value2 = ((~(-value)) & mask) + BN_1;
        return new _9(value2.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _9.fromBigInt(value);
        if (typeof value === "number")
            return _9.fromNumber(value);
        if (value.startsWith("0x"))
            return new _9(value.slice(2));
        return _9.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _9.create(value);
    }
    intoOrThrow() {
        const mask = (BN_1 << this.bitsn) - BN_1;
        const value = _libs_bigint_bigint_mjs__WEBPACK_IMPORTED_MODULE_2__/* .BigInts */ .l.decodeRaw(this.value);
        if ((value & mask) >> (this.bitsn - BN_1))
            return -(((~value) & mask) + BN_1);
        return value;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int136`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        return new _9(cursor.readOrThrow(64));
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_17 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__addDisposableResource */ .b)(env_17, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_17) {
            env_17.error = e_17;
            env_17.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__disposeResources */ .f)(env_17);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _9.bytes;
        const content = cursor.readOrThrow(_9.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _9(value);
    }
}
_9 = ZeroHexAbiInt136;
var AbiInt144;
(function (AbiInt144) {
    AbiInt144.dynamic = false;
    AbiInt144.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiInt144.create(value);
        return ZeroHexAbiInt144.create(value);
    }
    AbiInt144.create = create;
    function from(value) {
        return AbiInt144.create(value);
    }
    AbiInt144.from = from;
    function codegen() {
        return `Abi.Int144`;
    }
    AbiInt144.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiInt144.decodeOrThrow(cursor);
    }
    AbiInt144.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiInt144.readOrThrow(cursor);
    }
    AbiInt144.readOrThrow = readOrThrow;
})(AbiInt144 || (AbiInt144 = {}));
class BytesAbiInt144 {
    value;
    #class = _10;
    name = this.#class.name;
    static bytes = 18;
    static nibbles = 36;
    static bits = 144;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _10(value);
    }
    static from(value) {
        return _10.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiInt144(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiInt144(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int144`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _10.nibbles;
        const content = cursor.readOrThrow(_10.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _10(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - _10.bytes);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _10.bytes;
        const content = cursor.readOrThrow(_10.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _10(value);
    }
}
_10 = BytesAbiInt144;
class ZeroHexAbiInt144 {
    value;
    #class = _11;
    name = this.#class.name;
    static bytes = 18;
    static nibbles = 36;
    static bits = 144;
    static bitsn = BigInt(144);
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    bitsn = this.#class.bitsn;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return _11.fromBigInt(BigInt(value));
    }
    static fromBigInt(value) {
        if (value >= BN_0)
            return new _11(value.toString(16));
        const mask = (BN_1 << 256n) - BN_1;
        const value2 = ((~(-value)) & mask) + BN_1;
        return new _11(value2.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _11.fromBigInt(value);
        if (typeof value === "number")
            return _11.fromNumber(value);
        if (value.startsWith("0x"))
            return new _11(value.slice(2));
        return _11.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _11.create(value);
    }
    intoOrThrow() {
        const mask = (BN_1 << this.bitsn) - BN_1;
        const value = _libs_bigint_bigint_mjs__WEBPACK_IMPORTED_MODULE_2__/* .BigInts */ .l.decodeRaw(this.value);
        if ((value & mask) >> (this.bitsn - BN_1))
            return -(((~value) & mask) + BN_1);
        return value;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int144`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        return new _11(cursor.readOrThrow(64));
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_18 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__addDisposableResource */ .b)(env_18, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_18) {
            env_18.error = e_18;
            env_18.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__disposeResources */ .f)(env_18);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _11.bytes;
        const content = cursor.readOrThrow(_11.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _11(value);
    }
}
_11 = ZeroHexAbiInt144;
var AbiInt152;
(function (AbiInt152) {
    AbiInt152.dynamic = false;
    AbiInt152.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiInt152.create(value);
        return ZeroHexAbiInt152.create(value);
    }
    AbiInt152.create = create;
    function from(value) {
        return AbiInt152.create(value);
    }
    AbiInt152.from = from;
    function codegen() {
        return `Abi.Int152`;
    }
    AbiInt152.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiInt152.decodeOrThrow(cursor);
    }
    AbiInt152.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiInt152.readOrThrow(cursor);
    }
    AbiInt152.readOrThrow = readOrThrow;
})(AbiInt152 || (AbiInt152 = {}));
class BytesAbiInt152 {
    value;
    #class = _12;
    name = this.#class.name;
    static bytes = 19;
    static nibbles = 38;
    static bits = 152;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _12(value);
    }
    static from(value) {
        return _12.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiInt152(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiInt152(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int152`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _12.nibbles;
        const content = cursor.readOrThrow(_12.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _12(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - _12.bytes);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _12.bytes;
        const content = cursor.readOrThrow(_12.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _12(value);
    }
}
_12 = BytesAbiInt152;
class ZeroHexAbiInt152 {
    value;
    #class = _13;
    name = this.#class.name;
    static bytes = 19;
    static nibbles = 38;
    static bits = 152;
    static bitsn = BigInt(152);
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    bitsn = this.#class.bitsn;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return _13.fromBigInt(BigInt(value));
    }
    static fromBigInt(value) {
        if (value >= BN_0)
            return new _13(value.toString(16));
        const mask = (BN_1 << 256n) - BN_1;
        const value2 = ((~(-value)) & mask) + BN_1;
        return new _13(value2.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _13.fromBigInt(value);
        if (typeof value === "number")
            return _13.fromNumber(value);
        if (value.startsWith("0x"))
            return new _13(value.slice(2));
        return _13.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _13.create(value);
    }
    intoOrThrow() {
        const mask = (BN_1 << this.bitsn) - BN_1;
        const value = _libs_bigint_bigint_mjs__WEBPACK_IMPORTED_MODULE_2__/* .BigInts */ .l.decodeRaw(this.value);
        if ((value & mask) >> (this.bitsn - BN_1))
            return -(((~value) & mask) + BN_1);
        return value;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int152`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        return new _13(cursor.readOrThrow(64));
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_19 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__addDisposableResource */ .b)(env_19, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_19) {
            env_19.error = e_19;
            env_19.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__disposeResources */ .f)(env_19);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _13.bytes;
        const content = cursor.readOrThrow(_13.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _13(value);
    }
}
_13 = ZeroHexAbiInt152;
var AbiInt160;
(function (AbiInt160) {
    AbiInt160.dynamic = false;
    AbiInt160.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiInt160.create(value);
        return ZeroHexAbiInt160.create(value);
    }
    AbiInt160.create = create;
    function from(value) {
        return AbiInt160.create(value);
    }
    AbiInt160.from = from;
    function codegen() {
        return `Abi.Int160`;
    }
    AbiInt160.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiInt160.decodeOrThrow(cursor);
    }
    AbiInt160.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiInt160.readOrThrow(cursor);
    }
    AbiInt160.readOrThrow = readOrThrow;
})(AbiInt160 || (AbiInt160 = {}));
class BytesAbiInt160 {
    value;
    #class = _14;
    name = this.#class.name;
    static bytes = 20;
    static nibbles = 40;
    static bits = 160;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _14(value);
    }
    static from(value) {
        return _14.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiInt160(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiInt160(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int160`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _14.nibbles;
        const content = cursor.readOrThrow(_14.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _14(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - _14.bytes);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _14.bytes;
        const content = cursor.readOrThrow(_14.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _14(value);
    }
}
_14 = BytesAbiInt160;
class ZeroHexAbiInt160 {
    value;
    #class = _15;
    name = this.#class.name;
    static bytes = 20;
    static nibbles = 40;
    static bits = 160;
    static bitsn = BigInt(160);
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    bitsn = this.#class.bitsn;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return _15.fromBigInt(BigInt(value));
    }
    static fromBigInt(value) {
        if (value >= BN_0)
            return new _15(value.toString(16));
        const mask = (BN_1 << 256n) - BN_1;
        const value2 = ((~(-value)) & mask) + BN_1;
        return new _15(value2.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _15.fromBigInt(value);
        if (typeof value === "number")
            return _15.fromNumber(value);
        if (value.startsWith("0x"))
            return new _15(value.slice(2));
        return _15.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _15.create(value);
    }
    intoOrThrow() {
        const mask = (BN_1 << this.bitsn) - BN_1;
        const value = _libs_bigint_bigint_mjs__WEBPACK_IMPORTED_MODULE_2__/* .BigInts */ .l.decodeRaw(this.value);
        if ((value & mask) >> (this.bitsn - BN_1))
            return -(((~value) & mask) + BN_1);
        return value;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int160`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        return new _15(cursor.readOrThrow(64));
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_20 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__addDisposableResource */ .b)(env_20, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_20) {
            env_20.error = e_20;
            env_20.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__disposeResources */ .f)(env_20);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _15.bytes;
        const content = cursor.readOrThrow(_15.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _15(value);
    }
}
_15 = ZeroHexAbiInt160;
var AbiInt168;
(function (AbiInt168) {
    AbiInt168.dynamic = false;
    AbiInt168.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiInt168.create(value);
        return ZeroHexAbiInt168.create(value);
    }
    AbiInt168.create = create;
    function from(value) {
        return AbiInt168.create(value);
    }
    AbiInt168.from = from;
    function codegen() {
        return `Abi.Int168`;
    }
    AbiInt168.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiInt168.decodeOrThrow(cursor);
    }
    AbiInt168.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiInt168.readOrThrow(cursor);
    }
    AbiInt168.readOrThrow = readOrThrow;
})(AbiInt168 || (AbiInt168 = {}));
class BytesAbiInt168 {
    value;
    #class = _16;
    name = this.#class.name;
    static bytes = 21;
    static nibbles = 42;
    static bits = 168;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _16(value);
    }
    static from(value) {
        return _16.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiInt168(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiInt168(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int168`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _16.nibbles;
        const content = cursor.readOrThrow(_16.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _16(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - _16.bytes);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _16.bytes;
        const content = cursor.readOrThrow(_16.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _16(value);
    }
}
_16 = BytesAbiInt168;
class ZeroHexAbiInt168 {
    value;
    #class = _17;
    name = this.#class.name;
    static bytes = 21;
    static nibbles = 42;
    static bits = 168;
    static bitsn = BigInt(168);
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    bitsn = this.#class.bitsn;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return _17.fromBigInt(BigInt(value));
    }
    static fromBigInt(value) {
        if (value >= BN_0)
            return new _17(value.toString(16));
        const mask = (BN_1 << 256n) - BN_1;
        const value2 = ((~(-value)) & mask) + BN_1;
        return new _17(value2.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _17.fromBigInt(value);
        if (typeof value === "number")
            return _17.fromNumber(value);
        if (value.startsWith("0x"))
            return new _17(value.slice(2));
        return _17.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _17.create(value);
    }
    intoOrThrow() {
        const mask = (BN_1 << this.bitsn) - BN_1;
        const value = _libs_bigint_bigint_mjs__WEBPACK_IMPORTED_MODULE_2__/* .BigInts */ .l.decodeRaw(this.value);
        if ((value & mask) >> (this.bitsn - BN_1))
            return -(((~value) & mask) + BN_1);
        return value;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int168`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        return new _17(cursor.readOrThrow(64));
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_21 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__addDisposableResource */ .b)(env_21, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_21) {
            env_21.error = e_21;
            env_21.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__disposeResources */ .f)(env_21);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _17.bytes;
        const content = cursor.readOrThrow(_17.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _17(value);
    }
}
_17 = ZeroHexAbiInt168;
var AbiInt176;
(function (AbiInt176) {
    AbiInt176.dynamic = false;
    AbiInt176.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiInt176.create(value);
        return ZeroHexAbiInt176.create(value);
    }
    AbiInt176.create = create;
    function from(value) {
        return AbiInt176.create(value);
    }
    AbiInt176.from = from;
    function codegen() {
        return `Abi.Int176`;
    }
    AbiInt176.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiInt176.decodeOrThrow(cursor);
    }
    AbiInt176.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiInt176.readOrThrow(cursor);
    }
    AbiInt176.readOrThrow = readOrThrow;
})(AbiInt176 || (AbiInt176 = {}));
class BytesAbiInt176 {
    value;
    #class = _18;
    name = this.#class.name;
    static bytes = 22;
    static nibbles = 44;
    static bits = 176;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _18(value);
    }
    static from(value) {
        return _18.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiInt176(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiInt176(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int176`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _18.nibbles;
        const content = cursor.readOrThrow(_18.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _18(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - _18.bytes);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _18.bytes;
        const content = cursor.readOrThrow(_18.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _18(value);
    }
}
_18 = BytesAbiInt176;
class ZeroHexAbiInt176 {
    value;
    #class = _19;
    name = this.#class.name;
    static bytes = 22;
    static nibbles = 44;
    static bits = 176;
    static bitsn = BigInt(176);
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    bitsn = this.#class.bitsn;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return _19.fromBigInt(BigInt(value));
    }
    static fromBigInt(value) {
        if (value >= BN_0)
            return new _19(value.toString(16));
        const mask = (BN_1 << 256n) - BN_1;
        const value2 = ((~(-value)) & mask) + BN_1;
        return new _19(value2.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _19.fromBigInt(value);
        if (typeof value === "number")
            return _19.fromNumber(value);
        if (value.startsWith("0x"))
            return new _19(value.slice(2));
        return _19.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _19.create(value);
    }
    intoOrThrow() {
        const mask = (BN_1 << this.bitsn) - BN_1;
        const value = _libs_bigint_bigint_mjs__WEBPACK_IMPORTED_MODULE_2__/* .BigInts */ .l.decodeRaw(this.value);
        if ((value & mask) >> (this.bitsn - BN_1))
            return -(((~value) & mask) + BN_1);
        return value;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int176`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        return new _19(cursor.readOrThrow(64));
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_22 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__addDisposableResource */ .b)(env_22, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_22) {
            env_22.error = e_22;
            env_22.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__disposeResources */ .f)(env_22);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _19.bytes;
        const content = cursor.readOrThrow(_19.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _19(value);
    }
}
_19 = ZeroHexAbiInt176;
var AbiInt184;
(function (AbiInt184) {
    AbiInt184.dynamic = false;
    AbiInt184.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiInt184.create(value);
        return ZeroHexAbiInt184.create(value);
    }
    AbiInt184.create = create;
    function from(value) {
        return AbiInt184.create(value);
    }
    AbiInt184.from = from;
    function codegen() {
        return `Abi.Int184`;
    }
    AbiInt184.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiInt184.decodeOrThrow(cursor);
    }
    AbiInt184.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiInt184.readOrThrow(cursor);
    }
    AbiInt184.readOrThrow = readOrThrow;
})(AbiInt184 || (AbiInt184 = {}));
class BytesAbiInt184 {
    value;
    #class = _20;
    name = this.#class.name;
    static bytes = 23;
    static nibbles = 46;
    static bits = 184;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _20(value);
    }
    static from(value) {
        return _20.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiInt184(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiInt184(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int184`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _20.nibbles;
        const content = cursor.readOrThrow(_20.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _20(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - _20.bytes);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _20.bytes;
        const content = cursor.readOrThrow(_20.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _20(value);
    }
}
_20 = BytesAbiInt184;
class ZeroHexAbiInt184 {
    value;
    #class = _21;
    name = this.#class.name;
    static bytes = 23;
    static nibbles = 46;
    static bits = 184;
    static bitsn = BigInt(184);
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    bitsn = this.#class.bitsn;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return _21.fromBigInt(BigInt(value));
    }
    static fromBigInt(value) {
        if (value >= BN_0)
            return new _21(value.toString(16));
        const mask = (BN_1 << 256n) - BN_1;
        const value2 = ((~(-value)) & mask) + BN_1;
        return new _21(value2.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _21.fromBigInt(value);
        if (typeof value === "number")
            return _21.fromNumber(value);
        if (value.startsWith("0x"))
            return new _21(value.slice(2));
        return _21.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _21.create(value);
    }
    intoOrThrow() {
        const mask = (BN_1 << this.bitsn) - BN_1;
        const value = _libs_bigint_bigint_mjs__WEBPACK_IMPORTED_MODULE_2__/* .BigInts */ .l.decodeRaw(this.value);
        if ((value & mask) >> (this.bitsn - BN_1))
            return -(((~value) & mask) + BN_1);
        return value;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int184`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        return new _21(cursor.readOrThrow(64));
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_23 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__addDisposableResource */ .b)(env_23, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_23) {
            env_23.error = e_23;
            env_23.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__disposeResources */ .f)(env_23);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _21.bytes;
        const content = cursor.readOrThrow(_21.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _21(value);
    }
}
_21 = ZeroHexAbiInt184;
var AbiInt192;
(function (AbiInt192) {
    AbiInt192.dynamic = false;
    AbiInt192.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiInt192.create(value);
        return ZeroHexAbiInt192.create(value);
    }
    AbiInt192.create = create;
    function from(value) {
        return AbiInt192.create(value);
    }
    AbiInt192.from = from;
    function codegen() {
        return `Abi.Int192`;
    }
    AbiInt192.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiInt192.decodeOrThrow(cursor);
    }
    AbiInt192.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiInt192.readOrThrow(cursor);
    }
    AbiInt192.readOrThrow = readOrThrow;
})(AbiInt192 || (AbiInt192 = {}));
class BytesAbiInt192 {
    value;
    #class = _22;
    name = this.#class.name;
    static bytes = 24;
    static nibbles = 48;
    static bits = 192;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _22(value);
    }
    static from(value) {
        return _22.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiInt192(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiInt192(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int192`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _22.nibbles;
        const content = cursor.readOrThrow(_22.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _22(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - _22.bytes);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _22.bytes;
        const content = cursor.readOrThrow(_22.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _22(value);
    }
}
_22 = BytesAbiInt192;
class ZeroHexAbiInt192 {
    value;
    #class = _23;
    name = this.#class.name;
    static bytes = 24;
    static nibbles = 48;
    static bits = 192;
    static bitsn = BigInt(192);
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    bitsn = this.#class.bitsn;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return _23.fromBigInt(BigInt(value));
    }
    static fromBigInt(value) {
        if (value >= BN_0)
            return new _23(value.toString(16));
        const mask = (BN_1 << 256n) - BN_1;
        const value2 = ((~(-value)) & mask) + BN_1;
        return new _23(value2.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _23.fromBigInt(value);
        if (typeof value === "number")
            return _23.fromNumber(value);
        if (value.startsWith("0x"))
            return new _23(value.slice(2));
        return _23.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _23.create(value);
    }
    intoOrThrow() {
        const mask = (BN_1 << this.bitsn) - BN_1;
        const value = _libs_bigint_bigint_mjs__WEBPACK_IMPORTED_MODULE_2__/* .BigInts */ .l.decodeRaw(this.value);
        if ((value & mask) >> (this.bitsn - BN_1))
            return -(((~value) & mask) + BN_1);
        return value;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int192`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        return new _23(cursor.readOrThrow(64));
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_24 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__addDisposableResource */ .b)(env_24, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_24) {
            env_24.error = e_24;
            env_24.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__disposeResources */ .f)(env_24);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _23.bytes;
        const content = cursor.readOrThrow(_23.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _23(value);
    }
}
_23 = ZeroHexAbiInt192;
var AbiInt200;
(function (AbiInt200) {
    AbiInt200.dynamic = false;
    AbiInt200.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiInt200.create(value);
        return ZeroHexAbiInt200.create(value);
    }
    AbiInt200.create = create;
    function from(value) {
        return AbiInt200.create(value);
    }
    AbiInt200.from = from;
    function codegen() {
        return `Abi.Int200`;
    }
    AbiInt200.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiInt200.decodeOrThrow(cursor);
    }
    AbiInt200.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiInt200.readOrThrow(cursor);
    }
    AbiInt200.readOrThrow = readOrThrow;
})(AbiInt200 || (AbiInt200 = {}));
class BytesAbiInt200 {
    value;
    #class = _24;
    name = this.#class.name;
    static bytes = 25;
    static nibbles = 50;
    static bits = 200;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _24(value);
    }
    static from(value) {
        return _24.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiInt200(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiInt200(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int200`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _24.nibbles;
        const content = cursor.readOrThrow(_24.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _24(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - _24.bytes);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _24.bytes;
        const content = cursor.readOrThrow(_24.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _24(value);
    }
}
_24 = BytesAbiInt200;
class ZeroHexAbiInt200 {
    value;
    #class = _25;
    name = this.#class.name;
    static bytes = 25;
    static nibbles = 50;
    static bits = 200;
    static bitsn = BigInt(200);
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    bitsn = this.#class.bitsn;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return _25.fromBigInt(BigInt(value));
    }
    static fromBigInt(value) {
        if (value >= BN_0)
            return new _25(value.toString(16));
        const mask = (BN_1 << 256n) - BN_1;
        const value2 = ((~(-value)) & mask) + BN_1;
        return new _25(value2.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _25.fromBigInt(value);
        if (typeof value === "number")
            return _25.fromNumber(value);
        if (value.startsWith("0x"))
            return new _25(value.slice(2));
        return _25.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _25.create(value);
    }
    intoOrThrow() {
        const mask = (BN_1 << this.bitsn) - BN_1;
        const value = _libs_bigint_bigint_mjs__WEBPACK_IMPORTED_MODULE_2__/* .BigInts */ .l.decodeRaw(this.value);
        if ((value & mask) >> (this.bitsn - BN_1))
            return -(((~value) & mask) + BN_1);
        return value;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int200`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        return new _25(cursor.readOrThrow(64));
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_25 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__addDisposableResource */ .b)(env_25, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_25) {
            env_25.error = e_25;
            env_25.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__disposeResources */ .f)(env_25);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _25.bytes;
        const content = cursor.readOrThrow(_25.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _25(value);
    }
}
_25 = ZeroHexAbiInt200;
var AbiInt208;
(function (AbiInt208) {
    AbiInt208.dynamic = false;
    AbiInt208.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiInt208.create(value);
        return ZeroHexAbiInt208.create(value);
    }
    AbiInt208.create = create;
    function from(value) {
        return AbiInt208.create(value);
    }
    AbiInt208.from = from;
    function codegen() {
        return `Abi.Int208`;
    }
    AbiInt208.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiInt208.decodeOrThrow(cursor);
    }
    AbiInt208.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiInt208.readOrThrow(cursor);
    }
    AbiInt208.readOrThrow = readOrThrow;
})(AbiInt208 || (AbiInt208 = {}));
class BytesAbiInt208 {
    value;
    #class = _26;
    name = this.#class.name;
    static bytes = 26;
    static nibbles = 52;
    static bits = 208;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _26(value);
    }
    static from(value) {
        return _26.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiInt208(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiInt208(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int208`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _26.nibbles;
        const content = cursor.readOrThrow(_26.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _26(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - _26.bytes);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _26.bytes;
        const content = cursor.readOrThrow(_26.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _26(value);
    }
}
_26 = BytesAbiInt208;
class ZeroHexAbiInt208 {
    value;
    #class = _27;
    name = this.#class.name;
    static bytes = 26;
    static nibbles = 52;
    static bits = 208;
    static bitsn = BigInt(208);
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    bitsn = this.#class.bitsn;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return _27.fromBigInt(BigInt(value));
    }
    static fromBigInt(value) {
        if (value >= BN_0)
            return new _27(value.toString(16));
        const mask = (BN_1 << 256n) - BN_1;
        const value2 = ((~(-value)) & mask) + BN_1;
        return new _27(value2.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _27.fromBigInt(value);
        if (typeof value === "number")
            return _27.fromNumber(value);
        if (value.startsWith("0x"))
            return new _27(value.slice(2));
        return _27.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _27.create(value);
    }
    intoOrThrow() {
        const mask = (BN_1 << this.bitsn) - BN_1;
        const value = _libs_bigint_bigint_mjs__WEBPACK_IMPORTED_MODULE_2__/* .BigInts */ .l.decodeRaw(this.value);
        if ((value & mask) >> (this.bitsn - BN_1))
            return -(((~value) & mask) + BN_1);
        return value;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int208`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        return new _27(cursor.readOrThrow(64));
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_26 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__addDisposableResource */ .b)(env_26, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_26) {
            env_26.error = e_26;
            env_26.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__disposeResources */ .f)(env_26);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _27.bytes;
        const content = cursor.readOrThrow(_27.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _27(value);
    }
}
_27 = ZeroHexAbiInt208;
var AbiInt216;
(function (AbiInt216) {
    AbiInt216.dynamic = false;
    AbiInt216.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiInt216.create(value);
        return ZeroHexAbiInt216.create(value);
    }
    AbiInt216.create = create;
    function from(value) {
        return AbiInt216.create(value);
    }
    AbiInt216.from = from;
    function codegen() {
        return `Abi.Int216`;
    }
    AbiInt216.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiInt216.decodeOrThrow(cursor);
    }
    AbiInt216.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiInt216.readOrThrow(cursor);
    }
    AbiInt216.readOrThrow = readOrThrow;
})(AbiInt216 || (AbiInt216 = {}));
class BytesAbiInt216 {
    value;
    #class = _28;
    name = this.#class.name;
    static bytes = 27;
    static nibbles = 54;
    static bits = 216;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _28(value);
    }
    static from(value) {
        return _28.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiInt216(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiInt216(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int216`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _28.nibbles;
        const content = cursor.readOrThrow(_28.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _28(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - _28.bytes);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _28.bytes;
        const content = cursor.readOrThrow(_28.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _28(value);
    }
}
_28 = BytesAbiInt216;
class ZeroHexAbiInt216 {
    value;
    #class = _29;
    name = this.#class.name;
    static bytes = 27;
    static nibbles = 54;
    static bits = 216;
    static bitsn = BigInt(216);
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    bitsn = this.#class.bitsn;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return _29.fromBigInt(BigInt(value));
    }
    static fromBigInt(value) {
        if (value >= BN_0)
            return new _29(value.toString(16));
        const mask = (BN_1 << 256n) - BN_1;
        const value2 = ((~(-value)) & mask) + BN_1;
        return new _29(value2.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _29.fromBigInt(value);
        if (typeof value === "number")
            return _29.fromNumber(value);
        if (value.startsWith("0x"))
            return new _29(value.slice(2));
        return _29.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _29.create(value);
    }
    intoOrThrow() {
        const mask = (BN_1 << this.bitsn) - BN_1;
        const value = _libs_bigint_bigint_mjs__WEBPACK_IMPORTED_MODULE_2__/* .BigInts */ .l.decodeRaw(this.value);
        if ((value & mask) >> (this.bitsn - BN_1))
            return -(((~value) & mask) + BN_1);
        return value;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int216`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        return new _29(cursor.readOrThrow(64));
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_27 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__addDisposableResource */ .b)(env_27, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_27) {
            env_27.error = e_27;
            env_27.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__disposeResources */ .f)(env_27);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _29.bytes;
        const content = cursor.readOrThrow(_29.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _29(value);
    }
}
_29 = ZeroHexAbiInt216;
var AbiInt224;
(function (AbiInt224) {
    AbiInt224.dynamic = false;
    AbiInt224.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiInt224.create(value);
        return ZeroHexAbiInt224.create(value);
    }
    AbiInt224.create = create;
    function from(value) {
        return AbiInt224.create(value);
    }
    AbiInt224.from = from;
    function codegen() {
        return `Abi.Int224`;
    }
    AbiInt224.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiInt224.decodeOrThrow(cursor);
    }
    AbiInt224.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiInt224.readOrThrow(cursor);
    }
    AbiInt224.readOrThrow = readOrThrow;
})(AbiInt224 || (AbiInt224 = {}));
class BytesAbiInt224 {
    value;
    #class = _30;
    name = this.#class.name;
    static bytes = 28;
    static nibbles = 56;
    static bits = 224;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _30(value);
    }
    static from(value) {
        return _30.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiInt224(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiInt224(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int224`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _30.nibbles;
        const content = cursor.readOrThrow(_30.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _30(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - _30.bytes);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _30.bytes;
        const content = cursor.readOrThrow(_30.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _30(value);
    }
}
_30 = BytesAbiInt224;
class ZeroHexAbiInt224 {
    value;
    #class = _31;
    name = this.#class.name;
    static bytes = 28;
    static nibbles = 56;
    static bits = 224;
    static bitsn = BigInt(224);
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    bitsn = this.#class.bitsn;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return _31.fromBigInt(BigInt(value));
    }
    static fromBigInt(value) {
        if (value >= BN_0)
            return new _31(value.toString(16));
        const mask = (BN_1 << 256n) - BN_1;
        const value2 = ((~(-value)) & mask) + BN_1;
        return new _31(value2.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _31.fromBigInt(value);
        if (typeof value === "number")
            return _31.fromNumber(value);
        if (value.startsWith("0x"))
            return new _31(value.slice(2));
        return _31.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _31.create(value);
    }
    intoOrThrow() {
        const mask = (BN_1 << this.bitsn) - BN_1;
        const value = _libs_bigint_bigint_mjs__WEBPACK_IMPORTED_MODULE_2__/* .BigInts */ .l.decodeRaw(this.value);
        if ((value & mask) >> (this.bitsn - BN_1))
            return -(((~value) & mask) + BN_1);
        return value;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int224`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        return new _31(cursor.readOrThrow(64));
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_28 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__addDisposableResource */ .b)(env_28, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_28) {
            env_28.error = e_28;
            env_28.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__disposeResources */ .f)(env_28);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _31.bytes;
        const content = cursor.readOrThrow(_31.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _31(value);
    }
}
_31 = ZeroHexAbiInt224;
var AbiInt232;
(function (AbiInt232) {
    AbiInt232.dynamic = false;
    AbiInt232.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiInt232.create(value);
        return ZeroHexAbiInt232.create(value);
    }
    AbiInt232.create = create;
    function from(value) {
        return AbiInt232.create(value);
    }
    AbiInt232.from = from;
    function codegen() {
        return `Abi.Int232`;
    }
    AbiInt232.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiInt232.decodeOrThrow(cursor);
    }
    AbiInt232.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiInt232.readOrThrow(cursor);
    }
    AbiInt232.readOrThrow = readOrThrow;
})(AbiInt232 || (AbiInt232 = {}));
class BytesAbiInt232 {
    value;
    #class = _32;
    name = this.#class.name;
    static bytes = 29;
    static nibbles = 58;
    static bits = 232;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _32(value);
    }
    static from(value) {
        return _32.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiInt232(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiInt232(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int232`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _32.nibbles;
        const content = cursor.readOrThrow(_32.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _32(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - _32.bytes);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _32.bytes;
        const content = cursor.readOrThrow(_32.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _32(value);
    }
}
_32 = BytesAbiInt232;
class ZeroHexAbiInt232 {
    value;
    #class = _33;
    name = this.#class.name;
    static bytes = 29;
    static nibbles = 58;
    static bits = 232;
    static bitsn = BigInt(232);
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    bitsn = this.#class.bitsn;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return _33.fromBigInt(BigInt(value));
    }
    static fromBigInt(value) {
        if (value >= BN_0)
            return new _33(value.toString(16));
        const mask = (BN_1 << 256n) - BN_1;
        const value2 = ((~(-value)) & mask) + BN_1;
        return new _33(value2.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _33.fromBigInt(value);
        if (typeof value === "number")
            return _33.fromNumber(value);
        if (value.startsWith("0x"))
            return new _33(value.slice(2));
        return _33.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _33.create(value);
    }
    intoOrThrow() {
        const mask = (BN_1 << this.bitsn) - BN_1;
        const value = _libs_bigint_bigint_mjs__WEBPACK_IMPORTED_MODULE_2__/* .BigInts */ .l.decodeRaw(this.value);
        if ((value & mask) >> (this.bitsn - BN_1))
            return -(((~value) & mask) + BN_1);
        return value;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int232`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        return new _33(cursor.readOrThrow(64));
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_29 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__addDisposableResource */ .b)(env_29, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_29) {
            env_29.error = e_29;
            env_29.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__disposeResources */ .f)(env_29);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _33.bytes;
        const content = cursor.readOrThrow(_33.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _33(value);
    }
}
_33 = ZeroHexAbiInt232;
var AbiInt240;
(function (AbiInt240) {
    AbiInt240.dynamic = false;
    AbiInt240.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiInt240.create(value);
        return ZeroHexAbiInt240.create(value);
    }
    AbiInt240.create = create;
    function from(value) {
        return AbiInt240.create(value);
    }
    AbiInt240.from = from;
    function codegen() {
        return `Abi.Int240`;
    }
    AbiInt240.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiInt240.decodeOrThrow(cursor);
    }
    AbiInt240.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiInt240.readOrThrow(cursor);
    }
    AbiInt240.readOrThrow = readOrThrow;
})(AbiInt240 || (AbiInt240 = {}));
class BytesAbiInt240 {
    value;
    #class = _34;
    name = this.#class.name;
    static bytes = 30;
    static nibbles = 60;
    static bits = 240;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _34(value);
    }
    static from(value) {
        return _34.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiInt240(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiInt240(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int240`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _34.nibbles;
        const content = cursor.readOrThrow(_34.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _34(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - _34.bytes);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _34.bytes;
        const content = cursor.readOrThrow(_34.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _34(value);
    }
}
_34 = BytesAbiInt240;
class ZeroHexAbiInt240 {
    value;
    #class = _35;
    name = this.#class.name;
    static bytes = 30;
    static nibbles = 60;
    static bits = 240;
    static bitsn = BigInt(240);
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    bitsn = this.#class.bitsn;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return _35.fromBigInt(BigInt(value));
    }
    static fromBigInt(value) {
        if (value >= BN_0)
            return new _35(value.toString(16));
        const mask = (BN_1 << 256n) - BN_1;
        const value2 = ((~(-value)) & mask) + BN_1;
        return new _35(value2.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _35.fromBigInt(value);
        if (typeof value === "number")
            return _35.fromNumber(value);
        if (value.startsWith("0x"))
            return new _35(value.slice(2));
        return _35.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _35.create(value);
    }
    intoOrThrow() {
        const mask = (BN_1 << this.bitsn) - BN_1;
        const value = _libs_bigint_bigint_mjs__WEBPACK_IMPORTED_MODULE_2__/* .BigInts */ .l.decodeRaw(this.value);
        if ((value & mask) >> (this.bitsn - BN_1))
            return -(((~value) & mask) + BN_1);
        return value;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int240`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        return new _35(cursor.readOrThrow(64));
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_30 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__addDisposableResource */ .b)(env_30, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_30) {
            env_30.error = e_30;
            env_30.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__disposeResources */ .f)(env_30);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _35.bytes;
        const content = cursor.readOrThrow(_35.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _35(value);
    }
}
_35 = ZeroHexAbiInt240;
var AbiInt248;
(function (AbiInt248) {
    AbiInt248.dynamic = false;
    AbiInt248.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiInt248.create(value);
        return ZeroHexAbiInt248.create(value);
    }
    AbiInt248.create = create;
    function from(value) {
        return AbiInt248.create(value);
    }
    AbiInt248.from = from;
    function codegen() {
        return `Abi.Int248`;
    }
    AbiInt248.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiInt248.decodeOrThrow(cursor);
    }
    AbiInt248.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiInt248.readOrThrow(cursor);
    }
    AbiInt248.readOrThrow = readOrThrow;
})(AbiInt248 || (AbiInt248 = {}));
class BytesAbiInt248 {
    value;
    #class = _36;
    name = this.#class.name;
    static bytes = 31;
    static nibbles = 62;
    static bits = 248;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _36(value);
    }
    static from(value) {
        return _36.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiInt248(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiInt248(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int248`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _36.nibbles;
        const content = cursor.readOrThrow(_36.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _36(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - _36.bytes);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _36.bytes;
        const content = cursor.readOrThrow(_36.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _36(value);
    }
}
_36 = BytesAbiInt248;
class ZeroHexAbiInt248 {
    value;
    #class = _37;
    name = this.#class.name;
    static bytes = 31;
    static nibbles = 62;
    static bits = 248;
    static bitsn = BigInt(248);
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    bitsn = this.#class.bitsn;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return _37.fromBigInt(BigInt(value));
    }
    static fromBigInt(value) {
        if (value >= BN_0)
            return new _37(value.toString(16));
        const mask = (BN_1 << 256n) - BN_1;
        const value2 = ((~(-value)) & mask) + BN_1;
        return new _37(value2.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _37.fromBigInt(value);
        if (typeof value === "number")
            return _37.fromNumber(value);
        if (value.startsWith("0x"))
            return new _37(value.slice(2));
        return _37.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _37.create(value);
    }
    intoOrThrow() {
        const mask = (BN_1 << this.bitsn) - BN_1;
        const value = _libs_bigint_bigint_mjs__WEBPACK_IMPORTED_MODULE_2__/* .BigInts */ .l.decodeRaw(this.value);
        if ((value & mask) >> (this.bitsn - BN_1))
            return -(((~value) & mask) + BN_1);
        return value;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int248`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        return new _37(cursor.readOrThrow(64));
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_31 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__addDisposableResource */ .b)(env_31, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_31) {
            env_31.error = e_31;
            env_31.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__disposeResources */ .f)(env_31);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _37.bytes;
        const content = cursor.readOrThrow(_37.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _37(value);
    }
}
_37 = ZeroHexAbiInt248;
var AbiInt256;
(function (AbiInt256) {
    AbiInt256.dynamic = false;
    AbiInt256.size = 32;
    function create(value) {
        if (value instanceof Uint8Array)
            return BytesAbiInt256.create(value);
        return ZeroHexAbiInt256.create(value);
    }
    AbiInt256.create = create;
    function from(value) {
        return AbiInt256.create(value);
    }
    AbiInt256.from = from;
    function codegen() {
        return `Abi.Int256`;
    }
    AbiInt256.codegen = codegen;
    function decodeOrThrow(cursor) {
        return ZeroHexAbiInt256.decodeOrThrow(cursor);
    }
    AbiInt256.decodeOrThrow = decodeOrThrow;
    function readOrThrow(cursor) {
        return BytesAbiInt256.readOrThrow(cursor);
    }
    AbiInt256.readOrThrow = readOrThrow;
})(AbiInt256 || (AbiInt256 = {}));
class BytesAbiInt256 {
    value;
    #class = _38;
    name = this.#class.name;
    static bytes = 32;
    static nibbles = 64;
    static bits = 256;
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static create(value) {
        return new _38(value);
    }
    static from(value) {
        return _38.create(value);
    }
    intoOrThrow() {
        return new ZeroHexAbiInt256(this.encodePackedOrThrow()).intoOrThrow();
    }
    toJSON() {
        return new ZeroHexAbiInt256(this.encodePackedOrThrow()).toJSON();
    }
    static codegen() {
        return `Abi.Int256`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value).padStart(64, "0");
    }
    encodePackedOrThrow() {
        return _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(this.value);
    }
    static decodeOrThrow(cursor) {
        cursor.offset += 64 - _38.nibbles;
        const content = cursor.readOrThrow(_38.nibbles);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(content).copyAndDispose();
        return new _38(value);
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        cursor.fillOrThrow(0, 32 - _38.bytes);
        cursor.writeOrThrow(this.value);
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _38.bytes;
        const content = cursor.readOrThrow(_38.bytes);
        const value = _hazae41_bytes__WEBPACK_IMPORTED_MODULE_1__/* .Bytes */ .J.from(content);
        return new _38(value);
    }
}
_38 = BytesAbiInt256;
class ZeroHexAbiInt256 {
    value;
    #class = _39;
    name = this.#class.name;
    static bytes = 32;
    static nibbles = 64;
    static bits = 256;
    static bitsn = BigInt(256);
    static dynamic = false;
    static size = 32;
    bytes = this.#class.bytes;
    nibbles = this.#class.nibbles;
    bits = this.#class.bits;
    bitsn = this.#class.bitsn;
    dynamic = this.#class.dynamic;
    size = this.#class.size;
    constructor(value) {
        this.value = value;
    }
    static fromNumber(value) {
        return _39.fromBigInt(BigInt(value));
    }
    static fromBigInt(value) {
        if (value >= BN_0)
            return new _39(value.toString(16));
        const mask = (BN_1 << 256n) - BN_1;
        const value2 = ((~(-value)) & mask) + BN_1;
        return new _39(value2.toString(16));
    }
    static create(value) {
        if (typeof value === "bigint")
            return _39.fromBigInt(value);
        if (typeof value === "number")
            return _39.fromNumber(value);
        if (value.startsWith("0x"))
            return new _39(value.slice(2));
        return _39.fromBigInt(BigInt(value));
    }
    static from(value) {
        return _39.create(value);
    }
    intoOrThrow() {
        const mask = (BN_1 << this.bitsn) - BN_1;
        const value = _libs_bigint_bigint_mjs__WEBPACK_IMPORTED_MODULE_2__/* .BigInts */ .l.decodeRaw(this.value);
        if ((value & mask) >> (this.bitsn - BN_1))
            return -(((~value) & mask) + BN_1);
        return value;
    }
    toJSON() {
        return this.intoOrThrow().toString();
    }
    static codegen() {
        return `Abi.Int256`;
    }
    get class() {
        return this.#class;
    }
    encodeOrThrow() {
        return this.value.padStart(64, "0");
    }
    encodePackedOrThrow() {
        return this.value;
    }
    static decodeOrThrow(cursor) {
        return new _39(cursor.readOrThrow(64));
    }
    sizeOrThrow() {
        return this.size;
    }
    writeOrThrow(cursor) {
        const env_32 = { stack: [], error: void 0, hasError: false };
        try {
            const slice = (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__addDisposableResource */ .b)(env_32, _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().padStartAndDecodeOrThrow(this.value), false);
            cursor.fillOrThrow(0, 32 - slice.bytes.length);
            cursor.writeOrThrow(slice.bytes);
        }
        catch (e_32) {
            env_32.error = e_32;
            env_32.hasError = true;
        }
        finally {
            (0,_node_modules_tslib_tslib_es6_mjs__WEBPACK_IMPORTED_MODULE_3__/* .__disposeResources */ .f)(env_32);
        }
    }
    static readOrThrow(cursor) {
        cursor.offset += 32 - _39.bytes;
        const content = cursor.readOrThrow(_39.bytes);
        const value = _hazae41_base16__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U().encodeOrThrow(content);
        return new _39(value);
    }
}
_39 = ZeroHexAbiInt256;
const intByName = {
    int8: AbiInt8,
    int16: AbiInt16,
    int24: AbiInt24,
    int32: AbiInt32,
    int40: AbiInt40,
    int48: AbiInt48,
    int56: AbiInt56,
    int64: AbiInt64,
    int72: AbiInt72,
    int80: AbiInt80,
    int88: AbiInt88,
    int96: AbiInt96,
    int104: AbiInt104,
    int112: AbiInt112,
    int120: AbiInt120,
    int128: AbiInt128,
    int136: AbiInt136,
    int144: AbiInt144,
    int152: AbiInt152,
    int160: AbiInt160,
    int168: AbiInt168,
    int176: AbiInt176,
    int184: AbiInt184,
    int192: AbiInt192,
    int200: AbiInt200,
    int208: AbiInt208,
    int216: AbiInt216,
    int224: AbiInt224,
    int232: AbiInt232,
    int240: AbiInt240,
    int248: AbiInt248,
    int256: AbiInt256,
};


//# sourceMappingURL=int.mjs.map


/***/ })

}]);