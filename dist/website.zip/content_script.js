/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
var __webpack_exports__ = {};

;// CONCATENATED MODULE: ./node_modules/@hazae41/symbol-dispose-polyfill/dist/esm/mods/symbol-dispose-polyfill/polyfill.mjs
if (typeof Symbol.dispose !== "symbol")
    Object.defineProperty(Symbol, "dispose", {
        configurable: false,
        enumerable: false,
        writable: false,
        value: Symbol.for("dispose")
    });
if (typeof Symbol.asyncDispose !== "symbol")
    Object.defineProperty(Symbol, "asyncDispose", {
        configurable: false,
        enumerable: false,
        writable: false,
        value: Symbol.for("asyncDispose")
    });
//# sourceMappingURL=polyfill.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/symbol-dispose-polyfill/dist/esm/index.mjs

//# sourceMappingURL=index.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/future/dist/esm/mods/future/future.mjs
class Future {
    #resolve;
    #reject;
    promise;
    /**
     * Just like a Promise but you can manually resolve or reject it
     */
    constructor() {
        this.promise = new Promise((subresolve, subreject) => {
            this.#resolve = subresolve;
            this.#reject = subreject;
        });
    }
    get resolve() {
        return this.#resolve;
    }
    get reject() {
        return this.#reject;
    }
}


//# sourceMappingURL=future.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/errors.mjs


class Unimplemented extends (/* unused pure expression or super */ null && (Error)) {
    #class = Unimplemented;
    name = this.#class.name;
    constructor(options) {
        super(`Something is not implemented`, options);
    }
}
class AssertError extends Error {
    #class = AssertError;
    name = this.#class.name;
    constructor(options) {
        super(`Some assertion failed`, options);
    }
}
class Panic extends Error {
    #class = Panic;
    name = this.#class.name;
    static from(cause) {
        return new Panic(`Something was not expected`, { cause });
    }
    static fromAndThrow(cause) {
        throw new Panic(`Something was not expected`, { cause });
    }
}
class Catched extends Error {
    #class = Catched;
    name = this.#class.name;
    constructor(options) {
        super(`Something has been catched`, options);
    }
    static from(cause) {
        return new Catched({ cause });
    }
    static fromAndThrow(cause) {
        throw new Catched({ cause });
    }
    /**
     * Throw if `Catched`, wrap in `Err` otherwise
     * @param error
     * @returns `Err(error)` if not `Catched`
     * @throws `error.cause` if `Catched`
     */
    static throwOrErr(error) {
        if (error instanceof Catched)
            throw error.cause;
        return new err_Err(error);
    }
}


//# sourceMappingURL=errors.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/option/dist/esm/mods/option/option.mjs



var Option;
(function (Option) {
    function from(init) {
        if ("inner" in init)
            return new some_Some(init.inner);
        return new none_None();
    }
    Option.from = from;
    /**
     * Create an Option from a nullable value
     * @param inner
     * @returns `Some<T>` if `T`, `None` if `undefined`
     */
    function wrap(inner) {
        if (inner == null)
            return new none_None();
        return new some_Some(inner);
    }
    Option.wrap = wrap;
    async function map(inner, mapper) {
        return Option.wrap(inner).map(mapper).then(o => o.get());
    }
    Option.map = map;
    function mapSync(inner, mapper) {
        return Option.wrap(inner).mapSync(mapper).get();
    }
    Option.mapSync = mapSync;
    function unwrap(inner) {
        return Option.wrap(inner).unwrap();
    }
    Option.unwrap = unwrap;
})(Option || (Option = {}));


//# sourceMappingURL=option.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/result.mjs





var Result;
(function (Result) {
    Result.debug = false;
    /**
     * Create a Result from a maybe Error value
     * @param inner
     * @returns `Ok<T>` if `T`, `Err<Error>` if `Error`
     */
    function from(inner) {
        if (inner instanceof Error)
            return new err_Err(inner);
        else
            return new ok_Ok(inner);
    }
    Result.from = from;
    /**
     * Create a Result from a boolean
     * @param value
     * @returns
     */
    function assert(value) {
        return value ? ok_Ok.void() : new err_Err(new AssertError());
    }
    Result.assert = assert;
    function rewrap(wrapper) {
        try {
            return new ok_Ok(wrapper.unwrap());
        }
        catch (error) {
            return new err_Err(error);
        }
    }
    Result.rewrap = rewrap;
    /**
     * Catch an Err thrown from Err.throw
     * @param callback
     * @param type
     * @returns `Ok<T>` if no `Err` was thrown, `Err<E>` otherwise
     * @see Err.throw
     */
    async function unthrow(callback) {
        let ref;
        try {
            return await callback((e) => ref = e);
        }
        catch (e) {
            if (ref !== undefined)
                return ref;
            throw e;
        }
    }
    Result.unthrow = unthrow;
    /**
     * Catch an Err thrown from Err.throw
     * @param callback
     * @param type
     * @returns `Ok<T>` if no `Err` was thrown, `Err<E>` otherwise
     * @see Err.throw
     */
    function unthrowSync(callback) {
        let ref;
        try {
            return callback((e) => ref = e);
        }
        catch (e) {
            if (ref !== undefined)
                return ref;
            throw e;
        }
    }
    Result.unthrowSync = unthrowSync;
    /**
     * Run a callback and wrap any returned value in Ok<T> and any thrown error in Err<unknown>
     * @param callback
     * @returns
     */
    async function runAndWrap(callback) {
        try {
            return new ok_Ok(await callback());
        }
        catch (e) {
            return new err_Err(e);
        }
    }
    Result.runAndWrap = runAndWrap;
    /**
     * Run a callback and wrap any returned value in Ok<T> and any thrown error in Err<unknown>
     * @param callback
     * @returns
     */
    function runAndWrapSync(callback) {
        try {
            return new ok_Ok(callback());
        }
        catch (e) {
            return new err_Err(e);
        }
    }
    Result.runAndWrapSync = runAndWrapSync;
    /**
     * Run a callback and wrap any returned value in Ok<T> and any thrown error in Err<Catched>
     * @param callback
     * @returns
     */
    async function runAndDoubleWrap(callback) {
        try {
            return new ok_Ok(await callback());
        }
        catch (e) {
            return new err_Err(Catched.from(e));
        }
    }
    Result.runAndDoubleWrap = runAndDoubleWrap;
    /**
     * Run a callback and wrap any returned value in Ok<T> and any thrown error in Err<Catched>
     * @param callback
     * @returns
     */
    function runAndDoubleWrapSync(callback) {
        try {
            return new ok_Ok(callback());
        }
        catch (e) {
            return new err_Err(Catched.from(e));
        }
    }
    Result.runAndDoubleWrapSync = runAndDoubleWrapSync;
    /**
     * Run a callback and wrap any thrown error in Err<unknown>
     * @param callback
     * @returns
     */
    async function runOrWrap(callback) {
        try {
            return await callback();
        }
        catch (e) {
            return new err_Err(e);
        }
    }
    Result.runOrWrap = runOrWrap;
    /**
     * Run a callback and wrap any thrown error in Err<unknown>
     * @param callback
     * @returns
     */
    function runOrWrapSync(callback) {
        try {
            return callback();
        }
        catch (e) {
            return new err_Err(e);
        }
    }
    Result.runOrWrapSync = runOrWrapSync;
    /**
     * Run a callback and wrap any thrown error in Err<unknown>
     * @param callback
     * @returns
     */
    async function runOrDoubleWrap(callback) {
        try {
            return await callback();
        }
        catch (e) {
            return new err_Err(Catched.from(e));
        }
    }
    Result.runOrDoubleWrap = runOrDoubleWrap;
    /**
     * Run a callback and wrap any thrown error in Err<unknown>
     * @param callback
     * @returns
     */
    function runOrDoubleWrapSync(callback) {
        try {
            return callback();
        }
        catch (e) {
            return new err_Err(Catched.from(e));
        }
    }
    Result.runOrDoubleWrapSync = runOrDoubleWrapSync;
    /**
     * Transform `Iterable<Result<T,E>` into `Result<Array<T>, E>`
     * @param iterable
     * @returns `Result<Array<T>, E>`
     */
    function all(iterable) {
        return collect(iterate(iterable));
    }
    Result.all = all;
    function maybeAll(iterable) {
        return maybeCollect(maybeIterate(iterable));
    }
    Result.maybeAll = maybeAll;
    /**
     * Transform `Iterable<Result<T,E>` into `Iterator<T, Result<void, E>>`
     * @param iterable
     * @returns `Iterator<T, Result<void, E>>`
     */
    function* iterate(iterable) {
        for (const result of iterable) {
            if (result.isOk())
                yield result.get();
            else
                return result;
        }
        return ok_Ok.void();
    }
    Result.iterate = iterate;
    function* maybeIterate(iterable) {
        for (const result of iterable) {
            if (result == null)
                return result;
            else if (result.isOk())
                yield result.get();
            else
                return result;
        }
        return ok_Ok.void();
    }
    Result.maybeIterate = maybeIterate;
    /**
     * Transform `Iterator<T, Result<void, E>>` into `Result<Array<T>, E>`
     * @param iterator `Result<Array<T>, E>`
     */
    function collect(iterator) {
        const array = new Array();
        let result = iterator.next();
        for (; !result.done; result = iterator.next())
            array.push(result.value);
        return result.value.set(array);
    }
    Result.collect = collect;
    function maybeCollect(iterator) {
        const array = new Array();
        let result = iterator.next();
        for (; !result.done; result = iterator.next())
            array.push(result.value);
        return Option.mapSync(result.value, result => result.set(array));
    }
    Result.maybeCollect = maybeCollect;
})(Result || (Result = {}));


//# sourceMappingURL=result.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/err.mjs




class err_Err {
    #inner;
    #timeout;
    /**
     * A failure
     * @param inner
     */
    constructor(inner) {
        this.#inner = inner;
        if (!Result.debug)
            return;
        const error = new Error(`An Err has not been handled properly`);
        this.#timeout = setTimeout(() => { throw error; }, 1000);
    }
    /**
     * Create an empty `Err`
     * @returns `Err(void)`
     */
    static void() {
        return new err_Err(undefined);
    }
    /**
     * Create an `Err`
     * @param inner
     * @returns `Err(inner)`
     */
    static new(inner) {
        return new err_Err(inner);
    }
    /**
     * Create an `Err` with an `Error` inside
     * @param message
     * @param options
     * @returns `Err<Error>`
     */
    static error(message, options) {
        return new err_Err(new Error(message, options));
    }
    get inner() {
        return this.#inner;
    }
    /**
     * Set this result as handled
     */
    ignore() {
        if (!this.#timeout)
            return this;
        clearTimeout(this.#timeout);
        this.#timeout = undefined;
        return this;
    }
    /**
     * Type guard for `Ok`
     * @returns `true` if `Ok`, `false` if `Err`
     */
    isOk() {
        return false;
    }
    /**
     * Returns true if the result is `Ok` and the value inside of it matches a predicate
     * @param okPredicate
     * @returns `true` if `Ok` and `await okPredicate(this.inner)`, `false` otherwise
     */
    async isOkAnd(okPredicate) {
        return false;
    }
    /**
     * Returns true if the result is `Ok` and the value inside of it matches a predicate
     * @param okPredicate
     * @returns `true` if `Ok` and `await okPredicate(this.inner)`, `false` otherwise
     */
    isOkAndSync(okPredicate) {
        return false;
    }
    /**
     * Type guard for `Err`
     * @returns `true` if `Err`, `false` if `Ok`
     */
    isErr() {
        return true;
    }
    /**
     * Returns true if the result is `Err` and the value inside of it matches a predicate
     * @param errPredicate
     * @returns `true` if `Err` and `await errPredicate(this.inner)`, `false` otherwise
     */
    async isErrAnd(errPredicate) {
        return await errPredicate(this.inner);
    }
    /**
     * Returns true if the result is `Err` and the value inside of it matches a predicate
     * @param errPredicate
     * @returns `true` if `Err` and `await errPredicate(this.inner)`, `false` otherwise
     */
    isErrAndSync(errPredicate) {
        return errPredicate(this.inner);
    }
    /**
     * Compile-time safely get Ok's inner type
     * @returns `this.inner`
     * @throws if `this` is `Err`
     */
    get() {
        throw new Panic();
    }
    /**
     * Compile-time safely get Err's inner type
     * @returns `this.inner`
     * @throws if `this` is `Ok`
     */
    getErr() {
        this.ignore();
        return this.inner;
    }
    /**
     * Transform `Result<T, E>` into `Option<T>`
     * @returns `Some(this.inner)` if `Ok`, `None` if `Err`
     */
    ok() {
        this.ignore();
        return new none_None();
    }
    /**
     * Transform `Result<T, E>` into `Option<E>`
     * @returns `Some(this.inner)` if `Err`, `None` if `Ok`
     */
    err() {
        this.ignore();
        return new some_Some(this.inner);
    }
    /**
     * Returns an iterator over the possibly contained value
     * @yields `this.inner` if `Ok`
     */
    *[Symbol.iterator]() {
        this.ignore();
        return;
    }
    /**
     * Transform `Result<T,E>` into `[T,E]`
     * @returns `[this.inner, undefined]` if `Ok`, `[undefined, this.inner]` if `Err`
     */
    split() {
        this.ignore();
        return [undefined, this.inner];
    }
    /**
     * Returns true if the result is an `Ok` value containing the given value
     * @param value
     * @returns `true` if `Ok` and `this.inner === value`, `false` otherwise
     */
    contains(value) {
        return false;
    }
    /**
     * Returns true if the result is an `Err` value containing the given value
     * @param value
     * @returns `true` if `Err` and `this.inner === value`, `false` otherwise
     */
    containsErr(value) {
        return this.inner === value;
    }
    /**
     * Get the inner value or throw to the closest `Result.unthrow`
     * @param thrower The thrower from `Result.unthrow`
     * @returns `this.inner` if `Ok`
     * @throws `undefined` if `Err`
     * @see Result.unthrow
     * @see Result.unthrowSync
     */
    throw(thrower) {
        thrower(this);
        throw this;
    }
    /**
     * Get the inner value or throw the inner error wrapped inside another Error
     * @param message
     * @returns `this.inner` if `Ok`, `Error(message, { cause: this.inner })` if `Err`
     */
    expect(message) {
        this.ignore();
        throw new Error(message, { cause: this.inner });
    }
    /**
     * Get the inner error or throw the inner value wrapped inside another Error
     * @param message
     * @returns `this.inner` if `Err`, `Error(message, { cause: this.inner })` if `Ok`
     */
    expectErr(message) {
        this.ignore();
        return this.inner;
    }
    /**
     * Get the inner value or panic
     * @returns `this.inner` if `Ok`
     * @throws `this.inner` if `Err`
     */
    unwrap() {
        this.ignore();
        throw this.inner;
    }
    /**
     * Get the inner error or panic
     * @returns `this.inner` if `Err`
     * @throws `this.inner` if `Ok`
     */
    unwrapErr() {
        this.ignore();
        return this.inner;
    }
    /**
     * Get the inner value or a default one
     * @param value
     * @returns `this.inner` if `Ok`, `value` if `Err`
     */
    unwrapOr(value) {
        this.ignore();
        return value;
    }
    /**
     * Get the inner value or compute a default one from the inner error
     * @param errMapper
     * @returns `this.inner` if `Ok`, `await errMapper(this.inner)` if `Err`
     * @throws if `await errMapper(this.inner)` throws
     */
    async unwrapOrElse(errMapper) {
        this.ignore();
        return await errMapper(this.inner);
    }
    /**
     * Get the inner value or compute a default one from the inner error
     * @param errMapper
     * @returns `this.inner` if `Ok`, `errMapper(this.inner)` if `Err`
     * @throws if `errMapper(this.inner)` throws
     */
    unwrapOrElseSync(errMapper) {
        this.ignore();
        return errMapper(this.inner);
    }
    /**
     * Transform Result<Promise<T>, E> into Promise<Result<T, E>>
     * @returns `await this.inner` if `Ok`, `this` if `Err`
     */
    async await() {
        return this;
    }
    /**
     * Transform Result<T, Promise<E>> into Promise<Result<T, E>>
     * @returns `await this.inner` if `Err`, `this` if `Ok`
     */
    async awaitErr() {
        return new err_Err(await this.inner);
    }
    /**
     * Transform Result<Promise<T>, Promise<E>> into Promise<Result<T, E>>
     * @returns `await this.inner`
     */
    async awaitAll() {
        return await this.awaitErr();
    }
    /**
     * Transform `Result<T, E>` into `Result<void, E>`
     * @returns `Ok<void>` if `Ok<T>`, `Err<E>` if `E<E>`
     */
    clear() {
        return this;
    }
    /**
     * Transform `Result<T, E>` into `Result<T, void>`
     * @returns `Ok<T>` if `Ok<T>`, `Err<void>` if `E<E>`
     */
    clearErr() {
        this.ignore();
        return err_Err.void();
    }
    /**
     * Calls the given callback with the inner value if `Ok`
     * @param okCallback
     * @returns `this`
     */
    async inspect(okCallback) {
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Ok`
     * @param okCallback
     * @returns `this`
     */
    inspectSync(okCallback) {
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Err`
     * @param errCallback
     * @returns `this`
     */
    async inspectErr(errCallback) {
        await errCallback(this.inner);
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Err`
     * @param errCallback
     * @returns `this`
     */
    inspectErrSync(errCallback) {
        errCallback(this.inner);
        return this;
    }
    /**
     * Return a new `Ok` but with the given `inner`
     * @param inner
     * @returns `Ok(inner)` if `Ok`, `this` if `Err`
     */
    set(inner) {
        return this;
    }
    /**
     * Return a new `Err` but with the given `inner`
     * @param inner
     * @returns `Err(inner)` if `Err`, `this` if `Ok`
     */
    setErr(inner) {
        return new err_Err(inner);
    }
    /**
     * Map the inner value into another
     * @param okMapper
     * @returns `Ok(await okMapper(this.inner))` if `Ok`, `this` if `Err`
     * @throws if `await okMapper(this.inner)` throws
     */
    async map(okMapper) {
        return this;
    }
    /**
     * Map the inner value into another
     * @param okMapper
     * @returns `Ok(okMapper(this.inner))` if `Ok`, `this` if `Err`
     * @throws if `okMapper(this.inner)` throws
     */
    mapSync(okMapper) {
        return this;
    }
    /**
     * Map the inner error into another
     * @param errMapper
     * @returns `Err(await errMapper(this.inner))` if `Err`, `this` if `Ok`
     * @throws if `await errMapper(this.inner)` throws
     */
    async mapErr(errMapper) {
        this.ignore();
        return new err_Err(await errMapper(this.inner));
    }
    /**
     * Map the inner error into another
     * @param errMapper
     * @returns `Err(errMapper(this.inner))` if `Err`, `this` if `Ok`
     * @throws if `errMapper(this.inner)` throws
     */
    mapErrSync(errMapper) {
        this.ignore();
        return new err_Err(errMapper(this.inner));
    }
    /**
     * Map the inner value into another, or a default one
     * @param value
     * @param okMapper
     * @returns `await okMapper(this.inner)` if `Ok`, `value` if `Err`
     * @throws if `await okMapper(this.inner)` throws
     */
    async mapOr(value, okMapper) {
        this.ignore();
        return value;
    }
    /**
     * Map the inner value into another, or a default one
     * @param value
     * @param okMapper
     * @returns `okMapper(this.inner)` if `Ok`, `value` if `Err`
     * @throws if `okMapper(this.inner)` throws
     */
    mapOrSync(value, okMapper) {
        this.ignore();
        return value;
    }
    /**
     * Map the inner value into another, or a default one
     * @param errMapper
     * @param okMapper
     * @returns `await okMapper(this.inner)` if `Ok`, `await errMapper(this.inner)` if `Err`
     * @throws if `await okMapper(this.inner)` or `await errMapper(this.inner)` throws
     */
    async mapOrElse(errMapper, okMapper) {
        this.ignore();
        return await errMapper(this.inner);
    }
    /**
     * Map the inner value into another, or a default one
     * @param errMapper
     * @param okMapper
     * @returns `okMapper(this.inner)` if `Ok`, `errMapper(this.inner)` if `Err`
     * @throws if `okMapper(this.inner)` or `errMapper(this.inner)` throws
     */
    mapOrElseSync(errMapper, okMapper) {
        this.ignore();
        return errMapper(this.inner);
    }
    /**
     * Return `value` if `Ok`, return `this` if `Err`
     * @param value
     * @returns `value` if `Ok`, `this` if `Err`
     */
    and(value) {
        return this;
    }
    /**
     * Return `await okMapper(this.inner)` if `Ok`, return `this` if `Err`
     * @param okMapper
     * @returns `await okMapper(this.inner)` if `Ok`, `this` if `Err`
     * @throws if `await okMapper(this.inner)` throws
     */
    async andThen(okMapper) {
        return this;
    }
    /**
     * Return `okMapper(this.inner)` if `Ok`, return `this` if `Err`
     * @param okMapper
     * @returns `okMapper(this.inner)` if `Ok`, `this` if `Err`
     * @throws if `okMapper(this.inner)` throws
     */
    andThenSync(okMapper) {
        return this;
    }
    /**
     * Return `value` if `Err`, return `this` if `Ok`
     * @param value
     * @returns `value` if `Err`, `this` if `Ok`
     */
    or(value) {
        this.ignore();
        return value;
    }
    /**
     * Return `await errMapper(this.inner)` if `Err`, return `this` if `Ok`
     * @param errMapper
     * @returns `await errMapper(this.inner)` if `Err`, `this` if `Ok`
     * @throws if `await errMapper(this.inner)` throws
     */
    async orElse(errMapper) {
        this.ignore();
        return await errMapper(this.inner);
    }
    /**
     * Return `errMapper(this.inner)` if `Err`, return `this` if `Ok`
     * @param errMapper
     * @returns `errMapper(this.inner)` if `Err`, `this` if `Ok`
     * @throws if `errMapper(this.inner)` throws
     */
    orElseSync(errMapper) {
        this.ignore();
        return errMapper(this.inner);
    }
    /**
     * Transform Result<Result<T, E1>, E2> into Result<T, E1 | E2>
     * @param result
     * @returns `this` if `Err`, `this.inner` if `Ok`
     */
    flatten() {
        return this;
    }
}


//# sourceMappingURL=err.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/option/dist/esm/mods/option/none.mjs


class NoneError extends Error {
    constructor() {
        super(`Option is a None`);
    }
}
class none_None {
    inner;
    /**
     * An empty value
     */
    constructor(inner = undefined) {
        this.inner = inner;
    }
    /**
     * Create a `None`
     * @returns `None`
     */
    static new() {
        return new none_None();
    }
    static from(init) {
        return new none_None();
    }
    /**
     * Type guard for `Some`
     * @returns `true` if `Some`, `false` if `None`
     */
    isSome() {
        return false;
    }
    /**
     * Returns `true` if the option is a `Some` and the value inside of it matches a predicate
     * @param somePredicate
     * @returns `true` if `Some` and `await somePredicate(this.inner)`, `None` otherwise
     */
    async isSomeAnd(somePredicate) {
        return false;
    }
    /**
     * Returns `true` if the option is a `Some` and the value inside of it matches a predicate
     * @param somePredicate
     * @returns `true` if `Some` and `somePredicate(this.inner)`, `None` otherwise
     */
    isSomeAndSync(somePredicate) {
        return false;
    }
    /**
     * Type guard for `None`
     * @returns `true` if `None`, `false` if `Some`
     */
    isNone() {
        return true;
    }
    /**
     * Compile-time safely get `this.inner`
     * @returns `this.inner`
     */
    get() {
        return this.inner;
    }
    /**
     * Returns an iterator over the possibly contained value
     * @yields `this.inner` if `Some`
     */
    *[Symbol.iterator]() {
        return;
    }
    /**
     * Get the inner value if `Some`, throw `Error(message)` otherwise
     * @param message
     * @returns `this.inner` if `Some`
     * @throws `Error(message)` if `None`
     */
    expect(message) {
        throw new Error(message);
    }
    /**
     * Get the inner value or throw a NoneError
     * @returns `this.inner` if `Some`
     * @throws `NoneError` if `None`
     */
    unwrap() {
        throw new Error(`A None has been unwrapped`);
    }
    /**
     * Get the inner value or a default one
     * @param value
     * @returns `this.inner` if `Some`, `value` if `None`
     */
    unwrapOr(value) {
        return value;
    }
    /**
     * Returns the contained `Some` value or computes it from a closure
     * @param noneCallback
     * @returns `this.inner` if `Some`, `await noneCallback()` if `None`
     */
    async unwrapOrElse(noneCallback) {
        return await noneCallback();
    }
    /**
     * Returns the contained `Some` value or computes it from a closure
     * @param noneCallback
     * @returns `this.inner` if `Some`, `noneCallback()` if `None`
     */
    unwrapOrElseSync(noneCallback) {
        return noneCallback();
    }
    /**
     * Transform `Option<T>` into `Result<T, NoneError>`
     * @returns `Ok(this.inner)` if `Some`, `Err(NoneError)` if `None`
     */
    ok() {
        return new err_Err(new NoneError());
    }
    /**
     * Transform `Option<T>` into `Result<T, E>`
     * @param error
     * @returns `Ok(this.inner)` if `Some`, `Err(error)` if `None`
     */
    okOr(error) {
        return new err_Err(error);
    }
    /**
     * Transforms the `Option<T>` into a `Result<T, E>`, mapping `Some(v)` to `Ok(v)` and `None` to `Err(err())`
     * @param noneCallback
     * @returns `Ok(this.inner)` if `Some`, `Err(await noneCallback())` is `None`
     */
    async okOrElse(noneCallback) {
        return new err_Err(await noneCallback());
    }
    /**
     * Transforms the `Option<T>` into a `Result<T, E>`, mapping `Some(v)` to `Ok(v)` and `None` to `Err(err())`
     * @param noneCallback
     * @returns `Ok(this.inner)` if `Some`, `Err(noneCallback())` is `None`
     */
    okOrElseSync(noneCallback) {
        return new err_Err(noneCallback());
    }
    /**
     * Returns `None` if the option is `None`, otherwise calls `somePredicate` with the wrapped value
     * @param somePredicate
     * @returns `Some` if `Some` and `await somePredicate(this.inner)`, `None` otherwise
     */
    async filter(somePredicate) {
        return this;
    }
    /**
     * Returns `None` if the option is `None`, otherwise calls `somePredicate` with the wrapped value
     * @param somePredicate
     * @returns `Some` if `Some` and `somePredicate(this.inner)`, `None` otherwise
     */
    filterSync(somePredicate) {
        return this;
    }
    /**
     * Transform `Option<Promise<T>>` into `Promise<Option<T>>`
     * @returns `Promise<Option<T>>`
     */
    async await() {
        return this;
    }
    /**
     * Returns `true` if the option is a `Some` value containing the given value
     * @param value
     * @returns `true` if `Some` and `this.inner === value`, `None` otherwise
     */
    contains(value) {
        return false;
    }
    /**
     * Calls the given callback with the inner value if `Ok`
     * @param someCallback
     * @returns `this`
     */
    async inspect(someCallback) {
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Ok`
     * @param someCallback
     * @returns `this`
     */
    inspectSync(someCallback) {
        return this;
    }
    /**
     * Maps an `Option<T>` to `Option<U>` by applying a function to a contained value (if `Some`) or returns `None` (if `None`)
     * @param someMapper
     * @returns `Some(await someMapper(this.inner))` if `Some`, `this` if `None`
     */
    async map(someMapper) {
        return this;
    }
    /**
     * Maps an `Option<T>` to `Option<U>` by applying a function to a contained value (if `Some`) or returns `None` (if `None`)
     * @param someMapper
     * @returns `Some(someMapper(this.inner))` if `Some`, `this` if `None`
     */
    mapSync(someMapper) {
        return this;
    }
    /**
     * Returns the provided default result (if none), or applies a function to the contained value (if any)
     * @param value
     * @param someMapper
     * @returns `value` if `None`, `await someMapper(this.inner)` if `Some`
     */
    async mapOr(value, someMapper) {
        return value;
    }
    /**
     * Returns the provided default result (if none), or applies a function to the contained value (if any)
     * @param value
     * @param someMapper
     * @returns `value` if `None`, `someMapper(this.inner)` if `Some`
     */
    mapOrSync(value, someMapper) {
        return value;
    }
    /**
     * Computes a default function result (if none), or applies a different function to the contained value (if any)
     * @param noneCallback
     * @param someMapper
     * @returns `await someMapper(this.inner)` if `Some`, `await noneCallback()` if `None`
     */
    async mapOrElse(noneCallback, someMapper) {
        return await noneCallback();
    }
    /**
     * Computes a default function result (if none), or applies a different function to the contained value (if any)
     * @param noneCallback
     * @param someMapper
     * @returns `someMapper(this.inner)` if `Some`, `noneCallback()` if `None`
     */
    mapOrElseSync(noneCallback, someMapper) {
        return noneCallback();
    }
    /**
     * Returns `None` if the option is `None`, otherwise returns `value`
     * @param value
     * @returns `None` if `None`, `value` if `Some`
     */
    and(value) {
        return this;
    }
    /**
     * Returns `None` if the option is `None`, otherwise calls `someMapper` with the wrapped value and returns the result
     * @param someMapper
     * @returns `None` if `None`, `await someMapper(this.inner)` if `Some`
     */
    async andThen(someMapper) {
        return this;
    }
    /**
     * Returns `None` if the option is `None`, otherwise calls `someMapper` with the wrapped value and returns the result
     * @param someMapper
     * @returns `None` if `None`, `someMapper(this.inner)` if `Some`
     */
    andThenSync(someMapper) {
        return this;
    }
    /**
     * Returns `this` if `Some`, otherwise returns `value`
     * @param value
     * @returns `this` if `Some`, `value` if `None`
     */
    or(value) {
        return value;
    }
    /**
     * Returns `this` if `Some`, otherwise calls `noneCallback` and returns the result
     * @param noneCallback
     * @returns `this` if `Some`, `await noneCallback()` if `None`
     */
    async orElse(noneCallback) {
        return await noneCallback();
    }
    /**
     * Returns `this` if `Some`, otherwise calls `noneCallback` and returns the result
     * @param noneCallback
     * @returns `this` if `Some`, `noneCallback()` if `None`
     */
    orElseSync(noneCallback) {
        return noneCallback();
    }
    /**
     * Returns `Some` if exactly one of the options is `Some`, otherwise returns `None`
     * @param value
     * @returns `None` if both are `Some` or both are `None`, the only `Some` otherwise
     */
    xor(value) {
        return value;
    }
    /**
     * Zips `this` with another `Option`
     * @param other
     * @returns `Some([this.inner, other.inner])` if both are `Some`, `None` if one of them is `None`
     */
    zip(other) {
        return this;
    }
}


//# sourceMappingURL=none.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/option/dist/esm/mods/option/some.mjs



class some_Some {
    inner;
    /**
     * An existing value
     * @param inner
     */
    constructor(inner) {
        this.inner = inner;
    }
    /**
     * Create a `Some`
     * @param inner
     * @returns `Some(inner)`
     */
    static new(inner) {
        return new some_Some(inner);
    }
    static from(init) {
        return new some_Some(init.inner);
    }
    /**
     * Type guard for `Some`
     * @returns `true` if `Some`, `false` if `None`
     */
    isSome() {
        return true;
    }
    /**
     * Returns `true` if the option is a `Some` and the value inside of it matches a predicate
     * @param somePredicate
     * @returns `true` if `Some` and `await somePredicate(this.inner)`, `None` otherwise
     */
    async isSomeAnd(somePredicate) {
        return await somePredicate(this.inner);
    }
    /**
     * Returns `true` if the option is a `Some` and the value inside of it matches a predicate
     * @param somePredicate
     * @returns `true` if `Some` and `somePredicate(this.inner)`, `None` otherwise
     */
    isSomeAndSync(somePredicate) {
        return somePredicate(this.inner);
    }
    /**
     * Type guard for `None`
     * @returns `true` if `None`, `false` if `Some`
     */
    isNone() {
        return false;
    }
    /**
     * Compile-time safely get `this.inner`
     * @returns `this.inner`
     */
    get() {
        return this.inner;
    }
    /**
     * Returns an iterator over the possibly contained value
     * @yields `this.inner` if `Some`
     */
    *[Symbol.iterator]() {
        yield this.inner;
    }
    /**
     * Get the inner value if `Some`, throw `Error(message)` otherwise
     * @param message
     * @returns `this.inner` if `Some`
     * @throws `Error(message)` if `None`
     */
    expect(message) {
        return this.inner;
    }
    /**
     * Get the inner value or throw a NoneError
     * @returns `this.inner` if `Some`
     * @throws `NoneError` if `None`
     */
    unwrap() {
        return this.inner;
    }
    /**
     * Get the inner value or a default one
     * @param value
     * @returns `this.inner` if `Some`, `value` if `None`
     */
    unwrapOr(value) {
        return this.inner;
    }
    /**
     * Returns the contained `Some` value or computes it from a closure
     * @param noneCallback
     * @returns `this.inner` if `Some`, `await noneCallback()` if `None`
     */
    async unwrapOrElse(noneCallback) {
        return this.inner;
    }
    /**
     * Returns the contained `Some` value or computes it from a closure
     * @param noneCallback
     * @returns `this.inner` if `Some`, `noneCallback()` if `None`
     */
    unwrapOrElseSync(noneCallback) {
        return this.inner;
    }
    /**
     * Transform `Option<T>` into `Result<T, NoneError>`
     * @returns `Ok(this.inner)` if `Some`, `Err(NoneError)` if `None`
     */
    ok() {
        return new ok_Ok(this.inner);
    }
    /**
     * Transform `Option<T>` into `Result<T, E>`
     * @param error
     * @returns `Ok(this.inner)` if `Some`, `Err(error)` if `None`
     */
    okOr(error) {
        return new ok_Ok(this.inner);
    }
    /**
     * Transforms the `Option<T>` into a `Result<T, E>`, mapping `Some(v)` to `Ok(v)` and `None` to `Err(err())`
     * @param noneCallback
     * @returns `Ok(this.inner)` if `Some`, `Err(await noneCallback())` is `None`
     */
    async okOrElse(noneCallback) {
        return new ok_Ok(this.inner);
    }
    /**
     * Transforms the `Option<T>` into a `Result<T, E>`, mapping `Some(v)` to `Ok(v)` and `None` to `Err(err())`
     * @param noneCallback
     * @returns `Ok(this.inner)` if `Some`, `Err(noneCallback())` is `None`
     */
    okOrElseSync(noneCallback) {
        return new ok_Ok(this.inner);
    }
    /**
     * Returns `None` if the option is `None`, otherwise calls `somePredicate` with the wrapped value
     * @param somePredicate
     * @returns `Some` if `Some` and `await somePredicate(this.inner)`, `None` otherwise
     */
    async filter(somePredicate) {
        if (await somePredicate(this.inner))
            return this;
        else
            return new none_None();
    }
    /**
     * Returns `None` if the option is `None`, otherwise calls `somePredicate` with the wrapped value
     * @param somePredicate
     * @returns `Some` if `Some` and `somePredicate(this.inner)`, `None` otherwise
     */
    filterSync(somePredicate) {
        if (somePredicate(this.inner))
            return this;
        else
            return new none_None();
    }
    /**
     * Transform `Option<Promise<T>>` into `Promise<Option<T>>`
     * @returns `Promise<Option<T>>`
     */
    async await() {
        return new some_Some(await this.inner);
    }
    /**
     * Returns `true` if the option is a `Some` value containing the given value
     * @param value
     * @returns `true` if `Some` and `this.inner === value`, `None` otherwise
     */
    contains(value) {
        return this.inner === value;
    }
    /**
     * Calls the given callback with the inner value if `Ok`
     * @param someCallback
     * @returns `this`
     */
    async inspect(someCallback) {
        await someCallback(this.inner);
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Ok`
     * @param someCallback
     * @returns `this`
     */
    inspectSync(someCallback) {
        someCallback(this.inner);
        return this;
    }
    /**
     * Maps an `Option<T>` to `Option<U>` by applying a function to a contained value (if `Some`) or returns `None` (if `None`)
     * @param someMapper
     * @returns `Some(await someMapper(this.inner))` if `Some`, `this` if `None`
     */
    async map(someMapper) {
        return new some_Some(await someMapper(this.inner));
    }
    /**
     * Maps an `Option<T>` to `Option<U>` by applying a function to a contained value (if `Some`) or returns `None` (if `None`)
     * @param someMapper
     * @returns `Some(someMapper(this.inner))` if `Some`, `this` if `None`
     */
    mapSync(someMapper) {
        return new some_Some(someMapper(this.inner));
    }
    /**
     * Returns the provided default result (if none), or applies a function to the contained value (if any)
     * @param value
     * @param someMapper
     * @returns `value` if `None`, `await someMapper(this.inner)` if `Some`
     */
    async mapOr(value, someMapper) {
        return await someMapper(this.inner);
    }
    /**
     * Returns the provided default result (if none), or applies a function to the contained value (if any)
     * @param value
     * @param someMapper
     * @returns `value` if `None`, `someMapper(this.inner)` if `Some`
     */
    mapOrSync(value, someMapper) {
        return someMapper(this.inner);
    }
    /**
     * Computes a default function result (if none), or applies a different function to the contained value (if any)
     * @param noneCallback
     * @param someMapper
     * @returns `await someMapper(this.inner)` if `Some`, `await noneCallback()` if `None`
     */
    async mapOrElse(noneCallback, someMapper) {
        return await someMapper(this.inner);
    }
    /**
     * Computes a default function result (if none), or applies a different function to the contained value (if any)
     * @param noneCallback
     * @param someMapper
     * @returns `someMapper(this.inner)` if `Some`, `noneCallback()` if `None`
     */
    mapOrElseSync(noneCallback, someMapper) {
        return someMapper(this.inner);
    }
    /**
     * Returns `None` if the option is `None`, otherwise returns `value`
     * @param value
     * @returns `None` if `None`, `value` if `Some`
     */
    and(value) {
        return value;
    }
    /**
     * Returns `None` if the option is `None`, otherwise calls `someMapper` with the wrapped value and returns the result
     * @param someMapper
     * @returns `None` if `None`, `await someMapper(this.inner)` if `Some`
     */
    async andThen(someMapper) {
        return await someMapper(this.inner);
    }
    /**
     * Returns `None` if the option is `None`, otherwise calls `someMapper` with the wrapped value and returns the result
     * @param someMapper
     * @returns `None` if `None`, `someMapper(this.inner)` if `Some`
     */
    andThenSync(someMapper) {
        return someMapper(this.inner);
    }
    /**
     * Returns `this` if `Some`, otherwise returns `value`
     * @param value
     * @returns `this` if `Some`, `value` if `None`
     */
    or(value) {
        return this;
    }
    /**
     * Returns `this` if `Some`, otherwise calls `noneCallback` and returns the result
     * @param noneCallback
     * @returns `this` if `Some`, `await noneCallback()` if `None`
     */
    async orElse(noneCallback) {
        return this;
    }
    /**
     * Returns `this` if `Some`, otherwise calls `noneCallback` and returns the result
     * @param noneCallback
     * @returns `this` if `Some`, `noneCallback()` if `None`
     */
    orElseSync(noneCallback) {
        return this;
    }
    /**
     * Returns `Some` if exactly one of the options is `Some`, otherwise returns `None`
     * @param value
     * @returns `None` if both are `Some` or both are `None`, the only `Some` otherwise
     */
    xor(value) {
        if (value.isSome())
            return new none_None();
        else
            return this;
    }
    /**
     * Zips `this` with another `Option`
     * @param other
     * @returns `Some([this.inner, other.inner])` if both are `Some`, `None` if one of them is `None`
     */
    zip(other) {
        if (other.isSome())
            return new some_Some([this.inner, other.inner]);
        else
            return other;
    }
}


//# sourceMappingURL=some.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/ok.mjs




class ok_Ok {
    #inner;
    #timeout;
    /**
     * A success
     * @param inner
     */
    constructor(inner) {
        this.#inner = inner;
        if (!Result.debug)
            return;
        const error = new Error(`An Ok has not been handled properly`);
        this.#timeout = setTimeout(() => { throw error; }, 1000);
    }
    /**
     * Create an empty `Ok`
     * @returns `Ok(void)`
     */
    static void() {
        return new ok_Ok(undefined);
    }
    /**
     * Create an `Ok`
     * @param inner
     * @returns `Ok(inner)`
     */
    static new(inner) {
        return new ok_Ok(inner);
    }
    get inner() {
        return this.#inner;
    }
    /**
     * Set this result as handled
     */
    ignore() {
        if (!this.#timeout)
            return this;
        clearTimeout(this.#timeout);
        this.#timeout = undefined;
        return this;
    }
    /**
     * Type guard for `Ok`
     * @returns `true` if `Ok`, `false` if `Err`
     */
    isOk() {
        return true;
    }
    /**
     * Returns true if the result is `Ok` and the value inside of it matches a predicate
     * @param okPredicate
     * @returns `true` if `Ok` and `await okPredicate(this.inner)`, `false` otherwise
     */
    async isOkAnd(okPredicate) {
        return await okPredicate(this.inner);
    }
    /**
     * Returns true if the result is `Ok` and the value inside of it matches a predicate
     * @param okPredicate
     * @returns `true` if `Ok` and `await okPredicate(this.inner)`, `false` otherwise
     */
    isOkAndSync(okPredicate) {
        return okPredicate(this.inner);
    }
    /**
     * Type guard for `Err`
     * @returns `true` if `Err`, `false` if `Ok`
     */
    isErr() {
        return false;
    }
    /**
     * Returns true if the result is `Err` and the value inside of it matches a predicate
     * @param errPredicate
     * @returns `true` if `Err` and `await errPredicate(this.inner)`, `false` otherwise
     */
    async isErrAnd(errPredicate) {
        return false;
    }
    /**
     * Returns true if the result is `Err` and the value inside of it matches a predicate
     * @param errPredicate
     * @returns `true` if `Err` and `await errPredicate(this.inner)`, `false` otherwise
     */
    isErrAndSync(errPredicate) {
        return false;
    }
    /**
     * Compile-time safely get Ok's inner type
     * @returns `this.inner`
     * @throws if `this` is `Err`
     */
    get() {
        this.ignore();
        return this.inner;
    }
    /**
     * Compile-time safely get Err's inner type
     * @returns `this.inner`
     * @throws if `this` is `Ok`
     */
    getErr() {
        throw new Panic();
    }
    /**
     * Transform `Result<T, E>` into `Option<T>`
     * @returns `Some(this.inner)` if `Ok`, `None` if `Err`
     */
    ok() {
        this.ignore();
        return new some_Some(this.inner);
    }
    /**
     * Transform `Result<T, E>` into `Option<E>`
     * @returns `Some(this.inner)` if `Err`, `None` if `Ok`
     */
    err() {
        this.ignore();
        return new none_None();
    }
    /**
     * Returns an iterator over the possibly contained value
     * @yields `this.inner` if `Ok`
     */
    *[Symbol.iterator]() {
        this.ignore();
        yield this.inner;
    }
    /**
     * Transform `Result<T,E>` into `[T,E]`
     * @returns `[this.inner, undefined]` if `Ok`, `[undefined, this.inner]` if `Err`
     */
    split() {
        this.ignore();
        return [this.inner, undefined];
    }
    /**
     * Returns true if the result is an `Ok` value containing the given value
     * @param value
     * @returns `true` if `Ok` and `this.inner === value`, `false` otherwise
     */
    contains(value) {
        return this.inner === value;
    }
    /**
     * Returns true if the result is an `Err` value containing the given value
     * @param value
     * @returns `true` if `Err` and `this.inner === value`, `false` otherwise
     */
    containsErr(value) {
        return false;
    }
    /**
     * Just like `unwrap` but it throws to the closest `Result.unthrow`
     * @returns `this.inner` if `Ok`
     * @throws `this` if `Err`
     * @see Result.unthrow
     * @see Result.unthrowSync
     */
    throw(thrower) {
        this.ignore();
        return this.inner;
    }
    /**
     * Get the inner value or throw the inner error wrapped inside another Error
     * @param message
     * @returns `this.inner` if `Ok`, `Error(message, { cause: this.inner })` if `Err`
     */
    expect(message) {
        this.ignore();
        return this.inner;
    }
    /**
     * Get the inner error or throw the inner value wrapped inside another Error
     * @param message
     * @returns `this.inner` if `Err`, `Error(message, { cause: this.inner })` if `Ok`
     */
    expectErr(message) {
        this.ignore();
        throw new Error(message, { cause: this.inner });
    }
    /**
     * Get the inner value or panic
     * @returns `this.inner` if `Ok`
     * @throws `this.inner` if `Err`
     */
    unwrap() {
        this.ignore();
        return this.inner;
    }
    /**
     * Get the inner error or panic
     * @returns `this.inner` if `Err`
     * @throws `this.inner` if `Ok`
     */
    unwrapErr() {
        this.ignore();
        throw this.inner;
    }
    /**
     * Get the inner value or a default one
     * @param value
     * @returns `this.inner` if `Ok`, `value` if `Err`
     */
    unwrapOr(value) {
        this.ignore();
        return this.inner;
    }
    /**
     * Get the inner value or compute a default one from the inner error
     * @param errMapper
     * @returns `this.inner` if `Ok`, `await errMapper(this.inner)` if `Err`
     * @throws if `await errMapper(this.inner)` throws
     */
    async unwrapOrElse(errMapper) {
        this.ignore();
        return this.inner;
    }
    /**
     * Get the inner value or compute a default one from the inner error
     * @param errMapper
     * @returns `this.inner` if `Ok`, `errMapper(this.inner)` if `Err`
     * @throws if `errMapper(this.inner)` throws
     */
    unwrapOrElseSync(errMapper) {
        this.ignore();
        return this.inner;
    }
    /**
     * Transform Result<Promise<T>, E> into Promise<Result<T, E>>
     * @returns `await this.inner` if `Ok`, `this` if `Err`
     */
    async await() {
        return new ok_Ok(await this.inner);
    }
    /**
     * Transform Result<T, Promise<E>> into Promise<Result<T, E>>
     * @returns `await this.inner` if `Err`, `this` if `Ok`
     */
    async awaitErr() {
        return this;
    }
    /**
     * Transform Result<Promise<T>, Promise<E>> into Promise<Result<T, E>>
     * @returns `await this.inner`
     */
    async awaitAll() {
        return await this.await();
    }
    /**
     * Transform `Result<T, E>` into `Result<void, E>`
     * @returns `Ok<void>` if `Ok<T>`, `Err<E>` if `E<E>`
     */
    clear() {
        this.ignore();
        return ok_Ok.void();
    }
    /**
     * Transform `Result<T, E>` into `Result<T, void>`
     * @returns `Ok<T>` if `Ok<T>`, `Err<void>` if `E<E>`
     */
    clearErr() {
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Ok`
     * @param okCallback
     * @returns `this`
     */
    async inspect(okCallback) {
        await okCallback(this.inner);
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Ok`
     * @param okCallback
     * @returns `this`
     */
    inspectSync(okCallback) {
        okCallback(this.inner);
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Err`
     * @param errCallback
     * @returns `this`
     */
    async inspectErr(errCallback) {
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Err`
     * @param errCallback
     * @returns `this`
     */
    inspectErrSync(errCallback) {
        return this;
    }
    /**
     * Return a new `Ok` but with the given `inner`
     * @param inner
     * @returns `Ok(inner)` if `Ok`, `this` if `Err`
     */
    set(inner) {
        return new ok_Ok(inner);
    }
    /**
     * Return a new `Err` but with the given `inner`
     * @param inner
     * @returns `Err(inner)` if `Err`, `this` if `Ok`
     */
    setErr(inner) {
        return this;
    }
    /**
     * Map the inner value into another
     * @param okMapper
     * @returns `Ok(await okMapper(this.inner))` if `Ok`, `this` if `Err`
     * @throws if `await okMapper(this.inner)` throws
     */
    async map(okMapper) {
        this.ignore();
        return new ok_Ok(await okMapper(this.inner));
    }
    /**
     * Map the inner value into another
     * @param okMapper
     * @returns `Ok(okMapper(this.inner))` if `Ok`, `this` if `Err`
     * @throws if `okMapper(this.inner)` throws
     */
    mapSync(okMapper) {
        this.ignore();
        return new ok_Ok(okMapper(this.inner));
    }
    /**
     * Map the inner error into another
     * @param errMapper
     * @returns `Err(await errMapper(this.inner))` if `Err`, `this` if `Ok`
     * @throws if `await errMapper(this.inner)` throws
     */
    async mapErr(errMapper) {
        return this;
    }
    /**
     * Map the inner error into another
     * @param errMapper
     * @returns `Err(errMapper(this.inner))` if `Err`, `this` if `Ok`
     * @throws if `errMapper(this.inner)` throws
     */
    mapErrSync(errMapper) {
        return this;
    }
    /**
     * Map the inner value into another, or a default one
     * @param value
     * @param okMapper
     * @returns `await okMapper(this.inner)` if `Ok`, `value` if `Err`
     * @throws if `await okMapper(this.inner)` throws
     */
    async mapOr(value, okMapper) {
        this.ignore();
        return await okMapper(this.inner);
    }
    /**
     * Map the inner value into another, or a default one
     * @param value
     * @param okMapper
     * @returns `okMapper(this.inner)` if `Ok`, `value` if `Err`
     * @throws if `okMapper(this.inner)` throws
     */
    mapOrSync(value, okMapper) {
        this.ignore();
        return okMapper(this.inner);
    }
    /**
     * Map the inner value into another, or a default one
     * @param errMapper
     * @param okMapper
     * @returns `await okMapper(this.inner)` if `Ok`, `await errMapper(this.inner)` if `Err`
     * @throws if `await okMapper(this.inner)` or `await errMapper(this.inner)` throws
     */
    async mapOrElse(errMapper, okMapper) {
        this.ignore();
        return await okMapper(this.inner);
    }
    /**
     * Map the inner value into another, or a default one
     * @param errMapper
     * @param okMapper
     * @returns `okMapper(this.inner)` if `Ok`, `errMapper(this.inner)` if `Err`
     * @throws if `okMapper(this.inner)` or `errMapper(this.inner)` throws
     */
    mapOrElseSync(errMapper, okMapper) {
        this.ignore();
        return okMapper(this.inner);
    }
    /**
     * Return `value` if `Ok`, return `this` if `Err`
     * @param value
     * @returns `value` if `Ok`, `this` if `Err`
     */
    and(value) {
        this.ignore();
        return value;
    }
    /**
     * Return `await okMapper(this.inner)` if `Ok`, return `this` if `Err`
     * @param okMapper
     * @returns `await okMapper(this.inner)` if `Ok`, `this` if `Err`
     * @throws if `await okMapper(this.inner)` throws
     */
    async andThen(okMapper) {
        this.ignore();
        return await okMapper(this.inner);
    }
    /**
     * Return `okMapper(this.inner)` if `Ok`, return `this` if `Err`
     * @param okMapper
     * @returns `okMapper(this.inner)` if `Ok`, `this` if `Err`
     * @throws if `okMapper(this.inner)` throws
     */
    andThenSync(okMapper) {
        this.ignore();
        return okMapper(this.inner);
    }
    /**
     * Return `value` if `Err`, return `this` if `Ok`
     * @param value
     * @returns `value` if `Err`, `this` if `Ok`
     */
    or(value) {
        return this;
    }
    /**
     * Return `await errMapper(this.inner)` if `Err`, return `this` if `Ok`
     * @param errMapper
     * @returns `await errMapper(this.inner)` if `Err`, `this` if `Ok`
     * @throws if `await errMapper(this.inner)` throws
     */
    async orElse(errMapper) {
        return this;
    }
    /**
     * Return `errMapper(this.inner)` if `Err`, return `this` if `Ok`
     * @param errMapper
     * @returns `errMapper(this.inner)` if `Err`, `this` if `Ok`
     * @throws if `errMapper(this.inner)` throws
     */
    orElseSync(errMapper) {
        return this;
    }
    /**
     * Transform Result<Result<T, E1>, E2> into Result<T, E1 | E2>
     * @param result
     * @returns `this` if `Err`, `this.inner` if `Ok`
     */
    flatten() {
        return this.inner;
    }
}


//# sourceMappingURL=ok.mjs.map

;// CONCATENATED MODULE: ./src/libs/blobs/blobs.ts


var Blobs;
(function(Blobs) {
    async function readAsDataURL(blob) {
        const future = new Future();
        const reader = new FileReader();
        const onLoad = ()=>{
            future.resolve(reader.result);
        };
        const onError = ()=>{
            future.reject(reader.error);
        };
        try {
            reader.addEventListener("load", onLoad, {
                passive: true
            });
            reader.addEventListener("error", onError, {
                passive: true
            });
            reader.readAsDataURL(blob);
            return await future.promise;
        } finally{
            reader.removeEventListener("load", onLoad);
            reader.removeEventListener("error", onError);
        }
    }
    Blobs.readAsDataURL = readAsDataURL;
    async function tryReadAsDataURL(blob) {
        const future = new Future();
        const reader = new FileReader();
        const onLoad = ()=>{
            future.resolve(new ok_Ok(reader.result));
        };
        const onError = ()=>{
            future.resolve(new err_Err(reader.error));
        };
        try {
            reader.addEventListener("load", onLoad, {
                passive: true
            });
            reader.addEventListener("error", onError, {
                passive: true
            });
            reader.readAsDataURL(blob);
            return await future.promise;
        } finally{
            reader.removeEventListener("load", onLoad);
            reader.removeEventListener("error", onError);
        }
    }
    Blobs.tryReadAsDataURL = tryReadAsDataURL;
})(Blobs || (Blobs = {}));

;// CONCATENATED MODULE: ./node_modules/@swc/helpers/esm/_class_apply_descriptor_get.js
function _class_apply_descriptor_get(receiver, descriptor) {
    if (descriptor.get) return descriptor.get.call(receiver);

    return descriptor.value;
}


;// CONCATENATED MODULE: ./node_modules/@swc/helpers/esm/_class_extract_field_descriptor.js
function _class_extract_field_descriptor(receiver, privateMap, action) {
    if (!privateMap.has(receiver)) throw new TypeError("attempted to " + action + " private field on non-instance");

    return privateMap.get(receiver);
}


;// CONCATENATED MODULE: ./node_modules/@swc/helpers/esm/_class_private_field_get.js



function _class_private_field_get_class_private_field_get(receiver, privateMap) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "get");
    return _class_apply_descriptor_get(receiver, descriptor);
}


;// CONCATENATED MODULE: ./node_modules/@swc/helpers/esm/_check_private_redeclaration.js
function _check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}


;// CONCATENATED MODULE: ./node_modules/@swc/helpers/esm/_class_private_field_init.js


function _class_private_field_init_class_private_field_init(obj, privateMap, value) {
    _check_private_redeclaration(obj, privateMap);
    privateMap.set(obj, value);
}


;// CONCATENATED MODULE: ./node_modules/@swc/helpers/esm/_class_apply_descriptor_set.js
function _class_apply_descriptor_set(receiver, descriptor, value) {
    if (descriptor.set) descriptor.set.call(receiver, value);
    else {
        if (!descriptor.writable) {
            // This should only throw in strict mode, but class bodies are
            // always strict and private fields can only be used inside
            // class bodies.
            throw new TypeError("attempted to set read only private field");
        }
        descriptor.value = value;
    }
}


;// CONCATENATED MODULE: ./node_modules/@swc/helpers/esm/_class_private_field_set.js



function _class_private_field_set_class_private_field_set(receiver, privateMap, value) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "set");
    _class_apply_descriptor_set(receiver, descriptor, value);
    return value;
}


;// CONCATENATED MODULE: ./src/libs/browser/browser.ts



var _a;

var _globalThis_browser;
const browser = (_globalThis_browser = globalThis.browser) !== null && _globalThis_browser !== void 0 ? _globalThis_browser : globalThis.chrome;
var _class = /*#__PURE__*/ new WeakMap();
class BrowserError extends Error {
    static from(cause) {
        return new _a(undefined, {
            cause
        });
    }
    static async runOrThrow(callback) {
        try {
            const result = await callback();
            if (browser.runtime.lastError) throw browser.runtime.lastError;
            return result;
        } catch (e) {
            throw _a.from(e);
        }
    }
    static runOrThrowSync(callback) {
        try {
            const result = callback();
            if (browser.runtime.lastError) throw browser.runtime.lastError;
            return result;
        } catch (e) {
            throw _a.from(e);
        }
    }
    static async tryRun(callback) {
        try {
            const result = await callback();
            if (browser.runtime.lastError) throw browser.runtime.lastError;
            return new ok_Ok(result);
        } catch (e) {
            return new err_Err(_a.from(e));
        }
    }
    static tryRunSync(callback) {
        try {
            const result = callback();
            if (browser.runtime.lastError) throw browser.runtime.lastError;
            return new ok_Ok(result);
        } catch (e) {
            return new err_Err(_a.from(e));
        }
    }
    constructor(...args){
        super(...args);
        _class_private_field_init_class_private_field_init(this, _class, {
            writable: true,
            value: void 0
        });
        _class_private_field_set_class_private_field_set(this, _class, _a);
        this.name = _class_private_field_get_class_private_field_get(this, _class).name;
    }
}
_a = BrowserError;

;// CONCATENATED MODULE: ./node_modules/@hazae41/jsonrpc/dist/esm/mods/rpc/err.mjs


class RpcError extends Error {
    code;
    message;
    data;
    #class = RpcError;
    name = this.#class.name;
    static codes = {
        ParseError: -32700,
        InvalidRequest: -32600,
        MethodNotFound: -32601,
        InvalidParams: -32602,
        InternalError: -32603
    };
    static messages = {
        ParseError: "Parse error",
        InvalidRequest: "Invalid Request",
        MethodNotFound: "Method not found",
        InvalidParams: "Invalid params",
        InternalError: "Internal error",
        ServerError: "Server error"
    };
    constructor(code, message, data = undefined) {
        super(message);
        this.code = code;
        this.message = message;
        this.data = data;
    }
    static from(init) {
        const { code, message, data } = init;
        return new RpcError(code, message, data);
    }
    static rewrap(error) {
        if (error instanceof RpcError)
            return error;
        if (error instanceof Error)
            return new RpcError(-32603, error.message);
        return new RpcError(-32603, "An unknown error occured");
    }
    /**
     * Used by JSON.stringify
     */
    toJSON() {
        const { code, message, data } = this;
        return { code, message, data };
    }
}
class RpcParseError extends RpcError {
    #class = RpcParseError;
    name = this.#class.name;
    static code = RpcError.codes.ParseError;
    static message = RpcError.messages.ParseError;
    constructor() {
        super(RpcError.codes.ParseError, RpcError.messages.ParseError);
    }
}
class err_RpcInvalidRequestError extends RpcError {
    #class = err_RpcInvalidRequestError;
    name = this.#class.name;
    static code = RpcError.codes.InvalidRequest;
    static message = RpcError.messages.InvalidRequest;
    constructor() {
        super(RpcError.codes.InvalidRequest, RpcError.messages.InvalidRequest);
    }
}
class RpcMethodNotFoundError extends RpcError {
    #class = RpcMethodNotFoundError;
    name = this.#class.name;
    static code = RpcError.codes.MethodNotFound;
    static message = RpcError.messages.MethodNotFound;
    constructor() {
        super(RpcError.codes.MethodNotFound, RpcError.messages.MethodNotFound);
    }
}
class RpcInvalidParamsError extends RpcError {
    #class = RpcInvalidParamsError;
    name = this.#class.name;
    static code = RpcError.codes.InvalidParams;
    static message = RpcError.messages.InvalidParams;
    constructor() {
        super(RpcError.codes.InvalidParams, RpcError.messages.InvalidParams);
    }
}
class err_RpcInternalError extends RpcError {
    #class = err_RpcInternalError;
    name = this.#class.name;
    static code = RpcError.codes.InternalError;
    static message = RpcError.messages.InternalError;
    constructor() {
        super(RpcError.codes.InternalError, RpcError.messages.InternalError);
    }
}
class RpcErr extends err_Err {
    id;
    error;
    jsonrpc = "2.0";
    constructor(id, error) {
        super(error);
        this.id = id;
        this.error = error;
    }
    static from(init) {
        return new RpcErr(init.id, RpcError.from(init.error));
    }
    static rewrap(id, result) {
        return new RpcErr(id, RpcError.rewrap(result.inner));
    }
}


//# sourceMappingURL=err.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/jsonrpc/dist/esm/mods/rpc/ok.mjs


var RpcOkInit;
(function (RpcOkInit) {
    function from(response) {
        const { jsonrpc, id, result } = response;
        return { jsonrpc, id, result };
    }
    RpcOkInit.from = from;
})(RpcOkInit || (RpcOkInit = {}));
class RpcOk extends ok_Ok {
    id;
    result;
    jsonrpc = "2.0";
    constructor(id, result) {
        super(result);
        this.id = id;
        this.result = result;
    }
    static from(init) {
        return new RpcOk(init.id, init.result);
    }
    static rewrap(id, result) {
        return new RpcOk(id, result.inner);
    }
}


//# sourceMappingURL=ok.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/jsonrpc/dist/esm/mods/rpc/response.mjs



var response_RpcResponse;
(function (RpcResponse) {
    function from(init) {
        if ("error" in init)
            return RpcErr.from(init);
        return RpcOk.from(init);
    }
    RpcResponse.from = from;
    function rewrap(id, result) {
        if (result.isErr())
            return RpcErr.rewrap(id, result);
        return RpcOk.rewrap(id, result);
    }
    RpcResponse.rewrap = rewrap;
})(response_RpcResponse || (response_RpcResponse = {}));


//# sourceMappingURL=response.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/jsonrpc/dist/esm/mods/rpc/request.mjs
class RpcRequest {
    id;
    method;
    params;
    jsonrpc = "2.0";
    constructor(id, method, params) {
        this.id = id;
        this.method = method;
        this.params = params;
    }
    static from(init) {
        const { id, method, params } = init;
        return new RpcRequest(id, method, params);
    }
    toJSON() {
        const { jsonrpc, id, method, params } = this;
        return { jsonrpc, id, method, params };
    }
}


//# sourceMappingURL=request.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/jsonrpc/dist/esm/mods/rpc/rpc.mjs


class rpc_RpcCounter {
    id = 0;
    prepare(init) {
        return new RpcRequest(this.id++, init.method, init.params);
    }
}


//# sourceMappingURL=rpc.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/plume/dist/esm/node_modules/tslib/tslib.es6.mjs
/******************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */
/* global Reflect, Promise, SuppressedError, Symbol */


function tslib_es6_addDisposableResource(env, value, async) {
    if (value !== null && value !== void 0) {
        if (typeof value !== "object" && typeof value !== "function") throw new TypeError("Object expected.");
        var dispose;
        if (async) {
            if (!Symbol.asyncDispose) throw new TypeError("Symbol.asyncDispose is not defined.");
            dispose = value[Symbol.asyncDispose];
        }
        if (dispose === void 0) {
            if (!Symbol.dispose) throw new TypeError("Symbol.dispose is not defined.");
            dispose = value[Symbol.dispose];
        }
        if (typeof dispose !== "function") throw new TypeError("Object not disposable.");
        env.stack.push({ value: value, dispose: dispose, async: async });
    }
    else if (async) {
        env.stack.push({ async: true });
    }
    return value;
}

var _SuppressedError = typeof SuppressedError === "function" ? SuppressedError : function (error, suppressed, message) {
    var e = new Error(message);
    return e.name = "SuppressedError", e.error = error, e.suppressed = suppressed, e;
};

function tslib_es6_disposeResources(env) {
    function fail(e) {
        env.error = env.hasError ? new _SuppressedError(e, env.error, "An error was suppressed during disposal.") : e;
        env.hasError = true;
    }
    function next() {
        while (env.stack.length) {
            var rec = env.stack.pop();
            try {
                var result = rec.dispose && rec.dispose.call(rec.value);
                if (rec.async) return Promise.resolve(result).then(next, function(e) { fail(e); return next(); });
            }
            catch (e) {
                fail(e);
            }
        }
        if (env.hasError) throw env.error;
    }
    return next();
}


//# sourceMappingURL=tslib.es6.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/cleaner/dist/esm/node_modules/tslib/tslib.es6.mjs
/******************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */
/* global Reflect, Promise, SuppressedError, Symbol */


function tslib_tslib_es6_addDisposableResource(env, value, async) {
    if (value !== null && value !== void 0) {
        if (typeof value !== "object" && typeof value !== "function") throw new TypeError("Object expected.");
        var dispose;
        if (async) {
            if (!Symbol.asyncDispose) throw new TypeError("Symbol.asyncDispose is not defined.");
            dispose = value[Symbol.asyncDispose];
        }
        if (dispose === void 0) {
            if (!Symbol.dispose) throw new TypeError("Symbol.dispose is not defined.");
            dispose = value[Symbol.dispose];
        }
        if (typeof dispose !== "function") throw new TypeError("Object not disposable.");
        env.stack.push({ value: value, dispose: dispose, async: async });
    }
    else if (async) {
        env.stack.push({ async: true });
    }
    return value;
}

var tslib_es6_SuppressedError = typeof SuppressedError === "function" ? SuppressedError : function (error, suppressed, message) {
    var e = new Error(message);
    return e.name = "SuppressedError", e.error = error, e.suppressed = suppressed, e;
};

function tslib_tslib_es6_disposeResources(env) {
    function fail(e) {
        env.error = env.hasError ? new tslib_es6_SuppressedError(e, env.error, "An error was suppressed during disposal.") : e;
        env.hasError = true;
    }
    function next() {
        while (env.stack.length) {
            var rec = env.stack.pop();
            try {
                var result = rec.dispose && rec.dispose.call(rec.value);
                if (rec.async) return Promise.resolve(result).then(next, function(e) { fail(e); return next(); });
            }
            catch (e) {
                fail(e);
            }
        }
        if (env.hasError) throw env.error;
    }
    return next();
}


//# sourceMappingURL=tslib.es6.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/cleaner/dist/esm/src/mods/dispose/dispose.mjs


class Disposer {
    inner;
    dispose;
    constructor(inner, dispose) {
        this.inner = inner;
        this.dispose = dispose;
    }
    static from(disposable) {
        return new Disposer(disposable, () => disposable[Symbol.dispose]());
    }
    [Symbol.dispose]() {
        this.dispose();
    }
    mapSync(mapper) {
        return new Disposer(mapper(this.inner), this.dispose);
    }
    async map(mapper) {
        return new Disposer(await mapper(this.inner), this.dispose);
    }
}
class AsyncDisposer {
    inner;
    asyncDispose;
    constructor(inner, asyncDispose) {
        this.inner = inner;
        this.asyncDispose = asyncDispose;
    }
    static from(disposable) {
        return new AsyncDisposer(disposable, () => disposable[Symbol.asyncDispose]());
    }
    async [Symbol.asyncDispose]() {
        await this.asyncDispose();
    }
    mapSync(mapper) {
        return new AsyncDisposer(mapper(this.inner), this.asyncDispose);
    }
    async map(mapper) {
        return new AsyncDisposer(await mapper(this.inner), this.asyncDispose);
    }
}
class PromiseDisposer {
    inner;
    dispose;
    constructor(inner, dispose) {
        this.inner = inner;
        this.dispose = dispose;
    }
    static from(disposable) {
        return new PromiseDisposer(disposable, () => disposable[Symbol.dispose]());
    }
    then(onfulfilled, onrejected) {
        return this.inner.then(onfulfilled, onrejected);
    }
    [Symbol.dispose]() {
        this.dispose();
    }
}
class AsyncPromiseDisposer {
    inner;
    asyncDispose;
    constructor(inner, asyncDispose) {
        this.inner = inner;
        this.asyncDispose = asyncDispose;
    }
    static from(disposable) {
        return new PromiseDisposer(disposable, () => disposable[Symbol.asyncDispose]());
    }
    then(onfulfilled, onrejected) {
        return this.inner.then(onfulfilled, onrejected);
    }
    async [Symbol.asyncDispose]() {
        await this.asyncDispose();
    }
}
var Disposable;
(function (Disposable) {
    async function dispose(disposable) {
        const env_1 = { stack: [], error: void 0, hasError: false };
        try {
            const _ = tslib_tslib_es6_addDisposableResource(env_1, disposable, true);
        }
        catch (e_1) {
            env_1.error = e_1;
            env_1.hasError = true;
        }
        finally {
            const result_1 = tslib_tslib_es6_disposeResources(env_1);
            if (result_1)
                await result_1;
        }
    }
    Disposable.dispose = dispose;
    function disposeSync(disposable) {
        const env_2 = { stack: [], error: void 0, hasError: false };
        try {
            const _ = tslib_tslib_es6_addDisposableResource(env_2, disposable, false);
        }
        catch (e_2) {
            env_2.error = e_2;
            env_2.hasError = true;
        }
        finally {
            tslib_tslib_es6_disposeResources(env_2);
        }
    }
    Disposable.disposeSync = disposeSync;
})(Disposable || (Disposable = {}));


//# sourceMappingURL=dispose.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/plume/dist/esm/src/mods/errors.mjs





var errors_a, _b, _c;
class errors_AbortedError extends Error {
    #class = errors_a;
    name = this.#class.name;
    static from(cause) {
        return new errors_a(`Aborted`, { cause });
    }
    static waitOrThrow(signal) {
        const future = new Future();
        if (signal.aborted) {
            future.reject(errors_a.from(signal));
            return new PromiseDisposer(future.promise, () => { });
        }
        const onAbort = (event) => {
            future.reject(errors_a.from(event));
        };
        signal.addEventListener("abort", onAbort, { passive: true });
        const dispose = () => signal.removeEventListener("abort", onAbort);
        const promise = future.promise.finally(dispose);
        return new PromiseDisposer(promise, dispose);
    }
    static tryWait(signal) {
        const future = new Future();
        if (signal.aborted) {
            future.resolve(new err_Err(errors_a.from(signal)));
            return new PromiseDisposer(future.promise, () => { });
        }
        const onAbort = (event) => {
            future.resolve(new err_Err(errors_a.from(event)));
        };
        signal.addEventListener("abort", onAbort, { passive: true });
        const dispose = () => signal.removeEventListener("abort", onAbort);
        const promise = future.promise.finally(dispose);
        return new PromiseDisposer(promise, dispose);
    }
}
errors_a = errors_AbortedError;
class errors_ErroredError extends Error {
    #class = _b;
    name = this.#class.name;
    static from(cause) {
        return new _b(`Errored`, { cause });
    }
    static waitOrThrow(target) {
        return target.wait("error", (future, event) => {
            future.reject(_b.from(event));
            return new none_None();
        });
    }
    static tryWait(target) {
        return target.wait("error", (future, event) => {
            future.resolve(new err_Err(_b.from(event)));
            return new none_None();
        });
    }
}
_b = errors_ErroredError;
class errors_ClosedError extends Error {
    #class = _c;
    name = this.#class.name;
    static from(cause) {
        return new _c(`Closed`, { cause });
    }
    static waitOrThrow(target) {
        return target.wait("close", (future, event) => {
            future.reject(_c.from(event));
            return new none_None();
        });
    }
    static tryWait(target) {
        return target.wait("close", (future, event) => {
            future.resolve(new err_Err(_c.from(event)));
            return new none_None();
        });
    }
}
_c = errors_ClosedError;


//# sourceMappingURL=errors.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/plume/dist/esm/src/mods/waiters.mjs



async function waitOrSignal(target, type, callback, signal) {
    const env_1 = { stack: [], error: void 0, hasError: false };
    try {
        const abort = __addDisposableResource(env_1, AbortedError.waitOrThrow(signal), false);
        const event = __addDisposableResource(env_1, target.wait(type, callback), false);
        return await Promise.race([abort, event]);
    }
    catch (e_1) {
        env_1.error = e_1;
        env_1.hasError = true;
    }
    finally {
        __disposeResources(env_1);
    }
}
async function tryWaitOrSignal(target, type, callback, signal) {
    const env_2 = { stack: [], error: void 0, hasError: false };
    try {
        const abort = __addDisposableResource(env_2, AbortedError.tryWait(signal), false);
        const event = __addDisposableResource(env_2, target.wait(type, callback), false);
        return await Promise.race([abort, event]);
    }
    catch (e_2) {
        env_2.error = e_2;
        env_2.hasError = true;
    }
    finally {
        __disposeResources(env_2);
    }
}
async function waitOrCloseOrError(target, type, callback) {
    const env_3 = { stack: [], error: void 0, hasError: false };
    try {
        const error = __addDisposableResource(env_3, ErroredError.waitOrThrow(target), false);
        const close = __addDisposableResource(env_3, ClosedError.waitOrThrow(target), false);
        const event = __addDisposableResource(env_3, target.wait(type, callback), false);
        return await Promise.race([error, close, event]);
    }
    catch (e_3) {
        env_3.error = e_3;
        env_3.hasError = true;
    }
    finally {
        __disposeResources(env_3);
    }
}
async function tryWaitOrCloseOrError(target, type, callback) {
    const env_4 = { stack: [], error: void 0, hasError: false };
    try {
        const error = tslib_es6_addDisposableResource(env_4, errors_ErroredError.tryWait(target), false);
        const close = tslib_es6_addDisposableResource(env_4, errors_ClosedError.tryWait(target), false);
        const event = tslib_es6_addDisposableResource(env_4, target.wait(type, callback), false);
        return await Promise.race([error, close, event]);
    }
    catch (e_4) {
        env_4.error = e_4;
        env_4.hasError = true;
    }
    finally {
        tslib_es6_disposeResources(env_4);
    }
}
async function waitOrCloseOrErrorOrSignal(target, type, callback, signal) {
    const env_5 = { stack: [], error: void 0, hasError: false };
    try {
        const abort = __addDisposableResource(env_5, AbortedError.waitOrThrow(signal), false);
        const error = __addDisposableResource(env_5, ErroredError.waitOrThrow(target), false);
        const close = __addDisposableResource(env_5, ClosedError.waitOrThrow(target), false);
        const event = __addDisposableResource(env_5, target.wait(type, callback), false);
        return await Promise.race([abort, error, close, event]);
    }
    catch (e_5) {
        env_5.error = e_5;
        env_5.hasError = true;
    }
    finally {
        __disposeResources(env_5);
    }
}
async function tryWaitOrCloseOrErrorOrSignal(target, type, callback, signal) {
    const env_6 = { stack: [], error: void 0, hasError: false };
    try {
        const abort = __addDisposableResource(env_6, AbortedError.tryWait(signal), false);
        const error = __addDisposableResource(env_6, ErroredError.tryWait(target), false);
        const close = __addDisposableResource(env_6, ClosedError.tryWait(target), false);
        const event = __addDisposableResource(env_6, target.wait(type, callback), false);
        return await Promise.race([abort, error, close, event]);
    }
    catch (e_6) {
        env_6.error = e_6;
        env_6.hasError = true;
    }
    finally {
        __disposeResources(env_6);
    }
}


//# sourceMappingURL=waiters.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/plume/dist/esm/src/mods/target.mjs




class target_SuperEventTarget {
    #listeners = new Map();
    get listeners() {
        return this.#listeners;
    }
    /**
     * Add a listener to an event
     * @param type Event type //  "abort", "error", "message", "close"
     * @param listener Event listener // (e) => new Some(123)
     * @param options Options // { passive: true }
     * @returns
     */
    on(type, listener, options = {}) {
        let listeners = this.#listeners.get(type);
        if (listeners === undefined) {
            listeners = new Map();
            this.#listeners.set(type, listeners);
        }
        const off = () => this.off(type, listener);
        const internalOptions = { ...options, off };
        internalOptions.signal?.addEventListener("abort", off, { passive: true });
        listeners.set(listener, internalOptions);
        return off;
    }
    /**
     * Remove a listener from an event
     * @param type Event type //  "abort", "error", "message", "close"
     * @param listener Event listener // (e) => console.log("hello")
     * @param options Just to look like DOM's EventTarget
     * @returns
     */
    off(type, listener) {
        const listeners = this.#listeners.get(type);
        if (!listeners)
            return;
        const options = listeners.get(listener);
        if (!options)
            return;
        options.signal?.removeEventListener("abort", options.off);
        listeners.delete(listener);
        if (listeners.size > 0)
            return;
        this.#listeners.delete(type);
    }
    /**
     * Dispatch an event to its listeners
     *
     * - Dispatch to active listeners sequencially
     * - Return if one of the listeners returned something
     * - Dispatch to passive listeners concurrently
     * - Return if one of the listeners returned something
     * - Return nothing
     * @param value The object to emit
     * @returns `Some` if the event
     */
    async emit(type, value) {
        const listeners = this.#listeners.get(type);
        if (!listeners)
            return new none_None();
        const promises = new Array();
        for (const [listener, options] of listeners) {
            if (options.passive)
                continue;
            if (options.once)
                this.off(type, listener);
            const returned = await listener(...value);
            if (returned.isNone())
                continue;
            return returned;
        }
        for (const [listener, options] of listeners) {
            if (!options.passive)
                continue;
            if (options.once)
                this.off(type, listener);
            const returned = listener(...value);
            if (returned instanceof Promise) {
                promises.push(returned);
                continue;
            }
            if (returned.isNone())
                continue;
            return returned;
        }
        const returneds = await Promise.all(promises);
        for (const returned of returneds)
            if (returned.isSome())
                return returned;
        return new none_None();
    }
    /**
     * Like `.on`, but instead of returning to the target, capture the returned value in a future, and return nothing to the target
     * @param type
     * @param callback
     * @returns
     */
    wait(type, callback) {
        const future = new Future();
        const dispose = this.on(type, async (...params) => {
            return await callback(future, ...params);
        }, { passive: true });
        const promise = future.promise.finally(dispose);
        return new PromiseDisposer(promise, dispose);
    }
}


//# sourceMappingURL=target.mjs.map

;// CONCATENATED MODULE: ./src/libs/console/index.ts
var console_Console;
(function(Console) {
    Console.debugging = false;
    function debug() {
        for(var _len = arguments.length, params = new Array(_len), _key = 0; _key < _len; _key++){
            params[_key] = arguments[_key];
        }
        if (!Console.debugging) return;
        console.debug(...params);
    }
    Console.debug = debug;
})(console_Console || (console_Console = {}));

;// CONCATENATED MODULE: ./src/libs/channel/channel.ts









var _clean = /*#__PURE__*/ new WeakMap();
let _Symbol_dispose = Symbol.dispose;
class WebsitePort {
    [_Symbol_dispose]() {
        _class_private_field_get(this, _clean).call(this);
    }
    async runPingLoop() {
        let count = 0;
        while(true){
            await new Promise((ok)=>setTimeout(ok, 1000));
            const signal = AbortSignal.timeout(1000);
            const result = await this.tryPingOrSignal(signal).then((r)=>r.flatten());
            if (result.isErr()) count++;
            else count = 0;
            if (count === 2) {
                await this.events.emit("close", [
                    undefined
                ]);
                return;
            }
        }
    }
    async tryRouteRequest(request) {
        try {
            if (request.method === "brume_ping") return Ok.void();
            const returned = await this.events.emit("request", [
                request
            ]);
            if (returned.isSome()) return returned.inner;
            return new Err(new RpcInvalidRequestError());
        } catch (e) {
            return new Err(new RpcInternalError());
        }
    }
    async onRequest(request) {
        if (request.id !== "ping") Console.debug(this.name, "->", request);
        const result = await this.tryRouteRequest(request);
        const response = RpcResponse.rewrap(request.id, result);
        if (request.id !== "ping") Console.debug(this.name, "<-", response, result);
        this.port.postMessage(JSON.stringify(response));
    }
    async onResponse(response) {
        if (response.id !== "ping") Console.debug(this.name, "->", response);
        const returned = await this.events.emit("response", [
            response
        ]);
        if (returned.isSome()) return returned.inner;
        return new Err(new Error("Unhandled JSON-RPC response ".concat(JSON.stringify(response))));
    }
    async onMessage(message) {
        const data = JSON.parse(message.data);
        if ("method" in data) return await this.onRequest(data);
        return await this.onResponse(data);
    }
    async tryRequest(init) {
        const request = this.counter.prepare(init);
        if (request.id !== "ping") Console.debug(this.name, "<-", request);
        this.port.postMessage(JSON.stringify(request));
        return Plume.tryWaitOrCloseOrError(this.events, "response", (future, init)=>{
            if (init.id !== request.id) return new None();
            const response = RpcResponse.from(init);
            future.resolve(new Ok(response));
            return new Some(undefined);
        });
    }
    async tryPingOrSignal(signal) {
        const request = {
            id: "ping",
            method: "brume_ping"
        };
        this.port.postMessage(JSON.stringify(request));
        return Plume.tryWaitOrCloseOrErrorOrSignal(this.events, "response", (future, init)=>{
            if (init.id !== request.id) return new None();
            const response = RpcResponse.from(init);
            future.resolve(new Ok(response));
            return new Some(undefined);
        }, signal);
    }
    constructor(name, port){
        _class_private_field_init(this, _clean, {
            writable: true,
            value: void 0
        });
        this.counter = new RpcCounter();
        this.uuid = crypto.randomUUID();
        this.events = new SuperEventTarget();
        this.name = name;
        this.port = port;
        const onMessage = this.onMessage.bind(this);
        this.port.addEventListener("message", onMessage, {
            passive: true
        });
        _class_private_field_set(this, _clean, ()=>{
            this.port.removeEventListener("message", onMessage);
            _class_private_field_set(this, _clean, ()=>{});
        });
    }
}
var _clean1 = /*#__PURE__*/ new WeakMap();
let _Symbol_dispose1 = Symbol.dispose;
class ExtensionPort {
    [_Symbol_dispose1]() {
        _class_private_field_get_class_private_field_get(this, _clean1).call(this);
    }
    async tryRouteRequest(request) {
        try {
            if (request.method === "brume_ping") return ok_Ok.void();
            const returned = await this.events.emit("request", [
                request
            ]);
            if (returned.isSome()) return returned.inner;
            return new err_Err(new err_RpcInvalidRequestError());
        } catch (e) {
            return new err_Err(new err_RpcInternalError());
        }
    }
    async onRequest(request) {
        if (request.id !== "ping") console_Console.debug(this.name, "->", request);
        const result = await this.tryRouteRequest(request);
        const response = response_RpcResponse.rewrap(request.id, result);
        if (request.id !== "ping") console_Console.debug(this.name, "<-", response);
        BrowserError.tryRunSync(()=>{
            this.port.postMessage(JSON.stringify(response));
        }).ignore();
    }
    async onResponse(response) {
        if (response.id !== "ping") console_Console.debug(this.name, "->", response);
        const returned = await this.events.emit("response", [
            response
        ]);
        if (returned.isSome()) return returned.inner;
        return new err_Err(new Error("Unhandled JSON-RPC response ".concat(JSON.stringify(response))));
    }
    async onMessage(message) {
        const data = JSON.parse(message);
        if ("method" in data) return await this.onRequest(data);
        return await this.onResponse(data);
    }
    async onDisconnect() {
        await this.events.emit("close", [
            undefined
        ]);
    }
    async tryRequest(init) {
        return await Result.unthrow(async (t)=>{
            const request = this.counter.prepare(init);
            if (request.id !== "ping") console_Console.debug(this.name, "<-", request);
            BrowserError.tryRunSync(()=>{
                this.port.postMessage(JSON.stringify(request));
            }).throw(t);
            return tryWaitOrCloseOrError(this.events, "response", (future, init)=>{
                if (init.id !== request.id) return new none_None();
                const response = response_RpcResponse.from(init);
                future.resolve(new ok_Ok(response));
                return new some_Some(undefined);
            });
        });
    }
    constructor(name, port){
        _class_private_field_init_class_private_field_init(this, _clean1, {
            writable: true,
            value: void 0
        });
        this.counter = new rpc_RpcCounter();
        this.uuid = crypto.randomUUID();
        this.events = new target_SuperEventTarget();
        this.name = name;
        this.port = port;
        const onMessage = this.onMessage.bind(this);
        const onDisconnect = this.onDisconnect.bind(this);
        this.port.onMessage.addListener(onMessage);
        this.port.onDisconnect.addListener(onDisconnect);
        _class_private_field_set_class_private_field_set(this, _clean1, ()=>{
            this.port.onMessage.removeListener(onMessage);
            this.port.onDisconnect.removeListener(onDisconnect);
            _class_private_field_set_class_private_field_set(this, _clean1, ()=>{});
        });
    }
}

;// CONCATENATED MODULE: ./src/libs/fetch/fetch.ts

async function tryFetchAsJson(input, init) {
    try {
        const res = await fetch(input, init);
        if (!res.ok) return new err_Err(new Error(await res.text()));
        return new ok_Ok(await res.json());
    } catch (e) {
        return new err_Err(Catched.from(e));
    }
}
async function tryFetchAsBlob(input, init) {
    try {
        const res = await fetch(input, init);
        if (!res.ok) return new err_Err(new Error(await res.text()));
        return new ok_Ok(await res.blob());
    } catch (e) {
        return new err_Err(Catched.from(e));
    }
}

;// CONCATENATED MODULE: ./node_modules/@hazae41/box/dist/esm/mods/box/box.mjs


var box_a;
class BoxMovedError extends Error {
    #class = box_a;
    name = this.#class.name;
    constructor() {
        super(`Box has been moved`);
    }
}
box_a = BoxMovedError;
class Box {
    inner;
    #moved = false;
    /**
     * Object that uniquely owns a type T and can dispose it
     */
    constructor(inner) {
        this.inner = inner;
    }
    [Symbol.dispose]() {
        if (this.#moved)
            return;
        this.inner[Symbol.dispose]();
    }
    /**
     * Create a new Box
     * @param inner
     * @returns
     */
    static new(inner) {
        return new Box(inner);
    }
    /**
     * Create a new Box that's already moved
     * @param inner
     * @returns
     */
    static greedy(inner) {
        const box = new Box(inner);
        box.#moved = true;
        return box;
    }
    get moved() {
        return this.#moved;
    }
    get() {
        if (this.#moved)
            return undefined;
        return this.inner;
    }
    /**
     * Just get the inner value
     * @returns T
     * @throws BoxMovedError if moved
     */
    getOrThrow() {
        if (this.#moved)
            throw new BoxMovedError();
        return this.inner;
    }
    /**
     * Just get the inner value
     * @returns Ok<T> or Err<BoxMovedError> if moved
     */
    tryGet() {
        if (this.#moved)
            return new err_Err(new BoxMovedError());
        return new ok_Ok(this.inner);
    }
    unwrap() {
        if (this.#moved)
            return undefined;
        this.#moved = true;
        return this.inner;
    }
    /**
     * Get the inner value and set this as moved
     * @returns T
     * @throws BoxMovedError if already moved
     */
    unwrapOrThrow() {
        if (this.#moved)
            throw new BoxMovedError();
        this.#moved = true;
        return this.inner;
    }
    /**
     * Get the inner value and set this as moved
     * @returns Ok<T> or Err<BoxMovedError> if already moved
     */
    tryUnwrap() {
        if (this.#moved)
            return new err_Err(new BoxMovedError());
        this.#moved = true;
        return new ok_Ok(this.inner);
    }
    move() {
        if (this.#moved)
            return undefined;
        this.#moved = true;
        return new Box(this.inner);
    }
    /**
     * Move the inner value to a new box and set this one as moved
     * @returns Box<T>
     * @throws BoxMovedError if already moved
     */
    moveOrThrow() {
        if (this.#moved)
            throw new BoxMovedError();
        this.#moved = true;
        return new Box(this.inner);
    }
    /**
     * Move the inner value to a new box and set this one as moved
     * @returns Ok<Box<T>> or Err<BoxMovedError> if already moved
     */
    tryMove() {
        if (this.#moved)
            return new err_Err(new BoxMovedError());
        this.#moved = true;
        return new ok_Ok(new Box(this.inner));
    }
    /**
     * Create a new Box that's already moved, and keep this one as is
     * @returns Box<T>
     */
    greed() {
        const moved = new Box(this.inner);
        moved.#moved = true;
        return moved;
    }
}


//# sourceMappingURL=box.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/piscine/dist/esm/node_modules/tslib/tslib.es6.mjs
/******************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */
/* global Reflect, Promise, SuppressedError, Symbol */


function node_modules_tslib_tslib_es6_addDisposableResource(env, value, async) {
    if (value !== null && value !== void 0) {
        if (typeof value !== "object" && typeof value !== "function") throw new TypeError("Object expected.");
        var dispose;
        if (async) {
            if (!Symbol.asyncDispose) throw new TypeError("Symbol.asyncDispose is not defined.");
            dispose = value[Symbol.asyncDispose];
        }
        if (dispose === void 0) {
            if (!Symbol.dispose) throw new TypeError("Symbol.dispose is not defined.");
            dispose = value[Symbol.dispose];
        }
        if (typeof dispose !== "function") throw new TypeError("Object not disposable.");
        env.stack.push({ value: value, dispose: dispose, async: async });
    }
    else if (async) {
        env.stack.push({ async: true });
    }
    return value;
}

var tslib_tslib_es6_SuppressedError = typeof SuppressedError === "function" ? SuppressedError : function (error, suppressed, message) {
    var e = new Error(message);
    return e.name = "SuppressedError", e.error = error, e.suppressed = suppressed, e;
};

function node_modules_tslib_tslib_es6_disposeResources(env) {
    function fail(e) {
        env.error = env.hasError ? new tslib_tslib_es6_SuppressedError(e, env.error, "An error was suppressed during disposal.") : e;
        env.hasError = true;
    }
    function next() {
        while (env.stack.length) {
            var rec = env.stack.pop();
            try {
                var result = rec.dispose && rec.dispose.call(rec.value);
                if (rec.async) return Promise.resolve(result).then(next, function(e) { fail(e); return next(); });
            }
            catch (e) {
                fail(e);
            }
        }
        if (env.hasError) throw env.error;
    }
    return next();
}


//# sourceMappingURL=tslib.es6.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/arrays/dist/esm/mods/arrays/arrays.mjs
/**
 * Get the last value
 * @param array
 * @returns
 */
function last(array) {
    if (array.length === 0)
        return undefined;
    return array[lastIndex(array)];
}
/**
 * Get the last index
 * @param array
 * @returns
 */
function lastIndex(array) {
    return array.length - 1;
}
/**
 * Get a random value using Math's PRNG
 * @param array
 * @returns
 */
function random(array) {
    if (array.length === 0)
        return undefined;
    return array[randomIndex(array)];
}
/**
 * Get a random index using Math's PRNG
 * @param array
 * @returns
 */
function randomIndex(array) {
    return Math.floor(Math.random() * array.length);
}
/**
 * Get a random value using WebCrypto's CSPRNG
 * @param array
 * @returns
 */
function cryptoRandom(array) {
    if (array.length === 0)
        return undefined;
    return array[cryptoRandomIndex(array)];
}
/**
 * Get a random value using WebCrypto's CSPRNG
 * @param array
 * @returns
 */
function cryptoRandomIndex(array) {
    const values = new Uint32Array(1);
    crypto.getRandomValues(values);
    return values[0] % array.length;
}
/**
 * Get a random value using Math's PRNG and delete it from the array
 * @param array
 * @returns
 */
function takeRandom(array) {
    if (array.length === 0)
        return undefined;
    const index = randomIndex(array);
    const element = array[index];
    array.splice(index, 1);
    return element;
}
/**
 * Get a random value using WebCrypto's CSPRNG and delete it from the array
 * @param array
 * @returns
 */
function takeCryptoRandom(array) {
    if (array.length === 0)
        return undefined;
    const index = cryptoRandomIndex(array);
    const element = array[index];
    array.splice(index, 1);
    return element;
}


//# sourceMappingURL=arrays.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/piscine/dist/esm/src/libs/signals/signals.mjs
var AbortSignals;
(function (AbortSignals) {
    function never() {
        return new AbortController().signal;
    }
    AbortSignals.never = never;
    function timeout(delay, parent) {
        return merge(AbortSignal.timeout(delay), parent);
    }
    AbortSignals.timeout = timeout;
    function merge(a, b) {
        if (b === undefined)
            return a;
        const c = new AbortController();
        const onAbort = (reason) => {
            c.abort(reason);
            a.removeEventListener("abort", onAbort);
            b.removeEventListener("abort", onAbort);
        };
        a.addEventListener("abort", onAbort, { passive: true });
        b.addEventListener("abort", onAbort, { passive: true });
        return c.signal;
    }
    AbortSignals.merge = merge;
})(AbortSignals || (AbortSignals = {}));


//# sourceMappingURL=signals.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/piscine/dist/esm/src/mods/pool/pool.mjs







var pool_a, pool_b;
class PoolOkEntry extends ok_Ok {
    pool;
    index;
    value;
    constructor(pool, index, value) {
        super(value);
        this.pool = pool;
        this.index = index;
        this.value = value;
    }
}
class PoolErrEntry extends err_Err {
    pool;
    index;
    value;
    constructor(pool, index, value) {
        super(value);
        this.pool = pool;
        this.index = index;
        this.value = value;
    }
}
class EmptyPoolError extends Error {
    #class = pool_a;
    name = this.#class.name;
    constructor() {
        super(`Empty pool`);
    }
}
pool_a = EmptyPoolError;
class EmptySlotError extends Error {
    #class = pool_b;
    name = this.#class.name;
    constructor() {
        super(`Empty pool slot`);
    }
}
pool_b = EmptySlotError;
class Pool {
    creator;
    params;
    #capacity;
    events = new target_SuperEventTarget();
    #allAborters = new Array();
    /**
     * Entry by index, can be sparse
     */
    #allEntries = new Array();
    /**
     * Promise by index, can be sparse
     */
    #allPromises = new Array();
    /**
     * Entries that are ok
     */
    #okEntries = new Set();
    /**
     * Entries that are err
     */
    #errEntries = new Set();
    /**
     * Promises that are started (running or settled)
     */
    #startedPromises = new Set();
    /**
     * A pool of circuits
     * @param tor
     * @param params
     */
    constructor(creator, params = {}) {
        this.creator = creator;
        this.params = params;
        const { capacity = 3 } = params;
        this.#capacity = capacity;
        for (let index = 0; index < capacity; index++)
            this.#start(index);
        return;
    }
    /**
     * Number of ok elements
     */
    get size() {
        return this.#okEntries.size;
    }
    /**
     * Number of slots
     */
    get capacity() {
        return this.#capacity;
    }
    /**
     * Iterator on ok elements
     * @returns
     */
    [Symbol.iterator]() {
        return this.#okEntries.values();
    }
    /**
     * Whether all entries are err
     */
    get stagnant() {
        return this.#errEntries.size === this.#capacity;
    }
    #start(index) {
        const promise = this.#createOrThrow(index);
        /**
         * Set promise as handled
         */
        promise.catch(() => { });
        this.#allPromises[index] = promise;
        this.#startedPromises.add(promise);
        this.events.emit("started", [index]).catch(console.error);
    }
    async #createOrThrow(index) {
        const aborter = new AbortController();
        this.#allAborters[index] = aborter;
        const { signal } = aborter;
        const result = await Result.runAndDoubleWrap(async () => {
            return await this.creator({ pool: this, index, signal });
        }).then(r => r.flatten());
        if (result.isOk()) {
            const env_1 = { stack: [], error: void 0, hasError: false };
            try {
                const inner = node_modules_tslib_tslib_es6_addDisposableResource(env_1, new Box(result.inner), false);
                signal.throwIfAborted();
                const entry = new PoolOkEntry(this, index, inner.unwrapOrThrow());
                this.#allEntries[index] = entry;
                this.#okEntries.add(entry);
                this.events.emit("created", [entry]).catch(console.error);
                return entry;
            }
            catch (e_1) {
                env_1.error = e_1;
                env_1.hasError = true;
            }
            finally {
                node_modules_tslib_tslib_es6_disposeResources(env_1);
            }
        }
        signal.throwIfAborted();
        const entry = new PoolErrEntry(this, index, result.inner);
        this.#allEntries[index] = entry;
        this.#errEntries.add(entry);
        this.events.emit("created", [entry]).catch(console.error);
        throw result.inner;
    }
    #delete(index) {
        const aborter = this.#allAborters.at(index);
        if (aborter != null) {
            aborter.abort();
            delete this.#allAborters[index];
        }
        const promise = this.#allPromises.at(index);
        if (promise != null) {
            this.#startedPromises.delete(promise);
            delete this.#allPromises[index];
        }
        const entry = this.#allEntries.at(index);
        if (entry != null) {
            if (entry.isOk()) {
                entry.inner[Symbol.dispose]();
                this.#okEntries.delete(entry);
            }
            if (entry.isErr()) {
                this.#errEntries.delete(entry);
            }
            delete this.#allEntries[index];
            this.events.emit("deleted", [entry]).catch(console.error);
            return entry;
        }
        return undefined;
    }
    /**
     * Restart the index and return the previous entry
     * @param element
     * @returns
     */
    restart(index) {
        const entry = this.#delete(index);
        this.#start(index);
        return entry;
    }
    /**
     * Modify capacity
     * @param capacity
     * @returns
     */
    growOrShrink(capacity) {
        if (capacity > this.#capacity) {
            const previous = this.#capacity;
            this.#capacity = capacity;
            for (let i = previous; i < capacity; i++)
                this.#start(i);
            return previous;
        }
        else if (capacity < this.#capacity) {
            const previous = this.#capacity;
            this.#capacity = capacity;
            for (let i = capacity; i < previous; i++)
                this.#delete(i);
            return previous;
        }
        return this.#capacity;
    }
    async getOrThrow(index, signal = AbortSignals.never()) {
        const env_2 = { stack: [], error: void 0, hasError: false };
        try {
            const promise = this.#allPromises.at(index);
            if (promise === undefined)
                throw new EmptySlotError();
            const abort = node_modules_tslib_tslib_es6_addDisposableResource(env_2, errors_AbortedError.waitOrThrow(signal), false);
            return await Promise.race([abort, promise]);
        }
        catch (e_2) {
            env_2.error = e_2;
            env_2.hasError = true;
        }
        finally {
            node_modules_tslib_tslib_es6_disposeResources(env_2);
        }
    }
    /**
     * Get the element at index, if still loading, wait for it, err if not started
     * @param index
     * @returns
     */
    async tryGet(index, signal = AbortSignals.never()) {
        return await Result.runAndDoubleWrap(() => this.getOrThrow(index, signal));
    }
    /**
     * Get the element at index, throw if empty
     * @param index
     * @returns the element at index
     * @throws if empty
     */
    getSyncOrThrow(index) {
        const entry = this.#allEntries.at(index);
        if (entry === undefined)
            throw new EmptySlotError();
        return entry;
    }
    /**
     * Get the element at index, err if empty
     * @param index
     * @returns
     */
    tryGetSync(index) {
        return Result.runAndDoubleWrapSync(() => this.getSyncOrThrow(index));
    }
    /**
     * Wait for any element to be created, then get a random one using Math's PRNG
     * @returns
     */
    async getRandomOrThrow(signal = AbortSignals.never()) {
        while (true) {
            const env_3 = { stack: [], error: void 0, hasError: false };
            try {
                const abort = node_modules_tslib_tslib_es6_addDisposableResource(env_3, errors_AbortedError.waitOrThrow(signal), false);
                const first = Promise.any(this.#startedPromises);
                await Promise.race([first, abort]);
                try {
                    return this.getRandomSyncOrThrow();
                }
                catch (e) {
                    /**
                     * The element has been deleted already?
                     */
                }
            }
            catch (e_3) {
                env_3.error = e_3;
                env_3.hasError = true;
            }
            finally {
                node_modules_tslib_tslib_es6_disposeResources(env_3);
            }
        }
    }
    /**
     * Wait for any element to be created, then get a random one using Math's PRNG
     * @returns
     */
    async tryGetRandom(signal = AbortSignals.never()) {
        return await Result.runAndDoubleWrap(() => this.getRandomOrThrow(signal));
    }
    /**
     * Get a random element from the pool using Math's PRNG, throws if none available
     * @returns
     */
    getRandomSyncOrThrow() {
        if (this.#okEntries.size === 0)
            throw new EmptyPoolError();
        const entries = [...this.#okEntries];
        return random(entries);
    }
    /**
     * Get a random element from the pool using Math's PRNG, throws if none available
     * @returns
     */
    tryGetRandomSync() {
        return Result.runAndDoubleWrapSync(() => this.getRandomSyncOrThrow());
    }
    /**
     * Wait for any element to be created, then get a random one using WebCrypto's CSPRNG
     * @returns
     */
    async getCryptoRandomOrThrow(signal = AbortSignals.never()) {
        while (true) {
            const env_4 = { stack: [], error: void 0, hasError: false };
            try {
                const abort = node_modules_tslib_tslib_es6_addDisposableResource(env_4, errors_AbortedError.waitOrThrow(signal), false);
                const first = Promise.any(this.#startedPromises);
                await Promise.race([first, abort]);
                try {
                    return this.getCryptoRandomSyncOrThrow();
                }
                catch (e) {
                    /**
                     * The element has been deleted already?
                     */
                }
            }
            catch (e_4) {
                env_4.error = e_4;
                env_4.hasError = true;
            }
            finally {
                node_modules_tslib_tslib_es6_disposeResources(env_4);
            }
        }
    }
    /**
     * Wait for any element to be created, then get a random one using WebCrypto's CSPRNG
     * @returns
     */
    async tryGetCryptoRandom(signal = AbortSignals.never()) {
        return await Result.runAndDoubleWrap(() => this.getCryptoRandomOrThrow(signal));
    }
    /**
     * Get a random element from the pool using WebCrypto's CSPRNG
     * @returns
     */
    getCryptoRandomSyncOrThrow() {
        if (this.#okEntries.size === 0)
            throw new EmptyPoolError();
        const entries = [...this.#okEntries];
        return cryptoRandom(entries);
    }
    /**
     * Get a random element from the pool using WebCrypto's CSPRNG
     * @returns
     */
    tryGetCryptoRandomSync() {
        return Result.runAndDoubleWrapSync(() => this.getCryptoRandomSyncOrThrow());
    }
    /**
     * Take a random element from the pool using Math's PRNG
     * @param pool
     * @returns
     */
    static takeRandomSyncOrThrow(pool) {
        const entry = pool.getRandomSyncOrThrow();
        if (entry.isErr())
            return entry;
        const { index, value } = entry;
        const value2 = value.mapSync(x => x.moveOrThrow());
        const entry2 = new PoolOkEntry(pool, index, value2);
        pool.restart(index);
        return entry2;
    }
    /**
     * Take a random element from the pool using Math's PRNG
     * @param pool
     * @returns
     */
    static tryTakeRandomSync(pool) {
        return Result.runAndDoubleWrapSync(() => this.takeRandomSyncOrThrow(pool));
    }
    /**
     * Take a random element from the pool using Math's PRNG
     * @param pool
     * @returns
     */
    static async takeRandomOrThrow(pool, signal = AbortSignals.never()) {
        return await pool.lock(async (pool) => {
            const entry = await pool.getRandomOrThrow(signal);
            if (entry.isErr())
                return entry;
            const { index, value } = entry;
            const value2 = value.mapSync(x => x.moveOrThrow());
            const entry2 = new PoolOkEntry(pool, index, value2);
            pool.restart(index);
            return entry2;
        });
    }
    /**
     * Take a random element from the pool using Math's PRNG
     * @param pool
     * @returns
     */
    static async tryTakeRandom(pool, signal = AbortSignals.never()) {
        return await Result.runAndDoubleWrap(() => this.takeRandomOrThrow(pool, signal));
    }
    /**
     * Take a random element from the pool using WebCrypto's CSPRNG
     * @param pool
     * @returns
     */
    static takeCryptoRandomSyncOrThrow(pool) {
        const entry = pool.getCryptoRandomSyncOrThrow();
        if (entry.isErr())
            return entry;
        const { index, value } = entry;
        const value2 = value.mapSync(x => x.moveOrThrow());
        const entry2 = new PoolOkEntry(pool, index, value2);
        pool.restart(index);
        return entry2;
    }
    /**
     * Take a random element from the pool using WebCrypto's CSPRNG
     * @param pool
     * @returns
     */
    static tryTakeCryptoRandomSync(pool) {
        return Result.runAndDoubleWrapSync(() => this.takeCryptoRandomSyncOrThrow(pool));
    }
    /**
     * Take a random element from the pool using WebCrypto's CSPRNG
     * @param pool
     * @returns
     */
    static async takeCryptoRandomOrThrow(pool, signal = AbortSignals.never()) {
        return await pool.lock(async (pool) => {
            const entry = await pool.getCryptoRandomOrThrow(signal);
            if (entry.isErr())
                return entry;
            const { index, value } = entry;
            const value2 = value.mapSync(x => x.moveOrThrow());
            const entry2 = new PoolOkEntry(pool, index, value2);
            pool.restart(index);
            return entry2;
        });
    }
    /**
     * Take a random element from the pool using WebCrypto's CSPRNG
     * @param pool
     * @returns
     */
    static async tryTakeCryptoRandom(pool, signal = AbortSignals.never()) {
        return await Result.runAndDoubleWrap(() => this.takeCryptoRandomOrThrow(pool, signal));
    }
}


//# sourceMappingURL=pool.mjs.map

;// CONCATENATED MODULE: ./src/mods/background/content_script/index.ts
var content_script_addDisposableResource = undefined && undefined.__addDisposableResource || function(env, value, async) {
    if (value !== null && value !== void 0) {
        if (typeof value !== "object" && typeof value !== "function") throw new TypeError("Object expected.");
        var dispose;
        if (async) {
            if (!Symbol.asyncDispose) throw new TypeError("Symbol.asyncDispose is not defined.");
            dispose = value[Symbol.asyncDispose];
        }
        if (dispose === void 0) {
            if (!Symbol.dispose) throw new TypeError("Symbol.dispose is not defined.");
            dispose = value[Symbol.dispose];
        }
        if (typeof dispose !== "function") throw new TypeError("Object not disposable.");
        env.stack.push({
            value: value,
            dispose: dispose,
            async: async
        });
    } else if (async) {
        env.stack.push({
            async: true
        });
    }
    return value;
};
var content_script_disposeResources = undefined && undefined.__disposeResources || function(SuppressedError1) {
    return function(env) {
        function fail(e) {
            env.error = env.hasError ? new SuppressedError1(e, env.error, "An error was suppressed during disposal.") : e;
            env.hasError = true;
        }
        function next() {
            while(env.stack.length){
                var rec = env.stack.pop();
                try {
                    var result = rec.dispose && rec.dispose.call(rec.value);
                    if (rec.async) return Promise.resolve(result).then(next, function(e) {
                        fail(e);
                        return next();
                    });
                } catch (e) {
                    fail(e);
                }
            }
            if (env.hasError) throw env.error;
        }
        return next();
    };
}(typeof SuppressedError === "function" ? SuppressedError : function(error, suppressed, message) {
    var e = new Error(message);
    return e.name = "SuppressedError", e.error = error, e.suppressed = suppressed, e;
});











const mouse = {
    x: window.screen.width / 2,
    y: window.screen.height / 2
};
addEventListener("mousemove", (e)=>{
    mouse.x = e.screenX;
    mouse.y = e.screenY;
}, {
    passive: true
});
if (IS_FIREFOX || IS_SAFARI) {
    const container = document.documentElement;
    const scriptBody = atob("LyoqKioqKi8gKCgpID0+IHsgLy8gd2VicGFja0Jvb3RzdHJhcAovKioqKioqLyAJInVzZSBzdHJpY3QiOwp2YXIgX193ZWJwYWNrX2V4cG9ydHNfXyA9IHt9OwoKOy8vIENPTkNBVEVOQVRFRCBNT0RVTEU6IC4vbm9kZV9tb2R1bGVzL0BoYXphZTQxL3N5bWJvbC1kaXNwb3NlLXBvbHlmaWxsL2Rpc3QvZXNtL21vZHMvc3ltYm9sLWRpc3Bvc2UtcG9seWZpbGwvcG9seWZpbGwubWpzCmlmICh0eXBlb2YgU3ltYm9sLmRpc3Bvc2UgIT09ICJzeW1ib2wiKQogICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KFN5bWJvbCwgImRpc3Bvc2UiLCB7CiAgICAgICAgY29uZmlndXJhYmxlOiBmYWxzZSwKICAgICAgICBlbnVtZXJhYmxlOiBmYWxzZSwKICAgICAgICB3cml0YWJsZTogZmFsc2UsCiAgICAgICAgdmFsdWU6IFN5bWJvbC5mb3IoImRpc3Bvc2UiKQogICAgfSk7CmlmICh0eXBlb2YgU3ltYm9sLmFzeW5jRGlzcG9zZSAhPT0gInN5bWJvbCIpCiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoU3ltYm9sLCAiYXN5bmNEaXNwb3NlIiwgewogICAgICAgIGNvbmZpZ3VyYWJsZTogZmFsc2UsCiAgICAgICAgZW51bWVyYWJsZTogZmFsc2UsCiAgICAgICAgd3JpdGFibGU6IGZhbHNlLAogICAgICAgIHZhbHVlOiBTeW1ib2wuZm9yKCJhc3luY0Rpc3Bvc2UiKQogICAgfSk7Ci8vIyBzb3VyY2VNYXBwaW5nVVJMPXBvbHlmaWxsLm1qcy5tYXAKCjsvLyBDT05DQVRFTkFURUQgTU9EVUxFOiAuL25vZGVfbW9kdWxlcy9AaGF6YWU0MS9zeW1ib2wtZGlzcG9zZS1wb2x5ZmlsbC9kaXN0L2VzbS9pbmRleC5tanMKCi8vIyBzb3VyY2VNYXBwaW5nVVJMPWluZGV4Lm1qcy5tYXAKCjsvLyBDT05DQVRFTkFURUQgTU9EVUxFOiAuL25vZGVfbW9kdWxlcy9AaGF6YWU0MS9mdXR1cmUvZGlzdC9lc20vbW9kcy9mdXR1cmUvZnV0dXJlLm1qcwpjbGFzcyBGdXR1cmUgewogICAgI3Jlc29sdmU7CiAgICAjcmVqZWN0OwogICAgcHJvbWlzZTsKICAgIC8qKgogICAgICogSnVzdCBsaWtlIGEgUHJvbWlzZSBidXQgeW91IGNhbiBtYW51YWxseSByZXNvbHZlIG9yIHJlamVjdCBpdAogICAgICovCiAgICBjb25zdHJ1Y3RvcigpIHsKICAgICAgICB0aGlzLnByb21pc2UgPSBuZXcgUHJvbWlzZSgoc3VicmVzb2x2ZSwgc3VicmVqZWN0KSA9PiB7CiAgICAgICAgICAgIHRoaXMuI3Jlc29sdmUgPSBzdWJyZXNvbHZlOwogICAgICAgICAgICB0aGlzLiNyZWplY3QgPSBzdWJyZWplY3Q7CiAgICAgICAgfSk7CiAgICB9CiAgICBnZXQgcmVzb2x2ZSgpIHsKICAgICAgICByZXR1cm4gdGhpcy4jcmVzb2x2ZTsKICAgIH0KICAgIGdldCByZWplY3QoKSB7CiAgICAgICAgcmV0dXJuIHRoaXMuI3JlamVjdDsKICAgIH0KfQoKCi8vIyBzb3VyY2VNYXBwaW5nVVJMPWZ1dHVyZS5tanMubWFwCgo7Ly8gQ09OQ0FURU5BVEVEIE1PRFVMRTogLi9ub2RlX21vZHVsZXMvQGhhemFlNDEvb3B0aW9uL2Rpc3QvZXNtL21vZHMvb3B0aW9uL25vbmUubWpzCgoKY2xhc3MgTm9uZUVycm9yIGV4dGVuZHMgRXJyb3IgewogICAgY29uc3RydWN0b3IoKSB7CiAgICAgICAgc3VwZXIoYE9wdGlvbiBpcyBhIE5vbmVgKTsKICAgIH0KfQpjbGFzcyBOb25lIHsKICAgIGlubmVyOwogICAgLyoqCiAgICAgKiBBbiBlbXB0eSB2YWx1ZQogICAgICovCiAgICBjb25zdHJ1Y3Rvcihpbm5lciA9IHVuZGVmaW5lZCkgewogICAgICAgIHRoaXMuaW5uZXIgPSBpbm5lcjsKICAgIH0KICAgIC8qKgogICAgICogQ3JlYXRlIGEgYE5vbmVgCiAgICAgKiBAcmV0dXJucyBgTm9uZWAKICAgICAqLwogICAgc3RhdGljIG5ldygpIHsKICAgICAgICByZXR1cm4gbmV3IE5vbmUoKTsKICAgIH0KICAgIHN0YXRpYyBmcm9tKGluaXQpIHsKICAgICAgICByZXR1cm4gbmV3IE5vbmUoKTsKICAgIH0KICAgIC8qKgogICAgICogVHlwZSBndWFyZCBmb3IgYFNvbWVgCiAgICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYFNvbWVgLCBgZmFsc2VgIGlmIGBOb25lYAogICAgICovCiAgICBpc1NvbWUoKSB7CiAgICAgICAgcmV0dXJuIGZhbHNlOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGB0cnVlYCBpZiB0aGUgb3B0aW9uIGlzIGEgYFNvbWVgIGFuZCB0aGUgdmFsdWUgaW5zaWRlIG9mIGl0IG1hdGNoZXMgYSBwcmVkaWNhdGUKICAgICAqIEBwYXJhbSBzb21lUHJlZGljYXRlCiAgICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYFNvbWVgIGFuZCBgYXdhaXQgc29tZVByZWRpY2F0ZSh0aGlzLmlubmVyKWAsIGBOb25lYCBvdGhlcndpc2UKICAgICAqLwogICAgYXN5bmMgaXNTb21lQW5kKHNvbWVQcmVkaWNhdGUpIHsKICAgICAgICByZXR1cm4gZmFsc2U7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYHRydWVgIGlmIHRoZSBvcHRpb24gaXMgYSBgU29tZWAgYW5kIHRoZSB2YWx1ZSBpbnNpZGUgb2YgaXQgbWF0Y2hlcyBhIHByZWRpY2F0ZQogICAgICogQHBhcmFtIHNvbWVQcmVkaWNhdGUKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgU29tZWAgYW5kIGBzb21lUHJlZGljYXRlKHRoaXMuaW5uZXIpYCwgYE5vbmVgIG90aGVyd2lzZQogICAgICovCiAgICBpc1NvbWVBbmRTeW5jKHNvbWVQcmVkaWNhdGUpIHsKICAgICAgICByZXR1cm4gZmFsc2U7CiAgICB9CiAgICAvKioKICAgICAqIFR5cGUgZ3VhcmQgZm9yIGBOb25lYAogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBOb25lYCwgYGZhbHNlYCBpZiBgU29tZWAKICAgICAqLwogICAgaXNOb25lKCkgewogICAgICAgIHJldHVybiB0cnVlOwogICAgfQogICAgLyoqCiAgICAgKiBDb21waWxlLXRpbWUgc2FmZWx5IGdldCBgdGhpcy5pbm5lcmAKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYAogICAgICovCiAgICBnZXQoKSB7CiAgICAgICAgcmV0dXJuIHRoaXMuaW5uZXI7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYW4gaXRlcmF0b3Igb3ZlciB0aGUgcG9zc2libHkgY29udGFpbmVkIHZhbHVlCiAgICAgKiBAeWllbGRzIGB0aGlzLmlubmVyYCBpZiBgU29tZWAKICAgICAqLwogICAgKltTeW1ib2wuaXRlcmF0b3JdKCkgewogICAgICAgIHJldHVybjsKICAgIH0KICAgIC8qKgogICAgICogR2V0IHRoZSBpbm5lciB2YWx1ZSBpZiBgU29tZWAsIHRocm93IGBFcnJvcihtZXNzYWdlKWAgb3RoZXJ3aXNlCiAgICAgKiBAcGFyYW0gbWVzc2FnZQogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBTb21lYAogICAgICogQHRocm93cyBgRXJyb3IobWVzc2FnZSlgIGlmIGBOb25lYAogICAgICovCiAgICBleHBlY3QobWVzc2FnZSkgewogICAgICAgIHRocm93IG5ldyBFcnJvcihtZXNzYWdlKTsKICAgIH0KICAgIC8qKgogICAgICogR2V0IHRoZSBpbm5lciB2YWx1ZSBvciB0aHJvdyBhIE5vbmVFcnJvcgogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBTb21lYAogICAgICogQHRocm93cyBgTm9uZUVycm9yYCBpZiBgTm9uZWAKICAgICAqLwogICAgdW53cmFwKCkgewogICAgICAgIHRocm93IG5ldyBFcnJvcihgQSBOb25lIGhhcyBiZWVuIHVud3JhcHBlZGApOwogICAgfQogICAgLyoqCiAgICAgKiBHZXQgdGhlIGlubmVyIHZhbHVlIG9yIGEgZGVmYXVsdCBvbmUKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBTb21lYCwgYHZhbHVlYCBpZiBgTm9uZWAKICAgICAqLwogICAgdW53cmFwT3IodmFsdWUpIHsKICAgICAgICByZXR1cm4gdmFsdWU7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgdGhlIGNvbnRhaW5lZCBgU29tZWAgdmFsdWUgb3IgY29tcHV0ZXMgaXQgZnJvbSBhIGNsb3N1cmUKICAgICAqIEBwYXJhbSBub25lQ2FsbGJhY2sKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgU29tZWAsIGBhd2FpdCBub25lQ2FsbGJhY2soKWAgaWYgYE5vbmVgCiAgICAgKi8KICAgIGFzeW5jIHVud3JhcE9yRWxzZShub25lQ2FsbGJhY2spIHsKICAgICAgICByZXR1cm4gYXdhaXQgbm9uZUNhbGxiYWNrKCk7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgdGhlIGNvbnRhaW5lZCBgU29tZWAgdmFsdWUgb3IgY29tcHV0ZXMgaXQgZnJvbSBhIGNsb3N1cmUKICAgICAqIEBwYXJhbSBub25lQ2FsbGJhY2sKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgU29tZWAsIGBub25lQ2FsbGJhY2soKWAgaWYgYE5vbmVgCiAgICAgKi8KICAgIHVud3JhcE9yRWxzZVN5bmMobm9uZUNhbGxiYWNrKSB7CiAgICAgICAgcmV0dXJuIG5vbmVDYWxsYmFjaygpOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm0gYE9wdGlvbjxUPmAgaW50byBgUmVzdWx0PFQsIE5vbmVFcnJvcj5gCiAgICAgKiBAcmV0dXJucyBgT2sodGhpcy5pbm5lcilgIGlmIGBTb21lYCwgYEVycihOb25lRXJyb3IpYCBpZiBgTm9uZWAKICAgICAqLwogICAgb2soKSB7CiAgICAgICAgcmV0dXJuIG5ldyBFcnIobmV3IE5vbmVFcnJvcigpKTsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtIGBPcHRpb248VD5gIGludG8gYFJlc3VsdDxULCBFPmAKICAgICAqIEBwYXJhbSBlcnJvcgogICAgICogQHJldHVybnMgYE9rKHRoaXMuaW5uZXIpYCBpZiBgU29tZWAsIGBFcnIoZXJyb3IpYCBpZiBgTm9uZWAKICAgICAqLwogICAgb2tPcihlcnJvcikgewogICAgICAgIHJldHVybiBuZXcgRXJyKGVycm9yKTsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtcyB0aGUgYE9wdGlvbjxUPmAgaW50byBhIGBSZXN1bHQ8VCwgRT5gLCBtYXBwaW5nIGBTb21lKHYpYCB0byBgT2sodilgIGFuZCBgTm9uZWAgdG8gYEVycihlcnIoKSlgCiAgICAgKiBAcGFyYW0gbm9uZUNhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgT2sodGhpcy5pbm5lcilgIGlmIGBTb21lYCwgYEVycihhd2FpdCBub25lQ2FsbGJhY2soKSlgIGlzIGBOb25lYAogICAgICovCiAgICBhc3luYyBva09yRWxzZShub25lQ2FsbGJhY2spIHsKICAgICAgICByZXR1cm4gbmV3IEVycihhd2FpdCBub25lQ2FsbGJhY2soKSk7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybXMgdGhlIGBPcHRpb248VD5gIGludG8gYSBgUmVzdWx0PFQsIEU+YCwgbWFwcGluZyBgU29tZSh2KWAgdG8gYE9rKHYpYCBhbmQgYE5vbmVgIHRvIGBFcnIoZXJyKCkpYAogICAgICogQHBhcmFtIG5vbmVDYWxsYmFjawogICAgICogQHJldHVybnMgYE9rKHRoaXMuaW5uZXIpYCBpZiBgU29tZWAsIGBFcnIobm9uZUNhbGxiYWNrKCkpYCBpcyBgTm9uZWAKICAgICAqLwogICAgb2tPckVsc2VTeW5jKG5vbmVDYWxsYmFjaykgewogICAgICAgIHJldHVybiBuZXcgRXJyKG5vbmVDYWxsYmFjaygpKTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBgTm9uZWAgaWYgdGhlIG9wdGlvbiBpcyBgTm9uZWAsIG90aGVyd2lzZSBjYWxscyBgc29tZVByZWRpY2F0ZWAgd2l0aCB0aGUgd3JhcHBlZCB2YWx1ZQogICAgICogQHBhcmFtIHNvbWVQcmVkaWNhdGUKICAgICAqIEByZXR1cm5zIGBTb21lYCBpZiBgU29tZWAgYW5kIGBhd2FpdCBzb21lUHJlZGljYXRlKHRoaXMuaW5uZXIpYCwgYE5vbmVgIG90aGVyd2lzZQogICAgICovCiAgICBhc3luYyBmaWx0ZXIoc29tZVByZWRpY2F0ZSkgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGBOb25lYCBpZiB0aGUgb3B0aW9uIGlzIGBOb25lYCwgb3RoZXJ3aXNlIGNhbGxzIGBzb21lUHJlZGljYXRlYCB3aXRoIHRoZSB3cmFwcGVkIHZhbHVlCiAgICAgKiBAcGFyYW0gc29tZVByZWRpY2F0ZQogICAgICogQHJldHVybnMgYFNvbWVgIGlmIGBTb21lYCBhbmQgYHNvbWVQcmVkaWNhdGUodGhpcy5pbm5lcilgLCBgTm9uZWAgb3RoZXJ3aXNlCiAgICAgKi8KICAgIGZpbHRlclN5bmMoc29tZVByZWRpY2F0ZSkgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm0gYE9wdGlvbjxQcm9taXNlPFQ+PmAgaW50byBgUHJvbWlzZTxPcHRpb248VD4+YAogICAgICogQHJldHVybnMgYFByb21pc2U8T3B0aW9uPFQ+PmAKICAgICAqLwogICAgYXN5bmMgYXdhaXQoKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYHRydWVgIGlmIHRoZSBvcHRpb24gaXMgYSBgU29tZWAgdmFsdWUgY29udGFpbmluZyB0aGUgZ2l2ZW4gdmFsdWUKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBTb21lYCBhbmQgYHRoaXMuaW5uZXIgPT09IHZhbHVlYCwgYE5vbmVgIG90aGVyd2lzZQogICAgICovCiAgICBjb250YWlucyh2YWx1ZSkgewogICAgICAgIHJldHVybiBmYWxzZTsKICAgIH0KICAgIC8qKgogICAgICogQ2FsbHMgdGhlIGdpdmVuIGNhbGxiYWNrIHdpdGggdGhlIGlubmVyIHZhbHVlIGlmIGBPa2AKICAgICAqIEBwYXJhbSBzb21lQ2FsbGJhY2sKICAgICAqIEByZXR1cm5zIGB0aGlzYAogICAgICovCiAgICBhc3luYyBpbnNwZWN0KHNvbWVDYWxsYmFjaykgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBDYWxscyB0aGUgZ2l2ZW4gY2FsbGJhY2sgd2l0aCB0aGUgaW5uZXIgdmFsdWUgaWYgYE9rYAogICAgICogQHBhcmFtIHNvbWVDYWxsYmFjawogICAgICogQHJldHVybnMgYHRoaXNgCiAgICAgKi8KICAgIGluc3BlY3RTeW5jKHNvbWVDYWxsYmFjaykgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBNYXBzIGFuIGBPcHRpb248VD5gIHRvIGBPcHRpb248VT5gIGJ5IGFwcGx5aW5nIGEgZnVuY3Rpb24gdG8gYSBjb250YWluZWQgdmFsdWUgKGlmIGBTb21lYCkgb3IgcmV0dXJucyBgTm9uZWAgKGlmIGBOb25lYCkKICAgICAqIEBwYXJhbSBzb21lTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgU29tZShhd2FpdCBzb21lTWFwcGVyKHRoaXMuaW5uZXIpKWAgaWYgYFNvbWVgLCBgdGhpc2AgaWYgYE5vbmVgCiAgICAgKi8KICAgIGFzeW5jIG1hcChzb21lTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIE1hcHMgYW4gYE9wdGlvbjxUPmAgdG8gYE9wdGlvbjxVPmAgYnkgYXBwbHlpbmcgYSBmdW5jdGlvbiB0byBhIGNvbnRhaW5lZCB2YWx1ZSAoaWYgYFNvbWVgKSBvciByZXR1cm5zIGBOb25lYCAoaWYgYE5vbmVgKQogICAgICogQHBhcmFtIHNvbWVNYXBwZXIKICAgICAqIEByZXR1cm5zIGBTb21lKHNvbWVNYXBwZXIodGhpcy5pbm5lcikpYCBpZiBgU29tZWAsIGB0aGlzYCBpZiBgTm9uZWAKICAgICAqLwogICAgbWFwU3luYyhzb21lTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgdGhlIHByb3ZpZGVkIGRlZmF1bHQgcmVzdWx0IChpZiBub25lKSwgb3IgYXBwbGllcyBhIGZ1bmN0aW9uIHRvIHRoZSBjb250YWluZWQgdmFsdWUgKGlmIGFueSkKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHBhcmFtIHNvbWVNYXBwZXIKICAgICAqIEByZXR1cm5zIGB2YWx1ZWAgaWYgYE5vbmVgLCBgYXdhaXQgc29tZU1hcHBlcih0aGlzLmlubmVyKWAgaWYgYFNvbWVgCiAgICAgKi8KICAgIGFzeW5jIG1hcE9yKHZhbHVlLCBzb21lTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIHZhbHVlOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIHRoZSBwcm92aWRlZCBkZWZhdWx0IHJlc3VsdCAoaWYgbm9uZSksIG9yIGFwcGxpZXMgYSBmdW5jdGlvbiB0byB0aGUgY29udGFpbmVkIHZhbHVlIChpZiBhbnkpCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEBwYXJhbSBzb21lTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgdmFsdWVgIGlmIGBOb25lYCwgYHNvbWVNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBTb21lYAogICAgICovCiAgICBtYXBPclN5bmModmFsdWUsIHNvbWVNYXBwZXIpIHsKICAgICAgICByZXR1cm4gdmFsdWU7CiAgICB9CiAgICAvKioKICAgICAqIENvbXB1dGVzIGEgZGVmYXVsdCBmdW5jdGlvbiByZXN1bHQgKGlmIG5vbmUpLCBvciBhcHBsaWVzIGEgZGlmZmVyZW50IGZ1bmN0aW9uIHRvIHRoZSBjb250YWluZWQgdmFsdWUgKGlmIGFueSkKICAgICAqIEBwYXJhbSBub25lQ2FsbGJhY2sKICAgICAqIEBwYXJhbSBzb21lTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgYXdhaXQgc29tZU1hcHBlcih0aGlzLmlubmVyKWAgaWYgYFNvbWVgLCBgYXdhaXQgbm9uZUNhbGxiYWNrKClgIGlmIGBOb25lYAogICAgICovCiAgICBhc3luYyBtYXBPckVsc2Uobm9uZUNhbGxiYWNrLCBzb21lTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIGF3YWl0IG5vbmVDYWxsYmFjaygpOwogICAgfQogICAgLyoqCiAgICAgKiBDb21wdXRlcyBhIGRlZmF1bHQgZnVuY3Rpb24gcmVzdWx0IChpZiBub25lKSwgb3IgYXBwbGllcyBhIGRpZmZlcmVudCBmdW5jdGlvbiB0byB0aGUgY29udGFpbmVkIHZhbHVlIChpZiBhbnkpCiAgICAgKiBAcGFyYW0gbm9uZUNhbGxiYWNrCiAgICAgKiBAcGFyYW0gc29tZU1hcHBlcgogICAgICogQHJldHVybnMgYHNvbWVNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBTb21lYCwgYG5vbmVDYWxsYmFjaygpYCBpZiBgTm9uZWAKICAgICAqLwogICAgbWFwT3JFbHNlU3luYyhub25lQ2FsbGJhY2ssIHNvbWVNYXBwZXIpIHsKICAgICAgICByZXR1cm4gbm9uZUNhbGxiYWNrKCk7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYE5vbmVgIGlmIHRoZSBvcHRpb24gaXMgYE5vbmVgLCBvdGhlcndpc2UgcmV0dXJucyBgdmFsdWVgCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEByZXR1cm5zIGBOb25lYCBpZiBgTm9uZWAsIGB2YWx1ZWAgaWYgYFNvbWVgCiAgICAgKi8KICAgIGFuZCh2YWx1ZSkgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGBOb25lYCBpZiB0aGUgb3B0aW9uIGlzIGBOb25lYCwgb3RoZXJ3aXNlIGNhbGxzIGBzb21lTWFwcGVyYCB3aXRoIHRoZSB3cmFwcGVkIHZhbHVlIGFuZCByZXR1cm5zIHRoZSByZXN1bHQKICAgICAqIEBwYXJhbSBzb21lTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgTm9uZWAgaWYgYE5vbmVgLCBgYXdhaXQgc29tZU1hcHBlcih0aGlzLmlubmVyKWAgaWYgYFNvbWVgCiAgICAgKi8KICAgIGFzeW5jIGFuZFRoZW4oc29tZU1hcHBlcikgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGBOb25lYCBpZiB0aGUgb3B0aW9uIGlzIGBOb25lYCwgb3RoZXJ3aXNlIGNhbGxzIGBzb21lTWFwcGVyYCB3aXRoIHRoZSB3cmFwcGVkIHZhbHVlIGFuZCByZXR1cm5zIHRoZSByZXN1bHQKICAgICAqIEBwYXJhbSBzb21lTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgTm9uZWAgaWYgYE5vbmVgLCBgc29tZU1hcHBlcih0aGlzLmlubmVyKWAgaWYgYFNvbWVgCiAgICAgKi8KICAgIGFuZFRoZW5TeW5jKHNvbWVNYXBwZXIpIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBgdGhpc2AgaWYgYFNvbWVgLCBvdGhlcndpc2UgcmV0dXJucyBgdmFsdWVgCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEByZXR1cm5zIGB0aGlzYCBpZiBgU29tZWAsIGB2YWx1ZWAgaWYgYE5vbmVgCiAgICAgKi8KICAgIG9yKHZhbHVlKSB7CiAgICAgICAgcmV0dXJuIHZhbHVlOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGB0aGlzYCBpZiBgU29tZWAsIG90aGVyd2lzZSBjYWxscyBgbm9uZUNhbGxiYWNrYCBhbmQgcmV0dXJucyB0aGUgcmVzdWx0CiAgICAgKiBAcGFyYW0gbm9uZUNhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgdGhpc2AgaWYgYFNvbWVgLCBgYXdhaXQgbm9uZUNhbGxiYWNrKClgIGlmIGBOb25lYAogICAgICovCiAgICBhc3luYyBvckVsc2Uobm9uZUNhbGxiYWNrKSB7CiAgICAgICAgcmV0dXJuIGF3YWl0IG5vbmVDYWxsYmFjaygpOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGB0aGlzYCBpZiBgU29tZWAsIG90aGVyd2lzZSBjYWxscyBgbm9uZUNhbGxiYWNrYCBhbmQgcmV0dXJucyB0aGUgcmVzdWx0CiAgICAgKiBAcGFyYW0gbm9uZUNhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgdGhpc2AgaWYgYFNvbWVgLCBgbm9uZUNhbGxiYWNrKClgIGlmIGBOb25lYAogICAgICovCiAgICBvckVsc2VTeW5jKG5vbmVDYWxsYmFjaykgewogICAgICAgIHJldHVybiBub25lQ2FsbGJhY2soKTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBgU29tZWAgaWYgZXhhY3RseSBvbmUgb2YgdGhlIG9wdGlvbnMgaXMgYFNvbWVgLCBvdGhlcndpc2UgcmV0dXJucyBgTm9uZWAKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHJldHVybnMgYE5vbmVgIGlmIGJvdGggYXJlIGBTb21lYCBvciBib3RoIGFyZSBgTm9uZWAsIHRoZSBvbmx5IGBTb21lYCBvdGhlcndpc2UKICAgICAqLwogICAgeG9yKHZhbHVlKSB7CiAgICAgICAgcmV0dXJuIHZhbHVlOwogICAgfQogICAgLyoqCiAgICAgKiBaaXBzIGB0aGlzYCB3aXRoIGFub3RoZXIgYE9wdGlvbmAKICAgICAqIEBwYXJhbSBvdGhlcgogICAgICogQHJldHVybnMgYFNvbWUoW3RoaXMuaW5uZXIsIG90aGVyLmlubmVyXSlgIGlmIGJvdGggYXJlIGBTb21lYCwgYE5vbmVgIGlmIG9uZSBvZiB0aGVtIGlzIGBOb25lYAogICAgICovCiAgICB6aXAob3RoZXIpIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KfQoKCi8vIyBzb3VyY2VNYXBwaW5nVVJMPW5vbmUubWpzLm1hcAoKOy8vIENPTkNBVEVOQVRFRCBNT0RVTEU6IC4vbm9kZV9tb2R1bGVzL0BoYXphZTQxL3Jlc3VsdC9kaXN0L2VzbS9tb2RzL3Jlc3VsdC9lcnJvcnMubWpzCgoKY2xhc3MgVW5pbXBsZW1lbnRlZCBleHRlbmRzICgvKiB1bnVzZWQgcHVyZSBleHByZXNzaW9uIG9yIHN1cGVyICovIG51bGwgJiYgKEVycm9yKSkgewogICAgI2NsYXNzID0gVW5pbXBsZW1lbnRlZDsKICAgIG5hbWUgPSB0aGlzLiNjbGFzcy5uYW1lOwogICAgY29uc3RydWN0b3Iob3B0aW9ucykgewogICAgICAgIHN1cGVyKGBTb21ldGhpbmcgaXMgbm90IGltcGxlbWVudGVkYCwgb3B0aW9ucyk7CiAgICB9Cn0KY2xhc3MgQXNzZXJ0RXJyb3IgZXh0ZW5kcyBFcnJvciB7CiAgICAjY2xhc3MgPSBBc3NlcnRFcnJvcjsKICAgIG5hbWUgPSB0aGlzLiNjbGFzcy5uYW1lOwogICAgY29uc3RydWN0b3Iob3B0aW9ucykgewogICAgICAgIHN1cGVyKGBTb21lIGFzc2VydGlvbiBmYWlsZWRgLCBvcHRpb25zKTsKICAgIH0KfQpjbGFzcyBQYW5pYyBleHRlbmRzIEVycm9yIHsKICAgICNjbGFzcyA9IFBhbmljOwogICAgbmFtZSA9IHRoaXMuI2NsYXNzLm5hbWU7CiAgICBzdGF0aWMgZnJvbShjYXVzZSkgewogICAgICAgIHJldHVybiBuZXcgUGFuaWMoYFNvbWV0aGluZyB3YXMgbm90IGV4cGVjdGVkYCwgeyBjYXVzZSB9KTsKICAgIH0KICAgIHN0YXRpYyBmcm9tQW5kVGhyb3coY2F1c2UpIHsKICAgICAgICB0aHJvdyBuZXcgUGFuaWMoYFNvbWV0aGluZyB3YXMgbm90IGV4cGVjdGVkYCwgeyBjYXVzZSB9KTsKICAgIH0KfQpjbGFzcyBDYXRjaGVkIGV4dGVuZHMgRXJyb3IgewogICAgI2NsYXNzID0gQ2F0Y2hlZDsKICAgIG5hbWUgPSB0aGlzLiNjbGFzcy5uYW1lOwogICAgY29uc3RydWN0b3Iob3B0aW9ucykgewogICAgICAgIHN1cGVyKGBTb21ldGhpbmcgaGFzIGJlZW4gY2F0Y2hlZGAsIG9wdGlvbnMpOwogICAgfQogICAgc3RhdGljIGZyb20oY2F1c2UpIHsKICAgICAgICByZXR1cm4gbmV3IENhdGNoZWQoeyBjYXVzZSB9KTsKICAgIH0KICAgIHN0YXRpYyBmcm9tQW5kVGhyb3coY2F1c2UpIHsKICAgICAgICB0aHJvdyBuZXcgQ2F0Y2hlZCh7IGNhdXNlIH0pOwogICAgfQogICAgLyoqCiAgICAgKiBUaHJvdyBpZiBgQ2F0Y2hlZGAsIHdyYXAgaW4gYEVycmAgb3RoZXJ3aXNlCiAgICAgKiBAcGFyYW0gZXJyb3IKICAgICAqIEByZXR1cm5zIGBFcnIoZXJyb3IpYCBpZiBub3QgYENhdGNoZWRgCiAgICAgKiBAdGhyb3dzIGBlcnJvci5jYXVzZWAgaWYgYENhdGNoZWRgCiAgICAgKi8KICAgIHN0YXRpYyB0aHJvd09yRXJyKGVycm9yKSB7CiAgICAgICAgaWYgKGVycm9yIGluc3RhbmNlb2YgQ2F0Y2hlZCkKICAgICAgICAgICAgdGhyb3cgZXJyb3IuY2F1c2U7CiAgICAgICAgcmV0dXJuIG5ldyBFcnIoZXJyb3IpOwogICAgfQp9CgoKLy8jIHNvdXJjZU1hcHBpbmdVUkw9ZXJyb3JzLm1qcy5tYXAKCjsvLyBDT05DQVRFTkFURUQgTU9EVUxFOiAuL25vZGVfbW9kdWxlcy9AaGF6YWU0MS9vcHRpb24vZGlzdC9lc20vbW9kcy9vcHRpb24vb3B0aW9uLm1qcwoKCgp2YXIgT3B0aW9uOwooZnVuY3Rpb24gKE9wdGlvbikgewogICAgZnVuY3Rpb24gZnJvbShpbml0KSB7CiAgICAgICAgaWYgKCJpbm5lciIgaW4gaW5pdCkKICAgICAgICAgICAgcmV0dXJuIG5ldyBTb21lKGluaXQuaW5uZXIpOwogICAgICAgIHJldHVybiBuZXcgTm9uZSgpOwogICAgfQogICAgT3B0aW9uLmZyb20gPSBmcm9tOwogICAgLyoqCiAgICAgKiBDcmVhdGUgYW4gT3B0aW9uIGZyb20gYSBudWxsYWJsZSB2YWx1ZQogICAgICogQHBhcmFtIGlubmVyCiAgICAgKiBAcmV0dXJucyBgU29tZTxUPmAgaWYgYFRgLCBgTm9uZWAgaWYgYHVuZGVmaW5lZGAKICAgICAqLwogICAgZnVuY3Rpb24gd3JhcChpbm5lcikgewogICAgICAgIGlmIChpbm5lciA9PSBudWxsKQogICAgICAgICAgICByZXR1cm4gbmV3IE5vbmUoKTsKICAgICAgICByZXR1cm4gbmV3IFNvbWUoaW5uZXIpOwogICAgfQogICAgT3B0aW9uLndyYXAgPSB3cmFwOwogICAgYXN5bmMgZnVuY3Rpb24gbWFwKGlubmVyLCBtYXBwZXIpIHsKICAgICAgICByZXR1cm4gT3B0aW9uLndyYXAoaW5uZXIpLm1hcChtYXBwZXIpLnRoZW4obyA9PiBvLmdldCgpKTsKICAgIH0KICAgIE9wdGlvbi5tYXAgPSBtYXA7CiAgICBmdW5jdGlvbiBtYXBTeW5jKGlubmVyLCBtYXBwZXIpIHsKICAgICAgICByZXR1cm4gT3B0aW9uLndyYXAoaW5uZXIpLm1hcFN5bmMobWFwcGVyKS5nZXQoKTsKICAgIH0KICAgIE9wdGlvbi5tYXBTeW5jID0gbWFwU3luYzsKICAgIGZ1bmN0aW9uIHVud3JhcChpbm5lcikgewogICAgICAgIHJldHVybiBPcHRpb24ud3JhcChpbm5lcikudW53cmFwKCk7CiAgICB9CiAgICBPcHRpb24udW53cmFwID0gdW53cmFwOwp9KShPcHRpb24gfHwgKE9wdGlvbiA9IHt9KSk7CgoKLy8jIHNvdXJjZU1hcHBpbmdVUkw9b3B0aW9uLm1qcy5tYXAKCjsvLyBDT05DQVRFTkFURUQgTU9EVUxFOiAuL25vZGVfbW9kdWxlcy9AaGF6YWU0MS9yZXN1bHQvZGlzdC9lc20vbW9kcy9yZXN1bHQvcmVzdWx0Lm1qcwoKCgoKCnZhciBSZXN1bHQ7CihmdW5jdGlvbiAoUmVzdWx0KSB7CiAgICBSZXN1bHQuZGVidWcgPSBmYWxzZTsKICAgIC8qKgogICAgICogQ3JlYXRlIGEgUmVzdWx0IGZyb20gYSBtYXliZSBFcnJvciB2YWx1ZQogICAgICogQHBhcmFtIGlubmVyCiAgICAgKiBAcmV0dXJucyBgT2s8VD5gIGlmIGBUYCwgYEVycjxFcnJvcj5gIGlmIGBFcnJvcmAKICAgICAqLwogICAgZnVuY3Rpb24gZnJvbShpbm5lcikgewogICAgICAgIGlmIChpbm5lciBpbnN0YW5jZW9mIEVycm9yKQogICAgICAgICAgICByZXR1cm4gbmV3IEVycihpbm5lcik7CiAgICAgICAgZWxzZQogICAgICAgICAgICByZXR1cm4gbmV3IE9rKGlubmVyKTsKICAgIH0KICAgIFJlc3VsdC5mcm9tID0gZnJvbTsKICAgIC8qKgogICAgICogQ3JlYXRlIGEgUmVzdWx0IGZyb20gYSBib29sZWFuCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEByZXR1cm5zCiAgICAgKi8KICAgIGZ1bmN0aW9uIGFzc2VydCh2YWx1ZSkgewogICAgICAgIHJldHVybiB2YWx1ZSA/IE9rLnZvaWQoKSA6IG5ldyBFcnIobmV3IEFzc2VydEVycm9yKCkpOwogICAgfQogICAgUmVzdWx0LmFzc2VydCA9IGFzc2VydDsKICAgIGZ1bmN0aW9uIHJld3JhcCh3cmFwcGVyKSB7CiAgICAgICAgdHJ5IHsKICAgICAgICAgICAgcmV0dXJuIG5ldyBPayh3cmFwcGVyLnVud3JhcCgpKTsKICAgICAgICB9CiAgICAgICAgY2F0Y2ggKGVycm9yKSB7CiAgICAgICAgICAgIHJldHVybiBuZXcgRXJyKGVycm9yKTsKICAgICAgICB9CiAgICB9CiAgICBSZXN1bHQucmV3cmFwID0gcmV3cmFwOwogICAgLyoqCiAgICAgKiBDYXRjaCBhbiBFcnIgdGhyb3duIGZyb20gRXJyLnRocm93CiAgICAgKiBAcGFyYW0gY2FsbGJhY2sKICAgICAqIEBwYXJhbSB0eXBlCiAgICAgKiBAcmV0dXJucyBgT2s8VD5gIGlmIG5vIGBFcnJgIHdhcyB0aHJvd24sIGBFcnI8RT5gIG90aGVyd2lzZQogICAgICogQHNlZSBFcnIudGhyb3cKICAgICAqLwogICAgYXN5bmMgZnVuY3Rpb24gdW50aHJvdyhjYWxsYmFjaykgewogICAgICAgIGxldCByZWY7CiAgICAgICAgdHJ5IHsKICAgICAgICAgICAgcmV0dXJuIGF3YWl0IGNhbGxiYWNrKChlKSA9PiByZWYgPSBlKTsKICAgICAgICB9CiAgICAgICAgY2F0Y2ggKGUpIHsKICAgICAgICAgICAgaWYgKHJlZiAhPT0gdW5kZWZpbmVkKQogICAgICAgICAgICAgICAgcmV0dXJuIHJlZjsKICAgICAgICAgICAgdGhyb3cgZTsKICAgICAgICB9CiAgICB9CiAgICBSZXN1bHQudW50aHJvdyA9IHVudGhyb3c7CiAgICAvKioKICAgICAqIENhdGNoIGFuIEVyciB0aHJvd24gZnJvbSBFcnIudGhyb3cKICAgICAqIEBwYXJhbSBjYWxsYmFjawogICAgICogQHBhcmFtIHR5cGUKICAgICAqIEByZXR1cm5zIGBPazxUPmAgaWYgbm8gYEVycmAgd2FzIHRocm93biwgYEVycjxFPmAgb3RoZXJ3aXNlCiAgICAgKiBAc2VlIEVyci50aHJvdwogICAgICovCiAgICBmdW5jdGlvbiB1bnRocm93U3luYyhjYWxsYmFjaykgewogICAgICAgIGxldCByZWY7CiAgICAgICAgdHJ5IHsKICAgICAgICAgICAgcmV0dXJuIGNhbGxiYWNrKChlKSA9PiByZWYgPSBlKTsKICAgICAgICB9CiAgICAgICAgY2F0Y2ggKGUpIHsKICAgICAgICAgICAgaWYgKHJlZiAhPT0gdW5kZWZpbmVkKQogICAgICAgICAgICAgICAgcmV0dXJuIHJlZjsKICAgICAgICAgICAgdGhyb3cgZTsKICAgICAgICB9CiAgICB9CiAgICBSZXN1bHQudW50aHJvd1N5bmMgPSB1bnRocm93U3luYzsKICAgIC8qKgogICAgICogUnVuIGEgY2FsbGJhY2sgYW5kIHdyYXAgYW55IHJldHVybmVkIHZhbHVlIGluIE9rPFQ+IGFuZCBhbnkgdGhyb3duIGVycm9yIGluIEVycjx1bmtub3duPgogICAgICogQHBhcmFtIGNhbGxiYWNrCiAgICAgKiBAcmV0dXJucwogICAgICovCiAgICBhc3luYyBmdW5jdGlvbiBydW5BbmRXcmFwKGNhbGxiYWNrKSB7CiAgICAgICAgdHJ5IHsKICAgICAgICAgICAgcmV0dXJuIG5ldyBPayhhd2FpdCBjYWxsYmFjaygpKTsKICAgICAgICB9CiAgICAgICAgY2F0Y2ggKGUpIHsKICAgICAgICAgICAgcmV0dXJuIG5ldyBFcnIoZSk7CiAgICAgICAgfQogICAgfQogICAgUmVzdWx0LnJ1bkFuZFdyYXAgPSBydW5BbmRXcmFwOwogICAgLyoqCiAgICAgKiBSdW4gYSBjYWxsYmFjayBhbmQgd3JhcCBhbnkgcmV0dXJuZWQgdmFsdWUgaW4gT2s8VD4gYW5kIGFueSB0aHJvd24gZXJyb3IgaW4gRXJyPHVua25vd24+CiAgICAgKiBAcGFyYW0gY2FsbGJhY2sKICAgICAqIEByZXR1cm5zCiAgICAgKi8KICAgIGZ1bmN0aW9uIHJ1bkFuZFdyYXBTeW5jKGNhbGxiYWNrKSB7CiAgICAgICAgdHJ5IHsKICAgICAgICAgICAgcmV0dXJuIG5ldyBPayhjYWxsYmFjaygpKTsKICAgICAgICB9CiAgICAgICAgY2F0Y2ggKGUpIHsKICAgICAgICAgICAgcmV0dXJuIG5ldyBFcnIoZSk7CiAgICAgICAgfQogICAgfQogICAgUmVzdWx0LnJ1bkFuZFdyYXBTeW5jID0gcnVuQW5kV3JhcFN5bmM7CiAgICAvKioKICAgICAqIFJ1biBhIGNhbGxiYWNrIGFuZCB3cmFwIGFueSByZXR1cm5lZCB2YWx1ZSBpbiBPazxUPiBhbmQgYW55IHRocm93biBlcnJvciBpbiBFcnI8Q2F0Y2hlZD4KICAgICAqIEBwYXJhbSBjYWxsYmFjawogICAgICogQHJldHVybnMKICAgICAqLwogICAgYXN5bmMgZnVuY3Rpb24gcnVuQW5kRG91YmxlV3JhcChjYWxsYmFjaykgewogICAgICAgIHRyeSB7CiAgICAgICAgICAgIHJldHVybiBuZXcgT2soYXdhaXQgY2FsbGJhY2soKSk7CiAgICAgICAgfQogICAgICAgIGNhdGNoIChlKSB7CiAgICAgICAgICAgIHJldHVybiBuZXcgRXJyKENhdGNoZWQuZnJvbShlKSk7CiAgICAgICAgfQogICAgfQogICAgUmVzdWx0LnJ1bkFuZERvdWJsZVdyYXAgPSBydW5BbmREb3VibGVXcmFwOwogICAgLyoqCiAgICAgKiBSdW4gYSBjYWxsYmFjayBhbmQgd3JhcCBhbnkgcmV0dXJuZWQgdmFsdWUgaW4gT2s8VD4gYW5kIGFueSB0aHJvd24gZXJyb3IgaW4gRXJyPENhdGNoZWQ+CiAgICAgKiBAcGFyYW0gY2FsbGJhY2sKICAgICAqIEByZXR1cm5zCiAgICAgKi8KICAgIGZ1bmN0aW9uIHJ1bkFuZERvdWJsZVdyYXBTeW5jKGNhbGxiYWNrKSB7CiAgICAgICAgdHJ5IHsKICAgICAgICAgICAgcmV0dXJuIG5ldyBPayhjYWxsYmFjaygpKTsKICAgICAgICB9CiAgICAgICAgY2F0Y2ggKGUpIHsKICAgICAgICAgICAgcmV0dXJuIG5ldyBFcnIoQ2F0Y2hlZC5mcm9tKGUpKTsKICAgICAgICB9CiAgICB9CiAgICBSZXN1bHQucnVuQW5kRG91YmxlV3JhcFN5bmMgPSBydW5BbmREb3VibGVXcmFwU3luYzsKICAgIC8qKgogICAgICogUnVuIGEgY2FsbGJhY2sgYW5kIHdyYXAgYW55IHRocm93biBlcnJvciBpbiBFcnI8dW5rbm93bj4KICAgICAqIEBwYXJhbSBjYWxsYmFjawogICAgICogQHJldHVybnMKICAgICAqLwogICAgYXN5bmMgZnVuY3Rpb24gcnVuT3JXcmFwKGNhbGxiYWNrKSB7CiAgICAgICAgdHJ5IHsKICAgICAgICAgICAgcmV0dXJuIGF3YWl0IGNhbGxiYWNrKCk7CiAgICAgICAgfQogICAgICAgIGNhdGNoIChlKSB7CiAgICAgICAgICAgIHJldHVybiBuZXcgRXJyKGUpOwogICAgICAgIH0KICAgIH0KICAgIFJlc3VsdC5ydW5PcldyYXAgPSBydW5PcldyYXA7CiAgICAvKioKICAgICAqIFJ1biBhIGNhbGxiYWNrIGFuZCB3cmFwIGFueSB0aHJvd24gZXJyb3IgaW4gRXJyPHVua25vd24+CiAgICAgKiBAcGFyYW0gY2FsbGJhY2sKICAgICAqIEByZXR1cm5zCiAgICAgKi8KICAgIGZ1bmN0aW9uIHJ1bk9yV3JhcFN5bmMoY2FsbGJhY2spIHsKICAgICAgICB0cnkgewogICAgICAgICAgICByZXR1cm4gY2FsbGJhY2soKTsKICAgICAgICB9CiAgICAgICAgY2F0Y2ggKGUpIHsKICAgICAgICAgICAgcmV0dXJuIG5ldyBFcnIoZSk7CiAgICAgICAgfQogICAgfQogICAgUmVzdWx0LnJ1bk9yV3JhcFN5bmMgPSBydW5PcldyYXBTeW5jOwogICAgLyoqCiAgICAgKiBSdW4gYSBjYWxsYmFjayBhbmQgd3JhcCBhbnkgdGhyb3duIGVycm9yIGluIEVycjx1bmtub3duPgogICAgICogQHBhcmFtIGNhbGxiYWNrCiAgICAgKiBAcmV0dXJucwogICAgICovCiAgICBhc3luYyBmdW5jdGlvbiBydW5PckRvdWJsZVdyYXAoY2FsbGJhY2spIHsKICAgICAgICB0cnkgewogICAgICAgICAgICByZXR1cm4gYXdhaXQgY2FsbGJhY2soKTsKICAgICAgICB9CiAgICAgICAgY2F0Y2ggKGUpIHsKICAgICAgICAgICAgcmV0dXJuIG5ldyBFcnIoQ2F0Y2hlZC5mcm9tKGUpKTsKICAgICAgICB9CiAgICB9CiAgICBSZXN1bHQucnVuT3JEb3VibGVXcmFwID0gcnVuT3JEb3VibGVXcmFwOwogICAgLyoqCiAgICAgKiBSdW4gYSBjYWxsYmFjayBhbmQgd3JhcCBhbnkgdGhyb3duIGVycm9yIGluIEVycjx1bmtub3duPgogICAgICogQHBhcmFtIGNhbGxiYWNrCiAgICAgKiBAcmV0dXJucwogICAgICovCiAgICBmdW5jdGlvbiBydW5PckRvdWJsZVdyYXBTeW5jKGNhbGxiYWNrKSB7CiAgICAgICAgdHJ5IHsKICAgICAgICAgICAgcmV0dXJuIGNhbGxiYWNrKCk7CiAgICAgICAgfQogICAgICAgIGNhdGNoIChlKSB7CiAgICAgICAgICAgIHJldHVybiBuZXcgRXJyKENhdGNoZWQuZnJvbShlKSk7CiAgICAgICAgfQogICAgfQogICAgUmVzdWx0LnJ1bk9yRG91YmxlV3JhcFN5bmMgPSBydW5PckRvdWJsZVdyYXBTeW5jOwogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm0gYEl0ZXJhYmxlPFJlc3VsdDxULEU+YCBpbnRvIGBSZXN1bHQ8QXJyYXk8VD4sIEU+YAogICAgICogQHBhcmFtIGl0ZXJhYmxlCiAgICAgKiBAcmV0dXJucyBgUmVzdWx0PEFycmF5PFQ+LCBFPmAKICAgICAqLwogICAgZnVuY3Rpb24gYWxsKGl0ZXJhYmxlKSB7CiAgICAgICAgcmV0dXJuIGNvbGxlY3QoaXRlcmF0ZShpdGVyYWJsZSkpOwogICAgfQogICAgUmVzdWx0LmFsbCA9IGFsbDsKICAgIGZ1bmN0aW9uIG1heWJlQWxsKGl0ZXJhYmxlKSB7CiAgICAgICAgcmV0dXJuIG1heWJlQ29sbGVjdChtYXliZUl0ZXJhdGUoaXRlcmFibGUpKTsKICAgIH0KICAgIFJlc3VsdC5tYXliZUFsbCA9IG1heWJlQWxsOwogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm0gYEl0ZXJhYmxlPFJlc3VsdDxULEU+YCBpbnRvIGBJdGVyYXRvcjxULCBSZXN1bHQ8dm9pZCwgRT4+YAogICAgICogQHBhcmFtIGl0ZXJhYmxlCiAgICAgKiBAcmV0dXJucyBgSXRlcmF0b3I8VCwgUmVzdWx0PHZvaWQsIEU+PmAKICAgICAqLwogICAgZnVuY3Rpb24qIGl0ZXJhdGUoaXRlcmFibGUpIHsKICAgICAgICBmb3IgKGNvbnN0IHJlc3VsdCBvZiBpdGVyYWJsZSkgewogICAgICAgICAgICBpZiAocmVzdWx0LmlzT2soKSkKICAgICAgICAgICAgICAgIHlpZWxkIHJlc3VsdC5nZXQoKTsKICAgICAgICAgICAgZWxzZQogICAgICAgICAgICAgICAgcmV0dXJuIHJlc3VsdDsKICAgICAgICB9CiAgICAgICAgcmV0dXJuIE9rLnZvaWQoKTsKICAgIH0KICAgIFJlc3VsdC5pdGVyYXRlID0gaXRlcmF0ZTsKICAgIGZ1bmN0aW9uKiBtYXliZUl0ZXJhdGUoaXRlcmFibGUpIHsKICAgICAgICBmb3IgKGNvbnN0IHJlc3VsdCBvZiBpdGVyYWJsZSkgewogICAgICAgICAgICBpZiAocmVzdWx0ID09IG51bGwpCiAgICAgICAgICAgICAgICByZXR1cm4gcmVzdWx0OwogICAgICAgICAgICBlbHNlIGlmIChyZXN1bHQuaXNPaygpKQogICAgICAgICAgICAgICAgeWllbGQgcmVzdWx0LmdldCgpOwogICAgICAgICAgICBlbHNlCiAgICAgICAgICAgICAgICByZXR1cm4gcmVzdWx0OwogICAgICAgIH0KICAgICAgICByZXR1cm4gT2sudm9pZCgpOwogICAgfQogICAgUmVzdWx0Lm1heWJlSXRlcmF0ZSA9IG1heWJlSXRlcmF0ZTsKICAgIC8qKgogICAgICogVHJhbnNmb3JtIGBJdGVyYXRvcjxULCBSZXN1bHQ8dm9pZCwgRT4+YCBpbnRvIGBSZXN1bHQ8QXJyYXk8VD4sIEU+YAogICAgICogQHBhcmFtIGl0ZXJhdG9yIGBSZXN1bHQ8QXJyYXk8VD4sIEU+YAogICAgICovCiAgICBmdW5jdGlvbiBjb2xsZWN0KGl0ZXJhdG9yKSB7CiAgICAgICAgY29uc3QgYXJyYXkgPSBuZXcgQXJyYXkoKTsKICAgICAgICBsZXQgcmVzdWx0ID0gaXRlcmF0b3IubmV4dCgpOwogICAgICAgIGZvciAoOyAhcmVzdWx0LmRvbmU7IHJlc3VsdCA9IGl0ZXJhdG9yLm5leHQoKSkKICAgICAgICAgICAgYXJyYXkucHVzaChyZXN1bHQudmFsdWUpOwogICAgICAgIHJldHVybiByZXN1bHQudmFsdWUuc2V0KGFycmF5KTsKICAgIH0KICAgIFJlc3VsdC5jb2xsZWN0ID0gY29sbGVjdDsKICAgIGZ1bmN0aW9uIG1heWJlQ29sbGVjdChpdGVyYXRvcikgewogICAgICAgIGNvbnN0IGFycmF5ID0gbmV3IEFycmF5KCk7CiAgICAgICAgbGV0IHJlc3VsdCA9IGl0ZXJhdG9yLm5leHQoKTsKICAgICAgICBmb3IgKDsgIXJlc3VsdC5kb25lOyByZXN1bHQgPSBpdGVyYXRvci5uZXh0KCkpCiAgICAgICAgICAgIGFycmF5LnB1c2gocmVzdWx0LnZhbHVlKTsKICAgICAgICByZXR1cm4gT3B0aW9uLm1hcFN5bmMocmVzdWx0LnZhbHVlLCByZXN1bHQgPT4gcmVzdWx0LnNldChhcnJheSkpOwogICAgfQogICAgUmVzdWx0Lm1heWJlQ29sbGVjdCA9IG1heWJlQ29sbGVjdDsKfSkoUmVzdWx0IHx8IChSZXN1bHQgPSB7fSkpOwoKCi8vIyBzb3VyY2VNYXBwaW5nVVJMPXJlc3VsdC5tanMubWFwCgo7Ly8gQ09OQ0FURU5BVEVEIE1PRFVMRTogLi9ub2RlX21vZHVsZXMvQGhhemFlNDEvcmVzdWx0L2Rpc3QvZXNtL21vZHMvcmVzdWx0L29rLm1qcwoKCgoKY2xhc3MgT2sgewogICAgI2lubmVyOwogICAgI3RpbWVvdXQ7CiAgICAvKioKICAgICAqIEEgc3VjY2VzcwogICAgICogQHBhcmFtIGlubmVyCiAgICAgKi8KICAgIGNvbnN0cnVjdG9yKGlubmVyKSB7CiAgICAgICAgdGhpcy4jaW5uZXIgPSBpbm5lcjsKICAgICAgICBpZiAoIVJlc3VsdC5kZWJ1ZykKICAgICAgICAgICAgcmV0dXJuOwogICAgICAgIGNvbnN0IGVycm9yID0gbmV3IEVycm9yKGBBbiBPayBoYXMgbm90IGJlZW4gaGFuZGxlZCBwcm9wZXJseWApOwogICAgICAgIHRoaXMuI3RpbWVvdXQgPSBzZXRUaW1lb3V0KCgpID0+IHsgdGhyb3cgZXJyb3I7IH0sIDEwMDApOwogICAgfQogICAgLyoqCiAgICAgKiBDcmVhdGUgYW4gZW1wdHkgYE9rYAogICAgICogQHJldHVybnMgYE9rKHZvaWQpYAogICAgICovCiAgICBzdGF0aWMgdm9pZCgpIHsKICAgICAgICByZXR1cm4gbmV3IE9rKHVuZGVmaW5lZCk7CiAgICB9CiAgICAvKioKICAgICAqIENyZWF0ZSBhbiBgT2tgCiAgICAgKiBAcGFyYW0gaW5uZXIKICAgICAqIEByZXR1cm5zIGBPayhpbm5lcilgCiAgICAgKi8KICAgIHN0YXRpYyBuZXcoaW5uZXIpIHsKICAgICAgICByZXR1cm4gbmV3IE9rKGlubmVyKTsKICAgIH0KICAgIGdldCBpbm5lcigpIHsKICAgICAgICByZXR1cm4gdGhpcy4jaW5uZXI7CiAgICB9CiAgICAvKioKICAgICAqIFNldCB0aGlzIHJlc3VsdCBhcyBoYW5kbGVkCiAgICAgKi8KICAgIGlnbm9yZSgpIHsKICAgICAgICBpZiAoIXRoaXMuI3RpbWVvdXQpCiAgICAgICAgICAgIHJldHVybiB0aGlzOwogICAgICAgIGNsZWFyVGltZW91dCh0aGlzLiN0aW1lb3V0KTsKICAgICAgICB0aGlzLiN0aW1lb3V0ID0gdW5kZWZpbmVkOwogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBUeXBlIGd1YXJkIGZvciBgT2tgCiAgICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYE9rYCwgYGZhbHNlYCBpZiBgRXJyYAogICAgICovCiAgICBpc09rKCkgewogICAgICAgIHJldHVybiB0cnVlOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIHRydWUgaWYgdGhlIHJlc3VsdCBpcyBgT2tgIGFuZCB0aGUgdmFsdWUgaW5zaWRlIG9mIGl0IG1hdGNoZXMgYSBwcmVkaWNhdGUKICAgICAqIEBwYXJhbSBva1ByZWRpY2F0ZQogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBPa2AgYW5kIGBhd2FpdCBva1ByZWRpY2F0ZSh0aGlzLmlubmVyKWAsIGBmYWxzZWAgb3RoZXJ3aXNlCiAgICAgKi8KICAgIGFzeW5jIGlzT2tBbmQob2tQcmVkaWNhdGUpIHsKICAgICAgICByZXR1cm4gYXdhaXQgb2tQcmVkaWNhdGUodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgdHJ1ZSBpZiB0aGUgcmVzdWx0IGlzIGBPa2AgYW5kIHRoZSB2YWx1ZSBpbnNpZGUgb2YgaXQgbWF0Y2hlcyBhIHByZWRpY2F0ZQogICAgICogQHBhcmFtIG9rUHJlZGljYXRlCiAgICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYE9rYCBhbmQgYGF3YWl0IG9rUHJlZGljYXRlKHRoaXMuaW5uZXIpYCwgYGZhbHNlYCBvdGhlcndpc2UKICAgICAqLwogICAgaXNPa0FuZFN5bmMob2tQcmVkaWNhdGUpIHsKICAgICAgICByZXR1cm4gb2tQcmVkaWNhdGUodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFR5cGUgZ3VhcmQgZm9yIGBFcnJgCiAgICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYEVycmAsIGBmYWxzZWAgaWYgYE9rYAogICAgICovCiAgICBpc0VycigpIHsKICAgICAgICByZXR1cm4gZmFsc2U7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgdHJ1ZSBpZiB0aGUgcmVzdWx0IGlzIGBFcnJgIGFuZCB0aGUgdmFsdWUgaW5zaWRlIG9mIGl0IG1hdGNoZXMgYSBwcmVkaWNhdGUKICAgICAqIEBwYXJhbSBlcnJQcmVkaWNhdGUKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgRXJyYCBhbmQgYGF3YWl0IGVyclByZWRpY2F0ZSh0aGlzLmlubmVyKWAsIGBmYWxzZWAgb3RoZXJ3aXNlCiAgICAgKi8KICAgIGFzeW5jIGlzRXJyQW5kKGVyclByZWRpY2F0ZSkgewogICAgICAgIHJldHVybiBmYWxzZTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyB0cnVlIGlmIHRoZSByZXN1bHQgaXMgYEVycmAgYW5kIHRoZSB2YWx1ZSBpbnNpZGUgb2YgaXQgbWF0Y2hlcyBhIHByZWRpY2F0ZQogICAgICogQHBhcmFtIGVyclByZWRpY2F0ZQogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBFcnJgIGFuZCBgYXdhaXQgZXJyUHJlZGljYXRlKHRoaXMuaW5uZXIpYCwgYGZhbHNlYCBvdGhlcndpc2UKICAgICAqLwogICAgaXNFcnJBbmRTeW5jKGVyclByZWRpY2F0ZSkgewogICAgICAgIHJldHVybiBmYWxzZTsKICAgIH0KICAgIC8qKgogICAgICogQ29tcGlsZS10aW1lIHNhZmVseSBnZXQgT2sncyBpbm5lciB0eXBlCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAKICAgICAqIEB0aHJvd3MgaWYgYHRoaXNgIGlzIGBFcnJgCiAgICAgKi8KICAgIGdldCgpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiB0aGlzLmlubmVyOwogICAgfQogICAgLyoqCiAgICAgKiBDb21waWxlLXRpbWUgc2FmZWx5IGdldCBFcnIncyBpbm5lciB0eXBlCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAKICAgICAqIEB0aHJvd3MgaWYgYHRoaXNgIGlzIGBPa2AKICAgICAqLwogICAgZ2V0RXJyKCkgewogICAgICAgIHRocm93IG5ldyBQYW5pYygpOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm0gYFJlc3VsdDxULCBFPmAgaW50byBgT3B0aW9uPFQ+YAogICAgICogQHJldHVybnMgYFNvbWUodGhpcy5pbm5lcilgIGlmIGBPa2AsIGBOb25lYCBpZiBgRXJyYAogICAgICovCiAgICBvaygpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiBuZXcgU29tZSh0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtIGBSZXN1bHQ8VCwgRT5gIGludG8gYE9wdGlvbjxFPmAKICAgICAqIEByZXR1cm5zIGBTb21lKHRoaXMuaW5uZXIpYCBpZiBgRXJyYCwgYE5vbmVgIGlmIGBPa2AKICAgICAqLwogICAgZXJyKCkgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIG5ldyBOb25lKCk7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYW4gaXRlcmF0b3Igb3ZlciB0aGUgcG9zc2libHkgY29udGFpbmVkIHZhbHVlCiAgICAgKiBAeWllbGRzIGB0aGlzLmlubmVyYCBpZiBgT2tgCiAgICAgKi8KICAgICpbU3ltYm9sLml0ZXJhdG9yXSgpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHlpZWxkIHRoaXMuaW5uZXI7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBgUmVzdWx0PFQsRT5gIGludG8gYFtULEVdYAogICAgICogQHJldHVybnMgYFt0aGlzLmlubmVyLCB1bmRlZmluZWRdYCBpZiBgT2tgLCBgW3VuZGVmaW5lZCwgdGhpcy5pbm5lcl1gIGlmIGBFcnJgCiAgICAgKi8KICAgIHNwbGl0KCkgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIFt0aGlzLmlubmVyLCB1bmRlZmluZWRdOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIHRydWUgaWYgdGhlIHJlc3VsdCBpcyBhbiBgT2tgIHZhbHVlIGNvbnRhaW5pbmcgdGhlIGdpdmVuIHZhbHVlCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgT2tgIGFuZCBgdGhpcy5pbm5lciA9PT0gdmFsdWVgLCBgZmFsc2VgIG90aGVyd2lzZQogICAgICovCiAgICBjb250YWlucyh2YWx1ZSkgewogICAgICAgIHJldHVybiB0aGlzLmlubmVyID09PSB2YWx1ZTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyB0cnVlIGlmIHRoZSByZXN1bHQgaXMgYW4gYEVycmAgdmFsdWUgY29udGFpbmluZyB0aGUgZ2l2ZW4gdmFsdWUKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBFcnJgIGFuZCBgdGhpcy5pbm5lciA9PT0gdmFsdWVgLCBgZmFsc2VgIG90aGVyd2lzZQogICAgICovCiAgICBjb250YWluc0Vycih2YWx1ZSkgewogICAgICAgIHJldHVybiBmYWxzZTsKICAgIH0KICAgIC8qKgogICAgICogSnVzdCBsaWtlIGB1bndyYXBgIGJ1dCBpdCB0aHJvd3MgdG8gdGhlIGNsb3Nlc3QgYFJlc3VsdC51bnRocm93YAogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBPa2AKICAgICAqIEB0aHJvd3MgYHRoaXNgIGlmIGBFcnJgCiAgICAgKiBAc2VlIFJlc3VsdC51bnRocm93CiAgICAgKiBAc2VlIFJlc3VsdC51bnRocm93U3luYwogICAgICovCiAgICB0aHJvdyh0aHJvd2VyKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gdGhpcy5pbm5lcjsKICAgIH0KICAgIC8qKgogICAgICogR2V0IHRoZSBpbm5lciB2YWx1ZSBvciB0aHJvdyB0aGUgaW5uZXIgZXJyb3Igd3JhcHBlZCBpbnNpZGUgYW5vdGhlciBFcnJvcgogICAgICogQHBhcmFtIG1lc3NhZ2UKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgT2tgLCBgRXJyb3IobWVzc2FnZSwgeyBjYXVzZTogdGhpcy5pbm5lciB9KWAgaWYgYEVycmAKICAgICAqLwogICAgZXhwZWN0KG1lc3NhZ2UpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiB0aGlzLmlubmVyOwogICAgfQogICAgLyoqCiAgICAgKiBHZXQgdGhlIGlubmVyIGVycm9yIG9yIHRocm93IHRoZSBpbm5lciB2YWx1ZSB3cmFwcGVkIGluc2lkZSBhbm90aGVyIEVycm9yCiAgICAgKiBAcGFyYW0gbWVzc2FnZQogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBFcnJgLCBgRXJyb3IobWVzc2FnZSwgeyBjYXVzZTogdGhpcy5pbm5lciB9KWAgaWYgYE9rYAogICAgICovCiAgICBleHBlY3RFcnIobWVzc2FnZSkgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgdGhyb3cgbmV3IEVycm9yKG1lc3NhZ2UsIHsgY2F1c2U6IHRoaXMuaW5uZXIgfSk7CiAgICB9CiAgICAvKioKICAgICAqIEdldCB0aGUgaW5uZXIgdmFsdWUgb3IgcGFuaWMKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgT2tgCiAgICAgKiBAdGhyb3dzIGB0aGlzLmlubmVyYCBpZiBgRXJyYAogICAgICovCiAgICB1bndyYXAoKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gdGhpcy5pbm5lcjsKICAgIH0KICAgIC8qKgogICAgICogR2V0IHRoZSBpbm5lciBlcnJvciBvciBwYW5pYwogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBFcnJgCiAgICAgKiBAdGhyb3dzIGB0aGlzLmlubmVyYCBpZiBgT2tgCiAgICAgKi8KICAgIHVud3JhcEVycigpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHRocm93IHRoaXMuaW5uZXI7CiAgICB9CiAgICAvKioKICAgICAqIEdldCB0aGUgaW5uZXIgdmFsdWUgb3IgYSBkZWZhdWx0IG9uZQogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAgaWYgYE9rYCwgYHZhbHVlYCBpZiBgRXJyYAogICAgICovCiAgICB1bndyYXBPcih2YWx1ZSkgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIHRoaXMuaW5uZXI7CiAgICB9CiAgICAvKioKICAgICAqIEdldCB0aGUgaW5uZXIgdmFsdWUgb3IgY29tcHV0ZSBhIGRlZmF1bHQgb25lIGZyb20gdGhlIGlubmVyIGVycm9yCiAgICAgKiBAcGFyYW0gZXJyTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAgaWYgYE9rYCwgYGF3YWl0IGVyck1hcHBlcih0aGlzLmlubmVyKWAgaWYgYEVycmAKICAgICAqIEB0aHJvd3MgaWYgYGF3YWl0IGVyck1hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIGFzeW5jIHVud3JhcE9yRWxzZShlcnJNYXBwZXIpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiB0aGlzLmlubmVyOwogICAgfQogICAgLyoqCiAgICAgKiBHZXQgdGhlIGlubmVyIHZhbHVlIG9yIGNvbXB1dGUgYSBkZWZhdWx0IG9uZSBmcm9tIHRoZSBpbm5lciBlcnJvcgogICAgICogQHBhcmFtIGVyck1hcHBlcgogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBPa2AsIGBlcnJNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBFcnJgCiAgICAgKiBAdGhyb3dzIGlmIGBlcnJNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICB1bndyYXBPckVsc2VTeW5jKGVyck1hcHBlcikgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIHRoaXMuaW5uZXI7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBSZXN1bHQ8UHJvbWlzZTxUPiwgRT4gaW50byBQcm9taXNlPFJlc3VsdDxULCBFPj4KICAgICAqIEByZXR1cm5zIGBhd2FpdCB0aGlzLmlubmVyYCBpZiBgT2tgLCBgdGhpc2AgaWYgYEVycmAKICAgICAqLwogICAgYXN5bmMgYXdhaXQoKSB7CiAgICAgICAgcmV0dXJuIG5ldyBPayhhd2FpdCB0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtIFJlc3VsdDxULCBQcm9taXNlPEU+PiBpbnRvIFByb21pc2U8UmVzdWx0PFQsIEU+PgogICAgICogQHJldHVybnMgYGF3YWl0IHRoaXMuaW5uZXJgIGlmIGBFcnJgLCBgdGhpc2AgaWYgYE9rYAogICAgICovCiAgICBhc3luYyBhd2FpdEVycigpIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtIFJlc3VsdDxQcm9taXNlPFQ+LCBQcm9taXNlPEU+PiBpbnRvIFByb21pc2U8UmVzdWx0PFQsIEU+PgogICAgICogQHJldHVybnMgYGF3YWl0IHRoaXMuaW5uZXJgCiAgICAgKi8KICAgIGFzeW5jIGF3YWl0QWxsKCkgewogICAgICAgIHJldHVybiBhd2FpdCB0aGlzLmF3YWl0KCk7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBgUmVzdWx0PFQsIEU+YCBpbnRvIGBSZXN1bHQ8dm9pZCwgRT5gCiAgICAgKiBAcmV0dXJucyBgT2s8dm9pZD5gIGlmIGBPazxUPmAsIGBFcnI8RT5gIGlmIGBFPEU+YAogICAgICovCiAgICBjbGVhcigpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiBPay52b2lkKCk7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBgUmVzdWx0PFQsIEU+YCBpbnRvIGBSZXN1bHQ8VCwgdm9pZD5gCiAgICAgKiBAcmV0dXJucyBgT2s8VD5gIGlmIGBPazxUPmAsIGBFcnI8dm9pZD5gIGlmIGBFPEU+YAogICAgICovCiAgICBjbGVhckVycigpIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogQ2FsbHMgdGhlIGdpdmVuIGNhbGxiYWNrIHdpdGggdGhlIGlubmVyIHZhbHVlIGlmIGBPa2AKICAgICAqIEBwYXJhbSBva0NhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgdGhpc2AKICAgICAqLwogICAgYXN5bmMgaW5zcGVjdChva0NhbGxiYWNrKSB7CiAgICAgICAgYXdhaXQgb2tDYWxsYmFjayh0aGlzLmlubmVyKTsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogQ2FsbHMgdGhlIGdpdmVuIGNhbGxiYWNrIHdpdGggdGhlIGlubmVyIHZhbHVlIGlmIGBPa2AKICAgICAqIEBwYXJhbSBva0NhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgdGhpc2AKICAgICAqLwogICAgaW5zcGVjdFN5bmMob2tDYWxsYmFjaykgewogICAgICAgIG9rQ2FsbGJhY2sodGhpcy5pbm5lcik7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIENhbGxzIHRoZSBnaXZlbiBjYWxsYmFjayB3aXRoIHRoZSBpbm5lciB2YWx1ZSBpZiBgRXJyYAogICAgICogQHBhcmFtIGVyckNhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgdGhpc2AKICAgICAqLwogICAgYXN5bmMgaW5zcGVjdEVycihlcnJDYWxsYmFjaykgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBDYWxscyB0aGUgZ2l2ZW4gY2FsbGJhY2sgd2l0aCB0aGUgaW5uZXIgdmFsdWUgaWYgYEVycmAKICAgICAqIEBwYXJhbSBlcnJDYWxsYmFjawogICAgICogQHJldHVybnMgYHRoaXNgCiAgICAgKi8KICAgIGluc3BlY3RFcnJTeW5jKGVyckNhbGxiYWNrKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybiBhIG5ldyBgT2tgIGJ1dCB3aXRoIHRoZSBnaXZlbiBgaW5uZXJgCiAgICAgKiBAcGFyYW0gaW5uZXIKICAgICAqIEByZXR1cm5zIGBPayhpbm5lcilgIGlmIGBPa2AsIGB0aGlzYCBpZiBgRXJyYAogICAgICovCiAgICBzZXQoaW5uZXIpIHsKICAgICAgICByZXR1cm4gbmV3IE9rKGlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJuIGEgbmV3IGBFcnJgIGJ1dCB3aXRoIHRoZSBnaXZlbiBgaW5uZXJgCiAgICAgKiBAcGFyYW0gaW5uZXIKICAgICAqIEByZXR1cm5zIGBFcnIoaW5uZXIpYCBpZiBgRXJyYCwgYHRoaXNgIGlmIGBPa2AKICAgICAqLwogICAgc2V0RXJyKGlubmVyKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIE1hcCB0aGUgaW5uZXIgdmFsdWUgaW50byBhbm90aGVyCiAgICAgKiBAcGFyYW0gb2tNYXBwZXIKICAgICAqIEByZXR1cm5zIGBPayhhd2FpdCBva01hcHBlcih0aGlzLmlubmVyKSlgIGlmIGBPa2AsIGB0aGlzYCBpZiBgRXJyYAogICAgICogQHRocm93cyBpZiBgYXdhaXQgb2tNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICBhc3luYyBtYXAob2tNYXBwZXIpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiBuZXcgT2soYXdhaXQgb2tNYXBwZXIodGhpcy5pbm5lcikpOwogICAgfQogICAgLyoqCiAgICAgKiBNYXAgdGhlIGlubmVyIHZhbHVlIGludG8gYW5vdGhlcgogICAgICogQHBhcmFtIG9rTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgT2sob2tNYXBwZXIodGhpcy5pbm5lcikpYCBpZiBgT2tgLCBgdGhpc2AgaWYgYEVycmAKICAgICAqIEB0aHJvd3MgaWYgYG9rTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgbWFwU3luYyhva01hcHBlcikgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIG5ldyBPayhva01hcHBlcih0aGlzLmlubmVyKSk7CiAgICB9CiAgICAvKioKICAgICAqIE1hcCB0aGUgaW5uZXIgZXJyb3IgaW50byBhbm90aGVyCiAgICAgKiBAcGFyYW0gZXJyTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgRXJyKGF3YWl0IGVyck1hcHBlcih0aGlzLmlubmVyKSlgIGlmIGBFcnJgLCBgdGhpc2AgaWYgYE9rYAogICAgICogQHRocm93cyBpZiBgYXdhaXQgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgYXN5bmMgbWFwRXJyKGVyck1hcHBlcikgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBNYXAgdGhlIGlubmVyIGVycm9yIGludG8gYW5vdGhlcgogICAgICogQHBhcmFtIGVyck1hcHBlcgogICAgICogQHJldHVybnMgYEVycihlcnJNYXBwZXIodGhpcy5pbm5lcikpYCBpZiBgRXJyYCwgYHRoaXNgIGlmIGBPa2AKICAgICAqIEB0aHJvd3MgaWYgYGVyck1hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIG1hcEVyclN5bmMoZXJyTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIE1hcCB0aGUgaW5uZXIgdmFsdWUgaW50byBhbm90aGVyLCBvciBhIGRlZmF1bHQgb25lCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEBwYXJhbSBva01hcHBlcgogICAgICogQHJldHVybnMgYGF3YWl0IG9rTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgT2tgLCBgdmFsdWVgIGlmIGBFcnJgCiAgICAgKiBAdGhyb3dzIGlmIGBhd2FpdCBva01hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIGFzeW5jIG1hcE9yKHZhbHVlLCBva01hcHBlcikgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIGF3YWl0IG9rTWFwcGVyKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBNYXAgdGhlIGlubmVyIHZhbHVlIGludG8gYW5vdGhlciwgb3IgYSBkZWZhdWx0IG9uZQogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcGFyYW0gb2tNYXBwZXIKICAgICAqIEByZXR1cm5zIGBva01hcHBlcih0aGlzLmlubmVyKWAgaWYgYE9rYCwgYHZhbHVlYCBpZiBgRXJyYAogICAgICogQHRocm93cyBpZiBgb2tNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICBtYXBPclN5bmModmFsdWUsIG9rTWFwcGVyKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gb2tNYXBwZXIodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIE1hcCB0aGUgaW5uZXIgdmFsdWUgaW50byBhbm90aGVyLCBvciBhIGRlZmF1bHQgb25lCiAgICAgKiBAcGFyYW0gZXJyTWFwcGVyCiAgICAgKiBAcGFyYW0gb2tNYXBwZXIKICAgICAqIEByZXR1cm5zIGBhd2FpdCBva01hcHBlcih0aGlzLmlubmVyKWAgaWYgYE9rYCwgYGF3YWl0IGVyck1hcHBlcih0aGlzLmlubmVyKWAgaWYgYEVycmAKICAgICAqIEB0aHJvd3MgaWYgYGF3YWl0IG9rTWFwcGVyKHRoaXMuaW5uZXIpYCBvciBgYXdhaXQgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgYXN5bmMgbWFwT3JFbHNlKGVyck1hcHBlciwgb2tNYXBwZXIpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiBhd2FpdCBva01hcHBlcih0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogTWFwIHRoZSBpbm5lciB2YWx1ZSBpbnRvIGFub3RoZXIsIG9yIGEgZGVmYXVsdCBvbmUKICAgICAqIEBwYXJhbSBlcnJNYXBwZXIKICAgICAqIEBwYXJhbSBva01hcHBlcgogICAgICogQHJldHVybnMgYG9rTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgT2tgLCBgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgRXJyYAogICAgICogQHRocm93cyBpZiBgb2tNYXBwZXIodGhpcy5pbm5lcilgIG9yIGBlcnJNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICBtYXBPckVsc2VTeW5jKGVyck1hcHBlciwgb2tNYXBwZXIpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiBva01hcHBlcih0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJuIGB2YWx1ZWAgaWYgYE9rYCwgcmV0dXJuIGB0aGlzYCBpZiBgRXJyYAogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcmV0dXJucyBgdmFsdWVgIGlmIGBPa2AsIGB0aGlzYCBpZiBgRXJyYAogICAgICovCiAgICBhbmQodmFsdWUpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiB2YWx1ZTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJuIGBhd2FpdCBva01hcHBlcih0aGlzLmlubmVyKWAgaWYgYE9rYCwgcmV0dXJuIGB0aGlzYCBpZiBgRXJyYAogICAgICogQHBhcmFtIG9rTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgYXdhaXQgb2tNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBPa2AsIGB0aGlzYCBpZiBgRXJyYAogICAgICogQHRocm93cyBpZiBgYXdhaXQgb2tNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICBhc3luYyBhbmRUaGVuKG9rTWFwcGVyKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gYXdhaXQgb2tNYXBwZXIodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybiBgb2tNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBPa2AsIHJldHVybiBgdGhpc2AgaWYgYEVycmAKICAgICAqIEBwYXJhbSBva01hcHBlcgogICAgICogQHJldHVybnMgYG9rTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgT2tgLCBgdGhpc2AgaWYgYEVycmAKICAgICAqIEB0aHJvd3MgaWYgYG9rTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgYW5kVGhlblN5bmMob2tNYXBwZXIpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiBva01hcHBlcih0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJuIGB2YWx1ZWAgaWYgYEVycmAsIHJldHVybiBgdGhpc2AgaWYgYE9rYAogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcmV0dXJucyBgdmFsdWVgIGlmIGBFcnJgLCBgdGhpc2AgaWYgYE9rYAogICAgICovCiAgICBvcih2YWx1ZSkgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm4gYGF3YWl0IGVyck1hcHBlcih0aGlzLmlubmVyKWAgaWYgYEVycmAsIHJldHVybiBgdGhpc2AgaWYgYE9rYAogICAgICogQHBhcmFtIGVyck1hcHBlcgogICAgICogQHJldHVybnMgYGF3YWl0IGVyck1hcHBlcih0aGlzLmlubmVyKWAgaWYgYEVycmAsIGB0aGlzYCBpZiBgT2tgCiAgICAgKiBAdGhyb3dzIGlmIGBhd2FpdCBlcnJNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICBhc3luYyBvckVsc2UoZXJyTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybiBgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgRXJyYCwgcmV0dXJuIGB0aGlzYCBpZiBgT2tgCiAgICAgKiBAcGFyYW0gZXJyTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgRXJyYCwgYHRoaXNgIGlmIGBPa2AKICAgICAqIEB0aHJvd3MgaWYgYGVyck1hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIG9yRWxzZVN5bmMoZXJyTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBSZXN1bHQ8UmVzdWx0PFQsIEUxPiwgRTI+IGludG8gUmVzdWx0PFQsIEUxIHwgRTI+CiAgICAgKiBAcGFyYW0gcmVzdWx0CiAgICAgKiBAcmV0dXJucyBgdGhpc2AgaWYgYEVycmAsIGB0aGlzLmlubmVyYCBpZiBgT2tgCiAgICAgKi8KICAgIGZsYXR0ZW4oKSB7CiAgICAgICAgcmV0dXJuIHRoaXMuaW5uZXI7CiAgICB9Cn0KCgovLyMgc291cmNlTWFwcGluZ1VSTD1vay5tanMubWFwCgo7Ly8gQ09OQ0FURU5BVEVEIE1PRFVMRTogLi9ub2RlX21vZHVsZXMvQGhhemFlNDEvb3B0aW9uL2Rpc3QvZXNtL21vZHMvb3B0aW9uL3NvbWUubWpzCgoKCmNsYXNzIFNvbWUgewogICAgaW5uZXI7CiAgICAvKioKICAgICAqIEFuIGV4aXN0aW5nIHZhbHVlCiAgICAgKiBAcGFyYW0gaW5uZXIKICAgICAqLwogICAgY29uc3RydWN0b3IoaW5uZXIpIHsKICAgICAgICB0aGlzLmlubmVyID0gaW5uZXI7CiAgICB9CiAgICAvKioKICAgICAqIENyZWF0ZSBhIGBTb21lYAogICAgICogQHBhcmFtIGlubmVyCiAgICAgKiBAcmV0dXJucyBgU29tZShpbm5lcilgCiAgICAgKi8KICAgIHN0YXRpYyBuZXcoaW5uZXIpIHsKICAgICAgICByZXR1cm4gbmV3IFNvbWUoaW5uZXIpOwogICAgfQogICAgc3RhdGljIGZyb20oaW5pdCkgewogICAgICAgIHJldHVybiBuZXcgU29tZShpbml0LmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogVHlwZSBndWFyZCBmb3IgYFNvbWVgCiAgICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYFNvbWVgLCBgZmFsc2VgIGlmIGBOb25lYAogICAgICovCiAgICBpc1NvbWUoKSB7CiAgICAgICAgcmV0dXJuIHRydWU7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYHRydWVgIGlmIHRoZSBvcHRpb24gaXMgYSBgU29tZWAgYW5kIHRoZSB2YWx1ZSBpbnNpZGUgb2YgaXQgbWF0Y2hlcyBhIHByZWRpY2F0ZQogICAgICogQHBhcmFtIHNvbWVQcmVkaWNhdGUKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgU29tZWAgYW5kIGBhd2FpdCBzb21lUHJlZGljYXRlKHRoaXMuaW5uZXIpYCwgYE5vbmVgIG90aGVyd2lzZQogICAgICovCiAgICBhc3luYyBpc1NvbWVBbmQoc29tZVByZWRpY2F0ZSkgewogICAgICAgIHJldHVybiBhd2FpdCBzb21lUHJlZGljYXRlKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGB0cnVlYCBpZiB0aGUgb3B0aW9uIGlzIGEgYFNvbWVgIGFuZCB0aGUgdmFsdWUgaW5zaWRlIG9mIGl0IG1hdGNoZXMgYSBwcmVkaWNhdGUKICAgICAqIEBwYXJhbSBzb21lUHJlZGljYXRlCiAgICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYFNvbWVgIGFuZCBgc29tZVByZWRpY2F0ZSh0aGlzLmlubmVyKWAsIGBOb25lYCBvdGhlcndpc2UKICAgICAqLwogICAgaXNTb21lQW5kU3luYyhzb21lUHJlZGljYXRlKSB7CiAgICAgICAgcmV0dXJuIHNvbWVQcmVkaWNhdGUodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFR5cGUgZ3VhcmQgZm9yIGBOb25lYAogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBOb25lYCwgYGZhbHNlYCBpZiBgU29tZWAKICAgICAqLwogICAgaXNOb25lKCkgewogICAgICAgIHJldHVybiBmYWxzZTsKICAgIH0KICAgIC8qKgogICAgICogQ29tcGlsZS10aW1lIHNhZmVseSBnZXQgYHRoaXMuaW5uZXJgCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAKICAgICAqLwogICAgZ2V0KCkgewogICAgICAgIHJldHVybiB0aGlzLmlubmVyOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGFuIGl0ZXJhdG9yIG92ZXIgdGhlIHBvc3NpYmx5IGNvbnRhaW5lZCB2YWx1ZQogICAgICogQHlpZWxkcyBgdGhpcy5pbm5lcmAgaWYgYFNvbWVgCiAgICAgKi8KICAgICpbU3ltYm9sLml0ZXJhdG9yXSgpIHsKICAgICAgICB5aWVsZCB0aGlzLmlubmVyOwogICAgfQogICAgLyoqCiAgICAgKiBHZXQgdGhlIGlubmVyIHZhbHVlIGlmIGBTb21lYCwgdGhyb3cgYEVycm9yKG1lc3NhZ2UpYCBvdGhlcndpc2UKICAgICAqIEBwYXJhbSBtZXNzYWdlCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAgaWYgYFNvbWVgCiAgICAgKiBAdGhyb3dzIGBFcnJvcihtZXNzYWdlKWAgaWYgYE5vbmVgCiAgICAgKi8KICAgIGV4cGVjdChtZXNzYWdlKSB7CiAgICAgICAgcmV0dXJuIHRoaXMuaW5uZXI7CiAgICB9CiAgICAvKioKICAgICAqIEdldCB0aGUgaW5uZXIgdmFsdWUgb3IgdGhyb3cgYSBOb25lRXJyb3IKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgU29tZWAKICAgICAqIEB0aHJvd3MgYE5vbmVFcnJvcmAgaWYgYE5vbmVgCiAgICAgKi8KICAgIHVud3JhcCgpIHsKICAgICAgICByZXR1cm4gdGhpcy5pbm5lcjsKICAgIH0KICAgIC8qKgogICAgICogR2V0IHRoZSBpbm5lciB2YWx1ZSBvciBhIGRlZmF1bHQgb25lCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgU29tZWAsIGB2YWx1ZWAgaWYgYE5vbmVgCiAgICAgKi8KICAgIHVud3JhcE9yKHZhbHVlKSB7CiAgICAgICAgcmV0dXJuIHRoaXMuaW5uZXI7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgdGhlIGNvbnRhaW5lZCBgU29tZWAgdmFsdWUgb3IgY29tcHV0ZXMgaXQgZnJvbSBhIGNsb3N1cmUKICAgICAqIEBwYXJhbSBub25lQ2FsbGJhY2sKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgU29tZWAsIGBhd2FpdCBub25lQ2FsbGJhY2soKWAgaWYgYE5vbmVgCiAgICAgKi8KICAgIGFzeW5jIHVud3JhcE9yRWxzZShub25lQ2FsbGJhY2spIHsKICAgICAgICByZXR1cm4gdGhpcy5pbm5lcjsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyB0aGUgY29udGFpbmVkIGBTb21lYCB2YWx1ZSBvciBjb21wdXRlcyBpdCBmcm9tIGEgY2xvc3VyZQogICAgICogQHBhcmFtIG5vbmVDYWxsYmFjawogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBTb21lYCwgYG5vbmVDYWxsYmFjaygpYCBpZiBgTm9uZWAKICAgICAqLwogICAgdW53cmFwT3JFbHNlU3luYyhub25lQ2FsbGJhY2spIHsKICAgICAgICByZXR1cm4gdGhpcy5pbm5lcjsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtIGBPcHRpb248VD5gIGludG8gYFJlc3VsdDxULCBOb25lRXJyb3I+YAogICAgICogQHJldHVybnMgYE9rKHRoaXMuaW5uZXIpYCBpZiBgU29tZWAsIGBFcnIoTm9uZUVycm9yKWAgaWYgYE5vbmVgCiAgICAgKi8KICAgIG9rKCkgewogICAgICAgIHJldHVybiBuZXcgT2sodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBgT3B0aW9uPFQ+YCBpbnRvIGBSZXN1bHQ8VCwgRT5gCiAgICAgKiBAcGFyYW0gZXJyb3IKICAgICAqIEByZXR1cm5zIGBPayh0aGlzLmlubmVyKWAgaWYgYFNvbWVgLCBgRXJyKGVycm9yKWAgaWYgYE5vbmVgCiAgICAgKi8KICAgIG9rT3IoZXJyb3IpIHsKICAgICAgICByZXR1cm4gbmV3IE9rKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm1zIHRoZSBgT3B0aW9uPFQ+YCBpbnRvIGEgYFJlc3VsdDxULCBFPmAsIG1hcHBpbmcgYFNvbWUodilgIHRvIGBPayh2KWAgYW5kIGBOb25lYCB0byBgRXJyKGVycigpKWAKICAgICAqIEBwYXJhbSBub25lQ2FsbGJhY2sKICAgICAqIEByZXR1cm5zIGBPayh0aGlzLmlubmVyKWAgaWYgYFNvbWVgLCBgRXJyKGF3YWl0IG5vbmVDYWxsYmFjaygpKWAgaXMgYE5vbmVgCiAgICAgKi8KICAgIGFzeW5jIG9rT3JFbHNlKG5vbmVDYWxsYmFjaykgewogICAgICAgIHJldHVybiBuZXcgT2sodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybXMgdGhlIGBPcHRpb248VD5gIGludG8gYSBgUmVzdWx0PFQsIEU+YCwgbWFwcGluZyBgU29tZSh2KWAgdG8gYE9rKHYpYCBhbmQgYE5vbmVgIHRvIGBFcnIoZXJyKCkpYAogICAgICogQHBhcmFtIG5vbmVDYWxsYmFjawogICAgICogQHJldHVybnMgYE9rKHRoaXMuaW5uZXIpYCBpZiBgU29tZWAsIGBFcnIobm9uZUNhbGxiYWNrKCkpYCBpcyBgTm9uZWAKICAgICAqLwogICAgb2tPckVsc2VTeW5jKG5vbmVDYWxsYmFjaykgewogICAgICAgIHJldHVybiBuZXcgT2sodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYE5vbmVgIGlmIHRoZSBvcHRpb24gaXMgYE5vbmVgLCBvdGhlcndpc2UgY2FsbHMgYHNvbWVQcmVkaWNhdGVgIHdpdGggdGhlIHdyYXBwZWQgdmFsdWUKICAgICAqIEBwYXJhbSBzb21lUHJlZGljYXRlCiAgICAgKiBAcmV0dXJucyBgU29tZWAgaWYgYFNvbWVgIGFuZCBgYXdhaXQgc29tZVByZWRpY2F0ZSh0aGlzLmlubmVyKWAsIGBOb25lYCBvdGhlcndpc2UKICAgICAqLwogICAgYXN5bmMgZmlsdGVyKHNvbWVQcmVkaWNhdGUpIHsKICAgICAgICBpZiAoYXdhaXQgc29tZVByZWRpY2F0ZSh0aGlzLmlubmVyKSkKICAgICAgICAgICAgcmV0dXJuIHRoaXM7CiAgICAgICAgZWxzZQogICAgICAgICAgICByZXR1cm4gbmV3IE5vbmUoKTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBgTm9uZWAgaWYgdGhlIG9wdGlvbiBpcyBgTm9uZWAsIG90aGVyd2lzZSBjYWxscyBgc29tZVByZWRpY2F0ZWAgd2l0aCB0aGUgd3JhcHBlZCB2YWx1ZQogICAgICogQHBhcmFtIHNvbWVQcmVkaWNhdGUKICAgICAqIEByZXR1cm5zIGBTb21lYCBpZiBgU29tZWAgYW5kIGBzb21lUHJlZGljYXRlKHRoaXMuaW5uZXIpYCwgYE5vbmVgIG90aGVyd2lzZQogICAgICovCiAgICBmaWx0ZXJTeW5jKHNvbWVQcmVkaWNhdGUpIHsKICAgICAgICBpZiAoc29tZVByZWRpY2F0ZSh0aGlzLmlubmVyKSkKICAgICAgICAgICAgcmV0dXJuIHRoaXM7CiAgICAgICAgZWxzZQogICAgICAgICAgICByZXR1cm4gbmV3IE5vbmUoKTsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtIGBPcHRpb248UHJvbWlzZTxUPj5gIGludG8gYFByb21pc2U8T3B0aW9uPFQ+PmAKICAgICAqIEByZXR1cm5zIGBQcm9taXNlPE9wdGlvbjxUPj5gCiAgICAgKi8KICAgIGFzeW5jIGF3YWl0KCkgewogICAgICAgIHJldHVybiBuZXcgU29tZShhd2FpdCB0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBgdHJ1ZWAgaWYgdGhlIG9wdGlvbiBpcyBhIGBTb21lYCB2YWx1ZSBjb250YWluaW5nIHRoZSBnaXZlbiB2YWx1ZQogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYFNvbWVgIGFuZCBgdGhpcy5pbm5lciA9PT0gdmFsdWVgLCBgTm9uZWAgb3RoZXJ3aXNlCiAgICAgKi8KICAgIGNvbnRhaW5zKHZhbHVlKSB7CiAgICAgICAgcmV0dXJuIHRoaXMuaW5uZXIgPT09IHZhbHVlOwogICAgfQogICAgLyoqCiAgICAgKiBDYWxscyB0aGUgZ2l2ZW4gY2FsbGJhY2sgd2l0aCB0aGUgaW5uZXIgdmFsdWUgaWYgYE9rYAogICAgICogQHBhcmFtIHNvbWVDYWxsYmFjawogICAgICogQHJldHVybnMgYHRoaXNgCiAgICAgKi8KICAgIGFzeW5jIGluc3BlY3Qoc29tZUNhbGxiYWNrKSB7CiAgICAgICAgYXdhaXQgc29tZUNhbGxiYWNrKHRoaXMuaW5uZXIpOwogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBDYWxscyB0aGUgZ2l2ZW4gY2FsbGJhY2sgd2l0aCB0aGUgaW5uZXIgdmFsdWUgaWYgYE9rYAogICAgICogQHBhcmFtIHNvbWVDYWxsYmFjawogICAgICogQHJldHVybnMgYHRoaXNgCiAgICAgKi8KICAgIGluc3BlY3RTeW5jKHNvbWVDYWxsYmFjaykgewogICAgICAgIHNvbWVDYWxsYmFjayh0aGlzLmlubmVyKTsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogTWFwcyBhbiBgT3B0aW9uPFQ+YCB0byBgT3B0aW9uPFU+YCBieSBhcHBseWluZyBhIGZ1bmN0aW9uIHRvIGEgY29udGFpbmVkIHZhbHVlIChpZiBgU29tZWApIG9yIHJldHVybnMgYE5vbmVgIChpZiBgTm9uZWApCiAgICAgKiBAcGFyYW0gc29tZU1hcHBlcgogICAgICogQHJldHVybnMgYFNvbWUoYXdhaXQgc29tZU1hcHBlcih0aGlzLmlubmVyKSlgIGlmIGBTb21lYCwgYHRoaXNgIGlmIGBOb25lYAogICAgICovCiAgICBhc3luYyBtYXAoc29tZU1hcHBlcikgewogICAgICAgIHJldHVybiBuZXcgU29tZShhd2FpdCBzb21lTWFwcGVyKHRoaXMuaW5uZXIpKTsKICAgIH0KICAgIC8qKgogICAgICogTWFwcyBhbiBgT3B0aW9uPFQ+YCB0byBgT3B0aW9uPFU+YCBieSBhcHBseWluZyBhIGZ1bmN0aW9uIHRvIGEgY29udGFpbmVkIHZhbHVlIChpZiBgU29tZWApIG9yIHJldHVybnMgYE5vbmVgIChpZiBgTm9uZWApCiAgICAgKiBAcGFyYW0gc29tZU1hcHBlcgogICAgICogQHJldHVybnMgYFNvbWUoc29tZU1hcHBlcih0aGlzLmlubmVyKSlgIGlmIGBTb21lYCwgYHRoaXNgIGlmIGBOb25lYAogICAgICovCiAgICBtYXBTeW5jKHNvbWVNYXBwZXIpIHsKICAgICAgICByZXR1cm4gbmV3IFNvbWUoc29tZU1hcHBlcih0aGlzLmlubmVyKSk7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgdGhlIHByb3ZpZGVkIGRlZmF1bHQgcmVzdWx0IChpZiBub25lKSwgb3IgYXBwbGllcyBhIGZ1bmN0aW9uIHRvIHRoZSBjb250YWluZWQgdmFsdWUgKGlmIGFueSkKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHBhcmFtIHNvbWVNYXBwZXIKICAgICAqIEByZXR1cm5zIGB2YWx1ZWAgaWYgYE5vbmVgLCBgYXdhaXQgc29tZU1hcHBlcih0aGlzLmlubmVyKWAgaWYgYFNvbWVgCiAgICAgKi8KICAgIGFzeW5jIG1hcE9yKHZhbHVlLCBzb21lTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIGF3YWl0IHNvbWVNYXBwZXIodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgdGhlIHByb3ZpZGVkIGRlZmF1bHQgcmVzdWx0IChpZiBub25lKSwgb3IgYXBwbGllcyBhIGZ1bmN0aW9uIHRvIHRoZSBjb250YWluZWQgdmFsdWUgKGlmIGFueSkKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHBhcmFtIHNvbWVNYXBwZXIKICAgICAqIEByZXR1cm5zIGB2YWx1ZWAgaWYgYE5vbmVgLCBgc29tZU1hcHBlcih0aGlzLmlubmVyKWAgaWYgYFNvbWVgCiAgICAgKi8KICAgIG1hcE9yU3luYyh2YWx1ZSwgc29tZU1hcHBlcikgewogICAgICAgIHJldHVybiBzb21lTWFwcGVyKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBDb21wdXRlcyBhIGRlZmF1bHQgZnVuY3Rpb24gcmVzdWx0IChpZiBub25lKSwgb3IgYXBwbGllcyBhIGRpZmZlcmVudCBmdW5jdGlvbiB0byB0aGUgY29udGFpbmVkIHZhbHVlIChpZiBhbnkpCiAgICAgKiBAcGFyYW0gbm9uZUNhbGxiYWNrCiAgICAgKiBAcGFyYW0gc29tZU1hcHBlcgogICAgICogQHJldHVybnMgYGF3YWl0IHNvbWVNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBTb21lYCwgYGF3YWl0IG5vbmVDYWxsYmFjaygpYCBpZiBgTm9uZWAKICAgICAqLwogICAgYXN5bmMgbWFwT3JFbHNlKG5vbmVDYWxsYmFjaywgc29tZU1hcHBlcikgewogICAgICAgIHJldHVybiBhd2FpdCBzb21lTWFwcGVyKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBDb21wdXRlcyBhIGRlZmF1bHQgZnVuY3Rpb24gcmVzdWx0IChpZiBub25lKSwgb3IgYXBwbGllcyBhIGRpZmZlcmVudCBmdW5jdGlvbiB0byB0aGUgY29udGFpbmVkIHZhbHVlIChpZiBhbnkpCiAgICAgKiBAcGFyYW0gbm9uZUNhbGxiYWNrCiAgICAgKiBAcGFyYW0gc29tZU1hcHBlcgogICAgICogQHJldHVybnMgYHNvbWVNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBTb21lYCwgYG5vbmVDYWxsYmFjaygpYCBpZiBgTm9uZWAKICAgICAqLwogICAgbWFwT3JFbHNlU3luYyhub25lQ2FsbGJhY2ssIHNvbWVNYXBwZXIpIHsKICAgICAgICByZXR1cm4gc29tZU1hcHBlcih0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBgTm9uZWAgaWYgdGhlIG9wdGlvbiBpcyBgTm9uZWAsIG90aGVyd2lzZSByZXR1cm5zIGB2YWx1ZWAKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHJldHVybnMgYE5vbmVgIGlmIGBOb25lYCwgYHZhbHVlYCBpZiBgU29tZWAKICAgICAqLwogICAgYW5kKHZhbHVlKSB7CiAgICAgICAgcmV0dXJuIHZhbHVlOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGBOb25lYCBpZiB0aGUgb3B0aW9uIGlzIGBOb25lYCwgb3RoZXJ3aXNlIGNhbGxzIGBzb21lTWFwcGVyYCB3aXRoIHRoZSB3cmFwcGVkIHZhbHVlIGFuZCByZXR1cm5zIHRoZSByZXN1bHQKICAgICAqIEBwYXJhbSBzb21lTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgTm9uZWAgaWYgYE5vbmVgLCBgYXdhaXQgc29tZU1hcHBlcih0aGlzLmlubmVyKWAgaWYgYFNvbWVgCiAgICAgKi8KICAgIGFzeW5jIGFuZFRoZW4oc29tZU1hcHBlcikgewogICAgICAgIHJldHVybiBhd2FpdCBzb21lTWFwcGVyKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGBOb25lYCBpZiB0aGUgb3B0aW9uIGlzIGBOb25lYCwgb3RoZXJ3aXNlIGNhbGxzIGBzb21lTWFwcGVyYCB3aXRoIHRoZSB3cmFwcGVkIHZhbHVlIGFuZCByZXR1cm5zIHRoZSByZXN1bHQKICAgICAqIEBwYXJhbSBzb21lTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgTm9uZWAgaWYgYE5vbmVgLCBgc29tZU1hcHBlcih0aGlzLmlubmVyKWAgaWYgYFNvbWVgCiAgICAgKi8KICAgIGFuZFRoZW5TeW5jKHNvbWVNYXBwZXIpIHsKICAgICAgICByZXR1cm4gc29tZU1hcHBlcih0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBgdGhpc2AgaWYgYFNvbWVgLCBvdGhlcndpc2UgcmV0dXJucyBgdmFsdWVgCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEByZXR1cm5zIGB0aGlzYCBpZiBgU29tZWAsIGB2YWx1ZWAgaWYgYE5vbmVgCiAgICAgKi8KICAgIG9yKHZhbHVlKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYHRoaXNgIGlmIGBTb21lYCwgb3RoZXJ3aXNlIGNhbGxzIGBub25lQ2FsbGJhY2tgIGFuZCByZXR1cm5zIHRoZSByZXN1bHQKICAgICAqIEBwYXJhbSBub25lQ2FsbGJhY2sKICAgICAqIEByZXR1cm5zIGB0aGlzYCBpZiBgU29tZWAsIGBhd2FpdCBub25lQ2FsbGJhY2soKWAgaWYgYE5vbmVgCiAgICAgKi8KICAgIGFzeW5jIG9yRWxzZShub25lQ2FsbGJhY2spIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBgdGhpc2AgaWYgYFNvbWVgLCBvdGhlcndpc2UgY2FsbHMgYG5vbmVDYWxsYmFja2AgYW5kIHJldHVybnMgdGhlIHJlc3VsdAogICAgICogQHBhcmFtIG5vbmVDYWxsYmFjawogICAgICogQHJldHVybnMgYHRoaXNgIGlmIGBTb21lYCwgYG5vbmVDYWxsYmFjaygpYCBpZiBgTm9uZWAKICAgICAqLwogICAgb3JFbHNlU3luYyhub25lQ2FsbGJhY2spIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBgU29tZWAgaWYgZXhhY3RseSBvbmUgb2YgdGhlIG9wdGlvbnMgaXMgYFNvbWVgLCBvdGhlcndpc2UgcmV0dXJucyBgTm9uZWAKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHJldHVybnMgYE5vbmVgIGlmIGJvdGggYXJlIGBTb21lYCBvciBib3RoIGFyZSBgTm9uZWAsIHRoZSBvbmx5IGBTb21lYCBvdGhlcndpc2UKICAgICAqLwogICAgeG9yKHZhbHVlKSB7CiAgICAgICAgaWYgKHZhbHVlLmlzU29tZSgpKQogICAgICAgICAgICByZXR1cm4gbmV3IE5vbmUoKTsKICAgICAgICBlbHNlCiAgICAgICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBaaXBzIGB0aGlzYCB3aXRoIGFub3RoZXIgYE9wdGlvbmAKICAgICAqIEBwYXJhbSBvdGhlcgogICAgICogQHJldHVybnMgYFNvbWUoW3RoaXMuaW5uZXIsIG90aGVyLmlubmVyXSlgIGlmIGJvdGggYXJlIGBTb21lYCwgYE5vbmVgIGlmIG9uZSBvZiB0aGVtIGlzIGBOb25lYAogICAgICovCiAgICB6aXAob3RoZXIpIHsKICAgICAgICBpZiAob3RoZXIuaXNTb21lKCkpCiAgICAgICAgICAgIHJldHVybiBuZXcgU29tZShbdGhpcy5pbm5lciwgb3RoZXIuaW5uZXJdKTsKICAgICAgICBlbHNlCiAgICAgICAgICAgIHJldHVybiBvdGhlcjsKICAgIH0KfQoKCi8vIyBzb3VyY2VNYXBwaW5nVVJMPXNvbWUubWpzLm1hcAoKOy8vIENPTkNBVEVOQVRFRCBNT0RVTEU6IC4vbm9kZV9tb2R1bGVzL0BoYXphZTQxL3Jlc3VsdC9kaXN0L2VzbS9tb2RzL3Jlc3VsdC9lcnIubWpzCgoKCgpjbGFzcyBFcnIgewogICAgI2lubmVyOwogICAgI3RpbWVvdXQ7CiAgICAvKioKICAgICAqIEEgZmFpbHVyZQogICAgICogQHBhcmFtIGlubmVyCiAgICAgKi8KICAgIGNvbnN0cnVjdG9yKGlubmVyKSB7CiAgICAgICAgdGhpcy4jaW5uZXIgPSBpbm5lcjsKICAgICAgICBpZiAoIVJlc3VsdC5kZWJ1ZykKICAgICAgICAgICAgcmV0dXJuOwogICAgICAgIGNvbnN0IGVycm9yID0gbmV3IEVycm9yKGBBbiBFcnIgaGFzIG5vdCBiZWVuIGhhbmRsZWQgcHJvcGVybHlgKTsKICAgICAgICB0aGlzLiN0aW1lb3V0ID0gc2V0VGltZW91dCgoKSA9PiB7IHRocm93IGVycm9yOyB9LCAxMDAwKTsKICAgIH0KICAgIC8qKgogICAgICogQ3JlYXRlIGFuIGVtcHR5IGBFcnJgCiAgICAgKiBAcmV0dXJucyBgRXJyKHZvaWQpYAogICAgICovCiAgICBzdGF0aWMgdm9pZCgpIHsKICAgICAgICByZXR1cm4gbmV3IEVycih1bmRlZmluZWQpOwogICAgfQogICAgLyoqCiAgICAgKiBDcmVhdGUgYW4gYEVycmAKICAgICAqIEBwYXJhbSBpbm5lcgogICAgICogQHJldHVybnMgYEVycihpbm5lcilgCiAgICAgKi8KICAgIHN0YXRpYyBuZXcoaW5uZXIpIHsKICAgICAgICByZXR1cm4gbmV3IEVycihpbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIENyZWF0ZSBhbiBgRXJyYCB3aXRoIGFuIGBFcnJvcmAgaW5zaWRlCiAgICAgKiBAcGFyYW0gbWVzc2FnZQogICAgICogQHBhcmFtIG9wdGlvbnMKICAgICAqIEByZXR1cm5zIGBFcnI8RXJyb3I+YAogICAgICovCiAgICBzdGF0aWMgZXJyb3IobWVzc2FnZSwgb3B0aW9ucykgewogICAgICAgIHJldHVybiBuZXcgRXJyKG5ldyBFcnJvcihtZXNzYWdlLCBvcHRpb25zKSk7CiAgICB9CiAgICBnZXQgaW5uZXIoKSB7CiAgICAgICAgcmV0dXJuIHRoaXMuI2lubmVyOwogICAgfQogICAgLyoqCiAgICAgKiBTZXQgdGhpcyByZXN1bHQgYXMgaGFuZGxlZAogICAgICovCiAgICBpZ25vcmUoKSB7CiAgICAgICAgaWYgKCF0aGlzLiN0aW1lb3V0KQogICAgICAgICAgICByZXR1cm4gdGhpczsKICAgICAgICBjbGVhclRpbWVvdXQodGhpcy4jdGltZW91dCk7CiAgICAgICAgdGhpcy4jdGltZW91dCA9IHVuZGVmaW5lZDsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogVHlwZSBndWFyZCBmb3IgYE9rYAogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBPa2AsIGBmYWxzZWAgaWYgYEVycmAKICAgICAqLwogICAgaXNPaygpIHsKICAgICAgICByZXR1cm4gZmFsc2U7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgdHJ1ZSBpZiB0aGUgcmVzdWx0IGlzIGBPa2AgYW5kIHRoZSB2YWx1ZSBpbnNpZGUgb2YgaXQgbWF0Y2hlcyBhIHByZWRpY2F0ZQogICAgICogQHBhcmFtIG9rUHJlZGljYXRlCiAgICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYE9rYCBhbmQgYGF3YWl0IG9rUHJlZGljYXRlKHRoaXMuaW5uZXIpYCwgYGZhbHNlYCBvdGhlcndpc2UKICAgICAqLwogICAgYXN5bmMgaXNPa0FuZChva1ByZWRpY2F0ZSkgewogICAgICAgIHJldHVybiBmYWxzZTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyB0cnVlIGlmIHRoZSByZXN1bHQgaXMgYE9rYCBhbmQgdGhlIHZhbHVlIGluc2lkZSBvZiBpdCBtYXRjaGVzIGEgcHJlZGljYXRlCiAgICAgKiBAcGFyYW0gb2tQcmVkaWNhdGUKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgT2tgIGFuZCBgYXdhaXQgb2tQcmVkaWNhdGUodGhpcy5pbm5lcilgLCBgZmFsc2VgIG90aGVyd2lzZQogICAgICovCiAgICBpc09rQW5kU3luYyhva1ByZWRpY2F0ZSkgewogICAgICAgIHJldHVybiBmYWxzZTsKICAgIH0KICAgIC8qKgogICAgICogVHlwZSBndWFyZCBmb3IgYEVycmAKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgRXJyYCwgYGZhbHNlYCBpZiBgT2tgCiAgICAgKi8KICAgIGlzRXJyKCkgewogICAgICAgIHJldHVybiB0cnVlOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIHRydWUgaWYgdGhlIHJlc3VsdCBpcyBgRXJyYCBhbmQgdGhlIHZhbHVlIGluc2lkZSBvZiBpdCBtYXRjaGVzIGEgcHJlZGljYXRlCiAgICAgKiBAcGFyYW0gZXJyUHJlZGljYXRlCiAgICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYEVycmAgYW5kIGBhd2FpdCBlcnJQcmVkaWNhdGUodGhpcy5pbm5lcilgLCBgZmFsc2VgIG90aGVyd2lzZQogICAgICovCiAgICBhc3luYyBpc0VyckFuZChlcnJQcmVkaWNhdGUpIHsKICAgICAgICByZXR1cm4gYXdhaXQgZXJyUHJlZGljYXRlKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIHRydWUgaWYgdGhlIHJlc3VsdCBpcyBgRXJyYCBhbmQgdGhlIHZhbHVlIGluc2lkZSBvZiBpdCBtYXRjaGVzIGEgcHJlZGljYXRlCiAgICAgKiBAcGFyYW0gZXJyUHJlZGljYXRlCiAgICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYEVycmAgYW5kIGBhd2FpdCBlcnJQcmVkaWNhdGUodGhpcy5pbm5lcilgLCBgZmFsc2VgIG90aGVyd2lzZQogICAgICovCiAgICBpc0VyckFuZFN5bmMoZXJyUHJlZGljYXRlKSB7CiAgICAgICAgcmV0dXJuIGVyclByZWRpY2F0ZSh0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogQ29tcGlsZS10aW1lIHNhZmVseSBnZXQgT2sncyBpbm5lciB0eXBlCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAKICAgICAqIEB0aHJvd3MgaWYgYHRoaXNgIGlzIGBFcnJgCiAgICAgKi8KICAgIGdldCgpIHsKICAgICAgICB0aHJvdyBuZXcgUGFuaWMoKTsKICAgIH0KICAgIC8qKgogICAgICogQ29tcGlsZS10aW1lIHNhZmVseSBnZXQgRXJyJ3MgaW5uZXIgdHlwZQogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgCiAgICAgKiBAdGhyb3dzIGlmIGB0aGlzYCBpcyBgT2tgCiAgICAgKi8KICAgIGdldEVycigpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiB0aGlzLmlubmVyOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm0gYFJlc3VsdDxULCBFPmAgaW50byBgT3B0aW9uPFQ+YAogICAgICogQHJldHVybnMgYFNvbWUodGhpcy5pbm5lcilgIGlmIGBPa2AsIGBOb25lYCBpZiBgRXJyYAogICAgICovCiAgICBvaygpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiBuZXcgTm9uZSgpOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm0gYFJlc3VsdDxULCBFPmAgaW50byBgT3B0aW9uPEU+YAogICAgICogQHJldHVybnMgYFNvbWUodGhpcy5pbm5lcilgIGlmIGBFcnJgLCBgTm9uZWAgaWYgYE9rYAogICAgICovCiAgICBlcnIoKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gbmV3IFNvbWUodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYW4gaXRlcmF0b3Igb3ZlciB0aGUgcG9zc2libHkgY29udGFpbmVkIHZhbHVlCiAgICAgKiBAeWllbGRzIGB0aGlzLmlubmVyYCBpZiBgT2tgCiAgICAgKi8KICAgICpbU3ltYm9sLml0ZXJhdG9yXSgpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybjsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtIGBSZXN1bHQ8VCxFPmAgaW50byBgW1QsRV1gCiAgICAgKiBAcmV0dXJucyBgW3RoaXMuaW5uZXIsIHVuZGVmaW5lZF1gIGlmIGBPa2AsIGBbdW5kZWZpbmVkLCB0aGlzLmlubmVyXWAgaWYgYEVycmAKICAgICAqLwogICAgc3BsaXQoKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gW3VuZGVmaW5lZCwgdGhpcy5pbm5lcl07CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgdHJ1ZSBpZiB0aGUgcmVzdWx0IGlzIGFuIGBPa2AgdmFsdWUgY29udGFpbmluZyB0aGUgZ2l2ZW4gdmFsdWUKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBPa2AgYW5kIGB0aGlzLmlubmVyID09PSB2YWx1ZWAsIGBmYWxzZWAgb3RoZXJ3aXNlCiAgICAgKi8KICAgIGNvbnRhaW5zKHZhbHVlKSB7CiAgICAgICAgcmV0dXJuIGZhbHNlOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIHRydWUgaWYgdGhlIHJlc3VsdCBpcyBhbiBgRXJyYCB2YWx1ZSBjb250YWluaW5nIHRoZSBnaXZlbiB2YWx1ZQogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYEVycmAgYW5kIGB0aGlzLmlubmVyID09PSB2YWx1ZWAsIGBmYWxzZWAgb3RoZXJ3aXNlCiAgICAgKi8KICAgIGNvbnRhaW5zRXJyKHZhbHVlKSB7CiAgICAgICAgcmV0dXJuIHRoaXMuaW5uZXIgPT09IHZhbHVlOwogICAgfQogICAgLyoqCiAgICAgKiBHZXQgdGhlIGlubmVyIHZhbHVlIG9yIHRocm93IHRvIHRoZSBjbG9zZXN0IGBSZXN1bHQudW50aHJvd2AKICAgICAqIEBwYXJhbSB0aHJvd2VyIFRoZSB0aHJvd2VyIGZyb20gYFJlc3VsdC51bnRocm93YAogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBPa2AKICAgICAqIEB0aHJvd3MgYHVuZGVmaW5lZGAgaWYgYEVycmAKICAgICAqIEBzZWUgUmVzdWx0LnVudGhyb3cKICAgICAqIEBzZWUgUmVzdWx0LnVudGhyb3dTeW5jCiAgICAgKi8KICAgIHRocm93KHRocm93ZXIpIHsKICAgICAgICB0aHJvd2VyKHRoaXMpOwogICAgICAgIHRocm93IHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIEdldCB0aGUgaW5uZXIgdmFsdWUgb3IgdGhyb3cgdGhlIGlubmVyIGVycm9yIHdyYXBwZWQgaW5zaWRlIGFub3RoZXIgRXJyb3IKICAgICAqIEBwYXJhbSBtZXNzYWdlCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAgaWYgYE9rYCwgYEVycm9yKG1lc3NhZ2UsIHsgY2F1c2U6IHRoaXMuaW5uZXIgfSlgIGlmIGBFcnJgCiAgICAgKi8KICAgIGV4cGVjdChtZXNzYWdlKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICB0aHJvdyBuZXcgRXJyb3IobWVzc2FnZSwgeyBjYXVzZTogdGhpcy5pbm5lciB9KTsKICAgIH0KICAgIC8qKgogICAgICogR2V0IHRoZSBpbm5lciBlcnJvciBvciB0aHJvdyB0aGUgaW5uZXIgdmFsdWUgd3JhcHBlZCBpbnNpZGUgYW5vdGhlciBFcnJvcgogICAgICogQHBhcmFtIG1lc3NhZ2UKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgRXJyYCwgYEVycm9yKG1lc3NhZ2UsIHsgY2F1c2U6IHRoaXMuaW5uZXIgfSlgIGlmIGBPa2AKICAgICAqLwogICAgZXhwZWN0RXJyKG1lc3NhZ2UpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiB0aGlzLmlubmVyOwogICAgfQogICAgLyoqCiAgICAgKiBHZXQgdGhlIGlubmVyIHZhbHVlIG9yIHBhbmljCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAgaWYgYE9rYAogICAgICogQHRocm93cyBgdGhpcy5pbm5lcmAgaWYgYEVycmAKICAgICAqLwogICAgdW53cmFwKCkgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgdGhyb3cgdGhpcy5pbm5lcjsKICAgIH0KICAgIC8qKgogICAgICogR2V0IHRoZSBpbm5lciBlcnJvciBvciBwYW5pYwogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBFcnJgCiAgICAgKiBAdGhyb3dzIGB0aGlzLmlubmVyYCBpZiBgT2tgCiAgICAgKi8KICAgIHVud3JhcEVycigpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiB0aGlzLmlubmVyOwogICAgfQogICAgLyoqCiAgICAgKiBHZXQgdGhlIGlubmVyIHZhbHVlIG9yIGEgZGVmYXVsdCBvbmUKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBPa2AsIGB2YWx1ZWAgaWYgYEVycmAKICAgICAqLwogICAgdW53cmFwT3IodmFsdWUpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiB2YWx1ZTsKICAgIH0KICAgIC8qKgogICAgICogR2V0IHRoZSBpbm5lciB2YWx1ZSBvciBjb21wdXRlIGEgZGVmYXVsdCBvbmUgZnJvbSB0aGUgaW5uZXIgZXJyb3IKICAgICAqIEBwYXJhbSBlcnJNYXBwZXIKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgT2tgLCBgYXdhaXQgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgRXJyYAogICAgICogQHRocm93cyBpZiBgYXdhaXQgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgYXN5bmMgdW53cmFwT3JFbHNlKGVyck1hcHBlcikgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIGF3YWl0IGVyck1hcHBlcih0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogR2V0IHRoZSBpbm5lciB2YWx1ZSBvciBjb21wdXRlIGEgZGVmYXVsdCBvbmUgZnJvbSB0aGUgaW5uZXIgZXJyb3IKICAgICAqIEBwYXJhbSBlcnJNYXBwZXIKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgT2tgLCBgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgRXJyYAogICAgICogQHRocm93cyBpZiBgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgdW53cmFwT3JFbHNlU3luYyhlcnJNYXBwZXIpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiBlcnJNYXBwZXIodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBSZXN1bHQ8UHJvbWlzZTxUPiwgRT4gaW50byBQcm9taXNlPFJlc3VsdDxULCBFPj4KICAgICAqIEByZXR1cm5zIGBhd2FpdCB0aGlzLmlubmVyYCBpZiBgT2tgLCBgdGhpc2AgaWYgYEVycmAKICAgICAqLwogICAgYXN5bmMgYXdhaXQoKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBSZXN1bHQ8VCwgUHJvbWlzZTxFPj4gaW50byBQcm9taXNlPFJlc3VsdDxULCBFPj4KICAgICAqIEByZXR1cm5zIGBhd2FpdCB0aGlzLmlubmVyYCBpZiBgRXJyYCwgYHRoaXNgIGlmIGBPa2AKICAgICAqLwogICAgYXN5bmMgYXdhaXRFcnIoKSB7CiAgICAgICAgcmV0dXJuIG5ldyBFcnIoYXdhaXQgdGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBSZXN1bHQ8UHJvbWlzZTxUPiwgUHJvbWlzZTxFPj4gaW50byBQcm9taXNlPFJlc3VsdDxULCBFPj4KICAgICAqIEByZXR1cm5zIGBhd2FpdCB0aGlzLmlubmVyYAogICAgICovCiAgICBhc3luYyBhd2FpdEFsbCgpIHsKICAgICAgICByZXR1cm4gYXdhaXQgdGhpcy5hd2FpdEVycigpOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm0gYFJlc3VsdDxULCBFPmAgaW50byBgUmVzdWx0PHZvaWQsIEU+YAogICAgICogQHJldHVybnMgYE9rPHZvaWQ+YCBpZiBgT2s8VD5gLCBgRXJyPEU+YCBpZiBgRTxFPmAKICAgICAqLwogICAgY2xlYXIoKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBgUmVzdWx0PFQsIEU+YCBpbnRvIGBSZXN1bHQ8VCwgdm9pZD5gCiAgICAgKiBAcmV0dXJucyBgT2s8VD5gIGlmIGBPazxUPmAsIGBFcnI8dm9pZD5gIGlmIGBFPEU+YAogICAgICovCiAgICBjbGVhckVycigpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiBFcnIudm9pZCgpOwogICAgfQogICAgLyoqCiAgICAgKiBDYWxscyB0aGUgZ2l2ZW4gY2FsbGJhY2sgd2l0aCB0aGUgaW5uZXIgdmFsdWUgaWYgYE9rYAogICAgICogQHBhcmFtIG9rQ2FsbGJhY2sKICAgICAqIEByZXR1cm5zIGB0aGlzYAogICAgICovCiAgICBhc3luYyBpbnNwZWN0KG9rQ2FsbGJhY2spIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogQ2FsbHMgdGhlIGdpdmVuIGNhbGxiYWNrIHdpdGggdGhlIGlubmVyIHZhbHVlIGlmIGBPa2AKICAgICAqIEBwYXJhbSBva0NhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgdGhpc2AKICAgICAqLwogICAgaW5zcGVjdFN5bmMob2tDYWxsYmFjaykgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBDYWxscyB0aGUgZ2l2ZW4gY2FsbGJhY2sgd2l0aCB0aGUgaW5uZXIgdmFsdWUgaWYgYEVycmAKICAgICAqIEBwYXJhbSBlcnJDYWxsYmFjawogICAgICogQHJldHVybnMgYHRoaXNgCiAgICAgKi8KICAgIGFzeW5jIGluc3BlY3RFcnIoZXJyQ2FsbGJhY2spIHsKICAgICAgICBhd2FpdCBlcnJDYWxsYmFjayh0aGlzLmlubmVyKTsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogQ2FsbHMgdGhlIGdpdmVuIGNhbGxiYWNrIHdpdGggdGhlIGlubmVyIHZhbHVlIGlmIGBFcnJgCiAgICAgKiBAcGFyYW0gZXJyQ2FsbGJhY2sKICAgICAqIEByZXR1cm5zIGB0aGlzYAogICAgICovCiAgICBpbnNwZWN0RXJyU3luYyhlcnJDYWxsYmFjaykgewogICAgICAgIGVyckNhbGxiYWNrKHRoaXMuaW5uZXIpOwogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm4gYSBuZXcgYE9rYCBidXQgd2l0aCB0aGUgZ2l2ZW4gYGlubmVyYAogICAgICogQHBhcmFtIGlubmVyCiAgICAgKiBAcmV0dXJucyBgT2soaW5uZXIpYCBpZiBgT2tgLCBgdGhpc2AgaWYgYEVycmAKICAgICAqLwogICAgc2V0KGlubmVyKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybiBhIG5ldyBgRXJyYCBidXQgd2l0aCB0aGUgZ2l2ZW4gYGlubmVyYAogICAgICogQHBhcmFtIGlubmVyCiAgICAgKiBAcmV0dXJucyBgRXJyKGlubmVyKWAgaWYgYEVycmAsIGB0aGlzYCBpZiBgT2tgCiAgICAgKi8KICAgIHNldEVycihpbm5lcikgewogICAgICAgIHJldHVybiBuZXcgRXJyKGlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogTWFwIHRoZSBpbm5lciB2YWx1ZSBpbnRvIGFub3RoZXIKICAgICAqIEBwYXJhbSBva01hcHBlcgogICAgICogQHJldHVybnMgYE9rKGF3YWl0IG9rTWFwcGVyKHRoaXMuaW5uZXIpKWAgaWYgYE9rYCwgYHRoaXNgIGlmIGBFcnJgCiAgICAgKiBAdGhyb3dzIGlmIGBhd2FpdCBva01hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIGFzeW5jIG1hcChva01hcHBlcikgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBNYXAgdGhlIGlubmVyIHZhbHVlIGludG8gYW5vdGhlcgogICAgICogQHBhcmFtIG9rTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgT2sob2tNYXBwZXIodGhpcy5pbm5lcikpYCBpZiBgT2tgLCBgdGhpc2AgaWYgYEVycmAKICAgICAqIEB0aHJvd3MgaWYgYG9rTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgbWFwU3luYyhva01hcHBlcikgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBNYXAgdGhlIGlubmVyIGVycm9yIGludG8gYW5vdGhlcgogICAgICogQHBhcmFtIGVyck1hcHBlcgogICAgICogQHJldHVybnMgYEVycihhd2FpdCBlcnJNYXBwZXIodGhpcy5pbm5lcikpYCBpZiBgRXJyYCwgYHRoaXNgIGlmIGBPa2AKICAgICAqIEB0aHJvd3MgaWYgYGF3YWl0IGVyck1hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIGFzeW5jIG1hcEVycihlcnJNYXBwZXIpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiBuZXcgRXJyKGF3YWl0IGVyck1hcHBlcih0aGlzLmlubmVyKSk7CiAgICB9CiAgICAvKioKICAgICAqIE1hcCB0aGUgaW5uZXIgZXJyb3IgaW50byBhbm90aGVyCiAgICAgKiBAcGFyYW0gZXJyTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgRXJyKGVyck1hcHBlcih0aGlzLmlubmVyKSlgIGlmIGBFcnJgLCBgdGhpc2AgaWYgYE9rYAogICAgICogQHRocm93cyBpZiBgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgbWFwRXJyU3luYyhlcnJNYXBwZXIpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiBuZXcgRXJyKGVyck1hcHBlcih0aGlzLmlubmVyKSk7CiAgICB9CiAgICAvKioKICAgICAqIE1hcCB0aGUgaW5uZXIgdmFsdWUgaW50byBhbm90aGVyLCBvciBhIGRlZmF1bHQgb25lCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEBwYXJhbSBva01hcHBlcgogICAgICogQHJldHVybnMgYGF3YWl0IG9rTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgT2tgLCBgdmFsdWVgIGlmIGBFcnJgCiAgICAgKiBAdGhyb3dzIGlmIGBhd2FpdCBva01hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIGFzeW5jIG1hcE9yKHZhbHVlLCBva01hcHBlcikgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIHZhbHVlOwogICAgfQogICAgLyoqCiAgICAgKiBNYXAgdGhlIGlubmVyIHZhbHVlIGludG8gYW5vdGhlciwgb3IgYSBkZWZhdWx0IG9uZQogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcGFyYW0gb2tNYXBwZXIKICAgICAqIEByZXR1cm5zIGBva01hcHBlcih0aGlzLmlubmVyKWAgaWYgYE9rYCwgYHZhbHVlYCBpZiBgRXJyYAogICAgICogQHRocm93cyBpZiBgb2tNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICBtYXBPclN5bmModmFsdWUsIG9rTWFwcGVyKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gdmFsdWU7CiAgICB9CiAgICAvKioKICAgICAqIE1hcCB0aGUgaW5uZXIgdmFsdWUgaW50byBhbm90aGVyLCBvciBhIGRlZmF1bHQgb25lCiAgICAgKiBAcGFyYW0gZXJyTWFwcGVyCiAgICAgKiBAcGFyYW0gb2tNYXBwZXIKICAgICAqIEByZXR1cm5zIGBhd2FpdCBva01hcHBlcih0aGlzLmlubmVyKWAgaWYgYE9rYCwgYGF3YWl0IGVyck1hcHBlcih0aGlzLmlubmVyKWAgaWYgYEVycmAKICAgICAqIEB0aHJvd3MgaWYgYGF3YWl0IG9rTWFwcGVyKHRoaXMuaW5uZXIpYCBvciBgYXdhaXQgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgYXN5bmMgbWFwT3JFbHNlKGVyck1hcHBlciwgb2tNYXBwZXIpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiBhd2FpdCBlcnJNYXBwZXIodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIE1hcCB0aGUgaW5uZXIgdmFsdWUgaW50byBhbm90aGVyLCBvciBhIGRlZmF1bHQgb25lCiAgICAgKiBAcGFyYW0gZXJyTWFwcGVyCiAgICAgKiBAcGFyYW0gb2tNYXBwZXIKICAgICAqIEByZXR1cm5zIGBva01hcHBlcih0aGlzLmlubmVyKWAgaWYgYE9rYCwgYGVyck1hcHBlcih0aGlzLmlubmVyKWAgaWYgYEVycmAKICAgICAqIEB0aHJvd3MgaWYgYG9rTWFwcGVyKHRoaXMuaW5uZXIpYCBvciBgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgbWFwT3JFbHNlU3luYyhlcnJNYXBwZXIsIG9rTWFwcGVyKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gZXJyTWFwcGVyKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm4gYHZhbHVlYCBpZiBgT2tgLCByZXR1cm4gYHRoaXNgIGlmIGBFcnJgCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEByZXR1cm5zIGB2YWx1ZWAgaWYgYE9rYCwgYHRoaXNgIGlmIGBFcnJgCiAgICAgKi8KICAgIGFuZCh2YWx1ZSkgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm4gYGF3YWl0IG9rTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgT2tgLCByZXR1cm4gYHRoaXNgIGlmIGBFcnJgCiAgICAgKiBAcGFyYW0gb2tNYXBwZXIKICAgICAqIEByZXR1cm5zIGBhd2FpdCBva01hcHBlcih0aGlzLmlubmVyKWAgaWYgYE9rYCwgYHRoaXNgIGlmIGBFcnJgCiAgICAgKiBAdGhyb3dzIGlmIGBhd2FpdCBva01hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIGFzeW5jIGFuZFRoZW4ob2tNYXBwZXIpIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJuIGBva01hcHBlcih0aGlzLmlubmVyKWAgaWYgYE9rYCwgcmV0dXJuIGB0aGlzYCBpZiBgRXJyYAogICAgICogQHBhcmFtIG9rTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgb2tNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBPa2AsIGB0aGlzYCBpZiBgRXJyYAogICAgICogQHRocm93cyBpZiBgb2tNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICBhbmRUaGVuU3luYyhva01hcHBlcikgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm4gYHZhbHVlYCBpZiBgRXJyYCwgcmV0dXJuIGB0aGlzYCBpZiBgT2tgCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEByZXR1cm5zIGB2YWx1ZWAgaWYgYEVycmAsIGB0aGlzYCBpZiBgT2tgCiAgICAgKi8KICAgIG9yKHZhbHVlKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gdmFsdWU7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybiBgYXdhaXQgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgRXJyYCwgcmV0dXJuIGB0aGlzYCBpZiBgT2tgCiAgICAgKiBAcGFyYW0gZXJyTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgYXdhaXQgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgRXJyYCwgYHRoaXNgIGlmIGBPa2AKICAgICAqIEB0aHJvd3MgaWYgYGF3YWl0IGVyck1hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIGFzeW5jIG9yRWxzZShlcnJNYXBwZXIpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiBhd2FpdCBlcnJNYXBwZXIodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybiBgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgRXJyYCwgcmV0dXJuIGB0aGlzYCBpZiBgT2tgCiAgICAgKiBAcGFyYW0gZXJyTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgRXJyYCwgYHRoaXNgIGlmIGBPa2AKICAgICAqIEB0aHJvd3MgaWYgYGVyck1hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIG9yRWxzZVN5bmMoZXJyTWFwcGVyKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gZXJyTWFwcGVyKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm0gUmVzdWx0PFJlc3VsdDxULCBFMT4sIEUyPiBpbnRvIFJlc3VsdDxULCBFMSB8IEUyPgogICAgICogQHBhcmFtIHJlc3VsdAogICAgICogQHJldHVybnMgYHRoaXNgIGlmIGBFcnJgLCBgdGhpcy5pbm5lcmAgaWYgYE9rYAogICAgICovCiAgICBmbGF0dGVuKCkgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQp9CgoKLy8jIHNvdXJjZU1hcHBpbmdVUkw9ZXJyLm1qcy5tYXAKCjsvLyBDT05DQVRFTkFURUQgTU9EVUxFOiAuL25vZGVfbW9kdWxlcy9AaGF6YWU0MS9qc29ucnBjL2Rpc3QvZXNtL21vZHMvcnBjL2Vyci5tanMKCgpjbGFzcyBScGNFcnJvciBleHRlbmRzIEVycm9yIHsKICAgIGNvZGU7CiAgICBtZXNzYWdlOwogICAgZGF0YTsKICAgICNjbGFzcyA9IFJwY0Vycm9yOwogICAgbmFtZSA9IHRoaXMuI2NsYXNzLm5hbWU7CiAgICBzdGF0aWMgY29kZXMgPSB7CiAgICAgICAgUGFyc2VFcnJvcjogLTMyNzAwLAogICAgICAgIEludmFsaWRSZXF1ZXN0OiAtMzI2MDAsCiAgICAgICAgTWV0aG9kTm90Rm91bmQ6IC0zMjYwMSwKICAgICAgICBJbnZhbGlkUGFyYW1zOiAtMzI2MDIsCiAgICAgICAgSW50ZXJuYWxFcnJvcjogLTMyNjAzCiAgICB9OwogICAgc3RhdGljIG1lc3NhZ2VzID0gewogICAgICAgIFBhcnNlRXJyb3I6ICJQYXJzZSBlcnJvciIsCiAgICAgICAgSW52YWxpZFJlcXVlc3Q6ICJJbnZhbGlkIFJlcXVlc3QiLAogICAgICAgIE1ldGhvZE5vdEZvdW5kOiAiTWV0aG9kIG5vdCBmb3VuZCIsCiAgICAgICAgSW52YWxpZFBhcmFtczogIkludmFsaWQgcGFyYW1zIiwKICAgICAgICBJbnRlcm5hbEVycm9yOiAiSW50ZXJuYWwgZXJyb3IiLAogICAgICAgIFNlcnZlckVycm9yOiAiU2VydmVyIGVycm9yIgogICAgfTsKICAgIGNvbnN0cnVjdG9yKGNvZGUsIG1lc3NhZ2UsIGRhdGEgPSB1bmRlZmluZWQpIHsKICAgICAgICBzdXBlcihtZXNzYWdlKTsKICAgICAgICB0aGlzLmNvZGUgPSBjb2RlOwogICAgICAgIHRoaXMubWVzc2FnZSA9IG1lc3NhZ2U7CiAgICAgICAgdGhpcy5kYXRhID0gZGF0YTsKICAgIH0KICAgIHN0YXRpYyBmcm9tKGluaXQpIHsKICAgICAgICBjb25zdCB7IGNvZGUsIG1lc3NhZ2UsIGRhdGEgfSA9IGluaXQ7CiAgICAgICAgcmV0dXJuIG5ldyBScGNFcnJvcihjb2RlLCBtZXNzYWdlLCBkYXRhKTsKICAgIH0KICAgIHN0YXRpYyByZXdyYXAoZXJyb3IpIHsKICAgICAgICBpZiAoZXJyb3IgaW5zdGFuY2VvZiBScGNFcnJvcikKICAgICAgICAgICAgcmV0dXJuIGVycm9yOwogICAgICAgIGlmIChlcnJvciBpbnN0YW5jZW9mIEVycm9yKQogICAgICAgICAgICByZXR1cm4gbmV3IFJwY0Vycm9yKC0zMjYwMywgZXJyb3IubWVzc2FnZSk7CiAgICAgICAgcmV0dXJuIG5ldyBScGNFcnJvcigtMzI2MDMsICJBbiB1bmtub3duIGVycm9yIG9jY3VyZWQiKTsKICAgIH0KICAgIC8qKgogICAgICogVXNlZCBieSBKU09OLnN0cmluZ2lmeQogICAgICovCiAgICB0b0pTT04oKSB7CiAgICAgICAgY29uc3QgeyBjb2RlLCBtZXNzYWdlLCBkYXRhIH0gPSB0aGlzOwogICAgICAgIHJldHVybiB7IGNvZGUsIG1lc3NhZ2UsIGRhdGEgfTsKICAgIH0KfQpjbGFzcyBScGNQYXJzZUVycm9yIGV4dGVuZHMgUnBjRXJyb3IgewogICAgI2NsYXNzID0gUnBjUGFyc2VFcnJvcjsKICAgIG5hbWUgPSB0aGlzLiNjbGFzcy5uYW1lOwogICAgc3RhdGljIGNvZGUgPSBScGNFcnJvci5jb2Rlcy5QYXJzZUVycm9yOwogICAgc3RhdGljIG1lc3NhZ2UgPSBScGNFcnJvci5tZXNzYWdlcy5QYXJzZUVycm9yOwogICAgY29uc3RydWN0b3IoKSB7CiAgICAgICAgc3VwZXIoUnBjRXJyb3IuY29kZXMuUGFyc2VFcnJvciwgUnBjRXJyb3IubWVzc2FnZXMuUGFyc2VFcnJvcik7CiAgICB9Cn0KY2xhc3MgUnBjSW52YWxpZFJlcXVlc3RFcnJvciBleHRlbmRzIFJwY0Vycm9yIHsKICAgICNjbGFzcyA9IFJwY0ludmFsaWRSZXF1ZXN0RXJyb3I7CiAgICBuYW1lID0gdGhpcy4jY2xhc3MubmFtZTsKICAgIHN0YXRpYyBjb2RlID0gUnBjRXJyb3IuY29kZXMuSW52YWxpZFJlcXVlc3Q7CiAgICBzdGF0aWMgbWVzc2FnZSA9IFJwY0Vycm9yLm1lc3NhZ2VzLkludmFsaWRSZXF1ZXN0OwogICAgY29uc3RydWN0b3IoKSB7CiAgICAgICAgc3VwZXIoUnBjRXJyb3IuY29kZXMuSW52YWxpZFJlcXVlc3QsIFJwY0Vycm9yLm1lc3NhZ2VzLkludmFsaWRSZXF1ZXN0KTsKICAgIH0KfQpjbGFzcyBScGNNZXRob2ROb3RGb3VuZEVycm9yIGV4dGVuZHMgUnBjRXJyb3IgewogICAgI2NsYXNzID0gUnBjTWV0aG9kTm90Rm91bmRFcnJvcjsKICAgIG5hbWUgPSB0aGlzLiNjbGFzcy5uYW1lOwogICAgc3RhdGljIGNvZGUgPSBScGNFcnJvci5jb2Rlcy5NZXRob2ROb3RGb3VuZDsKICAgIHN0YXRpYyBtZXNzYWdlID0gUnBjRXJyb3IubWVzc2FnZXMuTWV0aG9kTm90Rm91bmQ7CiAgICBjb25zdHJ1Y3RvcigpIHsKICAgICAgICBzdXBlcihScGNFcnJvci5jb2Rlcy5NZXRob2ROb3RGb3VuZCwgUnBjRXJyb3IubWVzc2FnZXMuTWV0aG9kTm90Rm91bmQpOwogICAgfQp9CmNsYXNzIFJwY0ludmFsaWRQYXJhbXNFcnJvciBleHRlbmRzIFJwY0Vycm9yIHsKICAgICNjbGFzcyA9IFJwY0ludmFsaWRQYXJhbXNFcnJvcjsKICAgIG5hbWUgPSB0aGlzLiNjbGFzcy5uYW1lOwogICAgc3RhdGljIGNvZGUgPSBScGNFcnJvci5jb2Rlcy5JbnZhbGlkUGFyYW1zOwogICAgc3RhdGljIG1lc3NhZ2UgPSBScGNFcnJvci5tZXNzYWdlcy5JbnZhbGlkUGFyYW1zOwogICAgY29uc3RydWN0b3IoKSB7CiAgICAgICAgc3VwZXIoUnBjRXJyb3IuY29kZXMuSW52YWxpZFBhcmFtcywgUnBjRXJyb3IubWVzc2FnZXMuSW52YWxpZFBhcmFtcyk7CiAgICB9Cn0KY2xhc3MgUnBjSW50ZXJuYWxFcnJvciBleHRlbmRzIFJwY0Vycm9yIHsKICAgICNjbGFzcyA9IFJwY0ludGVybmFsRXJyb3I7CiAgICBuYW1lID0gdGhpcy4jY2xhc3MubmFtZTsKICAgIHN0YXRpYyBjb2RlID0gUnBjRXJyb3IuY29kZXMuSW50ZXJuYWxFcnJvcjsKICAgIHN0YXRpYyBtZXNzYWdlID0gUnBjRXJyb3IubWVzc2FnZXMuSW50ZXJuYWxFcnJvcjsKICAgIGNvbnN0cnVjdG9yKCkgewogICAgICAgIHN1cGVyKFJwY0Vycm9yLmNvZGVzLkludGVybmFsRXJyb3IsIFJwY0Vycm9yLm1lc3NhZ2VzLkludGVybmFsRXJyb3IpOwogICAgfQp9CmNsYXNzIFJwY0VyciBleHRlbmRzIEVyciB7CiAgICBpZDsKICAgIGVycm9yOwogICAganNvbnJwYyA9ICIyLjAiOwogICAgY29uc3RydWN0b3IoaWQsIGVycm9yKSB7CiAgICAgICAgc3VwZXIoZXJyb3IpOwogICAgICAgIHRoaXMuaWQgPSBpZDsKICAgICAgICB0aGlzLmVycm9yID0gZXJyb3I7CiAgICB9CiAgICBzdGF0aWMgZnJvbShpbml0KSB7CiAgICAgICAgcmV0dXJuIG5ldyBScGNFcnIoaW5pdC5pZCwgUnBjRXJyb3IuZnJvbShpbml0LmVycm9yKSk7CiAgICB9CiAgICBzdGF0aWMgcmV3cmFwKGlkLCByZXN1bHQpIHsKICAgICAgICByZXR1cm4gbmV3IFJwY0VycihpZCwgUnBjRXJyb3IucmV3cmFwKHJlc3VsdC5pbm5lcikpOwogICAgfQp9CgoKLy8jIHNvdXJjZU1hcHBpbmdVUkw9ZXJyLm1qcy5tYXAKCjsvLyBDT05DQVRFTkFURUQgTU9EVUxFOiAuL25vZGVfbW9kdWxlcy9AaGF6YWU0MS9qc29ucnBjL2Rpc3QvZXNtL21vZHMvcnBjL29rLm1qcwoKCnZhciBScGNPa0luaXQ7CihmdW5jdGlvbiAoUnBjT2tJbml0KSB7CiAgICBmdW5jdGlvbiBmcm9tKHJlc3BvbnNlKSB7CiAgICAgICAgY29uc3QgeyBqc29ucnBjLCBpZCwgcmVzdWx0IH0gPSByZXNwb25zZTsKICAgICAgICByZXR1cm4geyBqc29ucnBjLCBpZCwgcmVzdWx0IH07CiAgICB9CiAgICBScGNPa0luaXQuZnJvbSA9IGZyb207Cn0pKFJwY09rSW5pdCB8fCAoUnBjT2tJbml0ID0ge30pKTsKY2xhc3MgUnBjT2sgZXh0ZW5kcyBPayB7CiAgICBpZDsKICAgIHJlc3VsdDsKICAgIGpzb25ycGMgPSAiMi4wIjsKICAgIGNvbnN0cnVjdG9yKGlkLCByZXN1bHQpIHsKICAgICAgICBzdXBlcihyZXN1bHQpOwogICAgICAgIHRoaXMuaWQgPSBpZDsKICAgICAgICB0aGlzLnJlc3VsdCA9IHJlc3VsdDsKICAgIH0KICAgIHN0YXRpYyBmcm9tKGluaXQpIHsKICAgICAgICByZXR1cm4gbmV3IFJwY09rKGluaXQuaWQsIGluaXQucmVzdWx0KTsKICAgIH0KICAgIHN0YXRpYyByZXdyYXAoaWQsIHJlc3VsdCkgewogICAgICAgIHJldHVybiBuZXcgUnBjT2soaWQsIHJlc3VsdC5pbm5lcik7CiAgICB9Cn0KCgovLyMgc291cmNlTWFwcGluZ1VSTD1vay5tanMubWFwCgo7Ly8gQ09OQ0FURU5BVEVEIE1PRFVMRTogLi9ub2RlX21vZHVsZXMvQGhhemFlNDEvanNvbnJwYy9kaXN0L2VzbS9tb2RzL3JwYy9yZXNwb25zZS5tanMKCgoKdmFyIFJwY1Jlc3BvbnNlOwooZnVuY3Rpb24gKFJwY1Jlc3BvbnNlKSB7CiAgICBmdW5jdGlvbiBmcm9tKGluaXQpIHsKICAgICAgICBpZiAoImVycm9yIiBpbiBpbml0KQogICAgICAgICAgICByZXR1cm4gUnBjRXJyLmZyb20oaW5pdCk7CiAgICAgICAgcmV0dXJuIFJwY09rLmZyb20oaW5pdCk7CiAgICB9CiAgICBScGNSZXNwb25zZS5mcm9tID0gZnJvbTsKICAgIGZ1bmN0aW9uIHJld3JhcChpZCwgcmVzdWx0KSB7CiAgICAgICAgaWYgKHJlc3VsdC5pc0VycigpKQogICAgICAgICAgICByZXR1cm4gUnBjRXJyLnJld3JhcChpZCwgcmVzdWx0KTsKICAgICAgICByZXR1cm4gUnBjT2sucmV3cmFwKGlkLCByZXN1bHQpOwogICAgfQogICAgUnBjUmVzcG9uc2UucmV3cmFwID0gcmV3cmFwOwp9KShScGNSZXNwb25zZSB8fCAoUnBjUmVzcG9uc2UgPSB7fSkpOwoKCi8vIyBzb3VyY2VNYXBwaW5nVVJMPXJlc3BvbnNlLm1qcy5tYXAKCjsvLyBDT05DQVRFTkFURUQgTU9EVUxFOiAuL25vZGVfbW9kdWxlcy9AaGF6YWU0MS9qc29ucnBjL2Rpc3QvZXNtL21vZHMvcnBjL3JlcXVlc3QubWpzCmNsYXNzIFJwY1JlcXVlc3QgewogICAgaWQ7CiAgICBtZXRob2Q7CiAgICBwYXJhbXM7CiAgICBqc29ucnBjID0gIjIuMCI7CiAgICBjb25zdHJ1Y3RvcihpZCwgbWV0aG9kLCBwYXJhbXMpIHsKICAgICAgICB0aGlzLmlkID0gaWQ7CiAgICAgICAgdGhpcy5tZXRob2QgPSBtZXRob2Q7CiAgICAgICAgdGhpcy5wYXJhbXMgPSBwYXJhbXM7CiAgICB9CiAgICBzdGF0aWMgZnJvbShpbml0KSB7CiAgICAgICAgY29uc3QgeyBpZCwgbWV0aG9kLCBwYXJhbXMgfSA9IGluaXQ7CiAgICAgICAgcmV0dXJuIG5ldyBScGNSZXF1ZXN0KGlkLCBtZXRob2QsIHBhcmFtcyk7CiAgICB9CiAgICB0b0pTT04oKSB7CiAgICAgICAgY29uc3QgeyBqc29ucnBjLCBpZCwgbWV0aG9kLCBwYXJhbXMgfSA9IHRoaXM7CiAgICAgICAgcmV0dXJuIHsganNvbnJwYywgaWQsIG1ldGhvZCwgcGFyYW1zIH07CiAgICB9Cn0KCgovLyMgc291cmNlTWFwcGluZ1VSTD1yZXF1ZXN0Lm1qcy5tYXAKCjsvLyBDT05DQVRFTkFURUQgTU9EVUxFOiAuL25vZGVfbW9kdWxlcy9AaGF6YWU0MS9qc29ucnBjL2Rpc3QvZXNtL21vZHMvcnBjL3JwYy5tanMKCgpjbGFzcyBScGNDb3VudGVyIHsKICAgIGlkID0gMDsKICAgIHByZXBhcmUoaW5pdCkgewogICAgICAgIHJldHVybiBuZXcgUnBjUmVxdWVzdCh0aGlzLmlkKyssIGluaXQubWV0aG9kLCBpbml0LnBhcmFtcyk7CiAgICB9Cn0KCgovLyMgc291cmNlTWFwcGluZ1VSTD1ycGMubWpzLm1hcAoKOy8vIENPTkNBVEVOQVRFRCBNT0RVTEU6IC4vc3JjL21vZHMvYmFja2dyb3VuZC9pbmplY3RlZF9zY3JpcHQvaW5kZXgudHMKCgoKCmNsYXNzIFByb3ZpZGVyIHsKICAgIGdldCBpc0JydW1lKCkgewogICAgICAgIHJldHVybiB0cnVlOwogICAgfQogICAgZ2V0IGlzTWV0YU1hc2soKSB7CiAgICAgICAgcmV0dXJuIHRydWU7CiAgICB9CiAgICAvKioKICAgICAqIEBkZXByZWNhdGVkCiAgICAgKi8gaXNDb25uZWN0ZWQoKSB7CiAgICAgICAgcmV0dXJuIHRydWU7CiAgICB9CiAgICAvKioKICAgICAqIEBkZXByZWNhdGVkCiAgICAgKi8gaXNVbmxvY2tlZCgpIHsKICAgICAgICByZXR1cm4gdHJ1ZTsKICAgIH0KICAgIC8qKgogICAgICogQGRlcHJlY2F0ZWQKICAgICAqLyBnZXQgY2hhaW5JZCgpIHsKICAgICAgICByZXR1cm4gdGhpcy5fY2hhaW5JZDsKICAgIH0KICAgIC8qKgogICAgICogQGRlcHJlY2F0ZWQKICAgICAqLyBnZXQgbmV0d29ya1ZlcnNpb24oKSB7CiAgICAgICAgcmV0dXJuIHRoaXMuX25ldHdvcmtWZXJzaW9uOwogICAgfQogICAgLyoqCiAgICAgKiBAZGVwcmVjYXRlZAogICAgICovIGdldCBzZWxlY3RlZEFkZHJlc3MoKSB7CiAgICAgICAgcmV0dXJuIHRoaXMuX2FjY291bnRzWzBdOwogICAgfQogICAgLyoqCiAgICAgKiBAZGVwcmVjYXRlZAogICAgICovIGdldCBfbWV0YW1hc2soKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIEBkZXByZWNhdGVkCiAgICAgKi8gZXZlbnROYW1lcygpIHsKICAgICAgICByZXR1cm4gWwogICAgICAgICAgICAiY29ubmVjdCIsCiAgICAgICAgICAgICJkaXNjb25uZWN0IiwKICAgICAgICAgICAgImNoYWluQ2hhbmdlZCIsCiAgICAgICAgICAgICJhY2NvdW50c0NoYW5nZWQiLAogICAgICAgICAgICAibmV0d29ya0NoYW5nZWQiCiAgICAgICAgXTsKICAgIH0KICAgIC8qKgogICAgICogQGRlcHJlY2F0ZWQKICAgICAqLyBnZXRNYXhMaXN0ZW5lcnMoKSB7CiAgICAgICAgcmV0dXJuIE51bWJlci5NQVhfU0FGRV9JTlRFR0VSOwogICAgfQogICAgLyoqCiAgICAgKiBAZGVwcmVjYXRlZAogICAgICovIHNldE1heExpc3RlbmVycyh4KSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIEBkZXByZWNhdGVkCiAgICAgKi8gbGlzdGVuZXJDb3VudCgpIHsKICAgICAgICByZXR1cm4gdGhpcy5fbGlzdGVuZXJDb3VudDsKICAgIH0KICAgIC8qKgogICAgICogQGRlcHJlY2F0ZWQKICAgICAqLyBsaXN0ZW5lcnMoa2V5KSB7CiAgICAgICAgY29uc3QgbGlzdGVuZXJzID0gdGhpcy5fbGlzdGVuZXJzQnlFdmVudC5nZXQoa2V5KTsKICAgICAgICBpZiAobGlzdGVuZXJzID09IG51bGwpIHJldHVybiBbXTsKICAgICAgICByZXR1cm4gWwogICAgICAgICAgICAuLi5saXN0ZW5lcnMKICAgICAgICBdOwogICAgfQogICAgLyoqCiAgICAgKiBAZGVwcmVjYXRlZAogICAgICovIHJhd0xpc3RlbmVycyhrZXkpIHsKICAgICAgICByZXR1cm4gdGhpcy5saXN0ZW5lcnMoa2V5KTsKICAgIH0KICAgIC8qKgogICAgICogQGRlcHJlY2F0ZWQKICAgICAqLyBhc3luYyBlbmFibGUoKSB7CiAgICAgICAgLyoqCiAgICAgICAgICogRW5hYmxlIGNvbXBhdGliaWxpdHkgbW9kZSBmb3IgdGhhdCBvbGQgYXBwIHRoYXQgbmVlZHMgdG8gcmVsb2FkIG9uIG5ldHdvcmsgY2hhbmdlCiAgICAgICAgICovIHRoaXMuYXV0b1JlZnJlc2hPbk5ldHdvcmtDaGFuZ2UgPSB0cnVlOwogICAgICAgIHJldHVybiBhd2FpdCB0aGlzLnJlcXVlc3QoewogICAgICAgICAgICBpZDogbnVsbCwKICAgICAgICAgICAgbWV0aG9kOiAiZXRoX3JlcXVlc3RBY2NvdW50cyIKICAgICAgICB9KTsKICAgIH0KICAgIGFzeW5jIHRyeVJlcXVlc3QocmVxaW5pdCkgewogICAgICAgIGNvbnN0IHJlcXVlc3QgPSB0aGlzLl9jb3VudGVyLnByZXBhcmUocmVxaW5pdCk7CiAgICAgICAgY29uc3QgZnV0dXJlID0gbmV3IEZ1dHVyZSgpOwogICAgICAgIGNvbnN0IG9uUmVzcG9uc2UgPSAoZSk9PnsKICAgICAgICAgICAgY29uc3QgcmVzaW5pdCA9IEpTT04ucGFyc2UoZS5kZXRhaWwpOwogICAgICAgICAgICBpZiAocmVzaW5pdC5pZCAhPT0gcmVxdWVzdC5pZCkgcmV0dXJuOwogICAgICAgICAgICBjb25zdCByZXNwb25zZSA9IFJwY1Jlc3BvbnNlLmZyb20ocmVzaW5pdCk7CiAgICAgICAgICAgIGNvbnN0IHJld3JhcHBlZCA9IFJwY1Jlc3BvbnNlLnJld3JhcChyZXFpbml0LmlkLCByZXNwb25zZSk7CiAgICAgICAgICAgIGZ1dHVyZS5yZXNvbHZlKHJld3JhcHBlZCk7CiAgICAgICAgfTsKICAgICAgICB0cnkgewogICAgICAgICAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcigiZXRoZXJldW06cmVzcG9uc2UiLCBvblJlc3BvbnNlKTsKICAgICAgICAgICAgY29uc3QgZGV0YWlsID0gSlNPTi5zdHJpbmdpZnkocmVxdWVzdCk7CiAgICAgICAgICAgIGNvbnN0IGV2ZW50ID0gbmV3IEN1c3RvbUV2ZW50KCJldGhlcmV1bTpyZXF1ZXN0IiwgewogICAgICAgICAgICAgICAgZGV0YWlsCiAgICAgICAgICAgIH0pOwogICAgICAgICAgICB3aW5kb3cuZGlzcGF0Y2hFdmVudChldmVudCk7CiAgICAgICAgICAgIHJldHVybiBhd2FpdCBmdXR1cmUucHJvbWlzZTsKICAgICAgICB9IGZpbmFsbHl7CiAgICAgICAgICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKCJldGhlcmV1bTpyZXNwb25zZSIsIG9uUmVzcG9uc2UpOwogICAgICAgIH0KICAgIH0KICAgIGFzeW5jIHJlcXVlc3QoaW5pdCkgewogICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHRoaXMudHJ5UmVxdWVzdChpbml0KTsKICAgICAgICBpZiAocmVzdWx0LmlzRXJyKCkpIHRocm93IHJlc3VsdC5pbm5lcjsKICAgICAgICByZXR1cm4gcmVzdWx0LmlubmVyOwogICAgfQogICAgYXN5bmMgcmVxdWVzdEJhdGNoKGluaXRzKSB7CiAgICAgICAgcmV0dXJuIGF3YWl0IFByb21pc2UuYWxsKGluaXRzLm1hcCgoaW5pdCk9PnRoaXMudHJ5UmVxdWVzdChpbml0KSkpOwogICAgfQogICAgYXN5bmMgX3NlbmQoaW5pdCwgY2FsbGJhY2spIHsKICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IHRoaXMudHJ5UmVxdWVzdChpbml0KTsKICAgICAgICBpZiAocmVzcG9uc2UuaXNFcnIoKSkgY2FsbGJhY2socmVzcG9uc2UuaW5uZXIsIHJlc3BvbnNlKTsKICAgICAgICBlbHNlIGNhbGxiYWNrKG51bGwsIHJlc3BvbnNlKTsKICAgIH0KICAgIC8qKgogICAgICogQGRlcHJlY2F0ZWQKICAgICAqLyBzZW5kKGluaXQsIGNhbGxiYWNrKSB7CiAgICAgICAgaWYgKHR5cGVvZiBpbml0ID09PSAic3RyaW5nIikgaW5pdCA9IHsKICAgICAgICAgICAgaWQ6IG51bGwsCiAgICAgICAgICAgIG1ldGhvZDogaW5pdAogICAgICAgIH07CiAgICAgICAgaWYgKGNhbGxiYWNrICE9IG51bGwpIHJldHVybiB0aGlzLl9zZW5kKGluaXQsIGNhbGxiYWNrKTsKICAgICAgICBpZiAoaW5pdC5tZXRob2QgPT09ICJldGhfYWNjb3VudHMiKSByZXR1cm4gUnBjT2sucmV3cmFwKGluaXQuaWQsIG5ldyBPayh0aGlzLl9hY2NvdW50cykpOwogICAgICAgIGlmIChpbml0Lm1ldGhvZCA9PT0gImV0aF9jb2luYmFzZSIpIHJldHVybiBScGNPay5yZXdyYXAoaW5pdC5pZCwgbmV3IE9rKHRoaXMuX2FjY291bnRzWzBdKSk7CiAgICAgICAgaWYgKGluaXQubWV0aG9kID09PSAibmV0X3ZlcnNpb24iKSByZXR1cm4gUnBjT2sucmV3cmFwKGluaXQuaWQsIG5ldyBPayh0aGlzLl9uZXR3b3JrVmVyc2lvbikpOwogICAgICAgIGlmIChpbml0Lm1ldGhvZCA9PT0gImV0aF91bmluc3RhbGxGaWx0ZXIiKSB0aHJvdyBuZXcgRXJyb3IoIlVuaW1wbGVtZW50ZWQgbWV0aG9kICIuY29uY2F0KGluaXQubWV0aG9kKSk7CiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCJBc3luY2hyb25vdXMgbWV0aG9kICIuY29uY2F0KGluaXQubWV0aG9kLCAiIHJlcXVpcmVzIGEgY2FsbGJhY2siKSk7CiAgICB9CiAgICAvKioKICAgICAqIEBkZXByZWNhdGVkCiAgICAgKi8gc2VuZEFzeW5jKGluaXQsIGNhbGxiYWNrKSB7CiAgICAgICAgaWYgKHR5cGVvZiBpbml0ID09PSAic3RyaW5nIikgaW5pdCA9IHsKICAgICAgICAgICAgaWQ6IG51bGwsCiAgICAgICAgICAgIG1ldGhvZDogaW5pdAogICAgICAgIH07CiAgICAgICAgdGhpcy5fc2VuZChpbml0LCBjYWxsYmFjayk7CiAgICB9CiAgICBfcmVlbWl0KGtleSkgewogICAgICAgIHRoaXMuX2xpc3RlbmVyc0J5RXZlbnQuc2V0KGtleSwgbmV3IFNldCgpKTsKICAgICAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcigiZXRoZXJldW06Ii5jb25jYXQoa2V5KSwgKGUpPT57CiAgICAgICAgICAgIHRoaXMuZW1pdChrZXksIEpTT04ucGFyc2UoZS5kZXRhaWwpKTsKICAgICAgICB9LCB7CiAgICAgICAgICAgIHBhc3NpdmU6IHRydWUKICAgICAgICB9KTsKICAgIH0KICAgIGVtaXQoa2V5KSB7CiAgICAgICAgZm9yKHZhciBfbGVuID0gYXJndW1lbnRzLmxlbmd0aCwgcGFyYW1zID0gbmV3IEFycmF5KF9sZW4gPiAxID8gX2xlbiAtIDEgOiAwKSwgX2tleSA9IDE7IF9rZXkgPCBfbGVuOyBfa2V5KyspewogICAgICAgICAgICBwYXJhbXNbX2tleSAtIDFdID0gYXJndW1lbnRzW19rZXldOwogICAgICAgIH0KICAgICAgICBjb25zdCBsaXN0ZW5lcnMgPSB0aGlzLl9saXN0ZW5lcnNCeUV2ZW50LmdldChrZXkpOwogICAgICAgIGlmIChsaXN0ZW5lcnMgPT0gbnVsbCkgcmV0dXJuOwogICAgICAgIGZvciAoY29uc3QgbGlzdGVuZXIgb2YgbGlzdGVuZXJzKWxpc3RlbmVyKC4uLnBhcmFtcyk7CiAgICAgICAgcmV0dXJuOwogICAgfQogICAgb24oa2V5LCBsaXN0ZW5lcikgewogICAgICAgIHRoaXMuYWRkTGlzdGVuZXIoa2V5LCBsaXN0ZW5lcik7CiAgICB9CiAgICBvZmYoa2V5LCBsaXN0ZW5lcikgewogICAgICAgIHRoaXMucmVtb3ZlTGlzdGVuZXIoa2V5LCBsaXN0ZW5lcik7CiAgICB9CiAgICBvbmNlKGtleSwgbGlzdGVuZXIpIHsKICAgICAgICB2YXIgX3RoaXMgPSB0aGlzOwogICAgICAgIGNvbnN0IGxpc3RlbmVyMiA9IGZ1bmN0aW9uKCkgewogICAgICAgICAgICBmb3IodmFyIF9sZW4gPSBhcmd1bWVudHMubGVuZ3RoLCBwYXJhbXMgPSBuZXcgQXJyYXkoX2xlbiksIF9rZXkgPSAwOyBfa2V5IDwgX2xlbjsgX2tleSsrKXsKICAgICAgICAgICAgICAgIHBhcmFtc1tfa2V5XSA9IGFyZ3VtZW50c1tfa2V5XTsKICAgICAgICAgICAgfQogICAgICAgICAgICBsaXN0ZW5lciguLi5wYXJhbXMpOwogICAgICAgICAgICBfdGhpcy5vZmYoa2V5LCBsaXN0ZW5lcjIpOwogICAgICAgIH07CiAgICAgICAgdGhpcy5vbihrZXksIGxpc3RlbmVyMik7CiAgICB9CiAgICBhZGRMaXN0ZW5lcihrZXksIGxpc3RlbmVyKSB7CiAgICAgICAgY29uc3QgbGlzdGVuZXJzID0gdGhpcy5fbGlzdGVuZXJzQnlFdmVudC5nZXQoa2V5KTsKICAgICAgICBpZiAobGlzdGVuZXJzID09IG51bGwpIHJldHVybjsKICAgICAgICB0aGlzLl9saXN0ZW5lckNvdW50IC09IGxpc3RlbmVycy5zaXplOwogICAgICAgIGxpc3RlbmVycy5hZGQobGlzdGVuZXIpOwogICAgICAgIHRoaXMuX2xpc3RlbmVyQ291bnQgKz0gbGlzdGVuZXJzLnNpemU7CiAgICB9CiAgICByZW1vdmVMaXN0ZW5lcihrZXksIGxpc3RlbmVyKSB7CiAgICAgICAgY29uc3QgbGlzdGVuZXJzID0gdGhpcy5fbGlzdGVuZXJzQnlFdmVudC5nZXQoa2V5KTsKICAgICAgICBpZiAobGlzdGVuZXJzID09IG51bGwpIHJldHVybjsKICAgICAgICBpZiAoIWxpc3RlbmVycy5kZWxldGUobGlzdGVuZXIpKSByZXR1cm47CiAgICAgICAgdGhpcy5fbGlzdGVuZXJDb3VudC0tOwogICAgfQogICAgcmVtb3ZlQWxsTGlzdGVuZXJzKGtleSkgewogICAgICAgIGNvbnN0IGxpc3RlbmVycyA9IHRoaXMuX2xpc3RlbmVyc0J5RXZlbnQuZ2V0KGtleSk7CiAgICAgICAgaWYgKGxpc3RlbmVycyA9PSBudWxsKSByZXR1cm47CiAgICAgICAgdGhpcy5fbGlzdGVuZXJDb3VudCAtPSBsaXN0ZW5lcnMuc2l6ZTsKICAgICAgICBsaXN0ZW5lcnMuY2xlYXIoKTsKICAgIH0KICAgIHByZXBlbmRMaXN0ZW5lcihrZXksIGxpc3RlbmVyKSB7CiAgICAgICAgY29uc3QgbGlzdGVuZXJzID0gdGhpcy5fbGlzdGVuZXJzQnlFdmVudC5nZXQoa2V5KTsKICAgICAgICBpZiAobGlzdGVuZXJzID09IG51bGwpIHJldHVybjsKICAgICAgICB0aGlzLl9saXN0ZW5lckNvdW50IC09IGxpc3RlbmVycy5zaXplOwogICAgICAgIGNvbnN0IG9yaWdpbmFsID0gWwogICAgICAgICAgICAuLi5saXN0ZW5lcnMKICAgICAgICBdOwogICAgICAgIGxpc3RlbmVycy5jbGVhcigpOwogICAgICAgIGxpc3RlbmVycy5hZGQobGlzdGVuZXIpOwogICAgICAgIGZvciAoY29uc3QgbGlzdGVuZXIgb2Ygb3JpZ2luYWwpbGlzdGVuZXJzLmFkZChsaXN0ZW5lcik7CiAgICAgICAgdGhpcy5fbGlzdGVuZXJDb3VudCArPSBsaXN0ZW5lcnMuc2l6ZTsKICAgIH0KICAgIHByZXBlbmRPbmNlTGlzdGVuZXIoa2V5LCBsaXN0ZW5lcikgewogICAgICAgIHZhciBfdGhpcyA9IHRoaXM7CiAgICAgICAgY29uc3QgbGlzdGVuZXIyID0gZnVuY3Rpb24oKSB7CiAgICAgICAgICAgIGZvcih2YXIgX2xlbiA9IGFyZ3VtZW50cy5sZW5ndGgsIHBhcmFtcyA9IG5ldyBBcnJheShfbGVuKSwgX2tleSA9IDA7IF9rZXkgPCBfbGVuOyBfa2V5KyspewogICAgICAgICAgICAgICAgcGFyYW1zW19rZXldID0gYXJndW1lbnRzW19rZXldOwogICAgICAgICAgICB9CiAgICAgICAgICAgIGxpc3RlbmVyKC4uLnBhcmFtcyk7CiAgICAgICAgICAgIF90aGlzLm9mZihrZXksIGxpc3RlbmVyMik7CiAgICAgICAgfTsKICAgICAgICB0aGlzLnByZXBlbmRMaXN0ZW5lcihrZXksIGxpc3RlbmVyMik7CiAgICB9CiAgICBjb25zdHJ1Y3RvcigpewogICAgICAgIHRoaXMuX2NvdW50ZXIgPSBuZXcgUnBjQ291bnRlcigpOwogICAgICAgIHRoaXMuX2xpc3RlbmVyc0J5RXZlbnQgPSBuZXcgTWFwKCk7CiAgICAgICAgLyoqCiAgICAgKiBAZGVwcmVjYXRlZAogICAgICovIHRoaXMuYXV0b1JlZnJlc2hPbk5ldHdvcmtDaGFuZ2UgPSBmYWxzZTsKICAgICAgICAvKioKICAgICAqIEBkZXByZWNhdGVkCiAgICAgKi8gdGhpcy5fYWNjb3VudHMgPSBuZXcgQXJyYXkoKTsKICAgICAgICAvKioKICAgICAqIEBkZXByZWNhdGVkCiAgICAgKi8gdGhpcy5fY2hhaW5JZCA9ICIweDEiOwogICAgICAgIC8qKgogICAgICogQGRlcHJlY2F0ZWQKICAgICAqLyB0aGlzLl9uZXR3b3JrVmVyc2lvbiA9ICIxIjsKICAgICAgICAvKioKICAgICAqIEBkZXByZWNhdGVkCiAgICAgKi8gdGhpcy5fbGlzdGVuZXJDb3VudCA9IDA7CiAgICAgICAgLyoqCiAgICAgICAgICogRml4IGZvciB0aGF0IHBvb3JseS1jb2RlZCBhcHAgdGhhdCBkb2VzIGBjb25zdCB7IHJlcXVlc3QgfSA9IHByb3ZpZGVyYAogICAgICAgICAqLyB0aGlzLnJlcXVlc3QgPSB0aGlzLnJlcXVlc3QuYmluZCh0aGlzKTsKICAgICAgICB0aGlzLnNlbmQgPSB0aGlzLnNlbmQuYmluZCh0aGlzKTsKICAgICAgICB0aGlzLnNlbmRBc3luYyA9IHRoaXMuc2VuZEFzeW5jLmJpbmQodGhpcyk7CiAgICAgICAgdGhpcy5lbmFibGUgPSB0aGlzLmVuYWJsZS5iaW5kKHRoaXMpOwogICAgICAgIHRoaXMuaXNDb25uZWN0ZWQgPSB0aGlzLmlzQ29ubmVjdGVkLmJpbmQodGhpcyk7CiAgICAgICAgdGhpcy5pc1VubG9ja2VkID0gdGhpcy5pc1VubG9ja2VkLmJpbmQodGhpcyk7CiAgICAgICAgdGhpcy5vbiA9IHRoaXMub24uYmluZCh0aGlzKTsKICAgICAgICB0aGlzLm9mZiA9IHRoaXMub2ZmLmJpbmQodGhpcyk7CiAgICAgICAgdGhpcy5vbmNlID0gdGhpcy5vbmNlLmJpbmQodGhpcyk7CiAgICAgICAgdGhpcy5lbWl0ID0gdGhpcy5lbWl0LmJpbmQodGhpcyk7CiAgICAgICAgdGhpcy5hZGRMaXN0ZW5lciA9IHRoaXMuYWRkTGlzdGVuZXIuYmluZCh0aGlzKTsKICAgICAgICB0aGlzLnJlbW92ZUxpc3RlbmVyID0gdGhpcy5yZW1vdmVMaXN0ZW5lci5iaW5kKHRoaXMpOwogICAgICAgIHRoaXMucHJlcGVuZExpc3RlbmVyID0gdGhpcy5wcmVwZW5kTGlzdGVuZXIuYmluZCh0aGlzKTsKICAgICAgICB0aGlzLnByZXBlbmRPbmNlTGlzdGVuZXIgPSB0aGlzLnByZXBlbmRPbmNlTGlzdGVuZXIuYmluZCh0aGlzKTsKICAgICAgICB0aGlzLnJlbW92ZUFsbExpc3RlbmVycyA9IHRoaXMucmVtb3ZlQWxsTGlzdGVuZXJzLmJpbmQodGhpcyk7CiAgICAgICAgdGhpcy5ldmVudE5hbWVzID0gdGhpcy5ldmVudE5hbWVzLmJpbmQodGhpcyk7CiAgICAgICAgdGhpcy5saXN0ZW5lcnMgPSB0aGlzLmxpc3RlbmVycy5iaW5kKHRoaXMpOwogICAgICAgIHRoaXMucmF3TGlzdGVuZXJzID0gdGhpcy5yYXdMaXN0ZW5lcnMuYmluZCh0aGlzKTsKICAgICAgICB0aGlzLmxpc3RlbmVyQ291bnQgPSB0aGlzLmxpc3RlbmVyQ291bnQuYmluZCh0aGlzKTsKICAgICAgICB0aGlzLmdldE1heExpc3RlbmVycyA9IHRoaXMuZ2V0TWF4TGlzdGVuZXJzLmJpbmQodGhpcyk7CiAgICAgICAgdGhpcy5zZXRNYXhMaXN0ZW5lcnMgPSB0aGlzLnNldE1heExpc3RlbmVycy5iaW5kKHRoaXMpOwogICAgICAgIHRoaXMuX3JlZW1pdCgiY29ubmVjdCIpOwogICAgICAgIHRoaXMuX3JlZW1pdCgiZGlzY29ubmVjdCIpOwogICAgICAgIHRoaXMuX3JlZW1pdCgiYWNjb3VudHNDaGFuZ2VkIik7CiAgICAgICAgdGhpcy5fcmVlbWl0KCJjaGFpbkNoYW5nZWQiKTsKICAgICAgICB0aGlzLl9yZWVtaXQoIm5ldHdvcmtDaGFuZ2VkIik7CiAgICAgICAgdGhpcy5vbigiYWNjb3VudHNDaGFuZ2VkIiwgKGFjY291bnRzKT0+ewogICAgICAgICAgICB0aGlzLl9hY2NvdW50cyA9IGFjY291bnRzOwogICAgICAgIH0pOwogICAgICAgIHRoaXMub24oImNoYWluQ2hhbmdlZCIsIChjaGFpbklkKT0+ewogICAgICAgICAgICB0aGlzLl9jaGFpbklkID0gY2hhaW5JZDsKICAgICAgICB9KTsKICAgICAgICAvKioKICAgICAgICAgKiBGaXggdGhhdCBvbGQgYXBwIHRoYXQgbmVlZHMgdG8gcmVsb2FkIG9uIG5ldHdvcmsgY2hhbmdlCiAgICAgICAgICovIHRoaXMub24oIm5ldHdvcmtDaGFuZ2VkIiwgKG5ldHdvcmtWZXJzaW9uKT0+ewogICAgICAgICAgICB0aGlzLl9uZXR3b3JrVmVyc2lvbiA9IG5ldHdvcmtWZXJzaW9uOwogICAgICAgICAgICBpZiAoIXRoaXMuYXV0b1JlZnJlc2hPbk5ldHdvcmtDaGFuZ2UpIHJldHVybjsKICAgICAgICAgICAgbG9jYXRpb24ucmVsb2FkKCk7CiAgICAgICAgfSk7CiAgICAgICAgLyoqCiAgICAgICAgICogRm9yY2UgdXBkYXRlIG9mIGBpc0Nvbm5lY3RlZGAsIGBzZWxlY3RlZEFkZHJlc3NgLCBgY2hhaW5JZGAgYG5ldHdvcmtWZXJzaW9uYAogICAgICAgICAqLyB0aGlzLnRyeVJlcXVlc3QoewogICAgICAgICAgICBpZDogbnVsbCwKICAgICAgICAgICAgbWV0aG9kOiAiZXRoX2FjY291bnRzIgogICAgICAgIH0pLnRoZW4oKHIpPT5yLmlnbm9yZSgpKTsKICAgIH0KfQpjb25zdCBwcm92aWRlciA9IG5ldyBQcm92aWRlcigpOwovLyBjb25zdCBwcm92aWRlciA9IG5ldyBQcm94eShuZXcgUHJvdmlkZXIoKSwgewovLyAgIGdldCh0YXJnZXQsIHAsIHJlY2VpdmVyKSB7Ci8vICAgICByZXR1cm4gUmVmbGVjdC5nZXQodGFyZ2V0LCBwLCByZWNlaXZlcikKLy8gICB9LAovLyB9KQovKioKICogRUlQLTExOTMKICovIHdpbmRvdy5ldGhlcmV1bSA9IHByb3ZpZGVyOwpjb25zdCBpY29uID0gbmV3IEZ1dHVyZSgpOwpjb25zdCBvbkxvZ28gPSAoZXZlbnQpPT57CiAgICBpY29uLnJlc29sdmUoSlNPTi5wYXJzZShldmVudC5kZXRhaWwpKTsKfTsKd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoImJydW1lOmljb24iLCBvbkxvZ28sIHsKICAgIHBhc3NpdmU6IHRydWUsCiAgICBvbmNlOiB0cnVlCn0pOwovKioKICogRUlQLTY5NjMKICovIHsKICAgIGFzeW5jIGZ1bmN0aW9uIGFubm91bmNlKCkgewogICAgICAgIGNvbnN0IGluZm8gPSBPYmplY3QuZnJlZXplKHsKICAgICAgICAgICAgdXVpZDogImU3NTBhOThjLWZmMmQtNGZjNC1iNmUyLWZhZjRkMTNkMWFkZCIsCiAgICAgICAgICAgIG5hbWU6ICJCcnVtZSBXYWxsZXQiLAogICAgICAgICAgICBpY29uOiBhd2FpdCBpY29uLnByb21pc2UsCiAgICAgICAgICAgIHJkbnM6ICJtb25leS5icnVtZSIKICAgICAgICB9KTsKICAgICAgICBjb25zdCBkZXRhaWwgPSBPYmplY3QuZnJlZXplKHsKICAgICAgICAgICAgaW5mbywKICAgICAgICAgICAgcHJvdmlkZXIKICAgICAgICB9KTsKICAgICAgICBjb25zdCBldmVudCA9IG5ldyBDdXN0b21FdmVudCgiZWlwNjk2Mzphbm5vdW5jZVByb3ZpZGVyIiwgewogICAgICAgICAgICBkZXRhaWwKICAgICAgICB9KTsKICAgICAgICB3aW5kb3cuZGlzcGF0Y2hFdmVudChldmVudCk7CiAgICB9CiAgICBmdW5jdGlvbiBvbkFubm91bmNlUmVxdWVzdChldmVudCkgewogICAgICAgIGFubm91bmNlKCk7CiAgICB9CiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcigiZWlwNjk2MzpyZXF1ZXN0UHJvdmlkZXIiLCBvbkFubm91bmNlUmVxdWVzdCwgewogICAgICAgIHBhc3NpdmU6IHRydWUKICAgIH0pOwogICAgYW5ub3VuY2UoKTsKfQovKioqKioqLyB9KSgpCjs=");
    const scriptUrl = browser.runtime.getURL("injected_script.js");
    const element = document.createElement("script");
    element.type = "text/javascript";
    element.textContent = "".concat(scriptBody, "\n//# sourceURL=").concat(scriptUrl);
    container.insertBefore(element, container.children[0]);
    container.removeChild(element);
}
async function tryGetOrigin() {
    const origin = {
        origin: location.origin,
        title: document.title
    };
    for (const meta of document.getElementsByTagName("meta")){
        if (meta.name === "application-name") {
            origin.title = meta.content;
            continue;
        }
    }
    for (const link of document.getElementsByTagName("link")){
        if ([
            "icon",
            "shortcut icon",
            "icon shortcut"
        ].includes(link.rel)) {
            const blob = await tryFetchAsBlob(link.href);
            if (blob.isErr()) continue;
            const data = await Blobs.tryReadAsDataURL(blob.inner);
            if (data.isErr()) continue;
            origin.icon = data.inner;
            continue;
        }
        if (link.rel === "manifest") {
            const manifest = await tryFetchAsJson(link.href);
            if (manifest.isErr()) continue;
            if (manifest.inner.name) origin.title = manifest.inner.name;
            if (manifest.inner.short_name) origin.title = manifest.inner.short_name;
            if (manifest.inner.description) origin.description = manifest.inner.description;
            continue;
        }
    }
    if (!origin.icon) {
        await (async ()=>{
            const blob = await tryFetchAsBlob("/favicon.ico");
            if (blob.isErr()) return;
            const data = await Blobs.tryReadAsDataURL(blob.inner);
            if (data.isErr()) return;
            origin.icon = data.inner;
        })();
    }
    return new ok_Ok(origin);
}
new Pool(async (params)=>{
    return Result.unthrow(async (t)=>{
        const env_1 = {
            stack: [],
            error: void 0,
            hasError: false
        };
        try {
            const { index, pool } = params;
            await new Promise((ok)=>setTimeout(ok, 1));
            const raw = BrowserError.tryRunSync(()=>{
                const port = browser.runtime.connect({
                    name: location.origin
                });
                port.onDisconnect.addListener(()=>void chrome.runtime.lastError);
                return port;
            }).throw(t);
            const preport = content_script_addDisposableResource(env_1, new Box(new Disposer(raw, ()=>raw.disconnect())), false);
            const prerouter = content_script_addDisposableResource(env_1, new Box(new ExtensionPort("background", preport.inner.inner)), false);
            const port = preport.moveOrThrow();
            const router = prerouter.moveOrThrow();
            const onInnerClean = ()=>{
                const env_2 = {
                    stack: [],
                    error: void 0,
                    hasError: false
                };
                try {
                    const postrouter = content_script_addDisposableResource(env_2, router, false);
                    const postport = content_script_addDisposableResource(env_2, port, false);
                } catch (e_2) {
                    env_2.error = e_2;
                    env_2.hasError = true;
                } finally{
                    content_script_disposeResources(env_2);
                }
            };
            const preinner = content_script_addDisposableResource(env_1, new Box(new Disposer(router.inner, onInnerClean)), false);
            const onScriptRequest = async (input)=>{
                const request = JSON.parse(input.detail);
                const result = await router.inner.tryRequest({
                    method: "brume_run",
                    params: [
                        request,
                        mouse
                    ]
                });
                const response = response_RpcResponse.rewrap(request.id, result.andThenSync((r)=>r));
                const detail = JSON.stringify(response);
                const output = new CustomEvent("ethereum:response", {
                    detail
                });
                window.dispatchEvent(output);
            };
            const onAccountsChanged = async (request)=>{
                const [accounts] = request.params;
                const detail = JSON.stringify(accounts);
                const event = new CustomEvent("ethereum:accountsChanged", {
                    detail
                });
                window.dispatchEvent(event);
                return ok_Ok.void();
            };
            const onConnect = async (request)=>{
                const [{ chainId }] = request.params;
                const detail = JSON.stringify({
                    chainId
                });
                const event = new CustomEvent("ethereum:connect", {
                    detail
                });
                window.dispatchEvent(event);
                return ok_Ok.void();
            };
            const onChainChanged = async (request)=>{
                const [chainId] = request.params;
                const detail = JSON.stringify(chainId);
                const event = new CustomEvent("ethereum:chainChanged", {
                    detail
                });
                window.dispatchEvent(event);
                return ok_Ok.void();
            };
            const onNetworkChanged = async (request)=>{
                const [chainId] = request.params;
                const detail = JSON.stringify(chainId);
                const event = new CustomEvent("ethereum:networkChanged", {
                    detail
                });
                window.dispatchEvent(event);
                return ok_Ok.void();
            };
            const onBackgroundRequest = async (request)=>{
                if (request.method === "brume_origin") return new some_Some(await tryGetOrigin());
                if (request.method === "connect") return new some_Some(await onConnect(request));
                if (request.method === "accountsChanged") return new some_Some(await onAccountsChanged(request));
                if (request.method === "chainChanged") return new some_Some(await onChainChanged(request));
                if (request.method === "networkChanged") return new some_Some(await onNetworkChanged(request));
                return new none_None();
            };
            const onClose = async ()=>{
                const event = new CustomEvent("ethereum:disconnect", {});
                window.dispatchEvent(event);
                pool.restart(index);
                return new none_None();
            };
            window.addEventListener("ethereum:request", onScriptRequest, {
                passive: true
            });
            router.inner.events.on("request", onBackgroundRequest, {
                passive: true
            });
            router.inner.events.on("close", onClose, {
                passive: true
            });
            const inner = preinner.moveOrThrow();
            const onEntryClean = ()=>{
                const env_3 = {
                    stack: [],
                    error: void 0,
                    hasError: false
                };
                try {
                    const postinner = content_script_addDisposableResource(env_3, inner, false);
                    window.removeEventListener("ethereum:request", onScriptRequest);
                    router.inner.events.off("request", onBackgroundRequest);
                    router.inner.events.off("close", onClose);
                } catch (e_3) {
                    env_3.error = e_3;
                    env_3.hasError = true;
                } finally{
                    content_script_disposeResources(env_3);
                }
            };
            const preentry = content_script_addDisposableResource(env_1, new Box(new Disposer(inner, onEntryClean)), false);
            {
                const icon = await router.inner.tryRequest({
                    method: "brume_icon"
                }).then((r)=>r.throw(t).throw(t));
                const detail = JSON.stringify(icon);
                const event = new CustomEvent("brume:icon", {
                    detail
                });
                window.dispatchEvent(event);
            }
            return new ok_Ok(preentry.unwrapOrThrow());
        } catch (e_1) {
            env_1.error = e_1;
            env_1.hasError = true;
        } finally{
            content_script_disposeResources(env_1);
        }
    });
}, {
    capacity: 1
});

/******/ })()
;