(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[557],{

/***/ 5682:
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


    (window.__NEXT_P = window.__NEXT_P || []).push([
      "/test/ui/textarea/contrast",
      function () {
        return __webpack_require__(4826);
      }
    ]);
    if(false) {}
  

/***/ }),

/***/ 4826:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ Page; }
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _libs_ui_textarea__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(110);


function Page() {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_libs_ui_textarea__WEBPACK_IMPORTED_MODULE_1__/* .Textarea.Contrast */ .g.m.Test, {});
}


/***/ }),

/***/ 110:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  g: function() { return /* reexport */ textarea_namespaceObject; }
});

// NAMESPACE OBJECT: ./src/libs/ui/textarea/index.tsx
var textarea_namespaceObject = {};
__webpack_require__.r(textarea_namespaceObject);
__webpack_require__.d(textarea_namespaceObject, {
  m: function() { return contrast_Contrast; }
});

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
;// CONCATENATED MODULE: ./src/libs/ui/textarea/contrast.tsx


function contrast_Contrast(props) {
    const { children, className, xref, ...input } = props;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("textarea", {
        className: "px-4 py-2 rounded-xl outline-none border border-transparent clicked-or-focused:border-contrast bg-contrast transition ".concat(className),
        ref: xref,
        ...input,
        children: children
    });
}
(function(Contrast) {
    function Test() {
        return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
            className: "p-1",
            children: /*#__PURE__*/ (0,jsx_runtime.jsx)(contrast_Contrast, {
                placeholder: "Hello world"
            })
        });
    }
    Contrast.Test = Test;
})(contrast_Contrast || (contrast_Contrast = {}));

;// CONCATENATED MODULE: ./src/libs/ui/textarea/index.tsx


;// CONCATENATED MODULE: ./src/libs/ui/textarea.tsx




/***/ })

},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
/******/ __webpack_require__.O(0, [774,888,179], function() { return __webpack_exec__(5682); });
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ _N_E = __webpack_exports__;
/******/ }
]);