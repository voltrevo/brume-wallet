"use strict";
(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[109],{

/***/ 7125:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  DonePage: function() { return /* binding */ DonePage; },
  PersonalSignPage: function() { return /* binding */ PersonalSignPage; },
  Ready: function() { return /* binding */ Ready; },
  SwitchPage: function() { return /* binding */ SwitchPage; },
  TransactPage: function() { return /* binding */ TransactPage; },
  TypedSignPage: function() { return /* binding */ TypedSignPage; },
  WalletAndChainSelectPage: function() { return /* binding */ WalletAndChainSelectPage; },
  "default": function() { return /* binding */ Popup; }
});

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
// EXTERNAL MODULE: ./src/libs/bigints/bigints.ts
var bigints = __webpack_require__(6827);
// EXTERNAL MODULE: ./src/libs/errors/errors.ts
var errors = __webpack_require__(8524);
// EXTERNAL MODULE: ./src/libs/ethereum/mods/chain.tsx
var mods_chain = __webpack_require__(9183);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/XMarkIcon.js
var XMarkIcon = __webpack_require__(1415);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/CheckIcon.js
var CheckIcon = __webpack_require__(2911);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/PlusIcon.js
var PlusIcon = __webpack_require__(8680);
// EXTERNAL MODULE: ./src/libs/react/callback.tsx
var callback = __webpack_require__(5379);
// EXTERNAL MODULE: ./src/libs/react/events.ts
var events = __webpack_require__(8418);
// EXTERNAL MODULE: ./src/libs/react/handles/boolean.tsx
var handles_boolean = __webpack_require__(8544);
// EXTERNAL MODULE: ./src/libs/react/memo.ts + 1 modules
var memo = __webpack_require__(7664);
// EXTERNAL MODULE: ./src/libs/results/results.ts
var results = __webpack_require__(7519);
// EXTERNAL MODULE: ./src/libs/ui/button.tsx + 8 modules
var ui_button = __webpack_require__(9178);
// EXTERNAL MODULE: ./src/libs/ui/dialog/dialog.tsx
var dialog = __webpack_require__(6488);
// EXTERNAL MODULE: ./src/mods/foreground/background/context.tsx + 3 modules
var background_context = __webpack_require__(5855);
// EXTERNAL MODULE: ./src/mods/foreground/components/page/header.tsx
var header = __webpack_require__(6915);
// EXTERNAL MODULE: ./src/mods/foreground/components/page/page.tsx
var page = __webpack_require__(179);
// EXTERNAL MODULE: ./src/mods/foreground/entities/requests/data.tsx + 1 modules
var data = __webpack_require__(7440);
// EXTERNAL MODULE: ./src/mods/foreground/entities/sessions/data.ts + 1 modules
var sessions_data = __webpack_require__(5743);
// EXTERNAL MODULE: ./node_modules/@swc/helpers/esm/_class_private_field_get.js + 1 modules
var _class_private_field_get = __webpack_require__(7121);
// EXTERNAL MODULE: ./node_modules/@swc/helpers/esm/_class_private_field_init.js
var _class_private_field_init = __webpack_require__(9886);
// EXTERNAL MODULE: ./node_modules/@swc/helpers/esm/_class_private_field_set.js + 1 modules
var _class_private_field_set = __webpack_require__(5321);
// EXTERNAL MODULE: ./src/libs/maps/maps.ts
var maps = __webpack_require__(1634);
// EXTERNAL MODULE: ./src/libs/signals/signals.ts
var signals = __webpack_require__(5802);
// EXTERNAL MODULE: ./src/libs/tor/circuits/circuits.ts
var circuits_circuits = __webpack_require__(9340);
// EXTERNAL MODULE: ./node_modules/@hazae41/fleche/dist/esm/src/mods/fetch/fetch.mjs + 8 modules
var fetch = __webpack_require__(2156);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/fetched/fetched.mjs
var fetched = __webpack_require__(1458);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/fetched/fail.mjs
var fail = __webpack_require__(9164);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/fetched/data.mjs
var fetched_data = __webpack_require__(8123);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/queries/simple/query.mjs
var query = __webpack_require__(6233);
// EXTERNAL MODULE: ./node_modules/@hazae41/option/dist/esm/mods/option/option.mjs
var option_option = __webpack_require__(5316);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/result.mjs
var result = __webpack_require__(918);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/err.mjs
var err = __webpack_require__(166);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/ok.mjs
var ok = __webpack_require__(5591);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/errors.mjs
var result_errors = __webpack_require__(2564);
;// CONCATENATED MODULE: ./src/mods/background/service_worker/entities/signatures/data.ts



var __addDisposableResource = undefined && undefined.__addDisposableResource || function(env, value, async) {
    if (value !== null && value !== void 0) {
        if (typeof value !== "object" && typeof value !== "function") throw new TypeError("Object expected.");
        var dispose;
        if (async) {
            if (!Symbol.asyncDispose) throw new TypeError("Symbol.asyncDispose is not defined.");
            dispose = value[Symbol.asyncDispose];
        }
        if (dispose === void 0) {
            if (!Symbol.dispose) throw new TypeError("Symbol.dispose is not defined.");
            dispose = value[Symbol.dispose];
        }
        if (typeof dispose !== "function") throw new TypeError("Object not disposable.");
        env.stack.push({
            value: value,
            dispose: dispose,
            async: async
        });
    } else if (async) {
        env.stack.push({
            async: true
        });
    }
    return value;
};
var __disposeResources = undefined && undefined.__disposeResources || function(SuppressedError1) {
    return function(env) {
        function fail(e) {
            env.error = env.hasError ? new SuppressedError1(e, env.error, "An error was suppressed during disposal.") : e;
            env.hasError = true;
        }
        function next() {
            while(env.stack.length){
                var rec = env.stack.pop();
                try {
                    var result = rec.dispose && rec.dispose.call(rec.value);
                    if (rec.async) return Promise.resolve(result).then(next, function(e) {
                        fail(e);
                        return next();
                    });
                } catch (e) {
                    fail(e);
                }
            }
            if (env.hasError) throw env.error;
        }
        return next();
    };
}(typeof SuppressedError === "function" ? SuppressedError : function(error, suppressed, message) {
    var e = new Error(message);
    return e.name = "SuppressedError", e.error = error, e.suppressed = suppressed, e;
});
var _a;







var _class = /*#__PURE__*/ new WeakMap();
class ApiError extends Error {
    static from(cause) {
        return new _a({
            cause
        });
    }
    constructor(options){
        super("Could not fetch", options);
        (0,_class_private_field_init._)(this, _class, {
            writable: true,
            value: void 0
        });
        (0,_class_private_field_set._)(this, _class, _a);
        this.name = (0,_class_private_field_get._)(this, _class).name;
    }
}
_a = ApiError;
async function tryFetchRaw(ethereum, url, init) {
    let more = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : {};
    return await result/* Result */.x.runAndDoubleWrap(async ()=>{
        const { signal: parentSignal } = more;
        const { brume } = ethereum;
        const circuits = option_option/* Option */.W.wrap(brume.circuits).ok().unwrap();
        async function runWithPoolOrThrow(index) {
            return await result/* Result */.x.unthrow(async (t)=>{
                const env_1 = {
                    stack: [],
                    error: void 0,
                    hasError: false
                };
                try {
                    const circuitSignal = signals/* AbortSignals */.f.timeout(5000, parentSignal);
                    const circuit = await circuits.tryGet(index, circuitSignal).then((r)=>r.unwrap().unwrap().inner);
                    const stream = __addDisposableResource(env_1, await circuits_circuits/* Circuits */.N.openAsOrThrow(circuit.inner, url), false);
                    const fetchSignal = signals/* AbortSignals */.f.timeout(5000, parentSignal);
                    const res = await (0,fetch/* fetch */.h)(url, {
                        signal: fetchSignal,
                        stream: stream.inner
                    });
                    if (!res.ok) {
                        const text = await result/* Result */.x.runAndDoubleWrap(()=>{
                            return res.text();
                        }).then((r)=>r.throw(t));
                        return new err/* Err */.U(new Error(text));
                    }
                    const json = await result/* Result */.x.runAndDoubleWrap(async ()=>{
                        return await res.json();
                    }).then((r)=>r.throw(t));
                    return new ok.Ok(json);
                } catch (e_1) {
                    env_1.error = e_1;
                    env_1.hasError = true;
                } finally{
                    __disposeResources(env_1);
                }
            }).then((r)=>fetched/* Fetched */.F.rewrap(r));
        }
        const promises = Array.from({
            length: circuits.capacity
        }, (_, i)=>runWithPoolOrThrow(i));
        const results = await Promise.allSettled(promises);
        const fetcheds = new Map();
        const counters = new Map();
        for (const result of results){
            if (result.status === "rejected") continue;
            if (result.value.isErr()) continue;
            if (init === null || init === void 0 ? void 0 : init.noCheck) return result.value;
            const raw = JSON.stringify(result.value.inner);
            const previous = option_option/* Option */.W.wrap(counters.get(raw)).unwrapOr(0);
            counters.set(raw, previous + 1);
            fetcheds.set(raw, result.value);
        }
        /**
         * One truth -> return it
         * Zero truth -> throw AggregateError
         */ if (counters.size < 2) return await Promise.any(promises);
        console.warn("Different results from multiple circuits for ".concat(url), {
            fetcheds
        });
        /**
         * Sort truths by occurence
         */ const sorteds = [
            ...maps/* Maps */.o.entries(counters)
        ].sort((a, b)=>b.value - a.value);
        /**
         * Two concurrent truths
         */ if (sorteds[0].value === sorteds[1].value) {
            console.warn("Could not choose truth for ".concat(url));
            const random = Math.round(Math.random());
            return fetcheds.get(sorteds[random].key);
        }
        return fetcheds.get(sorteds[0].key);
    });
}
var BgSignature;
(function(BgSignature) {
    BgSignature.method = "eth_getSignature";
    function key(hash) {
        return {
            version: 3,
            chainId: 1,
            method: BgSignature.method,
            params: [
                hash
            ]
        };
    }
    BgSignature.key = key;
    async function parseOrThrow(ethereum, request, storage) {
        const [hash] = request.params;
        return schema(ethereum, hash, storage);
    }
    BgSignature.parseOrThrow = parseOrThrow;
    function schema(ethereum, hash, storage) {
        const fetcher = async (key, more)=>{
            try {
                const url = "https://sig.eth.samczsun.com/api/v1/signatures?function=".concat(hash);
                const fetched = await tryFetchRaw(ethereum, url, {}, more).then((r)=>r.unwrap());
                if (fetched.isErr()) return fetched;
                const result = fetched.unwrap();
                if (!result.ok) return new fail/* Fail */.M(ApiError.from(result.error));
                return new fetched_data/* Data */.V(result.result.function[hash]);
            } catch (e) {
                return new fail/* Fail */.M(result_errors/* Catched */.$c.from(e));
            }
        };
        return (0,query/* createQuery */.rP)({
            key: key(hash),
            fetcher,
            storage
        });
    }
    BgSignature.schema = schema;
})(BgSignature || (BgSignature = {}));

// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/react/hooks/queries/simple.mjs + 1 modules
var simple = __webpack_require__(564);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/react/hooks/blocks/use-fetch.mjs
var use_fetch = __webpack_require__(4704);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/react/hooks/blocks/use-visible.mjs
var use_visible = __webpack_require__(7836);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/react/hooks/blocks/use-error.mjs
var use_error = __webpack_require__(3399);
// EXTERNAL MODULE: ./src/mods/foreground/storage/storage.ts
var storage_storage = __webpack_require__(604);
// EXTERNAL MODULE: ./src/mods/foreground/storage/user.tsx
var user = __webpack_require__(9718);
// EXTERNAL MODULE: ./src/mods/foreground/entities/wallets/data.ts
var wallets_data = __webpack_require__(9327);
;// CONCATENATED MODULE: ./src/mods/foreground/entities/signatures/data.tsx






var FgSignature;
(function(FgSignature) {
    FgSignature.key = BgSignature.key;
    function schema(ethereum, hash, storage) {
        if (ethereum == null) return;
        if (hash == null) return;
        const fetcher = async (request)=>await (0,wallets_data/* fetchOrFail */.yR)(request, ethereum);
        return (0,query/* createQuery */.rP)({
            key: FgSignature.key(hash),
            fetcher,
            storage
        });
    }
    FgSignature.schema = schema;
})(FgSignature || (FgSignature = {}));
function useSignature(ethereum, hash) {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(FgSignature.schema, [
        ethereum,
        hash,
        storage
    ]);
    (0,use_fetch/* useFetch */.i)(query);
    (0,use_visible/* useVisible */.E)(query);
    (0,storage_storage/* useSubscribe */.Q)(query, storage);
    (0,use_error/* useError */.V)(query, errors/* Errors */.D.onQueryError);
    return query;
}

// EXTERNAL MODULE: ./src/mods/foreground/entities/unknown/data.ts
var unknown_data = __webpack_require__(9801);
// EXTERNAL MODULE: ./src/mods/foreground/entities/users/context.tsx
var context = __webpack_require__(1677);
// EXTERNAL MODULE: ./src/mods/foreground/entities/wallets/all/create/index.tsx + 2 modules
var create = __webpack_require__(3166);
// EXTERNAL MODULE: ./src/mods/foreground/entities/wallets/all/page.tsx
var all_page = __webpack_require__(200);
// EXTERNAL MODULE: ./src/mods/foreground/errors/errors.ts
var errors_errors = __webpack_require__(202);
// EXTERNAL MODULE: ./src/mods/foreground/overlay/bottom.tsx + 3 modules
var bottom = __webpack_require__(9403);
// EXTERNAL MODULE: ./src/mods/foreground/overlay/navbar.tsx
var navbar = __webpack_require__(5794);
// EXTERNAL MODULE: ./src/mods/foreground/overlay/overlay.tsx + 2 modules
var overlay = __webpack_require__(938);
// EXTERNAL MODULE: ./src/mods/foreground/router/path/context.tsx
var path_context = __webpack_require__(8097);
// EXTERNAL MODULE: ./src/mods/foreground/router/router.tsx + 26 modules
var router = __webpack_require__(2144);
// EXTERNAL MODULE: ./node_modules/@hazae41/base16/dist/esm/src/mods/base16/adapter.mjs
var adapter = __webpack_require__(2248);
// EXTERNAL MODULE: ./node_modules/@hazae41/bytes/dist/esm/mods/bytes/bytes.mjs + 3 modules
var bytes = __webpack_require__(1694);
// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/types/zerohex/index.mjs
var zerohex = __webpack_require__(6113);
// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/abi/signature/signature.mjs + 4 modules
var signature = __webpack_require__(6403);
// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/abi/decode.mjs + 1 modules
var decode = __webpack_require__(7817);
// EXTERNAL MODULE: ./node_modules/@hazae41/jsonrpc/dist/esm/mods/rpc/ok.mjs
var rpc_ok = __webpack_require__(1752);
// EXTERNAL MODULE: ./node_modules/@hazae41/jsonrpc/dist/esm/mods/rpc/err.mjs
var rpc_err = __webpack_require__(667);
// EXTERNAL MODULE: ./node_modules/ethers/lib.esm/transaction/transaction.js + 2 modules
var transaction = __webpack_require__(5418);
// EXTERNAL MODULE: ./node_modules/react/index.js
var react = __webpack_require__(7294);
;// CONCATENATED MODULE: ./pages/popup.tsx





































function Popup() {
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("main", {
        id: "main",
        className: "p-safe grow w-full flex flex-col overflow-hidden",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(navbar/* NavBar */.l, {}),
            /*#__PURE__*/ (0,jsx_runtime.jsx)(overlay/* Overlay */.aV, {
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(background_context/* BackgroundGuard */.bI, {
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)(context/* UserGuard */.ds, {
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(Ready, {})
                    })
                })
            })
        ]
    });
}
function Ready() {
    const background = (0,background_context/* useBackgroundContext */.D_)().unwrap();
    (0,react.useEffect)(()=>{
        background.tryRequest({
            method: "popup_hello"
        }).then((r)=>r.unwrap().unwrap());
    }, [
        background
    ]);
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "grow w-full flex flex-col overflow-y-scroll",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "grow w-full m-auto max-w-3xl flex flex-col",
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)(router/* Router */.F, {})
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)(bottom/* Bottom */.z, {})
        ]
    });
}
function TransactPage() {
    var _requestQuery_data, _sessionQuery_data, _walletQuery_data, _maybeSession_wallets_at, _gasPriceQuery_data, _nonceQuery_data, _signaturesQuery_data;
    const { url, go } = (0,path_context/* usePathContext */.td)().unwrap();
    const { searchParams } = url;
    const background = (0,background_context/* useBackgroundContext */.D_)().unwrap();
    const id = option_option/* Option */.W.wrap(searchParams.get("id")).unwrap();
    const to = option_option/* Option */.W.wrap(searchParams.get("to")).unwrap();
    const gas = option_option/* Option */.W.wrap(searchParams.get("gas")).unwrap();
    const walletId = option_option/* Option */.W.wrap(searchParams.get("walletId")).unwrap();
    const chainId = option_option/* Option */.W.wrap(searchParams.get("chainId")).mapSync(Number).unwrap();
    const requestQuery = (0,data/* useAppRequest */.Vd)(id);
    const maybeRequest = (_requestQuery_data = requestQuery.data) === null || _requestQuery_data === void 0 ? void 0 : _requestQuery_data.inner;
    const sessionQuery = (0,sessions_data/* useSession */.k)(maybeRequest === null || maybeRequest === void 0 ? void 0 : maybeRequest.session);
    const maybeSession = (_sessionQuery_data = sessionQuery.data) === null || _sessionQuery_data === void 0 ? void 0 : _sessionQuery_data.inner;
    const walletQuery = (0,wallets_data/* useWallet */.Os)(walletId);
    const maybeWallet = (_walletQuery_data = walletQuery.data) === null || _walletQuery_data === void 0 ? void 0 : _walletQuery_data.inner;
    const chain = option_option/* Option */.W.wrap(mods_chain/* chainByChainId */.DH[chainId]).unwrap();
    const value = searchParams.get("value");
    const maybeData = searchParams.get("data");
    const context = (0,wallets_data/* useEthereumContext */.Kn)(maybeSession === null || maybeSession === void 0 ? void 0 : (_maybeSession_wallets_at = maybeSession.wallets.at(0)) === null || _maybeSession_wallets_at === void 0 ? void 0 : _maybeSession_wallets_at.uuid, chain);
    const gasPriceQuery = (0,unknown_data/* useGasPrice */.Fh)(context);
    const maybeGasPrice = (_gasPriceQuery_data = gasPriceQuery.data) === null || _gasPriceQuery_data === void 0 ? void 0 : _gasPriceQuery_data.inner;
    const nonceQuery = (0,unknown_data/* useNonce */.XE)(maybeWallet === null || maybeWallet === void 0 ? void 0 : maybeWallet.address, context);
    const maybeNonce = (_nonceQuery_data = nonceQuery.data) === null || _nonceQuery_data === void 0 ? void 0 : _nonceQuery_data.inner;
    const maybeHash = option_option/* Option */.W.wrap(maybeData).mapSync((x)=>{
        return x.slice(0, 10);
    }).inner;
    const signaturesQuery = useSignature(context, maybeHash);
    const maybeSignatures = (_signaturesQuery_data = signaturesQuery.data) === null || _signaturesQuery_data === void 0 ? void 0 : _signaturesQuery_data.inner;
    const maybeSignature = (0,memo/* useAsyncReplaceMemo */.EY)(async ()=>{
        if (maybeData == null) return;
        if (maybeHash == null) return;
        if (maybeSignatures == null) return;
        const zeroHexData = zerohex/* ZeroHexString */.T.from(maybeData);
        return maybeSignatures.map((param)=>{
            let { name } = param;
            return result/* Result */.x.runAndWrapSync(()=>{
                const abi = signature/* FunctionSignature */.I.parseOrThrow(name);
                const { args } = decode/* decodeOrThrow */.Dt(abi.funcAndArgs, zeroHexData);
                function stringifyOrThrow(x) {
                    if (typeof x === "string") return x;
                    if (typeof x === "boolean") return String(x);
                    if (typeof x === "number") return String(x);
                    if (typeof x === "bigint") return String(x);
                    if (x instanceof Uint8Array) return zerohex/* ZeroHexString */.T.from(adapter/* get */.U().encodeOrThrow(x));
                    if (Array.isArray(x)) return "(".concat(x.map(stringifyOrThrow).join(", "), ")");
                    return "unknown";
                }
                const decoded = args.intoOrThrow().map(stringifyOrThrow).join(", ");
                return {
                    name,
                    decoded
                };
            }).inspectErrSync((e)=>console.warn({
                    e
                })).unwrapOr(undefined);
        }).find((it)=>it != null);
    }, [
        maybeData,
        maybeHash,
        maybeSignatures
    ]);
    const onApprove = (0,callback/* useAsyncUniqueCallback */.T)(async ()=>{
        return await result/* Result */.x.unthrow(async (t)=>{
            const wallet = option_option/* Option */.W.wrap(maybeWallet).ok().throw(t);
            const gasPrice = option_option/* Option */.W.wrap(maybeGasPrice).ok().throw(t);
            const nonce = option_option/* Option */.W.wrap(maybeNonce).ok().throw(t);
            const tx = result/* Result */.x.runAndDoubleWrapSync(()=>{
                return transaction/* Transaction */.Y.from({
                    data: maybeData,
                    to: to,
                    gasLimit: gas,
                    chainId: chain.chainId,
                    gasPrice: gasPrice,
                    nonce: Number(nonce),
                    value: value
                });
            }).throw(t);
            const instance = await wallets_data/* EthereumWalletInstance */.Vy.tryFrom(wallet, background).then((r)=>r.throw(t));
            tx.signature = await instance.trySignTransaction(tx, background).then((r)=>r.throw(t));
            await background.tryRequest({
                method: "brume_respond",
                params: [
                    new rpc_ok/* RpcOk */.r(id, tx.serialized)
                ]
            }).then((r)=>r.throw(t).throw(t));
            go("/done");
            return ok.Ok.void();
        }).then(results/* Results */.u.logAndAlert);
    }, [
        background,
        id,
        maybeWallet,
        maybeGasPrice,
        maybeNonce,
        chain
    ]);
    const onReject = (0,callback/* useAsyncUniqueCallback */.T)(async ()=>{
        return await result/* Result */.x.unthrow(async (t)=>{
            await background.tryRequest({
                method: "brume_respond",
                params: [
                    rpc_err/* RpcErr */.s6.rewrap(id, new err/* Err */.U(new errors_errors/* UserRejectedError */.Ai()))
                ]
            }).then((r)=>r.throw(t).throw(t));
            go("/done");
            return ok.Ok.void();
        }).then(results/* Results */.u.logAndAlert);
    }, [
        background,
        id
    ]);
    const loading = (0,react.useMemo)(()=>{
        if (onApprove.loading) return true;
        if (gasPriceQuery.data == null) return true;
        if (nonceQuery.data == null) return true;
        return false;
    }, [
        onApprove.loading,
        gasPriceQuery.data,
        nonceQuery.data
    ]);
    var _maybeSignature_decoded;
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(page/* Page */.T, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "p-4 grow flex flex-col items-center justify-center",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "text-center text-xl font-medium",
                        children: "Transaction"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-full max-w-[230px] text-center text-contrast",
                        children: "Do you want to approve this transaction?"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "w-full p-4 grow flex flex-col",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "w-full p-4 border border-contrast rounded-xl whitespace-pre-wrap break-words",
                        children: [
                            "To: ",
                            to
                        ]
                    }),
                    value && /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "w-full p-4 border border-contrast rounded-xl whitespace-pre-wrap mt-2 break-words",
                        children: [
                            "Value: ",
                            bigints/* BigIntToHex */.W.tryDecode(zerohex/* ZeroHexString */.T.from(value)).mapSync((x)=>bigints/* BigInts */.l.float(x, 18)).ok().unwrapOr("Error")
                        ]
                    }),
                    maybeSignature && /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "grow w-full p-4 border border-contrast rounded-xl whitespace-pre-wrap mt-2 break-words",
                        children: [
                            "Function: ",
                            maybeSignature.name
                        ]
                    }),
                    (maybeSignature || maybeData) && /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "grow w-full p-4 border border-contrast rounded-xl whitespace-pre-wrap mt-2 break-words",
                        children: [
                            "Data: ",
                            (_maybeSignature_decoded = maybeSignature === null || maybeSignature === void 0 ? void 0 : maybeSignature.decoded) !== null && _maybeSignature_decoded !== void 0 ? _maybeSignature_decoded : maybeData
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "p-4 w-full flex items-center gap-2",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.Contrast */.z.mn, {
                        className: "grow po-md hovered-or-clicked-or-focused:scale-105 !transition",
                        onClick: onReject.run,
                        disabled: onReject.loading,
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)(XMarkIcon/* default */.Z, {
                                    className: "size-5"
                                }),
                                "No, reject it"
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.Gradient */.z.ph, {
                        className: "grow po-md hovered-or-clicked-or-focused:scale-105 !transition",
                        onClick: onApprove.run,
                        disabled: loading,
                        colorIndex: 5,
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)(CheckIcon/* default */.Z, {
                                    className: "size-5"
                                }),
                                "Yes, approve it"
                            ]
                        })
                    })
                ]
            })
        ]
    });
}
function SwitchPage() {
    const { url, go } = (0,path_context/* usePathContext */.td)().unwrap();
    const { searchParams } = url;
    const background = (0,background_context/* useBackgroundContext */.D_)().unwrap();
    const id = option_option/* Option */.W.wrap(searchParams.get("id")).unwrap();
    const onApprove = (0,callback/* useAsyncUniqueCallback */.T)(async ()=>{
        return await result/* Result */.x.unthrow(async (t)=>{
            await background.tryRequest({
                method: "brume_respond",
                params: [
                    new rpc_ok/* RpcOk */.r(id, undefined)
                ]
            }).then((r)=>r.throw(t).throw(t));
            go("/done");
            return ok.Ok.void();
        }).then(results/* Results */.u.logAndAlert);
    }, [
        background,
        id
    ]);
    const onReject = (0,callback/* useAsyncUniqueCallback */.T)(async ()=>{
        return await result/* Result */.x.unthrow(async (t)=>{
            await background.tryRequest({
                method: "brume_respond",
                params: [
                    rpc_err/* RpcErr */.s6.rewrap(id, new err/* Err */.U(new errors_errors/* UserRejectedError */.Ai()))
                ]
            }).then((r)=>r.throw(t).throw(t));
            await new Promise((ok)=>setTimeout(ok, 250));
            go("/done");
            return ok.Ok.void();
        }).then(results/* Results */.u.logAndAlert);
    }, [
        background,
        id
    ]);
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(page/* Page */.T, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "p-4 grow flex flex-col items-center justify-center",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "text-center text-xl font-medium",
                        children: "Switch chain"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-full max-w-[230px] text-center text-contrast",
                        children: "Do you want to switch the Ethereum chain?"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "p-4 w-full flex items-center gap-2",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.Contrast */.z.mn, {
                        className: "grow po-md hovered-or-clicked-or-focused:scale-105 !transition",
                        onClick: onReject.run,
                        disabled: onReject.loading,
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)(XMarkIcon/* default */.Z, {
                                    className: "size-5"
                                }),
                                "No, reject it"
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.Gradient */.z.ph, {
                        className: "grow po-md hovered-or-clicked-or-focused:scale-105 !transition",
                        onClick: onApprove.run,
                        disabled: onApprove.loading,
                        colorIndex: 5,
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)(CheckIcon/* default */.Z, {
                                    className: "size-5"
                                }),
                                "Yes, approve it"
                            ]
                        })
                    })
                ]
            })
        ]
    });
}
function PersonalSignPage() {
    var _walletQuery_data;
    const { url, go } = (0,path_context/* usePathContext */.td)().unwrap();
    const { searchParams } = url;
    const background = (0,background_context/* useBackgroundContext */.D_)().unwrap();
    const id = option_option/* Option */.W.wrap(searchParams.get("id")).unwrap();
    const message = option_option/* Option */.W.wrap(searchParams.get("message")).unwrap();
    const walletId = option_option/* Option */.W.wrap(searchParams.get("walletId")).unwrap();
    const walletQuery = (0,wallets_data/* useWallet */.Os)(walletId);
    const maybeWallet = (_walletQuery_data = walletQuery.data) === null || _walletQuery_data === void 0 ? void 0 : _walletQuery_data.inner;
    const userMessage = (0,react.useMemo)(()=>{
        return message.startsWith("0x") ? bytes/* Bytes */.J.toUtf8(adapter/* get */.U().tryPadStartAndDecode(message.slice(2)).unwrap().copyAndDispose()) : message;
    }, [
        message
    ]);
    const onApprove = (0,callback/* useAsyncUniqueCallback */.T)(async ()=>{
        return await result/* Result */.x.unthrow(async (t)=>{
            const wallet = option_option/* Option */.W.wrap(maybeWallet).ok().throw(t);
            const instance = await wallets_data/* EthereumWalletInstance */.Vy.tryFrom(wallet, background).then((r)=>r.throw(t));
            const signature = await instance.trySignPersonalMessage(userMessage, background).then((r)=>r.throw(t));
            await background.tryRequest({
                method: "brume_respond",
                params: [
                    new rpc_ok/* RpcOk */.r(id, signature)
                ]
            }).then((r)=>r.throw(t).throw(t));
            go("/done");
            return ok.Ok.void();
        }).then(results/* Results */.u.logAndAlert);
    }, [
        background,
        id,
        maybeWallet,
        userMessage
    ]);
    const onReject = (0,callback/* useAsyncUniqueCallback */.T)(async ()=>{
        return await result/* Result */.x.unthrow(async (t)=>{
            await background.tryRequest({
                method: "brume_respond",
                params: [
                    rpc_err/* RpcErr */.s6.rewrap(id, new err/* Err */.U(new errors_errors/* UserRejectedError */.Ai()))
                ]
            }).then((r)=>r.throw(t).throw(t));
            go("/done");
            return ok.Ok.void();
        }).then(results/* Results */.u.logAndAlert);
    }, [
        background,
        id
    ]);
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(page/* Page */.T, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "p-4 grow flex flex-col items-center justify-center",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "text-center text-xl font-medium",
                        children: "Sign message"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-full max-w-[230px] text-center text-contrast",
                        children: "Do you want to sign the following message?"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "w-full p-4 grow",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "h-full w-full p-4 border border-contrast rounded-xl whitespace-pre-wrap break-words",
                    children: userMessage
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "p-4 w-full flex items-center gap-2",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.Contrast */.z.mn, {
                        className: "grow po-md hovered-or-clicked-or-focused:scale-105 !transition",
                        onClick: onReject.run,
                        disabled: onReject.loading,
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)(XMarkIcon/* default */.Z, {
                                    className: "size-5"
                                }),
                                "No, reject it"
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.Gradient */.z.ph, {
                        className: "grow po-md hovered-or-clicked-or-focused:scale-105 !transition",
                        onClick: onApprove.run,
                        disabled: onApprove.loading,
                        colorIndex: 5,
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)(CheckIcon/* default */.Z, {
                                    className: "size-5"
                                }),
                                "Yes, approve it"
                            ]
                        })
                    })
                ]
            })
        ]
    });
}
function TypedSignPage() {
    var _walletQuery_data;
    const { url, go } = (0,path_context/* usePathContext */.td)().unwrap();
    const { searchParams } = url;
    const background = (0,background_context/* useBackgroundContext */.D_)().unwrap();
    const id = option_option/* Option */.W.wrap(searchParams.get("id")).unwrap();
    const data = option_option/* Option */.W.wrap(searchParams.get("data")).unwrap();
    const walletId = option_option/* Option */.W.wrap(searchParams.get("walletId")).unwrap();
    const walletQuery = (0,wallets_data/* useWallet */.Os)(walletId);
    const maybeWallet = (_walletQuery_data = walletQuery.data) === null || _walletQuery_data === void 0 ? void 0 : _walletQuery_data.inner;
    const onApprove = (0,callback/* useAsyncUniqueCallback */.T)(async ()=>{
        return await result/* Result */.x.unthrow(async (t)=>{
            const wallet = option_option/* Option */.W.wrap(maybeWallet).ok().throw(t);
            const typed = JSON.parse(data);
            const instance = await wallets_data/* EthereumWalletInstance */.Vy.tryFrom(wallet, background).then((r)=>r.throw(t));
            const signature = await instance.trySignEIP712HashedMessage(typed, background).then((r)=>r.throw(t));
            await background.tryRequest({
                method: "brume_respond",
                params: [
                    new rpc_ok/* RpcOk */.r(id, signature)
                ]
            }).then((r)=>r.throw(t).throw(t));
            go("/done");
            return ok.Ok.void();
        }).then(results/* Results */.u.logAndAlert);
    }, [
        background,
        id,
        maybeWallet,
        data
    ]);
    const onReject = (0,callback/* useAsyncUniqueCallback */.T)(async ()=>{
        return await result/* Result */.x.unthrow(async (t)=>{
            await background.tryRequest({
                method: "brume_respond",
                params: [
                    rpc_err/* RpcErr */.s6.rewrap(id, new err/* Err */.U(new errors_errors/* UserRejectedError */.Ai()))
                ]
            }).then((r)=>r.throw(t).throw(t));
            go("/done");
            return ok.Ok.void();
        }).then(results/* Results */.u.logAndAlert);
    }, [
        background,
        id
    ]);
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(page/* Page */.T, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "p-4 grow flex flex-col items-center justify-center",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "text-center text-xl font-medium",
                        children: "Sign message"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-full max-w-[230px] text-center text-contrast",
                        children: "Do you want to sign the following message?"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "w-full p-4 grow",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "h-full w-full p-4 border border-contrast rounded-xl whitespace-pre-wrap break-words",
                    children: JSON.stringify(JSON.parse(data))
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "p-4 w-full flex items-center gap-2",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.Contrast */.z.mn, {
                        className: "grow po-md hovered-or-clicked-or-focused:scale-105 !transition",
                        onClick: onReject.run,
                        disabled: onReject.loading,
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)(XMarkIcon/* default */.Z, {
                                    className: "size-5"
                                }),
                                "No, reject it"
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.Gradient */.z.ph, {
                        className: "grow po-md hovered-or-clicked-or-focused:scale-105 !transition",
                        onClick: onApprove.run,
                        disabled: onApprove.loading,
                        colorIndex: 5,
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)(CheckIcon/* default */.Z, {
                                    className: "size-5"
                                }),
                                "Yes, approve it"
                            ]
                        })
                    })
                ]
            })
        ]
    });
}
function WalletAndChainSelectPage() {
    var _wallets_data;
    const { url, go } = (0,path_context/* usePathContext */.td)().unwrap();
    const { searchParams } = url;
    const background = (0,background_context/* useBackgroundContext */.D_)().unwrap();
    const id = option_option/* Option */.W.wrap(searchParams.get("id")).unwrap();
    const wallets = (0,wallets_data/* useWallets */.rB)();
    const creator = (0,handles_boolean/* useBooleanHandle */.x)(false);
    const [persistent, setPersistent] = (0,react.useState)(true);
    const onPersistentChange = (0,events/* useInputChange */.Xy)((e)=>{
        setPersistent(e.currentTarget.checked);
    }, []);
    const [selecteds, setSelecteds] = (0,react.useState)([]);
    const [chain, setChain] = (0,react.useState)(1);
    const onWalletClick = (0,react.useCallback)((wallet)=>{
        const clone = new Set(selecteds);
        if (clone.has(wallet)) clone.delete(wallet);
        else clone.add(wallet);
        setSelecteds([
            ...clone
        ]);
    }, [
        selecteds
    ]);
    const onApprove = (0,callback/* useAsyncUniqueCallback */.T)(async ()=>{
        return await result/* Result */.x.unthrow(async (t)=>{
            if (selecteds.length === 0) return new err/* Err */.U(new errors/* UIError */.m("No wallet selected"));
            await background.tryRequest({
                method: "brume_respond",
                params: [
                    new rpc_ok/* RpcOk */.r(id, [
                        persistent,
                        chain,
                        selecteds
                    ])
                ]
            }).then((r)=>r.throw(t).throw(t));
            go("/done");
            return ok.Ok.void();
        }).then(results/* Results */.u.logAndAlert);
    }, [
        background,
        id,
        selecteds,
        chain,
        persistent
    ]);
    const onReject = (0,callback/* useAsyncUniqueCallback */.T)(async ()=>{
        return await result/* Result */.x.unthrow(async (t)=>{
            await background.tryRequest({
                method: "brume_respond",
                params: [
                    rpc_err/* RpcErr */.s6.rewrap(id, new err/* Err */.U(new errors_errors/* UserRejectedError */.Ai()))
                ]
            }).then((r)=>r.throw(t).throw(t));
            go("/done");
            return ok.Ok.void();
        }).then(results/* Results */.u.logAndAlert);
    }, [
        background,
        id
    ]);
    const Body = /*#__PURE__*/ (0,jsx_runtime.jsxs)(header/* PageBody */.xV, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(all_page/* SelectableWalletGrid */.Y7, {
                create: creator.enable,
                wallets: (_wallets_data = wallets.data) === null || _wallets_data === void 0 ? void 0 : _wallets_data.inner,
                ok: onWalletClick,
                selecteds: selecteds
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-4"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("label", {
                className: "flex items-center justify-between",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "",
                        children: "Keep me connected"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("input", {
                        className: "",
                        type: "checkbox",
                        checked: persistent,
                        onChange: onPersistentChange
                    })
                ]
            })
        ]
    });
    const Header = /*#__PURE__*/ (0,jsx_runtime.jsx)(header/* UserPageHeader */.To, {
        title: "Select wallets",
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.Base */.z.XY, {
            className: "size-8 hovered-or-clicked-or-focused:scale-105 !transition",
            onClick: creator.enable,
            children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(PlusIcon/* default */.Z, {
                    className: "size-5"
                })
            })
        })
    });
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(page/* Page */.T, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Dialog */.Vq, {
                opened: creator.current,
                close: creator.disable,
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(create/* WalletCreatorDialog */._, {})
            }),
            Header,
            Body,
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "p-4 w-full flex items-center gap-2",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.Contrast */.z.mn, {
                        className: "grow po-md hovered-or-clicked-or-focused:scale-105 !transition",
                        onClick: onReject.run,
                        disabled: onReject.loading,
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)(XMarkIcon/* default */.Z, {
                                    className: "size-5"
                                }),
                                "No, reject it"
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                        className: "".concat(ui_button/* Button.Base */.z.XY.className, " ").concat(ui_button/* Button.Gradient */.z.ph.className(5), " grow po-md hovered-or-clicked-or-focused:scale-105 !transition"),
                        onClick: onApprove.run,
                        disabled: onApprove.loading,
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)(CheckIcon/* default */.Z, {
                                    className: "size-5"
                                }),
                                "Yes, approve it"
                            ]
                        })
                    })
                ]
            })
        ]
    });
}
function DonePage() {
    var _useAppRequests_data;
    const { go } = (0,path_context/* usePathContext */.td)().unwrap();
    const requests = (_useAppRequests_data = (0,data/* useAppRequests */.fU)().data) === null || _useAppRequests_data === void 0 ? void 0 : _useAppRequests_data.inner;
    (0,react.useEffect)(()=>{
        if (!(requests === null || requests === void 0 ? void 0 : requests.length)) return;
        go("/requests");
    }, [
        requests
    ]);
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(page/* Page */.T, {
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "p-4 grow flex flex-col items-center justify-center",
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "text-center text-xl font-medium",
                    children: "Done"
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "w-full max-w-[230px] text-center text-contrast",
                    children: "You can now close this window or continue using it"
                })
            ]
        })
    });
}


/***/ }),

/***/ 6827:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   W: function() { return /* binding */ BigIntToHex; },
/* harmony export */   l: function() { return /* binding */ BigInts; }
/* harmony export */ });
/* harmony import */ var _swc_helpers_class_private_field_get__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7121);
/* harmony import */ var _swc_helpers_class_private_field_init__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9886);
/* harmony import */ var _swc_helpers_class_private_field_set__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5321);
/* harmony import */ var _hazae41_result__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(918);
/* harmony import */ var ethers__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9288);





var BigIntToHex;
(function(BigIntToHex) {
    function encodeOrThrow(value) {
        return "0x".concat(value.toString(16));
    }
    BigIntToHex.encodeOrThrow = encodeOrThrow;
    function decodeOrThrow(value) {
        return value.length === 2 ? 0n : BigInt(value);
    }
    BigIntToHex.decodeOrThrow = decodeOrThrow;
    function tryDecode(value) {
        return _hazae41_result__WEBPACK_IMPORTED_MODULE_0__/* .Result */ .x.runAndDoubleWrapSync(()=>decodeOrThrow(value));
    }
    BigIntToHex.tryDecode = tryDecode;
})(BigIntToHex || (BigIntToHex = {}));
var BigInts;
(function(BigInts) {
    var _a;
    var _class = /*#__PURE__*/ new WeakMap();
    class ParseError extends Error {
        static from(cause) {
            return new _a({
                cause
            });
        }
        constructor(options){
            super("Could not parse", options);
            (0,_swc_helpers_class_private_field_init__WEBPACK_IMPORTED_MODULE_1__._)(this, _class, {
                writable: true,
                value: void 0
            });
            (0,_swc_helpers_class_private_field_set__WEBPACK_IMPORTED_MODULE_2__._)(this, _class, _a);
            this.name = (0,_swc_helpers_class_private_field_get__WEBPACK_IMPORTED_MODULE_3__._)(this, _class).name;
        }
    }
    _a = ParseError;
    BigInts.ParseError = ParseError;
    function float(x) {
        let d = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 180;
        return ethers__WEBPACK_IMPORTED_MODULE_4__/* .FixedNumber */ .x.fromValue(x, d).round(3).toUnsafeFloat();
    }
    BigInts.float = float;
    function tryParse(text) {
        return _hazae41_result__WEBPACK_IMPORTED_MODULE_0__/* .Result */ .x.runAndDoubleWrapSync(()=>parseOrThrow(text));
    }
    BigInts.tryParse = tryParse;
    function parseOrThrow(text) {
        if (text.trim().length === 0) throw new ParseError();
        return BigInt(text);
    }
    BigInts.parseOrThrow = parseOrThrow;
    function tens(value) {
        return BigInt("1".concat("0".repeat(value)));
    }
    BigInts.tens = tens;
})(BigInts || (BigInts = {}));


/***/ }),

/***/ 1905:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   F: function() { return /* binding */ useCopy; }
/* harmony export */ });
/* harmony import */ var _libs_react_handles_boolean__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8544);
/* harmony import */ var _hazae41_result__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(918);
/* harmony import */ var _react_callback__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5379);



function useCopy(text) {
    const { current, enable, disable } = (0,_libs_react_handles_boolean__WEBPACK_IMPORTED_MODULE_0__/* .useBooleanHandle */ .x)(false);
    const { run } = (0,_react_callback__WEBPACK_IMPORTED_MODULE_1__/* .useAsyncUniqueCallback */ .T)(async ()=>{
        if (!text) return;
        await _hazae41_result__WEBPACK_IMPORTED_MODULE_2__/* .Result */ .x.runAndWrap(async ()=>{
            await navigator.clipboard.writeText(text);
        }).then((r)=>r.ignore());
        enable();
        setTimeout(()=>{
            disable();
        }, 600);
    }, [
        text
    ]);
    return {
        current,
        run
    };
}


/***/ }),

/***/ 9183:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DH: function() { return /* binding */ chainByChainId; },
/* harmony export */   ne: function() { return /* binding */ pairByAddress; },
/* harmony export */   q2: function() { return /* binding */ tokenByAddress; }
/* harmony export */ });
/* unused harmony exports tokenById, pairByName */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);

const chainByChainId = {
    1: {
        name: "Ethereum",
        chainId: 1,
        urls: [
            "wss://ethereum.publicnode.com",
            "wss://mainnet.gateway.tenderly.co"
        ],
        etherscan: "https://etherscan.io",
        token: {
            uuid: "664000af-5c47-4b6e-ab3e-c0c130e23b3c",
            type: "native",
            name: "ETH",
            chainId: 1,
            symbol: "ETH",
            decimals: 18,
            pairs: [
                "0x0d4a11d5eeaac28ec3f61d100daf4d40471f1852"
            ]
        },
        icon () {
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "h-6 w-6 bg-gray-900 rounded-full flex items-center justify-center",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                    className: "w-4 h-4 bg-white",
                    style: {
                        mask: "url(/assets/chains/ethereum.svg) no-repeat center / contain",
                        WebkitMask: "url(/assets/chains/ethereum.svg) no-repeat center / contain"
                    }
                })
            });
        }
    },
    5: {
        name: "Goerli (testnet)",
        chainId: 5,
        urls: [
            "wss://ethereum-goerli.publicnode.com"
        ],
        etherscan: "https://goerli.etherscan.io",
        token: {
            uuid: "664001af-5c47-4b6e-ab3e-c0c130e23b3c",
            type: "native",
            name: "ETH",
            chainId: 5,
            symbol: "ETH",
            decimals: 18
        },
        icon () {
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "h-6 w-6 bg-gray-900 rounded-full flex items-center justify-center text-xs",
                children: "G\xf6"
            });
        }
    },
    10: {
        name: "Optimism",
        chainId: 10,
        urls: [
            "wss://optimism.publicnode.com"
        ],
        etherscan: "https://optimistic.etherscan.io",
        token: {
            uuid: "664002af-5c47-4b6e-ab3e-c0c130e23b3c",
            type: "native",
            name: "ETH",
            chainId: 10,
            symbol: "ETH",
            decimals: 18,
            pairs: [
                "0x0d4a11d5eeaac28ec3f61d100daf4d40471f1852"
            ]
        },
        icon () {
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("img", {
                className: "w-6 h-6",
                src: "/assets/chains/optimism.svg",
                alt: "Optimism"
            });
        }
    },
    56: {
        name: "Binance",
        chainId: 56,
        urls: [
            "wss://bsc.publicnode.com"
        ],
        etherscan: "https://bscscan.com",
        token: {
            uuid: "664003af-5c47-4b6e-ab3e-c0c130e23b3c",
            type: "native",
            name: "BNB",
            chainId: 56,
            symbol: "BNB",
            decimals: 18,
            pairs: [
                "0x16b9a82891338f9ba80e2d6970fdda79d1eb0dae"
            ]
        },
        icon () {
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("img", {
                className: "w-6 h-6",
                src: "/assets/chains/binance.svg",
                alt: "Binance"
            });
        }
    },
    61: {
        name: "Ethereum Classic",
        chainId: 61,
        urls: [
            "https://etc.rivet.link"
        ],
        etherscan: "https://blockscout.com/etc/mainnet/",
        token: {
            uuid: "664004af-5c47-4b6e-ab3e-c0c130e23b3c",
            type: "native",
            name: "ETC",
            chainId: 61,
            symbol: "ETC",
            decimals: 18,
            pairs: [
                "0xdb8721b7a04c3e592264bf58558526b16b15e757"
            ]
        },
        icon () {
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "h-6 w-6 bg-green-500 rounded-full flex items-center justify-center",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                    className: "w-4 h-4 bg-white",
                    style: {
                        mask: "url(/assets/chains/classic.svg) no-repeat center / contain",
                        WebkitMask: "url(/assets/chains/classic.svg) no-repeat center / contain"
                    }
                })
            });
        }
    },
    100: {
        name: "Gnosis",
        chainId: 100,
        urls: [
            "wss://gnosis.publicnode.com"
        ],
        etherscan: "https://gnosisscan.io",
        token: {
            uuid: "664005af-5c47-4b6e-ab3e-c0c130e23b3c",
            type: "native",
            name: "xDAI",
            chainId: 100,
            symbol: "xDAI",
            decimals: 18,
            pairs: []
        },
        icon () {
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "h-6 w-6 bg-emerald-600 rounded-full flex items-center justify-center",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                    className: "w-4 h-4 bg-white",
                    style: {
                        mask: "url(/assets/chains/gnosis.svg) no-repeat center / contain",
                        WebkitMask: "url(/assets/chains/gnosis.svg) no-repeat center / contain"
                    }
                })
            });
        }
    },
    137: {
        name: "Polygon Bor",
        chainId: 137,
        urls: [
            "wss://polygon-bor.publicnode.com"
        ],
        etherscan: "https://polygonscan.com",
        token: {
            uuid: "664006af-5c47-4b6e-ab3e-c0c130e23b3c",
            type: "native",
            name: "MATIC",
            chainId: 137,
            symbol: "MATIC",
            decimals: 18,
            pairs: [
                "0x819f3450dA6f110BA6Ea52195B3beaFa246062dE",
                "0x0d4a11d5eeaac28ec3f61d100daf4d40471f1852"
            ]
        },
        icon () {
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "h-6 w-6 bg-purple-500 rounded-full flex items-center justify-center",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                    className: "w-4 h-4 bg-white",
                    style: {
                        mask: "url(/assets/chains/polygon.svg) no-repeat center / contain",
                        WebkitMask: "url(/assets/chains/polygon.svg) no-repeat center / contain"
                    }
                })
            });
        }
    },
    324: {
        name: "zkSync",
        chainId: 324,
        urls: [
            "https://1rpc.io/zksync2-era"
        ],
        etherscan: "https://explorer.zksync.io/",
        token: {
            uuid: "664007af-5c47-4b6e-ab3e-c0c130e23b3c",
            type: "native",
            name: "ETH",
            chainId: 324,
            symbol: "ETH",
            decimals: 18,
            pairs: [
                "0x0d4a11d5eeaac28ec3f61d100daf4d40471f1852"
            ]
        },
        icon () {
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "h-6 w-6 bg-violet-500 rounded-full flex items-center justify-center",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                    className: "w-4 h-4 bg-white",
                    style: {
                        mask: "url(/assets/chains/zksync.png) no-repeat center / contain",
                        WebkitMask: "url(/assets/chains/zksync.png) no-repeat center / contain"
                    }
                })
            });
        }
    },
    7700: {
        name: "Canto",
        chainId: 7700,
        urls: [
            "https://canto.gravitychain.io"
        ],
        etherscan: "https://cantoscan.com/",
        token: {
            uuid: "c0098941-1a08-4db1-9498-03a4cbceb672",
            type: "native",
            name: "Canto",
            chainId: 7700,
            symbol: "CANTO",
            decimals: 18
        },
        icon () {
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "h-6 w-6 bg-[#111111] rounded-full flex items-center justify-center",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("img", {
                    className: "w-4 h-4",
                    src: "/assets/chains/canto.png",
                    alt: "Canto"
                })
            });
        }
    },
    8453: {
        name: "Base",
        chainId: 8453,
        urls: [
            "wss://base.publicnode.com"
        ],
        etherscan: "https://basescan.org",
        token: {
            uuid: "664008af-5c47-4b6e-ab3e-c0c130e23b3c",
            type: "native",
            name: "ETH",
            chainId: 8453,
            symbol: "ETH",
            decimals: 18,
            pairs: [
                "0x0d4a11d5eeaac28ec3f61d100daf4d40471f1852"
            ]
        },
        icon () {
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "h-6 w-6 bg-blue-500 rounded-full flex items-center justify-center",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                    className: "w-4 h-4 bg-white",
                    style: {
                        mask: "url(/assets/chains/base.svg) no-repeat center / contain",
                        WebkitMask: "url(/assets/chains/base.svg) no-repeat center / contain"
                    }
                })
            });
        }
    },
    42161: {
        name: "Arbitrum One",
        chainId: 42161,
        urls: [
            "wss://arbitrum-one.publicnode.com"
        ],
        etherscan: "https://arbiscan.io",
        token: {
            uuid: "664009af-5c47-4b6e-ab3e-c0c130e23b3c",
            type: "native",
            name: "ETH",
            chainId: 42161,
            symbol: "ETH",
            decimals: 18,
            pairs: [
                "0x0d4a11d5eeaac28ec3f61d100daf4d40471f1852"
            ]
        },
        icon () {
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "h-6 w-6 bg-blue-500 rounded-full flex items-center justify-center",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                    className: "w-4 h-4 bg-white",
                    style: {
                        mask: "url(/assets/chains/arbitrum.png) no-repeat center / contain",
                        WebkitMask: "url(/assets/chains/arbitrum.png) no-repeat center / contain"
                    }
                })
            });
        }
    },
    42220: {
        name: "Celo",
        chainId: 42220,
        urls: [
            "https://1rpc.io/celo"
        ],
        etherscan: "https://celoscan.io",
        token: {
            uuid: "664010af-5c47-4b6e-ab3e-c0c130e23b3c",
            type: "native",
            name: "CELO",
            chainId: 42220,
            symbol: "CELO",
            decimals: 18,
            pairs: [
                "0xf5b1bc6c9c180b64f5711567b1d6a51a350f8422"
            ]
        },
        icon () {
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("img", {
                className: "w-6 h-6",
                src: "/assets/chains/celo.svg",
                alt: "Celo"
            });
        }
    },
    43114: {
        name: "Avalanche C-Chain",
        chainId: 43114,
        urls: [
            "wss://avalanche-c-chain.publicnode.com"
        ],
        etherscan: "https://snowtrace.io",
        token: {
            uuid: "664011af-5c47-4b6e-ab3e-c0c130e23b3c",
            type: "native",
            name: "ETH",
            chainId: 43114,
            symbol: "ETH",
            decimals: 18,
            pairs: [
                "0x0d4a11d5eeaac28ec3f61d100daf4d40471f1852"
            ]
        },
        icon () {
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("img", {
                className: "w-6 h-6",
                src: "/assets/chains/avalanche.png",
                alt: "Avalanche"
            });
        }
    },
    59144: {
        name: "Linea",
        chainId: 59144,
        urls: [
            "https://rpc.linea.build"
        ],
        etherscan: "https://lineascan.build",
        token: {
            uuid: "664012af-5c47-4b6e-ab3e-c0c130e23b3c",
            type: "native",
            name: "ETH",
            chainId: 59144,
            symbol: "ETH",
            decimals: 18,
            pairs: [
                "0x0d4a11d5eeaac28ec3f61d100daf4d40471f1852"
            ]
        },
        icon () {
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("img", {
                className: "w-6 h-6 rounded-full",
                src: "/assets/chains/linea.jpg",
                alt: "Linea"
            });
        }
    },
    11155111: {
        name: "Sepolia (testnet)",
        chainId: 11155111,
        urls: [
            "wss://ethereum-sepolia.publicnode.com"
        ],
        etherscan: "https://sepolia.etherscan.io",
        token: {
            uuid: "664013af-5c47-4b6e-ab3e-c0c130e23b3c",
            type: "native",
            name: "ETH",
            chainId: 11155111,
            symbol: "ETH",
            decimals: 18
        },
        icon () {
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "h-6 w-6 bg-gray-900 rounded-full flex items-center justify-center text-xs",
                children: "Se"
            });
        }
    }
};
const tokenByAddress = {
    "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2": {
        uuid: "7b8dab00-e96b-41aa-b9d8-0ba39d2f96a6",
        type: "contract",
        name: "Wrapped ETH",
        chainId: 1,
        symbol: "WETH",
        decimals: 18,
        address: "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2",
        pairs: [
            "0x0d4a11d5eeaac28ec3f61d100daf4d40471f1852"
        ]
    },
    "0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599": {
        uuid: "7b8dab01-e96b-41aa-b9d8-0ba39d2f96a6",
        type: "contract",
        name: "Wrapped BTC",
        chainId: 1,
        symbol: "WBTC",
        decimals: 8,
        address: "0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599",
        pairs: [
            "0xbb2b8038a1640196fbe3e38816f3e67cba72d940",
            "0x0d4a11d5eeaac28ec3f61d100daf4d40471f1852"
        ]
    },
    "0x6B175474E89094C44Da98b954EedeAC495271d0F": {
        uuid: "7b8dab02-e96b-41aa-b9d8-0ba39d2f96a6",
        type: "contract",
        name: "DAI",
        chainId: 1,
        symbol: "DAI",
        decimals: 18,
        address: "0x6B175474E89094C44Da98b954EedeAC495271d0F",
        pairs: []
    },
    "0xdAC17F958D2ee523a2206206994597C13D831ec7": {
        uuid: "7b8dab03-e96b-41aa-b9d8-0ba39d2f96a6",
        type: "contract",
        name: "Tether USD",
        chainId: 1,
        symbol: "USDT",
        decimals: 6,
        address: "0xdAC17F958D2ee523a2206206994597C13D831ec7",
        pairs: []
    },
    "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48": {
        uuid: "7b8dab04-e96b-41aa-b9d8-0ba39d2f96a6",
        type: "contract",
        name: "USD Coin",
        chainId: 1,
        symbol: "USDC",
        decimals: 6,
        address: "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48",
        pairs: []
    },
    "0x7D1AfA7B718fb893dB30A3aBc0Cfc608AaCfeBB0": {
        uuid: "7b8dab05-e96b-41aa-b9d8-0ba39d2f96a6",
        type: "contract",
        name: "MATIC",
        chainId: 1,
        symbol: "MATIC",
        decimals: 18,
        address: "0x7D1AfA7B718fb893dB30A3aBc0Cfc608AaCfeBB0",
        pairs: [
            "0x819f3450dA6f110BA6Ea52195B3beaFa246062dE",
            "0x0d4a11d5eeaac28ec3f61d100daf4d40471f1852"
        ]
    },
    "0xae7ab96520DE3A18E5e111B5EaAb095312D7fE84": {
        uuid: "7b8dab06-e96b-41aa-b9d8-0ba39d2f96a6",
        type: "contract",
        name: "stETH",
        chainId: 1,
        symbol: "stETH",
        decimals: 18,
        address: "0xae7ab96520DE3A18E5e111B5EaAb095312D7fE84",
        pairs: [
            "0x0d4a11d5eeaac28ec3f61d100daf4d40471f1852"
        ]
    },
    "0x94b008aA00579c1307B0EF2c499aD98a8ce58e58": {
        uuid: "7b8dab07-e96b-41aa-b9d8-0ba39d2f96a6",
        type: "contract",
        name: "Tether USD",
        chainId: 10,
        symbol: "USDT",
        decimals: 6,
        address: "0x94b008aA00579c1307B0EF2c499aD98a8ce58e58",
        pairs: []
    },
    "0x7F5c764cBc14f9669B88837ca1490cCa17c31607": {
        uuid: "7b8dab08-e96b-41aa-b9d8-0ba39d2f96a6",
        type: "contract",
        name: "USD Coin",
        chainId: 10,
        symbol: "USDC",
        decimals: 6,
        address: "0x7F5c764cBc14f9669B88837ca1490cCa17c31607",
        pairs: []
    },
    "0xDA10009cBd5D07dd0CeCc66161FC93D7c9000da1": {
        uuid: "7b8dab09-e96b-41aa-b9d8-0ba39d2f96a6",
        type: "contract",
        name: "DAI",
        chainId: 10,
        symbol: "DAI",
        decimals: 18,
        address: "0xDA10009cBd5D07dd0CeCc66161FC93D7c9000da1",
        pairs: []
    },
    "0x68f180fcCe6836688e9084f035309E29Bf0A2095": {
        uuid: "7b8dab10-e96b-41aa-b9d8-0ba39d2f96a6",
        type: "contract",
        name: "Wrapped BTC",
        chainId: 10,
        symbol: "WBTC",
        decimals: 8,
        address: "0x68f180fcCe6836688e9084f035309E29Bf0A2095",
        pairs: [
            "0xbb2b8038a1640196fbe3e38816f3e67cba72d940",
            "0x0d4a11d5eeaac28ec3f61d100daf4d40471f1852"
        ]
    },
    "0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c": {
        uuid: "7b8dab11-e96b-41aa-b9d8-0ba39d2f96a6",
        type: "contract",
        name: "Wrapped BNB",
        chainId: 56,
        symbol: "WBNB",
        decimals: 18,
        address: "0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c",
        pairs: [
            "0x16b9a82891338f9ba80e2d6970fdda79d1eb0dae"
        ]
    },
    "0x55d398326f99059fF775485246999027B3197955": {
        uuid: "7b8dab12-e96b-41aa-b9d8-0ba39d2f96a6",
        type: "contract",
        name: "Tether USD",
        chainId: 56,
        symbol: "USDT",
        decimals: 18,
        address: "0x55d398326f99059fF775485246999027B3197955",
        pairs: []
    },
    "0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56": {
        uuid: "7b8dab13-e96b-41aa-b9d8-0ba39d2f96a6",
        type: "contract",
        name: "BUSD",
        chainId: 56,
        symbol: "BUSD",
        decimals: 18,
        address: "0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56",
        pairs: []
    },
    "0x3d6545b08693dae087e957cb1180ee38b9e3c25e": {
        uuid: "7b8dab14-e96b-41aa-b9d8-0ba39d2f96a6",
        type: "contract",
        name: "ETC",
        chainId: 56,
        symbol: "ETC",
        decimals: 18,
        address: "0x3d6545b08693dae087e957cb1180ee38b9e3c25e",
        pairs: [
            "0xdb8721b7a04c3e592264bf58558526b16b15e757"
        ]
    },
    "0xc2132D05D31c914a87C6611C10748AEb04B58e8F": {
        uuid: "7b8dab15-e96b-41aa-b9d8-0ba39d2f96a6",
        type: "contract",
        name: "Tether USD",
        chainId: 137,
        symbol: "USDT",
        decimals: 6,
        address: "0xc2132D05D31c914a87C6611C10748AEb04B58e8F",
        pairs: []
    },
    "0x471EcE3750Da237f93B8E339c536989b8978a438": {
        uuid: "7b8dab16-e96b-41aa-b9d8-0ba39d2f96a6",
        type: "contract",
        name: "Wrapped CELO",
        chainId: 42220,
        symbol: "WCELO",
        decimals: 18,
        address: "0x471EcE3750Da237f93B8E339c536989b8978a438",
        pairs: [
            "0xf5b1bc6c9c180b64f5711567b1d6a51a350f8422"
        ]
    },
    "0x64dEFa3544c695db8c535D289d843a189aa26b98": {
        uuid: "7b8dab17-e96b-41aa-b9d8-0ba39d2f96a6",
        type: "contract",
        name: "mCUSD",
        chainId: 42220,
        symbol: "mCUSD",
        decimals: 18,
        address: "0x64dEFa3544c695db8c535D289d843a189aa26b98",
        pairs: []
    }
};
const tokenById = {
    WETH_ON_ETHEREUM: "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2",
    WBTC_ON_ETHEREUM: "0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599",
    DAI_ON_ETHEREUM: "0x6B175474E89094C44Da98b954EedeAC495271d0F",
    USDT_ON_ETHEREUM: "0xdAC17F958D2ee523a2206206994597C13D831ec7",
    USDC_ON_ETHEREUM: "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48",
    MATIC_ON_ETHEREUM: "0x7D1AfA7B718fb893dB30A3aBc0Cfc608AaCfeBB0",
    STETH_ON_ETHEREUM: "0xae7ab96520DE3A18E5e111B5EaAb095312D7fE84",
    WBNB_ON_BINANCE: "0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c",
    USDT_ON_BINANCE: "0x55d398326f99059fF775485246999027B3197955",
    BUSD_ON_BINANCE: "0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56",
    ETC_ON_BINANCE: "0x3d6545b08693dae087e957cb1180ee38b9e3c25e",
    USDT_ON_OPTIMISM: "0x94b008aA00579c1307B0EF2c499aD98a8ce58e58",
    USDC_ON_OPTIMISM: "0x7F5c764cBc14f9669B88837ca1490cCa17c31607",
    DAI_ON_OPTIMISM: "0xDA10009cBd5D07dd0CeCc66161FC93D7c9000da1",
    WBTC_ON_OPTIMISM: "0x68f180fcCe6836688e9084f035309E29Bf0A2095",
    USDT_ON_POLYGON: "0xc2132D05D31c914a87C6611C10748AEb04B58e8F",
    CELO_ON_CELO: "0x471EcE3750Da237f93B8E339c536989b8978a438",
    MSUSD_ON_CELO: "0x64dEFa3544c695db8c535D289d843a189aa26b98"
};
const pairByAddress = {
    "0x0d4a11d5eeaac28ec3f61d100daf4d40471f1852": {
        chainId: 1,
        name: "WETH_USDT",
        address: "0x0d4a11d5eeaac28ec3f61d100daf4d40471f1852",
        token0: tokenById.WETH_ON_ETHEREUM,
        token1: tokenById.USDT_ON_ETHEREUM
    },
    "0xbb2b8038a1640196fbe3e38816f3e67cba72d940": {
        chainId: 1,
        name: "WBTC_WETH",
        address: "0xbb2b8038a1640196fbe3e38816f3e67cba72d940",
        token0: tokenById.WBTC_ON_ETHEREUM,
        token1: tokenById.WETH_ON_ETHEREUM
    },
    "0x819f3450dA6f110BA6Ea52195B3beaFa246062dE": {
        chainId: 1,
        name: "MATIC_WETH",
        address: "0x819f3450dA6f110BA6Ea52195B3beaFa246062dE",
        token0: tokenById.MATIC_ON_ETHEREUM,
        token1: tokenById.WETH_ON_ETHEREUM
    },
    "0x16b9a82891338f9ba80e2d6970fdda79d1eb0dae": {
        chainId: 56,
        name: "USDT_WBNB",
        address: "0x16b9a82891338f9ba80e2d6970fdda79d1eb0dae",
        token0: tokenById.USDT_ON_BINANCE,
        token1: tokenById.WBNB_ON_BINANCE,
        reversed: true
    },
    "0xdb8721b7a04c3e592264bf58558526b16b15e757": {
        chainId: 56,
        name: "ETC_BUSD",
        address: "0xdb8721b7a04c3e592264bf58558526b16b15e757",
        token0: "0x3d6545b08693dae087e957cb1180ee38b9e3c25e",
        token1: "0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56"
    },
    "0xf5b1bc6c9c180b64f5711567b1d6a51a350f8422": {
        chainId: 42220,
        name: "CELO_MCUSD",
        address: "0xf5b1bc6c9c180b64f5711567b1d6a51a350f8422",
        token0: "0x471EcE3750Da237f93B8E339c536989b8978a438",
        token1: "0x64dEFa3544c695db8c535D289d843a189aa26b98"
    }
};
const pairByName = {
    WETH_USDT: "0x0d4a11d5eeaac28ec3f61d100daf4d40471f1852",
    WBTC_WETH: "0xbb2b8038a1640196fbe3e38816f3e67cba72d940",
    MATIC_WETH: "0x819f3450dA6f110BA6Ea52195B3beaFa246062dE",
    USDT_WBNB: "0x16b9a82891338f9ba80e2d6970fdda79d1eb0dae",
    ETC_BUSD: "0xdb8721b7a04c3e592264bf58558526b16b15e757",
    CELO_MCUSD: "0xf5b1bc6c9c180b64f5711567b1d6a51a350f8422"
};


/***/ }),

/***/ 6919:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  P: function() { return /* reexport */ mods_namespaceObject; }
});

// NAMESPACE OBJECT: ./src/libs/ledger/mods/ethereum/index.ts
var mods_ethereum_namespaceObject = {};
__webpack_require__.r(mods_ethereum_namespaceObject);
__webpack_require__.d(mods_ethereum_namespaceObject, {
  getAddressOrThrow: function() { return getAddressOrThrow; },
  getAppConfigOrThrow: function() { return getAppConfigOrThrow; },
  readLegacyUnprotectedOrThrow: function() { return readLegacyUnprotectedOrThrow; },
  signEIP712HashedMessageOrThrow: function() { return signEIP712HashedMessageOrThrow; },
  signPersonalMessageOrThrow: function() { return signPersonalMessageOrThrow; },
  signTransactionOrThrow: function() { return signTransactionOrThrow; },
  tryGetAddress: function() { return tryGetAddress; },
  tryGetAppConfig: function() { return tryGetAppConfig; },
  trySignEIP712HashedMessage: function() { return trySignEIP712HashedMessage; },
  trySignPersonalMessage: function() { return trySignPersonalMessage; },
  trySignTransaction: function() { return trySignTransaction; },
  tryVerifyAndGetAddress: function() { return tryVerifyAndGetAddress; },
  verifyAndGetAddressOrThrow: function() { return verifyAndGetAddressOrThrow; }
});

// NAMESPACE OBJECT: ./src/libs/ledger/mods/usb/index.ts
var mods_usb_namespaceObject = {};
__webpack_require__.r(mods_usb_namespaceObject);
__webpack_require__.d(mods_usb_namespaceObject, {
  DeviceConfigError: function() { return DeviceConfigError; },
  DeviceInterfaceClaimError: function() { return DeviceInterfaceClaimError; },
  DeviceInterfaceNotFoundError: function() { return DeviceInterfaceNotFoundError; },
  DeviceNotFoundError: function() { return DeviceNotFoundError; },
  DeviceOpenError: function() { return DeviceOpenError; },
  DeviceResetError: function() { return DeviceResetError; },
  DeviceTransferInError: function() { return DeviceTransferInError; },
  DeviceTransferOutError: function() { return DeviceTransferOutError; },
  LedgerUSBDevice: function() { return LedgerUSBDevice; },
  PACKET_SIZE: function() { return PACKET_SIZE; },
  VENDOR_ID: function() { return VENDOR_ID; },
  tryConnect: function() { return tryConnect; },
  tryRequest: function() { return tryRequest; }
});

// NAMESPACE OBJECT: ./src/libs/ledger/mods/index.ts
var mods_namespaceObject = {};
__webpack_require__.r(mods_namespaceObject);
__webpack_require__.d(mods_namespaceObject, {
  kJ: function() { return mods_ethereum_namespaceObject; },
  vB: function() { return mods_usb_namespaceObject; }
});

// EXTERNAL MODULE: ./node_modules/@hazae41/base16/dist/esm/src/mods/base16/adapter.mjs
var adapter = __webpack_require__(2248);
// EXTERNAL MODULE: ./node_modules/@hazae41/binary/dist/esm/mods/binary/empty.mjs
var empty = __webpack_require__(1543);
// EXTERNAL MODULE: ./node_modules/@hazae41/binary/dist/esm/mods/binary/writable.mjs
var writable = __webpack_require__(2008);
// EXTERNAL MODULE: ./node_modules/@hazae41/binary/dist/esm/mods/binary/opaque.mjs
var opaque = __webpack_require__(468);
// EXTERNAL MODULE: ./node_modules/@hazae41/binary/dist/esm/mods/binary/readable.mjs
var readable = __webpack_require__(1916);
// EXTERNAL MODULE: ./node_modules/@hazae41/bytes/dist/esm/mods/bytes/bytes.mjs + 3 modules
var bytes_bytes = __webpack_require__(1694);
// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/rlp/rlp.mjs
var rlp_rlp = __webpack_require__(4864);
// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/rlp/index.mjs
var mods_rlp = __webpack_require__(6931);
// EXTERNAL MODULE: ./node_modules/@hazae41/cursor/dist/esm/mods/cursor/cursor.mjs + 5 modules
var cursor_cursor = __webpack_require__(6677);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/result.mjs
var result = __webpack_require__(918);
;// CONCATENATED MODULE: ./src/libs/ledger/mods/common/binary/paths.ts
class Paths {
    static from(path) {
        const paths = new Array();
        for (const subpath of path.split("/")){
            const value = subpath.endsWith("'") ? parseInt(subpath, 10) + 2147483648 : parseInt(subpath, 10);
            paths.push(value);
        }
        return new Paths(paths);
    }
    sizeOrThrow() {
        return 1 + this.paths.length * 4;
    }
    writeOrThrow(cursor) {
        cursor.writeUint8OrThrow(this.paths.length);
        for (const path of this.paths)cursor.writeUint32OrThrow(path);
        return;
    }
    constructor(paths){
        this.paths = paths;
    }
}

;// CONCATENATED MODULE: ./src/libs/ledger/mods/ethereum/ethereum.ts
var __addDisposableResource = undefined && undefined.__addDisposableResource || function(env, value, async) {
    if (value !== null && value !== void 0) {
        if (typeof value !== "object" && typeof value !== "function") throw new TypeError("Object expected.");
        var dispose;
        if (async) {
            if (!Symbol.asyncDispose) throw new TypeError("Symbol.asyncDispose is not defined.");
            dispose = value[Symbol.asyncDispose];
        }
        if (dispose === void 0) {
            if (!Symbol.dispose) throw new TypeError("Symbol.dispose is not defined.");
            dispose = value[Symbol.dispose];
        }
        if (typeof dispose !== "function") throw new TypeError("Object not disposable.");
        env.stack.push({
            value: value,
            dispose: dispose,
            async: async
        });
    } else if (async) {
        env.stack.push({
            async: true
        });
    }
    return value;
};
var __disposeResources = undefined && undefined.__disposeResources || function(SuppressedError1) {
    return function(env) {
        function fail(e) {
            env.error = env.hasError ? new SuppressedError1(e, env.error, "An error was suppressed during disposal.") : e;
            env.hasError = true;
        }
        function next() {
            while(env.stack.length){
                var rec = env.stack.pop();
                try {
                    var result = rec.dispose && rec.dispose.call(rec.value);
                    if (rec.async) return Promise.resolve(result).then(next, function(e) {
                        fail(e);
                        return next();
                    });
                } catch (e) {
                    fail(e);
                }
            }
            if (env.hasError) throw env.error;
        }
        return next();
    };
}(typeof SuppressedError === "function" ? SuppressedError : function(error, suppressed, message) {
    var e = new Error(message);
    return e.name = "SuppressedError", e.error = error, e.suppressed = suppressed, e;
});







async function tryGetAppConfig(device) {
    return await result/* Result */.x.runAndDoubleWrap(()=>getAppConfigOrThrow(device));
}
async function getAppConfigOrThrow(device) {
    const request = {
        cla: 0xe0,
        ins: 0x06,
        p1: 0x00,
        p2: 0x00,
        fragment: new empty/* Empty */.H()
    };
    const response = await device.requestOrThrow(request).then((r)=>r.unwrap().bytes);
    const arbitraryDataEnabled = Boolean(response[0] & 0x01);
    const erc20ProvisioningNecessary = Boolean(response[0] & 0x02);
    const starkEnabled = Boolean(response[0] & 0x04);
    const starkv2Supported = Boolean(response[0] & 0x08);
    const version = "".concat(response[1], ".").concat(response[2], ".").concat(response[3]);
    return {
        arbitraryDataEnabled,
        erc20ProvisioningNecessary,
        starkEnabled,
        starkv2Supported,
        version
    };
}
/**
 * Just get the address
 * @param device
 * @param path
 * @returns
 */ async function tryGetAddress(device, path) {
    return await result/* Result */.x.runAndDoubleWrap(()=>getAddressOrThrow(device, path));
}
/**
 * Just get the address
 * @param device
 * @param path
 * @returns
 */ async function getAddressOrThrow(device, path) {
    const paths = Paths.from(path);
    const bytes = writable/* Writable */.c.writeToBytesOrThrow(paths);
    const request = {
        cla: 0xe0,
        ins: 0x02,
        p1: 0x00,
        p2: 0x01,
        fragment: new opaque/* Opaque */.lD(bytes)
    };
    const response = await device.requestOrThrow(request).then((r)=>r.unwrap().bytes);
    const cursor = new cursor_cursor/* Cursor */.C(response);
    const uncompressedPublicKeyLength = cursor.readUint8OrThrow();
    const uncompressedPublicKey = cursor.readAndCopyOrThrow(uncompressedPublicKeyLength);
    const addressLength = cursor.readUint8OrThrow();
    const address = "0x".concat(bytes_bytes/* Bytes */.J.toAscii(cursor.readOrThrow(addressLength)));
    const chaincode = cursor.readAndCopyOrThrow(32);
    return {
        uncompressedPublicKey,
        address,
        chaincode
    };
}
/**
 * Ask the user to verify the address and get it
 * @param device
 * @param path
 * @returns
 */ async function tryVerifyAndGetAddress(device, path) {
    return await result/* Result */.x.runAndDoubleWrap(()=>verifyAndGetAddressOrThrow(device, path));
}
/**
 * Ask the user to verify the address and get it
 * @param device
 * @param path
 * @returns
 */ async function verifyAndGetAddressOrThrow(device, path) {
    const paths = Paths.from(path);
    const bytes = writable/* Writable */.c.writeToBytesOrThrow(paths);
    const request = {
        cla: 0xe0,
        ins: 0x02,
        p1: 0x01,
        p2: 0x01,
        fragment: new opaque/* Opaque */.lD(bytes)
    };
    const response = await device.requestOrThrow(request).then((r)=>r.unwrap().bytes);
    const cursor = new cursor_cursor/* Cursor */.C(response);
    const uncompressedPublicKeyLength = cursor.readUint8OrThrow();
    const uncompressedPublicKey = cursor.readAndCopyOrThrow(uncompressedPublicKeyLength);
    const addressLength = cursor.readUint8OrThrow();
    const address = "0x".concat(bytes_bytes/* Bytes */.J.toAscii(cursor.readOrThrow(addressLength)));
    const chaincode = cursor.readAndCopyOrThrow(32);
    return {
        uncompressedPublicKey,
        address,
        chaincode
    };
}
async function trySignPersonalMessage(device, path, message) {
    return await result/* Result */.x.runAndDoubleWrap(()=>signPersonalMessageOrThrow(device, path, message));
}
async function signPersonalMessageOrThrow(device, path, message) {
    const paths = Paths.from(path);
    const reader = new cursor_cursor/* Cursor */.C(message);
    let response;
    {
        const head = paths.sizeOrThrow() + 4;
        const body = Math.min(150 - head, reader.remaining);
        const chunk = reader.readOrThrow(body);
        const writer = new cursor_cursor/* Cursor */.C(new Uint8Array(head + body));
        paths.writeOrThrow(writer);
        writer.writeUint32OrThrow(message.length);
        writer.writeOrThrow(chunk);
        const request = {
            cla: 0xe0,
            ins: 0x08,
            p1: 0x00,
            p2: 0x00,
            fragment: new opaque/* Opaque */.lD(writer.bytes)
        };
        response = await device.requestOrThrow(request).then((r)=>r.unwrap().bytes);
    }
    while(reader.remaining){
        const body = Math.min(150, reader.remaining);
        const chunk = reader.readOrThrow(body);
        const request = {
            cla: 0xe0,
            ins: 0x08,
            p1: 0x80,
            p2: 0x00,
            fragment: new opaque/* Opaque */.lD(chunk)
        };
        response = await device.requestOrThrow(request).then((r)=>r.unwrap().bytes);
    }
    const cursor = new cursor_cursor/* Cursor */.C(response);
    const v = cursor.readUint8OrThrow() - 27;
    const r = cursor.readAndCopyOrThrow(32);
    const s = cursor.readAndCopyOrThrow(32);
    return {
        v,
        r,
        s
    };
}
/**
 * Get the unprotected part of a legacy replay-protected transaction
 * @param bytes
 * @returns
 */ function readLegacyUnprotectedOrThrow(bytes) {
    /**
     * This is not a legacy transaction (EIP-2718)
     */ if (bytes[0] < 0x80) return undefined;
    /**
     * Decode the bytes as RLP
     */ const rlp = rlp_rlp/* toPrimitive */.vb(readable/* Readable */.$.readFromBytesOrThrow(mods_rlp, bytes));
    if (!Array.isArray(rlp)) throw new Error("Wrong RLP type for transaction");
    /**
     * This is not a replay-protected transaction (EIP-155)
     */ if (rlp.length !== 9) return undefined;
    /**
     * Take only the first 6 parameters instead of the 9
     */ const [nonce, gasprice, startgas, to, value, data] = rlp;
    /**
     * Encode them as RLP
     */ return writable/* Writable */.c.writeToBytesOrThrow(rlp_rlp/* fromPrimitive */.Zl([
        nonce,
        gasprice,
        startgas,
        to,
        value,
        data
    ]));
}
async function trySignTransaction(device, path, transaction) {
    return await result/* Result */.x.runAndDoubleWrap(()=>signTransactionOrThrow(device, path, transaction));
}
async function signTransactionOrThrow(device, path, transaction) {
    const env_1 = {
        stack: [],
        error: void 0,
        hasError: false
    };
    try {
        const paths = Paths.from(path);
        const slice = __addDisposableResource(env_1, adapter/* get */.U().padStartAndDecodeOrThrow(transaction.unsignedSerialized.slice(2)), false);
        const reader = new cursor_cursor/* Cursor */.C(slice.bytes);
        const unprotected = readLegacyUnprotectedOrThrow(slice.bytes);
        let response;
        {
            const head = paths.sizeOrThrow();
            let body = Math.min(150 - head, reader.remaining);
            /**
             * Make sure that the chunk doesn't end right on the replay protection marker (EIP-155)
             * If it goes further than the unprotected part, then send the (few) remaining bytes of the protection
             */ if (unprotected != null && reader.offset + body >= unprotected.length) body = reader.remaining;
            const chunk = reader.readOrThrow(body);
            const writer = new cursor_cursor/* Cursor */.C(new Uint8Array(head + body));
            paths.writeOrThrow(writer);
            writer.writeOrThrow(chunk);
            const request = {
                cla: 0xe0,
                ins: 0x04,
                p1: 0x00,
                p2: 0x00,
                fragment: new opaque/* Opaque */.lD(writer.bytes)
            };
            response = await device.requestOrThrow(request).then((r)=>r.unwrap().bytes);
        }
        while(reader.remaining){
            let body = Math.min(150, reader.remaining);
            /**
             * Make sure that the chunk doesn't end right on the replay protection marker (EIP-155)
             * If it goes further than the unprotected part, then send the (few) remaining bytes of the protection
             */ if (unprotected != null && reader.offset + body >= unprotected.length) body = reader.remaining;
            const chunk = reader.readOrThrow(body);
            const request = {
                cla: 0xe0,
                ins: 0x04,
                p1: 0x80,
                p2: 0x00,
                fragment: new opaque/* Opaque */.lD(chunk)
            };
            response = await device.requestOrThrow(request).then((r)=>r.unwrap().bytes);
        }
        const cursor = new cursor_cursor/* Cursor */.C(response);
        const v = cursor.readUint8OrThrow();
        const r = cursor.readAndCopyOrThrow(32);
        const s = cursor.readAndCopyOrThrow(32);
        // if ((((chainId * 2) + 35) + 1) > 255) {
        //   const parity = Math.abs(v0 - (((chainId * 2) + 35) % 256))
        //   if (transaction.type == null)
        //     v = ((chainId * 2) + 35) + parity
        //   else
        //     v = (parity % 2) == 1 ? 0 : 1;
        // }
        return {
            v,
            r,
            s
        };
    } catch (e_1) {
        env_1.error = e_1;
        env_1.hasError = true;
    } finally{
        __disposeResources(env_1);
    }
}
async function trySignEIP712HashedMessage(device, path, domain, message) {
    return await result/* Result */.x.runAndDoubleWrap(()=>signEIP712HashedMessageOrThrow(device, path, domain, message));
}
async function signEIP712HashedMessageOrThrow(device, path, domain, message) {
    const paths = Paths.from(path);
    const writer = new cursor_cursor/* Cursor */.C(new Uint8Array(paths.sizeOrThrow() + 32 + 32));
    paths.writeOrThrow(writer);
    writer.writeOrThrow(domain);
    writer.writeOrThrow(message);
    const request = {
        cla: 0xe0,
        ins: 0x0c,
        p1: 0x00,
        p2: 0x00,
        fragment: new opaque/* Opaque */.lD(writer.bytes)
    };
    const response = await device.requestOrThrow(request).then((r)=>r.unwrap().bytes);
    const reader = new cursor_cursor/* Cursor */.C(response);
    const v = reader.readUint8OrThrow() - 27;
    const r = reader.readAndCopyOrThrow(32);
    const s = reader.readAndCopyOrThrow(32);
    return {
        v,
        r,
        s
    };
}

;// CONCATENATED MODULE: ./src/libs/ledger/mods/ethereum/index.ts


// EXTERNAL MODULE: ./node_modules/@swc/helpers/esm/_class_private_field_get.js + 1 modules
var _class_private_field_get = __webpack_require__(7121);
// EXTERNAL MODULE: ./node_modules/@swc/helpers/esm/_class_private_field_init.js
var _class_private_field_init = __webpack_require__(9886);
// EXTERNAL MODULE: ./node_modules/@swc/helpers/esm/_class_private_field_set.js + 1 modules
var _class_private_field_set = __webpack_require__(5321);
// EXTERNAL MODULE: ./node_modules/@swc/helpers/esm/_class_private_method_get.js
var _class_private_method_get = __webpack_require__(6723);
// EXTERNAL MODULE: ./node_modules/@swc/helpers/esm/_class_private_method_init.js
var _class_private_method_init = __webpack_require__(9979);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/ok.mjs
var ok = __webpack_require__(5591);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/err.mjs
var err = __webpack_require__(166);
;// CONCATENATED MODULE: ./src/libs/ledger/libs/apdu/request.ts



var _a;
var _class = /*#__PURE__*/ new WeakMap();
class ApduDataOverflowError extends Error {
    constructor(length){
        super("Data overflow (".concat(length, " > 255)"));
        (0,_class_private_field_init._)(this, _class, {
            writable: true,
            value: void 0
        });
        (0,_class_private_field_set._)(this, _class, _a);
        this.name = (0,_class_private_field_get._)(this, _class).name;
        this.length = length;
    }
}
_a = ApduDataOverflowError;
class ApduRequest {
    static fromOrThrow(init) {
        const { cla, ins, p1, p2, fragment } = init;
        const fragmentSize = fragment.sizeOrThrow();
        if (fragmentSize > 255) throw new ApduDataOverflowError(fragmentSize);
        return new ApduRequest(cla, ins, p1, p2, fragment, fragmentSize);
    }
    sizeOrThrow() {
        return 1 + 1 + 1 + 1 + 1 + this.fragmentSize;
    }
    writeOrThrow(cursor) {
        cursor.writeUint8OrThrow(this.cla);
        cursor.writeUint8OrThrow(this.ins);
        cursor.writeUint8OrThrow(this.p1);
        cursor.writeUint8OrThrow(this.p2);
        cursor.writeUint8OrThrow(this.fragmentSize);
        this.fragment.writeOrThrow(cursor);
    }
    constructor(cla, ins, p1, p2, fragment, fragmentSize){
        this.cla = cla;
        this.ins = ins;
        this.p1 = p1;
        this.p2 = p2;
        this.fragment = fragment;
        this.fragmentSize = fragmentSize;
    }
}

;// CONCATENATED MODULE: ./src/libs/ledger/libs/apdu/response.ts



var response_a, _b;


var ApduResponse;
(function(ApduResponse) {
    function readOrThrow(cursor) {
        const bytes = cursor.readAndCopyOrThrow(cursor.remaining - 2);
        const status = cursor.readUint16OrThrow();
        const fragment = new opaque/* Opaque */.lD(bytes);
        if (status === ApduOk.status) return new ApduOk(fragment);
        return new ApduErr(status, fragment);
    }
    ApduResponse.readOrThrow = readOrThrow;
})(ApduResponse || (ApduResponse = {}));
var response_class = /*#__PURE__*/ new WeakMap();
class ApduError extends Error {
    constructor(status, fragment){
        super("".concat(status));
        (0,_class_private_field_init._)(this, response_class, {
            writable: true,
            value: void 0
        });
        (0,_class_private_field_set._)(this, response_class, response_a);
        this.name = (0,_class_private_field_get._)(this, response_class).name;
        this.status = status;
        this.fragment = fragment;
    }
}
response_a = ApduError;
var _class1 = /*#__PURE__*/ new WeakMap();
class ApduOk extends ok.Ok {
    get status() {
        return (0,_class_private_field_get._)(this, _class1).status;
    }
    constructor(fragment){
        super(fragment);
        (0,_class_private_field_init._)(this, _class1, {
            writable: true,
            value: void 0
        });
        (0,_class_private_field_set._)(this, _class1, _b);
        this.fragment = fragment;
    }
}
ApduOk.status = 0x9000;
_b = ApduOk;
class ApduErr extends err/* Err */.U {
    constructor(status, fragment){
        super(new ApduError(status, fragment));
        this.status = status;
        this.fragment = fragment;
    }
}

;// CONCATENATED MODULE: ./src/libs/ledger/libs/hid/frame.ts



var frame_a, frame_b;


var frame_class = /*#__PURE__*/ new WeakMap();
class InvalidTagError extends Error {
    constructor(tag){
        super("Invalid tag ".concat(tag));
        (0,_class_private_field_init._)(this, frame_class, {
            writable: true,
            value: void 0
        });
        (0,_class_private_field_set._)(this, frame_class, frame_a);
        this.name = (0,_class_private_field_get._)(this, frame_class).name;
        this.tag = tag;
    }
}
frame_a = InvalidTagError;
var frame_class1 = /*#__PURE__*/ new WeakMap();
class HIDFrame {
    sizeOrThrow() {
        return 2 + 1 + 2 + this.fragment.sizeOrThrow();
    }
    writeOrThrow(cursor) {
        cursor.writeUint16OrThrow(this.channel);
        cursor.writeUint8OrThrow((0,_class_private_field_get._)(this, frame_class1).tag);
        cursor.writeUint16OrThrow(this.index);
        this.fragment.writeOrThrow(cursor);
    }
    static readOrThrow(cursor) {
        const channel = cursor.readUint16OrThrow();
        const tag = cursor.readUint8OrThrow();
        if (tag !== this.tag) throw new InvalidTagError(tag);
        const index = cursor.readUint16OrThrow();
        const bytes = cursor.readAndCopyOrThrow(cursor.remaining);
        const fragment = new opaque/* Opaque */.lD(bytes);
        return new frame_b(channel, fragment, index);
    }
    static *splitOrThrow(channel, bytes) {
        const chunks = new cursor_cursor/* Cursor */.C(bytes).splitOrThrow(59);
        let chunk = chunks.next();
        for(let i = 0; !chunk.done; chunk = chunks.next(), i++)yield new frame_b(channel, new opaque/* Opaque */.lD(chunk.value), i);
        return chunk.value;
    }
    static async unsplitOrThrow(channel, generator) {
        const first = await generator.next();
        if (first.done) return first.value;
        const frames = readable/* Readable */.$.readFromBytesOrThrow(HIDContainer, first.value.fragment.bytes);
        const bytes = new Uint8Array(frames.length);
        const cursor = new cursor_cursor/* Cursor */.C(bytes);
        cursor.writeOrThrow(frames.fragment.bytes.slice(0, cursor.remaining));
        if (!cursor.remaining) return cursor.bytes;
        let frame = await generator.next();
        for(; !frame.done; frame = await generator.next()){
            cursor.writeOrThrow(frame.value.fragment.bytes.slice(0, cursor.remaining));
            if (!cursor.remaining) return cursor.bytes;
            continue;
        }
        return frame.value;
    }
    constructor(channel, fragment, index){
        (0,_class_private_field_init._)(this, frame_class1, {
            writable: true,
            value: void 0
        });
        (0,_class_private_field_set._)(this, frame_class1, frame_b);
        this.channel = channel;
        this.fragment = fragment;
        this.index = index;
    }
}
HIDFrame.tag = 0x05;
frame_b = HIDFrame;
class HIDContainer {
    static newOrThrow(fragment) {
        return new HIDContainer(fragment.sizeOrThrow(), fragment);
    }
    sizeOrThrow() {
        return Math.ceil((2 + this.length) / 59) * 59;
    }
    writeOrThrow(cursor) {
        cursor.writeUint16OrThrow(this.length);
        this.fragment.writeOrThrow(cursor);
        cursor.fillOrThrow(0, cursor.remaining);
    }
    static readOrThrow(cursor) {
        const length = cursor.readUint16OrThrow();
        const bytes = cursor.readAndCopyOrThrow(cursor.remaining);
        const fragment = new opaque/* Opaque */.lD(bytes);
        return new HIDContainer(length, fragment);
    }
    constructor(length, fragment){
        this.length = length;
        this.fragment = fragment;
    }
}

;// CONCATENATED MODULE: ./src/libs/ledger/mods/usb/usb.ts





var usb_a, usb_b, _c, _d, _e, _f, _g, _h;






const VENDOR_ID = 0x2c97;
const PACKET_SIZE = 64;
var usb_class = /*#__PURE__*/ new WeakMap();
class DeviceNotFoundError extends Error {
    static from(cause) {
        return new usb_a({
            cause
        });
    }
    constructor(options){
        super("Could not find device", options);
        (0,_class_private_field_init._)(this, usb_class, {
            writable: true,
            value: void 0
        });
        (0,_class_private_field_set._)(this, usb_class, usb_a);
        this.name = (0,_class_private_field_get._)(this, usb_class).name;
    }
}
usb_a = DeviceNotFoundError;
var usb_class1 = /*#__PURE__*/ new WeakMap();
class DeviceOpenError extends Error {
    static from(cause) {
        return new usb_b({
            cause
        });
    }
    constructor(options){
        super("Could not open device", options);
        (0,_class_private_field_init._)(this, usb_class1, {
            writable: true,
            value: void 0
        });
        (0,_class_private_field_set._)(this, usb_class1, usb_b);
        this.name = (0,_class_private_field_get._)(this, usb_class1).name;
    }
}
usb_b = DeviceOpenError;
var _class2 = /*#__PURE__*/ new WeakMap();
class DeviceConfigError extends Error {
    static from(cause) {
        return new _c({
            cause
        });
    }
    constructor(options){
        super("Could not configure device", options);
        (0,_class_private_field_init._)(this, _class2, {
            writable: true,
            value: void 0
        });
        (0,_class_private_field_set._)(this, _class2, _c);
        this.name = (0,_class_private_field_get._)(this, _class2).name;
    }
}
_c = DeviceConfigError;
var _class3 = /*#__PURE__*/ new WeakMap();
class DeviceResetError extends Error {
    static from(cause) {
        return new _d({
            cause
        });
    }
    constructor(options){
        super("Could not reset device", options);
        (0,_class_private_field_init._)(this, _class3, {
            writable: true,
            value: void 0
        });
        (0,_class_private_field_set._)(this, _class3, _d);
        this.name = (0,_class_private_field_get._)(this, _class3).name;
    }
}
_d = DeviceResetError;
var _class4 = /*#__PURE__*/ new WeakMap();
class DeviceInterfaceNotFoundError extends Error {
    static from(cause) {
        return new _e({
            cause
        });
    }
    constructor(options){
        super("Could not find device interface", options);
        (0,_class_private_field_init._)(this, _class4, {
            writable: true,
            value: void 0
        });
        (0,_class_private_field_set._)(this, _class4, _e);
        this.name = (0,_class_private_field_get._)(this, _class4).name;
    }
}
_e = DeviceInterfaceNotFoundError;
var _class5 = /*#__PURE__*/ new WeakMap();
class DeviceInterfaceClaimError extends Error {
    static from(cause) {
        return new _f({
            cause
        });
    }
    constructor(options){
        super("Could not claim device interface", options);
        (0,_class_private_field_init._)(this, _class5, {
            writable: true,
            value: void 0
        });
        (0,_class_private_field_set._)(this, _class5, _f);
        this.name = (0,_class_private_field_get._)(this, _class5).name;
    }
}
_f = DeviceInterfaceClaimError;
var _class6 = /*#__PURE__*/ new WeakMap();
class DeviceTransferOutError extends Error {
    static from(cause) {
        return new _g({
            cause
        });
    }
    constructor(options){
        super("Could not transfer data to device", options);
        (0,_class_private_field_init._)(this, _class6, {
            writable: true,
            value: void 0
        });
        (0,_class_private_field_set._)(this, _class6, _g);
        this.name = (0,_class_private_field_get._)(this, _class6).name;
    }
}
_g = DeviceTransferOutError;
var _class7 = /*#__PURE__*/ new WeakMap();
class DeviceTransferInError extends Error {
    static from(cause) {
        return new _h({
            cause
        });
    }
    constructor(options){
        super("Could not transfer data from device", options);
        (0,_class_private_field_init._)(this, _class7, {
            writable: true,
            value: void 0
        });
        (0,_class_private_field_set._)(this, _class7, _h);
        this.name = (0,_class_private_field_get._)(this, _class7).name;
    }
}
_h = DeviceTransferInError;
async function tryRequest() {
    return await result/* Result */.x.unthrow(async (t)=>{
        const devices = await result/* Result */.x.runAndWrap(async ()=>{
            return await navigator.usb.getDevices();
        }).then((r)=>r.mapErrSync(DeviceNotFoundError.from).throw(t));
        const device = devices.find((x)=>x.vendorId === VENDOR_ID);
        if (device != null) return new ok.Ok(device);
        const device2 = await result/* Result */.x.runAndWrap(async ()=>{
            return await navigator.usb.requestDevice({
                filters: [
                    {
                        vendorId: VENDOR_ID
                    }
                ]
            });
        }).then((r)=>r.mapErrSync(DeviceNotFoundError.from).throw(t));
        return new ok.Ok(device2);
    });
}
async function tryConnect() {
    return await result/* Result */.x.unthrow(async (t)=>{
        const device = await tryRequest().then((r)=>r.throw(t));
        await result/* Result */.x.runAndWrap(async ()=>{
            return await device.open();
        }).then((r)=>r.mapErrSync(DeviceOpenError.from).throw(t));
        if (device.configuration == null) await result/* Result */.x.runAndWrap(async ()=>{
            return await device.selectConfiguration(1);
        }).then((r)=>r.mapErrSync(DeviceConfigError.from).throw(t));
        await result/* Result */.x.runAndWrap(async ()=>{
            return await device.reset();
        }).then((r)=>r.mapErrSync(DeviceResetError.from).inspectErrSync(console.warn));
        const iface = device.configurations[0].interfaces.find((param)=>{
            let { alternates } = param;
            return alternates.some((x)=>x.interfaceClass === 255);
        });
        if (iface == null) return new err/* Err */.U(new DeviceInterfaceNotFoundError());
        await result/* Result */.x.runAndWrap(async ()=>{
            return await device.claimInterface(iface.interfaceNumber);
        }).then((r)=>r.mapErrSync(DeviceInterfaceClaimError.from).throw(t));
        return new ok.Ok(new LedgerUSBDevice(device, iface));
    });
}
var _channel = /*#__PURE__*/ new WeakMap(), _transferOutOrThrow = /*#__PURE__*/ new WeakSet(), _transferInOrThrow = /*#__PURE__*/ new WeakSet(), _sendOrThrow = /*#__PURE__*/ new WeakSet(), _receiveOrThrow = /*#__PURE__*/ new WeakSet();
class LedgerUSBDevice {
    async requestOrThrow(init) {
        const request = ApduRequest.fromOrThrow(init);
        await (0,_class_private_method_get._)(this, _sendOrThrow, sendOrThrow).call(this, request);
        const bytes = await HIDFrame.unsplitOrThrow((0,_class_private_field_get._)(this, _channel), (0,_class_private_method_get._)(this, _receiveOrThrow, receiveOrThrow).call(this));
        const response = readable/* Readable */.$.readFromBytesOrThrow(ApduResponse, bytes);
        return response;
    }
    constructor(device, iface){
        (0,_class_private_method_init._)(this, _transferOutOrThrow);
        (0,_class_private_method_init._)(this, _transferInOrThrow);
        (0,_class_private_method_init._)(this, _sendOrThrow);
        (0,_class_private_method_init._)(this, _receiveOrThrow);
        (0,_class_private_field_init._)(this, _channel, {
            writable: true,
            value: void 0
        });
        (0,_class_private_field_set._)(this, _channel, Math.floor(Math.random() * 0xffff));
        this.device = device;
        this.iface = iface;
    }
}
async function transferOutOrThrow(frame) {
    await this.device.transferOut(3, writable/* Writable */.c.writeToBytesOrThrow(frame));
}
async function transferInOrThrow(length) {
    const result = await this.device.transferIn(3, length);
    if (result.data == null) throw new DeviceTransferInError();
    const bytes = bytes_bytes/* Bytes */.J.fromView(result.data);
    const frame = readable/* Readable */.$.readFromBytesOrThrow(HIDFrame, bytes);
    return frame;
}
async function sendOrThrow(fragment) {
    const container = HIDContainer.newOrThrow(fragment);
    const bytes = writable/* Writable */.c.writeToBytesOrThrow(container);
    const frames = HIDFrame.splitOrThrow((0,_class_private_field_get._)(this, _channel), bytes);
    let frame = frames.next();
    for(; !frame.done; frame = frames.next())await (0,_class_private_method_get._)(this, _transferOutOrThrow, transferOutOrThrow).call(this, frame.value);
    return frame.value;
}
async function* receiveOrThrow() {
    while(true)yield await (0,_class_private_method_get._)(this, _transferInOrThrow, transferInOrThrow).call(this, 64);
}

;// CONCATENATED MODULE: ./src/libs/ledger/mods/usb/index.ts


;// CONCATENATED MODULE: ./src/libs/ledger/mods/index.ts







;// CONCATENATED MODULE: ./src/libs/ledger/index.ts




/***/ }),

/***/ 1634:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   o: function() { return /* binding */ Maps; }
/* harmony export */ });
var Maps;
(function(Maps) {
    function getOrCreate(map, key, factory) {
        let value = map.get(key);
        if (value == null) {
            value = factory();
            map.set(key, value);
        }
        return value;
    }
    Maps.getOrCreate = getOrCreate;
    function* entry(entries) {
        for (const [key, value] of entries)yield {
            key,
            value
        };
    }
    function entries(map) {
        return entry(map.entries());
    }
    Maps.entries = entries;
})(Maps || (Maps = {}));


/***/ }),

/***/ 7519:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   u: function() { return /* binding */ Results; }
/* harmony export */ });
/* harmony import */ var _errors_errors__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8524);

var Results;
(function(Results) {
    function log(result) {
        result.inspectErrSync(_errors_errors__WEBPACK_IMPORTED_MODULE_0__/* .Errors */ .D.log);
        return result;
    }
    Results.log = log;
    function logAndAlert(result) {
        result.inspectErrSync(_errors_errors__WEBPACK_IMPORTED_MODULE_0__/* .Errors */ .D.logAndAlert);
        return result;
    }
    Results.logAndAlert = logAndAlert;
})(Results || (Results = {}));


/***/ }),

/***/ 5802:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   f: function() { return /* binding */ AbortSignals; }
/* harmony export */ });
var AbortSignals;
(function(AbortSignals) {
    function never() {
        return new AbortController().signal;
    }
    AbortSignals.never = never;
    function timeout(delay, parent) {
        return merge(AbortSignal.timeout(delay), parent);
    }
    AbortSignals.timeout = timeout;
    function merge(a, b) {
        if (b == null) return a;
        const c = new AbortController();
        const onAbort = (reason)=>{
            c.abort(reason);
            a.removeEventListener("abort", onAbort);
            b.removeEventListener("abort", onAbort);
        };
        a.addEventListener("abort", onAbort, {
            passive: true
        });
        b.addEventListener("abort", onAbort, {
            passive: true
        });
        return c.signal;
    }
    AbortSignals.merge = merge;
})(AbortSignals || (AbortSignals = {}));


/***/ }),

/***/ 9340:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   N: function() { return /* binding */ Circuits; }
/* harmony export */ });
/* harmony import */ var _hazae41_box__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6200);
/* harmony import */ var _hazae41_cadenas__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5939);
/* harmony import */ var _hazae41_cadenas__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8783);
/* harmony import */ var _hazae41_cleaner__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1878);
/* harmony import */ var _hazae41_echalote__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7240);
/* harmony import */ var _hazae41_echalote__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1020);
/* harmony import */ var _hazae41_fleche__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2156);
/* harmony import */ var _hazae41_option__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1371);
/* harmony import */ var _hazae41_piscine__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8794);
/* harmony import */ var _hazae41_piscine__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8697);
/* harmony import */ var _hazae41_result__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(918);
/* harmony import */ var _hazae41_result__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5591);
var __addDisposableResource = undefined && undefined.__addDisposableResource || function(env, value, async) {
    if (value !== null && value !== void 0) {
        if (typeof value !== "object" && typeof value !== "function") throw new TypeError("Object expected.");
        var dispose;
        if (async) {
            if (!Symbol.asyncDispose) throw new TypeError("Symbol.asyncDispose is not defined.");
            dispose = value[Symbol.asyncDispose];
        }
        if (dispose === void 0) {
            if (!Symbol.dispose) throw new TypeError("Symbol.dispose is not defined.");
            dispose = value[Symbol.dispose];
        }
        if (typeof dispose !== "function") throw new TypeError("Object not disposable.");
        env.stack.push({
            value: value,
            dispose: dispose,
            async: async
        });
    } else if (async) {
        env.stack.push({
            async: true
        });
    }
    return value;
};
var __disposeResources = undefined && undefined.__disposeResources || function(SuppressedError1) {
    return function(env) {
        function fail(e) {
            env.error = env.hasError ? new SuppressedError1(e, env.error, "An error was suppressed during disposal.") : e;
            env.hasError = true;
        }
        function next() {
            while(env.stack.length){
                var rec = env.stack.pop();
                try {
                    var result = rec.dispose && rec.dispose.call(rec.value);
                    if (rec.async) return Promise.resolve(result).then(next, function(e) {
                        fail(e);
                        return next();
                    });
                } catch (e) {
                    fail(e);
                }
            }
            if (env.hasError) throw env.error;
        }
        return next();
    };
}(typeof SuppressedError === "function" ? SuppressedError : function(error, suppressed, message) {
    var e = new Error(message);
    return e.name = "SuppressedError", e.error = error, e.suppressed = suppressed, e;
});








var Circuits;
(function(Circuits) {
    async function tryOpenAs(circuit, input) {
        return await _hazae41_result__WEBPACK_IMPORTED_MODULE_0__/* .Result */ .x.runAndDoubleWrap(()=>openAsOrThrow(circuit, input));
    }
    Circuits.tryOpenAs = tryOpenAs;
    async function openAsOrThrow(circuit, input) {
        const req = new Request(input);
        const url = new URL(req.url);
        if (url.protocol === "http:" || url.protocol === "ws:") {
            const tcp = await circuit.openOrThrow(url.hostname, Number(url.port) || 80);
            return new _hazae41_cleaner__WEBPACK_IMPORTED_MODULE_1__/* .Disposer */ .ku(tcp.outer, ()=>tcp.close());
        }
        if (url.protocol === "https:" || url.protocol === "wss:") {
            const tcp = await circuit.openOrThrow(url.hostname, Number(url.port) || 443);
            const ciphers = [
                _hazae41_cadenas__WEBPACK_IMPORTED_MODULE_2__/* .TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384 */ .$x,
                _hazae41_cadenas__WEBPACK_IMPORTED_MODULE_2__/* .TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384 */ .qZ
            ];
            const tls = new _hazae41_cadenas__WEBPACK_IMPORTED_MODULE_3__/* .TlsClientDuplex */ .g({
                host_name: url.hostname,
                ciphers
            });
            tcp.outer.readable.pipeTo(tls.inner.writable).catch(()=>{});
            tls.inner.readable.pipeTo(tcp.outer.writable).catch(()=>{});
            return new _hazae41_cleaner__WEBPACK_IMPORTED_MODULE_1__/* .Disposer */ .ku(tls.outer, ()=>tcp.close());
        }
        throw new Error(url.protocol);
    }
    Circuits.openAsOrThrow = openAsOrThrow;
    /**
     * Create a pool of Circuits modulo a pool of Tor clients
     * @param tors
     * @param params
     * @returns
     */ function pool(tors, consensus, params) {
        const middles = consensus.microdescs.filter((it)=> true && it.flags.includes("Fast") && it.flags.includes("Stable") && it.flags.includes("V2Dir"));
        const exits = consensus.microdescs.filter((it)=> true && it.flags.includes("Fast") && it.flags.includes("Stable") && it.flags.includes("Exit") && !it.flags.includes("BadExit"));
        let update = Date.now();
        const pool = new _hazae41_piscine__WEBPACK_IMPORTED_MODULE_4__/* .Pool */ .Kg(async (params)=>{
            while(true){
                const start = Date.now();
                const result = await _hazae41_result__WEBPACK_IMPORTED_MODULE_0__/* .Result */ .x.unthrow(async (t)=>{
                    const env_1 = {
                        stack: [],
                        error: void 0,
                        hasError: false
                    };
                    try {
                        const { index, signal } = params;
                        const tor = await tors.tryGet(index % tors.capacity, signal).then((r)=>r.throw(t).throw(t).inner.inner);
                        const circuit = __addDisposableResource(env_1, await (0,_hazae41_piscine__WEBPACK_IMPORTED_MODULE_5__/* .tryLoop */ .m4)(async ()=>{
                            return await _hazae41_result__WEBPACK_IMPORTED_MODULE_0__/* .Result */ .x.unthrow(async (t)=>{
                                const env_2 = {
                                    stack: [],
                                    error: void 0,
                                    hasError: false
                                };
                                try {
                                    const circuit = __addDisposableResource(env_2, new _hazae41_box__WEBPACK_IMPORTED_MODULE_6__/* .Box */ .x(await tor.tryCreate(AbortSignal.timeout(1000)).then((r)=>r.mapErrSync(_hazae41_piscine__WEBPACK_IMPORTED_MODULE_5__/* .Cancel */ .$j.new).throw(t))), false);
                                    /**
                                     * Try to extend to middle relay 3 times before giving up this circuit
                                     */ await (0,_hazae41_piscine__WEBPACK_IMPORTED_MODULE_5__/* .tryLoop */ .m4)(()=>{
                                        return _hazae41_result__WEBPACK_IMPORTED_MODULE_0__/* .Result */ .x.unthrow(async (t)=>{
                                            const head = middles[Math.floor(Math.random() * middles.length)];
                                            const body = await _hazae41_echalote__WEBPACK_IMPORTED_MODULE_7__/* .Consensus */ .L.Microdesc.tryFetch(circuit.inner, head).then((r)=>r.mapErrSync(_hazae41_piscine__WEBPACK_IMPORTED_MODULE_5__/* .Cancel */ .$j.new).throw(t));
                                            await circuit.inner.tryExtend(body, AbortSignal.timeout(1000)).then((r)=>r.mapErrSync(_hazae41_piscine__WEBPACK_IMPORTED_MODULE_5__/* .Retry */ .xC.new).throw(t));
                                            return _hazae41_result__WEBPACK_IMPORTED_MODULE_8__.Ok.void();
                                        });
                                    }, {
                                        init: 0,
                                        base: 0,
                                        max: 3
                                    }).then((r)=>r.mapErrSync(_hazae41_piscine__WEBPACK_IMPORTED_MODULE_5__/* .Retry */ .xC.new).throw(t));
                                    /**
                                     * Try to extend to exit relay 3 times before giving up this circuit
                                     */ await (0,_hazae41_piscine__WEBPACK_IMPORTED_MODULE_5__/* .tryLoop */ .m4)(()=>{
                                        return _hazae41_result__WEBPACK_IMPORTED_MODULE_0__/* .Result */ .x.unthrow(async (t)=>{
                                            const head = exits[Math.floor(Math.random() * exits.length)];
                                            const body = await _hazae41_echalote__WEBPACK_IMPORTED_MODULE_7__/* .Consensus */ .L.Microdesc.tryFetch(circuit.inner, head).then((r)=>r.mapErrSync(_hazae41_piscine__WEBPACK_IMPORTED_MODULE_5__/* .Cancel */ .$j.new).throw(t));
                                            await circuit.inner.tryExtend(body, AbortSignal.timeout(1000)).then((r)=>r.mapErrSync(_hazae41_piscine__WEBPACK_IMPORTED_MODULE_5__/* .Retry */ .xC.new).throw(t));
                                            return _hazae41_result__WEBPACK_IMPORTED_MODULE_8__.Ok.void();
                                        });
                                    }, {
                                        init: 0,
                                        base: 0,
                                        max: 3
                                    }).then((r)=>r.mapErrSync(_hazae41_piscine__WEBPACK_IMPORTED_MODULE_5__/* .Retry */ .xC.new).throw(t));
                                    /**
                                     * Try to open a stream to a reliable endpoint
                                     */ const stream = __addDisposableResource(env_2, await tryOpenAs(circuit.inner, "http://detectportal.firefox.com").then((r)=>r.mapErrSync(_hazae41_piscine__WEBPACK_IMPORTED_MODULE_5__/* .Retry */ .xC.new).throw(t)), false);
                                    /**
                                     * Reliability test
                                     */ for(let i = 0; i < 3; i++){
                                        /**
                                         * Speed test
                                         */ const signal = AbortSignal.timeout(1000);
                                        await _hazae41_result__WEBPACK_IMPORTED_MODULE_0__/* .Result */ .x.runAndDoubleWrap(async ()=>{
                                            await (0,_hazae41_fleche__WEBPACK_IMPORTED_MODULE_9__/* .fetch */ .h)("http://detectportal.firefox.com", {
                                                stream: stream.inner,
                                                signal,
                                                preventAbort: true,
                                                preventCancel: true,
                                                preventClose: true
                                            }).then((r)=>r.text());
                                        }).then((r)=>r.mapErrSync(_hazae41_piscine__WEBPACK_IMPORTED_MODULE_5__/* .Retry */ .xC.new).throw(t));
                                    }
                                    return new _hazae41_result__WEBPACK_IMPORTED_MODULE_8__.Ok(circuit.moveOrThrow());
                                } catch (e_2) {
                                    env_2.error = e_2;
                                    env_2.hasError = true;
                                } finally{
                                    __disposeResources(env_2);
                                }
                            });
                        }, {
                            max: 9
                        }).then((r)=>r.throw(t)), false);
                        return new _hazae41_result__WEBPACK_IMPORTED_MODULE_8__.Ok((0,_hazae41_echalote__WEBPACK_IMPORTED_MODULE_10__/* .createCircuitEntry */ .k)(circuit.moveOrThrow(), params));
                    } catch (e_1) {
                        env_1.error = e_1;
                        env_1.hasError = true;
                    } finally{
                        __disposeResources(env_1);
                    }
                }).then((r)=>r.inspectErrSync((e)=>console.error("Circuit creation failed", {
                            e
                        })));
                if (result.isOk()) return result;
                if (start < update) continue;
                return result;
            }
        }, params);
        tors.events.on("started", async (i)=>{
            update = Date.now();
            for(let i = 0; i < pool.capacity; i++){
                const child = pool.tryGetSync(i);
                if (child.isErr()) continue;
                if (child.inner.isErr()) pool.restart(i);
                continue;
            }
            return new _hazae41_option__WEBPACK_IMPORTED_MODULE_11__/* .None */ .H();
        }, {
            passive: true
        });
        return pool;
    }
    Circuits.pool = pool;
    /**
     * Create a pool of Circuits stealing from another pool of Circuits
     * @param circuits
     * @param params
     * @returns
     */ function subpool(circuits, params) {
        let update = Date.now();
        const pool = new _hazae41_piscine__WEBPACK_IMPORTED_MODULE_4__/* .Pool */ .Kg(async (params)=>{
            while(true){
                const start = Date.now();
                const result = await _hazae41_result__WEBPACK_IMPORTED_MODULE_0__/* .Result */ .x.unthrow(async (t)=>{
                    const env_3 = {
                        stack: [],
                        error: void 0,
                        hasError: false
                    };
                    try {
                        const circuit = __addDisposableResource(env_3, await _hazae41_piscine__WEBPACK_IMPORTED_MODULE_4__/* .Pool */ .Kg.tryTakeCryptoRandom(circuits).then((r)=>r.throw(t).throw(t).inner), false);
                        return new _hazae41_result__WEBPACK_IMPORTED_MODULE_8__.Ok((0,_hazae41_echalote__WEBPACK_IMPORTED_MODULE_10__/* .createCircuitEntry */ .k)(circuit.moveOrThrow(), params));
                    } catch (e_3) {
                        env_3.error = e_3;
                        env_3.hasError = true;
                    } finally{
                        __disposeResources(env_3);
                    }
                });
                if (result.isOk()) return result;
                if (start < update) continue;
                return result;
            }
        }, params);
        circuits.inner.events.on("started", async ()=>{
            update = Date.now();
            for(let i = 0; i < pool.capacity; i++){
                const child = pool.tryGetSync(i);
                if (child.isErr()) continue;
                if (child.inner.isErr()) pool.restart(i);
                continue;
            }
            return new _hazae41_option__WEBPACK_IMPORTED_MODULE_11__/* .None */ .H();
        }, {
            passive: true
        });
        return pool;
    }
    Circuits.subpool = subpool;
})(Circuits || (Circuits = {}));


/***/ }),

/***/ 9240:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   U: function() { return /* binding */ TextAnchor; }
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);

function TextAnchor(props) {
    const { className, href, children = href, target = "_blank", rel = "noreferrer", ...others } = props;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
        className: "a ".concat(className),
        href: href,
        target: target,
        rel: rel,
        ...others,
        children: children
    });
}


/***/ }),

/***/ 110:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  g: function() { return /* reexport */ textarea_namespaceObject; }
});

// NAMESPACE OBJECT: ./src/libs/ui/textarea/index.tsx
var textarea_namespaceObject = {};
__webpack_require__.r(textarea_namespaceObject);
__webpack_require__.d(textarea_namespaceObject, {
  m: function() { return contrast_Contrast; }
});

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
;// CONCATENATED MODULE: ./src/libs/ui/textarea/contrast.tsx


function contrast_Contrast(props) {
    const { children, className, xref, ...input } = props;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("textarea", {
        className: "px-4 py-2 rounded-xl outline-none border border-transparent clicked-or-focused:border-contrast bg-contrast transition ".concat(className),
        ref: xref,
        ...input,
        children: children
    });
}
(function(Contrast) {
    function Test() {
        return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
            className: "p-1",
            children: /*#__PURE__*/ (0,jsx_runtime.jsx)(contrast_Contrast, {
                placeholder: "Hello world"
            })
        });
    }
    Contrast.Test = Test;
})(contrast_Contrast || (contrast_Contrast = {}));

;// CONCATENATED MODULE: ./src/libs/ui/textarea/index.tsx


;// CONCATENATED MODULE: ./src/libs/ui/textarea.tsx




/***/ }),

/***/ 872:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   R: function() { return /* binding */ Url; },
/* harmony export */   d: function() { return /* binding */ qurl; }
/* harmony export */ });
/* harmony import */ var _hazae41_result__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5591);
/* harmony import */ var _hazae41_result__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(166);

function qurl(pathname) {
    let query = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
    const url = new URL(pathname, "https://nowhere");
    for (const [key, value] of Object.entries(query))if (value != null) url.searchParams.append(key, value);
    return "".concat(url.pathname).concat(url.search);
}
var Url;
(function(Url) {
    function tryParse(url) {
        try {
            return new _hazae41_result__WEBPACK_IMPORTED_MODULE_0__.Ok(new URL(url));
        } catch (e) {
            return new _hazae41_result__WEBPACK_IMPORTED_MODULE_1__/* .Err */ .U(new Error("Not an URL"));
        }
    }
    Url.tryParse = tryParse;
})(Url || (Url = {}));


/***/ }),

/***/ 299:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $: function() { return /* binding */ WebAuthnStorageError; },
/* harmony export */   g: function() { return /* binding */ WebAuthnStorage; }
/* harmony export */ });
/* harmony import */ var _swc_helpers_class_private_field_get__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7121);
/* harmony import */ var _swc_helpers_class_private_field_init__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9886);
/* harmony import */ var _swc_helpers_class_private_field_set__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5321);
/* harmony import */ var _hazae41_result__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(918);



var _a;

var _class = /*#__PURE__*/ new WeakMap();
class WebAuthnStorageError extends Error {
    static from(cause) {
        return new _a({
            cause
        });
    }
    constructor(options){
        super("Could not use authenticated storage", options);
        (0,_swc_helpers_class_private_field_init__WEBPACK_IMPORTED_MODULE_0__._)(this, _class, {
            writable: true,
            value: void 0
        });
        (0,_swc_helpers_class_private_field_set__WEBPACK_IMPORTED_MODULE_1__._)(this, _class, _a);
        this.name = (0,_swc_helpers_class_private_field_get__WEBPACK_IMPORTED_MODULE_2__._)(this, _class).name;
    }
}
_a = WebAuthnStorageError;
/**
 * Use WebAuthn as a authentication-protected storage of arbitrary bytes
 * This WON'T use the Secure Enclave as it stores the bytes in `userHandle` (probably on disk)
 *
 * This is used to prevent unauthenticated access to the (encrypted) bytes in the case of:
 * - supply-chain attack where the attacker has the encryption password: it would still require user approval before stealing the private key
 * - phishing, misclick, phone-left-on-the-table attack: it would still require user approval before signing transactions
 */ var WebAuthnStorage;
(function(WebAuthnStorage) {
    async function tryCreate(name, data) {
        return await _hazae41_result__WEBPACK_IMPORTED_MODULE_3__/* .Result */ .x.runAndWrap(async ()=>{
            return await createOrThrow(name, data);
        }).then((r)=>r.mapErrSync(WebAuthnStorageError.from));
    }
    WebAuthnStorage.tryCreate = tryCreate;
    async function createOrThrow(name, data) {
        const credential = await navigator.credentials.create({
            publicKey: {
                challenge: new Uint8Array([
                    117,
                    61,
                    252,
                    231,
                    191,
                    241
                ]),
                rp: {
                    id: location.hostname,
                    name: "Brume Wallet"
                },
                user: {
                    id: data,
                    name: name,
                    displayName: name
                },
                pubKeyCredParams: [
                    {
                        type: "public-key",
                        alg: -7
                    },
                    {
                        type: "public-key",
                        alg: -8
                    },
                    {
                        type: "public-key",
                        alg: -257
                    }
                ],
                authenticatorSelection: {
                    authenticatorAttachment: "platform"
                }
            }
        });
        return new Uint8Array(credential.rawId);
    }
    WebAuthnStorage.createOrThrow = createOrThrow;
    async function tryGet(id) {
        return await _hazae41_result__WEBPACK_IMPORTED_MODULE_3__/* .Result */ .x.runAndWrap(async ()=>{
            return await getOrThrow(id);
        }).then((r)=>r.mapErrSync(WebAuthnStorageError.from));
    }
    WebAuthnStorage.tryGet = tryGet;
    async function getOrThrow(id) {
        const credential = await navigator.credentials.get({
            publicKey: {
                challenge: new Uint8Array([
                    117,
                    61,
                    252,
                    231,
                    191,
                    241
                ]),
                allowCredentials: [
                    {
                        type: "public-key",
                        id
                    }
                ]
            }
        });
        return new Uint8Array(credential.response.userHandle);
    }
    WebAuthnStorage.getOrThrow = getOrThrow;
})(WebAuthnStorage || (WebAuthnStorage = {}));


/***/ }),

/***/ 580:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  H: function() { return /* binding */ BgEthereumContext; }
});

// EXTERNAL MODULE: ./src/libs/maps/maps.ts
var maps = __webpack_require__(1634);
// EXTERNAL MODULE: ./node_modules/@hazae41/bytes/dist/esm/mods/bytes/bytes.mjs + 3 modules
var bytes = __webpack_require__(1694);
// EXTERNAL MODULE: ./node_modules/@hazae41/fleche/dist/esm/src/mods/fetch/fetch.mjs + 8 modules
var fetch = __webpack_require__(2156);
// EXTERNAL MODULE: ./node_modules/@hazae41/future/dist/esm/mods/future/future.mjs
var future_future = __webpack_require__(6071);
// EXTERNAL MODULE: ./node_modules/@hazae41/jsonrpc/dist/esm/mods/rpc/request.mjs
var rpc_request = __webpack_require__(4356);
// EXTERNAL MODULE: ./node_modules/@hazae41/jsonrpc/dist/esm/mods/rpc/response.mjs
var rpc_response = __webpack_require__(5457);
// EXTERNAL MODULE: ./node_modules/@hazae41/plume/dist/esm/src/mods/errors.mjs
var errors = __webpack_require__(9107);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/result.mjs
var result = __webpack_require__(918);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/err.mjs
var err = __webpack_require__(166);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/ok.mjs
var ok = __webpack_require__(5591);
// EXTERNAL MODULE: ./src/libs/tor/circuits/circuits.ts
var circuits = __webpack_require__(9340);
;// CONCATENATED MODULE: ./src/libs/rpc/rpc.ts
var __addDisposableResource = undefined && undefined.__addDisposableResource || function(env, value, async) {
    if (value !== null && value !== void 0) {
        if (typeof value !== "object" && typeof value !== "function") throw new TypeError("Object expected.");
        var dispose;
        if (async) {
            if (!Symbol.asyncDispose) throw new TypeError("Symbol.asyncDispose is not defined.");
            dispose = value[Symbol.asyncDispose];
        }
        if (dispose === void 0) {
            if (!Symbol.dispose) throw new TypeError("Symbol.dispose is not defined.");
            dispose = value[Symbol.dispose];
        }
        if (typeof dispose !== "function") throw new TypeError("Object not disposable.");
        env.stack.push({
            value: value,
            dispose: dispose,
            async: async
        });
    } else if (async) {
        env.stack.push({
            async: true
        });
    }
    return value;
};
var __disposeResources = undefined && undefined.__disposeResources || function(SuppressedError1) {
    return function(env) {
        function fail(e) {
            env.error = env.hasError ? new SuppressedError1(e, env.error, "An error was suppressed during disposal.") : e;
            env.hasError = true;
        }
        function next() {
            while(env.stack.length){
                var rec = env.stack.pop();
                try {
                    var result = rec.dispose && rec.dispose.call(rec.value);
                    if (rec.async) return Promise.resolve(result).then(next, function(e) {
                        fail(e);
                        return next();
                    });
                } catch (e) {
                    fail(e);
                }
            }
            if (env.hasError) throw env.error;
        }
        return next();
    };
}(typeof SuppressedError === "function" ? SuppressedError : function(error, suppressed, message) {
    var e = new Error(message);
    return e.name = "SuppressedError", e.error = error, e.suppressed = suppressed, e;
});







var TorRpc;
(function(TorRpc) {
    async function tryFetchWithCircuit(input, init) {
        return await result/* Result */.x.unthrow(async (t)=>{
            const env_1 = {
                stack: [],
                error: void 0,
                hasError: false
            };
            try {
                const { id, method, params, circuit, ...rest } = init;
                const request = new rpc_request/* RpcRequest */.a(id, method, params);
                const body = bytes/* Bytes */.J.fromUtf8(JSON.stringify(request));
                const headers = new Headers(rest.headers);
                headers.set("Content-Type", "application/json");
                headers.set("Content-Length", "".concat(body.length));
                const stream = __addDisposableResource(env_1, await circuits/* Circuits */.N.openAsOrThrow(circuit, input), false);
                const res = await (0,fetch/* fetch */.h)(input, {
                    ...rest,
                    method: "POST",
                    headers,
                    body,
                    stream: stream.inner
                });
                if (!res.ok) {
                    const text = await result/* Result */.x.runAndDoubleWrap(()=>{
                        return res.text();
                    }).then((r)=>r.throw(t));
                    return new err/* Err */.U(new Error(text));
                }
                const json = await result/* Result */.x.runAndDoubleWrap(()=>{
                    return res.json();
                }).then((r)=>r.throw(t));
                const response = rpc_response/* RpcResponse */.S.from(json);
                if (response.id !== request.id) console.warn("Invalid response ID", response.id, "expected", request.id);
                return new ok.Ok(response);
            } catch (e_1) {
                env_1.error = e_1;
                env_1.hasError = true;
            } finally{
                __disposeResources(env_1);
            }
        });
    }
    TorRpc.tryFetchWithCircuit = tryFetchWithCircuit;
    async function tryFetchWithSocket(socket, request, signal) {
        const { id, method, params = [] } = request;
        socket.send(JSON.stringify(new rpc_request/* RpcRequest */.a(id, method, params)));
        const future = new future_future/* Future */.o();
        const onMessage = async (event)=>{
            if (typeof event.data !== "string") return;
            const response = rpc_response/* RpcResponse */.S.from(JSON.parse(event.data));
            if (response.id !== request.id) return;
            future.resolve(new ok.Ok(response));
        };
        const onError = (e)=>{
            future.resolve(new err/* Err */.U(errors/* ErroredError */.kN.from(e)));
        };
        const onClose = (e)=>{
            future.resolve(new err/* Err */.U(errors/* ClosedError */.$A.from(e)));
        };
        const onAbort = ()=>{
            future.resolve(new err/* Err */.U(errors/* AbortedError */.pe.from(signal.reason)));
        };
        try {
            socket.addEventListener("message", onMessage, {
                passive: true
            });
            socket.addEventListener("close", onClose, {
                passive: true
            });
            socket.addEventListener("error", onError, {
                passive: true
            });
            signal.addEventListener("abort", onAbort, {
                passive: true
            });
            return await future.promise;
        } finally{
            socket.removeEventListener("message", onMessage);
            socket.removeEventListener("close", onClose);
            socket.removeEventListener("error", onError);
            signal.removeEventListener("abort", onAbort);
        }
    }
    TorRpc.tryFetchWithSocket = tryFetchWithSocket;
})(TorRpc || (TorRpc = {}));

// EXTERNAL MODULE: ./src/libs/signals/signals.ts
var signals = __webpack_require__(5802);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/fetched/fetched.mjs
var fetched = __webpack_require__(1458);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/fetched/fail.mjs
var fail = __webpack_require__(9164);
// EXTERNAL MODULE: ./node_modules/@hazae41/option/dist/esm/mods/option/option.mjs
var option_option = __webpack_require__(5316);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/errors.mjs
var result_errors = __webpack_require__(2564);
;// CONCATENATED MODULE: ./src/mods/background/service_worker/context.ts






var BgEthereumContext;
(function(BgEthereumContext) {
    async function fetchOrFail(ethereum, init) {
        let more = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
        try {
            const { signal: parentSignal } = more;
            const { brume } = ethereum;
            const pools = option_option/* Option */.W.unwrap(brume[ethereum.chain.chainId]);
            async function runWithPoolOrThrow(index) {
                const poolSignal = signals/* AbortSignals */.f.timeout(5000, parentSignal);
                const pool = await pools.tryGet(index, poolSignal).then((r)=>r.unwrap().unwrap().inner.inner);
                async function runWithConnOrThrow(index) {
                    const connSignal = signals/* AbortSignals */.f.timeout(5000, parentSignal);
                    const conn = await pool.tryGet(index, connSignal).then((r)=>r.unwrap().unwrap().inner.inner);
                    const { counter, connection } = conn;
                    const request = counter.prepare(init);
                    if (connection.isURL()) {
                        const { url, circuit } = connection;
                        const signal = signals/* AbortSignals */.f.timeout(10000, parentSignal);
                        const result = await TorRpc.tryFetchWithCircuit(url, {
                            ...request,
                            circuit,
                            signal
                        });
                        if (result.isErr()) console.debug("Could not fetch ".concat(init.method, " from ").concat(url.href, " using ").concat(circuit.id), {
                            result
                        });
                        return fetched/* Fetched */.F.rewrap(result.unwrap());
                    }
                    if (connection.isWebSocket()) {
                        await connection.cooldown;
                        const { socket, circuit } = connection;
                        const signal = signals/* AbortSignals */.f.timeout(10000, parentSignal);
                        const result = await TorRpc.tryFetchWithSocket(socket, request, signal);
                        if (result.isErr()) console.debug("Could not fetch ".concat(init.method, " from ").concat(socket.url, " using ").concat(circuit.id), {
                            result
                        });
                        return fetched/* Fetched */.F.rewrap(result.unwrap());
                    }
                    throw new result_errors/* Panic */.F5();
                }
                const promises = Array.from({
                    length: pool.capacity
                }, (_, i)=>runWithConnOrThrow(i));
                const results = await Promise.allSettled(promises);
                const fetcheds = new Map();
                const counters = new Map();
                for (const result of results){
                    if (result.status === "rejected") continue;
                    if (result.value.isErr()) continue;
                    if (init === null || init === void 0 ? void 0 : init.noCheck) return result.value;
                    const raw = JSON.stringify(result.value.inner);
                    const previous = option_option/* Option */.W.wrap(counters.get(raw)).unwrapOr(0);
                    counters.set(raw, previous + 1);
                    fetcheds.set(raw, result.value);
                }
                /**
                 * One truth -> return it
                 * Zero truth -> throw AggregateError
                 */ if (counters.size < 2) return await Promise.any(promises);
                console.warn("Different results from multiple connections for ".concat(init.method, " on ").concat(ethereum.chain.name), {
                    fetcheds
                });
                /**
                 * Sort truths by occurence
                 */ const sorteds = [
                    ...maps/* Maps */.o.entries(counters)
                ].sort((a, b)=>b.value - a.value);
                /**
                 * Two concurrent truths
                 */ if (sorteds[0].value === sorteds[1].value) {
                    console.warn("Could not choose truth for ".concat(init.method, " on ").concat(ethereum.chain.name));
                    const random = Math.round(Math.random());
                    return fetcheds.get(sorteds[random].key);
                }
                return fetcheds.get(sorteds[0].key);
            }
            const promises = Array.from({
                length: pools.capacity
            }, (_, i)=>runWithPoolOrThrow(i));
            const results = await Promise.allSettled(promises);
            const fetcheds = new Map();
            const counters = new Map();
            for (const result of results){
                if (result.status === "rejected") continue;
                if (result.value.isErr()) continue;
                if (init === null || init === void 0 ? void 0 : init.noCheck) return result.value;
                const raw = JSON.stringify(result.value.inner);
                const previous = option_option/* Option */.W.wrap(counters.get(raw)).unwrapOr(0);
                counters.set(raw, previous + 1);
                fetcheds.set(raw, result.value);
            }
            /**
             * One truth -> return it
             * Zero truth -> throw AggregateError
             */ if (counters.size < 2) return await Promise.any(promises);
            console.warn("Different results from multiple circuits for ".concat(init.method, " on ").concat(ethereum.chain.name), {
                fetcheds
            });
            /**
             * Sort truths by occurence
             */ const sorteds = [
                ...maps/* Maps */.o.entries(counters)
            ].sort((a, b)=>b.value - a.value);
            /**
             * Two concurrent truths
             */ if (sorteds[0].value === sorteds[1].value) {
                console.warn("Could not choose truth for ".concat(init.method, " on ").concat(ethereum.chain.name));
                const random = Math.round(Math.random());
                return fetcheds.get(sorteds[random].key);
            }
            return fetcheds.get(sorteds[0].key);
        } catch (e) {
            return new fail/* Fail */.M(result_errors/* Catched */.$c.from(e));
        }
    }
    BgEthereumContext.fetchOrFail = fetchOrFail;
})(BgEthereumContext || (BgEthereumContext = {}));


/***/ }),

/***/ 2267:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   K: function() { return /* binding */ BgSeed; },
/* harmony export */   M: function() { return /* binding */ SeedRef; }
/* harmony export */ });
/* harmony import */ var _libs_glacier_mutators__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9949);
/* harmony import */ var _hazae41_glacier__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6233);
/* harmony import */ var _hazae41_glacier__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8123);


var SeedRef;
(function(SeedRef) {
    function from(seed) {
        return {
            ref: true,
            uuid: seed.uuid
        };
    }
    SeedRef.from = from;
})(SeedRef || (SeedRef = {}));
var BgSeed;
(function(BgSeed) {
    let All;
    (function(All) {
        All.key = "seeds";
        function schema(storage) {
            return (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_1__/* .createQuery */ .rP)({
                key: All.key,
                storage
            });
        }
        All.schema = schema;
    })(All = BgSeed.All || (BgSeed.All = {}));
    function key(uuid) {
        return "seed/".concat(uuid);
    }
    BgSeed.key = key;
    function schema(uuid, storage) {
        const indexer = async (states)=>{
            var _previous_real, _current_real;
            const { current, previous = current } = states;
            const previousData = (_previous_real = previous.real) === null || _previous_real === void 0 ? void 0 : _previous_real.data;
            const currentData = (_current_real = current.real) === null || _current_real === void 0 ? void 0 : _current_real.data;
            await All.schema(storage).mutate(_libs_glacier_mutators__WEBPACK_IMPORTED_MODULE_0__/* .Mutators */ .g.mapData(function() {
                let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : new _hazae41_glacier__WEBPACK_IMPORTED_MODULE_2__/* .Data */ .V([]);
                if ((previousData === null || previousData === void 0 ? void 0 : previousData.inner.uuid) === (currentData === null || currentData === void 0 ? void 0 : currentData.inner.uuid)) return d;
                if (previousData != null) d = d.mapSync((p)=>p.filter((x)=>x.uuid !== previousData.inner.uuid));
                if (currentData != null) d = d.mapSync((p)=>[
                        ...p,
                        SeedRef.from(currentData.inner)
                    ]);
                return d;
            }));
        };
        return (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_1__/* .createQuery */ .rP)({
            key: key(uuid),
            storage,
            indexer
        });
    }
    BgSeed.schema = schema;
})(BgSeed || (BgSeed = {}));


/***/ }),

/***/ 2534:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $: function() { return /* binding */ BgEthereum; },
/* harmony export */   f: function() { return /* binding */ BgTotal; }
/* harmony export */ });
/* harmony import */ var _libs_glacier_mutators__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9949);
/* harmony import */ var _hazae41_cubane__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8386);
/* harmony import */ var _hazae41_glacier__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6233);
/* harmony import */ var _hazae41_glacier__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8123);
/* harmony import */ var _hazae41_option__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5316);
/* harmony import */ var _context__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(580);





var BgEthereum;
(function(BgEthereum) {
    let Unknown;
    (function(Unknown) {
        function key(chainId, request) {
            const { method, params, noCheck } = request;
            return {
                chainId,
                method,
                params,
                noCheck
            };
        }
        Unknown.key = key;
        function schema(ethereum, request, storage) {
            const fetcher = async (request, more)=>await _context__WEBPACK_IMPORTED_MODULE_1__/* .BgEthereumContext */ .H.fetchOrFail(ethereum, request, more);
            return (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_2__/* .createQuery */ .rP)({
                key: key(ethereum.chain.chainId, request),
                fetcher,
                storage
            });
        }
        Unknown.schema = schema;
    })(Unknown = BgEthereum.Unknown || (BgEthereum.Unknown = {}));
})(BgEthereum || (BgEthereum = {}));
var BgTotal;
(function(BgTotal) {
    let Balance;
    (function(Balance) {
        let Priced;
        (function(Priced) {
            let ByAddress;
            (function(ByAddress) {
                let Record;
                (function(Record) {
                    function key(coin) {
                        return "totalPricedBalanceByWallet/".concat(coin);
                    }
                    Record.key = key;
                    function schema(coin, storage) {
                        const indexer = async (states)=>{
                            var _states_current_real_data, _states_current_real;
                            const values = _hazae41_option__WEBPACK_IMPORTED_MODULE_3__/* .Option */ .W.wrap((_states_current_real = states.current.real) === null || _states_current_real === void 0 ? void 0 : (_states_current_real_data = _states_current_real.data) === null || _states_current_real_data === void 0 ? void 0 : _states_current_real_data.inner).unwrapOr({});
                            const total = Object.values(values).reduce((x, y)=>_hazae41_cubane__WEBPACK_IMPORTED_MODULE_4__/* .Fixed */ .g.from(y).add(x), new _hazae41_cubane__WEBPACK_IMPORTED_MODULE_4__/* .Fixed */ .g(0n, 0));
                            const totalQuery = Priced.schema(coin, storage);
                            await totalQuery.mutate(_libs_glacier_mutators__WEBPACK_IMPORTED_MODULE_0__/* .Mutators */ .g.data(total));
                        };
                        return (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_2__/* .createQuery */ .rP)({
                            key: key(coin),
                            indexer,
                            storage
                        });
                    }
                    Record.schema = schema;
                })(Record = ByAddress.Record || (ByAddress.Record = {}));
                function key(address, coin) {
                    return "totalWalletPricedBalance/".concat(address, "/").concat(coin);
                }
                ByAddress.key = key;
                function schema(address, coin, storage) {
                    const indexer = async (states)=>{
                        var _states_current_real_data, _states_current_real;
                        const indexQuery = Record.schema(coin, storage);
                        const value = _hazae41_option__WEBPACK_IMPORTED_MODULE_3__/* .Option */ .W.wrap((_states_current_real = states.current.real) === null || _states_current_real === void 0 ? void 0 : (_states_current_real_data = _states_current_real.data) === null || _states_current_real_data === void 0 ? void 0 : _states_current_real_data.inner).unwrapOr(new _hazae41_cubane__WEBPACK_IMPORTED_MODULE_4__/* .Fixed */ .g(0n, 0));
                        await indexQuery.mutate(_libs_glacier_mutators__WEBPACK_IMPORTED_MODULE_0__/* .Mutators */ .g.mapInnerData((p)=>({
                                ...p,
                                [address]: value
                            }), new _hazae41_glacier__WEBPACK_IMPORTED_MODULE_5__/* .Data */ .V({})));
                    };
                    return (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_2__/* .createQuery */ .rP)({
                        key: key(address, coin),
                        indexer,
                        storage
                    });
                }
                ByAddress.schema = schema;
            })(ByAddress = Priced.ByAddress || (Priced.ByAddress = {}));
            function key(currency) {
                return "totalPricedBalance/".concat(currency);
            }
            Priced.key = key;
            function schema(currency, storage) {
                return (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_2__/* .createQuery */ .rP)({
                    key: key(currency),
                    storage
                });
            }
            Priced.schema = schema;
        })(Priced = Balance.Priced || (Balance.Priced = {}));
    })(Balance = BgTotal.Balance || (BgTotal.Balance = {}));
})(BgTotal || (BgTotal = {}));


/***/ }),

/***/ 7917:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   U: function() { return /* binding */ BgWallet; },
/* harmony export */   V: function() { return /* binding */ WalletRef; }
/* harmony export */ });
/* harmony import */ var _libs_glacier_mutators__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9949);
/* harmony import */ var _hazae41_glacier__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6233);
/* harmony import */ var _hazae41_glacier__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8123);


var WalletRef;
(function(WalletRef) {
    function create(uuid) {
        return {
            ref: true,
            uuid
        };
    }
    WalletRef.create = create;
    function from(wallet) {
        return create(wallet.uuid);
    }
    WalletRef.from = from;
})(WalletRef || (WalletRef = {}));
var BgWallet;
(function(BgWallet) {
    let All;
    (function(All) {
        let BySeed;
        (function(BySeed) {
            function key(uuid) {
                return "walletsBySeed/".concat(uuid);
            }
            BySeed.key = key;
            function schema(uuid, storage) {
                return (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_1__/* .createQuery */ .rP)({
                    key: key(uuid),
                    storage
                });
            }
            BySeed.schema = schema;
        })(BySeed = All.BySeed || (All.BySeed = {}));
        All.key = "wallets";
        function schema(storage) {
            return (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_1__/* .createQuery */ .rP)({
                key: All.key,
                storage
            });
        }
        All.schema = schema;
    })(All = BgWallet.All || (BgWallet.All = {}));
    function key(uuid) {
        return "wallet/".concat(uuid);
    }
    BgWallet.key = key;
    function schema(uuid, storage) {
        const indexer = async (states)=>{
            var _previous_real, _current_real;
            const { current, previous = current } = states;
            const previousData = (_previous_real = previous.real) === null || _previous_real === void 0 ? void 0 : _previous_real.data;
            const currentData = (_current_real = current.real) === null || _current_real === void 0 ? void 0 : _current_real.data;
            await All.schema(storage).mutate(_libs_glacier_mutators__WEBPACK_IMPORTED_MODULE_0__/* .Mutators */ .g.mapData(function() {
                let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : new _hazae41_glacier__WEBPACK_IMPORTED_MODULE_2__/* .Data */ .V([]);
                if ((previousData === null || previousData === void 0 ? void 0 : previousData.inner.uuid) === (currentData === null || currentData === void 0 ? void 0 : currentData.inner.uuid)) return d;
                if (previousData != null) d = d.mapSync((p)=>p.filter((x)=>x.uuid !== previousData.inner.uuid));
                if (currentData != null) d = d.mapSync((p)=>[
                        ...p,
                        WalletRef.from(currentData.inner)
                    ]);
                return d;
            }));
            if ((currentData === null || currentData === void 0 ? void 0 : currentData.inner.type) === "seeded") {
                const { seed } = currentData.inner;
                const walletsBySeedQuery = All.BySeed.schema(seed.uuid, storage);
                await walletsBySeedQuery.mutate(_libs_glacier_mutators__WEBPACK_IMPORTED_MODULE_0__/* .Mutators */ .g.mapData(function() {
                    let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : new _hazae41_glacier__WEBPACK_IMPORTED_MODULE_2__/* .Data */ .V([]);
                    if ((previousData === null || previousData === void 0 ? void 0 : previousData.inner.uuid) === (currentData === null || currentData === void 0 ? void 0 : currentData.inner.uuid)) return d;
                    if (previousData != null) d = d.mapSync((p)=>p.filter((x)=>x.uuid !== previousData.inner.uuid));
                    if (currentData != null) d = d.mapSync((p)=>[
                            ...p,
                            WalletRef.from(currentData.inner)
                        ]);
                    return d;
                }));
            }
        };
        return (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_1__/* .createQuery */ .rP)({
            key: key(uuid),
            indexer,
            storage
        });
    }
    BgWallet.schema = schema;
})(BgWallet || (BgWallet = {}));


/***/ }),

/***/ 797:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  aZ: function() { return /* binding */ useEnsLookup; },
  DB: function() { return /* binding */ useEnsReverse; },
  yh: function() { return /* binding */ useEnsReverseNoFetch; }
});

// UNUSED EXPORTS: FgEns

// EXTERNAL MODULE: ./src/libs/errors/errors.ts
var errors = __webpack_require__(8524);
// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/abi/signature/signature.mjs + 4 modules
var signature = __webpack_require__(6403);
// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/abi/types/function/function.mjs
var function_function = __webpack_require__(7205);
// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/abi/types/tuple/tuple.mjs
var tuple = __webpack_require__(5444);
// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/abi/types/bytes/static.mjs
var bytes_static = __webpack_require__(9914);
;// CONCATENATED MODULE: ./src/libs/abi/ens.abi.ts

var EnsAbi;
(function(EnsAbi) {
    EnsAbi.resolver = signature/* createFunctionSignature */.a("resolver", function_function/* createFunctionSelectorAndArguments */.VU(function_function/* FunctionSelector */.xS.from([
        1,
        120,
        184,
        191
    ]), tuple/* createTuple */.VS(bytes_static/* Bytes32 */.HM)));
    EnsAbi.addr = signature/* createFunctionSignature */.a("addr", function_function/* createFunctionSelectorAndArguments */.VU(function_function/* FunctionSelector */.xS.from([
        59,
        59,
        87,
        222
    ]), tuple/* createTuple */.VS(bytes_static/* Bytes32 */.HM)));
    EnsAbi.name = signature/* createFunctionSignature */.a("name", function_function/* createFunctionSelectorAndArguments */.VU(function_function/* FunctionSelector */.xS.from([
        105,
        31,
        52,
        49
    ]), tuple/* createTuple */.VS(bytes_static/* Bytes32 */.HM)));
})(EnsAbi || (EnsAbi = {}));

// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/abi/encode.mjs
var encode = __webpack_require__(6167);
// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/abi/types/address/address.mjs
var address_address = __webpack_require__(3831);
// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/abi/decode.mjs + 1 modules
var decode = __webpack_require__(7817);
// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/ens/index.mjs + 2 modules
var ens = __webpack_require__(2412);
// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/abi/types/string/string.mjs
var string = __webpack_require__(3997);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/fetched/data.mjs
var fetched_data = __webpack_require__(8123);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/fetched/fail.mjs
var fail = __webpack_require__(9164);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/queries/simple/query.mjs
var query = __webpack_require__(6233);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/errors.mjs
var result_errors = __webpack_require__(2564);
// EXTERNAL MODULE: ./src/mods/background/service_worker/context.ts + 1 modules
var context = __webpack_require__(580);
;// CONCATENATED MODULE: ./src/mods/background/service_worker/entities/names/data.ts





var BgEns;
(function(BgEns) {
    let Resolver;
    (function(Resolver) {
        async function fetchOrFail(ethereum, namehash, more) {
            try {
                const registry = "0x00000000000C2E074eC69A0dFb2997BA6C7d2e1e";
                const data = encode/* encodeOrThrow */.YM(EnsAbi.resolver.from(namehash));
                const fetched = await context/* BgEthereumContext */.H.fetchOrFail(ethereum, {
                    method: "eth_call",
                    params: [
                        {
                            to: registry,
                            data: data
                        },
                        "pending"
                    ]
                }, more);
                if (fetched.isErr()) return fetched;
                const returns = tuple/* createTuple */.VS(address_address/* Address */.kL);
                const [address] = decode/* decodeOrThrow */.Dt(returns, fetched.inner).intoOrThrow();
                return new fetched_data/* Data */.V(address);
            } catch (e) {
                return new fail/* Fail */.M(result_errors/* Catched */.$c.from(e));
            }
        }
        Resolver.fetchOrFail = fetchOrFail;
    })(Resolver = BgEns.Resolver || (BgEns.Resolver = {}));
    let Lookup;
    (function(Lookup) {
        Lookup.method = "ens_lookup";
        function key(name) {
            return {
                chainId: 1,
                method: Lookup.method,
                params: [
                    name
                ]
            };
        }
        Lookup.key = key;
        async function parseOrThrow(ethereum, request, storage) {
            const [name] = request.params;
            return schema(ethereum, name, storage);
        }
        Lookup.parseOrThrow = parseOrThrow;
        function schema(ethereum, name, storage) {
            const fetcher = (key, more)=>fetchOrFail(ethereum, name, more);
            return (0,query/* createQuery */.rP)({
                key: key(name),
                fetcher,
                storage
            });
        }
        Lookup.schema = schema;
        async function fetchOrFail(ethereum, name, more) {
            try {
                const namehash = ens/* namehashOrThrow */.Ez(name);
                const resolver = await Resolver.fetchOrFail(ethereum, namehash, more);
                if (resolver.isErr()) return resolver;
                const data = encode/* encodeOrThrow */.YM(EnsAbi.addr.from(namehash));
                const fetched = await context/* BgEthereumContext */.H.fetchOrFail(ethereum, {
                    method: "eth_call",
                    params: [
                        {
                            to: resolver.inner,
                            data: data
                        },
                        "pending"
                    ]
                }, more);
                if (fetched.isErr()) return fetched;
                const returns = tuple/* createTuple */.VS(address_address/* Address */.kL);
                const [address] = decode/* decodeOrThrow */.Dt(returns, fetched.inner).intoOrThrow();
                return new fetched_data/* Data */.V(address);
            } catch (e) {
                return new fail/* Fail */.M(result_errors/* Catched */.$c.from(e));
            }
        }
        Lookup.fetchOrFail = fetchOrFail;
    })(Lookup = BgEns.Lookup || (BgEns.Lookup = {}));
    let Reverse;
    (function(Reverse) {
        Reverse.method = "ens_reverse";
        function key(address) {
            return {
                chainId: 1,
                method: Reverse.method,
                params: [
                    address
                ]
            };
        }
        Reverse.key = key;
        async function parseOrThrow(ethereum, request, storage) {
            const [address] = request.params;
            return schema(ethereum, address, storage);
        }
        Reverse.parseOrThrow = parseOrThrow;
        function schema(ethereum, address, storage) {
            const fetcher = (key, more)=>fetchOrFail(ethereum, address, more);
            return (0,query/* createQuery */.rP)({
                key: key(address),
                fetcher,
                storage
            });
        }
        Reverse.schema = schema;
        async function fetchUncheckedOrFail(ethereum, address, more) {
            try {
                const namehash = ens/* namehashOrThrow */.Ez("".concat(address.slice(2), ".addr.reverse"));
                const resolver = await Resolver.fetchOrFail(ethereum, namehash, more);
                if (resolver.isErr()) return resolver;
                const data = encode/* encodeOrThrow */.YM(EnsAbi.name.from(namehash));
                const fetched = await context/* BgEthereumContext */.H.fetchOrFail(ethereum, {
                    method: "eth_call",
                    params: [
                        {
                            to: resolver.inner,
                            data: data
                        },
                        "pending"
                    ]
                }, more);
                if (fetched.isErr()) return fetched;
                const returns = tuple/* createTuple */.VS(string/* String */.L);
                const [name] = decode/* decodeOrThrow */.Dt(returns, fetched.inner).intoOrThrow();
                if (name.length === 0) return new fetched_data/* Data */.V(undefined);
                return new fetched_data/* Data */.V(name);
            } catch (e) {
                return new fail/* Fail */.M(result_errors/* Catched */.$c.from(e));
            }
        }
        Reverse.fetchUncheckedOrFail = fetchUncheckedOrFail;
        async function fetchOrFail(ethereum, address, more) {
            const name = await fetchUncheckedOrFail(ethereum, address, more);
            if (name.isErr()) return name;
            if (name.inner == null) return name;
            const address2 = await Lookup.fetchOrFail(ethereum, name.inner, more);
            if (address2.isErr()) return address2;
            if (address.toLowerCase() !== address2.inner.toLowerCase()) return new fetched_data/* Data */.V(undefined);
            return name;
        }
        Reverse.fetchOrFail = fetchOrFail;
    })(Reverse = BgEns.Reverse || (BgEns.Reverse = {}));
})(BgEns || (BgEns = {}));

// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/react/hooks/queries/simple.mjs + 1 modules
var simple = __webpack_require__(564);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/react/hooks/blocks/use-fetch.mjs
var use_fetch = __webpack_require__(4704);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/react/hooks/blocks/use-visible.mjs
var use_visible = __webpack_require__(7836);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/react/hooks/blocks/use-error.mjs
var use_error = __webpack_require__(3399);
// EXTERNAL MODULE: ./src/mods/foreground/storage/storage.ts
var storage_storage = __webpack_require__(604);
// EXTERNAL MODULE: ./src/mods/foreground/storage/user.tsx
var user = __webpack_require__(9718);
// EXTERNAL MODULE: ./src/mods/foreground/entities/wallets/data.ts
var data = __webpack_require__(9327);
;// CONCATENATED MODULE: ./src/mods/foreground/entities/names/data.ts






var FgEns;
(function(FgEns) {
    let Lookup;
    (function(Lookup) {
        Lookup.key = BgEns.Lookup.key;
        function schema(name, context, storage) {
            if (context == null) return;
            if (name == null) return;
            const fetcher = async (request)=>await (0,data/* fetchOrFail */.yR)(request, context);
            return (0,query/* createQuery */.rP)({
                key: BgEns.Lookup.key(name),
                fetcher,
                storage
            });
        }
        Lookup.schema = schema;
    })(Lookup = FgEns.Lookup || (FgEns.Lookup = {}));
    let Reverse;
    (function(Reverse) {
        function schema(address, context, storage) {
            if (context == null) return;
            if (address == null) return;
            const fetcher = async (request)=>await (0,data/* fetchOrFail */.yR)(request, context);
            return (0,query/* createQuery */.rP)({
                key: BgEns.Reverse.key(address),
                fetcher,
                storage
            });
        }
        Reverse.schema = schema;
    })(Reverse = FgEns.Reverse || (FgEns.Reverse = {}));
})(FgEns || (FgEns = {}));
function useEnsLookup(name, ethereum) {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(FgEns.Lookup.schema, [
        name,
        ethereum,
        storage
    ]);
    (0,use_fetch/* useFetch */.i)(query);
    (0,use_visible/* useVisible */.E)(query);
    (0,storage_storage/* useSubscribe */.Q)(query, storage);
    (0,use_error/* useError */.V)(query, errors/* Errors */.D.onQueryError);
    return query;
}
function useEnsReverse(address, ethereum) {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(FgEns.Reverse.schema, [
        address,
        ethereum,
        storage
    ]);
    (0,use_fetch/* useFetch */.i)(query);
    (0,use_visible/* useVisible */.E)(query);
    (0,storage_storage/* useSubscribe */.Q)(query, storage);
    (0,use_error/* useError */.V)(query, errors/* Errors */.D.onQueryError);
    return query;
}
/**
 * Used in the wallet list to display the ens name
 * @param address
 * @param ethereum
 * @returns
 */ function useEnsReverseNoFetch(address, ethereum) {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(FgEns.Reverse.schema, [
        address,
        ethereum,
        storage
    ]);
    (0,storage_storage/* useSubscribe */.Q)(query, storage);
    return query;
}


/***/ }),

/***/ 7440:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Vd: function() { return /* binding */ useAppRequest; },
  fU: function() { return /* binding */ useAppRequests; }
});

// UNUSED EXPORTS: FgAppRequest

// EXTERNAL MODULE: ./src/libs/glacier/mutators.ts
var mutators = __webpack_require__(9949);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/queries/simple/query.mjs
var query = __webpack_require__(6233);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/fetched/data.mjs
var data = __webpack_require__(8123);
;// CONCATENATED MODULE: ./src/mods/background/service_worker/entities/requests/data.tsx


var AppRequestRef;
(function(AppRequestRef) {
    function from(request) {
        return {
            ref: true,
            id: request.id
        };
    }
    AppRequestRef.from = from;
})(AppRequestRef || (AppRequestRef = {}));
var BgAppRequest;
(function(BgAppRequest) {
    let All;
    (function(All) {
        All.key = "requests";
        function schema() {
            return (0,query/* createQuery */.rP)({
                key: All.key
            });
        }
        All.schema = schema;
    })(All = BgAppRequest.All || (BgAppRequest.All = {}));
    function key(id) {
        return "request/".concat(id);
    }
    BgAppRequest.key = key;
    function schema(id) {
        const indexer = async (states)=>{
            var _previous_real, _current_real;
            const { current, previous = current } = states;
            const previousData = (_previous_real = previous.real) === null || _previous_real === void 0 ? void 0 : _previous_real.data;
            const currentData = (_current_real = current.real) === null || _current_real === void 0 ? void 0 : _current_real.data;
            await BgAppRequest.All.schema().mutate(mutators/* Mutators */.g.mapData(function() {
                let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : new data/* Data */.V([]);
                if ((previousData === null || previousData === void 0 ? void 0 : previousData.inner.id) === (currentData === null || currentData === void 0 ? void 0 : currentData.inner.id)) return d;
                if (previousData != null) d = d.mapSync((p)=>p.filter((x)=>x.id !== previousData.inner.id));
                if (currentData != null) d = d.mapSync((p)=>[
                        ...p,
                        AppRequestRef.from(currentData.inner)
                    ]);
                return d;
            }));
        };
        return (0,query/* createQuery */.rP)({
            key: key(id),
            indexer
        });
    }
    BgAppRequest.schema = schema;
})(BgAppRequest || (BgAppRequest = {}));

// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/react/hooks/queries/simple.mjs + 1 modules
var simple = __webpack_require__(564);
// EXTERNAL MODULE: ./src/mods/foreground/storage/storage.ts
var storage_storage = __webpack_require__(604);
// EXTERNAL MODULE: ./src/mods/foreground/storage/user.tsx
var user = __webpack_require__(9718);
;// CONCATENATED MODULE: ./src/mods/foreground/entities/requests/data.tsx





var FgAppRequest;
(function(FgAppRequest) {
    let All;
    (function(All) {
        All.key = BgAppRequest.All.key;
        function schema(storage) {
            return (0,query/* createQuery */.rP)({
                key: All.key,
                storage
            });
        }
        All.schema = schema;
    })(All = FgAppRequest.All || (FgAppRequest.All = {}));
    FgAppRequest.key = BgAppRequest.key;
    function schema(id, storage) {
        if (id == null) return;
        const indexer = async (states)=>{
            var _previous_real, _current_real;
            const { current, previous = current } = states;
            const previousData = (_previous_real = previous.real) === null || _previous_real === void 0 ? void 0 : _previous_real.data;
            const currentData = (_current_real = current.real) === null || _current_real === void 0 ? void 0 : _current_real.data;
            await All.schema(storage).mutate(mutators/* Mutators */.g.mapData(function() {
                let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : new data/* Data */.V([]);
                if ((previousData === null || previousData === void 0 ? void 0 : previousData.inner.id) === (currentData === null || currentData === void 0 ? void 0 : currentData.inner.id)) return d;
                if (previousData != null) d = d.mapSync((p)=>p.filter((x)=>x.id !== previousData.inner.id));
                if (currentData != null) d = d.mapSync((p)=>[
                        ...p,
                        AppRequestRef.from(currentData.inner)
                    ]);
                return d;
            }));
        };
        return (0,query/* createQuery */.rP)({
            key: FgAppRequest.key(id),
            indexer,
            storage
        });
    }
    FgAppRequest.schema = schema;
})(FgAppRequest || (FgAppRequest = {}));
function useAppRequest(id) {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(FgAppRequest.schema, [
        id,
        storage
    ]);
    (0,storage_storage/* useSubscribe */.Q)(query, storage);
    return query;
}
function useAppRequests() {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(FgAppRequest.All.schema, [
        storage
    ]);
    (0,storage_storage/* useSubscribe */.Q)(query, storage);
    return query;
}


/***/ }),

/***/ 5867:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Gz: function() { return /* binding */ SeedInstance; }
});

// UNUSED EXPORTS: AuthMnemonicSeedInstance, LedgerSeedInstance, UnauthMnemonicSeedInstance

// EXTERNAL MODULE: ./node_modules/@hazae41/base16/dist/esm/src/mods/base16/adapter.mjs
var adapter = __webpack_require__(2248);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/result.mjs
var result = __webpack_require__(918);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/ok.mjs
var ok = __webpack_require__(5591);
;// CONCATENATED MODULE: ./src/libs/ethereum/mods/signature.ts


var Hex;
(function(Hex) {
    function pad(text) {
        return text.padStart(text.length + text.length % 2, "0");
    }
    Hex.pad = pad;
})(Hex || (Hex = {}));
var Signature;
(function(Signature) {
    function tryFrom(init) {
        return result/* Result */.x.unthrowSync((t)=>{
            const { v, r, s } = init;
            const hv = Hex.pad(v.toString(16));
            const hr = adapter/* get */.U().tryEncode(r).throw(t);
            const hs = adapter/* get */.U().tryEncode(s).throw(t);
            return new ok.Ok("0x".concat(hr).concat(hs).concat(hv));
        });
    }
    Signature.tryFrom = tryFrom;
})(Signature || (Signature = {}));

// EXTERNAL MODULE: ./src/libs/ledger/index.ts + 9 modules
var ledger = __webpack_require__(6919);
// EXTERNAL MODULE: ./src/libs/webauthn/webauthn.ts
var webauthn = __webpack_require__(299);
// EXTERNAL MODULE: ./node_modules/@hazae41/base64/dist/esm/src/mods/base64/adapter.mjs
var base64_adapter = __webpack_require__(9467);
// EXTERNAL MODULE: ./node_modules/@hazae41/bytes/dist/esm/mods/bytes/bytes.mjs + 3 modules
var bytes = __webpack_require__(1694);
// EXTERNAL MODULE: ./node_modules/@hazae41/option/dist/esm/mods/option/option.mjs
var option_option = __webpack_require__(5316);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/errors.mjs
var errors = __webpack_require__(2564);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/err.mjs
var err = __webpack_require__(166);
// EXTERNAL MODULE: ./node_modules/@scure/bip32/lib/esm/index.js + 15 modules
var esm = __webpack_require__(1141);
// EXTERNAL MODULE: ./node_modules/@scure/bip39/esm/index.js
var bip39_esm = __webpack_require__(4857);
// EXTERNAL MODULE: ./node_modules/@scure/bip39/esm/wordlists/english.js
var english = __webpack_require__(5957);
// EXTERNAL MODULE: ./node_modules/ethers/lib.esm/wallet/wallet.js + 35 modules
var wallet = __webpack_require__(8884);
// EXTERNAL MODULE: ./node_modules/ethers/lib.esm/hash/typed-data.js
var typed_data = __webpack_require__(1386);
;// CONCATENATED MODULE: ./src/mods/foreground/entities/seeds/all/helpers.tsx












var SeedInstance;
(function(SeedInstance) {
    async function tryFrom(seed, background) {
        if (seed.type === "mnemonic") return new ok.Ok(new UnauthMnemonicSeedInstance(seed));
        if (seed.type === "authMnemonic") return new ok.Ok(new AuthMnemonicSeedInstance(seed));
        if (seed.type === "ledger") return new ok.Ok(new LedgerSeedInstance(seed));
        throw new errors/* Panic */.F5();
    }
    SeedInstance.tryFrom = tryFrom;
})(SeedInstance || (SeedInstance = {}));
class UnauthMnemonicSeedInstance {
    async tryGetMnemonic(background) {
        return new ok.Ok(this.data.mnemonic);
    }
    async tryGetPrivateKey(path, background) {
        return await result/* Result */.x.unthrow(async (t)=>{
            const mnemonic = await this.tryGetMnemonic(background).then((r)=>r.throw(t));
            const masterSeed = await (0,bip39_esm/* mnemonicToSeed */.OI)(mnemonic);
            const root = esm/* HDKey */.B.fromMasterSeed(masterSeed);
            const child = root.derive(path);
            const privateKeyBytes = option_option/* Option */.W.wrap(child.privateKey).ok().throw(t);
            return new ok.Ok("0x".concat(adapter/* get */.U().tryEncode(privateKeyBytes).throw(t)));
        });
    }
    async trySignPersonalMessage(path, message, background) {
        return await result/* Result */.x.unthrow(async (t)=>{
            const privateKey = await this.tryGetPrivateKey(path, background).then((r)=>r.throw(t));
            const signature = await result/* Result */.x.runAndDoubleWrap(async ()=>{
                return await new wallet/* Wallet */.w(privateKey).signMessage(message);
            }).then((r)=>r.throw(t));
            return new ok.Ok(signature);
        });
    }
    async trySignTransaction(path, transaction, background) {
        return await result/* Result */.x.unthrow(async (t)=>{
            const privateKey = await this.tryGetPrivateKey(path, background).then((r)=>r.throw(t));
            const signature = result/* Result */.x.runAndDoubleWrapSync(()=>{
                return new wallet/* Wallet */.w(privateKey).signingKey.sign(transaction.unsignedHash).serialized;
            }).throw(t);
            return new ok.Ok(signature);
        });
    }
    async trySignEIP712HashedMessage(path, data, background) {
        return await result/* Result */.x.unthrow(async (t)=>{
            const privateKey = await this.tryGetPrivateKey(path, background).then((r)=>r.throw(t));
            delete data.types["EIP712Domain"];
            const signature = await result/* Result */.x.runAndDoubleWrap(async ()=>{
                return await new wallet/* Wallet */.w(privateKey).signTypedData(data.domain, data.types, data.message);
            }).then((r)=>r.throw(t));
            return new ok.Ok(signature);
        });
    }
    constructor(data){
        this.data = data;
    }
}
class AuthMnemonicSeedInstance {
    async tryGetMnemonic(background) {
        return await result/* Result */.x.unthrow(async (t)=>{
            const { idBase64, ivBase64 } = this.data.mnemonic;
            const id = base64_adapter/* get */.U().tryDecodePadded(idBase64).throw(t).copyAndDispose();
            const cipher = await webauthn/* WebAuthnStorage */.g.tryGet(id).then((r)=>r.throw(t));
            const cipherBase64 = base64_adapter/* get */.U().tryEncodePadded(cipher).throw(t);
            const entropyBase64 = await background.tryRequest({
                method: "brume_decrypt",
                params: [
                    ivBase64,
                    cipherBase64
                ]
            }).then((r)=>r.throw(t).throw(t));
            const entropy = base64_adapter/* get */.U().tryDecodePadded(entropyBase64).throw(t).copyAndDispose();
            return new ok.Ok((0,bip39_esm/* entropyToMnemonic */.JJ)(entropy, english/* wordlist */.U));
        });
    }
    async tryGetPrivateKey(path, background) {
        return await result/* Result */.x.unthrow(async (t)=>{
            const mnemonic = await this.tryGetMnemonic(background).then((r)=>r.throw(t));
            const masterSeed = await (0,bip39_esm/* mnemonicToSeed */.OI)(mnemonic);
            const root = esm/* HDKey */.B.fromMasterSeed(masterSeed);
            const child = root.derive(path);
            const privateKeyBytes = option_option/* Option */.W.wrap(child.privateKey).ok().throw(t);
            return new ok.Ok("0x".concat(adapter/* get */.U().tryEncode(privateKeyBytes).throw(t)));
        });
    }
    async trySignPersonalMessage(path, message, background) {
        return await result/* Result */.x.unthrow(async (t)=>{
            const privateKey = await this.tryGetPrivateKey(path, background).then((r)=>r.throw(t));
            const signature = await result/* Result */.x.runAndDoubleWrap(async ()=>{
                return await new wallet/* Wallet */.w(privateKey).signMessage(message);
            }).then((r)=>r.throw(t));
            return new ok.Ok(signature);
        });
    }
    async trySignTransaction(path, transaction, background) {
        return await result/* Result */.x.unthrow(async (t)=>{
            const privateKey = await this.tryGetPrivateKey(path, background).then((r)=>r.throw(t));
            const signature = result/* Result */.x.runAndDoubleWrapSync(()=>{
                return new wallet/* Wallet */.w(privateKey).signingKey.sign(transaction.unsignedHash).serialized;
            }).throw(t);
            return new ok.Ok(signature);
        });
    }
    async trySignEIP712HashedMessage(path, data, background) {
        return await result/* Result */.x.unthrow(async (t)=>{
            const privateKey = await this.tryGetPrivateKey(path, background).then((r)=>r.throw(t));
            delete data.types["EIP712Domain"];
            const signature = await result/* Result */.x.runAndDoubleWrap(async ()=>{
                return await new wallet/* Wallet */.w(privateKey).signTypedData(data.domain, data.types, data.message);
            }).then((r)=>r.throw(t));
            return new ok.Ok(signature);
        });
    }
    constructor(data){
        this.data = data;
    }
}
class LedgerSeedInstance {
    async tryGetMnemonic(background) {
        return new err/* Err */.U(new errors/* Unimplemented */.iJ());
    }
    async tryGetPrivateKey(path, background) {
        return new err/* Err */.U(new errors/* Unimplemented */.iJ());
    }
    async trySignPersonalMessage(path, message, background) {
        return await result/* Result */.x.unthrow(async (t)=>{
            const device = await ledger/* Ledger.USB.tryConnect */.P.vB.tryConnect().then((r)=>r.throw(t));
            const signature = await ledger/* Ledger.Ethereum.trySignPersonalMessage */.P.kJ.trySignPersonalMessage(device, path.slice(2), bytes/* Bytes */.J.fromUtf8(message)).then((r)=>r.throw(t));
            return Signature.tryFrom(signature);
        });
    }
    async trySignTransaction(path, transaction, background) {
        return await result/* Result */.x.unthrow(async (t)=>{
            const device = await ledger/* Ledger.USB.tryConnect */.P.vB.tryConnect().then((r)=>r.throw(t));
            const signature = await ledger/* Ledger.Ethereum.trySignTransaction */.P.kJ.trySignTransaction(device, path.slice(2), transaction).then((r)=>r.throw(t));
            return Signature.tryFrom(signature);
        });
    }
    async trySignEIP712HashedMessage(path, data, background) {
        return await result/* Result */.x.unthrow(async (t)=>{
            const device = await ledger/* Ledger.USB.tryConnect */.P.vB.tryConnect().then((r)=>r.throw(t));
            delete data.types["EIP712Domain"];
            const encoder = result/* Result */.x.runAndDoubleWrapSync(()=>{
                return new typed_data/* TypedDataEncoder */.E(data.types);
            }).throw(t);
            const domain = result/* Result */.x.runAndDoubleWrapSync(()=>{
                return adapter/* get */.U().tryPadStartAndDecode(typed_data/* TypedDataEncoder */.E.hashDomain(data.domain).slice(2)).unwrap().copyAndDispose();
            }).throw(t);
            const message = result/* Result */.x.runAndDoubleWrapSync(()=>{
                return adapter/* get */.U().tryPadStartAndDecode(encoder.hashStruct(data.primaryType, data.message).slice(2)).unwrap().copyAndDispose();
            }).throw(t);
            const signature = await ledger/* Ledger.Ethereum.trySignEIP712HashedMessage */.P.kJ.trySignEIP712HashedMessage(device, path.slice(2), domain, message).then((r)=>r.throw(t));
            return Signature.tryFrom(signature);
        });
    }
    constructor(data){
        this.data = data;
    }
}


/***/ }),

/***/ 253:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   EU: function() { return /* binding */ FgSeed; },
/* harmony export */   Eu: function() { return /* binding */ useSeeds; },
/* harmony export */   WJ: function() { return /* binding */ useSeed; }
/* harmony export */ });
/* harmony import */ var _libs_glacier_mutators__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9949);
/* harmony import */ var _mods_background_service_worker_entities_seeds_data__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2267);
/* harmony import */ var _hazae41_glacier__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6233);
/* harmony import */ var _hazae41_glacier__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8123);
/* harmony import */ var _hazae41_glacier__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(564);
/* harmony import */ var _storage_storage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(604);
/* harmony import */ var _storage_user__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9718);





var FgSeed;
(function(FgSeed) {
    let All;
    (function(All) {
        All.key = _mods_background_service_worker_entities_seeds_data__WEBPACK_IMPORTED_MODULE_1__/* .BgSeed */ .K.All.key;
        function schema(storage) {
            return (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_4__/* .createQuery */ .rP)({
                key: All.key,
                storage
            });
        }
        All.schema = schema;
    })(All = FgSeed.All || (FgSeed.All = {}));
    FgSeed.key = _mods_background_service_worker_entities_seeds_data__WEBPACK_IMPORTED_MODULE_1__/* .BgSeed */ .K.key;
    function schema(uuid, storage) {
        if (uuid == null) return;
        const indexer = async (states)=>{
            var _previous_real, _current_real;
            const { current, previous = current } = states;
            const previousData = (_previous_real = previous.real) === null || _previous_real === void 0 ? void 0 : _previous_real.data;
            const currentData = (_current_real = current.real) === null || _current_real === void 0 ? void 0 : _current_real.data;
            await All.schema(storage).mutate(_libs_glacier_mutators__WEBPACK_IMPORTED_MODULE_0__/* .Mutators */ .g.mapData(function() {
                let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : new _hazae41_glacier__WEBPACK_IMPORTED_MODULE_5__/* .Data */ .V([]);
                if ((previousData === null || previousData === void 0 ? void 0 : previousData.inner.uuid) === (currentData === null || currentData === void 0 ? void 0 : currentData.inner.uuid)) return d;
                if (previousData != null) d = d.mapSync((p)=>p.filter((x)=>x.uuid !== previousData.inner.uuid));
                if (currentData != null) d = d.mapSync((p)=>[
                        ...p,
                        _mods_background_service_worker_entities_seeds_data__WEBPACK_IMPORTED_MODULE_1__/* .SeedRef */ .M.from(currentData.inner)
                    ]);
                return d;
            }));
        };
        return (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_4__/* .createQuery */ .rP)({
            key: FgSeed.key(uuid),
            indexer,
            storage
        });
    }
    FgSeed.schema = schema;
})(FgSeed || (FgSeed = {}));
function useSeed(uuid) {
    const storage = (0,_storage_user__WEBPACK_IMPORTED_MODULE_3__/* .useUserStorageContext */ .v6)().unwrap();
    const query = (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_6__/* .useQuery */ .aM)(FgSeed.schema, [
        uuid,
        storage
    ]);
    (0,_storage_storage__WEBPACK_IMPORTED_MODULE_2__/* .useSubscribe */ .Q)(query, storage);
    return query;
}
function useSeeds() {
    const storage = (0,_storage_user__WEBPACK_IMPORTED_MODULE_3__/* .useUserStorageContext */ .v6)().unwrap();
    const query = (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_6__/* .useQuery */ .aM)(FgSeed.All.schema, [
        storage
    ]);
    (0,_storage_storage__WEBPACK_IMPORTED_MODULE_2__/* .useSubscribe */ .Q)(query, storage);
    return query;
}


/***/ }),

/***/ 5743:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  k: function() { return /* binding */ useSession; }
});

// UNUSED EXPORTS: FgSession

// EXTERNAL MODULE: ./src/libs/glacier/mutators.ts
var mutators = __webpack_require__(9949);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/queries/simple/query.mjs
var query = __webpack_require__(6233);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/fetched/data.mjs
var data = __webpack_require__(8123);
;// CONCATENATED MODULE: ./src/mods/background/service_worker/entities/sessions/data.ts


var SessionRef;
(function(SessionRef) {
    function from(session) {
        return {
            ref: true,
            id: session.id,
            origin: session.origin
        };
    }
    SessionRef.from = from;
})(SessionRef || (SessionRef = {}));
class SessionStorage {
    getOrThrow(cacheKey) {
        return this.storage.getOrThrow(cacheKey);
    }
    setOrThrow(cacheKey, value) {
        var _value_data;
        if ((value === null || value === void 0 ? void 0 : (_value_data = value.data) === null || _value_data === void 0 ? void 0 : _value_data.data.persist) === false) return;
        return this.storage.setOrThrow(cacheKey, value);
    }
    constructor(storage){
        this.storage = storage;
    }
}
var BgSession;
(function(BgSession) {
    let All;
    (function(All) {
        let Temporary;
        (function(Temporary) {
            let ByWallet;
            (function(ByWallet) {
                function key(wallet) {
                    return "temporarySessionsByWallet/v2/".concat(wallet);
                }
                ByWallet.key = key;
                function schema(wallet) {
                    return (0,query/* createQuery */.rP)({
                        key: key(wallet)
                    });
                }
                ByWallet.schema = schema;
            })(ByWallet = Temporary.ByWallet || (Temporary.ByWallet = {}));
            Temporary.key = "temporarySessions/v2";
            function schema() {
                return (0,query/* createQuery */.rP)({
                    key: Temporary.key
                });
            }
            Temporary.schema = schema;
        })(Temporary = All.Temporary || (All.Temporary = {}));
        let Persistent;
        (function(Persistent) {
            let ByWallet;
            (function(ByWallet) {
                function key(wallet) {
                    return "persistentSessionsByWallet/v2/".concat(wallet);
                }
                ByWallet.key = key;
                function schema(wallet, storage) {
                    return (0,query/* createQuery */.rP)({
                        key: key(wallet),
                        storage
                    });
                }
                ByWallet.schema = schema;
            })(ByWallet = Persistent.ByWallet || (Persistent.ByWallet = {}));
            Persistent.key = "persistentSessions/v2";
            function schema(storage) {
                return (0,query/* createQuery */.rP)({
                    key: Persistent.key,
                    storage
                });
            }
            Persistent.schema = schema;
        })(Persistent = All.Persistent || (All.Persistent = {}));
    })(All = BgSession.All || (BgSession.All = {}));
    let ByOrigin;
    (function(ByOrigin) {
        function key(origin) {
            return "sessionByOrigin/".concat(origin);
        }
        ByOrigin.key = key;
        function schema(origin, storage) {
            return (0,query/* createQuery */.rP)({
                key: key(origin),
                storage
            });
        }
        ByOrigin.schema = schema;
    })(ByOrigin = BgSession.ByOrigin || (BgSession.ByOrigin = {}));
    function key(id) {
        return "session/v4/".concat(id);
    }
    BgSession.key = key;
    function schema(id, storage) {
        const indexer = async (states)=>{
            var _previous_real, _current_real;
            const { current, previous = current } = states;
            const previousData = (_previous_real = previous.real) === null || _previous_real === void 0 ? void 0 : _previous_real.data;
            const currentData = (_current_real = current.real) === null || _current_real === void 0 ? void 0 : _current_real.data;
            if (previousData != null) {
                if (previousData.inner.persist) {
                    const sessionByOrigin = ByOrigin.schema(previousData.inner.origin, storage);
                    await sessionByOrigin.delete();
                }
                const sessionsQuery = previousData.inner.persist ? All.Persistent.schema(storage) : All.Temporary.schema();
                await sessionsQuery.mutate(mutators/* Mutators */.g.mapData(function() {
                    let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : new data/* Data */.V([]);
                    return d.mapSync((p)=>p.filter((x)=>x.id !== previousData.inner.id));
                }));
                const previousWallets = new Set(previousData.inner.wallets);
                for (const wallet of previousWallets){
                    const sessionsByWalletQuery = previousData.inner.persist ? All.Persistent.ByWallet.schema(wallet.uuid, storage) : All.Temporary.ByWallet.schema(wallet.uuid);
                    await sessionsByWalletQuery.mutate(mutators/* Mutators */.g.mapData(function() {
                        let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : new data/* Data */.V([]);
                        return d.mapSync((p)=>p.filter((x)=>x.id !== previousData.inner.id));
                    }));
                }
            }
            if (currentData != null) {
                if (currentData.inner.persist) {
                    const sessionByOrigin = ByOrigin.schema(currentData.inner.origin, storage);
                    await sessionByOrigin.mutate(mutators/* Mutators */.g.data(SessionRef.from(currentData.inner)));
                }
                const sessionsQuery = currentData.inner.persist ? All.Persistent.schema(storage) : All.Temporary.schema();
                await sessionsQuery.mutate(mutators/* Mutators */.g.mapData(function() {
                    let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : new data/* Data */.V([]);
                    return d = d.mapSync((p)=>[
                            ...p,
                            SessionRef.from(currentData.inner)
                        ]);
                }));
                const currentWallets = new Set(currentData.inner.wallets);
                for (const wallet of currentWallets){
                    const sessionsByWalletQuery = currentData.inner.persist ? All.Persistent.ByWallet.schema(wallet.uuid, storage) : All.Temporary.ByWallet.schema(wallet.uuid);
                    await sessionsByWalletQuery.mutate(mutators/* Mutators */.g.mapData(function() {
                        let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : new data/* Data */.V([]);
                        return d.mapSync((p)=>[
                                ...p,
                                SessionRef.from(currentData.inner)
                            ]);
                    }));
                }
            }
        };
        return (0,query/* createQuery */.rP)({
            key: key(id),
            indexer,
            storage: new SessionStorage(storage)
        });
    }
    BgSession.schema = schema;
})(BgSession || (BgSession = {}));

// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/react/hooks/queries/simple.mjs + 1 modules
var simple = __webpack_require__(564);
// EXTERNAL MODULE: ./src/mods/foreground/storage/storage.ts
var storage_storage = __webpack_require__(604);
// EXTERNAL MODULE: ./src/mods/foreground/storage/user.tsx
var user = __webpack_require__(9718);
;// CONCATENATED MODULE: ./src/mods/foreground/entities/sessions/data.ts





var FgSession;
(function(FgSession) {
    let All;
    (function(All) {
        let Temporary;
        (function(Temporary) {
            let ByWallet;
            (function(ByWallet) {
                ByWallet.key = BgSession.All.Temporary.ByWallet.key;
                function schema(wallet, storage) {
                    if (wallet == null) return;
                    return (0,query/* createQuery */.rP)({
                        key: ByWallet.key(wallet),
                        storage
                    });
                }
                ByWallet.schema = schema;
            })(ByWallet = Temporary.ByWallet || (Temporary.ByWallet = {}));
            Temporary.key = BgSession.All.Temporary.key;
            function schema(storage) {
                return (0,query/* createQuery */.rP)({
                    key: Temporary.key,
                    storage
                });
            }
            Temporary.schema = schema;
        })(Temporary = All.Temporary || (All.Temporary = {}));
        let Persistent;
        (function(Persistent) {
            let ByWallet;
            (function(ByWallet) {
                ByWallet.key = BgSession.All.Persistent.ByWallet.key;
                function schema(wallet, storage) {
                    if (wallet == null) return;
                    return (0,query/* createQuery */.rP)({
                        key: ByWallet.key(wallet),
                        storage
                    });
                }
                ByWallet.schema = schema;
            })(ByWallet = Persistent.ByWallet || (Persistent.ByWallet = {}));
            Persistent.key = BgSession.All.Persistent.key;
            function schema(storage) {
                return (0,query/* createQuery */.rP)({
                    key: Persistent.key,
                    storage
                });
            }
            Persistent.schema = schema;
        })(Persistent = All.Persistent || (All.Persistent = {}));
    })(All = FgSession.All || (FgSession.All = {}));
    let ByOrigin;
    (function(ByOrigin) {
        ByOrigin.key = BgSession.ByOrigin.key;
        function schema(origin, storage) {
            return (0,query/* createQuery */.rP)({
                key: ByOrigin.key(origin),
                storage
            });
        }
        ByOrigin.schema = schema;
    })(ByOrigin = FgSession.ByOrigin || (FgSession.ByOrigin = {}));
    FgSession.key = BgSession.key;
    function shema(id, storage) {
        if (id == null) return;
        const indexer = async (states)=>{
            var _previous_real, _current_real;
            const { current, previous = current } = states;
            const previousData = (_previous_real = previous.real) === null || _previous_real === void 0 ? void 0 : _previous_real.data;
            const currentData = (_current_real = current.real) === null || _current_real === void 0 ? void 0 : _current_real.data;
            if (previousData != null) {
                if (previousData.inner.persist) {
                    const sessionByOrigin = ByOrigin.schema(previousData.inner.origin, storage);
                    await sessionByOrigin.delete();
                }
                const sessionsQuery = previousData.inner.persist ? All.Persistent.schema(storage) : All.Temporary.schema(storage);
                await sessionsQuery.mutate(mutators/* Mutators */.g.mapData(function() {
                    let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : new data/* Data */.V([]);
                    return d.mapSync((p)=>p.filter((x)=>x.id !== previousData.inner.id));
                }));
                const previousWallets = new Set(previousData.inner.wallets);
                for (const wallet of previousWallets){
                    const sessionsByWalletQuery = previousData.inner.persist ? All.Persistent.ByWallet.schema(wallet.uuid, storage) : All.Temporary.ByWallet.schema(wallet.uuid, storage);
                    await (sessionsByWalletQuery === null || sessionsByWalletQuery === void 0 ? void 0 : sessionsByWalletQuery.mutate(mutators/* Mutators */.g.mapData(function() {
                        let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : new data/* Data */.V([]);
                        return d.mapSync((p)=>p.filter((x)=>x.id !== previousData.inner.id));
                    })));
                }
            }
            if (currentData != null) {
                if (currentData.inner.persist) {
                    const sessionByOrigin = ByOrigin.schema(currentData.inner.origin, storage);
                    await sessionByOrigin.mutate(mutators/* Mutators */.g.data(SessionRef.from(currentData.inner)));
                }
                const sessionsQuery = currentData.inner.persist ? All.Persistent.schema(storage) : All.Temporary.schema(storage);
                await sessionsQuery.mutate(mutators/* Mutators */.g.mapData(function() {
                    let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : new data/* Data */.V([]);
                    return d = d.mapSync((p)=>[
                            ...p,
                            SessionRef.from(currentData.inner)
                        ]);
                }));
                const currentWallets = new Set(currentData.inner.wallets);
                for (const wallet of currentWallets){
                    const sessionsByWalletQuery = currentData.inner.persist ? All.Persistent.ByWallet.schema(wallet.uuid, storage) : All.Temporary.ByWallet.schema(wallet.uuid, storage);
                    await (sessionsByWalletQuery === null || sessionsByWalletQuery === void 0 ? void 0 : sessionsByWalletQuery.mutate(mutators/* Mutators */.g.mapData(function() {
                        let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : new data/* Data */.V([]);
                        return d.mapSync((p)=>[
                                ...p,
                                SessionRef.from(currentData.inner)
                            ]);
                    })));
                }
            }
        };
        // TODO storage
        return (0,query/* createQuery */.rP)({
            key: FgSession.key(id),
            indexer,
            storage
        });
    }
    FgSession.shema = shema;
})(FgSession || (FgSession = {}));
function useSession(id) {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(FgSession.shema, [
        id,
        storage
    ]);
    (0,storage_storage/* useSubscribe */.Q)(query, storage);
    return query;
}


/***/ }),

/***/ 9801:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Fh: function() { return /* binding */ useGasPrice; },
/* harmony export */   Nh: function() { return /* binding */ useEstimateGas; },
/* harmony export */   Q6: function() { return /* binding */ FgTotal; },
/* harmony export */   XE: function() { return /* binding */ useNonce; },
/* harmony export */   ZO: function() { return /* binding */ useTotalPricedBalance; },
/* harmony export */   h7: function() { return /* binding */ useTotalWalletPricedBalance; },
/* harmony export */   hy: function() { return /* binding */ useMaxPriorityFeePerGas; },
/* harmony export */   qK: function() { return /* binding */ FgEthereum; }
/* harmony export */ });
/* unused harmony export useUnknown */
/* harmony import */ var _libs_bigints_bigints__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6827);
/* harmony import */ var _libs_errors_errors__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8524);
/* harmony import */ var _libs_glacier_mutators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9949);
/* harmony import */ var _mods_background_service_worker_entities_unknown_data__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2534);
/* harmony import */ var _hazae41_cubane__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(8386);
/* harmony import */ var _hazae41_glacier__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6233);
/* harmony import */ var _hazae41_glacier__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(564);
/* harmony import */ var _hazae41_glacier__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4704);
/* harmony import */ var _hazae41_glacier__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7836);
/* harmony import */ var _hazae41_glacier__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8995);
/* harmony import */ var _hazae41_glacier__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3399);
/* harmony import */ var _hazae41_glacier__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(8123);
/* harmony import */ var _hazae41_option__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(5316);
/* harmony import */ var _storage_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(604);
/* harmony import */ var _storage_user__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9718);
/* harmony import */ var _wallets_data__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9327);










var FgEthereum;
(function(FgEthereum) {
    let Unknown;
    (function(Unknown) {
        Unknown.key = _mods_background_service_worker_entities_unknown_data__WEBPACK_IMPORTED_MODULE_3__/* .BgEthereum */ .$.Unknown.key;
        function schema(request, context, storage) {
            if (context == null) return;
            if (request == null) return;
            const fetcher = async (request)=>await (0,_wallets_data__WEBPACK_IMPORTED_MODULE_6__/* .fetchOrFail */ .yR)(request, context);
            return (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_7__/* .createQuery */ .rP)({
                key: Unknown.key(context.chain.chainId, request),
                fetcher,
                storage
            });
        }
        Unknown.schema = schema;
    })(Unknown = FgEthereum.Unknown || (FgEthereum.Unknown = {}));
    let EstimateGas;
    (function(EstimateGas) {
        function key(request, context) {
            return {
                chainId: context.chain.chainId,
                method: "eth_estimateGas",
                params: request.params
            };
        }
        EstimateGas.key = key;
        function schema(request, context, storage) {
            if (context == null) return;
            if (request == null) return;
            const fetcher = async (request)=>await (0,_wallets_data__WEBPACK_IMPORTED_MODULE_6__/* .fetchOrFail */ .yR)(request, context).then((r)=>r.mapSync(BigInt));
            return (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_7__/* .createQuery */ .rP)({
                key: key(request, context),
                fetcher,
                storage,
                dataSerializer: _libs_bigints_bigints__WEBPACK_IMPORTED_MODULE_0__/* .BigIntToHex */ .W
            });
        }
        EstimateGas.schema = schema;
    })(EstimateGas = FgEthereum.EstimateGas || (FgEthereum.EstimateGas = {}));
    let MaxPriorityFeePerGas;
    (function(MaxPriorityFeePerGas) {
        function key(chain) {
            return {
                chainId: chain.chainId,
                method: "eth_maxPriorityFeePerGas",
                params: []
            };
        }
        MaxPriorityFeePerGas.key = key;
        function schema(context, storage) {
            if (context == null) return;
            const fetcher = async (request)=>await (0,_wallets_data__WEBPACK_IMPORTED_MODULE_6__/* .fetchOrFail */ .yR)(request, context).then((r)=>r.mapSync(BigInt));
            return (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_7__/* .createQuery */ .rP)({
                key: key(context.chain),
                fetcher,
                storage,
                dataSerializer: _libs_bigints_bigints__WEBPACK_IMPORTED_MODULE_0__/* .BigIntToHex */ .W
            });
        }
        MaxPriorityFeePerGas.schema = schema;
    })(MaxPriorityFeePerGas = FgEthereum.MaxPriorityFeePerGas || (FgEthereum.MaxPriorityFeePerGas = {}));
    let GasPrice;
    (function(GasPrice) {
        function key(chain) {
            return {
                chainId: chain.chainId,
                method: "eth_gasPrice",
                params: [],
                noCheck: true
            };
        }
        GasPrice.key = key;
        function schema(context, storage) {
            if (context == null) return;
            const fetcher = async (request)=>await (0,_wallets_data__WEBPACK_IMPORTED_MODULE_6__/* .fetchOrFail */ .yR)(request, context).then((r)=>r.mapSync(BigInt));
            return (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_7__/* .createQuery */ .rP)({
                key: key(context.chain),
                fetcher,
                storage,
                dataSerializer: _libs_bigints_bigints__WEBPACK_IMPORTED_MODULE_0__/* .BigIntToHex */ .W
            });
        }
        GasPrice.schema = schema;
    })(GasPrice = FgEthereum.GasPrice || (FgEthereum.GasPrice = {}));
    let Nonce;
    (function(Nonce) {
        function key(address, chain) {
            return {
                chainId: chain.chainId,
                method: "eth_getTransactionCount",
                params: [
                    address,
                    "pending"
                ]
            };
        }
        Nonce.key = key;
        function schema(address, context, storage) {
            if (address == null) return;
            if (context == null) return;
            const fetcher = async function(request) {
                let more = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
                return await (0,_wallets_data__WEBPACK_IMPORTED_MODULE_6__/* .fetchOrFail */ .yR)(request, context).then((r)=>r.mapSync(BigInt));
            };
            return (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_7__/* .createQuery */ .rP)({
                key: key(address, context.chain),
                fetcher,
                storage,
                dataSerializer: _libs_bigints_bigints__WEBPACK_IMPORTED_MODULE_0__/* .BigIntToHex */ .W
            });
        }
        Nonce.schema = schema;
    })(Nonce = FgEthereum.Nonce || (FgEthereum.Nonce = {}));
})(FgEthereum || (FgEthereum = {}));
function useUnknown(request, context) {
    const storage = useUserStorageContext().unwrap();
    const query = useQuery(FgEthereum.Unknown.schema, [
        request,
        context,
        storage
    ]);
    useFetch(query);
    useVisible(query);
    useSubscribe(query, storage);
    useError(query, Errors.onQueryError);
    return query;
}
function useEstimateGas(request, context) {
    const storage = (0,_storage_user__WEBPACK_IMPORTED_MODULE_5__/* .useUserStorageContext */ .v6)().unwrap();
    const query = (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_8__/* .useQuery */ .aM)(FgEthereum.EstimateGas.schema, [
        request,
        context,
        storage
    ]);
    (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_9__/* .useFetch */ .i)(query);
    (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_10__/* .useVisible */ .E)(query);
    (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_11__/* .useInterval */ .Y)(query, 10 * 1000);
    (0,_storage_storage__WEBPACK_IMPORTED_MODULE_4__/* .useSubscribe */ .Q)(query, storage);
    (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_12__/* .useError */ .V)(query, _libs_errors_errors__WEBPACK_IMPORTED_MODULE_1__/* .Errors */ .D.onQueryError);
    return query;
}
function useMaxPriorityFeePerGas(context) {
    const storage = (0,_storage_user__WEBPACK_IMPORTED_MODULE_5__/* .useUserStorageContext */ .v6)().unwrap();
    const query = (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_8__/* .useQuery */ .aM)(FgEthereum.MaxPriorityFeePerGas.schema, [
        context,
        storage
    ]);
    (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_9__/* .useFetch */ .i)(query);
    (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_10__/* .useVisible */ .E)(query);
    (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_11__/* .useInterval */ .Y)(query, 10 * 1000);
    (0,_storage_storage__WEBPACK_IMPORTED_MODULE_4__/* .useSubscribe */ .Q)(query, storage);
    (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_12__/* .useError */ .V)(query, _libs_errors_errors__WEBPACK_IMPORTED_MODULE_1__/* .Errors */ .D.onQueryError);
    return query;
}
function useGasPrice(context) {
    const storage = (0,_storage_user__WEBPACK_IMPORTED_MODULE_5__/* .useUserStorageContext */ .v6)().unwrap();
    const query = (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_8__/* .useQuery */ .aM)(FgEthereum.GasPrice.schema, [
        context,
        storage
    ]);
    (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_9__/* .useFetch */ .i)(query);
    (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_10__/* .useVisible */ .E)(query);
    (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_11__/* .useInterval */ .Y)(query, 10 * 1000);
    (0,_storage_storage__WEBPACK_IMPORTED_MODULE_4__/* .useSubscribe */ .Q)(query, storage);
    (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_12__/* .useError */ .V)(query, _libs_errors_errors__WEBPACK_IMPORTED_MODULE_1__/* .Errors */ .D.onQueryError);
    return query;
}
function useNonce(address, context) {
    const storage = (0,_storage_user__WEBPACK_IMPORTED_MODULE_5__/* .useUserStorageContext */ .v6)().unwrap();
    const query = (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_8__/* .useQuery */ .aM)(FgEthereum.Nonce.schema, [
        address,
        context,
        storage
    ]);
    (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_9__/* .useFetch */ .i)(query);
    (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_10__/* .useVisible */ .E)(query);
    (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_11__/* .useInterval */ .Y)(query, 10 * 1000);
    (0,_storage_storage__WEBPACK_IMPORTED_MODULE_4__/* .useSubscribe */ .Q)(query, storage);
    (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_12__/* .useError */ .V)(query, _libs_errors_errors__WEBPACK_IMPORTED_MODULE_1__/* .Errors */ .D.onQueryError);
    return query;
}
var FgTotal;
(function(FgTotal) {
    let Balance;
    (function(Balance) {
        let Priced;
        (function(Priced) {
            let ByAddress;
            (function(ByAddress) {
                let Record;
                (function(Record) {
                    Record.key = _mods_background_service_worker_entities_unknown_data__WEBPACK_IMPORTED_MODULE_3__/* .BgTotal */ .f.Balance.Priced.ByAddress.Record.key;
                    function schema(coin, storage) {
                        const indexer = async (states)=>{
                            var _states_current_real_data, _states_current_real;
                            const values = _hazae41_option__WEBPACK_IMPORTED_MODULE_13__/* .Option */ .W.wrap((_states_current_real = states.current.real) === null || _states_current_real === void 0 ? void 0 : (_states_current_real_data = _states_current_real.data) === null || _states_current_real_data === void 0 ? void 0 : _states_current_real_data.inner).unwrapOr({});
                            const total = Object.values(values).reduce((x, y)=>_hazae41_cubane__WEBPACK_IMPORTED_MODULE_14__/* .Fixed */ .g.from(y).add(x), new _hazae41_cubane__WEBPACK_IMPORTED_MODULE_14__/* .Fixed */ .g(0n, 0));
                            const totalQuery = Priced.schema(coin, storage);
                            await totalQuery.mutate(_libs_glacier_mutators__WEBPACK_IMPORTED_MODULE_2__/* .Mutators */ .g.data(total));
                        };
                        return (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_7__/* .createQuery */ .rP)({
                            key: Record.key(coin),
                            indexer,
                            storage
                        });
                    }
                    Record.schema = schema;
                })(Record = ByAddress.Record || (ByAddress.Record = {}));
                function key(address, coin) {
                    return "totalWalletPricedBalance/".concat(address, "/").concat(coin);
                }
                ByAddress.key = key;
                function schema(address, coin, storage) {
                    if (address == null) return;
                    const indexer = async (states)=>{
                        var _states_current_real_data, _states_current_real;
                        const indexQuery = Record.schema(coin, storage);
                        const value = _hazae41_option__WEBPACK_IMPORTED_MODULE_13__/* .Option */ .W.wrap((_states_current_real = states.current.real) === null || _states_current_real === void 0 ? void 0 : (_states_current_real_data = _states_current_real.data) === null || _states_current_real_data === void 0 ? void 0 : _states_current_real_data.inner).unwrapOr(new _hazae41_cubane__WEBPACK_IMPORTED_MODULE_14__/* .Fixed */ .g(0n, 0));
                        await indexQuery.mutate(_libs_glacier_mutators__WEBPACK_IMPORTED_MODULE_2__/* .Mutators */ .g.mapInnerData((p)=>({
                                ...p,
                                [address]: value
                            }), new _hazae41_glacier__WEBPACK_IMPORTED_MODULE_15__/* .Data */ .V({})));
                    };
                    return (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_7__/* .createQuery */ .rP)({
                        key: key(address, coin),
                        indexer,
                        storage
                    });
                }
                ByAddress.schema = schema;
            })(ByAddress = Priced.ByAddress || (Priced.ByAddress = {}));
            function key(coin) {
                return "totalPricedBalance/".concat(coin);
            }
            Priced.key = key;
            function schema(coin, storage) {
                return (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_7__/* .createQuery */ .rP)({
                    key: key(coin),
                    storage
                });
            }
            Priced.schema = schema;
        })(Priced = Balance.Priced || (Balance.Priced = {}));
    })(Balance = FgTotal.Balance || (FgTotal.Balance = {}));
})(FgTotal || (FgTotal = {}));
function useTotalPricedBalance(coin) {
    const storage = (0,_storage_user__WEBPACK_IMPORTED_MODULE_5__/* .useUserStorageContext */ .v6)().unwrap();
    const query = (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_8__/* .useQuery */ .aM)(FgTotal.Balance.Priced.schema, [
        coin,
        storage
    ]);
    (0,_storage_storage__WEBPACK_IMPORTED_MODULE_4__/* .useSubscribe */ .Q)(query, storage);
    return query;
}
function useTotalWalletPricedBalance(address, coin) {
    const storage = (0,_storage_user__WEBPACK_IMPORTED_MODULE_5__/* .useUserStorageContext */ .v6)().unwrap();
    const query = (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_8__/* .useQuery */ .aM)(FgTotal.Balance.Priced.ByAddress.schema, [
        address,
        coin,
        storage
    ]);
    (0,_storage_storage__WEBPACK_IMPORTED_MODULE_4__/* .useSubscribe */ .Q)(query, storage);
    return query;
}


/***/ }),

/***/ 3166:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  _: function() { return /* binding */ WalletCreatorDialog; }
});

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/EyeIcon.js
var EyeIcon = __webpack_require__(2940);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/WalletIcon.js
var WalletIcon = __webpack_require__(5066);
// EXTERNAL MODULE: ./src/libs/ui/button.tsx + 8 modules
var ui_button = __webpack_require__(9178);
// EXTERNAL MODULE: ./src/libs/ui/dialog/dialog.tsx
var dialog = __webpack_require__(6488);
// EXTERNAL MODULE: ./node_modules/react/index.js
var react = __webpack_require__(7294);
// EXTERNAL MODULE: ./src/libs/colors/colors.ts
var colors = __webpack_require__(4231);
// EXTERNAL MODULE: ./src/libs/emojis/emojis.ts
var emojis = __webpack_require__(9912);
// EXTERNAL MODULE: ./src/libs/errors/errors.ts
var errors = __webpack_require__(8524);
// EXTERNAL MODULE: ./src/libs/ethereum/mods/chain.tsx
var chain = __webpack_require__(9183);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/PlusIcon.js
var PlusIcon = __webpack_require__(8680);
// EXTERNAL MODULE: ./src/libs/modhash/modhash.ts
var modhash_modhash = __webpack_require__(4628);
// EXTERNAL MODULE: ./src/libs/react/callback.tsx
var callback = __webpack_require__(5379);
// EXTERNAL MODULE: ./src/libs/react/events.ts
var events = __webpack_require__(8418);
// EXTERNAL MODULE: ./src/libs/react/ref.ts + 1 modules
var ref = __webpack_require__(4537);
// EXTERNAL MODULE: ./src/libs/results/results.ts
var results = __webpack_require__(7519);
// EXTERNAL MODULE: ./src/libs/ui/input.tsx + 4 modules
var input = __webpack_require__(9607);
// EXTERNAL MODULE: ./src/libs/ui/textarea.tsx + 2 modules
var ui_textarea = __webpack_require__(110);
// EXTERNAL MODULE: ./src/mods/foreground/background/context.tsx + 3 modules
var context = __webpack_require__(5855);
// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/types/address/index.mjs
var types_address = __webpack_require__(7657);
// EXTERNAL MODULE: ./node_modules/@hazae41/option/dist/esm/mods/option/option.mjs
var option_option = __webpack_require__(5316);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/result.mjs
var result = __webpack_require__(918);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/err.mjs
var err = __webpack_require__(166);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/errors.mjs
var result_errors = __webpack_require__(2564);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/ok.mjs
var ok = __webpack_require__(5591);
// EXTERNAL MODULE: ./src/mods/foreground/entities/names/data.ts + 2 modules
var data = __webpack_require__(797);
// EXTERNAL MODULE: ./src/mods/foreground/entities/wallets/avatar.tsx
var avatar = __webpack_require__(3650);
// EXTERNAL MODULE: ./src/mods/foreground/entities/wallets/data.ts
var wallets_data = __webpack_require__(9327);
;// CONCATENATED MODULE: ./src/mods/foreground/entities/wallets/all/create/readonly.tsx























function ReadonlyWalletCreatorDialog(props) {
    var _ensAddressQuery_data;
    const { close } = (0,dialog/* useDialogContext */.DA)().unwrap();
    const background = (0,context/* useBackgroundContext */.D_)().unwrap();
    const uuid = (0,ref/* useConstant */.hS)(()=>crypto.randomUUID());
    const mainnet = (0,wallets_data/* useEthereumContext */.Kn)(uuid, chain/* chainByChainId */.DH[1]);
    const modhash = (0,modhash_modhash/* useModhash */.jR)(uuid);
    const color = colors/* Colors */.w.mod(modhash);
    const emoji = emojis/* Emojis */.A.get(modhash);
    const [rawNameInput = "", setRawNameInput] = (0,react.useState)();
    const defNameInput = (0,react.useDeferredValue)(rawNameInput);
    const onNameInputChange = (0,events/* useInputChange */.Xy)((e)=>{
        setRawNameInput(e.currentTarget.value);
    }, []);
    const [rawAddressInput = "", setRawAddressInput] = (0,react.useState)();
    const defAddressInput = (0,react.useDeferredValue)(rawAddressInput);
    const onAddressInputChange = (0,events/* useTextAreaChange */.aN)((e)=>{
        setRawAddressInput(e.currentTarget.value);
    }, []);
    const maybeEnsInput = defAddressInput.endsWith(".eth") ? defAddressInput : undefined;
    const ensAddressQuery = (0,data/* useEnsLookup */.aZ)(maybeEnsInput, mainnet);
    const maybeAddress = defAddressInput.endsWith(".eth") ? (_ensAddressQuery_data = ensAddressQuery.data) === null || _ensAddressQuery_data === void 0 ? void 0 : _ensAddressQuery_data.inner : defAddressInput;
    const tryAdd = (0,callback/* useAsyncUniqueCallback */.T)(async ()=>{
        return await result/* Result */.x.unthrow(async (t)=>{
            if (!defNameInput) return new err/* Err */.U(new result_errors/* Panic */.F5());
            const address = option_option/* Option */.W.wrap(maybeAddress).okOrElseSync(()=>{
                return new errors/* UIError */.m("Could not fetch or parse address");
            }).mapSync((x)=>types_address/* Address */.k.from(x)).throw(t);
            const wallet = {
                coin: "ethereum",
                type: "readonly",
                uuid,
                name: defNameInput,
                color,
                emoji,
                address
            };
            await background.tryRequest({
                method: "brume_createWallet",
                params: [
                    wallet
                ]
            }).then((r)=>r.throw(t).throw(t));
            close();
            return ok.Ok.void();
        }).then(results/* Results */.u.logAndAlert);
    }, [
        defNameInput,
        maybeAddress,
        uuid,
        color,
        emoji,
        background,
        close
    ]);
    const addDisabled = (0,react.useMemo)(()=>{
        if (tryAdd.loading) return "Loading...";
        if (!defNameInput) return "Please enter a name";
        if (!defAddressInput) return "Please enter an address";
        return undefined;
    }, [
        tryAdd.loading,
        defNameInput,
        defAddressInput
    ]);
    const NameInput = /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "flex items-stretch gap-2",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "shrink-0",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(avatar/* WalletAvatar */.G, {
                    className: "size-12 text-2xl",
                    colorIndex: color,
                    emoji: emoji
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)(input/* Input.Contrast */.I.mn, {
                className: "w-full",
                placeholder: "Enter a name",
                value: rawNameInput,
                onChange: onNameInputChange
            })
        ]
    });
    const AddressInput = /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_textarea/* Textarea.Contrast */.g.m, {
        className: "w-full resize-none",
        placeholder: "vitalik.eth",
        value: rawAddressInput,
        onChange: onAddressInputChange,
        rows: 4
    });
    const AddButon = /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.Gradient */.z.ph, {
        className: "grow po-md",
        colorIndex: color,
        disabled: Boolean(addDisabled),
        onClick: tryAdd.run,
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsx)(PlusIcon/* default */.Z, {
                    className: "size-5"
                }),
                addDisabled || "Add"
            ]
        })
    });
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Dialog */.Vq.Title, {
                close: close,
                children: "New wallet"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-2"
            }),
            NameInput,
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-8"
            }),
            AddressInput,
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-8"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "flex items-center flex-wrap-reverse gap-2",
                children: AddButon
            })
        ]
    });
}

// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/KeyIcon.js
var KeyIcon = __webpack_require__(9878);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/LockClosedIcon.js
var LockClosedIcon = __webpack_require__(6186);
// EXTERNAL MODULE: ./src/libs/react/memo.ts + 1 modules
var memo = __webpack_require__(7664);
// EXTERNAL MODULE: ./src/libs/webauthn/webauthn.ts
var webauthn = __webpack_require__(299);
// EXTERNAL MODULE: ./node_modules/@hazae41/base16/dist/esm/src/mods/base16/adapter.mjs
var adapter = __webpack_require__(2248);
// EXTERNAL MODULE: ./node_modules/@hazae41/base64/dist/esm/src/mods/base64/adapter.mjs
var base64_adapter = __webpack_require__(9467);
// EXTERNAL MODULE: ./node_modules/@hazae41/bytes/dist/esm/mods/bytes/bytes.mjs + 3 modules
var bytes = __webpack_require__(1694);
// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/types/zerohex/index.mjs
var zerohex = __webpack_require__(6113);
// EXTERNAL MODULE: ./node_modules/@noble/curves/esm/secp256k1.js + 5 modules
var secp256k1 = __webpack_require__(7835);
;// CONCATENATED MODULE: ./src/mods/foreground/entities/wallets/all/create/standalone.tsx

var __addDisposableResource = undefined && undefined.__addDisposableResource || function(env, value, async) {
    if (value !== null && value !== void 0) {
        if (typeof value !== "object" && typeof value !== "function") throw new TypeError("Object expected.");
        var dispose;
        if (async) {
            if (!Symbol.asyncDispose) throw new TypeError("Symbol.asyncDispose is not defined.");
            dispose = value[Symbol.asyncDispose];
        }
        if (dispose === void 0) {
            if (!Symbol.dispose) throw new TypeError("Symbol.dispose is not defined.");
            dispose = value[Symbol.dispose];
        }
        if (typeof dispose !== "function") throw new TypeError("Object not disposable.");
        env.stack.push({
            value: value,
            dispose: dispose,
            async: async
        });
    } else if (async) {
        env.stack.push({
            async: true
        });
    }
    return value;
};
var __disposeResources = undefined && undefined.__disposeResources || function(SuppressedError1) {
    return function(env) {
        function fail(e) {
            env.error = env.hasError ? new SuppressedError1(e, env.error, "An error was suppressed during disposal.") : e;
            env.hasError = true;
        }
        function next() {
            while(env.stack.length){
                var rec = env.stack.pop();
                try {
                    var result = rec.dispose && rec.dispose.call(rec.value);
                    if (rec.async) return Promise.resolve(result).then(next, function(e) {
                        fail(e);
                        return next();
                    });
                } catch (e) {
                    fail(e);
                }
            }
            if (env.hasError) throw env.error;
        }
        return next();
    };
}(typeof SuppressedError === "function" ? SuppressedError : function(error, suppressed, message) {
    var e = new Error(message);
    return e.name = "SuppressedError", e.error = error, e.suppressed = suppressed, e;
});























function StandaloneWalletCreatorDialog(props) {
    const { close } = (0,dialog/* useDialogContext */.DA)().unwrap();
    const background = (0,context/* useBackgroundContext */.D_)().unwrap();
    const uuid = (0,ref/* useConstant */.hS)(()=>crypto.randomUUID());
    const modhash = (0,modhash_modhash/* useModhash */.jR)(uuid);
    const color = colors/* Colors */.w.mod(modhash);
    const emoji = emojis/* Emojis */.A.get(modhash);
    const [rawNameInput = "", setRawNameInput] = (0,react.useState)();
    const defNameInput = (0,react.useDeferredValue)(rawNameInput);
    const onNameInputChange = (0,events/* useInputChange */.Xy)((e)=>{
        setRawNameInput(e.currentTarget.value);
    }, []);
    const [rawKeyInput = "", setRawKeyInput] = (0,react.useState)();
    const defKeyInput = (0,react.useDeferredValue)(rawKeyInput);
    const zeroHexKey = zerohex/* ZeroHexString */.T.from(defKeyInput);
    const onKeyInputChange = (0,events/* useTextAreaChange */.aN)((e)=>{
        setRawKeyInput(e.currentTarget.value);
    }, []);
    const doGenerate = (0,callback/* useAsyncUniqueCallback */.T)(async ()=>{
        const bytes = secp256k1/* secp256k1 */.kA.utils.randomPrivateKey();
        setRawKeyInput("0x".concat(adapter/* get */.U().tryEncode(bytes).unwrap()));
    }, []);
    const tryAddUnauthenticated = (0,callback/* useAsyncUniqueCallback */.T)(async ()=>{
        return await result/* Result */.x.unthrow(async (t)=>{
            if (!defNameInput) return new err/* Err */.U(new result_errors/* Panic */.F5());
            if (!secp256k1/* secp256k1 */.kA.utils.isValidPrivateKey(zeroHexKey.slice(2))) return new err/* Err */.U(new result_errors/* Panic */.F5());
            if (!confirm("Did you backup your private key?")) return ok.Ok.void();
            const privateKeyBytes = adapter/* get */.U().tryPadStartAndDecode(zeroHexKey.slice(2)).throw(t).copyAndDispose();
            const uncompressedPublicKeyBytes = secp256k1/* secp256k1 */.kA.getPublicKey(privateKeyBytes, false);
            // const compressedPublicKeyBytes = secp256k1.getPublicKey(privateKeyBytes, true)
            const address = types_address/* Address */.k.compute(uncompressedPublicKeyBytes);
            // const uncompressedBitcoinAddress = await Bitcoin.Address.from(uncompressedPublicKeyBytes)
            // const compressedBitcoinAddress = await Bitcoin.Address.from(compressedPublicKeyBytes)
            const wallet = {
                coin: "ethereum",
                type: "privateKey",
                uuid,
                name: defNameInput,
                color,
                emoji,
                address,
                privateKey: zeroHexKey
            };
            await background.tryRequest({
                method: "brume_createWallet",
                params: [
                    wallet
                ]
            }).then((r)=>r.throw(t).throw(t));
            close();
            return ok.Ok.void();
        }).then(results/* Results */.u.logAndAlert);
    }, [
        defNameInput,
        zeroHexKey,
        uuid,
        color,
        emoji,
        background,
        close
    ]);
    const triedEncryptedPrivateKey = (0,memo/* useAsyncReplaceMemo */.EY)(async ()=>{
        return await result/* Result */.x.unthrow(async (t)=>{
            const env_1 = {
                stack: [],
                error: void 0,
                hasError: false
            };
            try {
                if (!defNameInput) return new err/* Err */.U(new result_errors/* Panic */.F5());
                if (!secp256k1/* secp256k1 */.kA.utils.isValidPrivateKey(zeroHexKey.slice(2))) return new err/* Err */.U(new result_errors/* Panic */.F5());
                const privateKeyMemory = __addDisposableResource(env_1, adapter/* get */.U().tryPadStartAndDecode(zeroHexKey.slice(2)).throw(t), false);
                const privateKeyBase64 = base64_adapter/* get */.U().tryEncodePadded(privateKeyMemory).throw(t);
                const [ivBase64, cipherBase64] = await background.tryRequest({
                    method: "brume_encrypt",
                    params: [
                        privateKeyBase64
                    ]
                }).then((r)=>r.throw(t).throw(t));
                return new ok.Ok([
                    ivBase64,
                    cipherBase64
                ]);
            } catch (e_1) {
                env_1.error = e_1;
                env_1.hasError = true;
            } finally{
                __disposeResources(env_1);
            }
        });
    }, [
        defNameInput,
        zeroHexKey,
        background
    ]);
    const [id, setId] = (0,react.useState)();
    (0,react.useEffect)(()=>{
        setId(undefined);
    }, [
        zeroHexKey
    ]);
    const tryAddAuthenticated1 = (0,callback/* useAsyncUniqueCallback */.T)(async ()=>{
        return await result/* Result */.x.unthrow(async (t)=>{
            if (!defNameInput) return new err/* Err */.U(new result_errors/* Panic */.F5());
            if (!secp256k1/* secp256k1 */.kA.utils.isValidPrivateKey(zeroHexKey.slice(2))) return new err/* Err */.U(new result_errors/* Panic */.F5());
            if (triedEncryptedPrivateKey == null) return new err/* Err */.U(new result_errors/* Panic */.F5());
            if (!confirm("Did you backup your private key?")) return ok.Ok.void();
            const [_, cipherBase64] = triedEncryptedPrivateKey.throw(t);
            const cipher = base64_adapter/* get */.U().tryDecodePadded(cipherBase64).throw(t).copyAndDispose();
            const id = await webauthn/* WebAuthnStorage */.g.tryCreate(defNameInput, cipher).then((r)=>r.throw(t));
            setId(id);
            return ok.Ok.void();
        }).then(results/* Results */.u.logAndAlert);
    }, [
        defNameInput,
        zeroHexKey,
        triedEncryptedPrivateKey,
        uuid,
        color,
        emoji,
        background
    ]);
    const tryAddAuthenticated2 = (0,callback/* useAsyncUniqueCallback */.T)(async ()=>{
        return await result/* Result */.x.unthrow(async (t)=>{
            if (!defNameInput) return new err/* Err */.U(new result_errors/* Panic */.F5());
            if (!secp256k1/* secp256k1 */.kA.utils.isValidPrivateKey(zeroHexKey.slice(2))) return new err/* Err */.U(new result_errors/* Panic */.F5());
            if (id == null) return new err/* Err */.U(new result_errors/* Panic */.F5());
            if (triedEncryptedPrivateKey == null) return new err/* Err */.U(new result_errors/* Panic */.F5());
            const privateKeyBytes = adapter/* get */.U().tryPadStartAndDecode(zeroHexKey.slice(2)).throw(t).copyAndDispose();
            const uncompressedPublicKeyBytes = secp256k1/* secp256k1 */.kA.getPublicKey(privateKeyBytes, false);
            // const compressedPublicKeyBytes = secp256k1.getPublicKey(privateKeyBytes, true)
            const address = types_address/* Address */.k.compute(uncompressedPublicKeyBytes);
            // const uncompressedBitcoinAddress = await Bitcoin.Address.from(uncompressedPublicKeyBytes)
            // const compressedBitcoinAddress = await Bitcoin.Address.from(compressedPublicKeyBytes)
            const [ivBase64, cipherBase64] = triedEncryptedPrivateKey.throw(t);
            const cipher = base64_adapter/* get */.U().tryDecodePadded(cipherBase64).throw(t).copyAndDispose();
            const cipher2 = await webauthn/* WebAuthnStorage */.g.tryGet(id).then((r)=>r.throw(t));
            if (!bytes/* Bytes */.J.equals(cipher, cipher2)) return new err/* Err */.U(new webauthn/* WebAuthnStorageError */.$());
            const idBase64 = base64_adapter/* get */.U().tryEncodePadded(id).throw(t);
            const privateKey = {
                ivBase64,
                idBase64
            };
            const wallet = {
                coin: "ethereum",
                type: "authPrivateKey",
                uuid,
                name: defNameInput,
                color,
                emoji,
                address,
                privateKey
            };
            await background.tryRequest({
                method: "brume_createWallet",
                params: [
                    wallet
                ]
            }).then((r)=>r.throw(t).throw(t));
            close();
            return ok.Ok.void();
        }).then(results/* Results */.u.logAndAlert);
    }, [
        defNameInput,
        zeroHexKey,
        id,
        triedEncryptedPrivateKey,
        uuid,
        color,
        emoji,
        background,
        close
    ]);
    const NameInput = /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "flex items-stretch gap-2",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "shrink-0",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(avatar/* WalletAvatar */.G, {
                    className: "size-12 text-2xl",
                    colorIndex: color,
                    emoji: emoji
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)(input/* Input.Contrast */.I.mn, {
                className: "w-full",
                placeholder: "Enter a name",
                value: rawNameInput,
                onChange: onNameInputChange
            })
        ]
    });
    const KeyInput = /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_textarea/* Textarea.Contrast */.g.m, {
        className: "w-full resize-none",
        placeholder: "Enter your private key",
        value: rawKeyInput,
        onChange: onKeyInputChange,
        rows: 4
    });
    const GenerateButton = /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.Contrast */.z.mn, {
        className: "flex-1 whitespace-nowrap po-md",
        onClick: doGenerate.run,
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsx)(KeyIcon/* default */.Z, {
                    className: "size-5"
                }),
                "Generate a private key"
            ]
        })
    });
    const canAdd = (0,react.useMemo)(()=>{
        if (!defNameInput) return false;
        if (!secp256k1/* secp256k1 */.kA.utils.isValidPrivateKey(zeroHexKey.slice(2))) return false;
        return true;
    }, [
        defNameInput,
        zeroHexKey
    ]);
    const AddUnauthButton = /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.Contrast */.z.mn, {
        className: "flex-1 whitespace-nowrap po-md",
        disabled: !canAdd,
        onClick: tryAddUnauthenticated.run,
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsx)(PlusIcon/* default */.Z, {
                    className: "size-5"
                }),
                "Add without authentication"
            ]
        })
    });
    const AddAuthButton1 = /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.Gradient */.z.ph, {
        className: "flex-1 whitespace-nowrap po-md",
        colorIndex: color,
        disabled: !canAdd,
        onClick: tryAddAuthenticated1.run,
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsx)(LockClosedIcon/* default */.Z, {
                    className: "size-5"
                }),
                "Add with authentication"
            ]
        })
    });
    const AddAuthButton2 = /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.Gradient */.z.ph, {
        className: "flex-1 whitespace-nowrap po-md",
        colorIndex: color,
        disabled: !canAdd,
        onClick: tryAddAuthenticated2.run,
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsx)(LockClosedIcon/* default */.Z, {
                    className: "size-5"
                }),
                "Add with authentication (1/2)"
            ]
        })
    });
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Dialog */.Vq.Title, {
                close: close,
                children: "New wallet"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-2"
            }),
            NameInput,
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-8"
            }),
            KeyInput,
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "flex items-center flex-wrap-reverse gap-2",
                children: GenerateButton
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-8"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "flex items-center flex-wrap-reverse gap-2",
                children: [
                    AddUnauthButton,
                    id == null ? AddAuthButton1 : AddAuthButton2
                ]
            })
        ]
    });
}

;// CONCATENATED MODULE: ./src/mods/foreground/entities/wallets/all/create/index.tsx







function WalletCreatorDialog(props) {
    const { opened, close } = (0,dialog/* useDialogContext */.DA)().unwrap();
    const [type, setType] = (0,react.useState)();
    const onWatchonlyClick = (0,react.useCallback)(()=>{
        setType("readonly");
    }, []);
    const onPrivateKeyClick = (0,react.useCallback)(()=>{
        setType("privateKey");
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Dialog */.Vq, {
                opened: opened && type === "readonly",
                close: close,
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(ReadonlyWalletCreatorDialog, {})
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Dialog */.Vq, {
                opened: opened && type === "privateKey",
                close: close,
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(StandaloneWalletCreatorDialog, {})
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Dialog */.Vq.Title, {
                close: close,
                children: "New wallet"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-2"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "w-full flex items-center gap-2",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.Contrast */.z.mn, {
                        className: "flex-1 whitespace-nowrap p-4 rounded-xl",
                        onClick: onWatchonlyClick,
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "".concat(ui_button/* Button.Shrinker */.z.Np.className, " flex-col"),
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)(EyeIcon/* default */.Z, {
                                    className: "size-6"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                    children: "Watch-only"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.Contrast */.z.mn, {
                        className: "flex-1 whitespace-nowrap p-4 rounded-xl",
                        onClick: onPrivateKeyClick,
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "".concat(ui_button/* Button.Shrinker */.z.Np.className, " flex-col"),
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)(WalletIcon/* default */.Z, {
                                    className: "size-6"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                    children: "Private key"
                                })
                            ]
                        })
                    })
                ]
            })
        ]
    });
}


/***/ }),

/***/ 200:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FU: function() { return /* binding */ WalletsPage; },
/* harmony export */   Y7: function() { return /* binding */ SelectableWalletGrid; },
/* harmony export */   oS: function() { return /* binding */ ClickableWalletGrid; }
/* harmony export */ });
/* unused harmony exports CheckableWalletDataCard, ClickableWalletDataCard, NewWalletCard */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _libs_icons_icons__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(8680);
/* harmony import */ var _libs_react_handles_boolean__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8544);
/* harmony import */ var _libs_ui_button__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9178);
/* harmony import */ var _libs_ui_dialog_dialog__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6488);
/* harmony import */ var _mods_foreground_components_page_header__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6915);
/* harmony import */ var _mods_foreground_components_page_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(179);
/* harmony import */ var _mods_foreground_router_path_context__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8097);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7294);
/* harmony import */ var _card__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9014);
/* harmony import */ var _context__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1949);
/* harmony import */ var _data__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9327);
/* harmony import */ var _create__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(3166);
/* eslint-disable @next/next/no-img-element */ 












function WalletsPage() {
    var _walletsQuery_data;
    const { go } = (0,_mods_foreground_router_path_context__WEBPACK_IMPORTED_MODULE_6__/* .usePathContext */ .td)().unwrap();
    const walletsQuery = (0,_data__WEBPACK_IMPORTED_MODULE_10__/* .useWallets */ .rB)();
    const maybeWallets = (_walletsQuery_data = walletsQuery.data) === null || _walletsQuery_data === void 0 ? void 0 : _walletsQuery_data.inner;
    const creator = (0,_libs_react_handles_boolean__WEBPACK_IMPORTED_MODULE_1__/* .useBooleanHandle */ .x)(false);
    const onWalletClick = (0,react__WEBPACK_IMPORTED_MODULE_7__.useCallback)((wallet)=>{
        go("/wallet/".concat(wallet.uuid));
    }, [
        go
    ]);
    const Body = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mods_foreground_components_page_header__WEBPACK_IMPORTED_MODULE_4__/* .PageBody */ .xV, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(ClickableWalletGrid, {
            ok: onWalletClick,
            create: creator.enable,
            wallets: maybeWallets
        })
    });
    const Header = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mods_foreground_components_page_header__WEBPACK_IMPORTED_MODULE_4__/* .UserPageHeader */ .To, {
                title: "Wallets",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_libs_ui_button__WEBPACK_IMPORTED_MODULE_2__/* .Button.Base */ .z.XY, {
                    className: "size-8 hovered-or-clicked-or-focused:scale-105 !transition",
                    onClick: creator.enable,
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: "".concat(_libs_ui_button__WEBPACK_IMPORTED_MODULE_2__/* .Button.Shrinker */ .z.Np.className),
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_libs_icons_icons__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                            className: "size-5"
                        })
                    })
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "po-md flex items-center",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                    className: "text-contrast",
                    children: "Wallets allow you to hold funds and generate signatures. You can import wallets from a private key or generate them from a seed."
                })
            })
        ]
    });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mods_foreground_components_page_page__WEBPACK_IMPORTED_MODULE_5__/* .Page */ .T, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_libs_ui_dialog_dialog__WEBPACK_IMPORTED_MODULE_3__/* .Dialog */ .Vq, {
                opened: creator.current,
                close: creator.disable,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_create__WEBPACK_IMPORTED_MODULE_11__/* .WalletCreatorDialog */ ._, {})
            }),
            Header,
            Body
        ]
    });
}
function ClickableWalletGrid(props) {
    const { wallets, ok, create } = props;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "grid grow place-content-start place-items-center gap-2 grid-cols-[repeat(auto-fill,minmax(10rem,1fr))]",
        children: [
            wallets === null || wallets === void 0 ? void 0 : wallets.map((wallet)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_context__WEBPACK_IMPORTED_MODULE_9__/* .WalletDataProvider */ .lp, {
                    uuid: wallet.uuid,
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(ClickableWalletDataCard, {
                        ok: ok
                    })
                }, wallet.uuid)),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(NewWalletCard, {
                ok: create
            })
        ]
    });
}
function SelectableWalletGrid(props) {
    const { wallets, ok, create, selecteds } = props;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "grid grow place-content-start place-items-center gap-2 grid-cols-[repeat(auto-fill,minmax(10rem,1fr))]",
        children: [
            wallets === null || wallets === void 0 ? void 0 : wallets.map((wallet)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(CheckableWalletDataCard, {
                    wallet: wallet,
                    index: selecteds.indexOf(wallet),
                    ok: ok
                }, wallet.uuid)),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(NewWalletCard, {
                ok: create
            })
        ]
    });
}
function CheckableWalletDataCard(props) {
    const { wallet, ok, index } = props;
    const checked = index !== -1;
    const onClick = (0,react__WEBPACK_IMPORTED_MODULE_7__.useCallback)(()=>{
        ok(wallet);
    }, [
        ok,
        wallet
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        className: "w-full aspect-video rounded-xl overflow-hidden cursor-pointer aria-checked:outline aria-checked:outline-2 aria-checked:outline-blue-600 animate-vibrate-loop",
        role: "checkbox",
        "aria-checked": checked,
        onClick: onClick,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_context__WEBPACK_IMPORTED_MODULE_9__/* .WalletDataProvider */ .lp, {
            uuid: wallet.uuid,
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_card__WEBPACK_IMPORTED_MODULE_8__/* .WalletDataCard */ .e, {
                index: index
            })
        })
    });
}
function ClickableWalletDataCard(props) {
    const wallet = (0,_context__WEBPACK_IMPORTED_MODULE_9__/* .useWalletDataContext */ .zI)().unwrap();
    const { ok } = props;
    const onClick = (0,react__WEBPACK_IMPORTED_MODULE_7__.useCallback)(()=>{
        ok(wallet);
    }, [
        ok,
        wallet
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        className: "w-full aspect-video rounded-xl overflow-hidden cursor-pointer hovered-or-clicked-or-focused:scale-105 !transition-transform",
        role: "button",
        onClick: onClick,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_card__WEBPACK_IMPORTED_MODULE_8__/* .WalletDataCard */ .e, {})
    });
}
function NewWalletCard(props) {
    const { ok } = props;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
        className: "po-md w-full aspect-video rounded-xl flex gap-2 justify-center items-center border border-contrast border-dashed hovered-or-clicked-or-focused:scale-105 !transition-transform",
        onClick: ok,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_libs_icons_icons__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                className: "size-5"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "font-medium",
                children: "New wallet"
            })
        ]
    });
}


/***/ }),

/***/ 3650:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   G: function() { return /* binding */ WalletAvatar; },
/* harmony export */   o: function() { return /* binding */ WalletIcon; }
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _libs_colors_colors__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4231);


function WalletIcon(props) {
    const { emoji, className } = props;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
        className: className,
        children: emoji
    });
}
function WalletAvatar(props) {
    const { colorIndex: color, emoji, className } = props;
    const [color1, color2] = _libs_colors_colors__WEBPACK_IMPORTED_MODULE_1__/* .Gradients */ .R.get(color);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        className: "bg-gradient-to-br from-".concat(color1, " to-").concat(color2, " rounded-full flex justify-center items-center ").concat(className),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(WalletIcon, {
            className: "",
            emoji: emoji
        })
    });
}


/***/ }),

/***/ 9014:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   T: function() { return /* binding */ SimpleWalletDataCard; },
/* harmony export */   e: function() { return /* binding */ WalletDataCard; }
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _libs_colors_colors__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4231);
/* harmony import */ var _libs_copy_copy__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1905);
/* harmony import */ var _libs_ethereum_mods_chain__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9183);
/* harmony import */ var _libs_icons_icons__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(6812);
/* harmony import */ var _libs_react_events__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8418);
/* harmony import */ var _libs_ui_button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9178);
/* harmony import */ var _hazae41_cubane__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(7657);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7294);
/* harmony import */ var _names_data__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(797);
/* harmony import */ var _unknown_data__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9801);
/* harmony import */ var _avatar__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3650);
/* harmony import */ var _context__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1949);
/* harmony import */ var _data__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(9327);
/* harmony import */ var _page__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3505);















function SimpleWalletDataCard() {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        className: "w-full aspect-video rounded-xl overflow-hidden",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(WalletDataCard, {})
    });
}
function WalletDataCard(props) {
    var _ens_data, _ens_data1;
    const wallet = (0,_context__WEBPACK_IMPORTED_MODULE_10__/* .useWalletDataContext */ .zI)().unwrap();
    const { index } = props;
    const mainnet = (0,_data__WEBPACK_IMPORTED_MODULE_11__/* .useEthereumContext */ .Kn)(wallet.uuid, _libs_ethereum_mods_chain__WEBPACK_IMPORTED_MODULE_3__/* .chainByChainId */ .DH[1]);
    const ens = (0,_names_data__WEBPACK_IMPORTED_MODULE_7__/* .useEnsReverseNoFetch */ .yh)(wallet.address, mainnet);
    const [color, color2] = _libs_colors_colors__WEBPACK_IMPORTED_MODULE_1__/* .Gradients */ .R.get(wallet.color);
    const onClickEllipsis = (0,_libs_react_events__WEBPACK_IMPORTED_MODULE_4__/* .useMouseCancel */ .I$)(()=>alert("This feature is not implemented yet"), []);
    const address = (0,react__WEBPACK_IMPORTED_MODULE_6__.useMemo)(()=>{
        return _hazae41_cubane__WEBPACK_IMPORTED_MODULE_13__/* .Address */ .k.from(wallet.address);
    }, [
        wallet.address
    ]);
    var _ens_data_inner;
    const ensOrAddress = (_ens_data_inner = (_ens_data = ens.data) === null || _ens_data === void 0 ? void 0 : _ens_data.inner) !== null && _ens_data_inner !== void 0 ? _ens_data_inner : address;
    var _ens_data_inner1;
    const ensOrAddressDisplay = (_ens_data_inner1 = (_ens_data1 = ens.data) === null || _ens_data1 === void 0 ? void 0 : _ens_data1.inner) !== null && _ens_data_inner1 !== void 0 ? _ens_data_inner1 : _hazae41_cubane__WEBPACK_IMPORTED_MODULE_13__/* .Address */ .k.format(address);
    const copyEthereumAddress = (0,_libs_copy_copy__WEBPACK_IMPORTED_MODULE_2__/* .useCopy */ .F)(ensOrAddress);
    const onClickCopyEthereumAddress = (0,_libs_react_events__WEBPACK_IMPORTED_MODULE_4__/* .useMouseCancel */ .I$)(copyEthereumAddress.run);
    const totalBalanceQuery = (0,_unknown_data__WEBPACK_IMPORTED_MODULE_8__/* .useTotalWalletPricedBalance */ .h7)(wallet.address, "usd");
    const totalBalanceDisplay = (0,_page__WEBPACK_IMPORTED_MODULE_12__/* .useCompactDisplayUsd */ .jJ)(totalBalanceQuery.current);
    const First = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex items-center",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "shrink-0",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_avatar__WEBPACK_IMPORTED_MODULE_9__/* .WalletIcon */ .o, {
                    className: "text-xl",
                    emoji: wallet.emoji
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "w-2 grow"
            }),
            index == null && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", {
                className: "".concat(_libs_ui_button__WEBPACK_IMPORTED_MODULE_5__/* .Button.Base */ .z.XY.className, " ").concat(_libs_ui_button__WEBPACK_IMPORTED_MODULE_5__/* .Button.White */ .z.Ej.className, " text-").concat(color),
                onClick: onClickEllipsis,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                    className: "".concat(_libs_ui_button__WEBPACK_IMPORTED_MODULE_5__/* .Button.Shrinker */ .z.Np.className),
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_libs_icons_icons__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                        className: "size-5"
                    })
                })
            }),
            index != null && index !== -1 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "border-2 border-white flex items-center justify-center rounded-full overflow-hidden",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                    className: "bg-blue-600 flex items-center justify-center size-5 text-white font-medium",
                    children: index + 1
                })
            }),
            index != null && index === -1 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "border-2 border-contrast flex items-center justify-center rounded-full",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                    className: "size-5"
                })
            })
        ]
    });
    const Name = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex items-center text-white font-medium",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "truncate",
                children: wallet.name
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "w-2 grow"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "font-base text-white-high-contrast",
                children: totalBalanceDisplay
            })
        ]
    });
    const AddressDisplay = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex justify-between items-center text-sm",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "text-white-high-contrast",
                children: "ETH"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "cursor-pointer text-white-high-contrast",
                onClick: onClickCopyEthereumAddress,
                children: copyEthereumAddress.current ? "Copied" : ensOrAddressDisplay
            })
        ]
    });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "po-md w-full h-full flex flex-col text-white bg-gradient-to-br from-".concat(color, " to-").concat(color2),
        children: [
            First,
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "grow"
            }),
            Name,
            AddressDisplay
        ]
    });
}


/***/ }),

/***/ 1949:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   lp: function() { return /* binding */ WalletDataProvider; },
/* harmony export */   zI: function() { return /* binding */ useWalletDataContext; }
/* harmony export */ });
/* unused harmony export WalletDataContext */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _hazae41_option__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5316);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7294);
/* harmony import */ var _data__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9327);




const WalletDataContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)(undefined);
function useWalletDataContext() {
    return _hazae41_option__WEBPACK_IMPORTED_MODULE_3__/* .Option */ .W.wrap((0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(WalletDataContext));
}
function WalletDataProvider(props) {
    const { uuid, children } = props;
    const wallet = (0,_data__WEBPACK_IMPORTED_MODULE_2__/* .useWallet */ .Os)(uuid);
    if (wallet.data == null) return null;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(WalletDataContext.Provider, {
        value: wallet.data.inner,
        children: children
    });
}


/***/ }),

/***/ 9327:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   IL: function() { return /* binding */ useEthereumContext2; },
/* harmony export */   Kn: function() { return /* binding */ useEthereumContext; },
/* harmony export */   Os: function() { return /* binding */ useWallet; },
/* harmony export */   QB: function() { return /* binding */ useWalletsBySeed; },
/* harmony export */   Vy: function() { return /* binding */ EthereumWalletInstance; },
/* harmony export */   rB: function() { return /* binding */ useWallets; },
/* harmony export */   yR: function() { return /* binding */ fetchOrFail; }
/* harmony export */ });
/* unused harmony exports FgWallet, EthereumSeededWalletInstance, EthereumUnauthPrivateKeyWalletInstance, EthereumAuthPrivateKeyWalletInstance */
/* harmony import */ var _libs_glacier_mutators__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9949);
/* harmony import */ var _libs_webauthn_webauthn__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(299);
/* harmony import */ var _mods_background_service_worker_entities_wallets_data__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7917);
/* harmony import */ var _hazae41_base16__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(2248);
/* harmony import */ var _hazae41_base64__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(9467);
/* harmony import */ var _hazae41_glacier__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6233);
/* harmony import */ var _hazae41_glacier__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8123);
/* harmony import */ var _hazae41_glacier__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(564);
/* harmony import */ var _hazae41_glacier__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(1458);
/* harmony import */ var _hazae41_option__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(5316);
/* harmony import */ var _hazae41_result__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(2564);
/* harmony import */ var _hazae41_result__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(918);
/* harmony import */ var _hazae41_result__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(5591);
/* harmony import */ var ethers__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(8884);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7294);
/* harmony import */ var _background_context__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5855);
/* harmony import */ var _storage_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(604);
/* harmony import */ var _storage_user__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9718);
/* harmony import */ var _seeds_all_helpers__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5867);
/* harmony import */ var _seeds_data__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(253);
var __addDisposableResource = undefined && undefined.__addDisposableResource || function(env, value, async) {
    if (value !== null && value !== void 0) {
        if (typeof value !== "object" && typeof value !== "function") throw new TypeError("Object expected.");
        var dispose;
        if (async) {
            if (!Symbol.asyncDispose) throw new TypeError("Symbol.asyncDispose is not defined.");
            dispose = value[Symbol.asyncDispose];
        }
        if (dispose === void 0) {
            if (!Symbol.dispose) throw new TypeError("Symbol.dispose is not defined.");
            dispose = value[Symbol.dispose];
        }
        if (typeof dispose !== "function") throw new TypeError("Object not disposable.");
        env.stack.push({
            value: value,
            dispose: dispose,
            async: async
        });
    } else if (async) {
        env.stack.push({
            async: true
        });
    }
    return value;
};
var __disposeResources = undefined && undefined.__disposeResources || function(SuppressedError1) {
    return function(env) {
        function fail(e) {
            env.error = env.hasError ? new SuppressedError1(e, env.error, "An error was suppressed during disposal.") : e;
            env.hasError = true;
        }
        function next() {
            while(env.stack.length){
                var rec = env.stack.pop();
                try {
                    var result = rec.dispose && rec.dispose.call(rec.value);
                    if (rec.async) return Promise.resolve(result).then(next, function(e) {
                        fail(e);
                        return next();
                    });
                } catch (e) {
                    fail(e);
                }
            }
            if (env.hasError) throw env.error;
        }
        return next();
    };
}(typeof SuppressedError === "function" ? SuppressedError : function(error, suppressed, message) {
    var e = new Error(message);
    return e.name = "SuppressedError", e.error = error, e.suppressed = suppressed, e;
});















var FgWallet;
(function(FgWallet) {
    let All;
    (function(All) {
        let BySeed;
        (function(BySeed) {
            BySeed.key = _mods_background_service_worker_entities_wallets_data__WEBPACK_IMPORTED_MODULE_2__/* .BgWallet */ .U.All.BySeed.key;
            function schema(uuid, storage) {
                if (uuid == null) return;
                return (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_9__/* .createQuery */ .rP)({
                    key: BySeed.key(uuid),
                    storage
                });
            }
            BySeed.schema = schema;
        })(BySeed = All.BySeed || (All.BySeed = {}));
        All.key = _mods_background_service_worker_entities_wallets_data__WEBPACK_IMPORTED_MODULE_2__/* .BgWallet */ .U.All.key;
        function schema(storage) {
            return (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_9__/* .createQuery */ .rP)({
                key: All.key,
                storage
            });
        }
        All.schema = schema;
    })(All = FgWallet.All || (FgWallet.All = {}));
    FgWallet.key = _mods_background_service_worker_entities_wallets_data__WEBPACK_IMPORTED_MODULE_2__/* .BgWallet */ .U.key;
    function schema(uuid, storage) {
        if (uuid == null) return;
        const indexer = async (states)=>{
            var _previous_real, _current_real;
            const { current, previous = current } = states;
            const previousData = (_previous_real = previous.real) === null || _previous_real === void 0 ? void 0 : _previous_real.data;
            const currentData = (_current_real = current.real) === null || _current_real === void 0 ? void 0 : _current_real.data;
            await All.schema(storage).mutate(_libs_glacier_mutators__WEBPACK_IMPORTED_MODULE_0__/* .Mutators */ .g.mapData(function() {
                let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : new _hazae41_glacier__WEBPACK_IMPORTED_MODULE_10__/* .Data */ .V([]);
                if ((previousData === null || previousData === void 0 ? void 0 : previousData.inner.uuid) === (currentData === null || currentData === void 0 ? void 0 : currentData.inner.uuid)) return d;
                if (previousData != null) d = d.mapSync((p)=>p.filter((x)=>x.uuid !== previousData.inner.uuid));
                if (currentData != null) d = d.mapSync((p)=>[
                        ...p,
                        _mods_background_service_worker_entities_wallets_data__WEBPACK_IMPORTED_MODULE_2__/* .WalletRef */ .V.from(currentData.inner)
                    ]);
                return d;
            }));
            if ((currentData === null || currentData === void 0 ? void 0 : currentData.inner.type) === "seeded") {
                const { seed } = currentData.inner;
                const walletsBySeedQuery = All.BySeed.schema(seed.uuid, storage);
                await (walletsBySeedQuery === null || walletsBySeedQuery === void 0 ? void 0 : walletsBySeedQuery.mutate(_libs_glacier_mutators__WEBPACK_IMPORTED_MODULE_0__/* .Mutators */ .g.mapData(function() {
                    let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : new _hazae41_glacier__WEBPACK_IMPORTED_MODULE_10__/* .Data */ .V([]);
                    if ((previousData === null || previousData === void 0 ? void 0 : previousData.inner.uuid) === (currentData === null || currentData === void 0 ? void 0 : currentData.inner.uuid)) return d;
                    if (previousData != null) d = d.mapSync((p)=>p.filter((x)=>x.uuid !== previousData.inner.uuid));
                    if (currentData != null) d = d.mapSync((p)=>[
                            ...p,
                            _mods_background_service_worker_entities_wallets_data__WEBPACK_IMPORTED_MODULE_2__/* .WalletRef */ .V.from(currentData.inner)
                        ]);
                    return d;
                })));
            }
        };
        return (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_9__/* .createQuery */ .rP)({
            key: FgWallet.key(uuid),
            indexer,
            storage
        });
    }
    FgWallet.schema = schema;
})(FgWallet || (FgWallet = {}));
function useWallet(uuid) {
    const storage = (0,_storage_user__WEBPACK_IMPORTED_MODULE_6__/* .useUserStorageContext */ .v6)().unwrap();
    const query = (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_11__/* .useQuery */ .aM)(FgWallet.schema, [
        uuid,
        storage
    ]);
    (0,_storage_storage__WEBPACK_IMPORTED_MODULE_5__/* .useSubscribe */ .Q)(query, storage);
    return query;
}
function useWallets() {
    const storage = (0,_storage_user__WEBPACK_IMPORTED_MODULE_6__/* .useUserStorageContext */ .v6)().unwrap();
    const query = (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_11__/* .useQuery */ .aM)(FgWallet.All.schema, [
        storage
    ]);
    (0,_storage_storage__WEBPACK_IMPORTED_MODULE_5__/* .useSubscribe */ .Q)(query, storage);
    return query;
}
function useWalletsBySeed(uuid) {
    const storage = (0,_storage_user__WEBPACK_IMPORTED_MODULE_6__/* .useUserStorageContext */ .v6)().unwrap();
    const query = (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_11__/* .useQuery */ .aM)(FgWallet.All.BySeed.schema, [
        uuid,
        storage
    ]);
    (0,_storage_storage__WEBPACK_IMPORTED_MODULE_5__/* .useSubscribe */ .Q)(query, storage);
    return query;
}
var EthereumWalletInstance;
(function(EthereumWalletInstance) {
    async function tryFrom(wallet, background) {
        if (wallet.type === "privateKey") return await EthereumUnauthPrivateKeyWalletInstance.tryNew(wallet, background);
        if (wallet.type === "authPrivateKey") return await EthereumAuthPrivateKeyWalletInstance.tryNew(wallet, background);
        if (wallet.type === "seeded") return await EthereumSeededWalletInstance.tryNew(wallet, background);
        throw new _hazae41_result__WEBPACK_IMPORTED_MODULE_12__/* .Panic */ .F5();
    }
    EthereumWalletInstance.tryFrom = tryFrom;
})(EthereumWalletInstance || (EthereumWalletInstance = {}));
class EthereumSeededWalletInstance {
    static async tryNew(data, background) {
        return await _hazae41_result__WEBPACK_IMPORTED_MODULE_13__/* .Result */ .x.unthrow(async (t)=>{
            var _seedState_data;
            const storage = new _storage_user__WEBPACK_IMPORTED_MODULE_6__/* .UserStorage */ .Jt(background);
            const seedQuery = _seeds_data__WEBPACK_IMPORTED_MODULE_8__/* .FgSeed */ .EU.schema(data.seed.uuid, storage);
            const seedState = await (seedQuery === null || seedQuery === void 0 ? void 0 : seedQuery.state);
            const seedData = _hazae41_option__WEBPACK_IMPORTED_MODULE_14__/* .Option */ .W.wrap(seedState === null || seedState === void 0 ? void 0 : (_seedState_data = seedState.data) === null || _seedState_data === void 0 ? void 0 : _seedState_data.inner).ok().throw(t);
            const seed = await _seeds_all_helpers__WEBPACK_IMPORTED_MODULE_7__/* .SeedInstance */ .Gz.tryFrom(seedData, background).then((r)=>r.throw(t));
            return new _hazae41_result__WEBPACK_IMPORTED_MODULE_15__.Ok(new EthereumSeededWalletInstance(data, seed));
        });
    }
    async tryGetPrivateKey(background) {
        return await this.seed.tryGetPrivateKey(this.data.path, background);
    }
    async trySignPersonalMessage(message, background) {
        return await this.seed.trySignPersonalMessage(this.data.path, message, background);
    }
    async trySignTransaction(transaction, background) {
        return await this.seed.trySignTransaction(this.data.path, transaction, background);
    }
    async trySignEIP712HashedMessage(data, background) {
        return await this.seed.trySignEIP712HashedMessage(this.data.path, data, background);
    }
    constructor(data, seed){
        this.data = data;
        this.seed = seed;
    }
}
class EthereumUnauthPrivateKeyWalletInstance {
    static async tryNew(data, background) {
        return new _hazae41_result__WEBPACK_IMPORTED_MODULE_15__.Ok(new EthereumUnauthPrivateKeyWalletInstance(data));
    }
    async tryGetPrivateKey(background) {
        return new _hazae41_result__WEBPACK_IMPORTED_MODULE_15__.Ok(this.data.privateKey);
    }
    async trySignPersonalMessage(message, background) {
        return await _hazae41_result__WEBPACK_IMPORTED_MODULE_13__/* .Result */ .x.unthrow(async (t)=>{
            const privateKey = await this.tryGetPrivateKey(background).then((r)=>r.throw(t));
            const signature = await _hazae41_result__WEBPACK_IMPORTED_MODULE_13__/* .Result */ .x.runAndDoubleWrap(async ()=>{
                return await new ethers__WEBPACK_IMPORTED_MODULE_16__/* .Wallet */ .w(privateKey).signMessage(message);
            }).then((r)=>r.throw(t));
            return new _hazae41_result__WEBPACK_IMPORTED_MODULE_15__.Ok(signature);
        });
    }
    async trySignTransaction(transaction, background) {
        return await _hazae41_result__WEBPACK_IMPORTED_MODULE_13__/* .Result */ .x.unthrow(async (t)=>{
            const privateKey = await this.tryGetPrivateKey(background).then((r)=>r.throw(t));
            const signature = _hazae41_result__WEBPACK_IMPORTED_MODULE_13__/* .Result */ .x.runAndDoubleWrapSync(()=>{
                return new ethers__WEBPACK_IMPORTED_MODULE_16__/* .Wallet */ .w(privateKey).signingKey.sign(transaction.unsignedHash).serialized;
            }).throw(t);
            return new _hazae41_result__WEBPACK_IMPORTED_MODULE_15__.Ok(signature);
        });
    }
    async trySignEIP712HashedMessage(data, background) {
        return await _hazae41_result__WEBPACK_IMPORTED_MODULE_13__/* .Result */ .x.unthrow(async (t)=>{
            const privateKey = await this.tryGetPrivateKey(background).then((r)=>r.throw(t));
            delete data.types["EIP712Domain"];
            const signature = await _hazae41_result__WEBPACK_IMPORTED_MODULE_13__/* .Result */ .x.runAndDoubleWrap(async ()=>{
                return await new ethers__WEBPACK_IMPORTED_MODULE_16__/* .Wallet */ .w(privateKey).signTypedData(data.domain, data.types, data.message);
            }).then((r)=>r.throw(t));
            return new _hazae41_result__WEBPACK_IMPORTED_MODULE_15__.Ok(signature);
        });
    }
    constructor(data){
        this.data = data;
    }
}
class EthereumAuthPrivateKeyWalletInstance {
    static async tryNew(data, background) {
        return new _hazae41_result__WEBPACK_IMPORTED_MODULE_15__.Ok(new EthereumAuthPrivateKeyWalletInstance(data));
    }
    async tryGetPrivateKey(background) {
        return await _hazae41_result__WEBPACK_IMPORTED_MODULE_13__/* .Result */ .x.unthrow(async (t)=>{
            const env_1 = {
                stack: [],
                error: void 0,
                hasError: false
            };
            try {
                const { idBase64, ivBase64 } = this.data.privateKey;
                const id = _hazae41_base64__WEBPACK_IMPORTED_MODULE_17__/* .get */ .U().tryDecodePadded(idBase64).throw(t).copyAndDispose();
                const cipher = await _libs_webauthn_webauthn__WEBPACK_IMPORTED_MODULE_1__/* .WebAuthnStorage */ .g.tryGet(id).then((r)=>r.throw(t));
                const cipherBase64 = _hazae41_base64__WEBPACK_IMPORTED_MODULE_17__/* .get */ .U().tryEncodePadded(cipher).throw(t);
                const privateKeyBase64 = await background.tryRequest({
                    method: "brume_decrypt",
                    params: [
                        ivBase64,
                        cipherBase64
                    ]
                }).then((r)=>r.throw(t).throw(t));
                const privateKeyMemory = __addDisposableResource(env_1, _hazae41_base64__WEBPACK_IMPORTED_MODULE_17__/* .get */ .U().tryDecodePadded(privateKeyBase64).throw(t), false);
                return new _hazae41_result__WEBPACK_IMPORTED_MODULE_15__.Ok("0x".concat(_hazae41_base16__WEBPACK_IMPORTED_MODULE_18__/* .get */ .U().tryEncode(privateKeyMemory).throw(t)));
            } catch (e_1) {
                env_1.error = e_1;
                env_1.hasError = true;
            } finally{
                __disposeResources(env_1);
            }
        });
    }
    async trySignPersonalMessage(message, background) {
        return await _hazae41_result__WEBPACK_IMPORTED_MODULE_13__/* .Result */ .x.unthrow(async (t)=>{
            const privateKey = await this.tryGetPrivateKey(background).then((r)=>r.throw(t));
            const signature = await _hazae41_result__WEBPACK_IMPORTED_MODULE_13__/* .Result */ .x.runAndDoubleWrap(async ()=>{
                return await new ethers__WEBPACK_IMPORTED_MODULE_16__/* .Wallet */ .w(privateKey).signMessage(message);
            }).then((r)=>r.throw(t));
            return new _hazae41_result__WEBPACK_IMPORTED_MODULE_15__.Ok(signature);
        });
    }
    async trySignTransaction(transaction, background) {
        return await _hazae41_result__WEBPACK_IMPORTED_MODULE_13__/* .Result */ .x.unthrow(async (t)=>{
            const privateKey = await this.tryGetPrivateKey(background).then((r)=>r.throw(t));
            const signature = _hazae41_result__WEBPACK_IMPORTED_MODULE_13__/* .Result */ .x.runAndDoubleWrapSync(()=>{
                return new ethers__WEBPACK_IMPORTED_MODULE_16__/* .Wallet */ .w(privateKey).signingKey.sign(transaction.unsignedHash).serialized;
            }).throw(t);
            return new _hazae41_result__WEBPACK_IMPORTED_MODULE_15__.Ok(signature);
        });
    }
    async trySignEIP712HashedMessage(data, background) {
        return await _hazae41_result__WEBPACK_IMPORTED_MODULE_13__/* .Result */ .x.unthrow(async (t)=>{
            const privateKey = await this.tryGetPrivateKey(background).then((r)=>r.throw(t));
            delete data.types["EIP712Domain"];
            const signature = await _hazae41_result__WEBPACK_IMPORTED_MODULE_13__/* .Result */ .x.runAndDoubleWrap(async ()=>{
                return await new ethers__WEBPACK_IMPORTED_MODULE_16__/* .Wallet */ .w(privateKey).signTypedData(data.domain, data.types, data.message);
            }).then((r)=>r.throw(t));
            return new _hazae41_result__WEBPACK_IMPORTED_MODULE_15__.Ok(signature);
        });
    }
    constructor(data){
        this.data = data;
    }
}
function useEthereumContext(uuid, chain) {
    const background = (0,_background_context__WEBPACK_IMPORTED_MODULE_4__/* .useBackgroundContext */ .D_)().unwrap();
    const maybeContext = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(()=>{
        if (uuid == null) return;
        if (chain == null) return;
        return {
            uuid,
            chain,
            background
        };
    }, [
        uuid,
        chain,
        background
    ]);
    return maybeContext;
}
function useEthereumContext2(uuid, chain) {
    const background = (0,_background_context__WEBPACK_IMPORTED_MODULE_4__/* .useBackgroundContext */ .D_)().unwrap();
    const maybeContext = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(()=>{
        if (uuid == null) return;
        if (chain == null) return;
        return {
            uuid,
            chain,
            background
        };
    }, [
        uuid,
        chain,
        background
    ]);
    return _hazae41_option__WEBPACK_IMPORTED_MODULE_14__/* .Option */ .W.wrap(maybeContext);
}
async function fetchOrFail(request, ethereum) {
    const { uuid, background, chain } = ethereum;
    return await background.tryRequest({
        method: "brume_eth_fetch",
        params: [
            uuid,
            chain.chainId,
            request
        ]
    }).then((r)=>_hazae41_glacier__WEBPACK_IMPORTED_MODULE_19__/* .Fetched */ .F.rewrap(r.unwrap()));
}


/***/ }),

/***/ 3505:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Zi: function() { return /* binding */ PriceResolver; },
  ds: function() { return /* binding */ WalletPage; },
  jJ: function() { return /* binding */ useCompactDisplayUsd; },
  iZ: function() { return /* binding */ useDisplayUsd; }
});

// UNUSED EXPORTS: useDisplay

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
// EXTERNAL MODULE: ./src/libs/colors/colors.ts
var colors = __webpack_require__(4231);
// EXTERNAL MODULE: ./src/libs/errors/errors.ts
var errors = __webpack_require__(8524);
// EXTERNAL MODULE: ./src/libs/ethereum/mods/chain.tsx
var mods_chain = __webpack_require__(9183);
// EXTERNAL MODULE: ./src/libs/glacier/mutators.ts
var mutators = __webpack_require__(9949);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/QrCodeIcon.js
var QrCodeIcon = __webpack_require__(4435);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/LinkIcon.js
var LinkIcon = __webpack_require__(23);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/EyeIcon.js
var EyeIcon = __webpack_require__(2940);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/PaperAirplaneIcon.js
var PaperAirplaneIcon = __webpack_require__(882);
// EXTERNAL MODULE: ./src/libs/modhash/modhash.ts
var modhash = __webpack_require__(4628);
// EXTERNAL MODULE: ./src/libs/react/events.ts
var events = __webpack_require__(8418);
// EXTERNAL MODULE: ./src/libs/react/handles/boolean.tsx
var handles_boolean = __webpack_require__(8544);
// EXTERNAL MODULE: ./src/libs/results/results.ts
var results = __webpack_require__(7519);
// EXTERNAL MODULE: ./src/libs/ui/button.tsx + 8 modules
var ui_button = __webpack_require__(9178);
// EXTERNAL MODULE: ./src/libs/ui/dialog/dialog.tsx
var dialog = __webpack_require__(6488);
// EXTERNAL MODULE: ./src/libs/url/url.ts
var url_url = __webpack_require__(872);
// EXTERNAL MODULE: ./node_modules/@hazae41/base16/dist/esm/src/mods/base16/adapter.mjs
var adapter = __webpack_require__(2248);
// EXTERNAL MODULE: ./node_modules/@hazae41/bytes/dist/esm/mods/bytes/bytes.mjs + 3 modules
var bytes_bytes = __webpack_require__(1694);
// EXTERNAL MODULE: ./node_modules/@hazae41/option/dist/esm/mods/option/option.mjs
var option_option = __webpack_require__(5316);
// EXTERNAL MODULE: ./node_modules/@hazae41/option/dist/esm/mods/option/none.mjs
var none = __webpack_require__(1371);
// EXTERNAL MODULE: ./node_modules/@hazae41/option/dist/esm/mods/option/some.mjs
var some = __webpack_require__(8862);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/result.mjs
var result = __webpack_require__(918);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/ok.mjs
var ok = __webpack_require__(5591);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/err.mjs
var err = __webpack_require__(166);
// EXTERNAL MODULE: ./node_modules/@hazae41/x25519/dist/esm/src/mods/x25519/adapter.mjs
var x25519_adapter = __webpack_require__(7747);
// EXTERNAL MODULE: ./node_modules/@swc/helpers/esm/_class_private_field_get.js + 1 modules
var _class_private_field_get = __webpack_require__(7121);
// EXTERNAL MODULE: ./node_modules/@swc/helpers/esm/_class_private_field_init.js
var _class_private_field_init = __webpack_require__(9886);
// EXTERNAL MODULE: ./node_modules/@swc/helpers/esm/_class_private_field_set.js + 1 modules
var _class_private_field_set = __webpack_require__(5321);
// EXTERNAL MODULE: ./node_modules/@swc/helpers/esm/_class_private_method_get.js
var _class_private_method_get = __webpack_require__(6723);
// EXTERNAL MODULE: ./node_modules/@swc/helpers/esm/_class_private_method_init.js
var _class_private_method_init = __webpack_require__(9979);
// EXTERNAL MODULE: ./node_modules/@hazae41/binary/dist/esm/mods/binary/writable.mjs
var writable = __webpack_require__(2008);
// EXTERNAL MODULE: ./node_modules/@hazae41/binary/dist/esm/mods/binary/opaque.mjs
var opaque = __webpack_require__(468);
;// CONCATENATED MODULE: ./src/libs/wconn/mods/crypto/crypto.ts



var _a, _b, _c;


var _class = /*#__PURE__*/ new WeakMap();
class CryptoError extends Error {
    static from(cause) {
        return new _a(undefined, {
            cause
        });
    }
    constructor(...args){
        super(...args);
        (0,_class_private_field_init._)(this, _class, {
            writable: true,
            value: void 0
        });
        (0,_class_private_field_set._)(this, _class, _a);
        this.name = (0,_class_private_field_get._)(this, _class).name;
    }
}
_a = CryptoError;
class Plaintext {
    encryptOrThrow(key, iv) {
        const plain = writable/* Writable */.c.writeToBytesOrThrow(this.fragment);
        const cipher = key.tryEncrypt(plain, iv).unwrap().copyAndDispose();
        return new Ciphertext(iv, cipher);
    }
    tryEncrypt(key, iv) {
        return result/* Result */.x.runAndDoubleWrapSync(()=>this.encryptOrThrow(key, iv));
    }
    constructor(fragment){
        this.fragment = fragment;
    }
}
class Ciphertext {
    decryptOrThrow(key) {
        const plain = key.tryDecrypt(this.inner, this.iv).unwrap().copyAndDispose();
        return new Plaintext(new opaque/* Opaque */.lD(plain));
    }
    tryDecrypt(key) {
        return result/* Result */.x.runAndDoubleWrapSync(()=>this.decryptOrThrow(key));
    }
    sizeOrThrow() {
        return this.iv.length + this.inner.length;
    }
    writeOrThrow(cursor) {
        cursor.writeOrThrow(this.iv);
        cursor.writeOrThrow(this.inner);
    }
    static readOrThrow(cursor) {
        const iv = cursor.readAndCopyOrThrow(12);
        const inner = cursor.readAndCopyOrThrow(cursor.remaining);
        return new Ciphertext(iv, inner);
    }
    constructor(iv, inner){
        this.iv = iv;
        this.inner = inner;
    }
}
var Envelope;
(function(Envelope) {
    var _d;
    var _class = /*#__PURE__*/ new WeakMap();
    class UnknownTypeError extends Error {
        constructor(type){
            super("Unknown type ".concat(type));
            (0,_class_private_field_init._)(this, _class, {
                writable: true,
                value: void 0
            });
            (0,_class_private_field_set._)(this, _class, _d);
            this.name = (0,_class_private_field_get._)(this, _class).name;
            this.type = type;
        }
    }
    _d = UnknownTypeError;
    Envelope.UnknownTypeError = UnknownTypeError;
    function readOrThrow(cursor) {
        const type = cursor.getUint8OrThrow();
        if (type === 0) return EnvelopeTypeZero.readOrThrow(cursor);
        if (type === 1) return EnvelopeTypeOne.readOrThrow(cursor);
        throw new UnknownTypeError(type);
    }
    Envelope.readOrThrow = readOrThrow;
})(Envelope || (Envelope = {}));
var _class1 = /*#__PURE__*/ new WeakMap();
class EnvelopeTypeZero {
    sizeOrThrow() {
        return 1 + this.fragment.sizeOrThrow();
    }
    writeOrThrow(cursor) {
        cursor.writeUint8OrThrow(this.type);
        this.fragment.writeOrThrow(cursor);
    }
    static readOrThrow(cursor) {
        const type = cursor.readUint8OrThrow();
        if (type !== _b.type) throw new Error("Invalid type-0 type ".concat(type));
        const bytes = cursor.readAndCopyOrThrow(cursor.remaining);
        const fragment = new opaque/* Opaque */.lD(bytes);
        return new _b(fragment);
    }
    constructor(fragment){
        (0,_class_private_field_init._)(this, _class1, {
            writable: true,
            value: void 0
        });
        (0,_class_private_field_set._)(this, _class1, _b);
        this.type = (0,_class_private_field_get._)(this, _class1).type;
        this.fragment = fragment;
    }
}
EnvelopeTypeZero.type = 0;
_b = EnvelopeTypeZero;
var _class2 = /*#__PURE__*/ new WeakMap();
class EnvelopeTypeOne {
    sizeOrThrow() {
        return 1 + this.sender.length + this.fragment.sizeOrThrow();
    }
    writeOrThrow(cursor) {
        cursor.writeUint8OrThrow(this.type);
        cursor.writeOrThrow(this.sender);
        this.fragment.writeOrThrow(cursor);
    }
    static readOrThrow(cursor) {
        const type = cursor.readUint8OrThrow();
        if (type !== _c.type) throw new Error("Invalid type ".concat(type));
        const sender = cursor.readAndCopyOrThrow(32);
        const bytes = cursor.readAndCopyOrThrow(cursor.remaining);
        const fragment = new opaque/* Opaque */.lD(bytes);
        return new _c(sender, fragment);
    }
    constructor(sender, fragment){
        (0,_class_private_field_init._)(this, _class2, {
            writable: true,
            value: void 0
        });
        (0,_class_private_field_set._)(this, _class2, _c);
        this.type = (0,_class_private_field_get._)(this, _class2).type;
        this.sender = sender;
        this.fragment = fragment;
    }
}
EnvelopeTypeOne.type = 1;
_c = EnvelopeTypeOne;

;// CONCATENATED MODULE: ./src/libs/wconn/mods/json/json.ts
var BigJson;
(function(BigJson) {
    /**
     * Bigger than MAX_SAFE_INTEGER
     */ const BIG_REGEX = /([\[:])?(\d{17,}|(?:[9](?:[1-9]07199254740991|0[1-9]7199254740991|00[8-9]199254740991|007[2-9]99254740991|007199[3-9]54740991|0071992[6-9]4740991|00719925[5-9]740991|007199254[8-9]40991|0071992547[5-9]0991|00719925474[1-9]991|00719925474099[2-9])))([,\}\]])/g;
    function stringify(value) {
        function replacer(key, value) {
            if (typeof value !== "bigint") return value;
            return "".concat(value.toString(), "n");
        }
        return JSON.stringify(value, replacer);
    }
    BigJson.stringify = stringify;
    function parse(text) {
        const replaced = text.replace(BIG_REGEX, '$1"$2n"$3');
        function reviver(key, value) {
            if (typeof value !== "string") return value;
            if (!value.match(/^\d+n$/)) return value;
            return BigInt(value.slice(0, -1));
        }
        return JSON.parse(replaced, reviver);
    }
    BigJson.parse = parse;
})(BigJson || (BigJson = {}));
var SafeJson;
(function(SafeJson) {
    function stringify(value) {
        if (typeof value === "string") return value;
        return BigJson.stringify(value);
    }
    SafeJson.stringify = stringify;
    function parse(text) {
        try {
            return BigJson.parse(text);
        } catch (e) {
            return text;
        }
    }
    SafeJson.parse = parse;
})(SafeJson || (SafeJson = {}));

// EXTERNAL MODULE: ./node_modules/@hazae41/base64/dist/esm/src/mods/base64/adapter.mjs
var base64_adapter = __webpack_require__(9467);
// EXTERNAL MODULE: ./node_modules/@hazae41/binary/dist/esm/mods/binary/readable.mjs
var readable = __webpack_require__(1916);
// EXTERNAL MODULE: ./node_modules/@hazae41/chacha20poly1305/dist/esm/src/mods/chacha20poly1305/adapter.mjs
var chacha20poly1305_adapter = __webpack_require__(5751);
// EXTERNAL MODULE: ./node_modules/@hazae41/future/dist/esm/mods/future/future.mjs
var future_future = __webpack_require__(6071);
// EXTERNAL MODULE: ./node_modules/@hazae41/jsonrpc/dist/esm/mods/rpc/response.mjs
var rpc_response = __webpack_require__(5457);
// EXTERNAL MODULE: ./node_modules/@hazae41/plume/dist/esm/src/mods/target.mjs
var target = __webpack_require__(4232);
// EXTERNAL MODULE: ./node_modules/@hazae41/jsonrpc/dist/esm/mods/rpc/request.mjs
var request = __webpack_require__(4356);
// EXTERNAL MODULE: ./node_modules/@hazae41/plume/dist/esm/src/mods/errors.mjs
var mods_errors = __webpack_require__(9107);
;// CONCATENATED MODULE: ./src/libs/wconn/mods/rpc/rpc.ts





var SafeRpc;
(function(SafeRpc) {
    function prepare(init) {
        const id = Date.now() + Math.floor(Math.random() * 1000);
        return new request/* RpcRequest */.a(id, init.method, init.params);
    }
    SafeRpc.prepare = prepare;
    async function tryRequest(socket, init, signal) {
        const request = prepare(init);
        socket.send(SafeJson.stringify(request));
        const future = new future_future/* Future */.o();
        const onMessage = async (event)=>{
            if (typeof event.data !== "string") return;
            const response = rpc_response/* RpcResponse */.S.from(SafeJson.parse(event.data));
            if (response.id !== request.id) return;
            future.resolve(new ok.Ok(response));
        };
        const onError = (e)=>{
            future.resolve(new err/* Err */.U(mods_errors/* ErroredError */.kN.from(e)));
        };
        const onClose = (e)=>{
            future.resolve(new err/* Err */.U(mods_errors/* ClosedError */.$A.from(e)));
        };
        const onAbort = ()=>{
            future.resolve(new err/* Err */.U(mods_errors/* AbortedError */.pe.from(signal.reason)));
        };
        try {
            socket.addEventListener("message", onMessage, {
                passive: true
            });
            socket.addEventListener("close", onClose, {
                passive: true
            });
            socket.addEventListener("error", onError, {
                passive: true
            });
            signal.addEventListener("abort", onAbort, {
                passive: true
            });
            return await future.promise;
        } finally{
            socket.removeEventListener("message", onMessage);
            socket.removeEventListener("close", onClose);
            socket.removeEventListener("error", onError);
            signal.removeEventListener("abort", onAbort);
        }
    }
    SafeRpc.tryRequest = tryRequest;
})(SafeRpc || (SafeRpc = {}));

;// CONCATENATED MODULE: ./src/libs/wconn/mods/crypto/client.ts





var __addDisposableResource = undefined && undefined.__addDisposableResource || function(env, value, async) {
    if (value !== null && value !== void 0) {
        if (typeof value !== "object" && typeof value !== "function") throw new TypeError("Object expected.");
        var dispose;
        if (async) {
            if (!Symbol.asyncDispose) throw new TypeError("Symbol.asyncDispose is not defined.");
            dispose = value[Symbol.asyncDispose];
        }
        if (dispose === void 0) {
            if (!Symbol.dispose) throw new TypeError("Symbol.dispose is not defined.");
            dispose = value[Symbol.dispose];
        }
        if (typeof dispose !== "function") throw new TypeError("Object not disposable.");
        env.stack.push({
            value: value,
            dispose: dispose,
            async: async
        });
    } else if (async) {
        env.stack.push({
            async: true
        });
    }
    return value;
};
var __disposeResources = undefined && undefined.__disposeResources || function(SuppressedError1) {
    return function(env) {
        function fail(e) {
            env.error = env.hasError ? new SuppressedError1(e, env.error, "An error was suppressed during disposal.") : e;
            env.hasError = true;
        }
        function next() {
            while(env.stack.length){
                var rec = env.stack.pop();
                try {
                    var result = rec.dispose && rec.dispose.call(rec.value);
                    if (rec.async) return Promise.resolve(result).then(next, function(e) {
                        fail(e);
                        return next();
                    });
                } catch (e) {
                    fail(e);
                }
            }
            if (env.hasError) throw env.error;
        }
        return next();
    };
}(typeof SuppressedError === "function" ? SuppressedError : function(error, suppressed, message) {
    var e = new Error(message);
    return e.name = "SuppressedError", e.error = error, e.suppressed = suppressed, e;
});












const ENGINE_RPC_OPTS = {
    wc_sessionPropose: {
        req: {
            ttl: 5 * 60,
            prompt: true,
            tag: 1100
        },
        res: {
            ttl: 5 * 60,
            prompt: false,
            tag: 1101
        }
    },
    wc_sessionSettle: {
        req: {
            ttl: 5 * 60,
            prompt: false,
            tag: 1102
        },
        res: {
            ttl: 5 * 60,
            prompt: false,
            tag: 1103
        }
    },
    wc_sessionUpdate: {
        req: {
            ttl: 24 * 60 * 60,
            prompt: false,
            tag: 1104
        },
        res: {
            ttl: 24 * 60 * 60,
            prompt: false,
            tag: 1105
        }
    },
    wc_sessionExtend: {
        req: {
            ttl: 24 * 60 * 60,
            prompt: false,
            tag: 1106
        },
        res: {
            ttl: 24 * 60 * 60,
            prompt: false,
            tag: 1107
        }
    },
    wc_sessionRequest: {
        req: {
            ttl: 5 * 60,
            prompt: true,
            tag: 1108
        },
        res: {
            ttl: 5 * 60,
            prompt: false,
            tag: 1109
        }
    },
    wc_sessionEvent: {
        req: {
            ttl: 5 * 60,
            prompt: true,
            tag: 1110
        },
        res: {
            ttl: 5 * 60,
            prompt: false,
            tag: 1111
        }
    },
    wc_sessionDelete: {
        req: {
            ttl: 24 * 60 * 60,
            prompt: false,
            tag: 1112
        },
        res: {
            ttl: 24 * 60 * 60,
            prompt: false,
            tag: 1113
        }
    },
    wc_sessionPing: {
        req: {
            ttl: 30,
            prompt: false,
            tag: 1114
        },
        res: {
            ttl: 30,
            prompt: false,
            tag: 1115
        }
    }
};
var _ack = /*#__PURE__*/ new WeakMap(), _onIrnRequest = /*#__PURE__*/ new WeakSet(), _onIrnSubscription = /*#__PURE__*/ new WeakSet(), _onMessage = /*#__PURE__*/ new WeakSet(), _onRequest = /*#__PURE__*/ new WeakSet(), _tryRouteRequest = /*#__PURE__*/ new WeakSet(), _onResponse = /*#__PURE__*/ new WeakSet(), _tryEncrypt = /*#__PURE__*/ new WeakSet();
class CryptoClient {
    static tryNew(topic, key, irn) {
        return result/* Result */.x.unthrowSync((t)=>{
            const cipher = chacha20poly1305_adapter/* get */.U().Cipher.tryImport(key).throw(t);
            const client = new CryptoClient(topic, key, irn, cipher);
            return new ok.Ok(client);
        });
    }
    async tryRequestAndWait(init) {
        return await this.tryRequest(init).then((r)=>r.andThen((x)=>x.promise));
    }
    async tryRequest(init) {
        return result/* Result */.x.unthrow(async (t)=>{
            const request = SafeRpc.prepare(init);
            // console.log("relay", "<-", request)
            const { topic } = this;
            const message = (0,_class_private_method_get._)(this, _tryEncrypt, tryEncrypt).call(this, request).throw(t);
            const { prompt, tag, ttl } = ENGINE_RPC_OPTS[init.method].req;
            const { id } = request;
            const end = Date.now() + ttl * 1000;
            const receipt = {
                id,
                end
            };
            const promise = this.tryWait(receipt);
            await this.irn.tryPublish({
                topic,
                message,
                prompt,
                tag,
                ttl
            }).then((r)=>r.throw(t));
            return new ok.Ok({
                receipt,
                promise
            });
        });
    }
    async waitOrThrow(receipt) {
        const future = new future_future/* Future */.o();
        const signal = AbortSignal.timeout(receipt.end - Date.now());
        const onResponse = (init)=>{
            if (init.id !== receipt.id) return new none/* None */.H();
            const response = rpc_response/* RpcResponse */.S.from(init);
            future.resolve(response);
            return new some/* Some */.b(undefined);
        };
        const onAbort = ()=>{
            future.reject(new Error("Timed out"));
        };
        try {
            this.events.on("response", onResponse, {
                passive: true
            });
            signal.addEventListener("abort", onAbort, {
                passive: true
            });
            return await future.promise;
        } finally{
            this.events.off("response", onResponse);
            signal.removeEventListener("abort", onAbort);
        }
    }
    async tryWait(receipt) {
        return await result/* Result */.x.runAndDoubleWrap(async ()=>this.waitOrThrow(receipt));
    }
    constructor(topic, key, irn, cipher){
        (0,_class_private_method_init._)(this, _onIrnRequest);
        (0,_class_private_method_init._)(this, _onIrnSubscription);
        (0,_class_private_method_init._)(this, _onMessage);
        (0,_class_private_method_init._)(this, _onRequest);
        (0,_class_private_method_init._)(this, _tryRouteRequest);
        (0,_class_private_method_init._)(this, _onResponse);
        (0,_class_private_method_init._)(this, _tryEncrypt);
        (0,_class_private_field_init._)(this, _ack, {
            writable: true,
            value: void 0
        });
        this.events = new target/* SuperEventTarget */.v();
        (0,_class_private_field_set._)(this, _ack, new Set());
        this.topic = topic;
        this.key = key;
        this.irn = irn;
        this.cipher = cipher;
        irn.events.on("request", (0,_class_private_method_get._)(this, _onIrnRequest, onIrnRequest).bind(this));
    }
}
async function onIrnRequest(request) {
    if (request.method === "irn_subscription") return await (0,_class_private_method_get._)(this, _onIrnSubscription, onIrnSubscription).call(this, request);
    return new none/* None */.H();
}
async function onIrnSubscription(request) {
    const { data } = request.params;
    if (data.topic !== this.topic) return new none/* None */.H();
    return new some/* Some */.b(await (0,_class_private_method_get._)(this, _onMessage, onMessage).call(this, data.message));
}
async function onMessage(message) {
    return result/* Result */.x.unthrow(async (t)=>{
        const env_1 = {
            stack: [],
            error: void 0,
            hasError: false
        };
        try {
            const slice = __addDisposableResource(env_1, base64_adapter/* get */.U().tryDecodePadded(message).throw(t), false);
            const envelope = readable/* Readable */.$.tryReadFromBytes(Envelope, slice.bytes).throw(t);
            const cipher = envelope.fragment.tryReadInto(Ciphertext).throw(t);
            const plain = cipher.tryDecrypt(this.cipher).throw(t);
            const plaintext = bytes_bytes/* Bytes */.J.toUtf8(plain.fragment.bytes);
            const data = SafeJson.parse(plaintext);
            if ("method" in data) (0,_class_private_method_get._)(this, _onRequest, onRequest).call(this, data).then((r)=>r.unwrap()).catch(console.warn);
            else (0,_class_private_method_get._)(this, _onResponse, onResponse).call(this, data).then((r)=>r.unwrap()).catch(console.warn);
            return new ok.Ok(true);
        } catch (e_1) {
            env_1.error = e_1;
            env_1.hasError = true;
        } finally{
            __disposeResources(env_1);
        }
    });
}
async function onRequest(request) {
    return result/* Result */.x.unthrow(async (t)=>{
        // console.log("relay request", "->", request)
        if (typeof request.id !== "number") return ok.Ok.void();
        if ((0,_class_private_field_get._)(this, _ack).has(request.id)) return ok.Ok.void();
        (0,_class_private_field_get._)(this, _ack).add(request.id);
        const result = await (0,_class_private_method_get._)(this, _tryRouteRequest, tryRouteRequest).call(this, request);
        const response = rpc_response/* RpcResponse */.S.rewrap(request.id, result);
        // console.log("relay", "<-", response)
        const { topic } = this;
        const message = (0,_class_private_method_get._)(this, _tryEncrypt, tryEncrypt).call(this, response).throw(t);
        const { prompt, tag, ttl } = ENGINE_RPC_OPTS[request.method].res;
        await this.irn.tryPublish({
            topic,
            message,
            prompt,
            tag,
            ttl
        }).then((r)=>r.throw(t));
        return ok.Ok.void();
    });
}
async function tryRouteRequest(request) {
    const returned = await this.events.emit("request", [
        request
    ]);
    if (returned.isSome()) return returned.inner;
    return new err/* Err */.U(new Error("Unhandled"));
}
async function onResponse(response) {
    // console.log("relay response", "->", response)
    const returned = await this.events.emit("response", [
        response
    ]);
    if (returned.isSome()) return ok.Ok.void();
    return new err/* Err */.U(new Error("Unhandled"));
}
function tryEncrypt(data) {
    return result/* Result */.x.unthrowSync((t)=>{
        const plaintext = SafeJson.stringify(data);
        const plain = new Plaintext(new opaque/* Opaque */.lD(bytes_bytes/* Bytes */.J.fromUtf8(plaintext)));
        const iv = bytes_bytes/* Bytes */.J.random(12); // TODO maybe use a counter
        const cipher = plain.tryEncrypt(this.cipher, iv).throw(t);
        const envelope = new EnvelopeTypeZero(cipher);
        const bytes = writable/* Writable */.c.tryWriteToBytes(envelope).throw(t);
        const message = base64_adapter/* get */.U().tryEncodePadded(bytes).throw(t);
        return new ok.Ok(message);
    });
}

;// CONCATENATED MODULE: ./src/libs/wconn/mods/wc/wc.ts
var wc_addDisposableResource = undefined && undefined.__addDisposableResource || function(env, value, async) {
    if (value !== null && value !== void 0) {
        if (typeof value !== "object" && typeof value !== "function") throw new TypeError("Object expected.");
        var dispose;
        if (async) {
            if (!Symbol.asyncDispose) throw new TypeError("Symbol.asyncDispose is not defined.");
            dispose = value[Symbol.asyncDispose];
        }
        if (dispose === void 0) {
            if (!Symbol.dispose) throw new TypeError("Symbol.dispose is not defined.");
            dispose = value[Symbol.dispose];
        }
        if (typeof dispose !== "function") throw new TypeError("Object not disposable.");
        env.stack.push({
            value: value,
            dispose: dispose,
            async: async
        });
    } else if (async) {
        env.stack.push({
            async: true
        });
    }
    return value;
};
var wc_disposeResources = undefined && undefined.__disposeResources || function(SuppressedError1) {
    return function(env) {
        function fail(e) {
            env.error = env.hasError ? new SuppressedError1(e, env.error, "An error was suppressed during disposal.") : e;
            env.hasError = true;
        }
        function next() {
            while(env.stack.length){
                var rec = env.stack.pop();
                try {
                    var result = rec.dispose && rec.dispose.call(rec.value);
                    if (rec.async) return Promise.resolve(result).then(next, function(e) {
                        fail(e);
                        return next();
                    });
                } catch (e) {
                    fail(e);
                }
            }
            if (env.hasError) throw env.error;
        }
        return next();
    };
}(typeof SuppressedError === "function" ? SuppressedError : function(error, suppressed, message) {
    var e = new Error(message);
    return e.name = "SuppressedError", e.error = error, e.suppressed = suppressed, e;
});







class WcProposal {
    constructor(client, metadata){
        this.client = client;
        this.metadata = metadata;
    }
}
class WcSession {
    async tryClose(reason) {
        return await result/* Result */.x.unthrow(async (t)=>{
            await this.client.tryRequest({
                method: "wc_sessionDelete",
                params: {
                    code: 6000,
                    message: "User disconnected."
                }
            }).then((r)=>r.throw(t));
            await this.client.irn.tryClose(reason).then((r)=>r.throw(t));
            return ok.Ok.void();
        });
    }
    constructor(client, metadata){
        this.client = client;
        this.metadata = metadata;
    }
}
var Wc;
(function(Wc) {
    Wc.RELAY = "wss://relay.walletconnect.org";
    function tryParse(url) {
        return result/* Result */.x.unthrow(async (t)=>{
            const { protocol, pathname, searchParams } = url;
            if (protocol !== "wc:") return new err/* Err */.U(new Error("Invalid protocol"));
            const [pairingTopic, version] = pathname.split("@");
            if (version !== "2") return new err/* Err */.U(new Error("Invalid version"));
            const relayProtocol = option_option/* Option */.W.wrap(searchParams.get("relay-protocol")).ok().throw(t);
            if (relayProtocol !== "irn") return new err/* Err */.U(new Error("Invalid relay protocol"));
            const symKeyHex = option_option/* Option */.W.wrap(searchParams.get("symKey")).ok().throw(t);
            const symKeyRaw = adapter/* get */.U().tryPadStartAndDecode(symKeyHex).throw(t).copyAndDispose();
            const symKey = bytes_bytes/* Bytes */.J.tryCast(symKeyRaw, 32).throw(t);
            return new ok.Ok({
                protocol,
                pairingTopic,
                version,
                relayProtocol,
                symKey
            });
        });
    }
    Wc.tryParse = tryParse;
    async function tryPair(irn, params, address) {
        return await result/* Result */.x.unthrow(async (t)=>{
            const env_1 = {
                stack: [],
                error: void 0,
                hasError: false
            };
            try {
                const { pairingTopic, symKey } = params;
                const pairing = CryptoClient.tryNew(pairingTopic, symKey, irn).throw(t);
                const relay = {
                    protocol: "irn"
                };
                const selfPrivate = await x25519_adapter/* get */.U().PrivateKey.tryRandom().then((r)=>r.throw(t));
                const selfPublic = selfPrivate.tryGetPublicKey().throw(t);
                const selfPublicMemory = wc_addDisposableResource(env_1, await selfPublic.tryExport().then((r)=>r.throw(t)), false);
                const selfPublicHex = adapter/* get */.U().tryEncode(selfPublicMemory).throw(t);
                await irn.trySubscribe(pairingTopic).then((r)=>r.throw(t));
                const proposal = await pairing.events.wait("request", async (future, request)=>{
                    if (request.method !== "wc_sessionPropose") return new none/* None */.H();
                    future.resolve(request);
                    return new some/* Some */.b(new ok.Ok({
                        relay,
                        responderPublicKey: selfPublicHex
                    }));
                }).inner;
                const peerPublicMemory = wc_addDisposableResource(env_1, adapter/* get */.U().tryPadStartAndDecode(proposal.params.proposer.publicKey).throw(t), false);
                const peerPublic = await x25519_adapter/* get */.U().PublicKey.tryImport(peerPublicMemory).then((r)=>r.throw(t));
                const sharedRef = await selfPrivate.tryCompute(peerPublic).then((r)=>r.throw(t));
                const sharedSlice = wc_addDisposableResource(env_1, sharedRef.tryExport().throw(t), false);
                const hdfk_key = await crypto.subtle.importKey("raw", sharedSlice.bytes, "HKDF", false, [
                    "deriveBits"
                ]);
                const hkdf_params = {
                    name: "HKDF",
                    hash: "SHA-256",
                    info: new Uint8Array(),
                    salt: new Uint8Array()
                };
                const sessionKey = new Uint8Array(await crypto.subtle.deriveBits(hkdf_params, hdfk_key, 8 * 32));
                const sessionDigest = new Uint8Array(await crypto.subtle.digest("SHA-256", sessionKey));
                const sessionTopic = adapter/* get */.U().tryEncode(sessionDigest).throw(t);
                const session = CryptoClient.tryNew(sessionTopic, sessionKey, irn).throw(t);
                await irn.trySubscribe(sessionTopic).then((r)=>r.throw(t));
                {
                    const { proposer, requiredNamespaces, optionalNamespaces } = proposal.params;
                    const namespaces = {
                        eip155: {
                            chains: Object.values(mods_chain/* chainByChainId */.DH).map((chain)=>"eip155:".concat(chain.chainId)),
                            methods: [
                                "eth_sendTransaction",
                                "personal_sign",
                                "eth_signTypedData",
                                "eth_signTypedData_v4"
                            ],
                            events: [
                                "chainChanged",
                                "accountsChanged"
                            ],
                            accounts: Object.values(mods_chain/* chainByChainId */.DH).map((chain)=>"eip155:".concat(chain.chainId, ":").concat(address))
                        }
                    };
                    const metadata = {
                        name: "Brume",
                        description: "Brume",
                        url: location.origin,
                        icons: []
                    };
                    const controller = {
                        publicKey: selfPublicHex,
                        metadata
                    };
                    const expiry = Math.floor((Date.now() + 7 * 24 * 60 * 60 * 1000) / 1000);
                    const params = {
                        relay,
                        namespaces,
                        requiredNamespaces,
                        optionalNamespaces,
                        pairingTopic,
                        controller,
                        expiry
                    };
                    const settlement = await session.tryRequest({
                        method: "wc_sessionSettle",
                        params
                    }).then((r)=>r.throw(t));
                    return new ok.Ok([
                        new WcSession(session, proposer.metadata),
                        settlement
                    ]);
                }
            } catch (e_1) {
                env_1.error = e_1;
                env_1.hasError = true;
            } finally{
                wc_disposeResources(env_1);
            }
        });
    }
    Wc.tryPair = tryPair;
})(Wc || (Wc = {}));

// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/abi/signature/signature.mjs + 4 modules
var signature_signature = __webpack_require__(6403);
// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/abi/types/function/function.mjs
var function_function = __webpack_require__(7205);
// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/abi/types/tuple/tuple.mjs
var tuple = __webpack_require__(5444);
// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/abi/types/address/address.mjs
var address = __webpack_require__(3831);
// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/abi/types/int/int.mjs
var int_int = __webpack_require__(5790);
;// CONCATENATED MODULE: ./src/libs/abi/erc20.abi.ts

var TokenAbi;
(function(TokenAbi) {
    TokenAbi.balanceOf = signature_signature/* createFunctionSignature */.a("balanceOf", function_function/* createFunctionSelectorAndArguments */.VU(function_function/* FunctionSelector */.xS.from([
        112,
        160,
        130,
        49
    ]), tuple/* createTuple */.VS(address/* Address */.kL)));
    TokenAbi.transfer = signature_signature/* createFunctionSignature */.a("transfer", function_function/* createFunctionSelectorAndArguments */.VU(function_function/* FunctionSelector */.xS.from([
        169,
        5,
        156,
        187
    ]), tuple/* createTuple */.VS(address/* Address */.kL, int_int/* Int256 */.R4)));
})(TokenAbi || (TokenAbi = {}));

// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/types/fixed/index.mjs
var types_fixed = __webpack_require__(8386);
// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/abi/encode.mjs
var encode = __webpack_require__(6167);
// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/abi/types/uint/uint.mjs
var uint = __webpack_require__(24);
// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/abi/decode.mjs + 1 modules
var decode = __webpack_require__(7817);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/queries/simple/query.mjs
var query = __webpack_require__(6233);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/fetched/data.mjs
var fetched_data = __webpack_require__(8123);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/fetched/fail.mjs
var fail = __webpack_require__(9164);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/errors.mjs
var result_errors = __webpack_require__(2564);
// EXTERNAL MODULE: ./src/mods/background/service_worker/context.ts + 1 modules
var service_worker_context = __webpack_require__(580);
// EXTERNAL MODULE: ./src/mods/background/service_worker/entities/unknown/data.ts
var data = __webpack_require__(2534);
;// CONCATENATED MODULE: ./src/libs/abi/pair.abi.ts

var PairAbi;
(function(PairAbi) {
    PairAbi.getReserves = signature_signature/* createFunctionSignature */.a("getReserves", function_function/* createFunctionSelectorAndArguments */.VU(function_function/* FunctionSelector */.xS.from([
        9,
        2,
        241,
        172
    ]), tuple/* createTuple */.VS()));
})(PairAbi || (PairAbi = {}));

// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/fetched/fetched.mjs
var fetched = __webpack_require__(1458);
;// CONCATENATED MODULE: ./src/mods/background/service_worker/entities/tokens/pairs/data.ts






var BgPair;
(function(BgPair) {
    let Price;
    (function(Price) {
        Price.method = "eth_getPairPrice";
        function key(pair) {
            return {
                chainId: pair.chainId,
                method: "eth_getPairPrice",
                params: [
                    pair.address
                ]
            };
        }
        Price.key = key;
        async function parseOrThrow(ethereum, request, storage) {
            const [address] = request.params;
            const pair = option_option/* Option */.W.unwrap(mods_chain/* pairByAddress */.ne[address]);
            return schema(ethereum, pair, storage);
        }
        Price.parseOrThrow = parseOrThrow;
        function schema(ethereum, pair, storage) {
            const fetcher = (key, more)=>fetched/* Fetched */.F.runOrDoubleWrap(async ()=>{
                    const data = encode/* encodeOrThrow */.YM(PairAbi.getReserves.from());
                    const fetched = await service_worker_context/* BgEthereumContext */.H.fetchOrFail(ethereum, {
                        method: "eth_call",
                        params: [
                            {
                                to: pair.address,
                                data: data
                            },
                            "pending"
                        ]
                    }, more);
                    if (fetched.isErr()) return fetched;
                    const returns = tuple/* createTuple */.VS(uint/* Uint112 */.jZ, uint/* Uint112 */.jZ, uint/* Uint32 */.cf);
                    const [a, b] = decode/* decodeOrThrow */.Dt(returns, fetched.inner).intoOrThrow();
                    const price = computeOrThrow(pair, [
                        a,
                        b
                    ]);
                    return new fetched_data/* Data */.V(price);
                });
            return (0,query/* createQuery */.rP)({
                key: key(pair),
                fetcher,
                storage
            });
        }
        Price.schema = schema;
        function computeOrThrow(pair, reserves) {
            const decimals0 = mods_chain/* tokenByAddress */.q2[pair.token0].decimals;
            const decimals1 = mods_chain/* tokenByAddress */.q2[pair.token1].decimals;
            const [reserve0, reserve1] = reserves;
            const quantity0 = new types_fixed/* Fixed */.g(reserve0, decimals0);
            const quantity1 = new types_fixed/* Fixed */.g(reserve1, decimals1);
            if (pair.reversed) return quantity0.div(quantity1);
            return quantity1.div(quantity0);
        }
        Price.computeOrThrow = computeOrThrow;
    })(Price = BgPair.Price || (BgPair.Price = {}));
})(BgPair || (BgPair = {}));

;// CONCATENATED MODULE: ./src/mods/background/service_worker/entities/tokens/data.ts










var TokenRef;
(function(TokenRef) {
    function from(token) {
        if (token.type === "native") return NativeTokenRef.from(token);
        if (token.type === "contract") return ContractTokenRef.from(token);
        throw new result_errors/* Panic */.F5();
    }
    TokenRef.from = from;
})(TokenRef || (TokenRef = {}));
var NativeTokenRef;
(function(NativeTokenRef) {
    function from(token) {
        const { uuid, type, chainId } = token;
        return {
            ref: true,
            uuid,
            type,
            chainId
        };
    }
    NativeTokenRef.from = from;
})(NativeTokenRef || (NativeTokenRef = {}));
var ContractTokenRef;
(function(ContractTokenRef) {
    function from(token) {
        const { uuid, type, chainId, address } = token;
        return {
            ref: true,
            uuid,
            type,
            chainId,
            address
        };
    }
    ContractTokenRef.from = from;
})(ContractTokenRef || (ContractTokenRef = {}));
var BgToken;
(function(BgToken) {
    let Balance;
    (function(Balance) {
        function key(address, currency) {
            return "pricedBalanceByToken/".concat(address, "/").concat(currency);
        }
        Balance.key = key;
        function schema(address, currency, storage) {
            const indexer = async (states)=>{
                var _states_current_real;
                const values = option_option/* Option */.W.wrap((_states_current_real = states.current.real) === null || _states_current_real === void 0 ? void 0 : _states_current_real.data).mapSync((d)=>d.inner).unwrapOr({});
                const total = Object.values(values).reduce((x, y)=>types_fixed/* Fixed */.g.from(y).add(x), new types_fixed/* Fixed */.g(0n, 0));
                const totalBalance = data/* BgTotal */.f.Balance.Priced.ByAddress.schema(address, currency, storage);
                await totalBalance.mutate(mutators/* Mutators */.g.data(total));
            };
            return (0,query/* createQuery */.rP)({
                key: key(address, currency),
                indexer,
                storage
            });
        }
        Balance.schema = schema;
    })(Balance = BgToken.Balance || (BgToken.Balance = {}));
    let Native;
    (function(Native) {
        let Balance;
        (function(Balance) {
            let Priced;
            (function(Priced) {
                function key(address, currency, chain) {
                    return {
                        chainId: chain.chainId,
                        method: "eth_getPricedBalance",
                        params: [
                            address,
                            currency
                        ]
                    };
                }
                Priced.key = key;
                function schema(account, coin, ethereum, storage) {
                    const indexer = async (states)=>{
                        var _states_current_real_data, _states_current_real;
                        const key = "".concat(ethereum.chain.chainId);
                        const value = option_option/* Option */.W.wrap((_states_current_real = states.current.real) === null || _states_current_real === void 0 ? void 0 : (_states_current_real_data = _states_current_real.data) === null || _states_current_real_data === void 0 ? void 0 : _states_current_real_data.inner).unwrapOr(new types_fixed/* Fixed */.g(0n, 0));
                        const indexQuery = BgToken.Balance.schema(account, coin, storage);
                        await indexQuery.mutate(mutators/* Mutators */.g.mapInnerData((p)=>({
                                ...p,
                                [key]: value
                            }), new fetched_data/* Data */.V({})));
                    };
                    return (0,query/* createQuery */.rP)({
                        key: key(account, coin, ethereum.chain),
                        indexer,
                        storage
                    });
                }
                Priced.schema = schema;
            })(Priced = Balance.Priced || (Balance.Priced = {}));
            Balance.method = "eth_getBalance";
            function key(account, block, chain) {
                return {
                    version: 2,
                    chainId: chain.chainId,
                    method: Balance.method,
                    params: [
                        account,
                        block
                    ]
                };
            }
            Balance.key = key;
            async function parseOrThrow(request, ethereum, storage) {
                const [account, block] = request.params;
                return schema(account, block, ethereum, storage);
            }
            Balance.parseOrThrow = parseOrThrow;
            function schema(account, block, context, storage) {
                const fetcher = async (request, more)=>await service_worker_context/* BgEthereumContext */.H.fetchOrFail(context, request, more).then((f)=>f.mapSync((x)=>new types_fixed/* ZeroHexFixed */.B(x, context.chain.token.decimals)));
                const indexer = async (states)=>{
                    var _states_current_real_data, _states_current_real;
                    if (block !== "pending") return;
                    const pricedBalance = await option_option/* Option */.W.wrap((_states_current_real = states.current.real) === null || _states_current_real === void 0 ? void 0 : (_states_current_real_data = _states_current_real.data) === null || _states_current_real_data === void 0 ? void 0 : _states_current_real_data.get()).andThen(async (balance)=>{
                        if (context.chain.token.pairs == null) return new none/* None */.H();
                        let pricedBalance = types_fixed/* Fixed */.g.from(balance);
                        for (const pairAddress of context.chain.token.pairs){
                            const pair = mods_chain/* pairByAddress */.ne[pairAddress];
                            const chain = mods_chain/* chainByChainId */.DH[pair.chainId];
                            const price = BgPair.Price.schema({
                                ...context,
                                chain
                            }, pair, storage);
                            const priceState = await price.state;
                            if (priceState.data == null) return new none/* None */.H();
                            pricedBalance = pricedBalance.mul(types_fixed/* Fixed */.g.from(priceState.data.inner));
                        }
                        return new some/* Some */.b(pricedBalance);
                    }).then((o)=>o.unwrapOr(new types_fixed/* Fixed */.g(0n, 0)));
                    const pricedBalanceQuery = Priced.schema(account, "usd", context, storage);
                    await pricedBalanceQuery.mutate(mutators/* Mutators */.g.set(new fetched_data/* Data */.V(pricedBalance)));
                };
                return (0,query/* createQuery */.rP)({
                    key: key(account, block, context.chain),
                    fetcher,
                    indexer,
                    storage
                });
            }
            Balance.schema = schema;
        })(Balance = Native.Balance || (Native.Balance = {}));
    })(Native = BgToken.Native || (BgToken.Native = {}));
    let Contract;
    (function(Contract) {
        let All;
        (function(All) {
            All.key = "contractTokens";
            function schema(storage) {
                return (0,query/* createQuery */.rP)({
                    key: All.key,
                    storage
                });
            }
            All.schema = schema;
        })(All = Contract.All || (Contract.All = {}));
        let Balance;
        (function(Balance) {
            let Priced;
            (function(Priced) {
                function key(address, token, currency, chain) {
                    return {
                        chainId: chain.chainId,
                        method: "eth_getTokenPricedBalance",
                        params: [
                            address,
                            token.address,
                            currency
                        ]
                    };
                }
                Priced.key = key;
                function schema(ethereum, account, token, coin, storage) {
                    const indexer = async (states)=>{
                        var _states_current_real_data, _states_current_real;
                        const key = "".concat(ethereum.chain.chainId, "/").concat(token.address);
                        const value = option_option/* Option */.W.wrap((_states_current_real = states.current.real) === null || _states_current_real === void 0 ? void 0 : (_states_current_real_data = _states_current_real.data) === null || _states_current_real_data === void 0 ? void 0 : _states_current_real_data.inner).unwrapOr(new types_fixed/* Fixed */.g(0n, 0));
                        const indexQuery = BgToken.Balance.schema(account, coin, storage);
                        await indexQuery.mutate(mutators/* Mutators */.g.mapInnerData((p)=>({
                                ...p,
                                [key]: value
                            }), new fetched_data/* Data */.V({})));
                    };
                    return (0,query/* createQuery */.rP)({
                        key: key(account, token, coin, ethereum.chain),
                        indexer,
                        storage
                    });
                }
                Priced.schema = schema;
            })(Priced = Balance.Priced || (Balance.Priced = {}));
            Balance.method = "eth_getTokenBalance";
            function key(account, token, block, chain) {
                return {
                    chainId: chain.chainId,
                    method: Balance.method,
                    params: [
                        account,
                        token.address,
                        block
                    ]
                };
            }
            Balance.key = key;
            async function parseOrThrow(ethereum, request, storage) {
                var _tokenState_data;
                const [account, address, block] = request.params;
                const tokenQuery = Contract.schema(ethereum.chain.chainId, address, storage);
                const tokenState = await tokenQuery.state;
                const tokenData = option_option/* Option */.W.wrap((_tokenState_data = tokenState.data) === null || _tokenState_data === void 0 ? void 0 : _tokenState_data.inner).or(option_option/* Option */.W.wrap(mods_chain/* tokenByAddress */.q2[address])).unwrap();
                return schema(ethereum, account, tokenData, block, storage);
            }
            Balance.parseOrThrow = parseOrThrow;
            function schema(ethereum, account, token, block, storage) {
                const fetcher = async (key, more)=>{
                    try {
                        const data = encode/* encodeOrThrow */.YM(TokenAbi.balanceOf.from(account));
                        const fetched = await service_worker_context/* BgEthereumContext */.H.fetchOrFail(ethereum, {
                            method: "eth_call",
                            params: [
                                {
                                    to: token.address,
                                    data: data
                                },
                                "pending"
                            ]
                        }, more);
                        if (fetched.isErr()) return fetched;
                        const returns = tuple/* createTuple */.VS(uint/* Uint256 */.kq);
                        const [balance] = decode/* decodeOrThrow */.Dt(returns, fetched.inner).inner;
                        const fixed = new types_fixed/* Fixed */.g(balance.intoOrThrow(), token.decimals);
                        return new fetched_data/* Data */.V(fixed);
                    } catch (e) {
                        return new fail/* Fail */.M(result_errors/* Catched */.$c.from(e));
                    }
                };
                const indexer = async (states)=>{
                    var _states_current_real_data, _states_current_real;
                    if (block !== "pending") return;
                    const pricedBalance = await option_option/* Option */.W.wrap((_states_current_real = states.current.real) === null || _states_current_real === void 0 ? void 0 : (_states_current_real_data = _states_current_real.data) === null || _states_current_real_data === void 0 ? void 0 : _states_current_real_data.get()).andThen(async (balance)=>{
                        if (token.pairs == null) return new none/* None */.H();
                        let pricedBalance = types_fixed/* Fixed */.g.from(balance);
                        for (const pairAddress of token.pairs){
                            const pair = mods_chain/* pairByAddress */.ne[pairAddress];
                            const chain = mods_chain/* chainByChainId */.DH[pair.chainId];
                            const price = BgPair.Price.schema({
                                ...ethereum,
                                chain
                            }, pair, storage);
                            const priceState = await price.state;
                            if (priceState.data == null) return new none/* None */.H();
                            pricedBalance = pricedBalance.mul(types_fixed/* Fixed */.g.from(priceState.data.inner));
                        }
                        return new some/* Some */.b(pricedBalance);
                    }).then((o)=>o.unwrapOr(new types_fixed/* Fixed */.g(0n, 0)));
                    const pricedBalanceQuery = Priced.schema(ethereum, account, token, "usd", storage);
                    await pricedBalanceQuery.mutate(mutators/* Mutators */.g.set(new fetched_data/* Data */.V(pricedBalance)));
                };
                return (0,query/* createQuery */.rP)({
                    key: key(account, token, block, ethereum.chain),
                    fetcher,
                    indexer,
                    storage
                });
            }
            Balance.schema = schema;
        })(Balance = Contract.Balance || (Contract.Balance = {}));
        function key(chainId, address) {
            return "contractToken/".concat(chainId, "/").concat(address);
        }
        Contract.key = key;
        function schema(chainId, address, storage) {
            const indexer = async (states)=>{
                var _previous_real_data, _previous_real, _current_real_data, _current_real;
                const { current, previous } = states;
                const previousData = previous === null || previous === void 0 ? void 0 : (_previous_real = previous.real) === null || _previous_real === void 0 ? void 0 : (_previous_real_data = _previous_real.data) === null || _previous_real_data === void 0 ? void 0 : _previous_real_data.inner;
                const currentData = (_current_real = current.real) === null || _current_real === void 0 ? void 0 : (_current_real_data = _current_real.data) === null || _current_real_data === void 0 ? void 0 : _current_real_data.inner;
                if ((previousData === null || previousData === void 0 ? void 0 : previousData.uuid) === (currentData === null || currentData === void 0 ? void 0 : currentData.uuid)) return;
                if (previousData != null) {
                    var _All_schema;
                    await ((_All_schema = All.schema(storage)) === null || _All_schema === void 0 ? void 0 : _All_schema.mutate(mutators/* Mutators */.g.mapData(function() {
                        let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : new fetched_data/* Data */.V([]);
                        return d.mapSync((p)=>p.filter((x)=>x.uuid !== previousData.uuid));
                    })));
                }
                if (currentData != null) {
                    var _All_schema1;
                    await ((_All_schema1 = All.schema(storage)) === null || _All_schema1 === void 0 ? void 0 : _All_schema1.mutate(mutators/* Mutators */.g.mapData(function() {
                        let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : new fetched_data/* Data */.V([]);
                        return d.mapSync((p)=>[
                                ...p,
                                ContractTokenRef.from(currentData)
                            ]);
                    })));
                }
            };
            return (0,query/* createQuery */.rP)({
                key: key(chainId, address),
                indexer,
                storage
            });
        }
        Contract.schema = schema;
    })(Contract = BgToken.Contract || (BgToken.Contract = {}));
})(BgToken || (BgToken = {}));

// EXTERNAL MODULE: ./src/mods/background/service_worker/entities/wallets/data.ts
var wallets_data = __webpack_require__(7917);
// EXTERNAL MODULE: ./node_modules/react/index.js
var react = __webpack_require__(7294);
// EXTERNAL MODULE: ./src/mods/foreground/background/context.tsx + 3 modules
var context = __webpack_require__(5855);
// EXTERNAL MODULE: ./src/mods/foreground/components/page/header.tsx
var header = __webpack_require__(6915);
// EXTERNAL MODULE: ./src/mods/foreground/components/page/page.tsx
var page = __webpack_require__(179);
// EXTERNAL MODULE: ./src/mods/foreground/router/path/context.tsx
var path_context = __webpack_require__(8097);
// EXTERNAL MODULE: ./src/mods/foreground/entities/names/data.ts + 2 modules
var names_data = __webpack_require__(797);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/PlusIcon.js
var PlusIcon = __webpack_require__(8680);
// EXTERNAL MODULE: ./src/libs/react/callback.tsx
var callback = __webpack_require__(5379);
// EXTERNAL MODULE: ./src/libs/ui/input.tsx + 4 modules
var input = __webpack_require__(9607);
// EXTERNAL MODULE: ./src/mods/foreground/storage/user.tsx
var user = __webpack_require__(9718);
// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/types/zerohex/index.mjs
var zerohex = __webpack_require__(6113);
// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/abi/types/string/string.mjs
var string = __webpack_require__(3997);
// EXTERNAL MODULE: ./src/mods/foreground/entities/unknown/data.ts
var unknown_data = __webpack_require__(9801);
// EXTERNAL MODULE: ./src/mods/foreground/entities/wallets/context.tsx
var wallets_context = __webpack_require__(1949);
;// CONCATENATED MODULE: ./src/libs/react/effect.tsx

function useEffectButOnlyFirstTime(callback, deps) {
    const first = useRef(true);
    useEffect(()=>{
        if (first.current) {
            first.current = false;
            return callback();
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, deps);
}
function useEffectButNotFirstTime(callback, deps) {
    const first = (0,react.useRef)(true);
    (0,react.useEffect)(()=>{
        if (first.current) {
            first.current = false;
            return;
        }
        return callback();
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, deps);
}

// EXTERNAL MODULE: ./src/mods/foreground/storage/storage.ts
var storage_storage = __webpack_require__(604);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/react/hooks/queries/simple.mjs + 1 modules
var simple = __webpack_require__(564);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/react/hooks/blocks/use-fetch.mjs
var use_fetch = __webpack_require__(4704);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/react/hooks/blocks/use-visible.mjs
var use_visible = __webpack_require__(7836);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/react/hooks/blocks/use-interval.mjs
var use_interval = __webpack_require__(8995);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/react/hooks/blocks/use-error.mjs
var use_error = __webpack_require__(3399);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/core/core.mjs + 4 modules
var core = __webpack_require__(4952);
// EXTERNAL MODULE: ./src/mods/foreground/entities/wallets/data.ts
var entities_wallets_data = __webpack_require__(9327);
;// CONCATENATED MODULE: ./src/mods/foreground/entities/tokens/pairs/data.ts






var FgPair;
(function(FgPair) {
    let Price;
    (function(Price) {
        Price.key = BgPair.Price.key;
        function schema(context, pair, storage) {
            if (context == null) return;
            const fetcher = async function(request) {
                let more = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
                return await (0,entities_wallets_data/* fetchOrFail */.yR)(request, context);
            };
            return (0,query/* createQuery */.rP)({
                key: Price.key(pair),
                fetcher,
                storage
            });
        }
        Price.schema = schema;
    })(Price = FgPair.Price || (FgPair.Price = {}));
})(FgPair || (FgPair = {}));
function usePairPrice(ethereum, pair) {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(FgPair.Price.schema, [
        ethereum,
        pair,
        storage
    ]);
    (0,use_fetch/* useFetch */.i)(query);
    (0,use_visible/* useVisible */.E)(query);
    (0,storage_storage/* useSubscribe */.Q)(query, storage);
    (0,use_error/* useError */.V)(query, errors/* Errors */.D.onQueryError);
    return query;
}

;// CONCATENATED MODULE: ./src/mods/foreground/entities/tokens/data.ts













var FgToken;
(function(FgToken) {
    let Balance;
    (function(Balance) {
        Balance.key = BgToken.Balance.key;
        function schema(address, currency, storage) {
            if (address == null) return;
            const indexer = async (states)=>{
                var _states_current_real;
                const values = option_option/* Option */.W.wrap((_states_current_real = states.current.real) === null || _states_current_real === void 0 ? void 0 : _states_current_real.data).mapSync((d)=>d.inner).unwrapOr({});
                const total = Object.values(values).reduce((x, y)=>types_fixed/* Fixed */.g.from(y).add(x), new types_fixed/* Fixed */.g(0n, 0));
                const totalBalance = unknown_data/* FgTotal */.Q6.Balance.Priced.ByAddress.schema(address, currency, storage);
                await (totalBalance === null || totalBalance === void 0 ? void 0 : totalBalance.mutate(mutators/* Mutators */.g.data(total)));
            };
            return (0,query/* createQuery */.rP)({
                key: Balance.key(address, currency),
                indexer,
                storage
            });
        }
        Balance.schema = schema;
    })(Balance = FgToken.Balance || (FgToken.Balance = {}));
    let Native;
    (function(Native) {
        let Balance;
        (function(Balance) {
            let Priced;
            (function(Priced) {
                Priced.key = BgToken.Native.Balance.Priced.key;
                function schema(address, coin, context, storage) {
                    if (context == null) return;
                    if (address == null) return;
                    const indexer = async (states)=>{
                        var _states_current_real_data, _states_current_real;
                        const key = "".concat(context.chain.chainId);
                        const value = option_option/* Option */.W.wrap((_states_current_real = states.current.real) === null || _states_current_real === void 0 ? void 0 : (_states_current_real_data = _states_current_real.data) === null || _states_current_real_data === void 0 ? void 0 : _states_current_real_data.inner).unwrapOr(new types_fixed/* Fixed */.g(0n, 0));
                        const indexQuery = FgToken.Balance.schema(address, coin, storage);
                        await (indexQuery === null || indexQuery === void 0 ? void 0 : indexQuery.mutate(mutators/* Mutators */.g.mapInnerData((p)=>({
                                ...p,
                                [key]: value
                            }), new fetched_data/* Data */.V({}))));
                    };
                    return (0,query/* createQuery */.rP)({
                        key: Priced.key(address, coin, context.chain),
                        indexer,
                        storage
                    });
                }
                Priced.schema = schema;
            })(Priced = Balance.Priced || (Balance.Priced = {}));
            Balance.key = BgToken.Native.Balance.key;
            function schema(address, block, context, storage) {
                if (address == null) return;
                if (context == null) return;
                if (block == null) return;
                const fetcher = async function(request) {
                    let more = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
                    return await (0,entities_wallets_data/* fetchOrFail */.yR)(request, context);
                };
                const indexer = async (states)=>{
                    var _states_current_real_data, _states_current_real;
                    if (block !== "pending") return;
                    const pricedBalance = await option_option/* Option */.W.wrap((_states_current_real = states.current.real) === null || _states_current_real === void 0 ? void 0 : (_states_current_real_data = _states_current_real.data) === null || _states_current_real_data === void 0 ? void 0 : _states_current_real_data.get()).andThen(async (balance)=>{
                        if (context.chain.token.pairs == null) return new none/* None */.H();
                        let pricedBalance = types_fixed/* Fixed */.g.from(balance);
                        for (const pairAddress of context.chain.token.pairs){
                            const pair = mods_chain/* pairByAddress */.ne[pairAddress];
                            const chain = mods_chain/* chainByChainId */.DH[pair.chainId];
                            const price = FgPair.Price.schema({
                                ...context,
                                chain
                            }, pair, storage);
                            const priceState = await (price === null || price === void 0 ? void 0 : price.state);
                            if ((priceState === null || priceState === void 0 ? void 0 : priceState.data) == null) return new none/* None */.H();
                            pricedBalance = pricedBalance.mul(types_fixed/* Fixed */.g.from(priceState.data.inner));
                        }
                        return new some/* Some */.b(pricedBalance);
                    }).then((o)=>o.unwrapOr(new types_fixed/* Fixed */.g(0n, 0)));
                    const pricedBalanceQuery = Priced.schema(address, "usd", context, storage);
                    await (pricedBalanceQuery === null || pricedBalanceQuery === void 0 ? void 0 : pricedBalanceQuery.mutate(mutators/* Mutators */.g.set(new fetched_data/* Data */.V(pricedBalance))));
                };
                return (0,query/* createQuery */.rP)({
                    key: Balance.key(address, block, context.chain),
                    fetcher,
                    indexer,
                    storage
                });
            }
            Balance.schema = schema;
        })(Balance = Native.Balance || (Native.Balance = {}));
    })(Native = FgToken.Native || (FgToken.Native = {}));
    let Contract;
    (function(Contract) {
        let Balance;
        (function(Balance) {
            let Priced;
            (function(Priced) {
                Priced.key = BgToken.Contract.Balance.Priced.key;
                function schema(account, token, coin, context, storage) {
                    if (context == null) return;
                    if (account == null) return;
                    if (token == null) return;
                    const indexer = async (states)=>{
                        var _states_current_real_data, _states_current_real;
                        const key = "".concat(context.chain.chainId, "/").concat(token.address);
                        const value = option_option/* Option */.W.wrap((_states_current_real = states.current.real) === null || _states_current_real === void 0 ? void 0 : (_states_current_real_data = _states_current_real.data) === null || _states_current_real_data === void 0 ? void 0 : _states_current_real_data.inner).unwrapOr(new types_fixed/* Fixed */.g(0n, 0));
                        const indexQuery = FgToken.Balance.schema(account, coin, storage);
                        await (indexQuery === null || indexQuery === void 0 ? void 0 : indexQuery.mutate(mutators/* Mutators */.g.mapInnerData((p)=>({
                                ...p,
                                [key]: value
                            }), new fetched_data/* Data */.V({}))));
                    };
                    return (0,query/* createQuery */.rP)({
                        key: Priced.key(account, token, coin, context.chain),
                        indexer,
                        storage
                    });
                }
                Priced.schema = schema;
            })(Priced = Balance.Priced || (Balance.Priced = {}));
            Balance.key = BgToken.Contract.Balance.key;
            function schema(address, token, block, context, storage) {
                if (address == null) return;
                if (token == null) return;
                if (context == null) return;
                if (block == null) return;
                const fetcher = async function(request) {
                    let more = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
                    return await (0,entities_wallets_data/* fetchOrFail */.yR)(request, context);
                };
                const indexer = async (states)=>{
                    var _states_current_real_data, _states_current_real;
                    if (block !== "pending") return;
                    const pricedBalance = await option_option/* Option */.W.wrap((_states_current_real = states.current.real) === null || _states_current_real === void 0 ? void 0 : (_states_current_real_data = _states_current_real.data) === null || _states_current_real_data === void 0 ? void 0 : _states_current_real_data.get()).andThen(async (balance)=>{
                        if (token.pairs == null) return new none/* None */.H();
                        let pricedBalance = types_fixed/* Fixed */.g.from(balance);
                        for (const pairAddress of token.pairs){
                            const pair = mods_chain/* pairByAddress */.ne[pairAddress];
                            const chain = mods_chain/* chainByChainId */.DH[pair.chainId];
                            const price = FgPair.Price.schema({
                                ...context,
                                chain
                            }, pair, storage);
                            const priceState = await (price === null || price === void 0 ? void 0 : price.state);
                            if ((priceState === null || priceState === void 0 ? void 0 : priceState.data) == null) return new none/* None */.H();
                            pricedBalance = pricedBalance.mul(types_fixed/* Fixed */.g.from(priceState.data.inner));
                        }
                        return new some/* Some */.b(pricedBalance);
                    }).then((o)=>o.unwrapOr(new types_fixed/* Fixed */.g(0n, 0)));
                    const pricedBalanceQuery = Priced.schema(address, token, "usd", context, storage);
                    await (pricedBalanceQuery === null || pricedBalanceQuery === void 0 ? void 0 : pricedBalanceQuery.mutate(mutators/* Mutators */.g.set(new fetched_data/* Data */.V(pricedBalance))));
                };
                return (0,query/* createQuery */.rP)({
                    key: Balance.key(address, token, block, context.chain),
                    fetcher,
                    indexer,
                    storage
                });
            }
            Balance.schema = schema;
        })(Balance = Contract.Balance || (Contract.Balance = {}));
        let All;
        (function(All) {
            All.key = BgToken.Contract.All.key;
            function schema(storage) {
                return (0,query/* createQuery */.rP)({
                    key: All.key,
                    storage
                });
            }
            All.schema = schema;
        })(All = Contract.All || (Contract.All = {}));
        Contract.key = BgToken.Contract.key;
        function schema(chainId, address, storage) {
            const indexer = async (states)=>{
                var _previous_real_data, _previous_real, _current_real_data, _current_real;
                const { current, previous } = states;
                const previousData = previous === null || previous === void 0 ? void 0 : (_previous_real = previous.real) === null || _previous_real === void 0 ? void 0 : (_previous_real_data = _previous_real.data) === null || _previous_real_data === void 0 ? void 0 : _previous_real_data.inner;
                const currentData = (_current_real = current.real) === null || _current_real === void 0 ? void 0 : (_current_real_data = _current_real.data) === null || _current_real_data === void 0 ? void 0 : _current_real_data.inner;
                if ((previousData === null || previousData === void 0 ? void 0 : previousData.uuid) === (currentData === null || currentData === void 0 ? void 0 : currentData.uuid)) return;
                if (previousData != null) {
                    var _All_schema;
                    await ((_All_schema = All.schema(storage)) === null || _All_schema === void 0 ? void 0 : _All_schema.mutate(mutators/* Mutators */.g.mapData(function() {
                        let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : new fetched_data/* Data */.V([]);
                        return d.mapSync((p)=>p.filter((x)=>x.uuid !== previousData.uuid));
                    })));
                }
                if (currentData != null) {
                    var _All_schema1;
                    await ((_All_schema1 = All.schema(storage)) === null || _All_schema1 === void 0 ? void 0 : _All_schema1.mutate(mutators/* Mutators */.g.mapData(function() {
                        let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : new fetched_data/* Data */.V([]);
                        return d.mapSync((p)=>[
                                ...p,
                                ContractTokenRef.from(currentData)
                            ]);
                    })));
                }
            };
            return (0,query/* createQuery */.rP)({
                key: Contract.key(chainId, address),
                indexer,
                storage
            });
        }
        Contract.schema = schema;
    })(Contract = FgToken.Contract || (FgToken.Contract = {}));
})(FgToken || (FgToken = {}));
function useToken(chainId, address) {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(FgToken.Contract.schema, [
        chainId,
        address,
        storage
    ]);
    (0,storage_storage/* useSubscribe */.Q)(query, storage);
    return query;
}
function useTokens() {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(FgToken.Contract.All.schema, [
        storage
    ]);
    (0,storage_storage/* useSubscribe */.Q)(query, storage);
    return query;
}
function useNativeBalance(address, block, context, prices) {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(FgToken.Native.Balance.schema, [
        address,
        block,
        context,
        storage
    ]);
    (0,use_fetch/* useFetch */.i)(query);
    (0,use_visible/* useVisible */.E)(query);
    (0,use_interval/* useInterval */.Y)(query, 10 * 1000);
    (0,storage_storage/* useSubscribe */.Q)(query, storage);
    (0,use_error/* useError */.V)(query, errors/* Errors */.D.onQueryError);
    useEffectButNotFirstTime(()=>{
        if (context == null) return;
        if (query.cacheKey == null) return;
        core/* core */.vE.reindexOrThrow(query.cacheKey, query).catch(console.warn);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        context,
        prices
    ]);
    return query;
}
function useContractBalance(address, token, block, context, prices) {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(FgToken.Contract.Balance.schema, [
        address,
        token,
        block,
        context,
        storage
    ]);
    (0,use_fetch/* useFetch */.i)(query);
    (0,use_visible/* useVisible */.E)(query);
    (0,use_interval/* useInterval */.Y)(query, 10 * 1000);
    (0,storage_storage/* useSubscribe */.Q)(query, storage);
    (0,use_error/* useError */.V)(query, errors/* Errors */.D.onQueryError);
    useEffectButNotFirstTime(()=>{
        if (context == null) return;
        if (query.cacheKey == null) return;
        core/* core */.vE.reindexOrThrow(query.cacheKey, query).catch(console.warn);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        context,
        prices
    ]);
    return query;
}
function useNativePricedBalance(address, coin, context) {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(FgToken.Native.Balance.Priced.schema, [
        address,
        coin,
        context,
        storage
    ]);
    (0,storage_storage/* useSubscribe */.Q)(query, storage);
    return query;
}
function useContractPricedBalance(address, token, coin, context) {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(FgToken.Contract.Balance.Priced.schema, [
        address,
        token,
        coin,
        context,
        storage
    ]);
    (0,storage_storage/* useSubscribe */.Q)(query, storage);
    return query;
}

;// CONCATENATED MODULE: ./src/mods/foreground/entities/tokens/add/dialog.tsx




















function TokenAddDialog(props) {
    const { close } = (0,dialog/* useDialogContext */.DA)().unwrap();
    const wallet = (0,wallets_context/* useWalletDataContext */.zI)().unwrap();
    const background = (0,context/* useBackgroundContext */.D_)().unwrap();
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const [chain, setChain] = (0,react.useState)(mods_chain/* chainByChainId */.DH[1]);
    const [rawAddress = "", setRawAddress] = (0,react.useState)();
    const defAddress = (0,react.useDeferredValue)(rawAddress);
    const onAddressChange = (0,events/* useInputChange */.Xy)((e)=>{
        setRawAddress(e.currentTarget.value);
    }, []);
    const token = useToken(chain.chainId, defAddress);
    const onAddClick = (0,callback/* useAsyncUniqueCallback */.T)(async ()=>{
        return await result/* Result */.x.unthrow(async (t)=>{
            if (!zerohex/* ZeroHexString */.T.is(defAddress)) return new err/* Err */.U(new errors/* UIError */.m("Invalid address"));
            const name = await result/* Result */.x.unthrow(async (t)=>{
                const context = {
                    uuid: wallet.uuid,
                    background,
                    chain
                };
                const signature = signature_signature/* FunctionSignature */.I.tryParse("name()").throw(t);
                const data = encode/* tryEncode */.eK(signature.from()).throw(t);
                const schema = unknown_data/* FgEthereum */.qK.Unknown.schema({
                    method: "eth_call",
                    params: [
                        {
                            to: defAddress,
                            data: data
                        },
                        "pending"
                    ]
                }, context, storage);
                if (schema == null) throw new result_errors/* Panic */.F5();
                const result = await schema.refetch().then((r)=>{
                    var _r_real;
                    return (_r_real = r.real) === null || _r_real === void 0 ? void 0 : _r_real.current.throw(t);
                });
                const returns = tuple/* createTuple */.VS(string/* String */.L);
                const [name] = decode/* tryDecode */.bB(returns, result).throw(t).intoOrThrow();
                return new ok.Ok(name);
            }).then((r)=>r.throw(t));
            const symbol = await result/* Result */.x.unthrow(async (t)=>{
                const context = {
                    uuid: wallet.uuid,
                    background,
                    chain
                };
                const signature = signature_signature/* FunctionSignature */.I.tryParse("symbol()").throw(t);
                const data = encode/* tryEncode */.eK(signature.from()).throw(t);
                const schema = unknown_data/* FgEthereum */.qK.Unknown.schema({
                    method: "eth_call",
                    params: [
                        {
                            to: defAddress,
                            data: data
                        },
                        "pending"
                    ]
                }, context, storage);
                if (schema == null) throw new result_errors/* Panic */.F5();
                const result = await schema.refetch().then((r)=>{
                    var _r_real;
                    return (_r_real = r.real) === null || _r_real === void 0 ? void 0 : _r_real.current.throw(t);
                });
                const returns = tuple/* createTuple */.VS(string/* String */.L);
                const [symbol] = decode/* tryDecode */.bB(returns, result).throw(t).intoOrThrow();
                return new ok.Ok(symbol);
            }).then((r)=>r.throw(t));
            const decimals = await result/* Result */.x.unthrow(async (t)=>{
                const context = {
                    uuid: wallet.uuid,
                    background,
                    chain
                };
                const signature = signature_signature/* FunctionSignature */.I.tryParse("decimals()").throw(t);
                const data = encode/* tryEncode */.eK(signature.from()).throw(t);
                const schema = unknown_data/* FgEthereum */.qK.Unknown.schema({
                    method: "eth_call",
                    params: [
                        {
                            to: defAddress,
                            data: data
                        },
                        "pending"
                    ]
                }, context, storage);
                if (schema == null) throw new result_errors/* Panic */.F5();
                const result = await schema.refetch().then((r)=>{
                    var _r_real;
                    return (_r_real = r.real) === null || _r_real === void 0 ? void 0 : _r_real.current.throw(t);
                });
                const returns = tuple/* createTuple */.VS(uint/* Uint8 */.bz);
                const [decimals] = decode/* tryDecode */.bB(returns, result).throw(t).intoOrThrow();
                return new ok.Ok(Number(decimals));
            }).then((r)=>r.throw(t));
            await token.mutate((s)=>{
                const data = new fetched_data/* Data */.V({
                    uuid: crypto.randomUUID(),
                    type: "contract",
                    chainId: chain.chainId,
                    address: defAddress,
                    name: name,
                    symbol: symbol,
                    decimals: decimals
                });
                return new some/* Some */.b(data);
            });
            close();
            return ok.Ok.void();
        }).then(results/* Results */.u.logAndAlert);
    }, [
        background,
        close,
        chain,
        defAddress
    ]);
    const addDisabled = (0,react.useMemo)(()=>{
        if (!defAddress) return "Please enter an address";
        return;
    }, [
        defAddress
    ]);
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Dialog */.Vq.Title, {
                close: close,
                children: "New token"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-2"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "flex flex-wrap items-center overflow-hidden gap-2",
                children: Object.values(mods_chain/* chainByChainId */.DH).map((x)=>/*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                        className: "".concat(ui_button/* Button.Base */.z.XY.className, " po-sm border border-contrast shrink-0 data-[selected=true]:border-opposite transition-colors"),
                        onClick: ()=>setChain(x),
                        "data-selected": chain === x,
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
                            children: x.name
                        })
                    }, x.chainId))
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-2"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)(input/* Input.Contrast */.I.mn, {
                className: "w-full",
                placeholder: "Contract address",
                value: rawAddress,
                onChange: onAddressChange
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-4"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.Gradient */.z.ph, {
                className: "w-full po-md",
                colorIndex: wallet.color,
                disabled: Boolean(addDisabled),
                onClick: onAddClick.run,
                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                    className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime.jsx)(PlusIcon/* default */.Z, {
                            className: "size-5"
                        }),
                        addDisabled || "Send"
                    ]
                })
            })
        ]
    });
}

// EXTERNAL MODULE: ./src/libs/copy/copy.tsx
var copy = __webpack_require__(1905);
// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/types/address/index.mjs
var types_address = __webpack_require__(7657);
// EXTERNAL MODULE: ./node_modules/@paulmillr/qr/index.js
var qr = __webpack_require__(3181);
;// CONCATENATED MODULE: ./src/mods/foreground/entities/wallets/actions/receive/receive.tsx
/* eslint-disable @next/next/no-img-element */ 








function WalletDataReceiveScreen(props) {
    const { close } = (0,dialog/* useDialogContext */.DA)().unwrap();
    const wallet = (0,wallets_context/* useWalletDataContext */.zI)().unwrap();
    const address = (0,react.useMemo)(()=>{
        return types_address/* Address */.k.from(wallet.address);
    }, [
        wallet.address
    ]);
    const url = (0,react.useMemo)(()=>{
        const bytes = (0,qr/* default */.ZP)(address, "gif", {
            ecc: "medium",
            scale: 10
        });
        const blob = new Blob([
            bytes
        ], {
            type: "image/gif"
        });
        return URL.createObjectURL(blob);
    }, [
        address
    ]);
    const onCopyClick = (0,copy/* useCopy */.F)(address);
    const onShareClick = (0,react.useCallback)(async ()=>{
        await result/* Result */.x.runAndWrap(async ()=>{
            await navigator.share({
                text: address
            });
        }).then((r)=>r.ignore());
    }, [
        address
    ]);
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Dialog */.Vq.Title, {
                close: close,
                children: "Receive"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "grow flex flex-col items-center justify-center",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "text-xl font-medium",
                        children: wallet.name
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                        className: "text-contrast text-center cursor-pointer",
                        onClick: onCopyClick.run,
                        children: onCopyClick.current ? "Copied" : types_address/* Address */.k.format(address)
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-4"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "bg-white rounded-xl p-1",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("img", {
                            className: "",
                            alt: "QR code",
                            src: url
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-4"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "text-contrast text-center max-w-xs",
                        children: "This is an Ethereum address, only send Ethereum-compatible stuff to this address"
                    })
                ]
            }),
            typeof navigator.share === "function" && /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                className: "".concat(ui_button/* Button.Base */.z.XY.className, " ").concat(ui_button/* Button.Contrast */.z.mn.className, " bg-high-contrast po-md"),
                onClick: onShareClick,
                children: "Share"
            })
        ]
    });
}

// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/ClipboardIcon.js
var ClipboardIcon = __webpack_require__(3306);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/XMarkIcon.js
var XMarkIcon = __webpack_require__(1415);
;// CONCATENATED MODULE: ./src/mods/foreground/entities/wallets/actions/send/nonce.tsx












function WalletSendScreenNonce(props) {
    var _pendingNonceQuery_current;
    const wallet = (0,wallets_context/* useWalletDataContext */.zI)().unwrap();
    const { close } = (0,dialog/* useDialogContext */.DA)().unwrap();
    const $state = (0,path_context/* usePathState */.qf)();
    const [chain, setChain] = (0,path_context/* useSearchState */.XN)("chain", $state);
    const [step, setStep] = (0,path_context/* useSearchState */.XN)("step", $state);
    const [nonce, setNonce] = (0,path_context/* useSearchState */.XN)("nonce", $state);
    const chainData = mods_chain/* chainByChainId */.DH[Number(chain)];
    const context = (0,entities_wallets_data/* useEthereumContext */.Kn)(wallet.uuid, chainData);
    const pendingNonceQuery = (0,unknown_data/* useNonce */.XE)(wallet.address, context);
    const maybePendingNonce = (_pendingNonceQuery_current = pendingNonceQuery.current) === null || _pendingNonceQuery_current === void 0 ? void 0 : _pendingNonceQuery_current.ok().get();
    const [rawNonceInput = "", setRawNonceInput] = (0,react.useState)(nonce);
    const onInputChange = (0,events/* useInputChange */.Xy)((e)=>{
        setRawNonceInput(e.target.value);
    }, []);
    const nonceInput = (0,react.useDeferredValue)(rawNonceInput);
    useEffectButNotFirstTime(()=>{
        setNonce(nonceInput);
    }, [
        nonceInput
    ]);
    const onSubmit = (0,react.useCallback)(async ()=>{
        setStep("value");
    }, [
        setStep
    ]);
    const onEnter = (0,events/* useKeyboardEnter */.Fj)(()=>{
        onSubmit();
    }, [
        onSubmit
    ]);
    const onClear = (0,react.useCallback)((e)=>{
        setRawNonceInput("");
    }, []);
    const onPaste = (0,react.useCallback)(async ()=>{
        setNonce(await navigator.clipboard.readText());
        setStep("value");
    }, [
        setNonce,
        setStep
    ]);
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Dialog */.Vq.Title, {
                close: close,
                children: "Send"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-4"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(SimpleBox, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "",
                        children: "Nonce"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-4"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(SimpleInput, {
                        autoFocus: true,
                        value: rawNonceInput,
                        onChange: onInputChange,
                        onKeyDown: onEnter,
                        placeholder: maybePendingNonce === null || maybePendingNonce === void 0 ? void 0 : maybePendingNonce.toString()
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-1"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "flex items-center",
                        children: [
                            rawNonceInput.length === 0 ? /*#__PURE__*/ (0,jsx_runtime.jsx)(ShrinkableNakedButtonInInputBox, {
                                onClick: onPaste,
                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(ClipboardIcon/* default */.Z, {
                                    className: "size-4"
                                })
                            }) : /*#__PURE__*/ (0,jsx_runtime.jsx)(ShrinkableNakedButtonInInputBox, {
                                onClick: onClear,
                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(XMarkIcon/* default */.Z, {
                                    className: "size-4"
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "w-1"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(ShrinkableContrastButtonInInputBox, {
                                onClick: onSubmit,
                                children: "OK"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-4"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "text-lg font-medium",
                children: "Pending transactions"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "grow flex flex-col items-center justify-center",
                children: "Coming soon..."
            })
        ]
    });
}

;// CONCATENATED MODULE: ./src/mods/foreground/entities/wallets/actions/send/target.tsx













function WalletSendScreenTarget(props) {
    var _ensQuery_current;
    const wallet = (0,wallets_context/* useWalletDataContext */.zI)().unwrap();
    const { close } = (0,dialog/* useDialogContext */.DA)().unwrap();
    const $state = (0,path_context/* usePathState */.qf)();
    const [step, setStep] = (0,path_context/* useSearchState */.XN)("step", $state);
    const [target, setTarget] = (0,path_context/* useSearchState */.XN)("target", $state);
    const mainnet = (0,entities_wallets_data/* useEthereumContext */.Kn)(wallet.uuid, mods_chain/* chainByChainId */.DH[1]);
    const [rawTargetInput = "", setRawTargetInput] = (0,react.useState)(target);
    const onTargetInputChange = (0,events/* useInputChange */.Xy)((e)=>{
        setRawTargetInput(e.target.value);
    }, []);
    const targetInput = (0,react.useDeferredValue)(rawTargetInput);
    useEffectButNotFirstTime(()=>{
        setTarget(targetInput);
    }, [
        targetInput
    ]);
    const maybeEnsInput = (target === null || target === void 0 ? void 0 : target.endsWith(".eth")) ? targetInput : undefined;
    const ensQuery = (0,names_data/* useEnsLookup */.aZ)(maybeEnsInput, mainnet);
    const maybeEns = (_ensQuery_current = ensQuery.current) === null || _ensQuery_current === void 0 ? void 0 : _ensQuery_current.ok().get();
    const onSubmit = (0,react.useCallback)(async ()=>{
        if (target == null) return;
        if (types_address/* Address */.k.from(target) == null && !target.endsWith(".eth")) return;
        setStep("value");
    }, [
        target,
        setStep
    ]);
    const onEnter = (0,events/* useKeyboardEnter */.Fj)(()=>{
        onSubmit();
    }, [
        onSubmit
    ]);
    const onClear = (0,react.useCallback)((e)=>{
        setRawTargetInput("");
    }, []);
    const onPaste = (0,react.useCallback)(async ()=>{
        const input = await navigator.clipboard.readText();
        if (types_address/* Address */.k.from(input) == null && !input.endsWith(".eth")) return;
        setTarget(input);
        setStep("value");
    }, [
        setStep,
        setTarget
    ]);
    const [mode, setMode] = (0,react.useState)("recents");
    const onRecentsClick = (0,react.useCallback)(()=>{
        setMode("recents");
    }, []);
    const onContactsClick = (0,react.useCallback)(()=>{
        setMode("contacts");
    }, []);
    const onBrumeClick = (0,react.useCallback)(()=>{
        setTarget("brume.eth");
        setStep("value");
    }, [
        setStep,
        setTarget
    ]);
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Dialog */.Vq.Title, {
                close: close,
                children: "Send"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-4"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(SimpleBox, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "",
                        children: "Target"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-4"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(SimpleInput, {
                        autoFocus: true,
                        value: rawTargetInput,
                        onChange: onTargetInputChange,
                        onKeyDown: onEnter,
                        placeholder: "brume.eth"
                    }, "target"),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-1"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "flex items-center",
                        children: [
                            rawTargetInput.length === 0 ? /*#__PURE__*/ (0,jsx_runtime.jsx)(ShrinkableNakedButtonInInputBox, {
                                onClick: onPaste,
                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(ClipboardIcon/* default */.Z, {
                                    className: "size-4"
                                })
                            }) : /*#__PURE__*/ (0,jsx_runtime.jsx)(ShrinkableNakedButtonInInputBox, {
                                onClick: onClear,
                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(XMarkIcon/* default */.Z, {
                                    className: "size-4"
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "w-1"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(ShrinkableContrastButtonInInputBox, {
                                onClick: onSubmit,
                                children: "OK"
                            })
                        ]
                    })
                ]
            }),
            maybeEns != null && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-2"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "po-md flex items-center bg-contrast rounded-xl cursor-pointer",
                        role: "button",
                        onClick: onSubmit,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "size-12 shrink-0 rounded-full bg-contrast"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "w-4"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "flex flex-col truncate",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "font-medium",
                                        children: targetInput
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "text-contrast truncate",
                                        children: maybeEns
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-4"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "flex items-center",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                        className: "text-lg font-medium text-contrast data-[active=true]:text-default",
                        onClick: onRecentsClick,
                        "data-active": mode === "recents",
                        children: "Recents"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "grow"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                        className: "text-contrast font-medium text-contrast data-[active=true]:text-default",
                        onClick: onContactsClick,
                        "data-active": mode === "contacts",
                        children: "Contacts"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-2"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "po-md flex items-center bg-contrast rounded-xl cursor-pointer",
                role: "button",
                onClick: onBrumeClick,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("img", {
                        className: "size-12 shrink-0 rounded-full bg-contrast",
                        src: "/square.png",
                        alt: "logo"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-4"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "flex flex-col truncate",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "font-medium",
                                children: "Brume Wallet"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "text-contrast truncate",
                                children: "brume.eth"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "grow flex flex-col items-center justify-center",
                children: "Coming soon..."
            })
        ]
    });
}

// EXTERNAL MODULE: ./src/libs/bigints/bigints.ts
var bigints = __webpack_require__(6827);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/CheckIcon.js
var CheckIcon = __webpack_require__(2911);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/ArrowTopRightOnSquareIcon.js
var ArrowTopRightOnSquareIcon = __webpack_require__(1902);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/PencilIcon.js
var PencilIcon = __webpack_require__(8974);
// EXTERNAL MODULE: ./node_modules/ethers/lib.esm/transaction/transaction.js + 2 modules
var transaction = __webpack_require__(5418);
;// CONCATENATED MODULE: ./src/mods/foreground/entities/blocks/data.ts





var FgBlock;
(function(FgBlock) {
    let ByNumber;
    (function(ByNumber) {
        function key(chain, number) {
            return {
                chainId: chain.chainId,
                method: "eth_getBlockByNumber",
                params: [
                    number,
                    false
                ],
                noCheck: true
            };
        }
        ByNumber.key = key;
        function schema(number, context, storage) {
            if (context == null) return;
            if (number == null) return;
            const fetcher = async (request)=>await (0,entities_wallets_data/* fetchOrFail */.yR)(request, context);
            return (0,query/* createQuery */.rP)({
                key: key(context.chain, number),
                fetcher,
                storage
            });
        }
        ByNumber.schema = schema;
    })(ByNumber = FgBlock.ByNumber || (FgBlock.ByNumber = {}));
})(FgBlock || (FgBlock = {}));
function useBlockByNumber(number, ethereum) {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(FgBlock.ByNumber.schema, [
        number,
        ethereum,
        storage
    ]);
    (0,use_fetch/* useFetch */.i)(query);
    (0,use_visible/* useVisible */.E)(query);
    (0,use_interval/* useInterval */.Y)(query, 10 * 1000);
    (0,storage_storage/* useSubscribe */.Q)(query, storage);
    (0,use_error/* useError */.V)(query, errors/* Errors */.D.onQueryError);
    return query;
}

;// CONCATENATED MODULE: ./src/mods/foreground/entities/wallets/actions/send/value/contract.tsx
























function WalletSendScreenContractValue(props) {
    var _tokenQuery_current, _pendingNonceQuery_current, _valuedBalanceQuery_current, _pricedBalanceQuery_current, _ensTargetQuery_current, _fetchedGasPriceQuery_current, _fetchedMaxPriorityFeePerGasQuery_current, _pendingBlockQuery_current, _legacyGasLimitQuery_current, _eip1559GasLimitQuery_current, _tokenData_pairs, _chainData_token_pairs, _eip1559GasLimitQuery_current1, _eip1559GasLimitQuery_current_get, _legacyGasLimitQuery_current1, _legacyGasLimitQuery_current_get;
    const wallet = (0,wallets_context/* useWalletDataContext */.zI)().unwrap();
    const { close } = (0,dialog/* useDialogContext */.DA)().unwrap();
    const $state = (0,path_context/* usePathState */.qf)();
    const [maybeStep, setStep] = (0,path_context/* useSearchState */.XN)("step", $state);
    const [maybeChain, setChain] = (0,path_context/* useSearchState */.XN)("chain", $state);
    const [maybeToken, setToken] = (0,path_context/* useSearchState */.XN)("token", $state);
    const [maybeTarget, setTarget] = (0,path_context/* useSearchState */.XN)("target", $state);
    const [maybeValued, setValued] = (0,path_context/* useSearchState */.XN)("valued", $state);
    const [maybePriced, setPriced] = (0,path_context/* useSearchState */.XN)("priced", $state);
    const [maybeNonce, setNonce] = (0,path_context/* useSearchState */.XN)("nonce", $state);
    const [maybeGasMode, setGasMode] = (0,path_context/* useSearchState */.XN)("gasMode", $state);
    const [maybeGasLimit, setGasLimit] = (0,path_context/* useSearchState */.XN)("gasLimit", $state);
    const [maybeGasPrice, setGasPrice] = (0,path_context/* useSearchState */.XN)("gasPrice", $state);
    const [maybeBaseFeePerGas, setBaseFeePerGas] = (0,path_context/* useSearchState */.XN)("baseFeePerGas", $state);
    const [maybeMaxPriorityFeePerGas, setMaxPriorityFeePerGas] = (0,path_context/* useSearchState */.XN)("maxPriorityFeePerGas", $state);
    const gasMode = option_option/* Option */.W.wrap(maybeGasMode).unwrapOr("normal");
    const chain = option_option/* Option */.W.unwrap(maybeChain);
    const chainData = mods_chain/* chainByChainId */.DH[Number(chain)];
    const token = option_option/* Option */.W.unwrap(maybeToken);
    const tokenQuery = useToken(chainData.chainId, token);
    const maybeTokenData = option_option/* Option */.W.wrap((_tokenQuery_current = tokenQuery.current) === null || _tokenQuery_current === void 0 ? void 0 : _tokenQuery_current.get());
    const maybeTokenDef = option_option/* Option */.W.wrap(mods_chain/* tokenByAddress */.q2[token]);
    const tokenData = maybeTokenData.or(maybeTokenDef).unwrap();
    const context = (0,entities_wallets_data/* useEthereumContext2 */.IL)(wallet.uuid, chainData).unwrap();
    const pendingNonceQuery = (0,unknown_data/* useNonce */.XE)(wallet.address, context);
    const maybePendingNonce = (_pendingNonceQuery_current = pendingNonceQuery.current) === null || _pendingNonceQuery_current === void 0 ? void 0 : _pendingNonceQuery_current.ok().get();
    const [tokenPrices, setTokenPrices] = (0,react.useState)(()=>{
        if (tokenData.pairs == null) return;
        return new Array(tokenData.pairs.length);
    });
    const [chainPrices, setChainPrices] = (0,react.useState)(()=>{
        if (chainData.token.pairs == null) return;
        return new Array(chainData.token.pairs.length);
    });
    const onTokenPrice = (0,react.useCallback)((param)=>{
        let [index, data] = param;
        setTokenPrices((prices)=>{
            if (prices == null) return;
            prices[index] = data;
            return [
                ...prices
            ];
        });
    }, []);
    const onChainPrice = (0,react.useCallback)((param)=>{
        let [index, data] = param;
        setChainPrices((prices)=>{
            if (prices == null) return;
            prices[index] = data;
            return [
                ...prices
            ];
        });
    }, []);
    const maybeTokenPrice = (0,react.useMemo)(()=>{
        if (tokenPrices == null) return;
        return tokenPrices.reduce((a, b)=>{
            if (a == null) return undefined;
            if (b == null) return undefined;
            return a.mul(types_fixed/* Fixed */.g.from(b));
        }, types_fixed/* Fixed */.g.unit(18));
    }, [
        tokenPrices
    ]);
    const maybeChainPrice = (0,react.useMemo)(()=>{
        if (chainPrices == null) return;
        return chainPrices.reduce((a, b)=>{
            if (a == null) return undefined;
            if (b == null) return undefined;
            return a.mul(types_fixed/* Fixed */.g.from(b));
        }, types_fixed/* Fixed */.g.unit(18));
    }, [
        chainPrices
    ]);
    const [rawValueInput = "", setRawValueInput] = (0,react.useState)(maybeValued);
    const [rawPricedInput = "", setRawPricedInput] = (0,react.useState)(maybePriced);
    const setValue = (0,react.useCallback)((input)=>{
        try {
            setRawValueInput(input);
            if (input.trim().length === 0) {
                setRawPricedInput(undefined);
                return;
            }
            if (maybeTokenPrice == null) {
                setRawPricedInput(undefined);
                return;
            }
            const priced = types_fixed/* Fixed */.g.fromString(input, tokenData.decimals).mul(maybeTokenPrice);
            if (priced.value === 0n) {
                setRawPricedInput(undefined);
                return;
            }
            setRawPricedInput(priced.toString());
        } catch (e) {
            setRawPricedInput(undefined);
            return;
        }
    }, [
        tokenData,
        maybeTokenPrice
    ]);
    const setPrice = (0,react.useCallback)((input)=>{
        try {
            setRawPricedInput(input);
            if (input.trim().length === 0) {
                setRawValueInput(undefined);
                return;
            }
            if (maybeTokenPrice == null) {
                setRawValueInput(undefined);
                return;
            }
            const valued = types_fixed/* Fixed */.g.fromString(input, tokenData.decimals).div(maybeTokenPrice);
            if (valued.value === 0n) {
                setRawValueInput(undefined);
                return;
            }
            setRawValueInput(valued.toString());
        } catch (e) {
            setRawValueInput(undefined);
            return;
        }
    }, [
        tokenData,
        maybeTokenPrice
    ]);
    const onValueInputChange = (0,events/* useInputChange */.Xy)((e)=>{
        setValue(e.target.value);
    }, [
        setValue
    ]);
    const onPricedInputChange = (0,events/* useInputChange */.Xy)((e)=>{
        setPrice(e.target.value);
    }, [
        setPrice
    ]);
    const valueInput = (0,react.useDeferredValue)(rawValueInput);
    const pricedInput = (0,react.useDeferredValue)(rawPricedInput);
    useEffectButNotFirstTime(()=>{
        setValued(valueInput);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        valueInput
    ]);
    useEffectButNotFirstTime(()=>{
        setPriced(pricedInput);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        pricedInput
    ]);
    const [mode, setMode] = (0,react.useState)("valued");
    const valuedBalanceQuery = useNativeBalance(wallet.address, "pending", context, tokenPrices);
    const pricedBalanceQuery = useNativePricedBalance(wallet.address, "usd", context);
    const valuedBalanceData = (_valuedBalanceQuery_current = valuedBalanceQuery.current) === null || _valuedBalanceQuery_current === void 0 ? void 0 : _valuedBalanceQuery_current.ok().get();
    const pricedBalanceData = (_pricedBalanceQuery_current = pricedBalanceQuery.current) === null || _pricedBalanceQuery_current === void 0 ? void 0 : _pricedBalanceQuery_current.ok().get();
    const onValueMaxClick = (0,react.useCallback)(()=>{
        if (valuedBalanceData == null) return;
        setValue(types_fixed/* Fixed */.g.from(valuedBalanceData).toString());
    }, [
        valuedBalanceData,
        setValue
    ]);
    const onPricedMaxClick = (0,react.useCallback)(()=>{
        if (pricedBalanceData == null) return;
        setPrice(types_fixed/* Fixed */.g.from(pricedBalanceData).toString());
    }, [
        pricedBalanceData,
        setPrice
    ]);
    const onValuedPaste = (0,react.useCallback)(async ()=>{
        setValue(await navigator.clipboard.readText());
    }, [
        setValue
    ]);
    const onPricedPaste = (0,react.useCallback)(async ()=>{
        setPrice(await navigator.clipboard.readText());
    }, [
        setPrice
    ]);
    const onValuedClear = (0,react.useCallback)(async ()=>{
        setValue("");
    }, [
        setValue
    ]);
    const onPricedClear = (0,react.useCallback)(async ()=>{
        setPrice("");
    }, [
        setPrice
    ]);
    const onTargetFocus = (0,react.useCallback)(()=>{
        setStep("target");
    }, [
        setStep
    ]);
    const onNonceClick = (0,react.useCallback)(()=>{
        setStep("nonce");
    }, [
        setStep
    ]);
    const onPricedClick = (0,react.useCallback)(()=>{
        setMode("priced");
    }, []);
    const onValuedClick = (0,react.useCallback)(()=>{
        setMode("valued");
    }, []);
    const mainnet = (0,entities_wallets_data/* useEthereumContext */.Kn)(wallet.uuid, mods_chain/* chainByChainId */.DH[1]);
    const maybeEnsQueryKey = (maybeTarget === null || maybeTarget === void 0 ? void 0 : maybeTarget.endsWith(".eth")) ? maybeTarget : undefined;
    const ensTargetQuery = (0,names_data/* useEnsLookup */.aZ)(maybeEnsQueryKey, mainnet);
    const maybeEnsTarget = (_ensTargetQuery_current = ensTargetQuery.current) === null || _ensTargetQuery_current === void 0 ? void 0 : _ensTargetQuery_current.ok().get();
    const maybeFinalTarget = (0,react.useMemo)(()=>{
        if (maybeTarget == null) return undefined;
        if (types_address/* Address */.k.from(maybeTarget) != null) return maybeTarget;
        if (maybeEnsTarget != null) return maybeEnsTarget;
        return undefined;
    }, [
        maybeTarget,
        maybeEnsTarget
    ]);
    const maybeFinalValue = (0,react.useMemo)(()=>{
        try {
            return (maybeValued === null || maybeValued === void 0 ? void 0 : maybeValued.trim().length) ? types_fixed/* Fixed */.g.fromString(maybeValued.trim(), tokenData.decimals) : new types_fixed/* Fixed */.g(0n, tokenData.decimals);
        } catch (e) {}
    }, [
        maybeValued,
        tokenData
    ]);
    const [rawNonceInput = "", setRawNonceInput] = (0,react.useState)(maybeNonce);
    const onNonceInputChange = (0,events/* useInputChange */.Xy)((e)=>{
        setRawNonceInput(e.target.value);
    }, []);
    const nonceInput = (0,react.useDeferredValue)(rawNonceInput);
    useEffectButNotFirstTime(()=>{
        setNonce(nonceInput);
    }, [
        nonceInput
    ]);
    const maybeCustomNonce = (0,react.useMemo)(()=>{
        try {
            return (maybeNonce === null || maybeNonce === void 0 ? void 0 : maybeNonce.trim().length) ? BigInt(maybeNonce.trim()) : undefined;
        } catch (e) {}
    }, [
        maybeNonce
    ]);
    const maybeFinalNonce = (0,react.useMemo)(()=>{
        if (maybeCustomNonce != null) return maybeCustomNonce;
        if (maybePendingNonce != null) return maybePendingNonce;
        return undefined;
    }, [
        maybeCustomNonce,
        maybePendingNonce
    ]);
    const maybeFinalData = (0,react.useMemo)(()=>{
        try {
            if (maybeFinalTarget == null) return undefined;
            if (maybeFinalValue == null) return undefined;
            const address = types_address/* Address */.k.fromOrThrow(maybeFinalTarget);
            const value = maybeFinalValue.value;
            return encode/* encodeOrThrow */.YM(TokenAbi.transfer.from(address, value));
        } catch (e) {}
    }, [
        maybeFinalTarget,
        maybeFinalValue
    ]);
    const onGasModeChange = (0,react.useCallback)((e)=>{
        setGasMode(e.currentTarget.value);
    }, [
        setGasMode
    ]);
    const fetchedGasPriceQuery = (0,unknown_data/* useGasPrice */.Fh)(context);
    const maybeFetchedGasPrice = (_fetchedGasPriceQuery_current = fetchedGasPriceQuery.current) === null || _fetchedGasPriceQuery_current === void 0 ? void 0 : _fetchedGasPriceQuery_current.ok().get();
    const fetchedMaxPriorityFeePerGasQuery = (0,unknown_data/* useMaxPriorityFeePerGas */.hy)(context);
    const maybeFetchedMaxPriorityFeePerGas = (_fetchedMaxPriorityFeePerGasQuery_current = fetchedMaxPriorityFeePerGasQuery.current) === null || _fetchedMaxPriorityFeePerGasQuery_current === void 0 ? void 0 : _fetchedMaxPriorityFeePerGasQuery_current.ok().get();
    const pendingBlockQuery = useBlockByNumber("pending", context);
    const maybePendingBlock = (_pendingBlockQuery_current = pendingBlockQuery.current) === null || _pendingBlockQuery_current === void 0 ? void 0 : _pendingBlockQuery_current.ok().get();
    const maybeFetchedBaseFeePerGas = (0,react.useMemo)(()=>{
        try {
            return (maybePendingBlock === null || maybePendingBlock === void 0 ? void 0 : maybePendingBlock.baseFeePerGas) != null ? bigints/* BigIntToHex */.W.decodeOrThrow(maybePendingBlock.baseFeePerGas) : undefined;
        } catch (e) {}
    }, [
        maybePendingBlock
    ]);
    const maybeIsEip1559 = (0,react.useMemo)(()=>{
        return (maybePendingBlock === null || maybePendingBlock === void 0 ? void 0 : maybePendingBlock.baseFeePerGas) != null;
    }, [
        maybePendingBlock
    ]);
    const [rawGasLimitInput = "", setRawGasLimitInput] = (0,react.useState)(maybeGasLimit);
    const onGasLimitInputChange = (0,events/* useInputChange */.Xy)((e)=>{
        setRawGasLimitInput(e.target.value);
    }, []);
    const gasLimitInput = (0,react.useDeferredValue)(rawGasLimitInput);
    useEffectButNotFirstTime(()=>{
        setGasLimit(gasLimitInput);
    }, [
        gasLimitInput
    ]);
    const [rawGasPriceInput = "", setRawGasPriceInput] = (0,react.useState)(maybeGasPrice);
    const onGasPriceInputChange = (0,events/* useInputChange */.Xy)((e)=>{
        setRawGasPriceInput(e.target.value);
    }, []);
    const gasPriceInput = (0,react.useDeferredValue)(rawGasPriceInput);
    useEffectButNotFirstTime(()=>{
        setGasPrice(gasPriceInput);
    }, [
        gasPriceInput
    ]);
    const [rawBaseFeePerGasInput = "", setRawBaseFeePerGasInput] = (0,react.useState)(maybeBaseFeePerGas);
    const onBaseFeePerGasInputChange = (0,events/* useInputChange */.Xy)((e)=>{
        setRawBaseFeePerGasInput(e.target.value);
    }, []);
    const baseFeePerGasInput = (0,react.useDeferredValue)(rawBaseFeePerGasInput);
    useEffectButNotFirstTime(()=>{
        setBaseFeePerGas(baseFeePerGasInput);
    }, [
        baseFeePerGasInput
    ]);
    const [rawMaxPriorityFeePerGasInput = "", setRawMaxPriorityFeePerGasInput] = (0,react.useState)(maybeMaxPriorityFeePerGas);
    const onMaxPriorityFeePerGasInputChange = (0,events/* useInputChange */.Xy)((e)=>{
        setRawMaxPriorityFeePerGasInput(e.target.value);
    }, []);
    const maxPriorityFeePerGasInput = (0,react.useDeferredValue)(rawMaxPriorityFeePerGasInput);
    useEffectButNotFirstTime(()=>{
        setMaxPriorityFeePerGas(maxPriorityFeePerGasInput);
    }, [
        maxPriorityFeePerGasInput
    ]);
    function useMaybeMemo(f, param) {
        let [x] = param;
        return (0,react.useMemo)(()=>{
            if (x == null) return undefined;
            return f(x);
        // eslint-disable-next-line react-hooks/exhaustive-deps
        }, [
            x
        ]);
    }
    const maybeNormalBaseFeePerGas = useMaybeMemo((baseFeePerGas)=>{
        return baseFeePerGas;
    }, [
        maybeFetchedBaseFeePerGas
    ]);
    const maybeFastBaseFeePerGas = useMaybeMemo((baseFeePerGas)=>{
        return baseFeePerGas + 1n * 10n ** 9n;
    }, [
        maybeFetchedBaseFeePerGas
    ]);
    const maybeUrgentBaseFeePerGas = useMaybeMemo((baseFeePerGas)=>{
        return baseFeePerGas + 2n * 10n ** 9n;
    }, [
        maybeFetchedBaseFeePerGas
    ]);
    const maybeCustomBaseFeePerGas = (0,react.useMemo)(()=>{
        try {
            return (maybeBaseFeePerGas === null || maybeBaseFeePerGas === void 0 ? void 0 : maybeBaseFeePerGas.trim().length) ? BigInt(maybeBaseFeePerGas.trim()) : maybeNormalBaseFeePerGas;
        } catch (e) {}
    }, [
        maybeBaseFeePerGas,
        maybeNormalBaseFeePerGas
    ]);
    const maybeNormalMaxPriorityFeePerGas = useMaybeMemo((maxPriorityFeePerGas)=>{
        return maxPriorityFeePerGas / 4n;
    }, [
        maybeFetchedMaxPriorityFeePerGas
    ]);
    const maybeFastMaxPriorityFeePerGas = useMaybeMemo((maxPriorityFeePerGas)=>{
        return maxPriorityFeePerGas / 2n;
    }, [
        maybeFetchedMaxPriorityFeePerGas
    ]);
    const maybeUrgentMaxPriorityFeePerGas = useMaybeMemo((maxPriorityFeePerGas)=>{
        return maxPriorityFeePerGas;
    }, [
        maybeFetchedMaxPriorityFeePerGas
    ]);
    const maybeCustomMaxPriorityFeePerGas = (0,react.useMemo)(()=>{
        try {
            return (maybeMaxPriorityFeePerGas === null || maybeMaxPriorityFeePerGas === void 0 ? void 0 : maybeMaxPriorityFeePerGas.trim().length) ? BigInt(maybeMaxPriorityFeePerGas.trim()) : maybeNormalMaxPriorityFeePerGas;
        } catch (e) {}
    }, [
        maybeMaxPriorityFeePerGas,
        maybeNormalMaxPriorityFeePerGas
    ]);
    const maybeNormalGasPrice = useMaybeMemo((gasPrice)=>{
        return gasPrice;
    }, [
        maybeFetchedGasPrice
    ]);
    const maybeFastGasPrice = useMaybeMemo((gasPrice)=>{
        return gasPrice * 110n / 100n;
    }, [
        maybeFetchedGasPrice
    ]);
    const maybeUrgentGasPrice = useMaybeMemo((gasPrice)=>{
        return gasPrice * 120n / 100n;
    }, [
        maybeFetchedGasPrice
    ]);
    const maybeCustomGasPrice = (0,react.useMemo)(()=>{
        try {
            return (maybeGasPrice === null || maybeGasPrice === void 0 ? void 0 : maybeGasPrice.trim().length) ? BigInt(maybeGasPrice.trim()) : maybeNormalGasPrice;
        } catch (e) {}
    }, [
        maybeGasPrice,
        maybeNormalGasPrice
    ]);
    const maybeNormalMinFeePerGas = (0,react.useMemo)(()=>{
        if (maybeNormalBaseFeePerGas == null) return undefined;
        if (maybeNormalMaxPriorityFeePerGas == null) return undefined;
        return maybeNormalBaseFeePerGas + maybeNormalMaxPriorityFeePerGas;
    }, [
        maybeNormalBaseFeePerGas,
        maybeNormalMaxPriorityFeePerGas
    ]);
    const maybeFastMinFeePerGas = (0,react.useMemo)(()=>{
        if (maybeFastBaseFeePerGas == null) return undefined;
        if (maybeFastMaxPriorityFeePerGas == null) return undefined;
        return maybeFastBaseFeePerGas + maybeFastMaxPriorityFeePerGas;
    }, [
        maybeFastBaseFeePerGas,
        maybeFastMaxPriorityFeePerGas
    ]);
    const maybeUrgentMinFeePerGas = (0,react.useMemo)(()=>{
        if (maybeUrgentBaseFeePerGas == null) return undefined;
        if (maybeUrgentMaxPriorityFeePerGas == null) return undefined;
        return maybeUrgentBaseFeePerGas + maybeUrgentMaxPriorityFeePerGas;
    }, [
        maybeUrgentBaseFeePerGas,
        maybeUrgentMaxPriorityFeePerGas
    ]);
    const maybeCustomMinFeePerGas = (0,react.useMemo)(()=>{
        if (maybeCustomBaseFeePerGas == null) return undefined;
        if (maybeCustomMaxPriorityFeePerGas == null) return undefined;
        return maybeCustomBaseFeePerGas + maybeCustomMaxPriorityFeePerGas;
    }, [
        maybeCustomBaseFeePerGas,
        maybeCustomMaxPriorityFeePerGas
    ]);
    const maybeNormalMaxFeePerGas = (0,react.useMemo)(()=>{
        if (maybeNormalBaseFeePerGas == null) return undefined;
        if (maybeNormalMaxPriorityFeePerGas == null) return undefined;
        return maybeNormalBaseFeePerGas * 2n + maybeNormalMaxPriorityFeePerGas;
    }, [
        maybeNormalBaseFeePerGas,
        maybeNormalMaxPriorityFeePerGas
    ]);
    const maybeFastMaxFeePerGas = (0,react.useMemo)(()=>{
        if (maybeFastBaseFeePerGas == null) return undefined;
        if (maybeFastMaxPriorityFeePerGas == null) return undefined;
        return maybeFastBaseFeePerGas * 2n + maybeFastMaxPriorityFeePerGas;
    }, [
        maybeFastBaseFeePerGas,
        maybeFastMaxPriorityFeePerGas
    ]);
    const maybeUrgentMaxFeePerGas = (0,react.useMemo)(()=>{
        if (maybeUrgentBaseFeePerGas == null) return undefined;
        if (maybeUrgentMaxPriorityFeePerGas == null) return undefined;
        return maybeUrgentBaseFeePerGas * 2n + maybeUrgentMaxPriorityFeePerGas;
    }, [
        maybeUrgentBaseFeePerGas,
        maybeUrgentMaxPriorityFeePerGas
    ]);
    const maybeCustomMaxFeePerGas = (0,react.useMemo)(()=>{
        if (maybeCustomBaseFeePerGas == null) return undefined;
        if (maybeCustomMaxPriorityFeePerGas == null) return undefined;
        return maybeCustomBaseFeePerGas * 2n + maybeCustomMaxPriorityFeePerGas;
    }, [
        maybeCustomBaseFeePerGas,
        maybeCustomMaxPriorityFeePerGas
    ]);
    function useMode(normal, fast, urgent, custom) {
        return (0,react.useMemo)(()=>{
            if (gasMode === "normal") return normal;
            if (gasMode === "fast") return fast;
            if (gasMode === "urgent") return urgent;
            if (gasMode === "custom") return custom;
            return undefined;
        // eslint-disable-next-line react-hooks/exhaustive-deps
        }, [
            gasMode,
            normal,
            fast,
            urgent,
            custom
        ]);
    }
    function useGasDisplay(gasPrice) {
        return (0,react.useMemo)(()=>{
            if (gasPrice == null) return "???";
            return Number(new types_fixed/* Fixed */.g(gasPrice, 9).move(4).toString()).toLocaleString(undefined, {
                maximumSignificantDigits: 2
            });
        }, [
            gasPrice
        ]);
    }
    function useCompactUsdDisplay(fixed) {
        return (0,react.useMemo)(()=>{
            if (fixed == null) return "???";
            return Number(fixed.move(2).toString()).toLocaleString(undefined, {
                style: "currency",
                currency: "USD",
                notation: "compact"
            });
        }, [
            fixed
        ]);
    }
    const maybeFinalGasPrice = useMode(maybeNormalGasPrice, maybeFastGasPrice, maybeUrgentGasPrice, maybeCustomGasPrice);
    const maybeFinalMaxFeePerGas = useMode(maybeNormalMaxFeePerGas, maybeFastMaxFeePerGas, maybeUrgentMaxFeePerGas, maybeCustomMaxFeePerGas);
    const maybeFinalMaxPriorityFeePerGas = useMode(maybeNormalMaxPriorityFeePerGas, maybeFastMaxPriorityFeePerGas, maybeUrgentMaxPriorityFeePerGas, maybeCustomMaxPriorityFeePerGas);
    const maybeLegacyGasLimitKey = (0,react.useMemo)(()=>{
        if (maybeIsEip1559 !== false) return undefined;
        if (maybeFinalTarget == null) return undefined;
        if (maybeFinalNonce == null) return undefined;
        if (maybeFinalGasPrice == null) return undefined;
        if (maybeFinalData == null) return undefined;
        return {
            method: "eth_estimateGas",
            params: [
                {
                    chainId: zerohex/* ZeroHexString */.T.from(chainData.chainId),
                    from: wallet.address,
                    to: tokenData.address,
                    gasPrice: zerohex/* ZeroHexString */.T.from(maybeFinalGasPrice),
                    nonce: zerohex/* ZeroHexString */.T.from(maybeFinalNonce),
                    data: maybeFinalData
                },
                "latest"
            ]
        };
    }, [
        wallet,
        chainData,
        tokenData,
        maybeIsEip1559,
        maybeFinalTarget,
        maybeFinalNonce,
        maybeFinalData,
        maybeFinalGasPrice
    ]);
    const maybeEip1559GasLimitKey = (0,react.useMemo)(()=>{
        if (maybeIsEip1559 !== true) return undefined;
        if (maybeFinalTarget == null) return undefined;
        if (maybeFinalNonce == null) return undefined;
        if (maybeFinalMaxFeePerGas == null) return undefined;
        if (maybeFinalMaxPriorityFeePerGas == null) return undefined;
        if (maybeFinalData == null) return undefined;
        return {
            method: "eth_estimateGas",
            params: [
                {
                    chainId: zerohex/* ZeroHexString */.T.from(chainData.chainId),
                    from: wallet.address,
                    to: tokenData.address,
                    maxFeePerGas: zerohex/* ZeroHexString */.T.from(maybeFinalMaxFeePerGas),
                    maxPriorityFeePerGas: zerohex/* ZeroHexString */.T.from(maybeFinalMaxPriorityFeePerGas),
                    nonce: zerohex/* ZeroHexString */.T.from(maybeFinalNonce),
                    data: maybeFinalData
                },
                "latest"
            ]
        };
    }, [
        wallet,
        chainData,
        tokenData,
        maybeIsEip1559,
        maybeFinalTarget,
        maybeFinalNonce,
        maybeFinalData,
        maybeFinalMaxFeePerGas,
        maybeFinalMaxPriorityFeePerGas
    ]);
    const legacyGasLimitQuery = (0,unknown_data/* useEstimateGas */.Nh)(maybeLegacyGasLimitKey, context);
    const maybeLegacyGasLimit = (_legacyGasLimitQuery_current = legacyGasLimitQuery.current) === null || _legacyGasLimitQuery_current === void 0 ? void 0 : _legacyGasLimitQuery_current.ok().get();
    const eip1559GasLimitQuery = (0,unknown_data/* useEstimateGas */.Nh)(maybeEip1559GasLimitKey, context);
    const maybeEip1559GasLimit = (_eip1559GasLimitQuery_current = eip1559GasLimitQuery.current) === null || _eip1559GasLimitQuery_current === void 0 ? void 0 : _eip1559GasLimitQuery_current.ok().get();
    const maybeFetchedGasLimit = (0,react.useMemo)(()=>{
        if (maybeIsEip1559 == null) return undefined;
        if (maybeLegacyGasLimit != null) return maybeLegacyGasLimit;
        if (maybeEip1559GasLimit != null) return maybeEip1559GasLimit;
        return undefined;
    }, [
        maybeIsEip1559,
        maybeLegacyGasLimit,
        maybeEip1559GasLimit
    ]);
    const maybeCustomGasLimit = (0,react.useMemo)(()=>{
        try {
            return (maybeGasLimit === null || maybeGasLimit === void 0 ? void 0 : maybeGasLimit.trim().length) ? BigInt(maybeGasLimit.trim()) : maybeFetchedGasLimit;
        } catch (e) {}
    }, [
        maybeGasLimit,
        maybeFetchedGasLimit
    ]);
    const maybeFinalGasLimit = (0,react.useMemo)(()=>{
        if (gasMode === "custom") return maybeCustomGasLimit;
        return maybeFetchedGasLimit;
    }, [
        gasMode,
        maybeCustomGasLimit,
        maybeFetchedGasLimit
    ]);
    const maybeNormalLegacyGasCost = (0,react.useMemo)(()=>{
        if (maybeLegacyGasLimit == null) return undefined;
        if (maybeNormalGasPrice == null) return undefined;
        if (maybeChainPrice == null) return undefined;
        return new types_fixed/* Fixed */.g(maybeLegacyGasLimit * maybeNormalGasPrice, 18).mul(maybeChainPrice);
    }, [
        maybeLegacyGasLimit,
        maybeNormalGasPrice,
        maybeChainPrice
    ]);
    const maybeFastLegacyGasCost = (0,react.useMemo)(()=>{
        if (maybeLegacyGasLimit == null) return undefined;
        if (maybeFastGasPrice == null) return undefined;
        if (maybeChainPrice == null) return undefined;
        return new types_fixed/* Fixed */.g(maybeLegacyGasLimit * maybeFastGasPrice, 18).mul(maybeChainPrice);
    }, [
        maybeLegacyGasLimit,
        maybeFastGasPrice,
        maybeChainPrice
    ]);
    const maybeUrgentLegacyGasCost = (0,react.useMemo)(()=>{
        if (maybeLegacyGasLimit == null) return undefined;
        if (maybeUrgentGasPrice == null) return undefined;
        if (maybeChainPrice == null) return undefined;
        return new types_fixed/* Fixed */.g(maybeLegacyGasLimit * maybeUrgentGasPrice, 18).mul(maybeChainPrice);
    }, [
        maybeLegacyGasLimit,
        maybeUrgentGasPrice,
        maybeChainPrice
    ]);
    const maybeCustomLegacyGasCost = (0,react.useMemo)(()=>{
        if (maybeCustomGasLimit == null) return undefined;
        if (maybeCustomGasPrice == null) return undefined;
        if (maybeChainPrice == null) return undefined;
        return new types_fixed/* Fixed */.g(maybeCustomGasLimit * maybeCustomGasPrice, 18).mul(maybeChainPrice);
    }, [
        maybeCustomGasLimit,
        maybeCustomGasPrice,
        maybeChainPrice
    ]);
    const maybeNormalMinEip1559GasCost = (0,react.useMemo)(()=>{
        if (maybeEip1559GasLimit == null) return undefined;
        if (maybeNormalMinFeePerGas == null) return undefined;
        if (maybeChainPrice == null) return undefined;
        return new types_fixed/* Fixed */.g(maybeEip1559GasLimit * maybeNormalMinFeePerGas, 18).mul(maybeChainPrice);
    }, [
        maybeEip1559GasLimit,
        maybeNormalMinFeePerGas,
        maybeChainPrice
    ]);
    const maybeFastMinEip1559GasCost = (0,react.useMemo)(()=>{
        if (maybeEip1559GasLimit == null) return undefined;
        if (maybeFastMinFeePerGas == null) return undefined;
        if (maybeChainPrice == null) return undefined;
        return new types_fixed/* Fixed */.g(maybeEip1559GasLimit * maybeFastMinFeePerGas, 18).mul(maybeChainPrice);
    }, [
        maybeEip1559GasLimit,
        maybeFastMinFeePerGas,
        maybeChainPrice
    ]);
    const maybeUrgentMinEip1559GasCost = (0,react.useMemo)(()=>{
        if (maybeEip1559GasLimit == null) return undefined;
        if (maybeUrgentMinFeePerGas == null) return undefined;
        if (maybeChainPrice == null) return undefined;
        return new types_fixed/* Fixed */.g(maybeEip1559GasLimit * maybeUrgentMinFeePerGas, 18).mul(maybeChainPrice);
    }, [
        maybeEip1559GasLimit,
        maybeUrgentMinFeePerGas,
        maybeChainPrice
    ]);
    const maybeCustomMinEip1559GasCost = (0,react.useMemo)(()=>{
        if (maybeCustomGasLimit == null) return undefined;
        if (maybeCustomMinFeePerGas == null) return undefined;
        if (maybeChainPrice == null) return undefined;
        return new types_fixed/* Fixed */.g(maybeCustomGasLimit * maybeCustomMinFeePerGas, 18).mul(maybeChainPrice);
    }, [
        maybeCustomGasLimit,
        maybeCustomMinFeePerGas,
        maybeChainPrice
    ]);
    const maybeNormalMaxEip1559GasCost = (0,react.useMemo)(()=>{
        if (maybeEip1559GasLimit == null) return undefined;
        if (maybeNormalMaxFeePerGas == null) return undefined;
        if (maybeChainPrice == null) return undefined;
        return new types_fixed/* Fixed */.g(maybeEip1559GasLimit * maybeNormalMaxFeePerGas, 18).mul(maybeChainPrice);
    }, [
        maybeEip1559GasLimit,
        maybeNormalMaxFeePerGas,
        maybeChainPrice
    ]);
    const maybeFastMaxEip1559GasCost = (0,react.useMemo)(()=>{
        if (maybeEip1559GasLimit == null) return undefined;
        if (maybeFastMaxFeePerGas == null) return undefined;
        if (maybeChainPrice == null) return undefined;
        return new types_fixed/* Fixed */.g(maybeEip1559GasLimit * maybeFastMaxFeePerGas, 18).mul(maybeChainPrice);
    }, [
        maybeEip1559GasLimit,
        maybeFastMaxFeePerGas,
        maybeChainPrice
    ]);
    const maybeUrgentMaxEip1559GasCost = (0,react.useMemo)(()=>{
        if (maybeEip1559GasLimit == null) return undefined;
        if (maybeUrgentMaxFeePerGas == null) return undefined;
        if (maybeChainPrice == null) return undefined;
        return new types_fixed/* Fixed */.g(maybeEip1559GasLimit * maybeUrgentMaxFeePerGas, 18).mul(maybeChainPrice);
    }, [
        maybeEip1559GasLimit,
        maybeUrgentMaxFeePerGas,
        maybeChainPrice
    ]);
    const maybeCustomMaxEip1559GasCost = (0,react.useMemo)(()=>{
        if (maybeCustomGasLimit == null) return undefined;
        if (maybeCustomMaxFeePerGas == null) return undefined;
        if (maybeChainPrice == null) return undefined;
        return new types_fixed/* Fixed */.g(maybeCustomGasLimit * maybeCustomMaxFeePerGas, 18).mul(maybeChainPrice);
    }, [
        maybeCustomGasLimit,
        maybeCustomMaxFeePerGas,
        maybeChainPrice
    ]);
    const maybeFinalLegacyGasCost = useMode(maybeNormalLegacyGasCost, maybeFastLegacyGasCost, maybeUrgentLegacyGasCost, maybeCustomLegacyGasCost);
    const maybeFinalMinEip1559GasCost = useMode(maybeNormalMinEip1559GasCost, maybeFastMinEip1559GasCost, maybeUrgentMinEip1559GasCost, maybeCustomMinEip1559GasCost);
    const maybeFinalMaxEip1559GasCost = useMode(maybeNormalMaxEip1559GasCost, maybeFastMaxEip1559GasCost, maybeUrgentMaxEip1559GasCost, maybeCustomMaxEip1559GasCost);
    const normalLegacyGasCostDisplay = useCompactUsdDisplay(maybeNormalLegacyGasCost);
    const fastLegacyGasCostDisplay = useCompactUsdDisplay(maybeFastLegacyGasCost);
    const urgentLegacyGasCostDisplay = useCompactUsdDisplay(maybeUrgentLegacyGasCost);
    const finalLegacyGasCostDisplay = useCompactUsdDisplay(maybeFinalLegacyGasCost);
    const normalMinEip1559GasCostDisplay = useCompactUsdDisplay(maybeNormalMinEip1559GasCost);
    const fastMinEip1559GasCostDisplay = useCompactUsdDisplay(maybeFastMinEip1559GasCost);
    const urgentMinEip1559GasCostDisplay = useCompactUsdDisplay(maybeUrgentMinEip1559GasCost);
    const finalMinEip1559GasCostDisplay = useCompactUsdDisplay(maybeFinalMinEip1559GasCost);
    const normalMaxEip1559GasCostDisplay = useCompactUsdDisplay(maybeNormalMaxEip1559GasCost);
    const fastMaxEip1559GasCostDisplay = useCompactUsdDisplay(maybeFastMaxEip1559GasCost);
    const urgentMaxEip1559GasCostDisplay = useCompactUsdDisplay(maybeUrgentMaxEip1559GasCost);
    const finalMaxEip1559GasCostDisplay = useCompactUsdDisplay(maybeFinalMaxEip1559GasCost);
    const normalGasPriceDisplay = useGasDisplay(maybeNormalGasPrice);
    const fastGasPriceDisplay = useGasDisplay(maybeFastGasPrice);
    const urgentGasPriceDisplay = useGasDisplay(maybeUrgentGasPrice);
    const normalBaseFeePerGasDisplay = useGasDisplay(maybeNormalBaseFeePerGas);
    const fastBaseFeePerGasDisplay = useGasDisplay(maybeFastBaseFeePerGas);
    const urgentBaseFeePerGasDisplay = useGasDisplay(maybeUrgentBaseFeePerGas);
    const normalMaxPriorityFeePerGasDisplay = useGasDisplay(maybeNormalMaxPriorityFeePerGas);
    const fastMaxPriorityFeePerGasDisplay = useGasDisplay(maybeFastMaxPriorityFeePerGas);
    const urgentMaxPriorityFeePerGasDisplay = useGasDisplay(maybeUrgentMaxPriorityFeePerGas);
    const [txSign, setTxSign] = (0,react.useState)();
    const [txHash, setTxHash] = (0,react.useState)();
    const onTxSignCopy = (0,copy/* useCopy */.F)(txSign);
    const onTxHashCopy = (0,copy/* useCopy */.F)(txHash);
    const signOrSend = (0,react.useCallback)(async (action)=>{
        try {
            if (maybeIsEip1559 == null) return;
            const target = option_option/* Option */.W.wrap(maybeFinalTarget).okOrElseSync(()=>{
                return new errors/* UIError */.m("Could not parse or fetch address");
            }).unwrap();
            const nonce = option_option/* Option */.W.wrap(maybeFinalNonce).okOrElseSync(()=>{
                return new errors/* UIError */.m("Could not parse or fetch nonce");
            }).unwrap();
            const data = option_option/* Option */.W.wrap(maybeFinalData).okOrElseSync(()=>{
                return new errors/* UIError */.m("Could not encode data");
            }).unwrap();
            const gasLimit = option_option/* Option */.W.wrap(maybeFinalGasLimit).okOrElseSync(()=>{
                return new errors/* UIError */.m("Could not fetch gasLimit");
            }).unwrap();
            let tx;
            /**
             * EIP-1559
             */ if (maybeIsEip1559) {
                const maxFeePerGas = option_option/* Option */.W.wrap(maybeFinalMaxFeePerGas).okOrElseSync(()=>{
                    return new errors/* UIError */.m("Could not fetch baseFeePerGas");
                }).unwrap();
                const maxPriorityFeePerGas = option_option/* Option */.W.wrap(maybeFinalMaxPriorityFeePerGas).okOrElseSync(()=>{
                    return new errors/* UIError */.m("Could not fetch maxPriorityFeePerGas");
                }).unwrap();
                tx = transaction/* Transaction */.Y.from({
                    to: tokenData.address,
                    gasLimit: gasLimit,
                    chainId: chainData.chainId,
                    maxFeePerGas: maxFeePerGas,
                    maxPriorityFeePerGas: maxPriorityFeePerGas,
                    nonce: Number(nonce),
                    data: data
                });
            } else {
                const gasPrice = option_option/* Option */.W.wrap(maybeFinalGasPrice).okOrElseSync(()=>{
                    return new errors/* UIError */.m("Could not fetch gasPrice");
                }).unwrap();
                tx = transaction/* Transaction */.Y.from({
                    to: types_address/* Address */.k.from(target),
                    gasLimit: gasLimit,
                    chainId: chainData.chainId,
                    gasPrice: gasPrice,
                    nonce: Number(nonce),
                    data: data
                });
            }
            const instance = await entities_wallets_data/* EthereumWalletInstance */.Vy.tryFrom(wallet, context.background).then((r)=>r.unwrap());
            const signature = await instance.trySignTransaction(tx, context.background).then((r)=>r.unwrap());
            tx.signature = signature;
            if (action === "sign") {
                setTxSign(tx.serialized);
                setTxHash(undefined);
                return;
            }
            if (action === "send") {
                const txHash = await context.background.tryRequest({
                    method: "brume_eth_fetch",
                    params: [
                        context.uuid,
                        context.chain.chainId,
                        {
                            method: "eth_sendRawTransaction",
                            params: [
                                tx.serialized
                            ],
                            noCheck: true
                        }
                    ]
                }).then((r)=>r.unwrap().unwrap());
                setTxHash(txHash);
                setTxSign(undefined);
                return;
            }
        } catch (e) {
            errors/* Errors */.D.logAndAlert(e);
        }
    }, [
        wallet,
        context,
        chainData,
        tokenData,
        maybeFinalTarget,
        maybeFinalNonce,
        maybeFinalData,
        maybeIsEip1559,
        maybeFinalGasLimit,
        maybeFinalMaxFeePerGas,
        maybeFinalMaxPriorityFeePerGas,
        maybeFinalGasPrice
    ]);
    const onSignClick = (0,callback/* useAsyncUniqueCallback */.T)(async ()=>{
        return await signOrSend("sign");
    }, [
        signOrSend
    ]);
    const onSendClick = (0,callback/* useAsyncUniqueCallback */.T)(async ()=>{
        return await signOrSend("send");
    }, [
        signOrSend
    ]);
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            (_tokenData_pairs = tokenData.pairs) === null || _tokenData_pairs === void 0 ? void 0 : _tokenData_pairs.map((address, i)=>/*#__PURE__*/ (0,jsx_runtime.jsx)(PriceResolver, {
                    index: i,
                    address: address,
                    ok: onTokenPrice
                }, i)),
            (_chainData_token_pairs = chainData.token.pairs) === null || _chainData_token_pairs === void 0 ? void 0 : _chainData_token_pairs.map((address, i)=>/*#__PURE__*/ (0,jsx_runtime.jsx)(PriceResolver, {
                    index: i,
                    address: address,
                    ok: onChainPrice
                }, i)),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(dialog/* Dialog */.Vq.Title, {
                close: close,
                children: [
                    "Send ",
                    tokenData.symbol,
                    " on ",
                    chainData.name
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-4"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(SimpleBox, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "",
                        children: "Target"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-4"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(SimpleInput, {
                        readOnly: true,
                        onFocus: onTargetFocus,
                        value: maybeTarget
                    }, "target")
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-2"
            }),
            mode === "valued" && /*#__PURE__*/ (0,jsx_runtime.jsxs)(SimpleBox, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "",
                        children: "Value"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-4"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "grow flex flex-col overflow-hidden",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "flex items-center",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)(SimpleInput, {
                                        autoFocus: true,
                                        value: rawValueInput,
                                        onChange: onValueInputChange,
                                        placeholder: "0.0"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "w-1"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "text-contrast",
                                        children: tokenData.symbol
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "flex items-center cursor-pointer",
                                role: "button",
                                onClick: onPricedClick,
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "text-contrast truncate",
                                        children: rawPricedInput || "0.0"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "grow"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "text-contrast",
                                        children: "USD"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-2"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "flex items-center",
                        children: [
                            rawValueInput.length === 0 ? /*#__PURE__*/ (0,jsx_runtime.jsx)(ShrinkableNakedButtonInInputBox, {
                                onClick: onValuedPaste,
                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(ClipboardIcon/* default */.Z, {
                                    className: "size-4"
                                })
                            }) : /*#__PURE__*/ (0,jsx_runtime.jsx)(ShrinkableNakedButtonInInputBox, {
                                onClick: onValuedClear,
                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(XMarkIcon/* default */.Z, {
                                    className: "size-4"
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "w-1"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(ShrinkableContrastButtonInInputBox, {
                                disabled: valuedBalanceQuery.data == null,
                                onClick: onValueMaxClick,
                                children: "100%"
                            })
                        ]
                    })
                ]
            }),
            mode === "priced" && /*#__PURE__*/ (0,jsx_runtime.jsxs)(SimpleBox, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "",
                        children: "Value"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-4"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "grow flex flex-col overflow-hidden",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "flex items-center",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)(SimpleInput, {
                                        autoFocus: true,
                                        value: rawPricedInput,
                                        onChange: onPricedInputChange,
                                        placeholder: "0.0"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "w-1"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "text-contrast",
                                        children: "USD"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "flex items-center cursor-pointer",
                                role: "button",
                                onClick: onValuedClick,
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "text-contrast truncate",
                                        children: rawValueInput || "0.0"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "grow"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "text-contrast",
                                        children: tokenData.symbol
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-2"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "flex items-center",
                        children: [
                            rawPricedInput.length === 0 ? /*#__PURE__*/ (0,jsx_runtime.jsx)(ShrinkableNakedButtonInInputBox, {
                                onClick: onPricedPaste,
                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(ClipboardIcon/* default */.Z, {
                                    className: "size-4"
                                })
                            }) : /*#__PURE__*/ (0,jsx_runtime.jsx)(ShrinkableNakedButtonInInputBox, {
                                onClick: onPricedClear,
                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(XMarkIcon/* default */.Z, {
                                    className: "size-4"
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "w-1"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(ShrinkableContrastButtonInInputBox, {
                                disabled: pricedBalanceQuery.data == null,
                                onClick: onPricedMaxClick,
                                children: "100%"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-4"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "font-medium",
                children: "Advanced"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-2"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(SimpleBox, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "",
                        children: "Nonce"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-4"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(SimpleInput, {
                        value: rawNonceInput,
                        onChange: onNonceInputChange,
                        placeholder: maybePendingNonce === null || maybePendingNonce === void 0 ? void 0 : maybePendingNonce.toString()
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-1"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(ShrinkableContrastButtonInInputBox, {
                        onClick: onNonceClick,
                        children: "Select"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-4"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "font-medium",
                children: "Gas"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-2"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(SimpleBox, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "",
                        children: "Gas"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-4"
                    }),
                    maybeIsEip1559 === true && /*#__PURE__*/ (0,jsx_runtime.jsxs)("select", {
                        className: "w-full my-0.5 bg-transparent outline-none",
                        value: gasMode,
                        onChange: onGasModeChange,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("option", {
                                value: "urgent",
                                children: "Urgent — ".concat(urgentBaseFeePerGasDisplay, ":").concat(urgentMaxPriorityFeePerGasDisplay, " Gwei — ").concat(urgentMinEip1559GasCostDisplay, "-").concat(urgentMaxEip1559GasCostDisplay)
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("option", {
                                value: "fast",
                                children: "Fast — ".concat(fastBaseFeePerGasDisplay, ":").concat(fastMaxPriorityFeePerGasDisplay, " Gwei — ").concat(fastMinEip1559GasCostDisplay, "-").concat(fastMaxEip1559GasCostDisplay)
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("option", {
                                value: "normal",
                                children: "Normal — ".concat(normalBaseFeePerGasDisplay, ":").concat(normalMaxPriorityFeePerGasDisplay, " Gwei — ").concat(normalMinEip1559GasCostDisplay, "-").concat(normalMaxEip1559GasCostDisplay)
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("option", {
                                value: "custom",
                                children: "Custom"
                            })
                        ]
                    }),
                    maybeIsEip1559 === false && /*#__PURE__*/ (0,jsx_runtime.jsxs)("select", {
                        className: "w-full my-0.5 bg-transparent outline-none",
                        value: gasMode,
                        onChange: onGasModeChange,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("option", {
                                value: "urgent",
                                children: "Urgent — ".concat(urgentGasPriceDisplay, " Gwei — ").concat(urgentLegacyGasCostDisplay)
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("option", {
                                value: "fast",
                                children: "Fast — ".concat(fastGasPriceDisplay, " Gwei — ").concat(fastLegacyGasCostDisplay)
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("option", {
                                value: "normal",
                                children: "Normal — ".concat(normalGasPriceDisplay, " Gwei — ").concat(normalLegacyGasCostDisplay)
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("option", {
                                value: "custom",
                                children: "Custom"
                            })
                        ]
                    })
                ]
            }),
            gasMode === "custom" && maybeIsEip1559 === false && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-2"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(SimpleBox, {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "",
                                children: "Gas Limit"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "w-4"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(SimpleInput, {
                                value: rawGasLimitInput,
                                onChange: onGasLimitInputChange,
                                placeholder: maybeFetchedGasLimit === null || maybeFetchedGasLimit === void 0 ? void 0 : maybeFetchedGasLimit.toString()
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-2"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(SimpleBox, {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "",
                                children: "Gas Price"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "w-4"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(SimpleInput, {
                                value: rawGasPriceInput,
                                onChange: onGasPriceInputChange,
                                placeholder: maybeFetchedGasPrice === null || maybeFetchedGasPrice === void 0 ? void 0 : maybeFetchedGasPrice.toString()
                            })
                        ]
                    })
                ]
            }),
            gasMode === "custom" && maybeIsEip1559 === true && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-2"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(SimpleBox, {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "",
                                children: "Gas Limit"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "w-4"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(SimpleInput, {
                                value: rawGasLimitInput,
                                onChange: onGasLimitInputChange,
                                placeholder: maybeFetchedGasLimit === null || maybeFetchedGasLimit === void 0 ? void 0 : maybeFetchedGasLimit.toString()
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-2"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(SimpleBox, {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "",
                                children: "Base Fee Per Gas"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "w-4"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(SimpleInput, {
                                value: rawBaseFeePerGasInput,
                                onChange: onBaseFeePerGasInputChange,
                                placeholder: maybeFetchedBaseFeePerGas === null || maybeFetchedBaseFeePerGas === void 0 ? void 0 : maybeFetchedBaseFeePerGas.toString()
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-2"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(SimpleBox, {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "",
                                children: "Max Priority Fee Per Gas"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "w-4"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(SimpleInput, {
                                value: rawMaxPriorityFeePerGasInput,
                                onChange: onMaxPriorityFeePerGasInputChange,
                                placeholder: maybeFetchedMaxPriorityFeePerGas === null || maybeFetchedMaxPriorityFeePerGas === void 0 ? void 0 : maybeFetchedMaxPriorityFeePerGas.toString()
                            })
                        ]
                    })
                ]
            }),
            maybeIsEip1559 === false && maybeFinalLegacyGasCost != null && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-2"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "text-contrast",
                        children: [
                            "This transaction is expected to cost ",
                            finalLegacyGasCostDisplay
                        ]
                    })
                ]
            }),
            maybeIsEip1559 === true && maybeFinalMinEip1559GasCost != null && maybeFinalMaxEip1559GasCost != null && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-2"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "text-contrast",
                        children: [
                            "This transaction is expected to cost ",
                            finalMinEip1559GasCostDisplay,
                            " but can cost up to ",
                            finalMaxEip1559GasCostDisplay
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-4 grow"
            }),
            txSign != null && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "po-md flex items-center bg-contrast rounded-xl",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "flex flex-col truncate",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    className: "flex items-center",
                                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "font-medium",
                                        children: "Transaction signed"
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    className: "text-contrast truncate",
                                    children: txSign
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    className: "h-2"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    className: "flex items-center gap-1",
                                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                                        className: "group px-2 bg-contrast rounded-full outline-none disabled:opacity-50 transition-opacity",
                                        onClick: onTxSignCopy.run,
                                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                            className: "h-full w-full flex items-center justify-center gap-2 group-active:scale-90 transition-transform",
                                            children: [
                                                "Copy",
                                                onTxSignCopy.current ? /*#__PURE__*/ (0,jsx_runtime.jsx)(CheckIcon/* default */.Z, {
                                                    className: "size-4"
                                                }) : /*#__PURE__*/ (0,jsx_runtime.jsx)(ClipboardIcon/* default */.Z, {
                                                    className: "size-4"
                                                })
                                            ]
                                        })
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-2"
                    })
                ]
            }),
            txHash != null && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "po-md flex items-center bg-contrast rounded-xl",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "flex flex-col truncate",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    className: "flex items-center",
                                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "font-medium",
                                        children: "Transaction sent"
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    className: "text-contrast truncate",
                                    children: txHash
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    className: "h-2"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: "flex items-center gap-1",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                                            className: "group px-2 bg-contrast rounded-full outline-none disabled:opacity-50 transition-opacity",
                                            onClick: onTxHashCopy.run,
                                            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                className: "h-full w-full flex items-center justify-center gap-2 group-active:scale-90 transition-transform",
                                                children: [
                                                    "Copy",
                                                    onTxHashCopy.current ? /*#__PURE__*/ (0,jsx_runtime.jsx)(CheckIcon/* default */.Z, {
                                                        className: "size-4"
                                                    }) : /*#__PURE__*/ (0,jsx_runtime.jsx)(ClipboardIcon/* default */.Z, {
                                                        className: "size-4"
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("a", {
                                            className: "group px-2 bg-contrast rounded-full",
                                            target: "_blank",
                                            rel: "noreferrer",
                                            href: "".concat(chainData.etherscan, "/tx/").concat(txHash),
                                            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                className: "h-full w-full flex items-center justify-center gap-2 group-active:scale-90 transition-transform",
                                                children: [
                                                    "Open",
                                                    /*#__PURE__*/ (0,jsx_runtime.jsx)(ArrowTopRightOnSquareIcon/* default */.Z, {
                                                        className: "size-4"
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-2"
                    })
                ]
            }),
            ((_eip1559GasLimitQuery_current1 = eip1559GasLimitQuery.current) === null || _eip1559GasLimitQuery_current1 === void 0 ? void 0 : _eip1559GasLimitQuery_current1.isErr()) && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "po-md flex items-center bg-contrast rounded-xl text-red-500",
                        children: (_eip1559GasLimitQuery_current_get = eip1559GasLimitQuery.current.get()) === null || _eip1559GasLimitQuery_current_get === void 0 ? void 0 : _eip1559GasLimitQuery_current_get.message
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-2"
                    })
                ]
            }),
            ((_legacyGasLimitQuery_current1 = legacyGasLimitQuery.current) === null || _legacyGasLimitQuery_current1 === void 0 ? void 0 : _legacyGasLimitQuery_current1.isErr()) && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "po-md flex items-center bg-contrast rounded-xl text-red-500",
                        children: (_legacyGasLimitQuery_current_get = legacyGasLimitQuery.current.get()) === null || _legacyGasLimitQuery_current_get === void 0 ? void 0 : _legacyGasLimitQuery_current_get.message
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-2"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "flex items-center",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(WideShrinkableContrastButton, {
                        disabled: onSignClick.loading,
                        onClick: onSignClick.run,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(PencilIcon/* default */.Z, {
                                className: "size-5"
                            }),
                            "Sign"
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-2"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(WideShrinkableOppositeButton, {
                        disabled: onSendClick.loading,
                        onClick: onSendClick.run,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(PaperAirplaneIcon/* default */.Z, {
                                className: "size-5"
                            }),
                            "Send"
                        ]
                    })
                ]
            })
        ]
    });
}

;// CONCATENATED MODULE: ./src/mods/foreground/entities/wallets/actions/send/value/native.tsx
























function WalletSendScreenNativeValue(props) {
    var _pendingNonceQuery_current, _valuedBalanceQuery_current, _pricedBalanceQuery_current, _ensTargetQuery_current, _fetchedGasPriceQuery_current, _fetchedMaxPriorityFeePerGasQuery_current, _pendingBlockQuery_current, _legacyGasLimitQuery_current, _eip1559GasLimitQuery_current, _tokenData_pairs, _eip1559GasLimitQuery_current1, _eip1559GasLimitQuery_current_get, _legacyGasLimitQuery_current1, _legacyGasLimitQuery_current_get;
    const wallet = (0,wallets_context/* useWalletDataContext */.zI)().unwrap();
    const { close } = (0,dialog/* useDialogContext */.DA)().unwrap();
    const $state = (0,path_context/* usePathState */.qf)();
    const [maybeStep, setStep] = (0,path_context/* useSearchState */.XN)("step", $state);
    const [maybeChain, setChain] = (0,path_context/* useSearchState */.XN)("chain", $state);
    const [maybeTarget, setTarget] = (0,path_context/* useSearchState */.XN)("target", $state);
    const [maybeValued, setValued] = (0,path_context/* useSearchState */.XN)("valued", $state);
    const [maybePriced, setPriced] = (0,path_context/* useSearchState */.XN)("priced", $state);
    const [maybeNonce, setNonce] = (0,path_context/* useSearchState */.XN)("nonce", $state);
    const [maybeData, setData] = (0,path_context/* useSearchState */.XN)("data", $state);
    const [maybeGasMode, setGasMode] = (0,path_context/* useSearchState */.XN)("gasMode", $state);
    const [maybeGasLimit, setGasLimit] = (0,path_context/* useSearchState */.XN)("gasLimit", $state);
    const [maybeGasPrice, setGasPrice] = (0,path_context/* useSearchState */.XN)("gasPrice", $state);
    const [maybeBaseFeePerGas, setBaseFeePerGas] = (0,path_context/* useSearchState */.XN)("baseFeePerGas", $state);
    const [maybeMaxPriorityFeePerGas, setMaxPriorityFeePerGas] = (0,path_context/* useSearchState */.XN)("maxPriorityFeePerGas", $state);
    const gasMode = option_option/* Option */.W.wrap(maybeGasMode).unwrapOr("normal");
    const chain = option_option/* Option */.W.unwrap(maybeChain);
    const chainData = mods_chain/* chainByChainId */.DH[Number(chain)];
    const tokenData = chainData.token;
    const context = (0,entities_wallets_data/* useEthereumContext2 */.IL)(wallet.uuid, chainData).unwrap();
    const pendingNonceQuery = (0,unknown_data/* useNonce */.XE)(wallet.address, context);
    const maybePendingNonce = (_pendingNonceQuery_current = pendingNonceQuery.current) === null || _pendingNonceQuery_current === void 0 ? void 0 : _pendingNonceQuery_current.ok().get();
    const [tokenPrices, setTokenPrices] = (0,react.useState)(()=>{
        if (tokenData.pairs == null) return;
        return new Array(tokenData.pairs.length);
    });
    const onPrice = (0,react.useCallback)((param)=>{
        let [index, data] = param;
        setTokenPrices((prices)=>{
            if (prices == null) return;
            prices[index] = data;
            return [
                ...prices
            ];
        });
    }, []);
    const maybeTokenPrice = (0,react.useMemo)(()=>{
        if (tokenPrices == null) return;
        return tokenPrices.reduce((a, b)=>{
            if (a == null) return undefined;
            if (b == null) return undefined;
            return a.mul(types_fixed/* Fixed */.g.from(b));
        }, types_fixed/* Fixed */.g.unit(18));
    }, [
        tokenPrices
    ]);
    const maybeChainPrice = maybeTokenPrice;
    const [rawValueInput = "", setRawValueInput] = (0,react.useState)(maybeValued);
    const [rawPricedInput = "", setRawPricedInput] = (0,react.useState)(maybePriced);
    const setValue = (0,react.useCallback)((input)=>{
        try {
            setRawValueInput(input);
            if (input.trim().length === 0) {
                setRawPricedInput(undefined);
                return;
            }
            if (maybeTokenPrice == null) {
                setRawPricedInput(undefined);
                return;
            }
            const priced = types_fixed/* Fixed */.g.fromString(input, tokenData.decimals).mul(maybeTokenPrice);
            if (priced.value === 0n) {
                setRawPricedInput(undefined);
                return;
            }
            setRawPricedInput(priced.toString());
        } catch (e) {
            setRawPricedInput(undefined);
            return;
        }
    }, [
        tokenData,
        maybeTokenPrice
    ]);
    const setPrice = (0,react.useCallback)((input)=>{
        try {
            setRawPricedInput(input);
            if (input.trim().length === 0) {
                setRawValueInput(undefined);
                return;
            }
            if (maybeTokenPrice == null) {
                setRawValueInput(undefined);
                return;
            }
            const valued = types_fixed/* Fixed */.g.fromString(input, tokenData.decimals).div(maybeTokenPrice);
            if (valued.value === 0n) {
                setRawValueInput(undefined);
                return;
            }
            setRawValueInput(valued.toString());
        } catch (e) {
            setRawValueInput(undefined);
            return;
        }
    }, [
        tokenData,
        maybeTokenPrice
    ]);
    const onValueInputChange = (0,events/* useInputChange */.Xy)((e)=>{
        setValue(e.target.value);
    }, [
        setValue
    ]);
    const onPricedInputChange = (0,events/* useInputChange */.Xy)((e)=>{
        setPrice(e.target.value);
    }, [
        setPrice
    ]);
    const valueInput = (0,react.useDeferredValue)(rawValueInput);
    const pricedInput = (0,react.useDeferredValue)(rawPricedInput);
    useEffectButNotFirstTime(()=>{
        setValued(valueInput);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        valueInput
    ]);
    useEffectButNotFirstTime(()=>{
        setPriced(pricedInput);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        pricedInput
    ]);
    const [mode, setMode] = (0,react.useState)("valued");
    const valuedBalanceQuery = useNativeBalance(wallet.address, "pending", context, tokenPrices);
    const pricedBalanceQuery = useNativePricedBalance(wallet.address, "usd", context);
    const valuedBalanceData = (_valuedBalanceQuery_current = valuedBalanceQuery.current) === null || _valuedBalanceQuery_current === void 0 ? void 0 : _valuedBalanceQuery_current.ok().get();
    const pricedBalanceData = (_pricedBalanceQuery_current = pricedBalanceQuery.current) === null || _pricedBalanceQuery_current === void 0 ? void 0 : _pricedBalanceQuery_current.ok().get();
    const onValueMaxClick = (0,react.useCallback)(()=>{
        if (valuedBalanceData == null) return;
        setValue(types_fixed/* Fixed */.g.from(valuedBalanceData).toString());
    }, [
        valuedBalanceData,
        setValue
    ]);
    const onPricedMaxClick = (0,react.useCallback)(()=>{
        if (pricedBalanceData == null) return;
        setPrice(types_fixed/* Fixed */.g.from(pricedBalanceData).toString());
    }, [
        pricedBalanceData,
        setPrice
    ]);
    const onValuedPaste = (0,react.useCallback)(async ()=>{
        setValue(await navigator.clipboard.readText());
    }, [
        setValue
    ]);
    const onPricedPaste = (0,react.useCallback)(async ()=>{
        setPrice(await navigator.clipboard.readText());
    }, [
        setPrice
    ]);
    const onValuedClear = (0,react.useCallback)(async ()=>{
        setValue("");
    }, [
        setValue
    ]);
    const onPricedClear = (0,react.useCallback)(async ()=>{
        setPrice("");
    }, [
        setPrice
    ]);
    const onTargetFocus = (0,react.useCallback)(()=>{
        setStep("target");
    }, [
        setStep
    ]);
    const onNonceClick = (0,react.useCallback)(()=>{
        setStep("nonce");
    }, [
        setStep
    ]);
    const onPricedClick = (0,react.useCallback)(()=>{
        setMode("priced");
    }, []);
    const onValuedClick = (0,react.useCallback)(()=>{
        setMode("valued");
    }, []);
    const mainnet = (0,entities_wallets_data/* useEthereumContext */.Kn)(wallet.uuid, mods_chain/* chainByChainId */.DH[1]);
    const maybeEnsQueryKey = (maybeTarget === null || maybeTarget === void 0 ? void 0 : maybeTarget.endsWith(".eth")) ? maybeTarget : undefined;
    const ensTargetQuery = (0,names_data/* useEnsLookup */.aZ)(maybeEnsQueryKey, mainnet);
    const maybeEnsTarget = (_ensTargetQuery_current = ensTargetQuery.current) === null || _ensTargetQuery_current === void 0 ? void 0 : _ensTargetQuery_current.ok().get();
    const maybeFinalTarget = (0,react.useMemo)(()=>{
        if (maybeTarget == null) return undefined;
        if (types_address/* Address */.k.from(maybeTarget) != null) return maybeTarget;
        if (maybeEnsTarget != null) return maybeEnsTarget;
        return undefined;
    }, [
        maybeTarget,
        maybeEnsTarget
    ]);
    const maybeFinalValue = (0,react.useMemo)(()=>{
        try {
            return (maybeValued === null || maybeValued === void 0 ? void 0 : maybeValued.trim().length) ? types_fixed/* Fixed */.g.fromString(maybeValued.trim(), tokenData.decimals) : new types_fixed/* Fixed */.g(0n, tokenData.decimals);
        } catch (e) {}
    }, [
        maybeValued,
        tokenData
    ]);
    const [rawNonceInput = "", setRawNonceInput] = (0,react.useState)(maybeNonce);
    const onNonceInputChange = (0,events/* useInputChange */.Xy)((e)=>{
        setRawNonceInput(e.target.value);
    }, []);
    const nonceInput = (0,react.useDeferredValue)(rawNonceInput);
    useEffectButNotFirstTime(()=>{
        setNonce(nonceInput);
    }, [
        nonceInput
    ]);
    const maybeCustomNonce = (0,react.useMemo)(()=>{
        try {
            return (maybeNonce === null || maybeNonce === void 0 ? void 0 : maybeNonce.trim().length) ? BigInt(maybeNonce.trim()) : undefined;
        } catch (e) {}
    }, [
        maybeNonce
    ]);
    const maybeFinalNonce = (0,react.useMemo)(()=>{
        if (maybeCustomNonce != null) return maybeCustomNonce;
        if (maybePendingNonce != null) return maybePendingNonce;
        return undefined;
    }, [
        maybeCustomNonce,
        maybePendingNonce
    ]);
    const [rawDataInput = "", setRawDataInput] = (0,react.useState)(maybeData);
    const onDataInputChange = (0,events/* useTextAreaChange */.aN)((e)=>{
        setRawDataInput(e.target.value);
    }, []);
    const dataInput = (0,react.useDeferredValue)(rawDataInput);
    useEffectButNotFirstTime(()=>{
        setData(dataInput);
    }, [
        dataInput
    ]);
    const triedFinalData = (0,react.useMemo)(()=>{
        if (!(maybeData === null || maybeData === void 0 ? void 0 : maybeData.trim().length)) return new ok.Ok(undefined);
        return result/* Result */.x.runAndWrapSync(()=>zerohex/* ZeroHexString */.T.from(maybeData.trim()));
    }, [
        maybeData
    ]);
    const onGasModeChange = (0,react.useCallback)((e)=>{
        setGasMode(e.currentTarget.value);
    }, [
        setGasMode
    ]);
    const fetchedGasPriceQuery = (0,unknown_data/* useGasPrice */.Fh)(context);
    const maybeFetchedGasPrice = (_fetchedGasPriceQuery_current = fetchedGasPriceQuery.current) === null || _fetchedGasPriceQuery_current === void 0 ? void 0 : _fetchedGasPriceQuery_current.ok().get();
    const fetchedMaxPriorityFeePerGasQuery = (0,unknown_data/* useMaxPriorityFeePerGas */.hy)(context);
    const maybeFetchedMaxPriorityFeePerGas = (_fetchedMaxPriorityFeePerGasQuery_current = fetchedMaxPriorityFeePerGasQuery.current) === null || _fetchedMaxPriorityFeePerGasQuery_current === void 0 ? void 0 : _fetchedMaxPriorityFeePerGasQuery_current.ok().get();
    const pendingBlockQuery = useBlockByNumber("pending", context);
    const maybePendingBlock = (_pendingBlockQuery_current = pendingBlockQuery.current) === null || _pendingBlockQuery_current === void 0 ? void 0 : _pendingBlockQuery_current.ok().get();
    const maybeFetchedBaseFeePerGas = (0,react.useMemo)(()=>{
        try {
            return (maybePendingBlock === null || maybePendingBlock === void 0 ? void 0 : maybePendingBlock.baseFeePerGas) != null ? bigints/* BigIntToHex */.W.decodeOrThrow(maybePendingBlock.baseFeePerGas) : undefined;
        } catch (e) {}
    }, [
        maybePendingBlock
    ]);
    const maybeIsEip1559 = (0,react.useMemo)(()=>{
        return (maybePendingBlock === null || maybePendingBlock === void 0 ? void 0 : maybePendingBlock.baseFeePerGas) != null;
    }, [
        maybePendingBlock
    ]);
    const [rawGasLimitInput = "", setRawGasLimitInput] = (0,react.useState)(maybeGasLimit);
    const onGasLimitInputChange = (0,events/* useInputChange */.Xy)((e)=>{
        setRawGasLimitInput(e.target.value);
    }, []);
    const gasLimitInput = (0,react.useDeferredValue)(rawGasLimitInput);
    useEffectButNotFirstTime(()=>{
        setGasLimit(gasLimitInput);
    }, [
        gasLimitInput
    ]);
    const [rawGasPriceInput = "", setRawGasPriceInput] = (0,react.useState)(maybeGasPrice);
    const onGasPriceInputChange = (0,events/* useInputChange */.Xy)((e)=>{
        setRawGasPriceInput(e.target.value);
    }, []);
    const gasPriceInput = (0,react.useDeferredValue)(rawGasPriceInput);
    useEffectButNotFirstTime(()=>{
        setGasPrice(gasPriceInput);
    }, [
        gasPriceInput
    ]);
    const [rawBaseFeePerGasInput = "", setRawBaseFeePerGasInput] = (0,react.useState)(maybeBaseFeePerGas);
    const onBaseFeePerGasInputChange = (0,events/* useInputChange */.Xy)((e)=>{
        setRawBaseFeePerGasInput(e.target.value);
    }, []);
    const baseFeePerGasInput = (0,react.useDeferredValue)(rawBaseFeePerGasInput);
    useEffectButNotFirstTime(()=>{
        setBaseFeePerGas(baseFeePerGasInput);
    }, [
        baseFeePerGasInput
    ]);
    const [rawMaxPriorityFeePerGasInput = "", setRawMaxPriorityFeePerGasInput] = (0,react.useState)(maybeMaxPriorityFeePerGas);
    const onMaxPriorityFeePerGasInputChange = (0,events/* useInputChange */.Xy)((e)=>{
        setRawMaxPriorityFeePerGasInput(e.target.value);
    }, []);
    const maxPriorityFeePerGasInput = (0,react.useDeferredValue)(rawMaxPriorityFeePerGasInput);
    useEffectButNotFirstTime(()=>{
        setMaxPriorityFeePerGas(maxPriorityFeePerGasInput);
    }, [
        maxPriorityFeePerGasInput
    ]);
    function useMaybeMemo(f, param) {
        let [x] = param;
        return (0,react.useMemo)(()=>{
            if (x == null) return undefined;
            return f(x);
        // eslint-disable-next-line react-hooks/exhaustive-deps
        }, [
            x
        ]);
    }
    const maybeNormalBaseFeePerGas = useMaybeMemo((baseFeePerGas)=>{
        return baseFeePerGas;
    }, [
        maybeFetchedBaseFeePerGas
    ]);
    const maybeFastBaseFeePerGas = useMaybeMemo((baseFeePerGas)=>{
        return baseFeePerGas + 1n * 10n ** 9n;
    }, [
        maybeFetchedBaseFeePerGas
    ]);
    const maybeUrgentBaseFeePerGas = useMaybeMemo((baseFeePerGas)=>{
        return baseFeePerGas + 2n * 10n ** 9n;
    }, [
        maybeFetchedBaseFeePerGas
    ]);
    const maybeCustomBaseFeePerGas = (0,react.useMemo)(()=>{
        try {
            return (maybeBaseFeePerGas === null || maybeBaseFeePerGas === void 0 ? void 0 : maybeBaseFeePerGas.trim().length) ? BigInt(maybeBaseFeePerGas.trim()) : maybeNormalBaseFeePerGas;
        } catch (e) {}
    }, [
        maybeBaseFeePerGas,
        maybeNormalBaseFeePerGas
    ]);
    const maybeNormalMaxPriorityFeePerGas = useMaybeMemo((maxPriorityFeePerGas)=>{
        return maxPriorityFeePerGas / 4n;
    }, [
        maybeFetchedMaxPriorityFeePerGas
    ]);
    const maybeFastMaxPriorityFeePerGas = useMaybeMemo((maxPriorityFeePerGas)=>{
        return maxPriorityFeePerGas / 2n;
    }, [
        maybeFetchedMaxPriorityFeePerGas
    ]);
    const maybeUrgentMaxPriorityFeePerGas = useMaybeMemo((maxPriorityFeePerGas)=>{
        return maxPriorityFeePerGas;
    }, [
        maybeFetchedMaxPriorityFeePerGas
    ]);
    const maybeCustomMaxPriorityFeePerGas = (0,react.useMemo)(()=>{
        try {
            return (maybeMaxPriorityFeePerGas === null || maybeMaxPriorityFeePerGas === void 0 ? void 0 : maybeMaxPriorityFeePerGas.trim().length) ? BigInt(maybeMaxPriorityFeePerGas.trim()) : maybeNormalMaxPriorityFeePerGas;
        } catch (e) {}
    }, [
        maybeMaxPriorityFeePerGas,
        maybeNormalMaxPriorityFeePerGas
    ]);
    const maybeNormalGasPrice = useMaybeMemo((gasPrice)=>{
        return gasPrice;
    }, [
        maybeFetchedGasPrice
    ]);
    const maybeFastGasPrice = useMaybeMemo((gasPrice)=>{
        return gasPrice * 110n / 100n;
    }, [
        maybeFetchedGasPrice
    ]);
    const maybeUrgentGasPrice = useMaybeMemo((gasPrice)=>{
        return gasPrice * 120n / 100n;
    }, [
        maybeFetchedGasPrice
    ]);
    const maybeCustomGasPrice = (0,react.useMemo)(()=>{
        try {
            return (maybeGasPrice === null || maybeGasPrice === void 0 ? void 0 : maybeGasPrice.trim().length) ? BigInt(maybeGasPrice.trim()) : maybeNormalGasPrice;
        } catch (e) {}
    }, [
        maybeGasPrice,
        maybeNormalGasPrice
    ]);
    const maybeNormalMinFeePerGas = (0,react.useMemo)(()=>{
        if (maybeNormalBaseFeePerGas == null) return undefined;
        if (maybeNormalMaxPriorityFeePerGas == null) return undefined;
        return maybeNormalBaseFeePerGas + maybeNormalMaxPriorityFeePerGas;
    }, [
        maybeNormalBaseFeePerGas,
        maybeNormalMaxPriorityFeePerGas
    ]);
    const maybeFastMinFeePerGas = (0,react.useMemo)(()=>{
        if (maybeFastBaseFeePerGas == null) return undefined;
        if (maybeFastMaxPriorityFeePerGas == null) return undefined;
        return maybeFastBaseFeePerGas + maybeFastMaxPriorityFeePerGas;
    }, [
        maybeFastBaseFeePerGas,
        maybeFastMaxPriorityFeePerGas
    ]);
    const maybeUrgentMinFeePerGas = (0,react.useMemo)(()=>{
        if (maybeUrgentBaseFeePerGas == null) return undefined;
        if (maybeUrgentMaxPriorityFeePerGas == null) return undefined;
        return maybeUrgentBaseFeePerGas + maybeUrgentMaxPriorityFeePerGas;
    }, [
        maybeUrgentBaseFeePerGas,
        maybeUrgentMaxPriorityFeePerGas
    ]);
    const maybeCustomMinFeePerGas = (0,react.useMemo)(()=>{
        if (maybeCustomBaseFeePerGas == null) return undefined;
        if (maybeCustomMaxPriorityFeePerGas == null) return undefined;
        return maybeCustomBaseFeePerGas + maybeCustomMaxPriorityFeePerGas;
    }, [
        maybeCustomBaseFeePerGas,
        maybeCustomMaxPriorityFeePerGas
    ]);
    const maybeNormalMaxFeePerGas = (0,react.useMemo)(()=>{
        if (maybeNormalBaseFeePerGas == null) return undefined;
        if (maybeNormalMaxPriorityFeePerGas == null) return undefined;
        return maybeNormalBaseFeePerGas * 2n + maybeNormalMaxPriorityFeePerGas;
    }, [
        maybeNormalBaseFeePerGas,
        maybeNormalMaxPriorityFeePerGas
    ]);
    const maybeFastMaxFeePerGas = (0,react.useMemo)(()=>{
        if (maybeFastBaseFeePerGas == null) return undefined;
        if (maybeFastMaxPriorityFeePerGas == null) return undefined;
        return maybeFastBaseFeePerGas * 2n + maybeFastMaxPriorityFeePerGas;
    }, [
        maybeFastBaseFeePerGas,
        maybeFastMaxPriorityFeePerGas
    ]);
    const maybeUrgentMaxFeePerGas = (0,react.useMemo)(()=>{
        if (maybeUrgentBaseFeePerGas == null) return undefined;
        if (maybeUrgentMaxPriorityFeePerGas == null) return undefined;
        return maybeUrgentBaseFeePerGas * 2n + maybeUrgentMaxPriorityFeePerGas;
    }, [
        maybeUrgentBaseFeePerGas,
        maybeUrgentMaxPriorityFeePerGas
    ]);
    const maybeCustomMaxFeePerGas = (0,react.useMemo)(()=>{
        if (maybeCustomBaseFeePerGas == null) return undefined;
        if (maybeCustomMaxPriorityFeePerGas == null) return undefined;
        return maybeCustomBaseFeePerGas * 2n + maybeCustomMaxPriorityFeePerGas;
    }, [
        maybeCustomBaseFeePerGas,
        maybeCustomMaxPriorityFeePerGas
    ]);
    function useMode(normal, fast, urgent, custom) {
        return (0,react.useMemo)(()=>{
            if (gasMode === "normal") return normal;
            if (gasMode === "fast") return fast;
            if (gasMode === "urgent") return urgent;
            if (gasMode === "custom") return custom;
            return undefined;
        // eslint-disable-next-line react-hooks/exhaustive-deps
        }, [
            gasMode,
            normal,
            fast,
            urgent,
            custom
        ]);
    }
    function useGasDisplay(gasPrice) {
        return (0,react.useMemo)(()=>{
            if (gasPrice == null) return "???";
            return Number(new types_fixed/* Fixed */.g(gasPrice, 9).move(4).toString()).toLocaleString(undefined, {
                maximumSignificantDigits: 2
            });
        }, [
            gasPrice
        ]);
    }
    function useCompactUsdDisplay(fixed) {
        return (0,react.useMemo)(()=>{
            if (fixed == null) return "???";
            return Number(fixed.move(2).toString()).toLocaleString(undefined, {
                style: "currency",
                currency: "USD",
                notation: "compact"
            });
        }, [
            fixed
        ]);
    }
    const maybeFinalGasPrice = useMode(maybeNormalGasPrice, maybeFastGasPrice, maybeUrgentGasPrice, maybeCustomGasPrice);
    const maybeFinalMaxFeePerGas = useMode(maybeNormalMaxFeePerGas, maybeFastMaxFeePerGas, maybeUrgentMaxFeePerGas, maybeCustomMaxFeePerGas);
    const maybeFinalMaxPriorityFeePerGas = useMode(maybeNormalMaxPriorityFeePerGas, maybeFastMaxPriorityFeePerGas, maybeUrgentMaxPriorityFeePerGas, maybeCustomMaxPriorityFeePerGas);
    const maybeLegacyGasLimitKey = (0,react.useMemo)(()=>{
        if (maybeIsEip1559 !== false) return undefined;
        if (maybeFinalTarget == null) return undefined;
        if (maybeFinalValue == null) return undefined;
        if (maybeFinalNonce == null) return undefined;
        if (maybeFinalGasPrice == null) return undefined;
        if (triedFinalData.isErr()) return undefined;
        return {
            method: "eth_estimateGas",
            params: [
                {
                    chainId: zerohex/* ZeroHexString */.T.from(chainData.chainId),
                    from: wallet.address,
                    to: maybeFinalTarget,
                    gasPrice: zerohex/* ZeroHexString */.T.from(maybeFinalGasPrice),
                    value: zerohex/* ZeroHexString */.T.from(maybeFinalValue.value),
                    nonce: zerohex/* ZeroHexString */.T.from(maybeFinalNonce),
                    data: triedFinalData.get()
                },
                "latest"
            ]
        };
    }, [
        wallet,
        chainData,
        maybeIsEip1559,
        maybeFinalTarget,
        maybeFinalValue,
        maybeFinalNonce,
        triedFinalData,
        maybeFinalGasPrice
    ]);
    const maybeEip1559GasLimitKey = (0,react.useMemo)(()=>{
        if (maybeIsEip1559 !== true) return undefined;
        if (maybeFinalTarget == null) return undefined;
        if (maybeFinalValue == null) return undefined;
        if (maybeFinalNonce == null) return undefined;
        if (maybeFinalMaxFeePerGas == null) return undefined;
        if (maybeFinalMaxPriorityFeePerGas == null) return undefined;
        if (triedFinalData.isErr()) return undefined;
        return {
            method: "eth_estimateGas",
            params: [
                {
                    chainId: zerohex/* ZeroHexString */.T.from(chainData.chainId),
                    from: wallet.address,
                    to: maybeFinalTarget,
                    maxFeePerGas: zerohex/* ZeroHexString */.T.from(maybeFinalMaxFeePerGas),
                    maxPriorityFeePerGas: zerohex/* ZeroHexString */.T.from(maybeFinalMaxPriorityFeePerGas),
                    value: zerohex/* ZeroHexString */.T.from(maybeFinalValue.value),
                    nonce: zerohex/* ZeroHexString */.T.from(maybeFinalNonce),
                    data: triedFinalData.get()
                },
                "latest"
            ]
        };
    }, [
        wallet,
        chainData,
        maybeIsEip1559,
        maybeFinalTarget,
        maybeFinalValue,
        maybeFinalNonce,
        triedFinalData,
        maybeFinalMaxFeePerGas,
        maybeFinalMaxPriorityFeePerGas
    ]);
    const legacyGasLimitQuery = (0,unknown_data/* useEstimateGas */.Nh)(maybeLegacyGasLimitKey, context);
    const maybeLegacyGasLimit = (_legacyGasLimitQuery_current = legacyGasLimitQuery.current) === null || _legacyGasLimitQuery_current === void 0 ? void 0 : _legacyGasLimitQuery_current.ok().get();
    const eip1559GasLimitQuery = (0,unknown_data/* useEstimateGas */.Nh)(maybeEip1559GasLimitKey, context);
    const maybeEip1559GasLimit = (_eip1559GasLimitQuery_current = eip1559GasLimitQuery.current) === null || _eip1559GasLimitQuery_current === void 0 ? void 0 : _eip1559GasLimitQuery_current.ok().get();
    const maybeFetchedGasLimit = (0,react.useMemo)(()=>{
        if (maybeIsEip1559 == null) return undefined;
        if (maybeLegacyGasLimit != null) return maybeLegacyGasLimit;
        if (maybeEip1559GasLimit != null) return maybeEip1559GasLimit;
        return undefined;
    }, [
        maybeIsEip1559,
        maybeLegacyGasLimit,
        maybeEip1559GasLimit
    ]);
    const maybeCustomGasLimit = (0,react.useMemo)(()=>{
        try {
            return (maybeGasLimit === null || maybeGasLimit === void 0 ? void 0 : maybeGasLimit.trim().length) ? BigInt(maybeGasLimit.trim()) : maybeFetchedGasLimit;
        } catch (e) {}
    }, [
        maybeGasLimit,
        maybeFetchedGasLimit
    ]);
    const maybeFinalGasLimit = (0,react.useMemo)(()=>{
        if (gasMode === "custom") return maybeCustomGasLimit;
        return maybeFetchedGasLimit;
    }, [
        gasMode,
        maybeCustomGasLimit,
        maybeFetchedGasLimit
    ]);
    const maybeNormalLegacyGasCost = (0,react.useMemo)(()=>{
        if (maybeLegacyGasLimit == null) return undefined;
        if (maybeNormalGasPrice == null) return undefined;
        if (maybeChainPrice == null) return undefined;
        return new types_fixed/* Fixed */.g(maybeLegacyGasLimit * maybeNormalGasPrice, 18).mul(maybeChainPrice);
    }, [
        maybeLegacyGasLimit,
        maybeNormalGasPrice,
        maybeChainPrice
    ]);
    const maybeFastLegacyGasCost = (0,react.useMemo)(()=>{
        if (maybeLegacyGasLimit == null) return undefined;
        if (maybeFastGasPrice == null) return undefined;
        if (maybeChainPrice == null) return undefined;
        return new types_fixed/* Fixed */.g(maybeLegacyGasLimit * maybeFastGasPrice, 18).mul(maybeChainPrice);
    }, [
        maybeLegacyGasLimit,
        maybeFastGasPrice,
        maybeChainPrice
    ]);
    const maybeUrgentLegacyGasCost = (0,react.useMemo)(()=>{
        if (maybeLegacyGasLimit == null) return undefined;
        if (maybeUrgentGasPrice == null) return undefined;
        if (maybeChainPrice == null) return undefined;
        return new types_fixed/* Fixed */.g(maybeLegacyGasLimit * maybeUrgentGasPrice, 18).mul(maybeChainPrice);
    }, [
        maybeLegacyGasLimit,
        maybeUrgentGasPrice,
        maybeChainPrice
    ]);
    const maybeCustomLegacyGasCost = (0,react.useMemo)(()=>{
        if (maybeCustomGasLimit == null) return undefined;
        if (maybeCustomGasPrice == null) return undefined;
        if (maybeChainPrice == null) return undefined;
        return new types_fixed/* Fixed */.g(maybeCustomGasLimit * maybeCustomGasPrice, 18).mul(maybeChainPrice);
    }, [
        maybeCustomGasLimit,
        maybeCustomGasPrice,
        maybeChainPrice
    ]);
    const maybeNormalMinEip1559GasCost = (0,react.useMemo)(()=>{
        if (maybeEip1559GasLimit == null) return undefined;
        if (maybeNormalMinFeePerGas == null) return undefined;
        if (maybeChainPrice == null) return undefined;
        return new types_fixed/* Fixed */.g(maybeEip1559GasLimit * maybeNormalMinFeePerGas, 18).mul(maybeChainPrice);
    }, [
        maybeEip1559GasLimit,
        maybeNormalMinFeePerGas,
        maybeChainPrice
    ]);
    const maybeFastMinEip1559GasCost = (0,react.useMemo)(()=>{
        if (maybeEip1559GasLimit == null) return undefined;
        if (maybeFastMinFeePerGas == null) return undefined;
        if (maybeChainPrice == null) return undefined;
        return new types_fixed/* Fixed */.g(maybeEip1559GasLimit * maybeFastMinFeePerGas, 18).mul(maybeChainPrice);
    }, [
        maybeEip1559GasLimit,
        maybeFastMinFeePerGas,
        maybeChainPrice
    ]);
    const maybeUrgentMinEip1559GasCost = (0,react.useMemo)(()=>{
        if (maybeEip1559GasLimit == null) return undefined;
        if (maybeUrgentMinFeePerGas == null) return undefined;
        if (maybeChainPrice == null) return undefined;
        return new types_fixed/* Fixed */.g(maybeEip1559GasLimit * maybeUrgentMinFeePerGas, 18).mul(maybeChainPrice);
    }, [
        maybeEip1559GasLimit,
        maybeUrgentMinFeePerGas,
        maybeChainPrice
    ]);
    const maybeCustomMinEip1559GasCost = (0,react.useMemo)(()=>{
        if (maybeCustomGasLimit == null) return undefined;
        if (maybeCustomMinFeePerGas == null) return undefined;
        if (maybeChainPrice == null) return undefined;
        return new types_fixed/* Fixed */.g(maybeCustomGasLimit * maybeCustomMinFeePerGas, 18).mul(maybeChainPrice);
    }, [
        maybeCustomGasLimit,
        maybeCustomMinFeePerGas,
        maybeChainPrice
    ]);
    const maybeNormalMaxEip1559GasCost = (0,react.useMemo)(()=>{
        if (maybeEip1559GasLimit == null) return undefined;
        if (maybeNormalMaxFeePerGas == null) return undefined;
        if (maybeChainPrice == null) return undefined;
        return new types_fixed/* Fixed */.g(maybeEip1559GasLimit * maybeNormalMaxFeePerGas, 18).mul(maybeChainPrice);
    }, [
        maybeEip1559GasLimit,
        maybeNormalMaxFeePerGas,
        maybeChainPrice
    ]);
    const maybeFastMaxEip1559GasCost = (0,react.useMemo)(()=>{
        if (maybeEip1559GasLimit == null) return undefined;
        if (maybeFastMaxFeePerGas == null) return undefined;
        if (maybeChainPrice == null) return undefined;
        return new types_fixed/* Fixed */.g(maybeEip1559GasLimit * maybeFastMaxFeePerGas, 18).mul(maybeChainPrice);
    }, [
        maybeEip1559GasLimit,
        maybeFastMaxFeePerGas,
        maybeChainPrice
    ]);
    const maybeUrgentMaxEip1559GasCost = (0,react.useMemo)(()=>{
        if (maybeEip1559GasLimit == null) return undefined;
        if (maybeUrgentMaxFeePerGas == null) return undefined;
        if (maybeChainPrice == null) return undefined;
        return new types_fixed/* Fixed */.g(maybeEip1559GasLimit * maybeUrgentMaxFeePerGas, 18).mul(maybeChainPrice);
    }, [
        maybeEip1559GasLimit,
        maybeUrgentMaxFeePerGas,
        maybeChainPrice
    ]);
    const maybeCustomMaxEip1559GasCost = (0,react.useMemo)(()=>{
        if (maybeCustomGasLimit == null) return undefined;
        if (maybeCustomMaxFeePerGas == null) return undefined;
        if (maybeChainPrice == null) return undefined;
        return new types_fixed/* Fixed */.g(maybeCustomGasLimit * maybeCustomMaxFeePerGas, 18).mul(maybeChainPrice);
    }, [
        maybeCustomGasLimit,
        maybeCustomMaxFeePerGas,
        maybeChainPrice
    ]);
    const maybeFinalLegacyGasCost = useMode(maybeNormalLegacyGasCost, maybeFastLegacyGasCost, maybeUrgentLegacyGasCost, maybeCustomLegacyGasCost);
    const maybeFinalMinEip1559GasCost = useMode(maybeNormalMinEip1559GasCost, maybeFastMinEip1559GasCost, maybeUrgentMinEip1559GasCost, maybeCustomMinEip1559GasCost);
    const maybeFinalMaxEip1559GasCost = useMode(maybeNormalMaxEip1559GasCost, maybeFastMaxEip1559GasCost, maybeUrgentMaxEip1559GasCost, maybeCustomMaxEip1559GasCost);
    const normalLegacyGasCostDisplay = useCompactUsdDisplay(maybeNormalLegacyGasCost);
    const fastLegacyGasCostDisplay = useCompactUsdDisplay(maybeFastLegacyGasCost);
    const urgentLegacyGasCostDisplay = useCompactUsdDisplay(maybeUrgentLegacyGasCost);
    const finalLegacyGasCostDisplay = useCompactUsdDisplay(maybeFinalLegacyGasCost);
    const normalMinEip1559GasCostDisplay = useCompactUsdDisplay(maybeNormalMinEip1559GasCost);
    const fastMinEip1559GasCostDisplay = useCompactUsdDisplay(maybeFastMinEip1559GasCost);
    const urgentMinEip1559GasCostDisplay = useCompactUsdDisplay(maybeUrgentMinEip1559GasCost);
    const finalMinEip1559GasCostDisplay = useCompactUsdDisplay(maybeFinalMinEip1559GasCost);
    const normalMaxEip1559GasCostDisplay = useCompactUsdDisplay(maybeNormalMaxEip1559GasCost);
    const fastMaxEip1559GasCostDisplay = useCompactUsdDisplay(maybeFastMaxEip1559GasCost);
    const urgentMaxEip1559GasCostDisplay = useCompactUsdDisplay(maybeUrgentMaxEip1559GasCost);
    const finalMaxEip1559GasCostDisplay = useCompactUsdDisplay(maybeFinalMaxEip1559GasCost);
    const normalGasPriceDisplay = useGasDisplay(maybeNormalGasPrice);
    const fastGasPriceDisplay = useGasDisplay(maybeFastGasPrice);
    const urgentGasPriceDisplay = useGasDisplay(maybeUrgentGasPrice);
    const normalBaseFeePerGasDisplay = useGasDisplay(maybeNormalBaseFeePerGas);
    const fastBaseFeePerGasDisplay = useGasDisplay(maybeFastBaseFeePerGas);
    const urgentBaseFeePerGasDisplay = useGasDisplay(maybeUrgentBaseFeePerGas);
    const normalMaxPriorityFeePerGasDisplay = useGasDisplay(maybeNormalMaxPriorityFeePerGas);
    const fastMaxPriorityFeePerGasDisplay = useGasDisplay(maybeFastMaxPriorityFeePerGas);
    const urgentMaxPriorityFeePerGasDisplay = useGasDisplay(maybeUrgentMaxPriorityFeePerGas);
    const [txSign, setTxSign] = (0,react.useState)();
    const [txHash, setTxHash] = (0,react.useState)();
    const onTxSignCopy = (0,copy/* useCopy */.F)(txSign);
    const onTxHashCopy = (0,copy/* useCopy */.F)(txHash);
    const signOrSend = (0,react.useCallback)(async (action)=>{
        try {
            if (maybeIsEip1559 == null) return;
            const target = option_option/* Option */.W.wrap(maybeFinalTarget).okOrElseSync(()=>{
                return new errors/* UIError */.m("Could not parse or fetch address");
            }).unwrap();
            const value = option_option/* Option */.W.wrap(maybeFinalValue).okOrElseSync(()=>{
                return new errors/* UIError */.m("Could not parse value");
            }).unwrap();
            const nonce = option_option/* Option */.W.wrap(maybeFinalNonce).okOrElseSync(()=>{
                return new errors/* UIError */.m("Could not parse or fetch nonce");
            }).unwrap();
            const data = triedFinalData.mapErrSync(()=>{
                return new errors/* UIError */.m("Could not parse data");
            }).unwrap();
            const gasLimit = option_option/* Option */.W.wrap(maybeFinalGasLimit).okOrElseSync(()=>{
                return new errors/* UIError */.m("Could not fetch gasLimit");
            }).unwrap();
            let tx;
            /**
             * EIP-1559
             */ if (maybeIsEip1559) {
                const maxFeePerGas = option_option/* Option */.W.wrap(maybeFinalMaxFeePerGas).okOrElseSync(()=>{
                    return new errors/* UIError */.m("Could not fetch baseFeePerGas");
                }).unwrap();
                const maxPriorityFeePerGas = option_option/* Option */.W.wrap(maybeFinalMaxPriorityFeePerGas).okOrElseSync(()=>{
                    return new errors/* UIError */.m("Could not fetch maxPriorityFeePerGas");
                }).unwrap();
                tx = transaction/* Transaction */.Y.from({
                    to: types_address/* Address */.k.from(target),
                    gasLimit: gasLimit,
                    chainId: chainData.chainId,
                    maxFeePerGas: maxFeePerGas,
                    maxPriorityFeePerGas: maxPriorityFeePerGas,
                    nonce: Number(nonce),
                    value: value.value,
                    data: data
                });
            } else {
                const gasPrice = option_option/* Option */.W.wrap(maybeFinalGasPrice).okOrElseSync(()=>{
                    return new errors/* UIError */.m("Could not fetch gasPrice");
                }).unwrap();
                tx = transaction/* Transaction */.Y.from({
                    to: types_address/* Address */.k.from(target),
                    gasLimit: gasLimit,
                    chainId: chainData.chainId,
                    gasPrice: gasPrice,
                    nonce: Number(nonce),
                    value: value.value,
                    data: data
                });
            }
            const instance = await entities_wallets_data/* EthereumWalletInstance */.Vy.tryFrom(wallet, context.background).then((r)=>r.unwrap());
            const signature = await instance.trySignTransaction(tx, context.background).then((r)=>r.unwrap());
            tx.signature = signature;
            if (action === "sign") {
                setTxSign(tx.serialized);
                setTxHash(undefined);
                return;
            }
            if (action === "send") {
                const txHash = await context.background.tryRequest({
                    method: "brume_eth_fetch",
                    params: [
                        context.uuid,
                        context.chain.chainId,
                        {
                            method: "eth_sendRawTransaction",
                            params: [
                                tx.serialized
                            ],
                            noCheck: true
                        }
                    ]
                }).then((r)=>r.unwrap().unwrap());
                setTxHash(txHash);
                setTxSign(undefined);
                return;
            }
        } catch (e) {
            errors/* Errors */.D.logAndAlert(e);
        }
    }, [
        wallet,
        context,
        chainData,
        maybeFinalTarget,
        maybeFinalValue,
        maybeFinalNonce,
        triedFinalData,
        maybeIsEip1559,
        maybeFinalGasLimit,
        maybeFinalMaxFeePerGas,
        maybeFinalMaxPriorityFeePerGas,
        maybeFinalGasPrice
    ]);
    const onSignClick = (0,callback/* useAsyncUniqueCallback */.T)(async ()=>{
        return await signOrSend("sign");
    }, [
        signOrSend
    ]);
    const onSendClick = (0,callback/* useAsyncUniqueCallback */.T)(async ()=>{
        return await signOrSend("send");
    }, [
        signOrSend
    ]);
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            (_tokenData_pairs = tokenData.pairs) === null || _tokenData_pairs === void 0 ? void 0 : _tokenData_pairs.map((address, i)=>/*#__PURE__*/ (0,jsx_runtime.jsx)(PriceResolver, {
                    index: i,
                    address: address,
                    ok: onPrice
                }, i)),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(dialog/* Dialog */.Vq.Title, {
                close: close,
                children: [
                    "Send ",
                    tokenData.symbol,
                    " on ",
                    chainData.name
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-4"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(SimpleBox, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "",
                        children: "Target"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-4"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(SimpleInput, {
                        readOnly: true,
                        onFocus: onTargetFocus,
                        value: maybeTarget
                    }, "target")
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-2"
            }),
            mode === "valued" && /*#__PURE__*/ (0,jsx_runtime.jsxs)(SimpleBox, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "",
                        children: "Value"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-4"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "grow flex flex-col overflow-hidden",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "flex items-center",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)(SimpleInput, {
                                        autoFocus: true,
                                        value: rawValueInput,
                                        onChange: onValueInputChange,
                                        placeholder: "0.0"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "w-1"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "text-contrast",
                                        children: tokenData.symbol
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "flex items-center cursor-pointer",
                                role: "button",
                                onClick: onPricedClick,
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "text-contrast truncate",
                                        children: rawPricedInput || "0.0"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "grow"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "text-contrast",
                                        children: "USD"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-2"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "flex items-center",
                        children: [
                            rawValueInput.length === 0 ? /*#__PURE__*/ (0,jsx_runtime.jsx)(ShrinkableNakedButtonInInputBox, {
                                onClick: onValuedPaste,
                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(ClipboardIcon/* default */.Z, {
                                    className: "size-4"
                                })
                            }) : /*#__PURE__*/ (0,jsx_runtime.jsx)(ShrinkableNakedButtonInInputBox, {
                                onClick: onValuedClear,
                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(XMarkIcon/* default */.Z, {
                                    className: "size-4"
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "w-1"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(ShrinkableContrastButtonInInputBox, {
                                disabled: valuedBalanceQuery.data == null,
                                onClick: onValueMaxClick,
                                children: "100%"
                            })
                        ]
                    })
                ]
            }),
            mode === "priced" && /*#__PURE__*/ (0,jsx_runtime.jsxs)(SimpleBox, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "",
                        children: "Value"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-4"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "grow flex flex-col overflow-hidden",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "flex items-center",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)(SimpleInput, {
                                        autoFocus: true,
                                        value: rawPricedInput,
                                        onChange: onPricedInputChange,
                                        placeholder: "0.0"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "w-1"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "text-contrast",
                                        children: "USD"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "flex items-center cursor-pointer",
                                role: "button",
                                onClick: onValuedClick,
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "text-contrast truncate",
                                        children: rawValueInput || "0.0"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "grow"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "text-contrast",
                                        children: tokenData.symbol
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-2"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "flex items-center",
                        children: [
                            rawPricedInput.length === 0 ? /*#__PURE__*/ (0,jsx_runtime.jsx)(ShrinkableNakedButtonInInputBox, {
                                onClick: onPricedPaste,
                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(ClipboardIcon/* default */.Z, {
                                    className: "size-4"
                                })
                            }) : /*#__PURE__*/ (0,jsx_runtime.jsx)(ShrinkableNakedButtonInInputBox, {
                                onClick: onPricedClear,
                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(XMarkIcon/* default */.Z, {
                                    className: "size-4"
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "w-1"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(ShrinkableContrastButtonInInputBox, {
                                disabled: pricedBalanceQuery.data == null,
                                onClick: onPricedMaxClick,
                                children: "100%"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-4"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "font-medium",
                children: "Advanced"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-2"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(SimpleBox, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "",
                        children: "Nonce"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-4"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(SimpleInput, {
                        value: rawNonceInput,
                        onChange: onNonceInputChange,
                        placeholder: maybePendingNonce === null || maybePendingNonce === void 0 ? void 0 : maybePendingNonce.toString()
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-1"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(ShrinkableContrastButtonInInputBox, {
                        onClick: onNonceClick,
                        children: "Select"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-2"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(SimpleBox, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "",
                        children: "Data"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-4"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(SimpleTextarea, {
                        rows: 3,
                        value: rawDataInput,
                        onChange: onDataInputChange,
                        placeholder: "0x0"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-4"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "font-medium",
                children: "Gas"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-2"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(SimpleBox, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "",
                        children: "Gas"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-4"
                    }),
                    maybeIsEip1559 === true && /*#__PURE__*/ (0,jsx_runtime.jsxs)("select", {
                        className: "w-full my-0.5 bg-transparent outline-none",
                        value: gasMode,
                        onChange: onGasModeChange,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("option", {
                                value: "urgent",
                                children: "Urgent — ".concat(urgentBaseFeePerGasDisplay, ":").concat(urgentMaxPriorityFeePerGasDisplay, " Gwei — ").concat(urgentMinEip1559GasCostDisplay, "-").concat(urgentMaxEip1559GasCostDisplay)
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("option", {
                                value: "fast",
                                children: "Fast — ".concat(fastBaseFeePerGasDisplay, ":").concat(fastMaxPriorityFeePerGasDisplay, " Gwei — ").concat(fastMinEip1559GasCostDisplay, "-").concat(fastMaxEip1559GasCostDisplay)
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("option", {
                                value: "normal",
                                children: "Normal — ".concat(normalBaseFeePerGasDisplay, ":").concat(normalMaxPriorityFeePerGasDisplay, " Gwei — ").concat(normalMinEip1559GasCostDisplay, "-").concat(normalMaxEip1559GasCostDisplay)
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("option", {
                                value: "custom",
                                children: "Custom"
                            })
                        ]
                    }),
                    maybeIsEip1559 === false && /*#__PURE__*/ (0,jsx_runtime.jsxs)("select", {
                        className: "w-full my-0.5 bg-transparent outline-none",
                        value: gasMode,
                        onChange: onGasModeChange,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("option", {
                                value: "urgent",
                                children: "Urgent — ".concat(urgentGasPriceDisplay, " Gwei — ").concat(urgentLegacyGasCostDisplay)
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("option", {
                                value: "fast",
                                children: "Fast — ".concat(fastGasPriceDisplay, " Gwei — ").concat(fastLegacyGasCostDisplay)
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("option", {
                                value: "normal",
                                children: "Normal — ".concat(normalGasPriceDisplay, " Gwei — ").concat(normalLegacyGasCostDisplay)
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("option", {
                                value: "custom",
                                children: "Custom"
                            })
                        ]
                    })
                ]
            }),
            gasMode === "custom" && maybeIsEip1559 === false && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-2"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(SimpleBox, {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "",
                                children: "Gas Limit"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "w-4"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(SimpleInput, {
                                value: rawGasLimitInput,
                                onChange: onGasLimitInputChange,
                                placeholder: maybeFetchedGasLimit === null || maybeFetchedGasLimit === void 0 ? void 0 : maybeFetchedGasLimit.toString()
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-2"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(SimpleBox, {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "",
                                children: "Gas Price"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "w-4"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(SimpleInput, {
                                value: rawGasPriceInput,
                                onChange: onGasPriceInputChange,
                                placeholder: maybeFetchedGasPrice === null || maybeFetchedGasPrice === void 0 ? void 0 : maybeFetchedGasPrice.toString()
                            })
                        ]
                    })
                ]
            }),
            gasMode === "custom" && maybeIsEip1559 === true && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-2"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(SimpleBox, {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "",
                                children: "Gas Limit"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "w-4"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(SimpleInput, {
                                value: rawGasLimitInput,
                                onChange: onGasLimitInputChange,
                                placeholder: maybeFetchedGasLimit === null || maybeFetchedGasLimit === void 0 ? void 0 : maybeFetchedGasLimit.toString()
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-2"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(SimpleBox, {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "",
                                children: "Base Fee Per Gas"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "w-4"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(SimpleInput, {
                                value: rawBaseFeePerGasInput,
                                onChange: onBaseFeePerGasInputChange,
                                placeholder: maybeFetchedBaseFeePerGas === null || maybeFetchedBaseFeePerGas === void 0 ? void 0 : maybeFetchedBaseFeePerGas.toString()
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-2"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(SimpleBox, {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "",
                                children: "Max Priority Fee Per Gas"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "w-4"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(SimpleInput, {
                                value: rawMaxPriorityFeePerGasInput,
                                onChange: onMaxPriorityFeePerGasInputChange,
                                placeholder: maybeFetchedMaxPriorityFeePerGas === null || maybeFetchedMaxPriorityFeePerGas === void 0 ? void 0 : maybeFetchedMaxPriorityFeePerGas.toString()
                            })
                        ]
                    })
                ]
            }),
            maybeIsEip1559 === false && maybeFinalLegacyGasCost != null && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-2"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "text-contrast",
                        children: [
                            "This transaction is expected to cost ",
                            finalLegacyGasCostDisplay
                        ]
                    })
                ]
            }),
            maybeIsEip1559 === true && maybeFinalMinEip1559GasCost != null && maybeFinalMaxEip1559GasCost != null && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-2"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "text-contrast",
                        children: [
                            "This transaction is expected to cost ",
                            finalMinEip1559GasCostDisplay,
                            " but can cost up to ",
                            finalMaxEip1559GasCostDisplay
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-4 grow"
            }),
            txSign != null && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "po-md flex items-center bg-contrast rounded-xl",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "flex flex-col truncate",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    className: "flex items-center",
                                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "font-medium",
                                        children: "Transaction signed"
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    className: "text-contrast truncate",
                                    children: txSign
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    className: "h-2"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    className: "flex items-center gap-1",
                                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                                        className: "group px-2 bg-contrast rounded-full outline-none disabled:opacity-50 transition-opacity",
                                        onClick: onTxSignCopy.run,
                                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                            className: "h-full w-full flex items-center justify-center gap-2 group-active:scale-90 transition-transform",
                                            children: [
                                                "Copy",
                                                onTxSignCopy.current ? /*#__PURE__*/ (0,jsx_runtime.jsx)(CheckIcon/* default */.Z, {
                                                    className: "size-4"
                                                }) : /*#__PURE__*/ (0,jsx_runtime.jsx)(ClipboardIcon/* default */.Z, {
                                                    className: "size-4"
                                                })
                                            ]
                                        })
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-2"
                    })
                ]
            }),
            txHash != null && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "po-md flex items-center bg-contrast rounded-xl",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "flex flex-col truncate",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    className: "flex items-center",
                                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "font-medium",
                                        children: "Transaction sent"
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    className: "text-contrast truncate",
                                    children: txHash
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    className: "h-2"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: "flex items-center gap-1",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                                            className: "group px-2 bg-contrast rounded-full outline-none disabled:opacity-50 transition-opacity",
                                            onClick: onTxHashCopy.run,
                                            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                className: "h-full w-full flex items-center justify-center gap-2 group-active:scale-90 transition-transform",
                                                children: [
                                                    "Copy",
                                                    onTxHashCopy.current ? /*#__PURE__*/ (0,jsx_runtime.jsx)(CheckIcon/* default */.Z, {
                                                        className: "size-4"
                                                    }) : /*#__PURE__*/ (0,jsx_runtime.jsx)(ClipboardIcon/* default */.Z, {
                                                        className: "size-4"
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("a", {
                                            className: "group px-2 bg-contrast rounded-full",
                                            target: "_blank",
                                            rel: "noreferrer",
                                            href: "".concat(chainData.etherscan, "/tx/").concat(txHash),
                                            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                className: "h-full w-full flex items-center justify-center gap-2 group-active:scale-90 transition-transform",
                                                children: [
                                                    "Open",
                                                    /*#__PURE__*/ (0,jsx_runtime.jsx)(ArrowTopRightOnSquareIcon/* default */.Z, {
                                                        className: "size-4"
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-2"
                    })
                ]
            }),
            ((_eip1559GasLimitQuery_current1 = eip1559GasLimitQuery.current) === null || _eip1559GasLimitQuery_current1 === void 0 ? void 0 : _eip1559GasLimitQuery_current1.isErr()) && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "po-md flex items-center bg-contrast rounded-xl text-red-500",
                        children: (_eip1559GasLimitQuery_current_get = eip1559GasLimitQuery.current.get()) === null || _eip1559GasLimitQuery_current_get === void 0 ? void 0 : _eip1559GasLimitQuery_current_get.message
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-2"
                    })
                ]
            }),
            ((_legacyGasLimitQuery_current1 = legacyGasLimitQuery.current) === null || _legacyGasLimitQuery_current1 === void 0 ? void 0 : _legacyGasLimitQuery_current1.isErr()) && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "po-md flex items-center bg-contrast rounded-xl text-red-500",
                        children: (_legacyGasLimitQuery_current_get = legacyGasLimitQuery.current.get()) === null || _legacyGasLimitQuery_current_get === void 0 ? void 0 : _legacyGasLimitQuery_current_get.message
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-2"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "flex items-center",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(WideShrinkableContrastButton, {
                        disabled: onSignClick.loading,
                        onClick: onSignClick.run,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(PencilIcon/* default */.Z, {
                                className: "size-5"
                            }),
                            "Sign"
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-2"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(WideShrinkableOppositeButton, {
                        disabled: onSendClick.loading,
                        onClick: onSendClick.run,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(PaperAirplaneIcon/* default */.Z, {
                                className: "size-5"
                            }),
                            "Send"
                        ]
                    })
                ]
            })
        ]
    });
}

;// CONCATENATED MODULE: ./src/mods/foreground/entities/wallets/actions/send/index.tsx






function WalletSendScreen(props) {
    const $path = (0,path_context/* usePathState */.qf)();
    const [step] = (0,path_context/* useSearchState */.XN)("step", $path);
    const [token] = (0,path_context/* useSearchState */.XN)("token", $path);
    if (step === "target") return /*#__PURE__*/ (0,jsx_runtime.jsx)(WalletSendScreenTarget, {});
    if (step === "value" && token == null) return /*#__PURE__*/ (0,jsx_runtime.jsx)(WalletSendScreenNativeValue, {});
    if (step === "value" && token != null) return /*#__PURE__*/ (0,jsx_runtime.jsx)(WalletSendScreenContractValue, {});
    if (step === "nonce") return /*#__PURE__*/ (0,jsx_runtime.jsx)(WalletSendScreenNonce, {});
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(WalletSendScreenTarget, {});
}
function SimpleBox(props) {
    const { children } = props;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
        className: "po-md flex items-start bg-contrast rounded-xl",
        children: children
    });
}
function SimpleInput(props) {
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("input", {
        className: "grow bg-transparent outline-none min-w-0",
        ...props
    });
}
function SimpleTextarea(props) {
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("textarea", {
        className: "grow bg-transparent outline-none min-w-0",
        ...props
    });
}
function ShrinkableNakedButtonInInputBox(props) {
    const { children, ...rest } = props;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
        className: "group rounded-full outline-none disabled:opacity-50 transition-opacity",
        ...rest,
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
            className: "h-full w-full flex items-center justify-center gap-2 group-enabled:group-active:scale-90 transition-transform",
            children: children
        })
    });
}
function ShrinkableContrastButtonInInputBox(props) {
    const { children, ...rest } = props;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
        className: "group px-2 bg-contrast rounded-full outline-none disabled:opacity-50 transition-opacity",
        ...rest,
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
            className: "h-full w-full flex items-center justify-center gap-2 group-enabled:group-active:scale-90 transition-transform",
            children: children
        })
    });
}
function WideShrinkableOppositeButton(props) {
    const { children, ...rest } = props;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
        className: "grow group po-md bg-opposite text-opposite rounded-xl outline-none disabled:opacity-50 transition-opacity",
        ...rest,
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
            className: "h-full w-full flex items-center justify-center gap-2 group-enabled:group-active:scale-90 transition-transform",
            children: children
        })
    });
}
function WideShrinkableContrastButton(props) {
    const { children, ...rest } = props;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
        className: "grow group po-md bg-contrast rounded-xl outline-none disabled:opacity-50 transition-opacity",
        ...rest,
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
            className: "h-full w-full flex items-center justify-center gap-2 group-enabled:group-active:scale-90 transition-transform",
            children: children
        })
    });
}

// EXTERNAL MODULE: ./src/mods/foreground/entities/wallets/card.tsx
var card = __webpack_require__(9014);
;// CONCATENATED MODULE: ./src/mods/background/service_worker/entities/wallets/tokens/data.ts



var TokenSettingsRef;
(function(TokenSettingsRef) {
    function from(settings) {
        const { uuid, wallet, token } = settings;
        return {
            ref: true,
            uuid,
            wallet,
            token
        };
    }
    TokenSettingsRef.from = from;
})(TokenSettingsRef || (TokenSettingsRef = {}));
var BgTokenSettings;
(function(BgTokenSettings) {
    let ByWallet;
    (function(ByWallet) {
        function key(wallet) {
            return "tokenSettingsByWallet/".concat(wallet.uuid);
        }
        ByWallet.key = key;
        function schema(wallet, storage) {
            if (wallet == null) return;
            return (0,query/* createQuery */.rP)({
                key: key(wallet),
                storage
            });
        }
        ByWallet.schema = schema;
    })(ByWallet = BgTokenSettings.ByWallet || (BgTokenSettings.ByWallet = {}));
    function key(wallet, token) {
        if (token.type === "native") return "tokenSettings/".concat(wallet.uuid, "/").concat(token.chainId, "/native");
        if (token.type === "contract") return "tokenSettings/".concat(wallet.uuid, "/").concat(token.chainId, "/").concat(token.address);
        throw new result_errors/* Panic */.F5();
    }
    BgTokenSettings.key = key;
    function schema(wallet, token, storage) {
        if (wallet == null) return;
        if (token == null) return;
        const indexer = async (states)=>{
            var _previous_real_data, _previous_real, _current_real_data, _current_real;
            const { current, previous } = states;
            const previousData = previous === null || previous === void 0 ? void 0 : (_previous_real = previous.real) === null || _previous_real === void 0 ? void 0 : (_previous_real_data = _previous_real.data) === null || _previous_real_data === void 0 ? void 0 : _previous_real_data.inner;
            const currentData = (_current_real = current.real) === null || _current_real === void 0 ? void 0 : (_current_real_data = _current_real.data) === null || _current_real_data === void 0 ? void 0 : _current_real_data.inner;
            if ((previousData === null || previousData === void 0 ? void 0 : previousData.uuid) === (currentData === null || currentData === void 0 ? void 0 : currentData.uuid)) return;
            if (previousData != null) {
                var _ByWallet_schema;
                await ((_ByWallet_schema = ByWallet.schema(previousData.wallet, storage)) === null || _ByWallet_schema === void 0 ? void 0 : _ByWallet_schema.mutate(mutators/* Mutators */.g.mapData(function() {
                    let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : new fetched_data/* Data */.V([]);
                    return d.mapSync((p)=>p.filter((x)=>x.uuid !== previousData.uuid));
                })));
            }
            if (currentData != null) {
                var _ByWallet_schema1;
                await ((_ByWallet_schema1 = ByWallet.schema(currentData.wallet, storage)) === null || _ByWallet_schema1 === void 0 ? void 0 : _ByWallet_schema1.mutate(mutators/* Mutators */.g.mapData(function() {
                    let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : new fetched_data/* Data */.V([]);
                    return d.mapSync((p)=>[
                            ...p,
                            TokenSettingsRef.from(currentData)
                        ]);
                })));
            }
        };
        return (0,query/* createQuery */.rP)({
            key: key(wallet, token),
            storage,
            indexer
        });
    }
    BgTokenSettings.schema = schema;
})(BgTokenSettings || (BgTokenSettings = {}));

;// CONCATENATED MODULE: ./src/mods/foreground/entities/wallets/tokens/data.ts





var FgTokenSettings;
(function(FgTokenSettings) {
    let ByWallet;
    (function(ByWallet) {
        ByWallet.key = BgTokenSettings.ByWallet.key;
        function schema(wallet, storage) {
            if (wallet == null) return;
            return (0,query/* createQuery */.rP)({
                key: ByWallet.key(wallet),
                storage
            });
        }
        ByWallet.schema = schema;
    })(ByWallet = FgTokenSettings.ByWallet || (FgTokenSettings.ByWallet = {}));
    FgTokenSettings.key = BgTokenSettings.key;
    function schema(wallet, token, storage) {
        if (wallet == null) return;
        if (token == null) return;
        const indexer = async (states)=>{
            var _previous_real_data, _previous_real, _current_real_data, _current_real;
            const { current, previous } = states;
            const previousData = previous === null || previous === void 0 ? void 0 : (_previous_real = previous.real) === null || _previous_real === void 0 ? void 0 : (_previous_real_data = _previous_real.data) === null || _previous_real_data === void 0 ? void 0 : _previous_real_data.inner;
            const currentData = (_current_real = current.real) === null || _current_real === void 0 ? void 0 : (_current_real_data = _current_real.data) === null || _current_real_data === void 0 ? void 0 : _current_real_data.inner;
            if ((previousData === null || previousData === void 0 ? void 0 : previousData.uuid) === (currentData === null || currentData === void 0 ? void 0 : currentData.uuid)) return;
            if (previousData != null) {
                var _ByWallet_schema;
                await ((_ByWallet_schema = ByWallet.schema(previousData.wallet, storage)) === null || _ByWallet_schema === void 0 ? void 0 : _ByWallet_schema.mutate(mutators/* Mutators */.g.mapData(function() {
                    let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : new fetched_data/* Data */.V([]);
                    return d.mapSync((p)=>p.filter((x)=>x.uuid !== previousData.uuid));
                })));
            }
            if (currentData != null) {
                var _ByWallet_schema1;
                await ((_ByWallet_schema1 = ByWallet.schema(currentData.wallet, storage)) === null || _ByWallet_schema1 === void 0 ? void 0 : _ByWallet_schema1.mutate(mutators/* Mutators */.g.mapData(function() {
                    let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : new fetched_data/* Data */.V([]);
                    return d.mapSync((p)=>[
                            ...p,
                            TokenSettingsRef.from(currentData)
                        ]);
                })));
            }
        };
        return (0,query/* createQuery */.rP)({
            key: FgTokenSettings.key(wallet, token),
            storage,
            indexer
        });
    }
    FgTokenSettings.schema = schema;
})(FgTokenSettings || (FgTokenSettings = {}));
function useTokenSettings(wallet, token) {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(FgTokenSettings.schema, [
        wallet,
        token,
        storage
    ]);
    (0,storage_storage/* useSubscribe */.Q)(query, storage);
    return query;
}
function useTokenSettingsByWallet(wallet) {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(FgTokenSettings.ByWallet.schema, [
        wallet,
        storage
    ]);
    (0,storage_storage/* useSubscribe */.Q)(query, storage);
    return query;
}

;// CONCATENATED MODULE: ./src/mods/foreground/entities/wallets/page.tsx
/* eslint-disable @next/next/no-img-element */ 

































function WalletPage(props) {
    const { uuid } = props;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(wallets_context/* WalletDataProvider */.lp, {
        uuid: uuid,
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(WalletDataPage, {})
    });
}
function useDisplay(result) {
    return (0,react.useMemo)(()=>{
        if (result == null) return "0.00";
        if (result.isErr()) return "0.00";
        const number = Number(types_fixed/* Fixed */.g.from(result.unwrap()).move(5).toString());
        return number.toLocaleString(undefined);
    }, [
        result
    ]);
}
function useDisplayUsd(result) {
    return (0,react.useMemo)(()=>{
        if (result == null) return "0.00";
        if (result.isErr()) return "Error";
        const number = Number(types_fixed/* Fixed */.g.from(result.unwrap()).move(2).toString());
        return number.toLocaleString(undefined, {
            style: "currency",
            currency: "USD",
            notation: "standard"
        });
    }, [
        result
    ]);
}
function useCompactDisplayUsd(result) {
    return (0,react.useMemo)(()=>{
        if (result == null) return "0.00";
        if (result.isErr()) return "Error";
        const number = Number(types_fixed/* Fixed */.g.from(result.unwrap()).move(2).toString());
        return number.toLocaleString(undefined, {
            style: "currency",
            currency: "USD",
            notation: "compact"
        });
    }, [
        result
    ]);
}
function WalletDataPage() {
    var _walletTokens_data, _userTokens_data;
    const wallet = (0,wallets_context/* useWalletDataContext */.zI)().unwrap();
    const background = (0,context/* useBackgroundContext */.D_)().unwrap();
    const subpath = (0,path_context/* useSubpath */._u)();
    const mainnet = (0,entities_wallets_data/* useEthereumContext2 */.IL)(wallet.uuid, mods_chain/* chainByChainId */.DH[1]).unwrap();
    (0,names_data/* useEnsReverse */.DB)(wallet.address, mainnet);
    const send = subpath.url.pathname === "/send";
    const onSendClose = (0,react.useCallback)(()=>{
        subpath.go("/");
    }, [
        subpath
    ]);
    const onSendClick = (0,react.useCallback)(()=>{
        subpath.go("/send?step=target&chain=".concat(mainnet === null || mainnet === void 0 ? void 0 : mainnet.chain.chainId));
    }, [
        subpath,
        mainnet
    ]);
    const receiveDialog = (0,handles_boolean/* useBooleanHandle */.x)(false);
    const [color, color2] = colors/* Gradients */.R.get(wallet.color);
    const [all, setAll] = (0,react.useState)(false);
    const [edit, setEdit] = (0,react.useState)(false);
    const add = (0,handles_boolean/* useBooleanHandle */.x)(false);
    const walletTokens = useTokenSettingsByWallet(wallet);
    const userTokens = useTokens();
    const allTokens = (0,react.useMemo)(()=>{
        const natives = Object.values(mods_chain/* chainByChainId */.DH).map((x)=>x.token);
        const contracts = Object.values(mods_chain/* tokenByAddress */.q2);
        const all = [
            ...natives,
            ...contracts
        ];
        return all.sort((a, b)=>a.chainId - b.chainId);
    }, []);
    const onBackClick = (0,react.useCallback)(()=>{
        path_context/* Paths */.nB.go("/wallets");
    }, []);
    const onCameraClick = (0,react.useCallback)(()=>{
        path_context/* Paths */.nB.go("/wallet/".concat(wallet.uuid, "/camera"));
    }, [
        wallet
    ]);
    const onLinkClick = (0,react.useCallback)(async ()=>{
        return await result/* Result */.x.unthrow(async (t)=>{
            const clipboard = await result/* Result */.x.runAndWrap(async ()=>{
                return await navigator.clipboard.readText();
            }).then((r)=>r.orElseSync(()=>{
                    return option_option/* Option */.W.wrap(prompt("Paste a WalletConnect link here")).ok();
                }).throw(t));
            const url = url_url/* Url */.R.tryParse(clipboard).setErr(new errors/* UIError */.m("You must copy a WalletConnect link")).throw(t);
            await Wc.tryParse(url).then((r)=>r.setErr(new errors/* UIError */.m("You must copy a WalletConnect link")).throw(t));
            alert("Connecting...");
            const metadata = await background.tryRequest({
                method: "brume_wc_connect",
                params: [
                    clipboard,
                    wallet.uuid
                ]
            }).then((r)=>r.throw(t).throw(t));
            alert("Connected to ".concat(metadata.name));
            return ok.Ok.void();
        }).then(results/* Results */.u.logAndAlert);
    }, [
        wallet,
        background
    ]);
    const Header = /*#__PURE__*/ (0,jsx_runtime.jsx)(header/* UserPageHeader */.To, {
        title: "Wallet",
        back: onBackClick,
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
            className: "flex gap-2",
            children: background.isWebsite() && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.Base */.z.XY, {
                        className: "size-8 hovered-or-clicked-or-focused:scale-105 !transition",
                        onClick: onCameraClick,
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
                            children: /*#__PURE__*/ (0,jsx_runtime.jsx)(QrCodeIcon/* default */.Z, {
                                className: "size-5"
                            })
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.Base */.z.XY, {
                        className: "size-8 hovered-or-clicked-or-focused:scale-105 !transition",
                        onClick: onLinkClick,
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
                            children: /*#__PURE__*/ (0,jsx_runtime.jsx)(LinkIcon/* default */.Z, {
                                className: "size-5"
                            })
                        })
                    })
                ]
            })
        })
    });
    const Card = /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
        className: "p-4 flex justify-center",
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "w-full max-w-sm",
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsx)(card/* SimpleWalletDataCard */.T, {}),
                wallet.type === "readonly" && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "h-2"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "po-sm bg-contrast text-contrast rounded-xl flex items-center justify-center",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)(EyeIcon/* default */.Z, {
                                    className: "size-5"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    className: "w-2"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    children: "This is a watch-only wallet"
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
    const Apps = /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "p-4 flex items-center justify-center flex-wrap gap-12",
        children: [
            wallet.type !== "readonly" && /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "flex flex-col items-center gap-2",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                        className: "text-white bg-gradient-to-r from-".concat(color, " to-").concat(color2, " rounded-xl p-3 hovered-or-clicked-or-focused:scale-105 !transition-transform"),
                        onClick: onSendClick,
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(PaperAirplaneIcon/* default */.Z, {
                            className: "size-6"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "",
                        children: "Send"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "flex flex-col items-center gap-2",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                        className: "text-white bg-gradient-to-r from-".concat(color, " to-").concat(color2, " rounded-xl p-3 hovered-or-clicked-or-focused:scale-105 !transition-transform"),
                        onClick: receiveDialog.enable,
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(QrCodeIcon/* default */.Z, {
                            className: "size-6"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "",
                        children: "Receive"
                    })
                ]
            })
        ]
    });
    const Body = /*#__PURE__*/ (0,jsx_runtime.jsxs)(header/* PageBody */.xV, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Dialog */.Vq, {
                opened: add.current,
                close: add.disable,
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(TokenAddDialog, {})
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "font-medium text-xl",
                children: "Tokens"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-4"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "flex flex-col gap-4",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(TokenRowRouter, {
                        token: mods_chain/* chainByChainId */.DH[1].token
                    }),
                    !edit && ((_walletTokens_data = walletTokens.data) === null || _walletTokens_data === void 0 ? void 0 : _walletTokens_data.inner.map((tokenSettings)=>/*#__PURE__*/ (0,jsx_runtime.jsx)(AddedTokenRow, {
                            settingsRef: tokenSettings
                        }, tokenSettings.uuid)))
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-4"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "flex items-center gap-2",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                        className: "".concat(ui_button/* Button.Base */.z.XY.className, " po-sm bg-gradient-to-r from-").concat(color, " to-").concat(color2, " text-white self-center hovered-or-clicked-or-focused:scale-105 !transition"),
                        onClick: ()=>setAll(!all),
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
                            children: all ? "Show less" : "Show more"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "grow"
                    }),
                    all && /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                        className: "".concat(ui_button/* Button.Base */.z.XY.className, " po-sm bg-gradient-to-r from-").concat(color, " to-").concat(color2, " text-white self-center hovered-or-clicked-or-focused:scale-105 !transition"),
                        onClick: ()=>setEdit(!edit),
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
                            children: edit ? "Done" : "Edit"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                        className: "".concat(ui_button/* Button.Base */.z.XY.className, " po-sm bg-gradient-to-r from-").concat(color, " to-").concat(color2, " text-white self-center hovered-or-clicked-or-focused:scale-105 !transition"),
                        onClick: add.enable,
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
                            children: "Add"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-4"
            }),
            all && /*#__PURE__*/ (0,jsx_runtime.jsx)(TokensEditContext.Provider, {
                value: edit,
                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                    className: "flex flex-col gap-4",
                    children: [
                        allTokens.map((token)=>/*#__PURE__*/ (0,jsx_runtime.jsx)(react.Fragment, {
                                children: token.uuid !== mods_chain/* chainByChainId */.DH[1].token.uuid && /*#__PURE__*/ (0,jsx_runtime.jsx)(UnaddedTokenRow, {
                                    token: token
                                })
                            }, token.uuid)),
                        (_userTokens_data = userTokens.data) === null || _userTokens_data === void 0 ? void 0 : _userTokens_data.inner.map((token)=>/*#__PURE__*/ (0,jsx_runtime.jsx)(UnaddedTokenRow, {
                                token: token
                            }, token.uuid))
                    ]
                })
            })
        ]
    });
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(page/* Page */.T, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(path_context/* PathContext */.FM.Provider, {
                value: subpath,
                children: wallet.type !== "readonly" && /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Screen */.lL, {
                    opened: send,
                    close: onSendClose,
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)(WalletSendScreen, {})
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Screen */.lL, {
                dark: true,
                opened: receiveDialog.current,
                close: receiveDialog.disable,
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(WalletDataReceiveScreen, {})
            }),
            Header,
            Card,
            Apps,
            Body
        ]
    });
}
const TokensEditContext = /*#__PURE__*/ (0,react.createContext)(false);
function useTokensEditContext() {
    return option_option/* Option */.W.wrap((0,react.useContext)(TokensEditContext));
}
function AddedTokenRow(props) {
    var _settings_data;
    const wallet = (0,wallets_context/* useWalletDataContext */.zI)().unwrap();
    const { settingsRef } = props;
    const { token } = settingsRef;
    const settings = useTokenSettings(wallet, token);
    if (token.type === "native" && token.chainId === 1) return null;
    if (!((_settings_data = settings.data) === null || _settings_data === void 0 ? void 0 : _settings_data.inner.enabled)) return null;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(TokenRowRouter, {
        token: settings.data.inner.token
    });
}
function UnaddedTokenRow(props) {
    var _settings_data;
    const edit = useTokensEditContext().unwrap();
    const wallet = (0,wallets_context/* useWalletDataContext */.zI)().unwrap();
    const { token } = props;
    const settings = useTokenSettings(wallet, token);
    if (((_settings_data = settings.data) === null || _settings_data === void 0 ? void 0 : _settings_data.inner.enabled) && !edit) return null;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(TokenRowRouter, {
        token: token
    });
}
function TokenRowRouter(props) {
    const { token } = props;
    if (token.type === "native") return /*#__PURE__*/ (0,jsx_runtime.jsx)(NativeTokenResolver, {
        token: token
    });
    if (token.type === "contract") return /*#__PURE__*/ (0,jsx_runtime.jsx)(ContractTokenResolver, {
        token: token
    });
    return null;
}
function NativeTokenResolver(props) {
    const { token } = props;
    const chainData = mods_chain/* chainByChainId */.DH[token.chainId];
    const tokenData = chainData.token;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(NativeTokenRow, {
        token: tokenData,
        chain: chainData
    });
}
function ContractTokenResolver(props) {
    var _tokenQuery_data;
    const { token } = props;
    const tokenQuery = useToken(token.chainId, token.address);
    var _tokenQuery_data_inner;
    const tokenData = (_tokenQuery_data_inner = (_tokenQuery_data = tokenQuery.data) === null || _tokenQuery_data === void 0 ? void 0 : _tokenQuery_data.inner) !== null && _tokenQuery_data_inner !== void 0 ? _tokenQuery_data_inner : mods_chain/* tokenByAddress */.q2[token.address];
    const chainData = mods_chain/* chainByChainId */.DH[token.chainId];
    if (tokenData == null) return null;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(ContractTokenRow, {
        token: tokenData,
        chain: chainData
    });
}
function NativeTokenRow(props) {
    var _token_pairs, _chain_token_pairs;
    const { token, chain } = props;
    const wallet = (0,wallets_context/* useWalletDataContext */.zI)().unwrap();
    const edit = useTokensEditContext().unwrap();
    const subpath = (0,path_context/* useSubpath */._u)();
    const context = (0,entities_wallets_data/* useEthereumContext2 */.IL)(wallet.uuid, chain).unwrap();
    const onSendClick = (0,react.useCallback)(()=>{
        subpath.go("/send?step=target&chain=".concat(context === null || context === void 0 ? void 0 : context.chain.chainId));
    }, [
        subpath,
        context
    ]);
    var _token_pairs_length;
    const [prices, setPrices] = (0,react.useState)(new Array((_token_pairs_length = (_token_pairs = token.pairs) === null || _token_pairs === void 0 ? void 0 : _token_pairs.length) !== null && _token_pairs_length !== void 0 ? _token_pairs_length : 0));
    const balanceQuery = useNativeBalance(wallet.address, "pending", context, prices);
    const balanceDisplay = useDisplay(balanceQuery.current);
    const balanceUsdFixed = useNativePricedBalance(wallet.address, "usd", context);
    const balanceUsdDisplay = useDisplayUsd(balanceUsdFixed.current);
    const onPrice = (0,react.useCallback)((param)=>{
        let [index, data] = param;
        setPrices((prices)=>{
            prices[index] = data;
            return [
                ...prices
            ];
        });
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            (_chain_token_pairs = chain.token.pairs) === null || _chain_token_pairs === void 0 ? void 0 : _chain_token_pairs.map((address, i)=>/*#__PURE__*/ (0,jsx_runtime.jsx)(PriceResolver, {
                    index: i,
                    address: address,
                    ok: onPrice
                }, i)),
            !edit && /*#__PURE__*/ (0,jsx_runtime.jsx)(ClickableTokenRow, {
                ok: onSendClick,
                token: token,
                chain: chain,
                balanceDisplay: balanceDisplay,
                balanceUsdDisplay: balanceUsdDisplay
            }),
            edit && /*#__PURE__*/ (0,jsx_runtime.jsx)(CheckableTokenRow, {
                token: token,
                chain: chain,
                balanceDisplay: balanceDisplay,
                balanceUsdDisplay: balanceUsdDisplay
            })
        ]
    });
}
function ContractTokenRow(props) {
    var _token_pairs, _token_pairs1;
    const { token, chain } = props;
    const wallet = (0,wallets_context/* useWalletDataContext */.zI)().unwrap();
    const edit = useTokensEditContext().unwrap();
    const subpath = (0,path_context/* useSubpath */._u)();
    const context = (0,entities_wallets_data/* useEthereumContext2 */.IL)(wallet.uuid, chain).unwrap();
    var _token_pairs_length;
    const [prices, setPrices] = (0,react.useState)(new Array((_token_pairs_length = (_token_pairs = token.pairs) === null || _token_pairs === void 0 ? void 0 : _token_pairs.length) !== null && _token_pairs_length !== void 0 ? _token_pairs_length : 0));
    const balanceQuery = useContractBalance(wallet.address, token, "pending", context, prices);
    const balanceDisplay = useDisplay(balanceQuery.current);
    const onSendClick = (0,react.useCallback)(()=>{
        subpath.go("/send?step=target&chain=".concat(context === null || context === void 0 ? void 0 : context.chain.chainId, "&token=").concat(token.address));
    }, [
        subpath,
        context,
        token
    ]);
    const balanceUsdFixed = useContractPricedBalance(wallet.address, token, "usd", context);
    const balanceUsdDisplay = useDisplayUsd(balanceUsdFixed.current);
    const onPrice = (0,react.useCallback)((param)=>{
        let [index, data] = param;
        setPrices((prices)=>{
            prices[index] = data;
            return [
                ...prices
            ];
        });
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            (_token_pairs1 = token.pairs) === null || _token_pairs1 === void 0 ? void 0 : _token_pairs1.map((address, i)=>/*#__PURE__*/ (0,jsx_runtime.jsx)(PriceResolver, {
                    index: i,
                    address: address,
                    ok: onPrice
                }, i)),
            !edit && /*#__PURE__*/ (0,jsx_runtime.jsx)(ClickableTokenRow, {
                ok: onSendClick,
                token: token,
                chain: chain,
                balanceDisplay: balanceDisplay,
                balanceUsdDisplay: balanceUsdDisplay
            }),
            edit && /*#__PURE__*/ (0,jsx_runtime.jsx)(CheckableTokenRow, {
                token: token,
                chain: chain,
                balanceDisplay: balanceDisplay,
                balanceUsdDisplay: balanceUsdDisplay
            })
        ]
    });
}
function PriceResolver(props) {
    const { ok, index, address } = props;
    const wallet = (0,wallets_context/* useWalletDataContext */.zI)().unwrap();
    const pairData = mods_chain/* pairByAddress */.ne[address];
    const chainData = mods_chain/* chainByChainId */.DH[pairData.chainId];
    const context = (0,entities_wallets_data/* useEthereumContext */.Kn)(wallet.uuid, chainData);
    const { data } = usePairPrice(context, pairData);
    (0,react.useEffect)(()=>{
        ok([
            index,
            data === null || data === void 0 ? void 0 : data.inner
        ]);
    }, [
        index,
        data,
        ok
    ]);
    return null;
}
function ClickableTokenRow(props) {
    const { ok, token, chain, balanceDisplay, balanceUsdDisplay } = props;
    const onClick = (0,react.useCallback)(()=>{
        ok();
    }, [
        ok
    ]);
    const tokenId = token.type === "native" ? token.chainId + token.symbol : token.chainId + token.address + token.symbol;
    const modtoken = colors/* Colors */.w.get((0,modhash/* useModhash */.jR)("".concat(tokenId)));
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("button", {
        className: "po-sm group flex items-center text-left",
        onClick: onClick,
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "relative h-12 w-12 flex items-center justify-center bg-".concat(modtoken, " text-white rounded-full"),
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "",
                        style: {
                            fontSize: "".concat(Math.min(20 - 2 * token.symbol.length, 16), "px")
                        },
                        children: token.symbol
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "absolute -bottom-2 -left-2",
                        children: chain.icon()
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "w-4"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "grow",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "flex items-center",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "grow flex items-center gap-1",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                        className: "",
                                        children: token.name
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                        className: "text-contrast",
                                        children: "on"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                        className: "",
                                        children: chain.name
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "",
                                children: balanceUsdDisplay
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "text-contrast",
                        children: [
                            balanceDisplay,
                            " ",
                            token.symbol
                        ]
                    })
                ]
            })
        ]
    });
}
function CheckableTokenRow(props) {
    var _settings_data;
    const { token, chain, balanceDisplay, balanceUsdDisplay } = props;
    const wallet = (0,wallets_context/* useWalletDataContext */.zI)().unwrap();
    const settings = useTokenSettings(wallet, token);
    const checked = (_settings_data = settings.data) === null || _settings_data === void 0 ? void 0 : _settings_data.inner.enabled;
    const onToggle = (0,events/* useInputChange */.Xy)(async (e)=>{
        const enabled = e.currentTarget.checked;
        await settings.mutate((s)=>{
            var _s_real;
            const data = mutators/* Mutators */.g.Datas.mapOrNew(function() {
                let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {
                    uuid: crypto.randomUUID(),
                    token: TokenRef.from(token),
                    wallet: wallets_data/* WalletRef */.V.from(wallet)
                };
                return {
                    ...d,
                    enabled
                };
            }, (_s_real = s.real) === null || _s_real === void 0 ? void 0 : _s_real.data);
            return new some/* Some */.b(data);
        });
    }, []);
    const tokenId = token.type === "native" ? token.chainId + token.symbol : token.chainId + token.address + token.symbol;
    const modtoken = colors/* Colors */.w.get((0,modhash/* useModhash */.jR)("".concat(tokenId)));
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("label", {
        className: "po-sm group flex items-center",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)("input", {
                className: "appearance-none",
                type: "checkbox",
                checked: checked,
                onChange: onToggle
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-6 w-6 border border-contrast rounded-full aria-checked:bg-blue-500 flex items-center justify-center transition-colors",
                "aria-checked": checked,
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "text-white invisible aria-checked:visible",
                    "aria-checked": checked,
                    children: "✓"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "w-4"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "relative h-12 w-12 flex items-center justify-center bg-".concat(modtoken, " text-white rounded-full"),
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "",
                        style: {
                            fontSize: "".concat(Math.min(20 - 2 * token.symbol.length, 16), "px")
                        },
                        children: token.symbol
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "absolute -bottom-2 -left-2",
                        children: chain.icon()
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "w-4"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "grow",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "flex items-center",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "grow flex items-center gap-1",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                        className: "",
                                        children: token.name
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                        className: "text-contrast",
                                        children: "on"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                        className: "",
                                        children: chain.name
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "",
                                children: balanceUsdDisplay
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "text-contrast",
                        children: [
                            balanceDisplay,
                            " ",
                            token.symbol
                        ]
                    })
                ]
            })
        ]
    });
}


/***/ }),

/***/ 202:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Ai: function() { return /* binding */ UserRejectedError; }
/* harmony export */ });
/* unused harmony exports UnauthorizedError, UnsupportedMethodError, DisconnectedError, ChainDisconnectedError */
/* harmony import */ var _swc_helpers_class_private_field_get__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7121);
/* harmony import */ var _swc_helpers_class_private_field_init__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9886);
/* harmony import */ var _swc_helpers_class_private_field_set__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5321);
/* harmony import */ var _hazae41_jsonrpc__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(667);



var _a, _b, _c, _d, _e;

var _class = /*#__PURE__*/ new WeakMap();
class UserRejectedError extends _hazae41_jsonrpc__WEBPACK_IMPORTED_MODULE_0__/* .RpcError */ .lt {
    static new() {
        return new _a();
    }
    constructor(){
        super(4001, "The user rejected the request.");
        (0,_swc_helpers_class_private_field_init__WEBPACK_IMPORTED_MODULE_1__._)(this, _class, {
            writable: true,
            value: void 0
        });
        (0,_swc_helpers_class_private_field_set__WEBPACK_IMPORTED_MODULE_2__._)(this, _class, _a);
        this.name = (0,_swc_helpers_class_private_field_get__WEBPACK_IMPORTED_MODULE_3__._)(this, _class).name;
    }
}
_a = UserRejectedError;
var _class1 = /*#__PURE__*/ new WeakMap();
class UnauthorizedError extends _hazae41_jsonrpc__WEBPACK_IMPORTED_MODULE_0__/* .RpcError */ .lt {
    static new() {
        return new _b();
    }
    constructor(){
        super(4100, "The requested method and/or account has not been authorized by the user.");
        (0,_swc_helpers_class_private_field_init__WEBPACK_IMPORTED_MODULE_1__._)(this, _class1, {
            writable: true,
            value: void 0
        });
        (0,_swc_helpers_class_private_field_set__WEBPACK_IMPORTED_MODULE_2__._)(this, _class1, _b);
        this.name = (0,_swc_helpers_class_private_field_get__WEBPACK_IMPORTED_MODULE_3__._)(this, _class1).name;
    }
}
_b = UnauthorizedError;
var _class2 = /*#__PURE__*/ new WeakMap();
class UnsupportedMethodError extends _hazae41_jsonrpc__WEBPACK_IMPORTED_MODULE_0__/* .RpcError */ .lt {
    static new() {
        return new _c();
    }
    constructor(){
        super(4200, "The Provider does not support the requested method.");
        (0,_swc_helpers_class_private_field_init__WEBPACK_IMPORTED_MODULE_1__._)(this, _class2, {
            writable: true,
            value: void 0
        });
        (0,_swc_helpers_class_private_field_set__WEBPACK_IMPORTED_MODULE_2__._)(this, _class2, _c);
        this.name = (0,_swc_helpers_class_private_field_get__WEBPACK_IMPORTED_MODULE_3__._)(this, _class2).name;
    }
}
_c = UnsupportedMethodError;
var _class3 = /*#__PURE__*/ new WeakMap();
class DisconnectedError extends _hazae41_jsonrpc__WEBPACK_IMPORTED_MODULE_0__/* .RpcError */ .lt {
    static new() {
        return new _d();
    }
    constructor(){
        super(4900, "The Provider is disconnected from all chains.");
        (0,_swc_helpers_class_private_field_init__WEBPACK_IMPORTED_MODULE_1__._)(this, _class3, {
            writable: true,
            value: void 0
        });
        (0,_swc_helpers_class_private_field_set__WEBPACK_IMPORTED_MODULE_2__._)(this, _class3, _d);
        this.name = (0,_swc_helpers_class_private_field_get__WEBPACK_IMPORTED_MODULE_3__._)(this, _class3).name;
    }
}
_d = DisconnectedError;
var _class4 = /*#__PURE__*/ new WeakMap();
class ChainDisconnectedError extends _hazae41_jsonrpc__WEBPACK_IMPORTED_MODULE_0__/* .RpcError */ .lt {
    static new() {
        return new _e();
    }
    constructor(){
        super(4901, "The Provider is not connected to the requested chain.");
        (0,_swc_helpers_class_private_field_init__WEBPACK_IMPORTED_MODULE_1__._)(this, _class4, {
            writable: true,
            value: void 0
        });
        (0,_swc_helpers_class_private_field_set__WEBPACK_IMPORTED_MODULE_2__._)(this, _class4, _e);
        this.name = (0,_swc_helpers_class_private_field_get__WEBPACK_IMPORTED_MODULE_3__._)(this, _class4).name;
    }
}
_e = ChainDisconnectedError;


/***/ }),

/***/ 9403:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  z: function() { return /* binding */ Bottom; }
});

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/HomeIcon.js
var HomeIcon = __webpack_require__(2237);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/WalletIcon.js
var WalletIcon = __webpack_require__(5066);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/SparklesIcon.js
var SparklesIcon = __webpack_require__(5083);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/GlobeAltIcon.js
var GlobeAltIcon = __webpack_require__(7950);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/CheckIcon.js
var CheckIcon = __webpack_require__(2911);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/PuzzlePieceIcon.js
var PuzzlePieceIcon = __webpack_require__(3225);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/CogIcon.js
var CogIcon = __webpack_require__(7272);
// EXTERNAL MODULE: ./src/libs/ui/anchor/anchor.tsx
var anchor_anchor = __webpack_require__(9240);
;// CONCATENATED MODULE: ./src/libs/ui/anchor/shrinker.tsx
var Shrinker;
(function(Shrinker) {
    Shrinker.className = "h-full w-full flex justify-center items-center gap-2 group-active:scale-90 transition-transform";
})(Shrinker || (Shrinker = {}));

;// CONCATENATED MODULE: ./src/libs/ui/anchor/index.tsx



;// CONCATENATED MODULE: ./src/libs/ui/anchor.tsx



// EXTERNAL MODULE: ./src/mods/foreground/entities/requests/data.tsx + 1 modules
var data = __webpack_require__(7440);
// EXTERNAL MODULE: ./src/mods/foreground/router/path/context.tsx
var context = __webpack_require__(8097);
;// CONCATENATED MODULE: ./src/mods/foreground/overlay/bottom.tsx





function Bottom() {
    var _requestsQuery_data;
    const { url } = (0,context/* usePathContext */.td)().unwrap();
    const requestsQuery = (0,data/* useAppRequests */.fU)();
    const requests = (_requestsQuery_data = requestsQuery.data) === null || _requestsQuery_data === void 0 ? void 0 : _requestsQuery_data.inner;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("nav", {
        className: "h-16 w-full shrink-0 border-t border-t-contrast",
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "w-full h-16 px-4 m-auto max-w-3xl flex items-center",
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsx)("a", {
                    className: "group grow text-contrast data-[selected=true]:text-default",
                    "data-selected": url.pathname === "/",
                    href: "#/",
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "".concat(Shrinker.className),
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(HomeIcon/* default */.Z, {
                            className: "size-6"
                        })
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("a", {
                    className: "group grow text-contrast data-[selected=true]:text-default",
                    "data-selected": url.pathname === "/wallets",
                    href: "#/wallets",
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "".concat(Shrinker.className),
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(WalletIcon/* default */.Z, {
                            className: "size-6"
                        })
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("a", {
                    className: "group grow text-contrast data-[selected=true]:text-default",
                    "data-selected": url.pathname === "/seeds",
                    href: "#/seeds",
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "".concat(Shrinker.className),
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(SparklesIcon/* default */.Z, {
                            className: "size-6"
                        })
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("a", {
                    className: "group grow text-contrast data-[selected=true]:text-default",
                    "data-selected": url.pathname === "/sessions",
                    href: "#/sessions",
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "".concat(Shrinker.className),
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(GlobeAltIcon/* default */.Z, {
                            className: "size-6"
                        })
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("a", {
                    className: "group grow text-contrast data-[selected=true]:text-default",
                    "data-selected": url.pathname === "/requests",
                    href: "#/requests",
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "".concat(Shrinker.className),
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "relative",
                            children: [
                                Boolean(requests === null || requests === void 0 ? void 0 : requests.length) && /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    className: "absolute top-0 -right-2",
                                    children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("span", {
                                        className: "relative flex w-2 h-2",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                                className: "animate-ping absolute inline-flex h-full w-full rounded-full bg-purple-400 opacity-75"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                                className: "relative inline-flex rounded-full w-2 h-2 bg-purple-400"
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)(CheckIcon/* default */.Z, {
                                    className: "size-6"
                                })
                            ]
                        })
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("a", {
                    className: "group grow text-contrast data-[selected=true]:text-default",
                    "data-selected": url.pathname === "/plugins",
                    href: "#/plugins",
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "".concat(Shrinker.className),
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(PuzzlePieceIcon/* default */.Z, {
                            className: "size-6"
                        })
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("a", {
                    className: "group grow text-contrast data-[selected=true]:text-default",
                    "data-selected": url.pathname === "/settings",
                    href: "#/settings",
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "".concat(Shrinker.className),
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(CogIcon/* default */.Z, {
                            className: "size-6"
                        })
                    })
                })
            ]
        })
    });
}


/***/ }),

/***/ 5794:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   l: function() { return /* binding */ NavBar; }
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _libs_browser_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3039);
/* harmony import */ var _libs_icons_icons__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1902);
/* harmony import */ var _libs_results_results__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7519);
/* harmony import */ var _libs_ui_button__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9178);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7294);
/* harmony import */ var _router_path_context__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8097);







function NavBar() {
    const { url } = (0,_router_path_context__WEBPACK_IMPORTED_MODULE_5__/* .usePathContext */ .td)().unwrap();
    const onOpen = (0,react__WEBPACK_IMPORTED_MODULE_4__.useCallback)(async ()=>{
        await _libs_browser_browser__WEBPACK_IMPORTED_MODULE_1__/* .BrowserError */ .v.tryRun(async ()=>{
            return await _libs_browser_browser__WEBPACK_IMPORTED_MODULE_1__/* .browser */ .X.tabs.create({
                url: "index.html#".concat(url.pathname)
            });
        }).then(_libs_results_results__WEBPACK_IMPORTED_MODULE_2__/* .Results */ .u.logAndAlert);
    }, [
        url
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        className: "w-full po-md border-b border-b-contrast",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
            className: "w-full max-w-[400px] m-auto flex items-center",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "bg-contrast rounded-xl po-sm grow flex items-center min-w-0",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "grow whitespace-nowrap overflow-hidden text-ellipsis text-sm",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                className: "text-contrast",
                                children: "brume://"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                children: url.pathname.slice(1)
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: "w-2"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_libs_ui_button__WEBPACK_IMPORTED_MODULE_3__/* .Button.Base */ .z.XY, {
                        className: "text-contrast hovered-or-clicked-or-focused:scale-105 !transition",
                        onClick: onOpen,
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                            className: "".concat(_libs_ui_button__WEBPACK_IMPORTED_MODULE_3__/* .Button.Shrinker */ .z.Np.className),
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_libs_icons_icons__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                className: "size-4"
                            })
                        })
                    })
                ]
            })
        })
    });
}


/***/ }),

/***/ 938:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  aV: function() { return /* binding */ Overlay; }
});

// UNUSED EXPORTS: ExtensionOverlay, UpdateBanner, WebsiteOverlay

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
// EXTERNAL MODULE: ./src/libs/browser/browser.ts
var browser = __webpack_require__(3039);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/err.mjs
var err = __webpack_require__(166);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/ok.mjs
var ok = __webpack_require__(5591);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/errors.mjs
var errors = __webpack_require__(2564);
;// CONCATENATED MODULE: ./src/libs/fetch/fetch.ts

async function tryFetchAsJson(input, init) {
    try {
        const res = await fetch(input, init);
        if (!res.ok) return new err/* Err */.U(new Error(await res.text()));
        return new ok.Ok(await res.json());
    } catch (e) {
        return new err/* Err */.U(errors/* Catched */.$c.from(e));
    }
}
async function tryFetchAsBlob(input, init) {
    try {
        const res = await fetch(input, init);
        if (!res.ok) return new Err(new Error(await res.text()));
        return new Ok(await res.blob());
    } catch (e) {
        return new Err(Catched.from(e));
    }
}

// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/ArrowPathIcon.js
var ArrowPathIcon = __webpack_require__(5973);
;// CONCATENATED MODULE: ./src/libs/semver/semver.ts
var Semver;
(function(Semver) {
    function isGreater(left, right) {
        const [la, lb, lc] = left.split(".").map((x)=>parseInt(x));
        const [ra, rb, rc] = right.split(".").map((x)=>parseInt(x));
        if (la > ra) return true;
        if (lb > rb) return true;
        if (lc > rc) return true;
        return false;
    }
    Semver.isGreater = isGreater;
})(Semver || (Semver = {}));

// EXTERNAL MODULE: ./src/libs/ui/button.tsx + 8 modules
var ui_button = __webpack_require__(9178);
// EXTERNAL MODULE: ./node_modules/@hazae41/option/dist/esm/mods/option/none.mjs
var none = __webpack_require__(1371);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/result.mjs
var result = __webpack_require__(918);
// EXTERNAL MODULE: ./node_modules/react/index.js
var react = __webpack_require__(7294);
// EXTERNAL MODULE: ./src/mods/foreground/background/context.tsx + 3 modules
var context = __webpack_require__(5855);
;// CONCATENATED MODULE: ./src/mods/foreground/overlay/overlay.tsx










const MAIN_PACKAGE_URL = "https://raw.githubusercontent.com/brumewallet/wallet/main/package.json";
function UpdateBanner(props) {
    const { ok } = props;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
        className: "w-full text-white bg-green-500 po-sm",
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "w-full max-w-[400px] m-auto flex flex-wrap gap-2 items-center text-sm",
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "grow",
                    children: "An update is available"
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.Base */.z.XY, {
                    className: "hovered-or-clicked-or-focused:scale-105 !transition",
                    onClick: ok,
                    children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(ArrowPathIcon/* default */.Z, {
                                className: "size-5"
                            }),
                            "Update"
                        ]
                    })
                })
            ]
        })
    });
}
function Overlay(props) {
    const { children } = props;
    const background = (0,context/* useBackgroundContext */.D_)().unwrap();
    if (background.isExtension()) return /*#__PURE__*/ (0,jsx_runtime.jsx)(ExtensionOverlay, {
        children: children
    });
    if (background.isWebsite()) return /*#__PURE__*/ (0,jsx_runtime.jsx)(WebsiteOverlay, {
        children: children
    });
    return null;
}
async function tryCheckWebsiteUpdate() {
    return await result/* Result */.x.unthrow(async (t)=>{
        const cached = await tryFetchAsJson("/manifest.json").then((r)=>r.throw(t));
        const current = await tryFetchAsJson("/manifest.json?").then((r)=>r.throw(t));
        if (current.version !== cached.version) return new ok.Ok(false); // Will be handled by SW
        const main = await tryFetchAsJson(MAIN_PACKAGE_URL).then((r)=>r.throw(t));
        return new ok.Ok(Semver.isGreater(main.version, cached.version));
    });
}
function WebsiteOverlay(props) {
    const { children } = props;
    const background = (0,context/* useBackgroundContext */.D_)().unwrap();
    const [updating, setUpdating] = (0,react.useState)();
    (0,react.useEffect)(()=>{
        if (!background.isWebsite()) return;
        const onUpdate = (sw)=>{
            setUpdating(sw);
            return new none/* None */.H();
        };
        return background.sw.on("update", onUpdate);
    }, [
        background
    ]);
    const update = (0,react.useCallback)(()=>{
        updating === null || updating === void 0 ? void 0 : updating.postMessage("SKIP_WAITING");
    }, [
        updating
    ]);
    const [updatable, setUpdatable] = (0,react.useState)(false);
    (0,react.useEffect)(()=>{
        tryCheckWebsiteUpdate().then((r)=>r.inspectSync(setUpdatable).inspectErrSync(console.warn));
    }, []);
    const update2 = (0,react.useCallback)(()=>{
        open("https://github.com/brumewallet/wallet/releases", "_blank", "noreferrer");
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            updating && /*#__PURE__*/ (0,jsx_runtime.jsx)(UpdateBanner, {
                ok: update
            }),
            updatable && /*#__PURE__*/ (0,jsx_runtime.jsx)(UpdateBanner, {
                ok: update2
            }),
            children
        ]
    });
}
async function tryCheckDevExtensionUpdate(self) {
    return await result/* Result */.x.unthrow(async (t)=>{
        const main = await tryFetchAsJson(MAIN_PACKAGE_URL).then((r)=>r.throw(t));
        return new ok.Ok(Semver.isGreater(main.version, self.version));
    });
}
async function tryCheckExtensionUpdate() {
    return await result/* Result */.x.unthrow(async (t)=>{
        const self = await browser/* BrowserError */.v.tryRun(async ()=>{
            return await browser/* browser */.X.management.getSelf();
        }).then((r)=>r.throw(t));
        if (self.installType === "development") return await tryCheckDevExtensionUpdate(self);
        return new ok.Ok(false);
    });
}
function ExtensionOverlay(props) {
    const { children } = props;
    const [updatable, setUpdatable] = (0,react.useState)(false);
    (0,react.useEffect)(()=>{
        tryCheckExtensionUpdate().then((r)=>r.inspectSync(setUpdatable).inspectErrSync(console.warn));
    }, []);
    const update = (0,react.useCallback)(()=>{
        open("https://github.com/brumewallet/wallet/releases", "_blank", "noreferrer");
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            updatable && /*#__PURE__*/ (0,jsx_runtime.jsx)(UpdateBanner, {
                ok: update
            }),
            children
        ]
    });
}


/***/ }),

/***/ 2144:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  F: function() { return /* binding */ Router; }
});

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
// EXTERNAL MODULE: ./pages/popup.tsx + 2 modules
var popup = __webpack_require__(7125);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/TrashIcon.js
var TrashIcon = __webpack_require__(6249);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/CubeTransparentIcon.js
var CubeTransparentIcon = __webpack_require__(3490);
// EXTERNAL MODULE: ./src/libs/react/callback.tsx
var callback = __webpack_require__(5379);
// EXTERNAL MODULE: ./src/libs/results/results.ts
var results = __webpack_require__(7519);
// EXTERNAL MODULE: ./src/libs/ui/button.tsx + 8 modules
var ui_button = __webpack_require__(9178);
// EXTERNAL MODULE: ./node_modules/react/index.js
var react = __webpack_require__(7294);
;// CONCATENATED MODULE: ./src/libs/ui/image/image_with_fallback.tsx


function ImageWithFallback(props) {
    const { children, src, onError, ...img } = props;
    const [error, setError] = (0,react.useState)(false);
    (0,react.useEffect)(()=>setError(false), [
        src
    ]);
    const onError2 = (0,react.useCallback)((event)=>{
        setError(true);
        return onError === null || onError === void 0 ? void 0 : onError(event);
    }, [
        onError
    ]);
    if (error) return /*#__PURE__*/ (0,jsx_runtime.jsx)(jsx_runtime.Fragment, {
        children: children
    });
    if (src == null) return /*#__PURE__*/ (0,jsx_runtime.jsx)(jsx_runtime.Fragment, {
        children: children
    });
    // eslint-disable-next-line jsx-a11y/alt-text, @next/next/no-img-element
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("img", {
        src: src,
        onError: onError2,
        ...img
    });
}

// EXTERNAL MODULE: ./src/libs/url/url.ts
var url = __webpack_require__(872);
// EXTERNAL MODULE: ./src/mods/foreground/background/context.tsx + 3 modules
var context = __webpack_require__(5855);
// EXTERNAL MODULE: ./src/mods/foreground/components/page/header.tsx
var header = __webpack_require__(6915);
// EXTERNAL MODULE: ./src/mods/foreground/components/page/page.tsx
var page = __webpack_require__(179);
// EXTERNAL MODULE: ./src/mods/foreground/errors/errors.ts
var errors = __webpack_require__(202);
// EXTERNAL MODULE: ./src/mods/foreground/router/path/context.tsx
var path_context = __webpack_require__(8097);
// EXTERNAL MODULE: ./node_modules/@hazae41/jsonrpc/dist/esm/mods/rpc/err.mjs
var err = __webpack_require__(667);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/result.mjs
var result = __webpack_require__(918);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/ok.mjs
var ok = __webpack_require__(5591);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/err.mjs
var result_err = __webpack_require__(166);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/queries/simple/query.mjs
var query = __webpack_require__(6233);
;// CONCATENATED MODULE: ./src/mods/background/service_worker/entities/blobbys/data.ts

var BlobbyRef;
(function(BlobbyRef) {
    function create(id) {
        return {
            ref: true,
            id
        };
    }
    BlobbyRef.create = create;
    function from(blobby) {
        return create(blobby.id);
    }
    BlobbyRef.from = from;
})(BlobbyRef || (BlobbyRef = {}));
var BgBlobby;
(function(BgBlobby) {
    function key(id) {
        return "blobby/".concat(id);
    }
    BgBlobby.key = key;
    function schema(id, storage) {
        return (0,query/* createQuery */.rP)({
            key: key(id),
            storage
        });
    }
    BgBlobby.schema = schema;
})(BgBlobby || (BgBlobby = {}));

// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/react/hooks/queries/simple.mjs + 1 modules
var simple = __webpack_require__(564);
// EXTERNAL MODULE: ./src/mods/foreground/storage/storage.ts
var storage_storage = __webpack_require__(604);
// EXTERNAL MODULE: ./src/mods/foreground/storage/user.tsx
var user = __webpack_require__(9718);
;// CONCATENATED MODULE: ./src/mods/foreground/entities/blobbys/data.ts




var FgBlobby;
(function(FgBlobby) {
    FgBlobby.key = BgBlobby.key;
    function schema(id, storage) {
        if (id == null) return;
        return (0,query/* createQuery */.rP)({
            key: FgBlobby.key(id),
            storage
        });
    }
    FgBlobby.schema = schema;
})(FgBlobby || (FgBlobby = {}));
function useBlobby(id) {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(FgBlobby.schema, [
        id,
        storage
    ]);
    (0,storage_storage/* useSubscribe */.Q)(query, storage);
    return query;
}

;// CONCATENATED MODULE: ./src/mods/background/service_worker/entities/origins/data.ts

var BgOrigin;
(function(BgOrigin) {
    function key(origin) {
        return "origins/".concat(origin);
    }
    BgOrigin.key = key;
    function schema(origin, storage) {
        return (0,query/* createQuery */.rP)({
            key: key(origin),
            storage
        });
    }
    BgOrigin.schema = schema;
})(BgOrigin || (BgOrigin = {}));

;// CONCATENATED MODULE: ./src/mods/foreground/entities/origins/data.ts




var FgOrigin;
(function(FgOrigin) {
    FgOrigin.key = BgOrigin.key;
    function schema(origin, storage) {
        if (origin == null) return;
        return (0,query/* createQuery */.rP)({
            key: FgOrigin.key(origin),
            storage
        });
    }
    FgOrigin.schema = schema;
})(FgOrigin || (FgOrigin = {}));
function useOrigin(origin) {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(FgOrigin.schema, [
        origin,
        storage
    ]);
    (0,storage_storage/* useSubscribe */.Q)(query, storage);
    return query;
}

// EXTERNAL MODULE: ./src/mods/foreground/entities/requests/data.tsx + 1 modules
var data = __webpack_require__(7440);
;// CONCATENATED MODULE: ./src/mods/foreground/entities/requests/all/page.tsx
/* eslint-disable @next/next/no-img-element */ 

















function RequestsPage() {
    var _requestsQuery_data;
    const background = (0,context/* useBackgroundContext */.D_)().unwrap();
    const requestsQuery = (0,data/* useAppRequests */.fU)();
    const maybeRequests = (_requestsQuery_data = requestsQuery.data) === null || _requestsQuery_data === void 0 ? void 0 : _requestsQuery_data.inner;
    const tryRejectAll = (0,callback/* useAsyncUniqueCallback */.T)(async ()=>{
        return await result/* Result */.x.unthrow(async (t)=>{
            if (maybeRequests == null) return ok.Ok.void();
            if (!confirm("Do you want to reject all requests?")) return ok.Ok.void();
            for (const { id } of maybeRequests)await background.tryRequest({
                method: "brume_respond",
                params: [
                    err/* RpcErr */.s6.rewrap(id, new result_err/* Err */.U(new errors/* UserRejectedError */.Ai()))
                ]
            }).then((r)=>r.throw(t).throw(t));
            return ok.Ok.void();
        }).then(results/* Results */.u.logAndAlert);
    }, [
        background,
        maybeRequests
    ]);
    const Body = /*#__PURE__*/ (0,jsx_runtime.jsx)(header/* PageBody */.xV, {
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
            className: "flex flex-col gap-2",
            children: maybeRequests === null || maybeRequests === void 0 ? void 0 : maybeRequests.map((request)=>/*#__PURE__*/ (0,jsx_runtime.jsx)(RequestRow, {
                    request: request
                }, request.id))
        })
    });
    const Header = /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(header/* UserPageHeader */.To, {
                title: "Requests",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.Base */.z.XY, {
                    className: "size-8 hovered-or-clicked-or-focused:scale-105 !transition",
                    disabled: tryRejectAll.loading || !Boolean(maybeRequests === null || maybeRequests === void 0 ? void 0 : maybeRequests.length),
                    onClick: tryRejectAll.run,
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(TrashIcon/* default */.Z, {
                            className: "size-5"
                        })
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "po-md flex items-center",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "text-contrast",
                    children: "Request allow you to approve various actions such as transactions and signatures. These requests are sent by applications through sessions."
                })
            })
        ]
    });
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(page/* Page */.T, {
        children: [
            Header,
            Body
        ]
    });
}
function RequestRow(props) {
    var _requestQuery_data, _originQuery_data, _maybeOriginData_icons, _iconDatas_find;
    const requestQuery = (0,data/* useAppRequest */.Vd)(props.request.id);
    const maybeRequestData = (_requestQuery_data = requestQuery.data) === null || _requestQuery_data === void 0 ? void 0 : _requestQuery_data.inner;
    const originQuery = useOrigin(maybeRequestData === null || maybeRequestData === void 0 ? void 0 : maybeRequestData.origin);
    const maybeOriginData = (_originQuery_data = originQuery.data) === null || _originQuery_data === void 0 ? void 0 : _originQuery_data.inner;
    const [iconDatas, setIconDatas] = (0,react.useState)([]);
    const onIconData = (0,react.useCallback)((param)=>{
        let [index, data] = param;
        setIconDatas((iconDatas)=>{
            iconDatas[index] = data;
            return [
                ...iconDatas
            ];
        });
    }, []);
    const open = (0,react.useCallback)(async ()=>{
        if (maybeRequestData == null) return;
        const { id, method, params } = maybeRequestData;
        path_context/* Paths */.nB.go((0,url/* qurl */.d)("/".concat(method, "?id=").concat(id), params));
    }, [
        maybeRequestData
    ]);
    if (maybeOriginData == null) return null;
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        role: "button",
        className: "po-md rounded-xl flex items-center gap-4",
        onClick: open,
        children: [
            (_maybeOriginData_icons = maybeOriginData.icons) === null || _maybeOriginData_icons === void 0 ? void 0 : _maybeOriginData_icons.map((x, i)=>/*#__PURE__*/ (0,jsx_runtime.jsx)(IndexedBlobbyLoader, {
                    index: i,
                    id: x.id,
                    ok: onIconData
                }, x.id)),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "shrink-0",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(ImageWithFallback, {
                    className: "size-10",
                    alt: "icon",
                    src: (_iconDatas_find = iconDatas.find(Boolean)) === null || _iconDatas_find === void 0 ? void 0 : _iconDatas_find.data,
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)(CubeTransparentIcon/* default */.Z, {
                        className: "size-10"
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "grow",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "font-medium",
                        children: maybeOriginData.title
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "text-contrast",
                        children: maybeOriginData.origin
                    })
                ]
            })
        ]
    });
}
function IndexedBlobbyLoader(props) {
    const { index, id, ok } = props;
    const { data } = useBlobby(id);
    (0,react.useEffect)(()=>{
        ok([
            index,
            data === null || data === void 0 ? void 0 : data.inner
        ]);
    }, [
        index,
        data,
        ok
    ]);
    return null;
}

// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/PlusIcon.js
var PlusIcon = __webpack_require__(8680);
// EXTERNAL MODULE: ./src/libs/react/handles/boolean.tsx
var handles_boolean = __webpack_require__(8544);
// EXTERNAL MODULE: ./src/libs/ui/dialog/dialog.tsx
var dialog = __webpack_require__(6488);
// EXTERNAL MODULE: ./src/libs/colors/colors.ts
var colors = __webpack_require__(4231);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/EllipsisHorizontalIcon.js
var EllipsisHorizontalIcon = __webpack_require__(6812);
// EXTERNAL MODULE: ./src/mods/foreground/entities/wallets/avatar.tsx
var avatar = __webpack_require__(3650);
// EXTERNAL MODULE: ./node_modules/@hazae41/option/dist/esm/mods/option/option.mjs
var option_option = __webpack_require__(5316);
// EXTERNAL MODULE: ./src/mods/foreground/entities/seeds/data.tsx
var seeds_data = __webpack_require__(253);
;// CONCATENATED MODULE: ./src/mods/foreground/entities/seeds/context.tsx




const SeedDataContext = /*#__PURE__*/ (0,react.createContext)(undefined);
function useSeedDataContext() {
    return option_option/* Option */.W.unwrap((0,react.useContext)(SeedDataContext));
}
function SeedDataProvider(props) {
    const { uuid, children } = props;
    const seed = (0,seeds_data/* useSeed */.WJ)(uuid);
    if (seed.data == null) return null;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(SeedDataContext.Provider, {
        value: seed.data.inner,
        children: children
    });
}

;// CONCATENATED MODULE: ./src/mods/foreground/entities/seeds/card.tsx






function SeedDataCard() {
    const seed = useSeedDataContext();
    const [color, color2] = colors/* Gradients */.R.get(seed.color);
    const First = /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "flex items-center",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "shrink-0",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(avatar/* WalletIcon */.o, {
                    className: "text-xl",
                    emoji: seed.emoji
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "w-2 grow"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.White */.z.Ej, {
                className: "text-".concat(color),
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)(EllipsisHorizontalIcon/* default */.Z, {
                        className: "size-5"
                    })
                })
            })
        ]
    });
    const Name = /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
        className: "flex items-center text-white font-medium",
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
            className: "truncate",
            children: seed.name
        })
    });
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "po-md w-full aspect-video rounded-xl flex flex-col text-white bg-gradient-to-br from-".concat(color, " to-").concat(color2),
        children: [
            First,
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "grow"
            }),
            Name
        ]
    });
}

// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/DocumentTextIcon.js
var DocumentTextIcon = __webpack_require__(8523);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/SwatchIcon.js
var SwatchIcon = __webpack_require__(341);
// EXTERNAL MODULE: ./src/libs/emojis/emojis.ts
var emojis = __webpack_require__(9912);
// EXTERNAL MODULE: ./src/libs/ledger/index.ts + 9 modules
var ledger = __webpack_require__(6919);
// EXTERNAL MODULE: ./src/libs/modhash/modhash.ts
var modhash_modhash = __webpack_require__(4628);
// EXTERNAL MODULE: ./src/libs/react/events.ts
var events = __webpack_require__(8418);
// EXTERNAL MODULE: ./src/libs/react/ref.ts + 1 modules
var ref = __webpack_require__(4537);
// EXTERNAL MODULE: ./src/libs/ui/input.tsx + 4 modules
var input = __webpack_require__(9607);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/errors.mjs
var result_errors = __webpack_require__(2564);
;// CONCATENATED MODULE: ./src/mods/foreground/entities/seeds/all/create/ledger.tsx

















function LedgerSeedCreatorDialog(props) {
    const { close } = (0,dialog/* useDialogContext */.DA)().unwrap();
    const background = (0,context/* useBackgroundContext */.D_)().unwrap();
    const uuid = (0,ref/* useConstant */.hS)(()=>crypto.randomUUID());
    const modhash = (0,modhash_modhash/* useModhash */.jR)(uuid);
    const color = colors/* Colors */.w.mod(modhash);
    const emoji = emojis/* Emojis */.A.get(modhash);
    const [rawNameInput = "", setRawNameInput] = (0,react.useState)();
    const defNameInput = (0,react.useDeferredValue)(rawNameInput);
    const onNameInputChange = (0,events/* useInputChange */.Xy)((e)=>{
        setRawNameInput(e.currentTarget.value);
    }, []);
    const tryAdd = (0,callback/* useAsyncUniqueCallback */.T)(async ()=>{
        return await result/* Result */.x.unthrow(async (t)=>{
            if (!defNameInput) return new result_err/* Err */.U(new result_errors/* Panic */.F5());
            const device = await ledger/* Ledger.USB.tryConnect */.P.vB.tryConnect().then((r)=>r.throw(t));
            const { address } = await ledger/* Ledger.Ethereum.tryGetAddress */.P.kJ.tryGetAddress(device, "44'/60'/0'/0/0").then((r)=>r.throw(t));
            const seed = {
                type: "ledger",
                uuid,
                name: defNameInput,
                color,
                emoji,
                address
            };
            await background.tryRequest({
                method: "brume_createSeed",
                params: [
                    seed
                ]
            }).then((r)=>r.throw(t).throw(t));
            close();
            return ok.Ok.void();
        }).then(results/* Results */.u.logAndAlert);
    }, [
        defNameInput,
        uuid,
        color,
        emoji,
        background,
        close
    ]);
    const NameInput = /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "flex items-stretch gap-2",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "shrink-0",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(avatar/* WalletAvatar */.G, {
                    className: "size-12 text-2xl",
                    colorIndex: color,
                    emoji: emoji
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)(input/* Input.Contrast */.I.mn, {
                className: "w-full",
                placeholder: "Enter a name",
                value: rawNameInput,
                onChange: onNameInputChange
            })
        ]
    });
    const canAdd = (0,react.useMemo)(()=>{
        if (!defNameInput) return false;
        return true;
    }, [
        defNameInput
    ]);
    const AddButton = /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.Gradient */.z.ph, {
        className: "flex-1 whitespace-nowrap po-md",
        colorIndex: color,
        disabled: !canAdd,
        onClick: tryAdd.run,
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsx)(PlusIcon/* default */.Z, {
                    className: "size-5"
                }),
                "Add"
            ]
        })
    });
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Dialog */.Vq.Title, {
                close: close,
                children: "New seed"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-2"
            }),
            NameInput,
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-8"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "flex items-center flex-wrap-reverse gap-2",
                children: AddButton
            })
        ]
    });
}

// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/KeyIcon.js
var KeyIcon = __webpack_require__(9878);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/LockClosedIcon.js
var LockClosedIcon = __webpack_require__(6186);
// EXTERNAL MODULE: ./src/libs/react/memo.ts + 1 modules
var memo = __webpack_require__(7664);
// EXTERNAL MODULE: ./src/libs/ui/textarea.tsx + 2 modules
var ui_textarea = __webpack_require__(110);
// EXTERNAL MODULE: ./src/libs/webauthn/webauthn.ts
var webauthn = __webpack_require__(299);
// EXTERNAL MODULE: ./node_modules/@hazae41/base64/dist/esm/src/mods/base64/adapter.mjs
var adapter = __webpack_require__(9467);
// EXTERNAL MODULE: ./node_modules/@hazae41/bytes/dist/esm/mods/bytes/bytes.mjs + 3 modules
var bytes = __webpack_require__(1694);
// EXTERNAL MODULE: ./node_modules/@scure/bip39/esm/index.js
var esm = __webpack_require__(4857);
// EXTERNAL MODULE: ./node_modules/@scure/bip39/esm/wordlists/english.js
var english = __webpack_require__(5957);
;// CONCATENATED MODULE: ./src/mods/foreground/entities/seeds/all/create/standalone.tsx

var __addDisposableResource = undefined && undefined.__addDisposableResource || function(env, value, async) {
    if (value !== null && value !== void 0) {
        if (typeof value !== "object" && typeof value !== "function") throw new TypeError("Object expected.");
        var dispose;
        if (async) {
            if (!Symbol.asyncDispose) throw new TypeError("Symbol.asyncDispose is not defined.");
            dispose = value[Symbol.asyncDispose];
        }
        if (dispose === void 0) {
            if (!Symbol.dispose) throw new TypeError("Symbol.dispose is not defined.");
            dispose = value[Symbol.dispose];
        }
        if (typeof dispose !== "function") throw new TypeError("Object not disposable.");
        env.stack.push({
            value: value,
            dispose: dispose,
            async: async
        });
    } else if (async) {
        env.stack.push({
            async: true
        });
    }
    return value;
};
var __disposeResources = undefined && undefined.__disposeResources || function(SuppressedError1) {
    return function(env) {
        function fail(e) {
            env.error = env.hasError ? new SuppressedError1(e, env.error, "An error was suppressed during disposal.") : e;
            env.hasError = true;
        }
        function next() {
            while(env.stack.length){
                var rec = env.stack.pop();
                try {
                    var result = rec.dispose && rec.dispose.call(rec.value);
                    if (rec.async) return Promise.resolve(result).then(next, function(e) {
                        fail(e);
                        return next();
                    });
                } catch (e) {
                    fail(e);
                }
            }
            if (env.hasError) throw env.error;
        }
        return next();
    };
}(typeof SuppressedError === "function" ? SuppressedError : function(error, suppressed, message) {
    var e = new Error(message);
    return e.name = "SuppressedError", e.error = error, e.suppressed = suppressed, e;
});






















function StandaloneSeedCreatorDialog(props) {
    const { close } = (0,dialog/* useDialogContext */.DA)().unwrap();
    const background = (0,context/* useBackgroundContext */.D_)().unwrap();
    const uuid = (0,ref/* useConstant */.hS)(()=>crypto.randomUUID());
    const modhash = (0,modhash_modhash/* useModhash */.jR)(uuid);
    const color = colors/* Colors */.w.mod(modhash);
    const emoji = emojis/* Emojis */.A.get(modhash);
    const [rawNameInput = "", setRawNameInput] = (0,react.useState)();
    const defNameInput = (0,react.useDeferredValue)(rawNameInput);
    const onNameInputChange = (0,events/* useInputChange */.Xy)((e)=>{
        setRawNameInput(e.currentTarget.value);
    }, []);
    const [rawPhraseInput = "", setRawPhraseInput] = (0,react.useState)();
    const defPhraseInput = (0,react.useDeferredValue)(rawPhraseInput);
    const onInputChange = (0,events/* useTextAreaChange */.aN)((e)=>{
        setRawPhraseInput(e.currentTarget.value);
    }, []);
    const doGenerate12 = (0,callback/* useAsyncUniqueCallback */.T)(async ()=>{
        setRawPhraseInput((0,esm/* generateMnemonic */.OF)(english/* wordlist */.U, 128));
    }, []);
    const doGenerate24 = (0,callback/* useAsyncUniqueCallback */.T)(async ()=>{
        setRawPhraseInput((0,esm/* generateMnemonic */.OF)(english/* wordlist */.U, 256));
    }, []);
    const tryAddUnauthenticated = (0,callback/* useAsyncUniqueCallback */.T)(async ()=>{
        return await result/* Result */.x.unthrow(async (t)=>{
            if (!defNameInput) return new result_err/* Err */.U(new result_errors/* Panic */.F5());
            if (!defPhraseInput) return new result_err/* Err */.U(new result_errors/* Panic */.F5());
            if (!confirm("Did you backup your seed phrase?")) return ok.Ok.void();
            const seed = {
                type: "mnemonic",
                uuid,
                name: defNameInput,
                color,
                emoji,
                mnemonic: defPhraseInput
            };
            await background.tryRequest({
                method: "brume_createSeed",
                params: [
                    seed
                ]
            }).then((r)=>r.throw(t).throw(t));
            close();
            return ok.Ok.void();
        }).then(results/* Results */.u.logAndAlert);
    }, [
        defNameInput,
        defPhraseInput,
        uuid,
        color,
        emoji,
        background,
        close
    ]);
    const triedEncryptedPhrase = (0,memo/* useAsyncReplaceMemo */.EY)(async ()=>{
        return await result/* Result */.x.unthrow(async (t)=>{
            if (!defNameInput) return new result_err/* Err */.U(new result_errors/* Panic */.F5());
            if (!defPhraseInput) return new result_err/* Err */.U(new result_errors/* Panic */.F5());
            try {
                const entropyBytes = (0,esm/* mnemonicToEntropy */.oy)(defPhraseInput, english/* wordlist */.U);
                const entropyBase64 = adapter/* get */.U().tryEncodePadded(entropyBytes).throw(t);
                const [ivBase64, cipherBase64] = await background.tryRequest({
                    method: "brume_encrypt",
                    params: [
                        entropyBase64
                    ]
                }).then((r)=>r.throw(t).throw(t));
                return new ok.Ok([
                    ivBase64,
                    cipherBase64
                ]);
            } catch (e) {
                return new result_err/* Err */.U(new result_errors/* Panic */.F5());
            }
        });
    }, [
        defNameInput,
        defPhraseInput,
        background
    ]);
    const [id, setId] = (0,react.useState)();
    (0,react.useEffect)(()=>{
        setId(undefined);
    }, [
        defPhraseInput
    ]);
    const tryAddAuthenticated1 = (0,callback/* useAsyncUniqueCallback */.T)(async ()=>{
        return await result/* Result */.x.unthrow(async (t)=>{
            if (!defNameInput) return new result_err/* Err */.U(new result_errors/* Panic */.F5());
            if (!defPhraseInput) return new result_err/* Err */.U(new result_errors/* Panic */.F5());
            if (triedEncryptedPhrase == null) return new result_err/* Err */.U(new result_errors/* Panic */.F5());
            if (!confirm("Did you backup your seed phrase?")) return ok.Ok.void();
            const [_, cipherBase64] = triedEncryptedPhrase.throw(t);
            const cipher = adapter/* get */.U().tryDecodePadded(cipherBase64).throw(t).copyAndDispose();
            const id = await webauthn/* WebAuthnStorage */.g.tryCreate(defNameInput, cipher).then((r)=>r.throw(t));
            setId(id);
            return ok.Ok.void();
        }).then(results/* Results */.u.logAndAlert);
    }, [
        defNameInput,
        defPhraseInput,
        triedEncryptedPhrase,
        uuid,
        color,
        emoji,
        background
    ]);
    const tryAddAuthenticated2 = (0,callback/* useAsyncUniqueCallback */.T)(async ()=>{
        return await result/* Result */.x.unthrow(async (t)=>{
            const env_1 = {
                stack: [],
                error: void 0,
                hasError: false
            };
            try {
                if (!defNameInput) return new result_err/* Err */.U(new result_errors/* Panic */.F5());
                if (!defPhraseInput) return new result_err/* Err */.U(new result_errors/* Panic */.F5());
                if (id == null) return new result_err/* Err */.U(new result_errors/* Panic */.F5());
                if (triedEncryptedPhrase == null) return new result_err/* Err */.U(new result_errors/* Panic */.F5());
                const [ivBase64, cipherBase64] = triedEncryptedPhrase.throw(t);
                const cipherSlice = __addDisposableResource(env_1, adapter/* get */.U().tryDecodePadded(cipherBase64).throw(t), false);
                const cipherBytes2 = await webauthn/* WebAuthnStorage */.g.tryGet(id).then((r)=>r.throw(t));
                if (!bytes/* Bytes */.J.equals(cipherSlice.bytes, cipherBytes2)) return new result_err/* Err */.U(new webauthn/* WebAuthnStorageError */.$());
                const idBase64 = adapter/* get */.U().tryEncodePadded(id).throw(t);
                const mnemonic = {
                    ivBase64,
                    idBase64
                };
                const seed = {
                    type: "authMnemonic",
                    uuid,
                    name: defNameInput,
                    color,
                    emoji,
                    mnemonic
                };
                await background.tryRequest({
                    method: "brume_createSeed",
                    params: [
                        seed
                    ]
                }).then((r)=>r.throw(t).throw(t));
                close();
                return ok.Ok.void();
            } catch (e_1) {
                env_1.error = e_1;
                env_1.hasError = true;
            } finally{
                __disposeResources(env_1);
            }
        }).then(results/* Results */.u.logAndAlert);
    }, [
        defNameInput,
        defPhraseInput,
        id,
        triedEncryptedPhrase,
        uuid,
        color,
        emoji,
        background,
        close
    ]);
    const NameInput = /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "flex items-stretch gap-2",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "shrink-0",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(avatar/* WalletAvatar */.G, {
                    className: "size-12 text-2xl",
                    colorIndex: color,
                    emoji: emoji
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)(input/* Input.Contrast */.I.mn, {
                className: "w-full",
                placeholder: "Enter a name",
                value: rawNameInput,
                onChange: onNameInputChange
            })
        ]
    });
    const PhraseInput = /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_textarea/* Textarea.Contrast */.g.m, {
        className: "w-full resize-none",
        placeholder: "Enter your seed phrase",
        value: rawPhraseInput,
        onChange: onInputChange,
        rows: 4
    });
    const Generate12Button = /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.Contrast */.z.mn, {
        className: "flex-1 whitespace-nowrap po-md",
        onClick: doGenerate12.run,
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsx)(KeyIcon/* default */.Z, {
                    className: "size-5"
                }),
                "Generate 12 random words"
            ]
        })
    });
    const Generate24Button = /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.Gradient */.z.ph, {
        className: "flex-1 whitespace-nowrap po-md",
        colorIndex: color,
        onClick: doGenerate24.run,
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsx)(KeyIcon/* default */.Z, {
                    className: "size-5"
                }),
                "Generate 24 random words"
            ]
        })
    });
    const canAdd = (0,react.useMemo)(()=>{
        if (!defNameInput) return false;
        if (!(0,esm/* validateMnemonic */._I)(defPhraseInput, english/* wordlist */.U)) return false;
        return true;
    }, [
        defNameInput,
        defPhraseInput
    ]);
    const AddUnauthButton = /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.Contrast */.z.mn, {
        className: "flex-1 whitespace-nowrap po-md",
        disabled: !canAdd,
        onClick: tryAddUnauthenticated.run,
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsx)(PlusIcon/* default */.Z, {
                    className: "size-5"
                }),
                "Add without authentication"
            ]
        })
    });
    const AddAuthButton1 = /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.Gradient */.z.ph, {
        className: "flex-1 whitespace-nowrap po-md",
        colorIndex: color,
        disabled: !canAdd,
        onClick: tryAddAuthenticated1.run,
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsx)(LockClosedIcon/* default */.Z, {
                    className: "size-5"
                }),
                "Add with authentication"
            ]
        })
    });
    const AddAuthButton2 = /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.Gradient */.z.ph, {
        className: "flex-1 whitespace-nowrap po-md",
        colorIndex: color,
        disabled: !canAdd,
        onClick: tryAddAuthenticated2.run,
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsx)(LockClosedIcon/* default */.Z, {
                    className: "size-5"
                }),
                "Add with authentication (1/2)"
            ]
        })
    });
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Dialog */.Vq.Title, {
                close: close,
                children: "New seed"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-2"
            }),
            NameInput,
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-8"
            }),
            PhraseInput,
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "flex items-center flex-wrap-reverse gap-2",
                children: [
                    Generate12Button,
                    Generate24Button
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-8"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "flex items-center flex-wrap-reverse gap-2",
                children: [
                    AddUnauthButton,
                    id == null ? AddAuthButton1 : AddAuthButton2
                ]
            })
        ]
    });
}

;// CONCATENATED MODULE: ./src/mods/foreground/entities/seeds/all/create/index.tsx











function SeedCreatorDialog(props) {
    const { opened, close } = (0,dialog/* useDialogContext */.DA)().unwrap();
    const { url } = (0,path_context/* usePathContext */.td)().unwrap();
    const background = (0,context/* useBackgroundContext */.D_)().unwrap();
    const [type, setType] = (0,react.useState)();
    const onLedgerClick = (0,react.useCallback)(async ()=>{
        return result/* Result */.x.unthrow(async (t)=>{
            if (location.pathname !== "/" && location.pathname !== "/index.html") {
                await background.tryRequest({
                    method: "brume_open",
                    params: [
                        url.pathname
                    ]
                }).then((r)=>r.throw(t).throw(t));
                return ok.Ok.void();
            }
            setType("ledger");
            return ok.Ok.void();
        }).then(results/* Results */.u.logAndAlert);
    }, [
        url,
        background
    ]);
    const onMnemonicClick = (0,react.useCallback)(()=>{
        setType("mnemonic");
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Dialog */.Vq, {
                opened: opened && type === "mnemonic",
                close: close,
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(StandaloneSeedCreatorDialog, {})
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Dialog */.Vq, {
                opened: opened && type === "ledger",
                close: close,
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(LedgerSeedCreatorDialog, {})
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Dialog */.Vq.Title, {
                close: close,
                children: "New seed"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-2"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "w-full flex items-center gap-2",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.Contrast */.z.mn, {
                        className: "flex-1 whitespace-nowrap p-4 rounded-xl",
                        onClick: onMnemonicClick,
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "".concat(ui_button/* Button.Shrinker */.z.Np.className, " flex-col"),
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)(DocumentTextIcon/* default */.Z, {
                                    className: "size-6"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                    children: "Mnemonic phrase"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.Contrast */.z.mn, {
                        className: "flex-1 whitespace-nowrap p-4 rounded-xl",
                        onClick: onLedgerClick,
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "".concat(ui_button/* Button.Shrinker */.z.Np.className, " flex-col"),
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)(SwatchIcon/* default */.Z, {
                                    className: "size-6"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                    children: "Ledger"
                                })
                            ]
                        })
                    })
                ]
            })
        ]
    });
}

;// CONCATENATED MODULE: ./src/mods/foreground/entities/seeds/all/page.tsx













function SeedsPage() {
    var _seedsQuery_data;
    const seedsQuery = (0,seeds_data/* useSeeds */.Eu)();
    const maybeSeeds = (_seedsQuery_data = seedsQuery.data) === null || _seedsQuery_data === void 0 ? void 0 : _seedsQuery_data.inner;
    const creator = (0,handles_boolean/* useBooleanHandle */.x)(false);
    const onSeedClick = (0,react.useCallback)((seed)=>{
        path_context/* Paths */.nB.go("/seed/".concat(seed.uuid));
    }, []);
    const Body = /*#__PURE__*/ (0,jsx_runtime.jsx)(header/* PageBody */.xV, {
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(ClickableSeedGrid, {
            ok: onSeedClick,
            create: creator.enable,
            maybeSeeds: maybeSeeds
        })
    });
    const Header = /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(header/* UserPageHeader */.To, {
                title: "Seeds",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.Base */.z.XY, {
                    className: "size-8 hovered-or-clicked-or-focused:scale-105 !transition",
                    onClick: creator.enable,
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(PlusIcon/* default */.Z, {
                            className: "size-5"
                        })
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "po-md flex items-center",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "text-contrast",
                    children: "Seeds allow you to generate wallets from a single secret. You can import a seed from a mnemonic phrase or connect a hardware wallet."
                })
            })
        ]
    });
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(page/* Page */.T, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Dialog */.Vq, {
                opened: creator.current,
                close: creator.disable,
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(SeedCreatorDialog, {})
            }),
            Header,
            Body
        ]
    });
}
function ClickableSeedGrid(props) {
    const { ok, create, maybeSeeds } = props;
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "grid grow place-content-start place-items-center gap-2 grid-cols-[repeat(auto-fill,minmax(10rem,1fr))]",
        children: [
            maybeSeeds === null || maybeSeeds === void 0 ? void 0 : maybeSeeds.map((seed)=>/*#__PURE__*/ (0,jsx_runtime.jsx)(SeedDataProvider, {
                    uuid: seed.uuid,
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)(ClickableSeedDataCard, {
                        ok: ok
                    })
                }, seed.uuid)),
            /*#__PURE__*/ (0,jsx_runtime.jsx)(NewSeedCard, {
                ok: create
            })
        ]
    });
}
function ClickableSeedDataCard(props) {
    const seed = useSeedDataContext();
    const { ok } = props;
    const onClick = (0,react.useCallback)(()=>{
        ok(seed);
    }, [
        ok,
        seed
    ]);
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
        className: "w-full hovered-or-clicked-or-focused:scale-105 !transition-transform",
        onClick: onClick,
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(SeedDataCard, {})
    });
}
function NewSeedCard(props) {
    const { ok } = props;
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("button", {
        className: "po-md w-full aspect-video rounded-xl flex gap-2 justify-center items-center border border-contrast border-dashed hovered-or-clicked-or-focused:scale-105 !transition-transform",
        onClick: ok,
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(PlusIcon/* default */.Z, {
                className: "size-5"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "font-medium",
                children: "New seed"
            })
        ]
    });
}

// EXTERNAL MODULE: ./src/libs/errors/errors.ts
var errors_errors = __webpack_require__(8524);
// EXTERNAL MODULE: ./src/mods/background/service_worker/entities/seeds/data.tsx
var entities_seeds_data = __webpack_require__(2267);
// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/types/zerohex/index.mjs
var zerohex = __webpack_require__(6113);
// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/types/address/index.mjs
var types_address = __webpack_require__(7657);
// EXTERNAL MODULE: ./node_modules/@noble/curves/esm/secp256k1.js + 5 modules
var secp256k1 = __webpack_require__(7835);
// EXTERNAL MODULE: ./node_modules/@scure/bip32/lib/esm/index.js + 15 modules
var lib_esm = __webpack_require__(1141);
// EXTERNAL MODULE: ./src/mods/foreground/entities/seeds/all/helpers.tsx + 1 modules
var helpers = __webpack_require__(5867);
;// CONCATENATED MODULE: ./src/mods/foreground/entities/wallets/all/create/seeded.tsx


























function SeededWalletCreatorDialog(props) {
    const { close } = (0,dialog/* useDialogContext */.DA)().unwrap();
    const background = (0,context/* useBackgroundContext */.D_)().unwrap();
    const seedData = useSeedDataContext();
    const uuid = (0,ref/* useConstant */.hS)(()=>crypto.randomUUID());
    const modhash = (0,modhash_modhash/* useModhash */.jR)(uuid);
    const color = colors/* Colors */.w.mod(modhash);
    const emoji = emojis/* Emojis */.A.get(modhash);
    const [rawNameInput = "", setRawNameInput] = (0,react.useState)();
    const defNameInput = (0,react.useDeferredValue)(rawNameInput);
    const onNameInputChange = (0,events/* useInputChange */.Xy)((e)=>{
        setRawNameInput(e.currentTarget.value);
    }, []);
    const [rawPathInput = "", setRawPathInput] = (0,react.useState)("m/44'/60'/0'/0/0");
    const defPathInput = (0,react.useDeferredValue)(rawPathInput);
    const onPathInputChange = (0,events/* useInputChange */.Xy)((e)=>{
        setRawPathInput(e.currentTarget.value);
    }, []);
    const [coin, setCoin] = (0,react.useState)("eth");
    const onCoinChange = (0,react.useCallback)((e)=>{
        setCoin(e.currentTarget.value);
    }, []);
    const [app, setApp] = (0,react.useState)("metamask");
    const onAppChange = (0,react.useCallback)((e)=>{
        setApp(e.currentTarget.value);
    }, []);
    const [rawIndexInput = "", setRawIndexInput] = (0,react.useState)("0");
    const defIndexInput = (0,react.useDeferredValue)(rawIndexInput);
    const onIndexInputChange = (0,events/* useInputChange */.Xy)((e)=>{
        setRawIndexInput(e.currentTarget.value);
    }, [
        coin,
        app
    ]);
    (0,react.useEffect)(()=>{
        if (coin === "custom") return setRawPathInput("m/44'/60'/0'/0/0");
        const rawCoin = coin === "eth" ? "60" : "61";
        if (app === "custom") return setRawPathInput("m/44'/".concat(rawCoin, "'/0'/0/0"));
        const rawInput = Number(defIndexInput).toFixed();
        if (app === "ledger") return setRawPathInput("m/44'/".concat(rawCoin, "'/").concat(rawInput, "'/0/0"));
        if (app === "metamask") return setRawPathInput("m/44'/".concat(rawCoin, "'/0'/0/").concat(rawInput));
    }, [
        coin,
        app,
        defIndexInput
    ]);
    const canAdd = (0,react.useMemo)(()=>{
        if (!defNameInput) return false;
        if (!defPathInput) return false;
        return true;
    }, [
        defNameInput,
        defPathInput
    ]);
    const tryAdd = (0,callback/* useAsyncUniqueCallback */.T)(async ()=>{
        return await result/* Result */.x.unthrow(async (t)=>{
            if (!defNameInput) return new result_err/* Err */.U(new result_errors/* Panic */.F5());
            if (seedData.type === "ledger") {
                const device = await ledger/* Ledger.USB.tryConnect */.P.vB.tryConnect().then((r)=>r.mapErrSync((cause)=>{
                        return new errors_errors/* UIError */.m("Could not connect to the device", {
                            cause
                        });
                    }).throw(t));
                const { address } = await ledger/* Ledger.Ethereum.tryGetAddress */.P.kJ.tryGetAddress(device, defPathInput.slice(2)).then((r)=>r.mapErrSync((cause)=>{
                        return new errors_errors/* UIError */.m("Could not get the address of the device", {
                            cause
                        });
                    }).throw(t));
                if (!zerohex/* ZeroHexString */.T.is(address)) return new result_err/* Err */.U(new errors_errors/* UIError */.m("Could not get the address of the device"));
                const seed = entities_seeds_data/* SeedRef */.M.from(seedData);
                const wallet = {
                    coin: "ethereum",
                    type: "seeded",
                    uuid,
                    name: defNameInput,
                    color,
                    emoji,
                    address,
                    seed,
                    path: defPathInput
                };
                await background.tryRequest({
                    method: "brume_createWallet",
                    params: [
                        wallet
                    ]
                }).then((r)=>r.mapErrSync((cause)=>{
                        return new errors_errors/* UIError */.m("Could not communicate with the backend", {
                            cause
                        });
                    }).throw(t).mapErrSync((cause)=>{
                        return new errors_errors/* UIError */.m("Could not create the wallet", {
                            cause
                        });
                    }).throw(t));
            } else {
                const instance = await helpers/* SeedInstance */.Gz.tryFrom(seedData, background).then((r)=>r.get());
                const mnemonic = await instance.tryGetMnemonic(background).then((r)=>r.mapErrSync((cause)=>{
                        return new errors_errors/* UIError */.m("Could not get mnemonic", {
                            cause
                        });
                    }).throw(t));
                const masterSeed = await result/* Result */.x.runAndDoubleWrap(async ()=>{
                    return await (0,esm/* mnemonicToSeed */.OI)(mnemonic);
                }).then((r)=>r.throw(t));
                const root = result/* Result */.x.runAndDoubleWrapSync(()=>{
                    return lib_esm/* HDKey */.B.fromMasterSeed(masterSeed);
                }).throw(t);
                const child = result/* Result */.x.runAndWrapSync(()=>{
                    return root.derive(defPathInput);
                }).mapErrSync((cause)=>{
                    return new errors_errors/* UIError */.m("Invalid derivation path", {
                        cause
                    });
                }).throw(t);
                const privateKeyBytes = option_option/* Option */.W.wrap(child.privateKey).ok().throw(t);
                const uncompressedPublicKeyBytes = secp256k1/* secp256k1 */.kA.getPublicKey(privateKeyBytes, false);
                const address = types_address/* Address */.k.compute(uncompressedPublicKeyBytes);
                const seed = entities_seeds_data/* SeedRef */.M.from(seedData);
                const wallet = {
                    coin: "ethereum",
                    type: "seeded",
                    uuid,
                    name: defNameInput,
                    color,
                    emoji,
                    address,
                    seed,
                    path: defPathInput
                };
                await background.tryRequest({
                    method: "brume_createWallet",
                    params: [
                        wallet
                    ]
                }).then((r)=>r.mapErrSync((cause)=>{
                        return new errors_errors/* UIError */.m("Could not communicate with the backend", {
                            cause
                        });
                    }).throw(t).mapErrSync((cause)=>{
                        return new errors_errors/* UIError */.m("Could not create the wallet", {
                            cause
                        });
                    }).throw(t));
            }
            close();
            return ok.Ok.void();
        }).then(results/* Results */.u.logAndAlert);
    }, [
        defNameInput,
        defPathInput,
        seedData,
        defPathInput,
        uuid,
        color,
        emoji,
        background,
        close
    ]);
    const NameInput = /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "flex items-stretch gap-2",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "shrink-0",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(avatar/* WalletAvatar */.G, {
                    className: "size-12 text-2xl",
                    colorIndex: color,
                    emoji: emoji
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)(input/* Input.Contrast */.I.mn, {
                className: "w-full",
                placeholder: "Enter a name",
                value: rawNameInput,
                onChange: onNameInputChange
            })
        ]
    });
    const PathInput = /*#__PURE__*/ (0,jsx_runtime.jsx)(input/* Input.Contrast */.I.mn, {
        className: "w-full",
        placeholder: "m/44'/60'/0'/0/0",
        value: rawPathInput,
        onChange: onPathInputChange
    });
    const IndexInput = /*#__PURE__*/ (0,jsx_runtime.jsx)(input/* Input.Contrast */.I.mn, {
        className: "w-full",
        placeholder: "0",
        type: "number",
        min: 0,
        value: rawIndexInput,
        onChange: onIndexInputChange
    });
    const AddButon = /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.Gradient */.z.ph, {
        className: "grow po-md",
        colorIndex: color,
        disabled: !defNameInput || !canAdd,
        onClick: tryAdd.run,
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsx)(PlusIcon/* default */.Z, {
                    className: "size-5"
                }),
                "Add"
            ]
        })
    });
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Dialog */.Vq.Title, {
                close: close,
                children: "New wallet"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-2"
            }),
            NameInput,
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-4"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "font-medium",
                children: "Choose an account type"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-2"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("select", {
                className: "",
                value: coin,
                onChange: onCoinChange,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("option", {
                        value: "eth",
                        children: "Ethereum"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("option", {
                        value: "etc",
                        children: "Ethereum Classic"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("option", {
                        value: "custom",
                        children: "Other"
                    })
                ]
            }),
            coin === "custom" && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-4"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "font-medium",
                        children: "Choose a derivation path"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-2"
                    }),
                    PathInput
                ]
            }),
            coin !== "custom" && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-2"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("select", {
                        value: app,
                        onChange: onAppChange,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("option", {
                                value: "metamask",
                                children: "MetaMask"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("option", {
                                value: "ledger",
                                children: "Ledger Live"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("option", {
                                value: "custom",
                                children: "Other"
                            })
                        ]
                    }),
                    app === "custom" && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "h-4"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "font-medium",
                                children: "Choose a derivation path"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "h-2"
                            }),
                            PathInput
                        ]
                    }),
                    app !== "custom" && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "h-4"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "font-medium",
                                children: "Choose an account index"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "h-2"
                            }),
                            IndexInput,
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "h-2"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "text-contrast",
                                children: [
                                    "Your derivation path will be ",
                                    rawPathInput
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-8"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "flex items-center flex-wrap-reverse gap-2",
                children: AddButon
            })
        ]
    });
}

// EXTERNAL MODULE: ./src/mods/foreground/entities/wallets/all/page.tsx
var all_page = __webpack_require__(200);
// EXTERNAL MODULE: ./src/mods/foreground/entities/wallets/data.ts
var wallets_data = __webpack_require__(9327);
;// CONCATENATED MODULE: ./src/mods/foreground/entities/seeds/page.tsx
/* eslint-disable @next/next/no-img-element */ 











function SeedPage(props) {
    const { uuid } = props;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(SeedDataProvider, {
        uuid: uuid,
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(SeedDataPage, {})
    });
}
function SeedDataPage() {
    var _walletsQuery_data;
    const seed = useSeedDataContext();
    const walletsQuery = (0,wallets_data/* useWalletsBySeed */.QB)(seed.uuid);
    const maybeWallets = (_walletsQuery_data = walletsQuery.data) === null || _walletsQuery_data === void 0 ? void 0 : _walletsQuery_data.inner;
    const creator = (0,handles_boolean/* useBooleanHandle */.x)(false);
    const onBackClick = (0,react.useCallback)(()=>{
        path_context/* Paths */.nB.go("/seeds");
    }, []);
    const onWalletClick = (0,react.useCallback)((wallet)=>{
        path_context/* Paths */.nB.go("/wallet/".concat(wallet.uuid));
    }, []);
    const Header = /*#__PURE__*/ (0,jsx_runtime.jsx)(header/* UserPageHeader */.To, {
        title: "Seed",
        back: onBackClick
    });
    const Card = /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
        className: "p-4 flex justify-center",
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
            className: "w-full max-w-sm",
            children: /*#__PURE__*/ (0,jsx_runtime.jsx)(SeedDataCard, {})
        })
    });
    const Body = /*#__PURE__*/ (0,jsx_runtime.jsx)(header/* PageBody */.xV, {
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(all_page/* ClickableWalletGrid */.oS, {
            ok: onWalletClick,
            create: creator.enable,
            wallets: maybeWallets
        })
    });
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(page/* Page */.T, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Dialog */.Vq, {
                opened: creator.current,
                close: creator.disable,
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(SeededWalletCreatorDialog, {})
            }),
            Header,
            Card,
            Body
        ]
    });
}

// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/EllipsisVerticalIcon.js
var EllipsisVerticalIcon = __webpack_require__(787);
// EXTERNAL MODULE: ./src/mods/foreground/entities/sessions/data.ts + 1 modules
var sessions_data = __webpack_require__(5743);
;// CONCATENATED MODULE: ./src/mods/background/service_worker/entities/sessions/status/data.ts

var Status;
(function(Status) {
    function key(id) {
        return "session/status/v4/".concat(id);
    }
    Status.key = key;
    function schema(id) {
        return (0,query/* createQuery */.rP)({
            key: key(id)
        });
    }
    Status.schema = schema;
})(Status || (Status = {}));

;// CONCATENATED MODULE: ./src/mods/foreground/entities/sessions/status/data.ts




function getStatus(id, storage) {
    if (id == null) return undefined;
    return (0,query/* createQuery */.rP)({
        key: Status.key(id),
        storage
    });
}
function useStatus(id) {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(getStatus, [
        id,
        storage
    ]);
    (0,storage_storage/* useSubscribe */.Q)(query, storage);
    return query;
}

;// CONCATENATED MODULE: ./src/mods/foreground/entities/sessions/all/data.ts



function getPersistentSessions(storage) {
    return (0,query/* createQuery */.rP)({
        key: "persistentSessions/v2",
        storage
    });
}
function usePersistentSessions() {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(getPersistentSessions, [
        storage
    ]);
    (0,storage_storage/* useSubscribe */.Q)(query, storage);
    return query;
}
function getTemporarySessions(storage) {
    return (0,query/* createQuery */.rP)({
        key: "temporarySessions/v2",
        storage
    });
}
function useTemporarySessions() {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(getTemporarySessions, [
        storage
    ]);
    (0,storage_storage/* useSubscribe */.Q)(query, storage);
    return query;
}

;// CONCATENATED MODULE: ./src/mods/foreground/entities/sessions/all/page.tsx
/* eslint-disable @next/next/no-img-element */ 
















function SessionsPage() {
    var _tempSessionsQuery_data, _persSessionsQuery_data;
    const background = (0,context/* useBackgroundContext */.D_)().unwrap();
    const tempSessionsQuery = useTemporarySessions();
    const maybeTempSessions = (_tempSessionsQuery_data = tempSessionsQuery.data) === null || _tempSessionsQuery_data === void 0 ? void 0 : _tempSessionsQuery_data.inner;
    const persSessionsQuery = usePersistentSessions();
    const maybePersSessions = (_persSessionsQuery_data = persSessionsQuery.data) === null || _persSessionsQuery_data === void 0 ? void 0 : _persSessionsQuery_data.inner;
    const length = (0,react.useMemo)(()=>{
        const temp = (maybeTempSessions === null || maybeTempSessions === void 0 ? void 0 : maybeTempSessions.length) || 0;
        const pers = (maybePersSessions === null || maybePersSessions === void 0 ? void 0 : maybePersSessions.length) || 0;
        return temp + pers;
    }, [
        maybeTempSessions,
        maybePersSessions
    ]);
    const tryDisconnectAll = (0,callback/* useAsyncUniqueCallback */.T)(async ()=>{
        return await result/* Result */.x.unthrow(async (t)=>{
            if (!confirm("Do you want to disconnect all sessions?")) return ok.Ok.void();
            for (const session of option_option/* Option */.W.wrap(maybeTempSessions).unwrapOr([]))await background.tryRequest({
                method: "brume_disconnect",
                params: [
                    session.id
                ]
            }).then((r)=>r.throw(t).throw(t));
            for (const session of option_option/* Option */.W.wrap(maybePersSessions).unwrapOr([]))await background.tryRequest({
                method: "brume_disconnect",
                params: [
                    session.id
                ]
            }).then((r)=>r.throw(t).throw(t));
            return ok.Ok.void();
        }).then(results/* Results */.u.logAndAlert);
    }, [
        background,
        maybePersSessions
    ]);
    const Body = /*#__PURE__*/ (0,jsx_runtime.jsx)(header/* PageBody */.xV, {
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "flex flex-col gap-2",
            children: [
                maybeTempSessions === null || maybeTempSessions === void 0 ? void 0 : maybeTempSessions.map((session)=>/*#__PURE__*/ (0,jsx_runtime.jsx)(SessionRow, {
                        session: session
                    }, session.id)),
                maybePersSessions === null || maybePersSessions === void 0 ? void 0 : maybePersSessions.map((session)=>/*#__PURE__*/ (0,jsx_runtime.jsx)(SessionRow, {
                        session: session
                    }, session.id))
            ]
        })
    });
    const Header = /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(header/* UserPageHeader */.To, {
                title: "Sessions",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.Base */.z.XY, {
                    className: "size-8 hovered-or-clicked-or-focused:scale-105 !transition",
                    disabled: tryDisconnectAll.loading || !length,
                    onClick: tryDisconnectAll.run,
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(TrashIcon/* default */.Z, {
                            className: "size-5"
                        })
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "po-md flex items-center",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "text-contrast",
                    children: "Sessions allow you to connect to applications. These applications can then make requests for you to approve."
                })
            })
        ]
    });
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(page/* Page */.T, {
        children: [
            Header,
            Body
        ]
    });
}
function SessionRow(props) {
    var _sessionQuery_data, _originQuery_data, _statusQuery_data, _maybeOriginData_icons, _iconDatas_find;
    const background = (0,context/* useBackgroundContext */.D_)().unwrap();
    const sessionQuery = (0,sessions_data/* useSession */.k)(props.session.id);
    const maybeSessionData = (_sessionQuery_data = sessionQuery.data) === null || _sessionQuery_data === void 0 ? void 0 : _sessionQuery_data.inner;
    const originQuery = useOrigin(maybeSessionData === null || maybeSessionData === void 0 ? void 0 : maybeSessionData.origin);
    const maybeOriginData = (_originQuery_data = originQuery.data) === null || _originQuery_data === void 0 ? void 0 : _originQuery_data.inner;
    const statusQuery = useStatus(props.session.id);
    const maybeStatusData = (_statusQuery_data = statusQuery.data) === null || _statusQuery_data === void 0 ? void 0 : _statusQuery_data.inner;
    const [iconDatas, setIconDatas] = (0,react.useState)([]);
    const onIconData = (0,react.useCallback)((param)=>{
        let [index, data] = param;
        setIconDatas((iconDatas)=>{
            iconDatas[index] = data;
            return [
                ...iconDatas
            ];
        });
    }, []);
    const tryDisconnect = (0,callback/* useAsyncUniqueCallback */.T)(async ()=>{
        return await result/* Result */.x.unthrow(async (t)=>{
            if (maybeSessionData == null) return ok.Ok.void();
            if (!confirm("Do you want to disconnect this session?")) return ok.Ok.void();
            await background.tryRequest({
                method: "brume_disconnect",
                params: [
                    maybeSessionData.id
                ]
            }).then((r)=>r.throw(t).throw(t));
            return ok.Ok.void();
        }).then(results/* Results */.u.logAndAlert);
    }, [
        background,
        maybeSessionData
    ]);
    if (maybeOriginData == null) return null;
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        role: "button",
        className: "po-md rounded-xl flex items-center gap-4",
        onClick: tryDisconnect.run,
        children: [
            (_maybeOriginData_icons = maybeOriginData.icons) === null || _maybeOriginData_icons === void 0 ? void 0 : _maybeOriginData_icons.map((x, i)=>/*#__PURE__*/ (0,jsx_runtime.jsx)(page_IndexedBlobbyLoader, {
                    index: i,
                    id: x.id,
                    ok: onIconData
                }, x.id)),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "relative shrink-0",
                children: [
                    (()=>{
                        if (maybeStatusData == null) return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "absolute top-0 -right-2 bg-blue-400 rounded-full w-2 h-2"
                        });
                        if (maybeStatusData.error == null) return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "absolute top-0 -right-2 bg-green-400 rounded-full w-2 h-2"
                        });
                        return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "absolute top-0 -right-2 bg-red-400 rounded-full w-2 h-2"
                        });
                    })(),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(ImageWithFallback, {
                        className: "size-10",
                        alt: "icon",
                        src: (_iconDatas_find = iconDatas.find(Boolean)) === null || _iconDatas_find === void 0 ? void 0 : _iconDatas_find.data,
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(CubeTransparentIcon/* default */.Z, {
                            className: "size-10"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "grow",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "font-medium",
                        children: maybeOriginData.title
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "text-contrast",
                        children: maybeOriginData.origin
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.Base */.z.XY, {
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)(EllipsisVerticalIcon/* default */.Z, {
                        className: "size-5"
                    })
                })
            })
        ]
    });
}
function page_IndexedBlobbyLoader(props) {
    const { index, id, ok } = props;
    const { data } = useBlobby(id);
    (0,react.useEffect)(()=>{
        ok([
            index,
            data === null || data === void 0 ? void 0 : data.inner
        ]);
    }, [
        index,
        data,
        ok
    ]);
    return null;
}

// EXTERNAL MODULE: ./src/libs/ui/anchor/anchor.tsx
var anchor_anchor = __webpack_require__(9240);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/fetched/data.mjs
var fetched_data = __webpack_require__(8123);
// EXTERNAL MODULE: ./node_modules/@hazae41/option/dist/esm/mods/option/some.mjs
var some = __webpack_require__(8862);
;// CONCATENATED MODULE: ./src/mods/background/service_worker/entities/settings/data.ts

var BgSettings;
(function(BgSettings) {
    let Logs;
    (function(Logs) {
        Logs.key = "settings/logs";
        function schema(storage) {
            return (0,query/* createQuery */.rP)({
                key: Logs.key,
                storage
            });
        }
        Logs.schema = schema;
    })(Logs = BgSettings.Logs || (BgSettings.Logs = {}));
})(BgSettings || (BgSettings = {}));

;// CONCATENATED MODULE: ./src/mods/foreground/entities/settings/data.ts




var FgSettings;
(function(FgSettings) {
    let Logs;
    (function(Logs) {
        Logs.key = BgSettings.Logs.key;
        function schema(storage) {
            return (0,query/* createQuery */.rP)({
                key: Logs.key,
                storage
            });
        }
        Logs.schema = schema;
    })(Logs = FgSettings.Logs || (FgSettings.Logs = {}));
})(FgSettings || (FgSettings = {}));
function useLogs() {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(FgSettings.Logs.schema, [
        storage
    ]);
    (0,storage_storage/* useSubscribe */.Q)(query, storage);
    return query;
}

;// CONCATENATED MODULE: ./src/mods/foreground/entities/settings/page.tsx








function SettingsPage() {
    var _logs_real;
    const logs = useLogs();
    const onLogsChange = (0,events/* useInputChange */.Xy)((e)=>{
        const checked = e.currentTarget.checked;
        logs.mutate(()=>new some/* Some */.b(new fetched_data/* Data */.V(checked)));
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(page/* Page */.T, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(header/* UserPageHeader */.To, {
                title: "Settings"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(header/* PageBody */.xV, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "po-md text-sm text-contrast uppercase",
                        children: "Others"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("label", {
                        className: "po-md bg-contrast rounded-xl flex items-center justify-between",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "",
                                children: "Enable logs"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("input", {
                                className: "",
                                type: "checkbox",
                                checked: Boolean((_logs_real = logs.real) === null || _logs_real === void 0 ? void 0 : _logs_real.current.inner),
                                onChange: onLogsChange
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "po-md text-sm text-contrast",
                        children: [
                            "All your requests will be seen on ",
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(anchor_anchor/* TextAnchor */.U, {
                                href: "https://logs.brume.money"
                            })
                        ]
                    })
                ]
            })
        ]
    });
}

// EXTERNAL MODULE: ./node_modules/@swc/helpers/esm/_class_private_field_get.js + 1 modules
var _class_private_field_get = __webpack_require__(7121);
// EXTERNAL MODULE: ./node_modules/@swc/helpers/esm/_class_private_field_init.js
var _class_private_field_init = __webpack_require__(9886);
// EXTERNAL MODULE: ./node_modules/@swc/helpers/esm/_class_private_field_set.js + 1 modules
var _class_private_field_set = __webpack_require__(5321);
;// CONCATENATED MODULE: ./src/mods/background/service_worker/entities/snaps/data.ts





var _a;




var SnapRef;
(function(SnapRef) {
    function create(uuid) {
        return {
            ref: true,
            uuid
        };
    }
    SnapRef.create = create;
    function from(snap) {
        return create(snap.uuid);
    }
    SnapRef.from = from;
})(SnapRef || (SnapRef = {}));
var BgSnap;
(function(BgSnap) {
    let All;
    (function(All) {
        All.key = "snaps";
        function schema(storage) {
            return (0,query/* createQuery */.rP)({
                key: All.key,
                storage
            });
        }
        All.schema = schema;
    })(All = BgSnap.All || (BgSnap.All = {}));
    function key(uuid) {
        return "snap/".concat(uuid);
    }
    BgSnap.key = key;
    function schema(id, storage) {
        return (0,query/* createQuery */.rP)({
            key: key(id),
            storage
        });
    }
    BgSnap.schema = schema;
})(BgSnap || (BgSnap = {}));
var _class = /*#__PURE__*/ new WeakMap();
class SnapError extends Error {
    static from(cause) {
        return new _a({
            cause
        });
    }
    constructor(options){
        super("Could not execute", options);
        (0,_class_private_field_init._)(this, _class, {
            writable: true,
            value: void 0
        });
        (0,_class_private_field_set._)(this, _class, _a);
        this.name = (0,_class_private_field_get._)(this, _class).name;
    }
}
_a = SnapError;
class RustSnapFactory {
    create(context) {
        const snap = new this.snap(context);
        return new RustSnapWrapper(snap);
    }
    constructor(bytecode){
        this.bytecode = bytecode;
        this.snap = createSnap(this.bytecode);
    }
}
var _onRequest = /*#__PURE__*/ new WeakSet();
class RustSnapContext {
    request(req) {
        const request = JSON.parse(req);
        const response = Result.runAndWrap(()=>{
            return _class_private_method_get(this, _onRequest, onRequest).call(this, request);
        }).then((r)=>RpcResponse.rewrap(null, r));
        return JSON.stringify(response);
    }
    constructor(){
        _class_private_method_init(this, _onRequest);
    }
}
function onRequest(request) {
    if (request.method === "log") {
        console.log(...request.params);
        return;
    }
    if (request.method === "brume_addChain") {
    // const [logo] = (request as RpcRequestInit<[]>).params
    }
    throw new Error("Unknown method ".concat(request.method));
}
class RustSnapWrapper {
    request(request) {
        try {
            const req = JSON.stringify(request);
            const ret = this.inner.on_request(req);
            const res = JSON.parse(ret);
            return new RpcOk(request.id, res);
        } catch (e) {
            return new RpcErr(request.id, RpcError.rewrap(e));
        }
    }
    constructor(/**
     * The WebAssembly module
     */ inner){
        this.inner = inner;
    }
}

;// CONCATENATED MODULE: ./src/mods/foreground/entities/snaps/data.tsx




var FgSnap;
(function(FgSnap) {
    let All;
    (function(All) {
        All.key = BgSnap.All.key;
        function schema(storage) {
            return (0,query/* createQuery */.rP)({
                key: All.key,
                storage
            });
        }
        All.schema = schema;
    })(All = FgSnap.All || (FgSnap.All = {}));
    FgSnap.key = BgSnap.key;
    function schema(uuid, storage) {
        if (uuid == null) return;
        return (0,query/* createQuery */.rP)({
            key: FgSnap.key(uuid),
            storage
        });
    }
    FgSnap.schema = schema;
})(FgSnap || (FgSnap = {}));
function useSnap(uuid) {
    const storage = useUserStorageContext().unwrap();
    const query = useQuery(FgSnap.schema, [
        uuid,
        storage
    ]);
    useSubscribe(query, storage);
    return query;
}
function useSnaps() {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(FgSnap.All.schema, [
        storage
    ]);
    (0,storage_storage/* useSubscribe */.Q)(query, storage);
    return query;
}

;// CONCATENATED MODULE: ./src/mods/foreground/entities/snaps/all/page.tsx







function SnapsPage() {
    const snapsQuery = useSnaps();
    const onAdd = (0,react.useCallback)(()=>{
        snapsQuery;
    }, []);
    const Body = /*#__PURE__*/ (0,jsx_runtime.jsx)(header/* PageBody */.xV, {
        children: "Coming soon..."
    });
    const Header = /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(header/* UserPageHeader */.To, {
                title: "Plugins",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                    className: "".concat(ui_button/* Button.Base */.z.XY.className, " size-8 hovered-or-clicked-or-focused:scale-105 !transition"),
                    onClick: onAdd,
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(PlusIcon/* default */.Z, {
                            className: "size-5"
                        })
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "po-md flex items-center",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "text-contrast",
                    children: "Plugins allow you to securely extend the features. These features can then be used by applications you connect to."
                })
            })
        ]
    });
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(page/* Page */.T, {
        children: [
            Header,
            Body
        ]
    });
}

// EXTERNAL MODULE: ./node_modules/@nuintun/qrcode/esm/qrcode/decoder/Reader.js + 15 modules
var Reader = __webpack_require__(845);
// EXTERNAL MODULE: ./src/mods/foreground/entities/wallets/context.tsx
var wallets_context = __webpack_require__(1949);
;// CONCATENATED MODULE: ./src/mods/foreground/entities/wallets/camera/page.tsx
/* eslint-disable @next/next/no-img-element */ 








function WalletCameraPage(props) {
    const { uuid } = props;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(wallets_context/* WalletDataProvider */.lp, {
        uuid: uuid,
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(WalletDataCameraPage, {})
    });
}
function WalletDataCameraPage() {
    const wallet = (0,wallets_context/* useWalletDataContext */.zI)().unwrap();
    const background = (0,context/* useBackgroundContext */.D_)().unwrap();
    const mounted = (0,react.useRef)(true);
    (0,react.useEffect)(()=>()=>{
            mounted.current = false;
        }, []);
    const video = (0,react.useRef)(null);
    const sight = (0,react.useRef)(null);
    const [text, setText] = (0,react.useState)();
    const onStream = (0,react.useCallback)((stream)=>{
        if (!video.current) return;
        if (!sight.current) return;
        video.current.addEventListener("canplay", ()=>{
            if (!video.current) return;
            if (!sight.current) return;
            const yratio = video.current.videoHeight / video.current.clientHeight;
            const xratio = video.current.videoWidth / video.current.clientWidth;
            const ratio = Math.min(yratio, xratio);
            const cw = video.current.clientWidth * ratio;
            const ch = video.current.clientHeight * ratio;
            const cx = video.current.videoWidth / 2 - cw / 2;
            const cy = video.current.videoHeight / 2 - ch / 2;
            const sx = cx + sight.current.offsetLeft * ratio;
            const sy = cy + sight.current.offsetTop * ratio;
            const sw = sight.current.offsetWidth * ratio;
            const sh = sight.current.offsetHeight * ratio;
            const canvas = document.createElement("canvas");
            canvas.width = sw;
            canvas.height = sh;
            const canvasCtx = canvas.getContext("2d");
            if (!canvasCtx) return;
            function loop() {
                if (!mounted.current) return;
                if (!video.current) return;
                if (!sight.current) return;
                if (!canvasCtx) return;
                canvasCtx.drawImage(video.current, sx, sy, sw, sh, 0, 0, canvas.width, canvas.height);
                const image = canvasCtx.getImageData(0, 0, sw, sh);
                let result = null;
                try {
                    result = new Reader/* Decoder */.h().decode(image.data, canvas.width, canvas.height);
                } catch (e) {}
                if (result != null) setText(result.data);
                setTimeout(loop, 1000);
            }
            setTimeout(loop, 1000);
        });
        video.current.srcObject = stream;
        video.current.play();
    }, []);
    (0,react.useEffect)(()=>{
        const video = {
            width: {
                ideal: 1080
            },
            height: {
                ideal: 1080
            },
            facingMode: {
                exact: "environment"
            }
        };
        navigator.mediaDevices.getUserMedia({
            video
        }).then(onStream).catch(errors_errors/* Errors */.D.logAndAlert);
    }, [
        onStream
    ]);
    const tryConnect = (0,callback/* useAsyncUniqueCallback */.T)(async (uri)=>{
        return await result/* Result */.x.unthrow(async (t)=>{
            alert("Connecting...");
            const metadata = await background.tryRequest({
                method: "brume_wc_connect",
                params: [
                    uri,
                    wallet.uuid
                ]
            }).then((r)=>r.throw(t).throw(t));
            alert("Connected to ".concat(metadata.name));
            return ok.Ok.void();
        }).then(results/* Results */.u.logAndAlert);
    }, [
        background,
        wallet
    ]);
    (0,react.useEffect)(()=>{
        if (text) tryConnect.run(text);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        text
    ]);
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(jsx_runtime.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "grow relative flex flex-col",
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "absolute w-full h-full flex flex-col items-center justify-center",
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)("img", {
                        className: "h-16 w-16",
                        src: "/assets/wc.svg",
                        alt: "WalletConnect"
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "absolute w-full h-full flex flex-col items-center justify-center",
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)("img", {
                        className: "h-64 w-64",
                        ref: sight,
                        src: "/assets/sight.svg",
                        alt: "sight"
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("video", {
                    className: "grow w-full object-cover",
                    ref: video,
                    playsInline: true,
                    muted: true
                })
            ]
        })
    });
}

// EXTERNAL MODULE: ./src/mods/foreground/entities/wallets/page.tsx + 22 modules
var wallets_page = __webpack_require__(3505);
// EXTERNAL MODULE: ./src/mods/foreground/entities/unknown/data.ts
var unknown_data = __webpack_require__(9801);
// EXTERNAL MODULE: ./src/mods/foreground/entities/users/context.tsx
var users_context = __webpack_require__(1677);
;// CONCATENATED MODULE: ./src/mods/foreground/home/page.tsx
/* eslint-disable @next/next/no-img-element */ 







function HomePage() {
    const userData = (0,users_context/* useUserContext */.SE)().unwrap();
    const background = (0,context/* useBackgroundContext */.D_)().unwrap();
    const totalPricedBalanceQuery = (0,unknown_data/* useTotalPricedBalance */.ZO)("usd");
    const totalPricedBalanceDisplay = (0,wallets_page/* useDisplayUsd */.iZ)(totalPricedBalanceQuery.current);
    (0,react.useEffect)(()=>{
        background.tryRequest({
            method: "brume_log"
        }).then((r)=>r.inspectErrSync(console.warn));
    }, [
        background
    ]);
    const [persisted, setPersisted] = (0,react.useState)();
    const getPersisted = (0,react.useCallback)(async ()=>{
        setPersisted(await navigator.storage.persist());
    }, []);
    (0,react.useEffect)(()=>{
        getPersisted();
        if (background.isExtension()) return;
        if (navigator.userAgent.toLowerCase().includes("firefox")) return;
        const t = setInterval(getPersisted, 1000);
        return ()=>clearTimeout(t);
    }, [
        background,
        getPersisted
    ]);
    const Body = /*#__PURE__*/ (0,jsx_runtime.jsxs)(header/* PageBody */.xV, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "text-center text-4xl font-medium",
                children: "Hi, ".concat(userData.name)
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-8"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "text-lg font-medium",
                children: "Total balance"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "text-2xl font-bold",
                children: totalPricedBalanceDisplay
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-4"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "po-md border border-contrast h-[300px] rounded-xl flex flex-col items-center justify-center",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("img", {
                        src: "/favicon.png",
                        alt: "logo",
                        className: "h-24 w-auto"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "",
                        children: "Coming soon..."
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-8"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "grow"
            }),
            persisted === false && background.isWebsite() && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "text-lg font-medium",
                        children: "Alerts"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-2"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "po-md border border-contrast rounded-xl",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("h3", {
                                className: "text-lg font-medium",
                                children: "Your storage is not persistent yet"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                                className: "text-contrast",
                                children: "Please add this website to your favorites or to your home screen in order to enable persistent storage"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "h-2"
                            })
                        ]
                    })
                ]
            })
        ]
    });
    const Header = /*#__PURE__*/ (0,jsx_runtime.jsx)(header/* UserPageHeader */.To, {
        title: "Home"
    });
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(page/* Page */.T, {
        children: [
            Header,
            Body
        ]
    });
}

;// CONCATENATED MODULE: ./src/mods/foreground/router/router.tsx













function Router() {
    const { url } = (0,path_context/* usePathContext */.td)().unwrap();
    let matches;
    if (url.pathname === "") return /*#__PURE__*/ (0,jsx_runtime.jsx)(HomePage, {});
    if (matches = url.pathname.match(/^\/$/)) return /*#__PURE__*/ (0,jsx_runtime.jsx)(HomePage, {});
    if (matches = url.pathname.match(/^\/wallets(\/)?$/)) return /*#__PURE__*/ (0,jsx_runtime.jsx)(all_page/* WalletsPage */.FU, {});
    if (matches = url.pathname.match(/^\/seeds(\/)?$/)) return /*#__PURE__*/ (0,jsx_runtime.jsx)(SeedsPage, {});
    if (matches = url.pathname.match(/^\/sessions(\/)?$/)) return /*#__PURE__*/ (0,jsx_runtime.jsx)(SessionsPage, {});
    if (matches = url.pathname.match(/^\/requests(\/)?$/)) return /*#__PURE__*/ (0,jsx_runtime.jsx)(RequestsPage, {});
    if (matches = url.pathname.match(/^\/plugins(\/)?$/)) return /*#__PURE__*/ (0,jsx_runtime.jsx)(SnapsPage, {});
    if (matches = url.pathname.match(/^\/wallet\/([^\/]+)(\/)?$/)) return /*#__PURE__*/ (0,jsx_runtime.jsx)(wallets_page/* WalletPage */.ds, {
        uuid: matches[1]
    });
    if (matches = url.pathname.match(/^\/wallet\/([^\/]+)\/camera(\/)?$/)) return /*#__PURE__*/ (0,jsx_runtime.jsx)(WalletCameraPage, {
        uuid: matches[1]
    });
    if (matches = url.pathname.match(/^\/seed\/([^\/]+)(\/)?$/)) return /*#__PURE__*/ (0,jsx_runtime.jsx)(SeedPage, {
        uuid: matches[1]
    });
    if (matches = url.pathname.match(/^\/settings(\/)?$/)) return /*#__PURE__*/ (0,jsx_runtime.jsx)(SettingsPage, {});
    if (matches = url.pathname.match(/^\/eth_requestAccounts(\/)?$/)) return /*#__PURE__*/ (0,jsx_runtime.jsx)(popup.WalletAndChainSelectPage, {});
    if (matches = url.pathname.match(/^\/eth_sendTransaction(\/)?$/)) return /*#__PURE__*/ (0,jsx_runtime.jsx)(popup.TransactPage, {});
    if (matches = url.pathname.match(/^\/wallet_switchEthereumChain(\/)?$/)) return /*#__PURE__*/ (0,jsx_runtime.jsx)(popup.SwitchPage, {});
    if (matches = url.pathname.match(/^\/personal_sign(\/)?$/)) return /*#__PURE__*/ (0,jsx_runtime.jsx)(popup.PersonalSignPage, {});
    if (matches = url.pathname.match(/^\/eth_signTypedData_v4(\/)?$/)) return /*#__PURE__*/ (0,jsx_runtime.jsx)(popup.TypedSignPage, {});
    if (matches = url.pathname.match(/^\/done(\/)?$/)) return /*#__PURE__*/ (0,jsx_runtime.jsx)(popup.DonePage, {});
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(jsx_runtime.Fragment, {
        children: "Error 404"
    });
}


/***/ })

}]);