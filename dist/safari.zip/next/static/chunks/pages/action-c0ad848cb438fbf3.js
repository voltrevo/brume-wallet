(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[826],{

/***/ 5610:
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


    (window.__NEXT_P = window.__NEXT_P || []).push([
      "/action",
      function () {
        return __webpack_require__(8747);
      }
    ]);
    if(false) {}
  

/***/ }),

/***/ 8747:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ Action; }
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _mods_foreground_background_context__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5855);
/* harmony import */ var _mods_foreground_entities_users_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1677);
/* harmony import */ var _mods_foreground_overlay_bottom__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9403);
/* harmony import */ var _mods_foreground_overlay_navbar__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5794);
/* harmony import */ var _mods_foreground_overlay_overlay__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(938);
/* harmony import */ var _mods_foreground_router_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5310);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7294);








function Action() {
    const background = (0,_mods_foreground_background_context__WEBPACK_IMPORTED_MODULE_1__/* .useBackgroundContext */ .D_)().unwrap();
    (0,react__WEBPACK_IMPORTED_MODULE_7__.useEffect)(()=>{
        /**
         * Chromium
         */ document.documentElement.classList.add("h-[600px", "w-[400px]");
        /**
         * Firefox
         */ document.body.classList.add("h-[600px]", "w-[400px]");
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_7__.useEffect)(()=>{
        background.tryRequest({
            method: "brume_getPath"
        }).then((r)=>r.unwrap().unwrap()).then((p)=>location.hash = p);
        const onHashChange = ()=>background.tryRequest({
                method: "brume_setPath",
                params: [
                    location.hash
                ]
            }).then((r)=>r.unwrap().unwrap());
        addEventListener("hashchange", onHashChange, {
            passive: true
        });
        return ()=>removeEventListener("hashchange", onHashChange);
    }, [
        background
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("main", {
        id: "main",
        className: "grow w-full flex flex-col overflow-hidden",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mods_foreground_overlay_navbar__WEBPACK_IMPORTED_MODULE_4__/* .NavBar */ .l, {}),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mods_foreground_overlay_overlay__WEBPACK_IMPORTED_MODULE_5__/* .Overlay */ .aV, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mods_foreground_background_context__WEBPACK_IMPORTED_MODULE_1__/* .BackgroundGuard */ .bI, {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mods_foreground_entities_users_context__WEBPACK_IMPORTED_MODULE_2__/* .UserGuard */ .ds, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                className: "grow w-full flex flex-col overflow-y-scroll",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                    className: "grow w-full m-auto max-w-3xl flex flex-col",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mods_foreground_router_router__WEBPACK_IMPORTED_MODULE_6__/* .Router */ .F, {})
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mods_foreground_overlay_bottom__WEBPACK_IMPORTED_MODULE_3__/* .Bottom */ .z, {})
                        ]
                    })
                })
            })
        ]
    });
}


/***/ })

},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
/******/ __webpack_require__.O(0, [67,801,376,570,250,751,774,888,179], function() { return __webpack_exec__(5610); });
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ _N_E = __webpack_exports__;
/******/ }
]);