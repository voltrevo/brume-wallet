"use strict";
(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[319],{

/***/ 2726:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DonePage: function() { return /* binding */ DonePage; },
/* harmony export */   PersonalSignPage: function() { return /* binding */ PersonalSignPage; },
/* harmony export */   Ready: function() { return /* binding */ Ready; },
/* harmony export */   SwitchPage: function() { return /* binding */ SwitchPage; },
/* harmony export */   TransactPage: function() { return /* binding */ TransactPage; },
/* harmony export */   TypedSignPage: function() { return /* binding */ TypedSignPage; },
/* harmony export */   WalletAndChainSelectPage: function() { return /* binding */ WalletAndChainSelectPage; },
/* harmony export */   "default": function() { return /* binding */ Popup; }
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _libs_bigints_bigints__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7795);
/* harmony import */ var _libs_errors_errors__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9071);
/* harmony import */ var _libs_ethereum_mods_chain__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9408);
/* harmony import */ var _libs_icons_icons__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(1415);
/* harmony import */ var _libs_icons_icons__WEBPACK_IMPORTED_MODULE_41__ = __webpack_require__(2911);
/* harmony import */ var _libs_icons_icons__WEBPACK_IMPORTED_MODULE_43__ = __webpack_require__(8680);
/* harmony import */ var _libs_react_callback__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7174);
/* harmony import */ var _libs_react_events__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4714);
/* harmony import */ var _libs_react_handles_boolean__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5902);
/* harmony import */ var _libs_react_memo__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2387);
/* harmony import */ var _libs_results_results__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(421);
/* harmony import */ var _libs_ui_button__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1258);
/* harmony import */ var _libs_ui_dialog_dialog__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3868);
/* harmony import */ var _libs_ui2_page_header__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1952);
/* harmony import */ var _libs_ui2_page_page__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3365);
/* harmony import */ var _mods_foreground_background_context__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(7028);
/* harmony import */ var _mods_foreground_entities_requests_data__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(7489);
/* harmony import */ var _mods_foreground_entities_sessions_data__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(5830);
/* harmony import */ var _mods_foreground_entities_signatures_data__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(4035);
/* harmony import */ var _mods_foreground_entities_unknown_data__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(5234);
/* harmony import */ var _mods_foreground_entities_users_context__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(6676);
/* harmony import */ var _mods_foreground_entities_wallets_all_create__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(4439);
/* harmony import */ var _mods_foreground_entities_wallets_all_page__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(882);
/* harmony import */ var _mods_foreground_entities_wallets_data__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(9031);
/* harmony import */ var _mods_foreground_errors_errors__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(8422);
/* harmony import */ var _mods_foreground_overlay_bottom__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(9609);
/* harmony import */ var _mods_foreground_overlay_navbar__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(74);
/* harmony import */ var _mods_foreground_overlay_overlay__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(8220);
/* harmony import */ var _mods_foreground_router_path_context__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(7921);
/* harmony import */ var _mods_foreground_router_router__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(2932);
/* harmony import */ var _hazae41_base16__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(2248);
/* harmony import */ var _hazae41_bytes__WEBPACK_IMPORTED_MODULE_42__ = __webpack_require__(1694);
/* harmony import */ var _hazae41_cubane__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(6113);
/* harmony import */ var _hazae41_cubane__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(167);
/* harmony import */ var _hazae41_cubane__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(7817);
/* harmony import */ var _hazae41_jsonrpc__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(1752);
/* harmony import */ var _hazae41_jsonrpc__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(667);
/* harmony import */ var _hazae41_option__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(5316);
/* harmony import */ var _hazae41_result__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(918);
/* harmony import */ var _hazae41_result__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(5591);
/* harmony import */ var _hazae41_result__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(166);
/* harmony import */ var ethers__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(5418);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(7294);





































function Popup() {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("main", {
        id: "main",
        className: "p-safe grow w-full flex flex-col overflow-hidden",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mods_foreground_overlay_navbar__WEBPACK_IMPORTED_MODULE_24__/* .NavBar */ .l, {}),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mods_foreground_overlay_overlay__WEBPACK_IMPORTED_MODULE_25__/* .Overlay */ .aV, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mods_foreground_background_context__WEBPACK_IMPORTED_MODULE_13__/* .BackgroundGuard */ .bI, {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mods_foreground_entities_users_context__WEBPACK_IMPORTED_MODULE_18__/* .UserGuard */ .ds, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Ready, {})
                    })
                })
            })
        ]
    });
}
function Ready() {
    const background = (0,_mods_foreground_background_context__WEBPACK_IMPORTED_MODULE_13__/* .useBackgroundContext */ .D_)().unwrap();
    (0,react__WEBPACK_IMPORTED_MODULE_28__.useEffect)(()=>{
        background.tryRequest({
            method: "popup_hello"
        }).then((r)=>r.unwrap().unwrap());
    }, [
        background
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "grow w-full flex flex-col overflow-y-scroll",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                    className: "grow w-full m-auto max-w-3xl flex flex-col",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mods_foreground_router_router__WEBPACK_IMPORTED_MODULE_27__/* .Router */ .F, {})
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mods_foreground_overlay_bottom__WEBPACK_IMPORTED_MODULE_23__/* .Bottom */ .z, {})
        ]
    });
}
function TransactPage() {
    var _requestQuery_data, _sessionQuery_data, _walletQuery_data, _maybeSession_wallets_at, _gasPriceQuery_data, _nonceQuery_data, _maybeSession_wallets_at1, _signaturesQuery_data;
    const { url, go } = (0,_mods_foreground_router_path_context__WEBPACK_IMPORTED_MODULE_26__/* .usePathContext */ .td)().unwrap();
    const { searchParams } = url;
    const background = (0,_mods_foreground_background_context__WEBPACK_IMPORTED_MODULE_13__/* .useBackgroundContext */ .D_)().unwrap();
    const id = _hazae41_option__WEBPACK_IMPORTED_MODULE_29__/* .Option */ .W.wrap(searchParams.get("id")).unwrap();
    const to = _hazae41_option__WEBPACK_IMPORTED_MODULE_29__/* .Option */ .W.wrap(searchParams.get("to")).unwrap();
    const gas = _hazae41_option__WEBPACK_IMPORTED_MODULE_29__/* .Option */ .W.wrap(searchParams.get("gas")).unwrap();
    const walletId = _hazae41_option__WEBPACK_IMPORTED_MODULE_29__/* .Option */ .W.wrap(searchParams.get("walletId")).unwrap();
    const chainId = _hazae41_option__WEBPACK_IMPORTED_MODULE_29__/* .Option */ .W.wrap(searchParams.get("chainId")).mapSync(Number).unwrap();
    const requestQuery = (0,_mods_foreground_entities_requests_data__WEBPACK_IMPORTED_MODULE_14__/* .useAppRequest */ .Vd)(id);
    const maybeRequest = (_requestQuery_data = requestQuery.data) === null || _requestQuery_data === void 0 ? void 0 : _requestQuery_data.get();
    const sessionQuery = (0,_mods_foreground_entities_sessions_data__WEBPACK_IMPORTED_MODULE_15__/* .useSession */ .k)(maybeRequest === null || maybeRequest === void 0 ? void 0 : maybeRequest.session);
    const maybeSession = (_sessionQuery_data = sessionQuery.data) === null || _sessionQuery_data === void 0 ? void 0 : _sessionQuery_data.get();
    const walletQuery = (0,_mods_foreground_entities_wallets_data__WEBPACK_IMPORTED_MODULE_21__/* .useWallet */ .Os)(walletId);
    const maybeWallet = (_walletQuery_data = walletQuery.data) === null || _walletQuery_data === void 0 ? void 0 : _walletQuery_data.get();
    const chain = _hazae41_option__WEBPACK_IMPORTED_MODULE_29__/* .Option */ .W.wrap(_libs_ethereum_mods_chain__WEBPACK_IMPORTED_MODULE_3__/* .chainByChainId */ .DH[chainId]).unwrap();
    const value = searchParams.get("value");
    const maybeData = searchParams.get("data");
    const context = (0,_mods_foreground_entities_wallets_data__WEBPACK_IMPORTED_MODULE_21__/* .useEthereumContext */ .Kn)(maybeSession === null || maybeSession === void 0 ? void 0 : (_maybeSession_wallets_at = maybeSession.wallets.at(0)) === null || _maybeSession_wallets_at === void 0 ? void 0 : _maybeSession_wallets_at.uuid, chain);
    const gasPriceQuery = (0,_mods_foreground_entities_unknown_data__WEBPACK_IMPORTED_MODULE_17__/* .useGasPrice */ .Fh)(context);
    const maybeGasPrice = (_gasPriceQuery_data = gasPriceQuery.data) === null || _gasPriceQuery_data === void 0 ? void 0 : _gasPriceQuery_data.get();
    const nonceQuery = (0,_mods_foreground_entities_unknown_data__WEBPACK_IMPORTED_MODULE_17__/* .useNonce */ .XE)(maybeWallet === null || maybeWallet === void 0 ? void 0 : maybeWallet.address, context);
    const maybeNonce = (_nonceQuery_data = nonceQuery.data) === null || _nonceQuery_data === void 0 ? void 0 : _nonceQuery_data.get();
    const maybeHash = _hazae41_option__WEBPACK_IMPORTED_MODULE_29__/* .Option */ .W.wrap(maybeData).mapSync((x)=>{
        return x.slice(0, 10);
    }).inner;
    const gnosis = (0,_mods_foreground_entities_wallets_data__WEBPACK_IMPORTED_MODULE_21__/* .useEthereumContext2 */ .IL)(maybeSession === null || maybeSession === void 0 ? void 0 : (_maybeSession_wallets_at1 = maybeSession.wallets.at(0)) === null || _maybeSession_wallets_at1 === void 0 ? void 0 : _maybeSession_wallets_at1.uuid, _libs_ethereum_mods_chain__WEBPACK_IMPORTED_MODULE_3__/* .chainByChainId */ .DH[100]).unwrap();
    const signaturesQuery = (0,_mods_foreground_entities_signatures_data__WEBPACK_IMPORTED_MODULE_16__/* .useSignature */ .F)(maybeHash, gnosis);
    const maybeSignatures = (_signaturesQuery_data = signaturesQuery.data) === null || _signaturesQuery_data === void 0 ? void 0 : _signaturesQuery_data.get();
    const maybeSignature = (0,_libs_react_memo__WEBPACK_IMPORTED_MODULE_7__/* .useAsyncReplaceMemo */ .EY)(async ()=>{
        if (maybeData == null) return;
        if (maybeHash == null) return;
        if (maybeSignatures == null) return;
        const zeroHexData = _hazae41_cubane__WEBPACK_IMPORTED_MODULE_30__/* .ZeroHexString */ .T.from(maybeData);
        return maybeSignatures.map((text)=>{
            return _hazae41_result__WEBPACK_IMPORTED_MODULE_31__/* .Result */ .x.runAndWrapSync(()=>{
                const abi = _hazae41_cubane__WEBPACK_IMPORTED_MODULE_32__/* .FunctionSignature */ .I.parseOrThrow(text);
                const { args } = _hazae41_cubane__WEBPACK_IMPORTED_MODULE_33__/* .decodeOrThrow */ .Dt(abi, zeroHexData);
                function stringifyOrThrow(x) {
                    if (typeof x === "string") return x;
                    if (typeof x === "boolean") return String(x);
                    if (typeof x === "number") return String(x);
                    if (typeof x === "bigint") return String(x);
                    if (x instanceof Uint8Array) return _hazae41_cubane__WEBPACK_IMPORTED_MODULE_30__/* .ZeroHexString */ .T.from(_hazae41_base16__WEBPACK_IMPORTED_MODULE_34__/* .get */ .U().encodeOrThrow(x));
                    if (Array.isArray(x)) return "(".concat(x.map(stringifyOrThrow).join(", "), ")");
                    return "unknown";
                }
                const decoded = args.intoOrThrow().map(stringifyOrThrow).join(", ");
                return {
                    text,
                    decoded
                };
            }).inspectErrSync((e)=>console.warn({
                    e
                })).unwrapOr(undefined);
        }).find((it)=>it != null);
    }, [
        maybeData,
        maybeHash,
        maybeSignatures
    ]);
    const onApprove = (0,_libs_react_callback__WEBPACK_IMPORTED_MODULE_4__/* .useAsyncUniqueCallback */ .T)(async ()=>{
        return await _hazae41_result__WEBPACK_IMPORTED_MODULE_31__/* .Result */ .x.unthrow(async (t)=>{
            const wallet = _hazae41_option__WEBPACK_IMPORTED_MODULE_29__/* .Option */ .W.wrap(maybeWallet).ok().throw(t);
            const gasPrice = _hazae41_option__WEBPACK_IMPORTED_MODULE_29__/* .Option */ .W.wrap(maybeGasPrice).ok().throw(t);
            const nonce = _hazae41_option__WEBPACK_IMPORTED_MODULE_29__/* .Option */ .W.wrap(maybeNonce).ok().throw(t);
            const tx = _hazae41_result__WEBPACK_IMPORTED_MODULE_31__/* .Result */ .x.runAndDoubleWrapSync(()=>{
                return ethers__WEBPACK_IMPORTED_MODULE_35__/* .Transaction */ .Y.from({
                    data: maybeData,
                    to: to,
                    gasLimit: gas,
                    chainId: chain.chainId,
                    gasPrice: gasPrice,
                    nonce: Number(nonce),
                    value: value
                });
            }).throw(t);
            const instance = await _mods_foreground_entities_wallets_data__WEBPACK_IMPORTED_MODULE_21__/* .EthereumWalletInstance */ .Vy.tryFrom(wallet, background).then((r)=>r.throw(t));
            tx.signature = await instance.trySignTransaction(tx, background).then((r)=>r.throw(t));
            await background.tryRequest({
                method: "brume_respond",
                params: [
                    new _hazae41_jsonrpc__WEBPACK_IMPORTED_MODULE_36__/* .RpcOk */ .r(id, tx.serialized)
                ]
            }).then((r)=>r.throw(t).throw(t));
            go("/done");
            return _hazae41_result__WEBPACK_IMPORTED_MODULE_37__.Ok.void();
        }).then(_libs_results_results__WEBPACK_IMPORTED_MODULE_8__/* .Results */ .u.logAndAlert);
    }, [
        background,
        id,
        maybeWallet,
        maybeGasPrice,
        maybeNonce,
        chain
    ]);
    const onReject = (0,_libs_react_callback__WEBPACK_IMPORTED_MODULE_4__/* .useAsyncUniqueCallback */ .T)(async ()=>{
        return await _hazae41_result__WEBPACK_IMPORTED_MODULE_31__/* .Result */ .x.unthrow(async (t)=>{
            await background.tryRequest({
                method: "brume_respond",
                params: [
                    _hazae41_jsonrpc__WEBPACK_IMPORTED_MODULE_38__/* .RpcErr */ .s6.rewrap(id, new _hazae41_result__WEBPACK_IMPORTED_MODULE_39__/* .Err */ .U(new _mods_foreground_errors_errors__WEBPACK_IMPORTED_MODULE_22__/* .UserRejectedError */ .Ai()))
                ]
            }).then((r)=>r.throw(t).throw(t));
            go("/done");
            return _hazae41_result__WEBPACK_IMPORTED_MODULE_37__.Ok.void();
        }).then(_libs_results_results__WEBPACK_IMPORTED_MODULE_8__/* .Results */ .u.logAndAlert);
    }, [
        background,
        id
    ]);
    const loading = (0,react__WEBPACK_IMPORTED_MODULE_28__.useMemo)(()=>{
        if (onApprove.loading) return true;
        if (gasPriceQuery.data == null) return true;
        if (nonceQuery.data == null) return true;
        return false;
    }, [
        onApprove.loading,
        gasPriceQuery.data,
        nonceQuery.data
    ]);
    var _maybeSignature_decoded;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_libs_ui2_page_page__WEBPACK_IMPORTED_MODULE_12__/* .Page */ .T, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "p-4 grow flex flex-col items-center justify-center",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: "text-center text-xl font-medium",
                        children: "Transaction"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: "w-full max-w-[230px] text-center text-contrast",
                        children: "Do you want to approve this transaction?"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "w-full p-4 grow flex flex-col",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-full p-4 border border-contrast rounded-xl whitespace-pre-wrap break-words",
                        children: [
                            "To: ",
                            to
                        ]
                    }),
                    value && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-full p-4 border border-contrast rounded-xl whitespace-pre-wrap mt-2 break-words",
                        children: [
                            "Value: ",
                            _libs_bigints_bigints__WEBPACK_IMPORTED_MODULE_1__/* .BigIntToHex */ .W.tryDecode(_hazae41_cubane__WEBPACK_IMPORTED_MODULE_30__/* .ZeroHexString */ .T.from(value)).mapSync((x)=>_libs_bigints_bigints__WEBPACK_IMPORTED_MODULE_1__/* .BigInts */ .l.float(x, 18)).ok().unwrapOr("Error")
                        ]
                    }),
                    maybeSignature && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "grow w-full p-4 border border-contrast rounded-xl whitespace-pre-wrap mt-2 break-words",
                        children: [
                            "Function: ",
                            maybeSignature.text
                        ]
                    }),
                    (maybeSignature || maybeData) && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "grow w-full p-4 border border-contrast rounded-xl whitespace-pre-wrap mt-2 break-words",
                        children: [
                            "Data: ",
                            (_maybeSignature_decoded = maybeSignature === null || maybeSignature === void 0 ? void 0 : maybeSignature.decoded) !== null && _maybeSignature_decoded !== void 0 ? _maybeSignature_decoded : maybeData
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "p-4 w-full flex items-center gap-2",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_libs_ui_button__WEBPACK_IMPORTED_MODULE_9__/* .Button.Contrast */ .z.mn, {
                        className: "grow po-md hovered-or-clicked-or-focused:scale-105 !transition",
                        onClick: onReject.run,
                        disabled: onReject.loading,
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "".concat(_libs_ui_button__WEBPACK_IMPORTED_MODULE_9__/* .Button.Shrinker */ .z.Np.className),
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_libs_icons_icons__WEBPACK_IMPORTED_MODULE_40__/* ["default"] */ .Z, {
                                    className: "size-5"
                                }),
                                "No, reject it"
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_libs_ui_button__WEBPACK_IMPORTED_MODULE_9__/* .Button.Gradient */ .z.ph, {
                        className: "grow po-md hovered-or-clicked-or-focused:scale-105 !transition",
                        onClick: onApprove.run,
                        disabled: loading,
                        colorIndex: 5,
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "".concat(_libs_ui_button__WEBPACK_IMPORTED_MODULE_9__/* .Button.Shrinker */ .z.Np.className),
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_libs_icons_icons__WEBPACK_IMPORTED_MODULE_41__/* ["default"] */ .Z, {
                                    className: "size-5"
                                }),
                                "Yes, approve it"
                            ]
                        })
                    })
                ]
            })
        ]
    });
}
function SwitchPage() {
    const { url, go } = (0,_mods_foreground_router_path_context__WEBPACK_IMPORTED_MODULE_26__/* .usePathContext */ .td)().unwrap();
    const { searchParams } = url;
    const background = (0,_mods_foreground_background_context__WEBPACK_IMPORTED_MODULE_13__/* .useBackgroundContext */ .D_)().unwrap();
    const id = _hazae41_option__WEBPACK_IMPORTED_MODULE_29__/* .Option */ .W.wrap(searchParams.get("id")).unwrap();
    const onApprove = (0,_libs_react_callback__WEBPACK_IMPORTED_MODULE_4__/* .useAsyncUniqueCallback */ .T)(async ()=>{
        return await _hazae41_result__WEBPACK_IMPORTED_MODULE_31__/* .Result */ .x.unthrow(async (t)=>{
            await background.tryRequest({
                method: "brume_respond",
                params: [
                    new _hazae41_jsonrpc__WEBPACK_IMPORTED_MODULE_36__/* .RpcOk */ .r(id, undefined)
                ]
            }).then((r)=>r.throw(t).throw(t));
            go("/done");
            return _hazae41_result__WEBPACK_IMPORTED_MODULE_37__.Ok.void();
        }).then(_libs_results_results__WEBPACK_IMPORTED_MODULE_8__/* .Results */ .u.logAndAlert);
    }, [
        background,
        id
    ]);
    const onReject = (0,_libs_react_callback__WEBPACK_IMPORTED_MODULE_4__/* .useAsyncUniqueCallback */ .T)(async ()=>{
        return await _hazae41_result__WEBPACK_IMPORTED_MODULE_31__/* .Result */ .x.unthrow(async (t)=>{
            await background.tryRequest({
                method: "brume_respond",
                params: [
                    _hazae41_jsonrpc__WEBPACK_IMPORTED_MODULE_38__/* .RpcErr */ .s6.rewrap(id, new _hazae41_result__WEBPACK_IMPORTED_MODULE_39__/* .Err */ .U(new _mods_foreground_errors_errors__WEBPACK_IMPORTED_MODULE_22__/* .UserRejectedError */ .Ai()))
                ]
            }).then((r)=>r.throw(t).throw(t));
            await new Promise((ok)=>setTimeout(ok, 250));
            go("/done");
            return _hazae41_result__WEBPACK_IMPORTED_MODULE_37__.Ok.void();
        }).then(_libs_results_results__WEBPACK_IMPORTED_MODULE_8__/* .Results */ .u.logAndAlert);
    }, [
        background,
        id
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_libs_ui2_page_page__WEBPACK_IMPORTED_MODULE_12__/* .Page */ .T, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "p-4 grow flex flex-col items-center justify-center",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: "text-center text-xl font-medium",
                        children: "Switch chain"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: "w-full max-w-[230px] text-center text-contrast",
                        children: "Do you want to switch the Ethereum chain?"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "p-4 w-full flex items-center gap-2",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_libs_ui_button__WEBPACK_IMPORTED_MODULE_9__/* .Button.Contrast */ .z.mn, {
                        className: "grow po-md hovered-or-clicked-or-focused:scale-105 !transition",
                        onClick: onReject.run,
                        disabled: onReject.loading,
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "".concat(_libs_ui_button__WEBPACK_IMPORTED_MODULE_9__/* .Button.Shrinker */ .z.Np.className),
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_libs_icons_icons__WEBPACK_IMPORTED_MODULE_40__/* ["default"] */ .Z, {
                                    className: "size-5"
                                }),
                                "No, reject it"
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_libs_ui_button__WEBPACK_IMPORTED_MODULE_9__/* .Button.Gradient */ .z.ph, {
                        className: "grow po-md hovered-or-clicked-or-focused:scale-105 !transition",
                        onClick: onApprove.run,
                        disabled: onApprove.loading,
                        colorIndex: 5,
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "".concat(_libs_ui_button__WEBPACK_IMPORTED_MODULE_9__/* .Button.Shrinker */ .z.Np.className),
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_libs_icons_icons__WEBPACK_IMPORTED_MODULE_41__/* ["default"] */ .Z, {
                                    className: "size-5"
                                }),
                                "Yes, approve it"
                            ]
                        })
                    })
                ]
            })
        ]
    });
}
function PersonalSignPage() {
    var _walletQuery_data;
    const { url, go } = (0,_mods_foreground_router_path_context__WEBPACK_IMPORTED_MODULE_26__/* .usePathContext */ .td)().unwrap();
    const { searchParams } = url;
    const background = (0,_mods_foreground_background_context__WEBPACK_IMPORTED_MODULE_13__/* .useBackgroundContext */ .D_)().unwrap();
    const id = _hazae41_option__WEBPACK_IMPORTED_MODULE_29__/* .Option */ .W.wrap(searchParams.get("id")).unwrap();
    const message = _hazae41_option__WEBPACK_IMPORTED_MODULE_29__/* .Option */ .W.wrap(searchParams.get("message")).unwrap();
    const walletId = _hazae41_option__WEBPACK_IMPORTED_MODULE_29__/* .Option */ .W.wrap(searchParams.get("walletId")).unwrap();
    const walletQuery = (0,_mods_foreground_entities_wallets_data__WEBPACK_IMPORTED_MODULE_21__/* .useWallet */ .Os)(walletId);
    const maybeWallet = (_walletQuery_data = walletQuery.data) === null || _walletQuery_data === void 0 ? void 0 : _walletQuery_data.get();
    const userMessage = (0,react__WEBPACK_IMPORTED_MODULE_28__.useMemo)(()=>{
        return message.startsWith("0x") ? _hazae41_bytes__WEBPACK_IMPORTED_MODULE_42__/* .Bytes */ .J.toUtf8(_hazae41_base16__WEBPACK_IMPORTED_MODULE_34__/* .get */ .U().tryPadStartAndDecode(message.slice(2)).unwrap().copyAndDispose()) : message;
    }, [
        message
    ]);
    const onApprove = (0,_libs_react_callback__WEBPACK_IMPORTED_MODULE_4__/* .useAsyncUniqueCallback */ .T)(async ()=>{
        return await _hazae41_result__WEBPACK_IMPORTED_MODULE_31__/* .Result */ .x.unthrow(async (t)=>{
            const wallet = _hazae41_option__WEBPACK_IMPORTED_MODULE_29__/* .Option */ .W.wrap(maybeWallet).ok().throw(t);
            const instance = await _mods_foreground_entities_wallets_data__WEBPACK_IMPORTED_MODULE_21__/* .EthereumWalletInstance */ .Vy.tryFrom(wallet, background).then((r)=>r.throw(t));
            const signature = await instance.trySignPersonalMessage(userMessage, background).then((r)=>r.throw(t));
            await background.tryRequest({
                method: "brume_respond",
                params: [
                    new _hazae41_jsonrpc__WEBPACK_IMPORTED_MODULE_36__/* .RpcOk */ .r(id, signature)
                ]
            }).then((r)=>r.throw(t).throw(t));
            go("/done");
            return _hazae41_result__WEBPACK_IMPORTED_MODULE_37__.Ok.void();
        }).then(_libs_results_results__WEBPACK_IMPORTED_MODULE_8__/* .Results */ .u.logAndAlert);
    }, [
        background,
        id,
        maybeWallet,
        userMessage
    ]);
    const onReject = (0,_libs_react_callback__WEBPACK_IMPORTED_MODULE_4__/* .useAsyncUniqueCallback */ .T)(async ()=>{
        return await _hazae41_result__WEBPACK_IMPORTED_MODULE_31__/* .Result */ .x.unthrow(async (t)=>{
            await background.tryRequest({
                method: "brume_respond",
                params: [
                    _hazae41_jsonrpc__WEBPACK_IMPORTED_MODULE_38__/* .RpcErr */ .s6.rewrap(id, new _hazae41_result__WEBPACK_IMPORTED_MODULE_39__/* .Err */ .U(new _mods_foreground_errors_errors__WEBPACK_IMPORTED_MODULE_22__/* .UserRejectedError */ .Ai()))
                ]
            }).then((r)=>r.throw(t).throw(t));
            go("/done");
            return _hazae41_result__WEBPACK_IMPORTED_MODULE_37__.Ok.void();
        }).then(_libs_results_results__WEBPACK_IMPORTED_MODULE_8__/* .Results */ .u.logAndAlert);
    }, [
        background,
        id
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_libs_ui2_page_page__WEBPACK_IMPORTED_MODULE_12__/* .Page */ .T, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "p-4 grow flex flex-col items-center justify-center",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: "text-center text-xl font-medium",
                        children: "Sign message"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: "w-full max-w-[230px] text-center text-contrast",
                        children: "Do you want to sign the following message?"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "w-full p-4 grow",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                    className: "h-full w-full p-4 border border-contrast rounded-xl whitespace-pre-wrap break-words",
                    children: userMessage
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "p-4 w-full flex items-center gap-2",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_libs_ui_button__WEBPACK_IMPORTED_MODULE_9__/* .Button.Contrast */ .z.mn, {
                        className: "grow po-md hovered-or-clicked-or-focused:scale-105 !transition",
                        onClick: onReject.run,
                        disabled: onReject.loading,
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "".concat(_libs_ui_button__WEBPACK_IMPORTED_MODULE_9__/* .Button.Shrinker */ .z.Np.className),
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_libs_icons_icons__WEBPACK_IMPORTED_MODULE_40__/* ["default"] */ .Z, {
                                    className: "size-5"
                                }),
                                "No, reject it"
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_libs_ui_button__WEBPACK_IMPORTED_MODULE_9__/* .Button.Gradient */ .z.ph, {
                        className: "grow po-md hovered-or-clicked-or-focused:scale-105 !transition",
                        onClick: onApprove.run,
                        disabled: onApprove.loading,
                        colorIndex: 5,
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "".concat(_libs_ui_button__WEBPACK_IMPORTED_MODULE_9__/* .Button.Shrinker */ .z.Np.className),
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_libs_icons_icons__WEBPACK_IMPORTED_MODULE_41__/* ["default"] */ .Z, {
                                    className: "size-5"
                                }),
                                "Yes, approve it"
                            ]
                        })
                    })
                ]
            })
        ]
    });
}
function TypedSignPage() {
    var _walletQuery_data;
    const { url, go } = (0,_mods_foreground_router_path_context__WEBPACK_IMPORTED_MODULE_26__/* .usePathContext */ .td)().unwrap();
    const { searchParams } = url;
    const background = (0,_mods_foreground_background_context__WEBPACK_IMPORTED_MODULE_13__/* .useBackgroundContext */ .D_)().unwrap();
    const id = _hazae41_option__WEBPACK_IMPORTED_MODULE_29__/* .Option */ .W.wrap(searchParams.get("id")).unwrap();
    const data = _hazae41_option__WEBPACK_IMPORTED_MODULE_29__/* .Option */ .W.wrap(searchParams.get("data")).unwrap();
    const walletId = _hazae41_option__WEBPACK_IMPORTED_MODULE_29__/* .Option */ .W.wrap(searchParams.get("walletId")).unwrap();
    const walletQuery = (0,_mods_foreground_entities_wallets_data__WEBPACK_IMPORTED_MODULE_21__/* .useWallet */ .Os)(walletId);
    const maybeWallet = (_walletQuery_data = walletQuery.data) === null || _walletQuery_data === void 0 ? void 0 : _walletQuery_data.get();
    const onApprove = (0,_libs_react_callback__WEBPACK_IMPORTED_MODULE_4__/* .useAsyncUniqueCallback */ .T)(async ()=>{
        return await _hazae41_result__WEBPACK_IMPORTED_MODULE_31__/* .Result */ .x.unthrow(async (t)=>{
            const wallet = _hazae41_option__WEBPACK_IMPORTED_MODULE_29__/* .Option */ .W.wrap(maybeWallet).ok().throw(t);
            const typed = JSON.parse(data);
            const instance = await _mods_foreground_entities_wallets_data__WEBPACK_IMPORTED_MODULE_21__/* .EthereumWalletInstance */ .Vy.tryFrom(wallet, background).then((r)=>r.throw(t));
            const signature = await instance.trySignEIP712HashedMessage(typed, background).then((r)=>r.throw(t));
            await background.tryRequest({
                method: "brume_respond",
                params: [
                    new _hazae41_jsonrpc__WEBPACK_IMPORTED_MODULE_36__/* .RpcOk */ .r(id, signature)
                ]
            }).then((r)=>r.throw(t).throw(t));
            go("/done");
            return _hazae41_result__WEBPACK_IMPORTED_MODULE_37__.Ok.void();
        }).then(_libs_results_results__WEBPACK_IMPORTED_MODULE_8__/* .Results */ .u.logAndAlert);
    }, [
        background,
        id,
        maybeWallet,
        data
    ]);
    const onReject = (0,_libs_react_callback__WEBPACK_IMPORTED_MODULE_4__/* .useAsyncUniqueCallback */ .T)(async ()=>{
        return await _hazae41_result__WEBPACK_IMPORTED_MODULE_31__/* .Result */ .x.unthrow(async (t)=>{
            await background.tryRequest({
                method: "brume_respond",
                params: [
                    _hazae41_jsonrpc__WEBPACK_IMPORTED_MODULE_38__/* .RpcErr */ .s6.rewrap(id, new _hazae41_result__WEBPACK_IMPORTED_MODULE_39__/* .Err */ .U(new _mods_foreground_errors_errors__WEBPACK_IMPORTED_MODULE_22__/* .UserRejectedError */ .Ai()))
                ]
            }).then((r)=>r.throw(t).throw(t));
            go("/done");
            return _hazae41_result__WEBPACK_IMPORTED_MODULE_37__.Ok.void();
        }).then(_libs_results_results__WEBPACK_IMPORTED_MODULE_8__/* .Results */ .u.logAndAlert);
    }, [
        background,
        id
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_libs_ui2_page_page__WEBPACK_IMPORTED_MODULE_12__/* .Page */ .T, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "p-4 grow flex flex-col items-center justify-center",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: "text-center text-xl font-medium",
                        children: "Sign message"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: "w-full max-w-[230px] text-center text-contrast",
                        children: "Do you want to sign the following message?"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "w-full p-4 grow",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                    className: "h-full w-full p-4 border border-contrast rounded-xl whitespace-pre-wrap break-words",
                    children: JSON.stringify(JSON.parse(data))
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "p-4 w-full flex items-center gap-2",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_libs_ui_button__WEBPACK_IMPORTED_MODULE_9__/* .Button.Contrast */ .z.mn, {
                        className: "grow po-md hovered-or-clicked-or-focused:scale-105 !transition",
                        onClick: onReject.run,
                        disabled: onReject.loading,
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "".concat(_libs_ui_button__WEBPACK_IMPORTED_MODULE_9__/* .Button.Shrinker */ .z.Np.className),
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_libs_icons_icons__WEBPACK_IMPORTED_MODULE_40__/* ["default"] */ .Z, {
                                    className: "size-5"
                                }),
                                "No, reject it"
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_libs_ui_button__WEBPACK_IMPORTED_MODULE_9__/* .Button.Gradient */ .z.ph, {
                        className: "grow po-md hovered-or-clicked-or-focused:scale-105 !transition",
                        onClick: onApprove.run,
                        disabled: onApprove.loading,
                        colorIndex: 5,
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "".concat(_libs_ui_button__WEBPACK_IMPORTED_MODULE_9__/* .Button.Shrinker */ .z.Np.className),
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_libs_icons_icons__WEBPACK_IMPORTED_MODULE_41__/* ["default"] */ .Z, {
                                    className: "size-5"
                                }),
                                "Yes, approve it"
                            ]
                        })
                    })
                ]
            })
        ]
    });
}
function WalletAndChainSelectPage() {
    var _wallets_data;
    const { url, go } = (0,_mods_foreground_router_path_context__WEBPACK_IMPORTED_MODULE_26__/* .usePathContext */ .td)().unwrap();
    const { searchParams } = url;
    const background = (0,_mods_foreground_background_context__WEBPACK_IMPORTED_MODULE_13__/* .useBackgroundContext */ .D_)().unwrap();
    const id = _hazae41_option__WEBPACK_IMPORTED_MODULE_29__/* .Option */ .W.wrap(searchParams.get("id")).unwrap();
    const wallets = (0,_mods_foreground_entities_wallets_data__WEBPACK_IMPORTED_MODULE_21__/* .useWallets */ .rB)();
    const creator = (0,_libs_react_handles_boolean__WEBPACK_IMPORTED_MODULE_6__/* .useBooleanHandle */ .x)(false);
    const [persistent, setPersistent] = (0,react__WEBPACK_IMPORTED_MODULE_28__.useState)(true);
    const onPersistentChange = (0,_libs_react_events__WEBPACK_IMPORTED_MODULE_5__/* .useInputChange */ .Xy)((e)=>{
        setPersistent(e.currentTarget.checked);
    }, []);
    const [selecteds, setSelecteds] = (0,react__WEBPACK_IMPORTED_MODULE_28__.useState)([]);
    const [chain, setChain] = (0,react__WEBPACK_IMPORTED_MODULE_28__.useState)(1);
    const onWalletClick = (0,react__WEBPACK_IMPORTED_MODULE_28__.useCallback)((wallet)=>{
        const clone = new Set(selecteds);
        if (clone.has(wallet)) clone.delete(wallet);
        else clone.add(wallet);
        setSelecteds([
            ...clone
        ]);
    }, [
        selecteds
    ]);
    const onApprove = (0,_libs_react_callback__WEBPACK_IMPORTED_MODULE_4__/* .useAsyncUniqueCallback */ .T)(async ()=>{
        return await _hazae41_result__WEBPACK_IMPORTED_MODULE_31__/* .Result */ .x.unthrow(async (t)=>{
            if (selecteds.length === 0) return new _hazae41_result__WEBPACK_IMPORTED_MODULE_39__/* .Err */ .U(new _libs_errors_errors__WEBPACK_IMPORTED_MODULE_2__/* .UIError */ .m("No wallet selected"));
            await background.tryRequest({
                method: "brume_respond",
                params: [
                    new _hazae41_jsonrpc__WEBPACK_IMPORTED_MODULE_36__/* .RpcOk */ .r(id, [
                        persistent,
                        chain,
                        selecteds
                    ])
                ]
            }).then((r)=>r.throw(t).throw(t));
            go("/done");
            return _hazae41_result__WEBPACK_IMPORTED_MODULE_37__.Ok.void();
        }).then(_libs_results_results__WEBPACK_IMPORTED_MODULE_8__/* .Results */ .u.logAndAlert);
    }, [
        background,
        id,
        selecteds,
        chain,
        persistent
    ]);
    const onReject = (0,_libs_react_callback__WEBPACK_IMPORTED_MODULE_4__/* .useAsyncUniqueCallback */ .T)(async ()=>{
        return await _hazae41_result__WEBPACK_IMPORTED_MODULE_31__/* .Result */ .x.unthrow(async (t)=>{
            await background.tryRequest({
                method: "brume_respond",
                params: [
                    _hazae41_jsonrpc__WEBPACK_IMPORTED_MODULE_38__/* .RpcErr */ .s6.rewrap(id, new _hazae41_result__WEBPACK_IMPORTED_MODULE_39__/* .Err */ .U(new _mods_foreground_errors_errors__WEBPACK_IMPORTED_MODULE_22__/* .UserRejectedError */ .Ai()))
                ]
            }).then((r)=>r.throw(t).throw(t));
            go("/done");
            return _hazae41_result__WEBPACK_IMPORTED_MODULE_37__.Ok.void();
        }).then(_libs_results_results__WEBPACK_IMPORTED_MODULE_8__/* .Results */ .u.logAndAlert);
    }, [
        background,
        id
    ]);
    const Body = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_libs_ui2_page_header__WEBPACK_IMPORTED_MODULE_11__/* .PageBody */ .xV, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mods_foreground_entities_wallets_all_page__WEBPACK_IMPORTED_MODULE_20__/* .SelectableWalletGrid */ .Y7, {
                create: creator.enable,
                wallets: (_wallets_data = wallets.data) === null || _wallets_data === void 0 ? void 0 : _wallets_data.get(),
                ok: onWalletClick,
                selecteds: selecteds
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "h-4"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                className: "flex items-center justify-between",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: "",
                        children: "Keep me connected"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("input", {
                        className: "",
                        type: "checkbox",
                        checked: persistent,
                        onChange: onPersistentChange
                    })
                ]
            })
        ]
    });
    const Header = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_libs_ui2_page_header__WEBPACK_IMPORTED_MODULE_11__/* .UserPageHeader */ .To, {
        title: "Select wallets",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_libs_ui_button__WEBPACK_IMPORTED_MODULE_9__/* .Button.Base */ .z.XY, {
            className: "size-8 hovered-or-clicked-or-focused:scale-105 !transition",
            onClick: creator.enable,
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "".concat(_libs_ui_button__WEBPACK_IMPORTED_MODULE_9__/* .Button.Shrinker */ .z.Np.className),
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_libs_icons_icons__WEBPACK_IMPORTED_MODULE_43__/* ["default"] */ .Z, {
                    className: "size-5"
                })
            })
        })
    });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_libs_ui2_page_page__WEBPACK_IMPORTED_MODULE_12__/* .Page */ .T, {
        children: [
            creator.current && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_libs_ui_dialog_dialog__WEBPACK_IMPORTED_MODULE_10__/* .Dialog */ .Vq, {
                close: creator.disable,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mods_foreground_entities_wallets_all_create__WEBPACK_IMPORTED_MODULE_19__/* .WalletCreatorDialog */ ._, {})
            }),
            Header,
            Body,
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "p-4 w-full flex items-center gap-2",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_libs_ui_button__WEBPACK_IMPORTED_MODULE_9__/* .Button.Contrast */ .z.mn, {
                        className: "grow po-md hovered-or-clicked-or-focused:scale-105 !transition",
                        onClick: onReject.run,
                        disabled: onReject.loading,
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "".concat(_libs_ui_button__WEBPACK_IMPORTED_MODULE_9__/* .Button.Shrinker */ .z.Np.className),
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_libs_icons_icons__WEBPACK_IMPORTED_MODULE_40__/* ["default"] */ .Z, {
                                    className: "size-5"
                                }),
                                "No, reject it"
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", {
                        className: "".concat(_libs_ui_button__WEBPACK_IMPORTED_MODULE_9__/* .Button.Base */ .z.XY.className, " ").concat(_libs_ui_button__WEBPACK_IMPORTED_MODULE_9__/* .Button.Gradient */ .z.ph.className(5), " grow po-md hovered-or-clicked-or-focused:scale-105 !transition"),
                        onClick: onApprove.run,
                        disabled: onApprove.loading,
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "".concat(_libs_ui_button__WEBPACK_IMPORTED_MODULE_9__/* .Button.Shrinker */ .z.Np.className),
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_libs_icons_icons__WEBPACK_IMPORTED_MODULE_41__/* ["default"] */ .Z, {
                                    className: "size-5"
                                }),
                                "Yes, approve it"
                            ]
                        })
                    })
                ]
            })
        ]
    });
}
function DonePage() {
    var _useAppRequests_data;
    const { go } = (0,_mods_foreground_router_path_context__WEBPACK_IMPORTED_MODULE_26__/* .usePathContext */ .td)().unwrap();
    const requests = (_useAppRequests_data = (0,_mods_foreground_entities_requests_data__WEBPACK_IMPORTED_MODULE_14__/* .useAppRequests */ .fU)().data) === null || _useAppRequests_data === void 0 ? void 0 : _useAppRequests_data.get();
    (0,react__WEBPACK_IMPORTED_MODULE_28__.useEffect)(()=>{
        if (!(requests === null || requests === void 0 ? void 0 : requests.length)) return;
        go("/requests");
    }, [
        requests
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_libs_ui2_page_page__WEBPACK_IMPORTED_MODULE_12__/* .Page */ .T, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "p-4 grow flex flex-col items-center justify-center",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                    className: "text-center text-xl font-medium",
                    children: "Done"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                    className: "w-full max-w-[230px] text-center text-contrast",
                    children: "You can now close this window or continue using it"
                })
            ]
        })
    });
}


/***/ }),

/***/ 7795:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   W: function() { return /* binding */ BigIntToHex; },
/* harmony export */   l: function() { return /* binding */ BigInts; }
/* harmony export */ });
/* harmony import */ var _swc_helpers_class_private_field_get__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7121);
/* harmony import */ var _swc_helpers_class_private_field_init__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9886);
/* harmony import */ var _swc_helpers_class_private_field_set__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5321);
/* harmony import */ var _hazae41_result__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(918);
/* harmony import */ var ethers__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9288);





var BigIntToHex;
(function(BigIntToHex) {
    function encodeOrThrow(value) {
        return "0x".concat(value.toString(16));
    }
    BigIntToHex.encodeOrThrow = encodeOrThrow;
    function decodeOrThrow(value) {
        return value.length === 2 ? 0n : BigInt(value);
    }
    BigIntToHex.decodeOrThrow = decodeOrThrow;
    function tryDecode(value) {
        return _hazae41_result__WEBPACK_IMPORTED_MODULE_0__/* .Result */ .x.runAndDoubleWrapSync(()=>decodeOrThrow(value));
    }
    BigIntToHex.tryDecode = tryDecode;
})(BigIntToHex || (BigIntToHex = {}));
var BigInts;
(function(BigInts) {
    var _a;
    var _class = /*#__PURE__*/ new WeakMap();
    class ParseError extends Error {
        static from(cause) {
            return new _a({
                cause
            });
        }
        constructor(options){
            super("Could not parse", options);
            (0,_swc_helpers_class_private_field_init__WEBPACK_IMPORTED_MODULE_1__._)(this, _class, {
                writable: true,
                value: void 0
            });
            (0,_swc_helpers_class_private_field_set__WEBPACK_IMPORTED_MODULE_2__._)(this, _class, _a);
            this.name = (0,_swc_helpers_class_private_field_get__WEBPACK_IMPORTED_MODULE_3__._)(this, _class).name;
        }
    }
    _a = ParseError;
    BigInts.ParseError = ParseError;
    function float(x) {
        let d = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 180;
        return ethers__WEBPACK_IMPORTED_MODULE_4__/* .FixedNumber */ .x.fromValue(x, d).round(3).toUnsafeFloat();
    }
    BigInts.float = float;
    function parseOrThrow(text) {
        if (text.trim().length === 0) throw new ParseError();
        return BigInt(text);
    }
    BigInts.parseOrThrow = parseOrThrow;
    function tens(value) {
        return BigInt("1".concat("0".repeat(value)));
    }
    BigInts.tens = tens;
})(BigInts || (BigInts = {}));


/***/ }),

/***/ 2306:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   F: function() { return /* binding */ useCopy; }
/* harmony export */ });
/* harmony import */ var _libs_react_handles_boolean__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5902);
/* harmony import */ var _hazae41_result__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(918);
/* harmony import */ var _react_callback__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7174);



function useCopy(text) {
    const { current, enable, disable } = (0,_libs_react_handles_boolean__WEBPACK_IMPORTED_MODULE_0__/* .useBooleanHandle */ .x)(false);
    const { run } = (0,_react_callback__WEBPACK_IMPORTED_MODULE_1__/* .useAsyncUniqueCallback */ .T)(async ()=>{
        if (!text) return;
        await _hazae41_result__WEBPACK_IMPORTED_MODULE_2__/* .Result */ .x.runAndWrap(async ()=>{
            await navigator.clipboard.writeText(text);
        }).then((r)=>r.ignore());
        enable();
        setTimeout(()=>{
            disable();
        }, 600);
    }, [
        text
    ]);
    return {
        current,
        run
    };
}


/***/ }),

/***/ 9408:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DH: function() { return /* binding */ chainByChainId; },
/* harmony export */   ne: function() { return /* binding */ pairByAddress; },
/* harmony export */   q2: function() { return /* binding */ tokenByAddress; }
/* harmony export */ });
/* unused harmony exports tokenById, pairByName */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);

const chainByChainId = {
    1: {
        name: "Ethereum",
        chainId: 1,
        urls: [
            "wss://ethereum.publicnode.com",
            "wss://mainnet.gateway.tenderly.co"
        ],
        etherscan: "https://etherscan.io",
        token: {
            uuid: "664000af-5c47-4b6e-ab3e-c0c130e23b3c",
            type: "native",
            name: "ETH",
            chainId: 1,
            symbol: "ETH",
            decimals: 18,
            pairs: [
                "0x0d4a11d5eeaac28ec3f61d100daf4d40471f1852"
            ]
        },
        icon () {
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "h-6 w-6 bg-gray-900 rounded-full flex items-center justify-center",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                    className: "w-4 h-4 bg-white",
                    style: {
                        mask: "url(/assets/chains/ethereum.svg) no-repeat center / contain",
                        WebkitMask: "url(/assets/chains/ethereum.svg) no-repeat center / contain"
                    }
                })
            });
        }
    },
    5: {
        name: "Goerli (testnet)",
        chainId: 5,
        urls: [
            "wss://ethereum-goerli.publicnode.com"
        ],
        etherscan: "https://goerli.etherscan.io",
        token: {
            uuid: "664001af-5c47-4b6e-ab3e-c0c130e23b3c",
            type: "native",
            name: "ETH",
            chainId: 5,
            symbol: "ETH",
            decimals: 18
        },
        icon () {
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "h-6 w-6 bg-gray-900 rounded-full flex items-center justify-center text-xs",
                children: "G\xf6"
            });
        }
    },
    10: {
        name: "Optimism",
        chainId: 10,
        urls: [
            "wss://optimism.publicnode.com"
        ],
        etherscan: "https://optimistic.etherscan.io",
        token: {
            uuid: "664002af-5c47-4b6e-ab3e-c0c130e23b3c",
            type: "native",
            name: "ETH",
            chainId: 10,
            symbol: "ETH",
            decimals: 18,
            pairs: [
                "0x0d4a11d5eeaac28ec3f61d100daf4d40471f1852"
            ]
        },
        icon () {
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("img", {
                className: "w-6 h-6",
                src: "/assets/chains/optimism.svg",
                alt: "Optimism"
            });
        }
    },
    56: {
        name: "Binance",
        chainId: 56,
        urls: [
            "wss://bsc.publicnode.com"
        ],
        etherscan: "https://bscscan.com",
        token: {
            uuid: "664003af-5c47-4b6e-ab3e-c0c130e23b3c",
            type: "native",
            name: "BNB",
            chainId: 56,
            symbol: "BNB",
            decimals: 18,
            pairs: [
                "0x16b9a82891338f9ba80e2d6970fdda79d1eb0dae"
            ]
        },
        icon () {
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("img", {
                className: "w-6 h-6",
                src: "/assets/chains/binance.svg",
                alt: "Binance"
            });
        }
    },
    61: {
        name: "Ethereum Classic",
        chainId: 61,
        urls: [
            "https://etc.rivet.link"
        ],
        etherscan: "https://blockscout.com/etc/mainnet/",
        token: {
            uuid: "664004af-5c47-4b6e-ab3e-c0c130e23b3c",
            type: "native",
            name: "ETC",
            chainId: 61,
            symbol: "ETC",
            decimals: 18,
            pairs: [
                "0xdb8721b7a04c3e592264bf58558526b16b15e757"
            ]
        },
        icon () {
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "h-6 w-6 bg-green-500 rounded-full flex items-center justify-center",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                    className: "w-4 h-4 bg-white",
                    style: {
                        mask: "url(/assets/chains/classic.svg) no-repeat center / contain",
                        WebkitMask: "url(/assets/chains/classic.svg) no-repeat center / contain"
                    }
                })
            });
        }
    },
    100: {
        name: "Gnosis",
        chainId: 100,
        urls: [
            "wss://gnosis.publicnode.com"
        ],
        etherscan: "https://gnosisscan.io",
        token: {
            uuid: "664005af-5c47-4b6e-ab3e-c0c130e23b3c",
            type: "native",
            name: "xDAI",
            chainId: 100,
            symbol: "xDAI",
            decimals: 18,
            pairs: []
        },
        icon () {
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "h-6 w-6 bg-emerald-600 rounded-full flex items-center justify-center",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                    className: "w-4 h-4 bg-white",
                    style: {
                        mask: "url(/assets/chains/gnosis.svg) no-repeat center / contain",
                        WebkitMask: "url(/assets/chains/gnosis.svg) no-repeat center / contain"
                    }
                })
            });
        }
    },
    137: {
        name: "Polygon Bor",
        chainId: 137,
        urls: [
            "wss://polygon-bor.publicnode.com"
        ],
        etherscan: "https://polygonscan.com",
        token: {
            uuid: "664006af-5c47-4b6e-ab3e-c0c130e23b3c",
            type: "native",
            name: "MATIC",
            chainId: 137,
            symbol: "MATIC",
            decimals: 18,
            pairs: [
                "0x819f3450dA6f110BA6Ea52195B3beaFa246062dE",
                "0x0d4a11d5eeaac28ec3f61d100daf4d40471f1852"
            ]
        },
        icon () {
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "h-6 w-6 bg-purple-500 rounded-full flex items-center justify-center",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                    className: "w-4 h-4 bg-white",
                    style: {
                        mask: "url(/assets/chains/polygon.svg) no-repeat center / contain",
                        WebkitMask: "url(/assets/chains/polygon.svg) no-repeat center / contain"
                    }
                })
            });
        }
    },
    324: {
        name: "zkSync",
        chainId: 324,
        urls: [
            "https://1rpc.io/zksync2-era"
        ],
        etherscan: "https://explorer.zksync.io/",
        token: {
            uuid: "664007af-5c47-4b6e-ab3e-c0c130e23b3c",
            type: "native",
            name: "ETH",
            chainId: 324,
            symbol: "ETH",
            decimals: 18,
            pairs: [
                "0x0d4a11d5eeaac28ec3f61d100daf4d40471f1852"
            ]
        },
        icon () {
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "h-6 w-6 bg-violet-500 rounded-full flex items-center justify-center",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                    className: "w-4 h-4 bg-white",
                    style: {
                        mask: "url(/assets/chains/zksync.png) no-repeat center / contain",
                        WebkitMask: "url(/assets/chains/zksync.png) no-repeat center / contain"
                    }
                })
            });
        }
    },
    7700: {
        name: "Canto",
        chainId: 7700,
        urls: [
            "https://canto.gravitychain.io"
        ],
        etherscan: "https://cantoscan.com/",
        token: {
            uuid: "c0098941-1a08-4db1-9498-03a4cbceb672",
            type: "native",
            name: "Canto",
            chainId: 7700,
            symbol: "CANTO",
            decimals: 18
        },
        icon () {
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "h-6 w-6 bg-[#111111] rounded-full flex items-center justify-center",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("img", {
                    className: "w-4 h-4",
                    src: "/assets/chains/canto.png",
                    alt: "Canto"
                })
            });
        }
    },
    8453: {
        name: "Base",
        chainId: 8453,
        urls: [
            "wss://base.publicnode.com"
        ],
        etherscan: "https://basescan.org",
        token: {
            uuid: "664008af-5c47-4b6e-ab3e-c0c130e23b3c",
            type: "native",
            name: "ETH",
            chainId: 8453,
            symbol: "ETH",
            decimals: 18,
            pairs: [
                "0x0d4a11d5eeaac28ec3f61d100daf4d40471f1852"
            ]
        },
        icon () {
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "h-6 w-6 bg-blue-500 rounded-full flex items-center justify-center",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                    className: "w-4 h-4 bg-white",
                    style: {
                        mask: "url(/assets/chains/base.svg) no-repeat center / contain",
                        WebkitMask: "url(/assets/chains/base.svg) no-repeat center / contain"
                    }
                })
            });
        }
    },
    42161: {
        name: "Arbitrum One",
        chainId: 42161,
        urls: [
            "wss://arbitrum-one.publicnode.com"
        ],
        etherscan: "https://arbiscan.io",
        token: {
            uuid: "664009af-5c47-4b6e-ab3e-c0c130e23b3c",
            type: "native",
            name: "ETH",
            chainId: 42161,
            symbol: "ETH",
            decimals: 18,
            pairs: [
                "0x0d4a11d5eeaac28ec3f61d100daf4d40471f1852"
            ]
        },
        icon () {
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "h-6 w-6 bg-blue-500 rounded-full flex items-center justify-center",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                    className: "w-4 h-4 bg-white",
                    style: {
                        mask: "url(/assets/chains/arbitrum.png) no-repeat center / contain",
                        WebkitMask: "url(/assets/chains/arbitrum.png) no-repeat center / contain"
                    }
                })
            });
        }
    },
    42220: {
        name: "Celo",
        chainId: 42220,
        urls: [
            "https://1rpc.io/celo"
        ],
        etherscan: "https://celoscan.io",
        token: {
            uuid: "664010af-5c47-4b6e-ab3e-c0c130e23b3c",
            type: "native",
            name: "CELO",
            chainId: 42220,
            symbol: "CELO",
            decimals: 18,
            pairs: [
                "0xf5b1bc6c9c180b64f5711567b1d6a51a350f8422"
            ]
        },
        icon () {
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("img", {
                className: "w-6 h-6",
                src: "/assets/chains/celo.svg",
                alt: "Celo"
            });
        }
    },
    43114: {
        name: "Avalanche C-Chain",
        chainId: 43114,
        urls: [
            "wss://avalanche-c-chain.publicnode.com"
        ],
        etherscan: "https://snowtrace.io",
        token: {
            uuid: "664011af-5c47-4b6e-ab3e-c0c130e23b3c",
            type: "native",
            name: "ETH",
            chainId: 43114,
            symbol: "ETH",
            decimals: 18,
            pairs: [
                "0x0d4a11d5eeaac28ec3f61d100daf4d40471f1852"
            ]
        },
        icon () {
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("img", {
                className: "w-6 h-6",
                src: "/assets/chains/avalanche.png",
                alt: "Avalanche"
            });
        }
    },
    59144: {
        name: "Linea",
        chainId: 59144,
        urls: [
            "https://rpc.linea.build"
        ],
        etherscan: "https://lineascan.build",
        token: {
            uuid: "664012af-5c47-4b6e-ab3e-c0c130e23b3c",
            type: "native",
            name: "ETH",
            chainId: 59144,
            symbol: "ETH",
            decimals: 18,
            pairs: [
                "0x0d4a11d5eeaac28ec3f61d100daf4d40471f1852"
            ]
        },
        icon () {
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("img", {
                className: "w-6 h-6 rounded-full",
                src: "/assets/chains/linea.jpg",
                alt: "Linea"
            });
        }
    },
    11155111: {
        name: "Sepolia (testnet)",
        chainId: 11155111,
        urls: [
            "wss://ethereum-sepolia.publicnode.com"
        ],
        etherscan: "https://sepolia.etherscan.io",
        token: {
            uuid: "664013af-5c47-4b6e-ab3e-c0c130e23b3c",
            type: "native",
            name: "ETH",
            chainId: 11155111,
            symbol: "ETH",
            decimals: 18
        },
        icon () {
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "h-6 w-6 bg-gray-900 rounded-full flex items-center justify-center text-xs",
                children: "Se"
            });
        }
    }
};
const tokenByAddress = {
    "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2": {
        uuid: "7b8dab00-e96b-41aa-b9d8-0ba39d2f96a6",
        type: "contract",
        name: "Wrapped ETH",
        chainId: 1,
        symbol: "WETH",
        decimals: 18,
        address: "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2",
        pairs: [
            "0x0d4a11d5eeaac28ec3f61d100daf4d40471f1852"
        ]
    },
    "0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599": {
        uuid: "7b8dab01-e96b-41aa-b9d8-0ba39d2f96a6",
        type: "contract",
        name: "Wrapped BTC",
        chainId: 1,
        symbol: "WBTC",
        decimals: 8,
        address: "0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599",
        pairs: [
            "0xbb2b8038a1640196fbe3e38816f3e67cba72d940",
            "0x0d4a11d5eeaac28ec3f61d100daf4d40471f1852"
        ]
    },
    "0x6B175474E89094C44Da98b954EedeAC495271d0F": {
        uuid: "7b8dab02-e96b-41aa-b9d8-0ba39d2f96a6",
        type: "contract",
        name: "DAI",
        chainId: 1,
        symbol: "DAI",
        decimals: 18,
        address: "0x6B175474E89094C44Da98b954EedeAC495271d0F",
        pairs: []
    },
    "0xdAC17F958D2ee523a2206206994597C13D831ec7": {
        uuid: "7b8dab03-e96b-41aa-b9d8-0ba39d2f96a6",
        type: "contract",
        name: "Tether USD",
        chainId: 1,
        symbol: "USDT",
        decimals: 6,
        address: "0xdAC17F958D2ee523a2206206994597C13D831ec7",
        pairs: []
    },
    "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48": {
        uuid: "7b8dab04-e96b-41aa-b9d8-0ba39d2f96a6",
        type: "contract",
        name: "USD Coin",
        chainId: 1,
        symbol: "USDC",
        decimals: 6,
        address: "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48",
        pairs: []
    },
    "0x7D1AfA7B718fb893dB30A3aBc0Cfc608AaCfeBB0": {
        uuid: "7b8dab05-e96b-41aa-b9d8-0ba39d2f96a6",
        type: "contract",
        name: "MATIC",
        chainId: 1,
        symbol: "MATIC",
        decimals: 18,
        address: "0x7D1AfA7B718fb893dB30A3aBc0Cfc608AaCfeBB0",
        pairs: [
            "0x819f3450dA6f110BA6Ea52195B3beaFa246062dE",
            "0x0d4a11d5eeaac28ec3f61d100daf4d40471f1852"
        ]
    },
    "0xae7ab96520DE3A18E5e111B5EaAb095312D7fE84": {
        uuid: "7b8dab06-e96b-41aa-b9d8-0ba39d2f96a6",
        type: "contract",
        name: "stETH",
        chainId: 1,
        symbol: "stETH",
        decimals: 18,
        address: "0xae7ab96520DE3A18E5e111B5EaAb095312D7fE84",
        pairs: [
            "0x0d4a11d5eeaac28ec3f61d100daf4d40471f1852"
        ]
    },
    "0x94b008aA00579c1307B0EF2c499aD98a8ce58e58": {
        uuid: "7b8dab07-e96b-41aa-b9d8-0ba39d2f96a6",
        type: "contract",
        name: "Tether USD",
        chainId: 10,
        symbol: "USDT",
        decimals: 6,
        address: "0x94b008aA00579c1307B0EF2c499aD98a8ce58e58",
        pairs: []
    },
    "0x7F5c764cBc14f9669B88837ca1490cCa17c31607": {
        uuid: "7b8dab08-e96b-41aa-b9d8-0ba39d2f96a6",
        type: "contract",
        name: "USD Coin",
        chainId: 10,
        symbol: "USDC",
        decimals: 6,
        address: "0x7F5c764cBc14f9669B88837ca1490cCa17c31607",
        pairs: []
    },
    "0xDA10009cBd5D07dd0CeCc66161FC93D7c9000da1": {
        uuid: "7b8dab09-e96b-41aa-b9d8-0ba39d2f96a6",
        type: "contract",
        name: "DAI",
        chainId: 10,
        symbol: "DAI",
        decimals: 18,
        address: "0xDA10009cBd5D07dd0CeCc66161FC93D7c9000da1",
        pairs: []
    },
    "0x68f180fcCe6836688e9084f035309E29Bf0A2095": {
        uuid: "7b8dab10-e96b-41aa-b9d8-0ba39d2f96a6",
        type: "contract",
        name: "Wrapped BTC",
        chainId: 10,
        symbol: "WBTC",
        decimals: 8,
        address: "0x68f180fcCe6836688e9084f035309E29Bf0A2095",
        pairs: [
            "0xbb2b8038a1640196fbe3e38816f3e67cba72d940",
            "0x0d4a11d5eeaac28ec3f61d100daf4d40471f1852"
        ]
    },
    "0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c": {
        uuid: "7b8dab11-e96b-41aa-b9d8-0ba39d2f96a6",
        type: "contract",
        name: "Wrapped BNB",
        chainId: 56,
        symbol: "WBNB",
        decimals: 18,
        address: "0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c",
        pairs: [
            "0x16b9a82891338f9ba80e2d6970fdda79d1eb0dae"
        ]
    },
    "0x55d398326f99059fF775485246999027B3197955": {
        uuid: "7b8dab12-e96b-41aa-b9d8-0ba39d2f96a6",
        type: "contract",
        name: "Tether USD",
        chainId: 56,
        symbol: "USDT",
        decimals: 18,
        address: "0x55d398326f99059fF775485246999027B3197955",
        pairs: []
    },
    "0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56": {
        uuid: "7b8dab13-e96b-41aa-b9d8-0ba39d2f96a6",
        type: "contract",
        name: "BUSD",
        chainId: 56,
        symbol: "BUSD",
        decimals: 18,
        address: "0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56",
        pairs: []
    },
    "0x3d6545b08693dae087e957cb1180ee38b9e3c25e": {
        uuid: "7b8dab14-e96b-41aa-b9d8-0ba39d2f96a6",
        type: "contract",
        name: "ETC",
        chainId: 56,
        symbol: "ETC",
        decimals: 18,
        address: "0x3d6545b08693dae087e957cb1180ee38b9e3c25e",
        pairs: [
            "0xdb8721b7a04c3e592264bf58558526b16b15e757"
        ]
    },
    "0xc2132D05D31c914a87C6611C10748AEb04B58e8F": {
        uuid: "7b8dab15-e96b-41aa-b9d8-0ba39d2f96a6",
        type: "contract",
        name: "Tether USD",
        chainId: 137,
        symbol: "USDT",
        decimals: 6,
        address: "0xc2132D05D31c914a87C6611C10748AEb04B58e8F",
        pairs: []
    },
    "0x471EcE3750Da237f93B8E339c536989b8978a438": {
        uuid: "7b8dab16-e96b-41aa-b9d8-0ba39d2f96a6",
        type: "contract",
        name: "Wrapped CELO",
        chainId: 42220,
        symbol: "WCELO",
        decimals: 18,
        address: "0x471EcE3750Da237f93B8E339c536989b8978a438",
        pairs: [
            "0xf5b1bc6c9c180b64f5711567b1d6a51a350f8422"
        ]
    },
    "0x64dEFa3544c695db8c535D289d843a189aa26b98": {
        uuid: "7b8dab17-e96b-41aa-b9d8-0ba39d2f96a6",
        type: "contract",
        name: "mCUSD",
        chainId: 42220,
        symbol: "mCUSD",
        decimals: 18,
        address: "0x64dEFa3544c695db8c535D289d843a189aa26b98",
        pairs: []
    }
};
const tokenById = {
    WETH_ON_ETHEREUM: "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2",
    WBTC_ON_ETHEREUM: "0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599",
    DAI_ON_ETHEREUM: "0x6B175474E89094C44Da98b954EedeAC495271d0F",
    USDT_ON_ETHEREUM: "0xdAC17F958D2ee523a2206206994597C13D831ec7",
    USDC_ON_ETHEREUM: "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48",
    MATIC_ON_ETHEREUM: "0x7D1AfA7B718fb893dB30A3aBc0Cfc608AaCfeBB0",
    STETH_ON_ETHEREUM: "0xae7ab96520DE3A18E5e111B5EaAb095312D7fE84",
    WBNB_ON_BINANCE: "0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c",
    USDT_ON_BINANCE: "0x55d398326f99059fF775485246999027B3197955",
    BUSD_ON_BINANCE: "0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56",
    ETC_ON_BINANCE: "0x3d6545b08693dae087e957cb1180ee38b9e3c25e",
    USDT_ON_OPTIMISM: "0x94b008aA00579c1307B0EF2c499aD98a8ce58e58",
    USDC_ON_OPTIMISM: "0x7F5c764cBc14f9669B88837ca1490cCa17c31607",
    DAI_ON_OPTIMISM: "0xDA10009cBd5D07dd0CeCc66161FC93D7c9000da1",
    WBTC_ON_OPTIMISM: "0x68f180fcCe6836688e9084f035309E29Bf0A2095",
    USDT_ON_POLYGON: "0xc2132D05D31c914a87C6611C10748AEb04B58e8F",
    CELO_ON_CELO: "0x471EcE3750Da237f93B8E339c536989b8978a438",
    MSUSD_ON_CELO: "0x64dEFa3544c695db8c535D289d843a189aa26b98"
};
const pairByAddress = {
    "0x0d4a11d5eeaac28ec3f61d100daf4d40471f1852": {
        chainId: 1,
        name: "WETH_USDT",
        address: "0x0d4a11d5eeaac28ec3f61d100daf4d40471f1852",
        token0: tokenById.WETH_ON_ETHEREUM,
        token1: tokenById.USDT_ON_ETHEREUM
    },
    "0xbb2b8038a1640196fbe3e38816f3e67cba72d940": {
        chainId: 1,
        name: "WBTC_WETH",
        address: "0xbb2b8038a1640196fbe3e38816f3e67cba72d940",
        token0: tokenById.WBTC_ON_ETHEREUM,
        token1: tokenById.WETH_ON_ETHEREUM
    },
    "0x819f3450dA6f110BA6Ea52195B3beaFa246062dE": {
        chainId: 1,
        name: "MATIC_WETH",
        address: "0x819f3450dA6f110BA6Ea52195B3beaFa246062dE",
        token0: tokenById.MATIC_ON_ETHEREUM,
        token1: tokenById.WETH_ON_ETHEREUM
    },
    "0x16b9a82891338f9ba80e2d6970fdda79d1eb0dae": {
        chainId: 56,
        name: "USDT_WBNB",
        address: "0x16b9a82891338f9ba80e2d6970fdda79d1eb0dae",
        token0: tokenById.USDT_ON_BINANCE,
        token1: tokenById.WBNB_ON_BINANCE,
        reversed: true
    },
    "0xdb8721b7a04c3e592264bf58558526b16b15e757": {
        chainId: 56,
        name: "ETC_BUSD",
        address: "0xdb8721b7a04c3e592264bf58558526b16b15e757",
        token0: "0x3d6545b08693dae087e957cb1180ee38b9e3c25e",
        token1: "0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56"
    },
    "0xf5b1bc6c9c180b64f5711567b1d6a51a350f8422": {
        chainId: 42220,
        name: "CELO_MCUSD",
        address: "0xf5b1bc6c9c180b64f5711567b1d6a51a350f8422",
        token0: "0x471EcE3750Da237f93B8E339c536989b8978a438",
        token1: "0x64dEFa3544c695db8c535D289d843a189aa26b98"
    }
};
const pairByName = {
    WETH_USDT: "0x0d4a11d5eeaac28ec3f61d100daf4d40471f1852",
    WBTC_WETH: "0xbb2b8038a1640196fbe3e38816f3e67cba72d940",
    MATIC_WETH: "0x819f3450dA6f110BA6Ea52195B3beaFa246062dE",
    USDT_WBNB: "0x16b9a82891338f9ba80e2d6970fdda79d1eb0dae",
    ETC_BUSD: "0xdb8721b7a04c3e592264bf58558526b16b15e757",
    CELO_MCUSD: "0xf5b1bc6c9c180b64f5711567b1d6a51a350f8422"
};


/***/ }),

/***/ 2029:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  P: function() { return /* reexport */ mods_namespaceObject; }
});

// NAMESPACE OBJECT: ./src/libs/ledger/mods/ethereum/index.ts
var mods_ethereum_namespaceObject = {};
__webpack_require__.r(mods_ethereum_namespaceObject);
__webpack_require__.d(mods_ethereum_namespaceObject, {
  getAddressOrThrow: function() { return getAddressOrThrow; },
  getAppConfigOrThrow: function() { return getAppConfigOrThrow; },
  readLegacyUnprotectedOrThrow: function() { return readLegacyUnprotectedOrThrow; },
  signEIP712HashedMessageOrThrow: function() { return signEIP712HashedMessageOrThrow; },
  signPersonalMessageOrThrow: function() { return signPersonalMessageOrThrow; },
  signTransactionOrThrow: function() { return signTransactionOrThrow; },
  tryGetAddress: function() { return tryGetAddress; },
  tryGetAppConfig: function() { return tryGetAppConfig; },
  trySignEIP712HashedMessage: function() { return trySignEIP712HashedMessage; },
  trySignPersonalMessage: function() { return trySignPersonalMessage; },
  trySignTransaction: function() { return trySignTransaction; },
  tryVerifyAndGetAddress: function() { return tryVerifyAndGetAddress; },
  verifyAndGetAddressOrThrow: function() { return verifyAndGetAddressOrThrow; }
});

// NAMESPACE OBJECT: ./src/libs/ledger/mods/usb/index.ts
var mods_usb_namespaceObject = {};
__webpack_require__.r(mods_usb_namespaceObject);
__webpack_require__.d(mods_usb_namespaceObject, {
  DeviceConfigError: function() { return DeviceConfigError; },
  DeviceInterfaceClaimError: function() { return DeviceInterfaceClaimError; },
  DeviceInterfaceNotFoundError: function() { return DeviceInterfaceNotFoundError; },
  DeviceNotFoundError: function() { return DeviceNotFoundError; },
  DeviceOpenError: function() { return DeviceOpenError; },
  DeviceResetError: function() { return DeviceResetError; },
  DeviceTransferInError: function() { return DeviceTransferInError; },
  DeviceTransferOutError: function() { return DeviceTransferOutError; },
  LedgerUSBDevice: function() { return LedgerUSBDevice; },
  PACKET_SIZE: function() { return PACKET_SIZE; },
  VENDOR_ID: function() { return VENDOR_ID; },
  tryConnect: function() { return tryConnect; },
  tryRequest: function() { return tryRequest; }
});

// NAMESPACE OBJECT: ./src/libs/ledger/mods/index.ts
var mods_namespaceObject = {};
__webpack_require__.r(mods_namespaceObject);
__webpack_require__.d(mods_namespaceObject, {
  kJ: function() { return mods_ethereum_namespaceObject; },
  vB: function() { return mods_usb_namespaceObject; }
});

// EXTERNAL MODULE: ./node_modules/@hazae41/base16/dist/esm/src/mods/base16/adapter.mjs
var adapter = __webpack_require__(2248);
// EXTERNAL MODULE: ./node_modules/@hazae41/binary/dist/esm/mods/binary/empty.mjs
var empty = __webpack_require__(1543);
// EXTERNAL MODULE: ./node_modules/@hazae41/binary/dist/esm/mods/binary/writable.mjs
var writable = __webpack_require__(2008);
// EXTERNAL MODULE: ./node_modules/@hazae41/binary/dist/esm/mods/binary/opaque.mjs
var opaque = __webpack_require__(2794);
// EXTERNAL MODULE: ./node_modules/@hazae41/binary/dist/esm/mods/binary/readable.mjs
var readable = __webpack_require__(1916);
// EXTERNAL MODULE: ./node_modules/@hazae41/bytes/dist/esm/mods/bytes/bytes.mjs + 3 modules
var bytes_bytes = __webpack_require__(1694);
// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/rlp/rlp.mjs
var rlp_rlp = __webpack_require__(4864);
// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/rlp/index.mjs
var mods_rlp = __webpack_require__(6931);
// EXTERNAL MODULE: ./node_modules/@hazae41/cursor/dist/esm/mods/cursor/cursor.mjs + 5 modules
var cursor_cursor = __webpack_require__(6677);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/result.mjs
var result = __webpack_require__(918);
;// CONCATENATED MODULE: ./src/libs/ledger/mods/common/binary/paths.ts
class Paths {
    static from(path) {
        const paths = new Array();
        for (const subpath of path.split("/")){
            const value = subpath.endsWith("'") ? parseInt(subpath, 10) + 2147483648 : parseInt(subpath, 10);
            paths.push(value);
        }
        return new Paths(paths);
    }
    sizeOrThrow() {
        return 1 + this.paths.length * 4;
    }
    writeOrThrow(cursor) {
        cursor.writeUint8OrThrow(this.paths.length);
        for (const path of this.paths)cursor.writeUint32OrThrow(path);
        return;
    }
    constructor(paths){
        this.paths = paths;
    }
}

;// CONCATENATED MODULE: ./src/libs/ledger/mods/ethereum/ethereum.ts
var __addDisposableResource = undefined && undefined.__addDisposableResource || function(env, value, async) {
    if (value !== null && value !== void 0) {
        if (typeof value !== "object" && typeof value !== "function") throw new TypeError("Object expected.");
        var dispose;
        if (async) {
            if (!Symbol.asyncDispose) throw new TypeError("Symbol.asyncDispose is not defined.");
            dispose = value[Symbol.asyncDispose];
        }
        if (dispose === void 0) {
            if (!Symbol.dispose) throw new TypeError("Symbol.dispose is not defined.");
            dispose = value[Symbol.dispose];
        }
        if (typeof dispose !== "function") throw new TypeError("Object not disposable.");
        env.stack.push({
            value: value,
            dispose: dispose,
            async: async
        });
    } else if (async) {
        env.stack.push({
            async: true
        });
    }
    return value;
};
var __disposeResources = undefined && undefined.__disposeResources || function(SuppressedError1) {
    return function(env) {
        function fail(e) {
            env.error = env.hasError ? new SuppressedError1(e, env.error, "An error was suppressed during disposal.") : e;
            env.hasError = true;
        }
        function next() {
            while(env.stack.length){
                var rec = env.stack.pop();
                try {
                    var result = rec.dispose && rec.dispose.call(rec.value);
                    if (rec.async) return Promise.resolve(result).then(next, function(e) {
                        fail(e);
                        return next();
                    });
                } catch (e) {
                    fail(e);
                }
            }
            if (env.hasError) throw env.error;
        }
        return next();
    };
}(typeof SuppressedError === "function" ? SuppressedError : function(error, suppressed, message) {
    var e = new Error(message);
    return e.name = "SuppressedError", e.error = error, e.suppressed = suppressed, e;
});







async function tryGetAppConfig(device) {
    return await result/* Result */.x.runAndDoubleWrap(()=>getAppConfigOrThrow(device));
}
async function getAppConfigOrThrow(device) {
    const request = {
        cla: 0xe0,
        ins: 0x06,
        p1: 0x00,
        p2: 0x00,
        fragment: new empty/* Empty */.H()
    };
    const response = await device.requestOrThrow(request).then((r)=>r.unwrap().bytes);
    const arbitraryDataEnabled = Boolean(response[0] & 0x01);
    const erc20ProvisioningNecessary = Boolean(response[0] & 0x02);
    const starkEnabled = Boolean(response[0] & 0x04);
    const starkv2Supported = Boolean(response[0] & 0x08);
    const version = "".concat(response[1], ".").concat(response[2], ".").concat(response[3]);
    return {
        arbitraryDataEnabled,
        erc20ProvisioningNecessary,
        starkEnabled,
        starkv2Supported,
        version
    };
}
/**
 * Just get the address
 * @param device
 * @param path
 * @returns
 */ async function tryGetAddress(device, path) {
    return await result/* Result */.x.runAndDoubleWrap(()=>getAddressOrThrow(device, path));
}
/**
 * Just get the address
 * @param device
 * @param path
 * @returns
 */ async function getAddressOrThrow(device, path) {
    const paths = Paths.from(path);
    const bytes = writable/* Writable */.c.writeToBytesOrThrow(paths);
    const request = {
        cla: 0xe0,
        ins: 0x02,
        p1: 0x00,
        p2: 0x01,
        fragment: new opaque/* Opaque */.lD(bytes)
    };
    const response = await device.requestOrThrow(request).then((r)=>r.unwrap().bytes);
    const cursor = new cursor_cursor/* Cursor */.C(response);
    const uncompressedPublicKeyLength = cursor.readUint8OrThrow();
    const uncompressedPublicKey = cursor.readAndCopyOrThrow(uncompressedPublicKeyLength);
    const addressLength = cursor.readUint8OrThrow();
    const address = "0x".concat(bytes_bytes/* Bytes */.J.toAscii(cursor.readOrThrow(addressLength)));
    const chaincode = cursor.readAndCopyOrThrow(32);
    return {
        uncompressedPublicKey,
        address,
        chaincode
    };
}
/**
 * Ask the user to verify the address and get it
 * @param device
 * @param path
 * @returns
 */ async function tryVerifyAndGetAddress(device, path) {
    return await result/* Result */.x.runAndDoubleWrap(()=>verifyAndGetAddressOrThrow(device, path));
}
/**
 * Ask the user to verify the address and get it
 * @param device
 * @param path
 * @returns
 */ async function verifyAndGetAddressOrThrow(device, path) {
    const paths = Paths.from(path);
    const bytes = writable/* Writable */.c.writeToBytesOrThrow(paths);
    const request = {
        cla: 0xe0,
        ins: 0x02,
        p1: 0x01,
        p2: 0x01,
        fragment: new opaque/* Opaque */.lD(bytes)
    };
    const response = await device.requestOrThrow(request).then((r)=>r.unwrap().bytes);
    const cursor = new cursor_cursor/* Cursor */.C(response);
    const uncompressedPublicKeyLength = cursor.readUint8OrThrow();
    const uncompressedPublicKey = cursor.readAndCopyOrThrow(uncompressedPublicKeyLength);
    const addressLength = cursor.readUint8OrThrow();
    const address = "0x".concat(bytes_bytes/* Bytes */.J.toAscii(cursor.readOrThrow(addressLength)));
    const chaincode = cursor.readAndCopyOrThrow(32);
    return {
        uncompressedPublicKey,
        address,
        chaincode
    };
}
async function trySignPersonalMessage(device, path, message) {
    return await result/* Result */.x.runAndDoubleWrap(()=>signPersonalMessageOrThrow(device, path, message));
}
async function signPersonalMessageOrThrow(device, path, message) {
    const paths = Paths.from(path);
    const reader = new cursor_cursor/* Cursor */.C(message);
    let response;
    {
        const head = paths.sizeOrThrow() + 4;
        const body = Math.min(150 - head, reader.remaining);
        const chunk = reader.readOrThrow(body);
        const writer = new cursor_cursor/* Cursor */.C(new Uint8Array(head + body));
        paths.writeOrThrow(writer);
        writer.writeUint32OrThrow(message.length);
        writer.writeOrThrow(chunk);
        const request = {
            cla: 0xe0,
            ins: 0x08,
            p1: 0x00,
            p2: 0x00,
            fragment: new opaque/* Opaque */.lD(writer.bytes)
        };
        response = await device.requestOrThrow(request).then((r)=>r.unwrap().bytes);
    }
    while(reader.remaining){
        const body = Math.min(150, reader.remaining);
        const chunk = reader.readOrThrow(body);
        const request = {
            cla: 0xe0,
            ins: 0x08,
            p1: 0x80,
            p2: 0x00,
            fragment: new opaque/* Opaque */.lD(chunk)
        };
        response = await device.requestOrThrow(request).then((r)=>r.unwrap().bytes);
    }
    const cursor = new cursor_cursor/* Cursor */.C(response);
    const v = cursor.readUint8OrThrow() - 27;
    const r = cursor.readAndCopyOrThrow(32);
    const s = cursor.readAndCopyOrThrow(32);
    return {
        v,
        r,
        s
    };
}
/**
 * Get the unprotected part of a legacy replay-protected transaction
 * @param bytes
 * @returns
 */ function readLegacyUnprotectedOrThrow(bytes) {
    /**
     * This is not a legacy transaction (EIP-2718)
     */ if (bytes[0] < 0x80) return undefined;
    /**
     * Decode the bytes as RLP
     */ const rlp = rlp_rlp/* toPrimitive */.vb(readable/* Readable */.$.readFromBytesOrThrow(mods_rlp, bytes));
    if (!Array.isArray(rlp)) throw new Error("Wrong RLP type for transaction");
    /**
     * This is not a replay-protected transaction (EIP-155)
     */ if (rlp.length !== 9) return undefined;
    /**
     * Take only the first 6 parameters instead of the 9
     */ const [nonce, gasprice, startgas, to, value, data] = rlp;
    /**
     * Encode them as RLP
     */ return writable/* Writable */.c.writeToBytesOrThrow(rlp_rlp/* fromPrimitive */.Zl([
        nonce,
        gasprice,
        startgas,
        to,
        value,
        data
    ]));
}
async function trySignTransaction(device, path, transaction) {
    return await result/* Result */.x.runAndDoubleWrap(()=>signTransactionOrThrow(device, path, transaction));
}
async function signTransactionOrThrow(device, path, transaction) {
    const env_1 = {
        stack: [],
        error: void 0,
        hasError: false
    };
    try {
        const paths = Paths.from(path);
        const slice = __addDisposableResource(env_1, adapter/* get */.U().padStartAndDecodeOrThrow(transaction.unsignedSerialized.slice(2)), false);
        const reader = new cursor_cursor/* Cursor */.C(slice.bytes);
        const unprotected = readLegacyUnprotectedOrThrow(slice.bytes);
        let response;
        {
            const head = paths.sizeOrThrow();
            let body = Math.min(150 - head, reader.remaining);
            /**
             * Make sure that the chunk doesn't end right on the replay protection marker (EIP-155)
             * If it goes further than the unprotected part, then send the (few) remaining bytes of the protection
             */ if (unprotected != null && reader.offset + body >= unprotected.length) body = reader.remaining;
            const chunk = reader.readOrThrow(body);
            const writer = new cursor_cursor/* Cursor */.C(new Uint8Array(head + body));
            paths.writeOrThrow(writer);
            writer.writeOrThrow(chunk);
            const request = {
                cla: 0xe0,
                ins: 0x04,
                p1: 0x00,
                p2: 0x00,
                fragment: new opaque/* Opaque */.lD(writer.bytes)
            };
            response = await device.requestOrThrow(request).then((r)=>r.unwrap().bytes);
        }
        while(reader.remaining){
            let body = Math.min(150, reader.remaining);
            /**
             * Make sure that the chunk doesn't end right on the replay protection marker (EIP-155)
             * If it goes further than the unprotected part, then send the (few) remaining bytes of the protection
             */ if (unprotected != null && reader.offset + body >= unprotected.length) body = reader.remaining;
            const chunk = reader.readOrThrow(body);
            const request = {
                cla: 0xe0,
                ins: 0x04,
                p1: 0x80,
                p2: 0x00,
                fragment: new opaque/* Opaque */.lD(chunk)
            };
            response = await device.requestOrThrow(request).then((r)=>r.unwrap().bytes);
        }
        const cursor = new cursor_cursor/* Cursor */.C(response);
        const v = cursor.readUint8OrThrow();
        const r = cursor.readAndCopyOrThrow(32);
        const s = cursor.readAndCopyOrThrow(32);
        // if ((((chainId * 2) + 35) + 1) > 255) {
        //   const parity = Math.abs(v0 - (((chainId * 2) + 35) % 256))
        //   if (transaction.type == null)
        //     v = ((chainId * 2) + 35) + parity
        //   else
        //     v = (parity % 2) == 1 ? 0 : 1;
        // }
        return {
            v,
            r,
            s
        };
    } catch (e_1) {
        env_1.error = e_1;
        env_1.hasError = true;
    } finally{
        __disposeResources(env_1);
    }
}
async function trySignEIP712HashedMessage(device, path, domain, message) {
    return await result/* Result */.x.runAndDoubleWrap(()=>signEIP712HashedMessageOrThrow(device, path, domain, message));
}
async function signEIP712HashedMessageOrThrow(device, path, domain, message) {
    const paths = Paths.from(path);
    const writer = new cursor_cursor/* Cursor */.C(new Uint8Array(paths.sizeOrThrow() + 32 + 32));
    paths.writeOrThrow(writer);
    writer.writeOrThrow(domain);
    writer.writeOrThrow(message);
    const request = {
        cla: 0xe0,
        ins: 0x0c,
        p1: 0x00,
        p2: 0x00,
        fragment: new opaque/* Opaque */.lD(writer.bytes)
    };
    const response = await device.requestOrThrow(request).then((r)=>r.unwrap().bytes);
    const reader = new cursor_cursor/* Cursor */.C(response);
    const v = reader.readUint8OrThrow() - 27;
    const r = reader.readAndCopyOrThrow(32);
    const s = reader.readAndCopyOrThrow(32);
    return {
        v,
        r,
        s
    };
}

;// CONCATENATED MODULE: ./src/libs/ledger/mods/ethereum/index.ts


// EXTERNAL MODULE: ./node_modules/@swc/helpers/esm/_class_private_field_get.js + 1 modules
var _class_private_field_get = __webpack_require__(7121);
// EXTERNAL MODULE: ./node_modules/@swc/helpers/esm/_class_private_field_init.js
var _class_private_field_init = __webpack_require__(9886);
// EXTERNAL MODULE: ./node_modules/@swc/helpers/esm/_class_private_field_set.js + 1 modules
var _class_private_field_set = __webpack_require__(5321);
// EXTERNAL MODULE: ./node_modules/@swc/helpers/esm/_class_private_method_get.js
var _class_private_method_get = __webpack_require__(6723);
// EXTERNAL MODULE: ./node_modules/@swc/helpers/esm/_class_private_method_init.js
var _class_private_method_init = __webpack_require__(9979);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/ok.mjs
var ok = __webpack_require__(5591);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/err.mjs
var err = __webpack_require__(166);
;// CONCATENATED MODULE: ./src/libs/ledger/libs/apdu/request.ts



var _a;
var _class = /*#__PURE__*/ new WeakMap();
class ApduDataOverflowError extends Error {
    constructor(length){
        super("Data overflow (".concat(length, " > 255)"));
        (0,_class_private_field_init._)(this, _class, {
            writable: true,
            value: void 0
        });
        (0,_class_private_field_set._)(this, _class, _a);
        this.name = (0,_class_private_field_get._)(this, _class).name;
        this.length = length;
    }
}
_a = ApduDataOverflowError;
class ApduRequest {
    static fromOrThrow(init) {
        const { cla, ins, p1, p2, fragment } = init;
        const fragmentSize = fragment.sizeOrThrow();
        if (fragmentSize > 255) throw new ApduDataOverflowError(fragmentSize);
        return new ApduRequest(cla, ins, p1, p2, fragment, fragmentSize);
    }
    sizeOrThrow() {
        return 1 + 1 + 1 + 1 + 1 + this.fragmentSize;
    }
    writeOrThrow(cursor) {
        cursor.writeUint8OrThrow(this.cla);
        cursor.writeUint8OrThrow(this.ins);
        cursor.writeUint8OrThrow(this.p1);
        cursor.writeUint8OrThrow(this.p2);
        cursor.writeUint8OrThrow(this.fragmentSize);
        this.fragment.writeOrThrow(cursor);
    }
    constructor(cla, ins, p1, p2, fragment, fragmentSize){
        this.cla = cla;
        this.ins = ins;
        this.p1 = p1;
        this.p2 = p2;
        this.fragment = fragment;
        this.fragmentSize = fragmentSize;
    }
}

;// CONCATENATED MODULE: ./src/libs/ledger/libs/apdu/response.ts



var response_a, _b;


var ApduResponse;
(function(ApduResponse) {
    function readOrThrow(cursor) {
        const bytes = cursor.readAndCopyOrThrow(cursor.remaining - 2);
        const status = cursor.readUint16OrThrow();
        const fragment = new opaque/* Opaque */.lD(bytes);
        if (status === ApduOk.status) return new ApduOk(fragment);
        return new ApduErr(status, fragment);
    }
    ApduResponse.readOrThrow = readOrThrow;
})(ApduResponse || (ApduResponse = {}));
var response_class = /*#__PURE__*/ new WeakMap();
class ApduError extends Error {
    constructor(status, fragment){
        super("".concat(status));
        (0,_class_private_field_init._)(this, response_class, {
            writable: true,
            value: void 0
        });
        (0,_class_private_field_set._)(this, response_class, response_a);
        this.name = (0,_class_private_field_get._)(this, response_class).name;
        this.status = status;
        this.fragment = fragment;
    }
}
response_a = ApduError;
var _class1 = /*#__PURE__*/ new WeakMap();
class ApduOk extends ok.Ok {
    get status() {
        return (0,_class_private_field_get._)(this, _class1).status;
    }
    constructor(fragment){
        super(fragment);
        (0,_class_private_field_init._)(this, _class1, {
            writable: true,
            value: void 0
        });
        (0,_class_private_field_set._)(this, _class1, _b);
        this.fragment = fragment;
    }
}
ApduOk.status = 0x9000;
_b = ApduOk;
class ApduErr extends err/* Err */.U {
    constructor(status, fragment){
        super(new ApduError(status, fragment));
        this.status = status;
        this.fragment = fragment;
    }
}

;// CONCATENATED MODULE: ./src/libs/ledger/libs/hid/frame.ts



var frame_a, frame_b;


var frame_class = /*#__PURE__*/ new WeakMap();
class InvalidTagError extends Error {
    constructor(tag){
        super("Invalid tag ".concat(tag));
        (0,_class_private_field_init._)(this, frame_class, {
            writable: true,
            value: void 0
        });
        (0,_class_private_field_set._)(this, frame_class, frame_a);
        this.name = (0,_class_private_field_get._)(this, frame_class).name;
        this.tag = tag;
    }
}
frame_a = InvalidTagError;
var frame_class1 = /*#__PURE__*/ new WeakMap();
class HIDFrame {
    sizeOrThrow() {
        return 2 + 1 + 2 + this.fragment.sizeOrThrow();
    }
    writeOrThrow(cursor) {
        cursor.writeUint16OrThrow(this.channel);
        cursor.writeUint8OrThrow((0,_class_private_field_get._)(this, frame_class1).tag);
        cursor.writeUint16OrThrow(this.index);
        this.fragment.writeOrThrow(cursor);
    }
    static readOrThrow(cursor) {
        const channel = cursor.readUint16OrThrow();
        const tag = cursor.readUint8OrThrow();
        if (tag !== this.tag) throw new InvalidTagError(tag);
        const index = cursor.readUint16OrThrow();
        const bytes = cursor.readAndCopyOrThrow(cursor.remaining);
        const fragment = new opaque/* Opaque */.lD(bytes);
        return new frame_b(channel, fragment, index);
    }
    static *splitOrThrow(channel, bytes) {
        const chunks = new cursor_cursor/* Cursor */.C(bytes).splitOrThrow(59);
        let chunk = chunks.next();
        for(let i = 0; !chunk.done; chunk = chunks.next(), i++)yield new frame_b(channel, new opaque/* Opaque */.lD(chunk.value), i);
        return chunk.value;
    }
    static async unsplitOrThrow(channel, generator) {
        const first = await generator.next();
        if (first.done) return first.value;
        const frames = readable/* Readable */.$.readFromBytesOrThrow(HIDContainer, first.value.fragment.bytes);
        const bytes = new Uint8Array(frames.length);
        const cursor = new cursor_cursor/* Cursor */.C(bytes);
        cursor.writeOrThrow(frames.fragment.bytes.slice(0, cursor.remaining));
        if (!cursor.remaining) return cursor.bytes;
        let frame = await generator.next();
        for(; !frame.done; frame = await generator.next()){
            cursor.writeOrThrow(frame.value.fragment.bytes.slice(0, cursor.remaining));
            if (!cursor.remaining) return cursor.bytes;
            continue;
        }
        return frame.value;
    }
    constructor(channel, fragment, index){
        (0,_class_private_field_init._)(this, frame_class1, {
            writable: true,
            value: void 0
        });
        (0,_class_private_field_set._)(this, frame_class1, frame_b);
        this.channel = channel;
        this.fragment = fragment;
        this.index = index;
    }
}
HIDFrame.tag = 0x05;
frame_b = HIDFrame;
class HIDContainer {
    static newOrThrow(fragment) {
        return new HIDContainer(fragment.sizeOrThrow(), fragment);
    }
    sizeOrThrow() {
        return Math.ceil((2 + this.length) / 59) * 59;
    }
    writeOrThrow(cursor) {
        cursor.writeUint16OrThrow(this.length);
        this.fragment.writeOrThrow(cursor);
        cursor.fillOrThrow(0, cursor.remaining);
    }
    static readOrThrow(cursor) {
        const length = cursor.readUint16OrThrow();
        const bytes = cursor.readAndCopyOrThrow(cursor.remaining);
        const fragment = new opaque/* Opaque */.lD(bytes);
        return new HIDContainer(length, fragment);
    }
    constructor(length, fragment){
        this.length = length;
        this.fragment = fragment;
    }
}

;// CONCATENATED MODULE: ./src/libs/ledger/mods/usb/usb.ts





var usb_a, usb_b, _c, _d, _e, _f, _g, _h;






const VENDOR_ID = 0x2c97;
const PACKET_SIZE = 64;
var usb_class = /*#__PURE__*/ new WeakMap();
class DeviceNotFoundError extends Error {
    static from(cause) {
        return new usb_a({
            cause
        });
    }
    constructor(options){
        super("Could not find device", options);
        (0,_class_private_field_init._)(this, usb_class, {
            writable: true,
            value: void 0
        });
        (0,_class_private_field_set._)(this, usb_class, usb_a);
        this.name = (0,_class_private_field_get._)(this, usb_class).name;
    }
}
usb_a = DeviceNotFoundError;
var usb_class1 = /*#__PURE__*/ new WeakMap();
class DeviceOpenError extends Error {
    static from(cause) {
        return new usb_b({
            cause
        });
    }
    constructor(options){
        super("Could not open device", options);
        (0,_class_private_field_init._)(this, usb_class1, {
            writable: true,
            value: void 0
        });
        (0,_class_private_field_set._)(this, usb_class1, usb_b);
        this.name = (0,_class_private_field_get._)(this, usb_class1).name;
    }
}
usb_b = DeviceOpenError;
var _class2 = /*#__PURE__*/ new WeakMap();
class DeviceConfigError extends Error {
    static from(cause) {
        return new _c({
            cause
        });
    }
    constructor(options){
        super("Could not configure device", options);
        (0,_class_private_field_init._)(this, _class2, {
            writable: true,
            value: void 0
        });
        (0,_class_private_field_set._)(this, _class2, _c);
        this.name = (0,_class_private_field_get._)(this, _class2).name;
    }
}
_c = DeviceConfigError;
var _class3 = /*#__PURE__*/ new WeakMap();
class DeviceResetError extends Error {
    static from(cause) {
        return new _d({
            cause
        });
    }
    constructor(options){
        super("Could not reset device", options);
        (0,_class_private_field_init._)(this, _class3, {
            writable: true,
            value: void 0
        });
        (0,_class_private_field_set._)(this, _class3, _d);
        this.name = (0,_class_private_field_get._)(this, _class3).name;
    }
}
_d = DeviceResetError;
var _class4 = /*#__PURE__*/ new WeakMap();
class DeviceInterfaceNotFoundError extends Error {
    static from(cause) {
        return new _e({
            cause
        });
    }
    constructor(options){
        super("Could not find device interface", options);
        (0,_class_private_field_init._)(this, _class4, {
            writable: true,
            value: void 0
        });
        (0,_class_private_field_set._)(this, _class4, _e);
        this.name = (0,_class_private_field_get._)(this, _class4).name;
    }
}
_e = DeviceInterfaceNotFoundError;
var _class5 = /*#__PURE__*/ new WeakMap();
class DeviceInterfaceClaimError extends Error {
    static from(cause) {
        return new _f({
            cause
        });
    }
    constructor(options){
        super("Could not claim device interface", options);
        (0,_class_private_field_init._)(this, _class5, {
            writable: true,
            value: void 0
        });
        (0,_class_private_field_set._)(this, _class5, _f);
        this.name = (0,_class_private_field_get._)(this, _class5).name;
    }
}
_f = DeviceInterfaceClaimError;
var _class6 = /*#__PURE__*/ new WeakMap();
class DeviceTransferOutError extends Error {
    static from(cause) {
        return new _g({
            cause
        });
    }
    constructor(options){
        super("Could not transfer data to device", options);
        (0,_class_private_field_init._)(this, _class6, {
            writable: true,
            value: void 0
        });
        (0,_class_private_field_set._)(this, _class6, _g);
        this.name = (0,_class_private_field_get._)(this, _class6).name;
    }
}
_g = DeviceTransferOutError;
var _class7 = /*#__PURE__*/ new WeakMap();
class DeviceTransferInError extends Error {
    static from(cause) {
        return new _h({
            cause
        });
    }
    constructor(options){
        super("Could not transfer data from device", options);
        (0,_class_private_field_init._)(this, _class7, {
            writable: true,
            value: void 0
        });
        (0,_class_private_field_set._)(this, _class7, _h);
        this.name = (0,_class_private_field_get._)(this, _class7).name;
    }
}
_h = DeviceTransferInError;
async function tryRequest() {
    return await result/* Result */.x.unthrow(async (t)=>{
        const devices = await result/* Result */.x.runAndWrap(async ()=>{
            return await navigator.usb.getDevices();
        }).then((r)=>r.mapErrSync(DeviceNotFoundError.from).throw(t));
        const device = devices.find((x)=>x.vendorId === VENDOR_ID);
        if (device != null) return new ok.Ok(device);
        const device2 = await result/* Result */.x.runAndWrap(async ()=>{
            return await navigator.usb.requestDevice({
                filters: [
                    {
                        vendorId: VENDOR_ID
                    }
                ]
            });
        }).then((r)=>r.mapErrSync(DeviceNotFoundError.from).throw(t));
        return new ok.Ok(device2);
    });
}
async function tryConnect() {
    return await result/* Result */.x.unthrow(async (t)=>{
        const device = await tryRequest().then((r)=>r.throw(t));
        await result/* Result */.x.runAndWrap(async ()=>{
            return await device.open();
        }).then((r)=>r.mapErrSync(DeviceOpenError.from).throw(t));
        if (device.configuration == null) await result/* Result */.x.runAndWrap(async ()=>{
            return await device.selectConfiguration(1);
        }).then((r)=>r.mapErrSync(DeviceConfigError.from).throw(t));
        await result/* Result */.x.runAndWrap(async ()=>{
            return await device.reset();
        }).then((r)=>r.mapErrSync(DeviceResetError.from).inspectErrSync(console.warn));
        const iface = device.configurations[0].interfaces.find((param)=>{
            let { alternates } = param;
            return alternates.some((x)=>x.interfaceClass === 255);
        });
        if (iface == null) return new err/* Err */.U(new DeviceInterfaceNotFoundError());
        await result/* Result */.x.runAndWrap(async ()=>{
            return await device.claimInterface(iface.interfaceNumber);
        }).then((r)=>r.mapErrSync(DeviceInterfaceClaimError.from).throw(t));
        return new ok.Ok(new LedgerUSBDevice(device, iface));
    });
}
var _channel = /*#__PURE__*/ new WeakMap(), _transferOutOrThrow = /*#__PURE__*/ new WeakSet(), _transferInOrThrow = /*#__PURE__*/ new WeakSet(), _sendOrThrow = /*#__PURE__*/ new WeakSet(), _receiveOrThrow = /*#__PURE__*/ new WeakSet();
class LedgerUSBDevice {
    async requestOrThrow(init) {
        const request = ApduRequest.fromOrThrow(init);
        await (0,_class_private_method_get._)(this, _sendOrThrow, sendOrThrow).call(this, request);
        const bytes = await HIDFrame.unsplitOrThrow((0,_class_private_field_get._)(this, _channel), (0,_class_private_method_get._)(this, _receiveOrThrow, receiveOrThrow).call(this));
        const response = readable/* Readable */.$.readFromBytesOrThrow(ApduResponse, bytes);
        return response;
    }
    constructor(device, iface){
        (0,_class_private_method_init._)(this, _transferOutOrThrow);
        (0,_class_private_method_init._)(this, _transferInOrThrow);
        (0,_class_private_method_init._)(this, _sendOrThrow);
        (0,_class_private_method_init._)(this, _receiveOrThrow);
        (0,_class_private_field_init._)(this, _channel, {
            writable: true,
            value: void 0
        });
        (0,_class_private_field_set._)(this, _channel, Math.floor(Math.random() * 0xffff));
        this.device = device;
        this.iface = iface;
    }
}
async function transferOutOrThrow(frame) {
    await this.device.transferOut(3, writable/* Writable */.c.writeToBytesOrThrow(frame));
}
async function transferInOrThrow(length) {
    const result = await this.device.transferIn(3, length);
    if (result.data == null) throw new DeviceTransferInError();
    const bytes = bytes_bytes/* Bytes */.J.fromView(result.data);
    const frame = readable/* Readable */.$.readFromBytesOrThrow(HIDFrame, bytes);
    return frame;
}
async function sendOrThrow(fragment) {
    const container = HIDContainer.newOrThrow(fragment);
    const bytes = writable/* Writable */.c.writeToBytesOrThrow(container);
    const frames = HIDFrame.splitOrThrow((0,_class_private_field_get._)(this, _channel), bytes);
    let frame = frames.next();
    for(; !frame.done; frame = frames.next())await (0,_class_private_method_get._)(this, _transferOutOrThrow, transferOutOrThrow).call(this, frame.value);
    return frame.value;
}
async function* receiveOrThrow() {
    while(true)yield await (0,_class_private_method_get._)(this, _transferInOrThrow, transferInOrThrow).call(this, 64);
}

;// CONCATENATED MODULE: ./src/libs/ledger/mods/usb/index.ts


;// CONCATENATED MODULE: ./src/libs/ledger/mods/index.ts







;// CONCATENATED MODULE: ./src/libs/ledger/index.ts




/***/ }),

/***/ 421:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   u: function() { return /* binding */ Results; }
/* harmony export */ });
/* harmony import */ var _hazae41_cleaner__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1878);
/* harmony import */ var _errors_errors__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9071);


var Results;
(function(Results) {
    function log(result) {
        result.inspectErrSync(_errors_errors__WEBPACK_IMPORTED_MODULE_0__/* .Errors */ .D.log);
        return result;
    }
    Results.log = log;
    function logAndAlert(result) {
        result.inspectErrSync(_errors_errors__WEBPACK_IMPORTED_MODULE_0__/* .Errors */ .D.logAndAlert);
        return result;
    }
    Results.logAndAlert = logAndAlert;
    function disposer(result) {
        return new _hazae41_cleaner__WEBPACK_IMPORTED_MODULE_1__/* .Disposer */ .ku(result, ()=>result.isOk() && result.inner[Symbol.dispose]());
    }
    Results.disposer = disposer;
})(Results || (Results = {}));


/***/ }),

/***/ 6826:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   U: function() { return /* binding */ TextAnchor; }
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);

function TextAnchor(props) {
    const { className, href, children = href, target = "_blank", rel = "noreferrer", ...others } = props;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
        className: "a ".concat(className),
        href: href,
        target: target,
        rel: rel,
        ...others,
        children: children
    });
}


/***/ }),

/***/ 9722:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  g: function() { return /* reexport */ textarea_namespaceObject; }
});

// NAMESPACE OBJECT: ./src/libs/ui/textarea/index.tsx
var textarea_namespaceObject = {};
__webpack_require__.r(textarea_namespaceObject);
__webpack_require__.d(textarea_namespaceObject, {
  m: function() { return contrast_Contrast; }
});

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
;// CONCATENATED MODULE: ./src/libs/ui/textarea/contrast.tsx


function contrast_Contrast(props) {
    const { children, className, xref, ...input } = props;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("textarea", {
        className: "px-4 py-2 rounded-xl outline-none border border-transparent clicked-or-focused:border-contrast bg-contrast transition ".concat(className),
        ref: xref,
        ...input,
        children: children
    });
}
(function(Contrast) {
    function Test() {
        return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
            className: "p-1",
            children: /*#__PURE__*/ (0,jsx_runtime.jsx)(contrast_Contrast, {
                placeholder: "Hello world"
            })
        });
    }
    Contrast.Test = Test;
})(contrast_Contrast || (contrast_Contrast = {}));

;// CONCATENATED MODULE: ./src/libs/ui/textarea/index.tsx


;// CONCATENATED MODULE: ./src/libs/ui/textarea.tsx




/***/ }),

/***/ 5731:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   d: function() { return /* binding */ qurl; }
/* harmony export */ });
function qurl(pathname) {
    let query = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
    const url = new URL(pathname, "https://nowhere");
    for (const [key, value] of Object.entries(query))if (value != null) url.searchParams.append(key, String(value));
    return "".concat(url.pathname).concat(url.search).concat(url.hash);
}


/***/ }),

/***/ 6177:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $: function() { return /* binding */ WebAuthnStorageError; },
/* harmony export */   g: function() { return /* binding */ WebAuthnStorage; }
/* harmony export */ });
/* harmony import */ var _swc_helpers_class_private_field_get__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7121);
/* harmony import */ var _swc_helpers_class_private_field_init__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9886);
/* harmony import */ var _swc_helpers_class_private_field_set__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5321);
/* harmony import */ var _hazae41_result__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(918);



var _a;

var _class = /*#__PURE__*/ new WeakMap();
class WebAuthnStorageError extends Error {
    static from(cause) {
        return new _a({
            cause
        });
    }
    constructor(options){
        super("Could not use authenticated storage", options);
        (0,_swc_helpers_class_private_field_init__WEBPACK_IMPORTED_MODULE_0__._)(this, _class, {
            writable: true,
            value: void 0
        });
        (0,_swc_helpers_class_private_field_set__WEBPACK_IMPORTED_MODULE_1__._)(this, _class, _a);
        this.name = (0,_swc_helpers_class_private_field_get__WEBPACK_IMPORTED_MODULE_2__._)(this, _class).name;
    }
}
_a = WebAuthnStorageError;
/**
 * Use WebAuthn as a authentication-protected storage of arbitrary bytes
 * This WON'T use the Secure Enclave as it stores the bytes in `userHandle` (probably on disk)
 *
 * This is used to prevent unauthenticated access to the (encrypted) bytes in the case of:
 * - supply-chain attack where the attacker has the encryption password: it would still require user approval before stealing the private key
 * - phishing, misclick, phone-left-on-the-table attack: it would still require user approval before signing transactions
 */ var WebAuthnStorage;
(function(WebAuthnStorage) {
    async function tryCreate(name, data) {
        return await _hazae41_result__WEBPACK_IMPORTED_MODULE_3__/* .Result */ .x.runAndWrap(async ()=>{
            return await createOrThrow(name, data);
        }).then((r)=>r.mapErrSync(WebAuthnStorageError.from));
    }
    WebAuthnStorage.tryCreate = tryCreate;
    async function createOrThrow(name, data) {
        const credential = await navigator.credentials.create({
            publicKey: {
                challenge: new Uint8Array([
                    117,
                    61,
                    252,
                    231,
                    191,
                    241
                ]),
                rp: {
                    id: location.hostname,
                    name: "Brume Wallet"
                },
                user: {
                    id: data,
                    name: name,
                    displayName: name
                },
                pubKeyCredParams: [
                    {
                        type: "public-key",
                        alg: -7
                    },
                    {
                        type: "public-key",
                        alg: -8
                    },
                    {
                        type: "public-key",
                        alg: -257
                    }
                ],
                authenticatorSelection: {
                    authenticatorAttachment: "platform"
                }
            }
        });
        return new Uint8Array(credential.rawId);
    }
    WebAuthnStorage.createOrThrow = createOrThrow;
    async function tryGet(id) {
        return await _hazae41_result__WEBPACK_IMPORTED_MODULE_3__/* .Result */ .x.runAndWrap(async ()=>{
            return await getOrThrow(id);
        }).then((r)=>r.mapErrSync(WebAuthnStorageError.from));
    }
    WebAuthnStorage.tryGet = tryGet;
    async function getOrThrow(id) {
        const credential = await navigator.credentials.get({
            publicKey: {
                challenge: new Uint8Array([
                    117,
                    61,
                    252,
                    231,
                    191,
                    241
                ]),
                allowCredentials: [
                    {
                        type: "public-key",
                        id
                    }
                ]
            }
        });
        return new Uint8Array(credential.response.userHandle);
    }
    WebAuthnStorage.getOrThrow = getOrThrow;
})(WebAuthnStorage || (WebAuthnStorage = {}));


/***/ }),

/***/ 2223:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  H: function() { return /* binding */ BgEthereumContext; }
});

;// CONCATENATED MODULE: ./src/libs/maps/maps.ts
var Maps;
(function(Maps) {
    function getOrCreate(map, key, factory) {
        let value = map.get(key);
        if (value == null) {
            value = factory();
            map.set(key, value);
        }
        return value;
    }
    Maps.getOrCreate = getOrCreate;
    function* entry(entries) {
        for (const [key, value] of entries)yield {
            key,
            value
        };
    }
    function entries(map) {
        return entry(map.entries());
    }
    Maps.entries = entries;
})(Maps || (Maps = {}));

// EXTERNAL MODULE: ./node_modules/@hazae41/bytes/dist/esm/mods/bytes/bytes.mjs + 3 modules
var bytes = __webpack_require__(1694);
// EXTERNAL MODULE: ./node_modules/@hazae41/fleche/dist/esm/src/mods/fetch/fetch.mjs + 8 modules
var fetch = __webpack_require__(2156);
// EXTERNAL MODULE: ./node_modules/@hazae41/future/dist/esm/mods/future/future.mjs
var future_future = __webpack_require__(6071);
// EXTERNAL MODULE: ./node_modules/@hazae41/jsonrpc/dist/esm/mods/rpc/request.mjs
var rpc_request = __webpack_require__(4356);
// EXTERNAL MODULE: ./node_modules/@hazae41/jsonrpc/dist/esm/mods/rpc/response.mjs
var rpc_response = __webpack_require__(5457);
// EXTERNAL MODULE: ./node_modules/@hazae41/plume/dist/esm/src/mods/errors.mjs
var errors = __webpack_require__(9107);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/result.mjs
var result_result = __webpack_require__(918);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/err.mjs
var err = __webpack_require__(166);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/ok.mjs
var ok = __webpack_require__(5591);
// EXTERNAL MODULE: ./node_modules/@hazae41/box/dist/esm/mods/box/box.mjs
var box = __webpack_require__(6200);
// EXTERNAL MODULE: ./node_modules/@hazae41/cadenas/dist/esm/src/mods/ciphers/ciphers.mjs + 8 modules
var ciphers_ciphers = __webpack_require__(5939);
// EXTERNAL MODULE: ./node_modules/@hazae41/cadenas/dist/esm/src/mods/client.mjs + 74 modules
var client = __webpack_require__(8783);
// EXTERNAL MODULE: ./node_modules/@hazae41/cleaner/dist/esm/src/mods/dispose/dispose.mjs + 1 modules
var dispose = __webpack_require__(1878);
// EXTERNAL MODULE: ./node_modules/@hazae41/echalote/dist/esm/src/mods/tor/consensus/consensus.mjs + 2 modules
var consensus_consensus = __webpack_require__(7240);
// EXTERNAL MODULE: ./node_modules/@hazae41/echalote/dist/esm/src/mods/tor/pool.mjs
var tor_pool = __webpack_require__(1020);
// EXTERNAL MODULE: ./node_modules/@hazae41/option/dist/esm/mods/option/none.mjs
var none = __webpack_require__(1371);
// EXTERNAL MODULE: ./node_modules/@hazae41/piscine/dist/esm/src/mods/pool/pool.mjs + 3 modules
var pool_pool = __webpack_require__(8794);
// EXTERNAL MODULE: ./node_modules/@hazae41/piscine/dist/esm/src/mods/loop/loop.mjs
var loop = __webpack_require__(8697);
;// CONCATENATED MODULE: ./src/libs/tor/circuits/circuits.ts
var __addDisposableResource = undefined && undefined.__addDisposableResource || function(env, value, async) {
    if (value !== null && value !== void 0) {
        if (typeof value !== "object" && typeof value !== "function") throw new TypeError("Object expected.");
        var dispose;
        if (async) {
            if (!Symbol.asyncDispose) throw new TypeError("Symbol.asyncDispose is not defined.");
            dispose = value[Symbol.asyncDispose];
        }
        if (dispose === void 0) {
            if (!Symbol.dispose) throw new TypeError("Symbol.dispose is not defined.");
            dispose = value[Symbol.dispose];
        }
        if (typeof dispose !== "function") throw new TypeError("Object not disposable.");
        env.stack.push({
            value: value,
            dispose: dispose,
            async: async
        });
    } else if (async) {
        env.stack.push({
            async: true
        });
    }
    return value;
};
var __disposeResources = undefined && undefined.__disposeResources || function(SuppressedError1) {
    return function(env) {
        function fail(e) {
            env.error = env.hasError ? new SuppressedError1(e, env.error, "An error was suppressed during disposal.") : e;
            env.hasError = true;
        }
        function next() {
            while(env.stack.length){
                var rec = env.stack.pop();
                try {
                    var result = rec.dispose && rec.dispose.call(rec.value);
                    if (rec.async) return Promise.resolve(result).then(next, function(e) {
                        fail(e);
                        return next();
                    });
                } catch (e) {
                    fail(e);
                }
            }
            if (env.hasError) throw env.error;
        }
        return next();
    };
}(typeof SuppressedError === "function" ? SuppressedError : function(error, suppressed, message) {
    var e = new Error(message);
    return e.name = "SuppressedError", e.error = error, e.suppressed = suppressed, e;
});








var Circuits;
(function(Circuits) {
    async function tryOpenAs(circuit, input) {
        return await result_result/* Result */.x.runAndDoubleWrap(()=>openAsOrThrow(circuit, input));
    }
    Circuits.tryOpenAs = tryOpenAs;
    async function openAsOrThrow(circuit, input) {
        const req = new Request(input);
        const url = new URL(req.url);
        if (url.protocol === "http:" || url.protocol === "ws:") {
            const tcp = await circuit.openOrThrow(url.hostname, Number(url.port) || 80);
            return new dispose/* Disposer */.ku(tcp.outer, ()=>tcp.close());
        }
        if (url.protocol === "https:" || url.protocol === "wss:") {
            const tcp = await circuit.openOrThrow(url.hostname, Number(url.port) || 443);
            const ciphers = [
                ciphers_ciphers/* TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384 */.$x,
                ciphers_ciphers/* TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384 */.qZ
            ];
            const tls = new client/* TlsClientDuplex */.g({
                host_name: url.hostname,
                ciphers
            });
            tcp.outer.readable.pipeTo(tls.inner.writable).catch(()=>{});
            tls.inner.readable.pipeTo(tcp.outer.writable).catch(()=>{});
            return new dispose/* Disposer */.ku(tls.outer, ()=>tcp.close());
        }
        throw new Error(url.protocol);
    }
    Circuits.openAsOrThrow = openAsOrThrow;
    /**
     * Create a pool of Circuits modulo a pool of Tor clients
     * @param tors
     * @param params
     * @returns
     */ function pool(tors, consensus, params) {
        const middles = consensus.microdescs.filter((it)=> true && it.flags.includes("Fast") && it.flags.includes("Stable") && it.flags.includes("V2Dir"));
        const exits = consensus.microdescs.filter((it)=> true && it.flags.includes("Fast") && it.flags.includes("Stable") && it.flags.includes("Exit") && !it.flags.includes("BadExit"));
        let update = Date.now();
        const pool = new pool_pool/* Pool */.Kg(async (params)=>{
            while(true){
                const start = Date.now();
                const result = await result_result/* Result */.x.runAndDoubleWrap(async ()=>{
                    const env_1 = {
                        stack: [],
                        error: void 0,
                        hasError: false
                    };
                    try {
                        const { index, signal } = params;
                        const circuit = __addDisposableResource(env_1, await (async ()=>{
                            while(true){
                                const tor = await tors.getOrThrow(index % tors.capacity, signal).then((r)=>r.unwrap().inner.inner);
                                try {
                                    const env_2 = {
                                        stack: [],
                                        error: void 0,
                                        hasError: false
                                    };
                                    try {
                                        const circuit = __addDisposableResource(env_2, new box/* Box */.x(await tor.createOrThrow(AbortSignal.timeout(1000))), false);
                                        /**
                                         * Try to extend to middle relay 3 times before giving up this circuit
                                         */ await (0,loop/* tryLoop */.m4)(()=>{
                                            return result_result/* Result */.x.unthrow(async (t)=>{
                                                const head = middles[Math.floor(Math.random() * middles.length)];
                                                const body = await consensus_consensus/* Consensus */.L.Microdesc.tryFetch(circuit.inner, head).then((r)=>r.mapErrSync(loop/* Cancel */.$j.new).throw(t));
                                                await circuit.inner.tryExtend(body, AbortSignal.timeout(1000)).then((r)=>r.mapErrSync(loop/* Retry */.xC.new).throw(t));
                                                return ok.Ok.void();
                                            });
                                        }, {
                                            init: 0,
                                            base: 0,
                                            max: 3
                                        }).then((r)=>r.unwrap());
                                        /**
                                         * Try to extend to exit relay 3 times before giving up this circuit
                                         */ await (0,loop/* tryLoop */.m4)(()=>{
                                            return result_result/* Result */.x.unthrow(async (t)=>{
                                                const head = exits[Math.floor(Math.random() * exits.length)];
                                                const body = await consensus_consensus/* Consensus */.L.Microdesc.tryFetch(circuit.inner, head).then((r)=>r.mapErrSync(loop/* Cancel */.$j.new).throw(t));
                                                await circuit.inner.tryExtend(body, AbortSignal.timeout(1000)).then((r)=>r.mapErrSync(loop/* Retry */.xC.new).throw(t));
                                                return ok.Ok.void();
                                            });
                                        }, {
                                            init: 0,
                                            base: 0,
                                            max: 3
                                        }).then((r)=>r.unwrap());
                                        /**
                                         * Try to open a stream to a reliable endpoint
                                         */ const stream = __addDisposableResource(env_2, await openAsOrThrow(circuit.inner, "http://detectportal.firefox.com"), false);
                                        /**
                                         * Reliability test
                                         */ for(let i = 0; i < 3; i++){
                                            /**
                                             * Speed test
                                             */ const signal = AbortSignal.timeout(1000);
                                            await (0,fetch/* fetch */.h)("http://detectportal.firefox.com", {
                                                stream: stream.inner,
                                                signal,
                                                preventAbort: true,
                                                preventCancel: true,
                                                preventClose: true
                                            }).then((r)=>r.text());
                                        }
                                        return circuit.moveOrThrow();
                                    } catch (e_2) {
                                        env_2.error = e_2;
                                        env_2.hasError = true;
                                    } finally{
                                        __disposeResources(env_2);
                                    }
                                } catch (e) {
                                    console.warn("Retrying circuit creation", {
                                        e
                                    });
                                    continue;
                                }
                            }
                        })(), false);
                        return (0,tor_pool/* createCircuitEntry */.k)(circuit.moveOrThrow(), params);
                    } catch (e_1) {
                        env_1.error = e_1;
                        env_1.hasError = true;
                    } finally{
                        __disposeResources(env_1);
                    }
                }).then((r)=>r.inspectErrSync((e)=>console.error("Circuit creation failed", {
                            e
                        })));
                if (result.isOk()) return result;
                if (start < update) continue;
                return result;
            }
        }, params);
        tors.events.on("started", async (i)=>{
            update = Date.now();
            for(let i = 0; i < pool.capacity; i++){
                const child = pool.tryGetSync(i);
                if (child.isErr()) continue;
                if (child.inner.isErr()) pool.restart(i);
                continue;
            }
            return new none/* None */.H();
        }, {
            passive: true
        });
        return pool;
    }
    Circuits.pool = pool;
    /**
     * Create a pool of Circuits stealing from another pool of Circuits
     * @param circuits
     * @param params
     * @returns
     */ function subpool(circuits, params) {
        let update = Date.now();
        const pool = new pool_pool/* Pool */.Kg(async (params)=>{
            while(true){
                const start = Date.now();
                const result = await result_result/* Result */.x.unthrow(async (t)=>{
                    const env_3 = {
                        stack: [],
                        error: void 0,
                        hasError: false
                    };
                    try {
                        const circuit = __addDisposableResource(env_3, await pool_pool/* Pool */.Kg.tryTakeCryptoRandom(circuits).then((r)=>r.throw(t).throw(t).inner), false);
                        return new ok.Ok((0,tor_pool/* createCircuitEntry */.k)(circuit.moveOrThrow(), params));
                    } catch (e_3) {
                        env_3.error = e_3;
                        env_3.hasError = true;
                    } finally{
                        __disposeResources(env_3);
                    }
                });
                if (result.isOk()) return result;
                if (start < update) continue;
                return result;
            }
        }, params);
        circuits.inner.events.on("started", async ()=>{
            update = Date.now();
            for(let i = 0; i < pool.capacity; i++){
                const child = pool.tryGetSync(i);
                if (child.isErr()) continue;
                if (child.inner.isErr()) pool.restart(i);
                continue;
            }
            return new none/* None */.H();
        }, {
            passive: true
        });
        return pool;
    }
    Circuits.subpool = subpool;
})(Circuits || (Circuits = {}));

;// CONCATENATED MODULE: ./src/libs/rpc/rpc.ts
var rpc_addDisposableResource = undefined && undefined.__addDisposableResource || function(env, value, async) {
    if (value !== null && value !== void 0) {
        if (typeof value !== "object" && typeof value !== "function") throw new TypeError("Object expected.");
        var dispose;
        if (async) {
            if (!Symbol.asyncDispose) throw new TypeError("Symbol.asyncDispose is not defined.");
            dispose = value[Symbol.asyncDispose];
        }
        if (dispose === void 0) {
            if (!Symbol.dispose) throw new TypeError("Symbol.dispose is not defined.");
            dispose = value[Symbol.dispose];
        }
        if (typeof dispose !== "function") throw new TypeError("Object not disposable.");
        env.stack.push({
            value: value,
            dispose: dispose,
            async: async
        });
    } else if (async) {
        env.stack.push({
            async: true
        });
    }
    return value;
};
var rpc_disposeResources = undefined && undefined.__disposeResources || function(SuppressedError1) {
    return function(env) {
        function fail(e) {
            env.error = env.hasError ? new SuppressedError1(e, env.error, "An error was suppressed during disposal.") : e;
            env.hasError = true;
        }
        function next() {
            while(env.stack.length){
                var rec = env.stack.pop();
                try {
                    var result = rec.dispose && rec.dispose.call(rec.value);
                    if (rec.async) return Promise.resolve(result).then(next, function(e) {
                        fail(e);
                        return next();
                    });
                } catch (e) {
                    fail(e);
                }
            }
            if (env.hasError) throw env.error;
        }
        return next();
    };
}(typeof SuppressedError === "function" ? SuppressedError : function(error, suppressed, message) {
    var e = new Error(message);
    return e.name = "SuppressedError", e.error = error, e.suppressed = suppressed, e;
});







var TorRpc;
(function(TorRpc) {
    async function tryFetchWithCircuit(input, init) {
        return await result_result/* Result */.x.unthrow(async (t)=>{
            const env_1 = {
                stack: [],
                error: void 0,
                hasError: false
            };
            try {
                const { id, method, params, circuit, ...rest } = init;
                const request = new rpc_request/* RpcRequest */.a(id, method, params);
                const body = bytes/* Bytes */.J.fromUtf8(JSON.stringify(request));
                const headers = new Headers(rest.headers);
                headers.set("Content-Type", "application/json");
                headers.set("Content-Length", "".concat(body.length));
                const stream = rpc_addDisposableResource(env_1, await Circuits.openAsOrThrow(circuit, input), false);
                const res = await (0,fetch/* fetch */.h)(input, {
                    ...rest,
                    method: "POST",
                    headers,
                    body,
                    stream: stream.inner
                });
                if (!res.ok) {
                    const text = await result_result/* Result */.x.runAndDoubleWrap(()=>{
                        return res.text();
                    }).then((r)=>r.throw(t));
                    return new err/* Err */.U(new Error(text));
                }
                const json = await result_result/* Result */.x.runAndDoubleWrap(()=>{
                    return res.json();
                }).then((r)=>r.throw(t));
                const response = rpc_response/* RpcResponse */.S.from(json);
                if (response.id !== request.id) console.warn("Invalid response ID", response.id, "expected", request.id);
                return new ok.Ok(response);
            } catch (e_1) {
                env_1.error = e_1;
                env_1.hasError = true;
            } finally{
                rpc_disposeResources(env_1);
            }
        });
    }
    TorRpc.tryFetchWithCircuit = tryFetchWithCircuit;
    async function tryFetchWithSocket(socket, request, signal) {
        const { id, method, params = [] } = request;
        socket.send(JSON.stringify(new rpc_request/* RpcRequest */.a(id, method, params)));
        const future = new future_future/* Future */.o();
        const onMessage = async (event)=>{
            if (typeof event.data !== "string") return;
            const response = rpc_response/* RpcResponse */.S.from(JSON.parse(event.data));
            if (response.id !== request.id) return;
            future.resolve(new ok.Ok(response));
        };
        const onError = (e)=>{
            future.resolve(new err/* Err */.U(errors/* ErroredError */.kN.from(e)));
        };
        const onClose = (e)=>{
            future.resolve(new err/* Err */.U(errors/* ClosedError */.$A.from(e)));
        };
        const onAbort = ()=>{
            future.resolve(new err/* Err */.U(errors/* AbortedError */.pe.from(signal.reason)));
        };
        try {
            socket.addEventListener("message", onMessage, {
                passive: true
            });
            socket.addEventListener("close", onClose, {
                passive: true
            });
            socket.addEventListener("error", onError, {
                passive: true
            });
            signal.addEventListener("abort", onAbort, {
                passive: true
            });
            return await future.promise;
        } finally{
            socket.removeEventListener("message", onMessage);
            socket.removeEventListener("close", onClose);
            socket.removeEventListener("error", onError);
            signal.removeEventListener("abort", onAbort);
        }
    }
    TorRpc.tryFetchWithSocket = tryFetchWithSocket;
})(TorRpc || (TorRpc = {}));

;// CONCATENATED MODULE: ./src/libs/signals/signals.ts
var AbortSignals;
(function(AbortSignals) {
    function never() {
        return new AbortController().signal;
    }
    AbortSignals.never = never;
    function timeout(delay, parent) {
        return merge(AbortSignal.timeout(delay), parent);
    }
    AbortSignals.timeout = timeout;
    function merge(a, b) {
        if (b == null) return a;
        const c = new AbortController();
        const onAbort = (reason)=>{
            c.abort(reason);
            a.removeEventListener("abort", onAbort);
            b.removeEventListener("abort", onAbort);
        };
        a.addEventListener("abort", onAbort, {
            passive: true
        });
        b.addEventListener("abort", onAbort, {
            passive: true
        });
        return c.signal;
    }
    AbortSignals.merge = merge;
})(AbortSignals || (AbortSignals = {}));

// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/fetched/fetched.mjs
var fetched = __webpack_require__(1458);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/fetched/fail.mjs
var fail = __webpack_require__(9164);
// EXTERNAL MODULE: ./node_modules/@hazae41/option/dist/esm/mods/option/option.mjs
var option_option = __webpack_require__(5316);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/errors.mjs
var result_errors = __webpack_require__(2564);
;// CONCATENATED MODULE: ./src/mods/background/service_worker/context.ts






var BgEthereumContext;
(function(BgEthereumContext) {
    async function fetchOrFail(ethereum, init) {
        let more = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
        try {
            const { signal: parentSignal } = more;
            const { brume } = ethereum;
            const pools = option_option/* Option */.W.unwrap(brume[ethereum.chain.chainId]);
            async function runWithPoolOrThrow(index) {
                const poolSignal = AbortSignals.timeout(5000, parentSignal);
                const pool = await pools.tryGet(index, poolSignal).then((r)=>r.unwrap().unwrap().inner.inner);
                async function runWithConnOrThrow(index) {
                    const connSignal = AbortSignals.timeout(5000, parentSignal);
                    const conn = await pool.tryGet(index, connSignal).then((r)=>r.unwrap().unwrap().inner.inner);
                    const { counter, connection } = conn;
                    const request = counter.prepare(init);
                    if (connection.isURL()) {
                        const { url, circuit } = connection;
                        const signal = AbortSignals.timeout(10000, parentSignal);
                        const result = await TorRpc.tryFetchWithCircuit(url, {
                            ...request,
                            circuit,
                            signal
                        });
                        if (result.isErr()) console.debug("Could not fetch ".concat(init.method, " from ").concat(url.href, " using ").concat(circuit.id), {
                            result
                        });
                        return fetched/* Fetched */.F.rewrap(result.unwrap());
                    }
                    if (connection.isWebSocket()) {
                        await connection.cooldown;
                        const { socket, circuit } = connection;
                        const signal = AbortSignals.timeout(10000, parentSignal);
                        const result = await TorRpc.tryFetchWithSocket(socket, request, signal);
                        if (result.isErr()) console.debug("Could not fetch ".concat(init.method, " from ").concat(socket.url, " using ").concat(circuit.id), {
                            result
                        });
                        return fetched/* Fetched */.F.rewrap(result.unwrap());
                    }
                    throw new result_errors/* Panic */.F5();
                }
                const promises = Array.from({
                    length: pool.capacity
                }, (_, i)=>runWithConnOrThrow(i));
                const results = await Promise.allSettled(promises);
                const fetcheds = new Map();
                const counters = new Map();
                for (const result of results){
                    if (result.status === "rejected") continue;
                    if (result.value.isErr()) continue;
                    if (init === null || init === void 0 ? void 0 : init.noCheck) return result.value;
                    const raw = JSON.stringify(result.value.inner);
                    const previous = option_option/* Option */.W.wrap(counters.get(raw)).unwrapOr(0);
                    counters.set(raw, previous + 1);
                    fetcheds.set(raw, result.value);
                }
                /**
                 * One truth -> return it
                 * Zero truth -> throw AggregateError
                 */ if (counters.size < 2) return await Promise.any(promises);
                console.warn("Different results from multiple connections for ".concat(init.method, " on ").concat(ethereum.chain.name), {
                    fetcheds
                });
                /**
                 * Sort truths by occurence
                 */ const sorteds = [
                    ...Maps.entries(counters)
                ].sort((a, b)=>b.value - a.value);
                /**
                 * Two concurrent truths
                 */ if (sorteds[0].value === sorteds[1].value) {
                    console.warn("Could not choose truth for ".concat(init.method, " on ").concat(ethereum.chain.name));
                    const random = Math.round(Math.random());
                    return fetcheds.get(sorteds[random].key);
                }
                return fetcheds.get(sorteds[0].key);
            }
            const promises = Array.from({
                length: pools.capacity
            }, (_, i)=>runWithPoolOrThrow(i));
            const results = await Promise.allSettled(promises);
            const fetcheds = new Map();
            const counters = new Map();
            for (const result of results){
                if (result.status === "rejected") continue;
                if (result.value.isErr()) continue;
                if (init === null || init === void 0 ? void 0 : init.noCheck) return result.value;
                const raw = JSON.stringify(result.value.inner);
                const previous = option_option/* Option */.W.wrap(counters.get(raw)).unwrapOr(0);
                counters.set(raw, previous + 1);
                fetcheds.set(raw, result.value);
            }
            /**
             * One truth -> return it
             * Zero truth -> throw AggregateError
             */ if (counters.size < 2) return await Promise.any(promises);
            console.warn("Different results from multiple circuits for ".concat(init.method, " on ").concat(ethereum.chain.name), {
                fetcheds
            });
            /**
             * Sort truths by occurence
             */ const sorteds = [
                ...Maps.entries(counters)
            ].sort((a, b)=>b.value - a.value);
            /**
             * Two concurrent truths
             */ if (sorteds[0].value === sorteds[1].value) {
                console.warn("Could not choose truth for ".concat(init.method, " on ").concat(ethereum.chain.name));
                const random = Math.round(Math.random());
                return fetcheds.get(sorteds[random].key);
            }
            return fetcheds.get(sorteds[0].key);
        } catch (e) {
            return new fail/* Fail */.M(result_errors/* Catched */.$c.from(e));
        }
    }
    BgEthereumContext.fetchOrFail = fetchOrFail;
})(BgEthereumContext || (BgEthereumContext = {}));


/***/ }),

/***/ 7254:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   K: function() { return /* binding */ BgSeed; },
/* harmony export */   M: function() { return /* binding */ SeedRef; }
/* harmony export */ });
/* harmony import */ var _libs_glacier_mutators__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2457);
/* harmony import */ var _hazae41_glacier__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6233);
/* harmony import */ var _hazae41_glacier__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8123);


var SeedRef;
(function(SeedRef) {
    function from(seed) {
        return {
            ref: true,
            uuid: seed.uuid
        };
    }
    SeedRef.from = from;
})(SeedRef || (SeedRef = {}));
var BgSeed;
(function(BgSeed) {
    let All;
    (function(All) {
        All.key = "seeds";
        function schema(storage) {
            return (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_1__/* .createQuery */ .rP)({
                key: All.key,
                storage
            });
        }
        All.schema = schema;
    })(All = BgSeed.All || (BgSeed.All = {}));
    function key(uuid) {
        return "seed/".concat(uuid);
    }
    BgSeed.key = key;
    function schema(uuid, storage) {
        const indexer = async (states)=>{
            var _previous_real, _current_real;
            const { current, previous = current } = states;
            const previousData = (_previous_real = previous.real) === null || _previous_real === void 0 ? void 0 : _previous_real.data;
            const currentData = (_current_real = current.real) === null || _current_real === void 0 ? void 0 : _current_real.data;
            await All.schema(storage).mutate(_libs_glacier_mutators__WEBPACK_IMPORTED_MODULE_0__/* .Mutators */ .g.mapData(function() {
                let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : new _hazae41_glacier__WEBPACK_IMPORTED_MODULE_2__/* .Data */ .V([]);
                if ((previousData === null || previousData === void 0 ? void 0 : previousData.inner.uuid) === (currentData === null || currentData === void 0 ? void 0 : currentData.inner.uuid)) return d;
                if (previousData != null) d = d.mapSync((p)=>p.filter((x)=>x.uuid !== previousData.inner.uuid));
                if (currentData != null) d = d.mapSync((p)=>[
                        ...p,
                        SeedRef.from(currentData.inner)
                    ]);
                return d;
            }));
        };
        return (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_1__/* .createQuery */ .rP)({
            key: key(uuid),
            storage,
            indexer
        });
    }
    BgSeed.schema = schema;
})(BgSeed || (BgSeed = {}));


/***/ }),

/***/ 3499:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $: function() { return /* binding */ BgEthereum; },
/* harmony export */   f: function() { return /* binding */ BgTotal; }
/* harmony export */ });
/* harmony import */ var _libs_glacier_mutators__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2457);
/* harmony import */ var _hazae41_cubane__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8386);
/* harmony import */ var _hazae41_glacier__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6233);
/* harmony import */ var _hazae41_glacier__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8123);
/* harmony import */ var _hazae41_option__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5316);
/* harmony import */ var _context__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2223);





var BgEthereum;
(function(BgEthereum) {
    let Unknown;
    (function(Unknown) {
        function key(chainId, request) {
            const { method, params, noCheck } = request;
            return {
                chainId,
                method,
                params,
                noCheck
            };
        }
        Unknown.key = key;
        function schema(ethereum, request, storage) {
            const fetcher = async (request, more)=>await _context__WEBPACK_IMPORTED_MODULE_1__/* .BgEthereumContext */ .H.fetchOrFail(ethereum, request, more);
            return (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_2__/* .createQuery */ .rP)({
                key: key(ethereum.chain.chainId, request),
                fetcher,
                storage
            });
        }
        Unknown.schema = schema;
    })(Unknown = BgEthereum.Unknown || (BgEthereum.Unknown = {}));
})(BgEthereum || (BgEthereum = {}));
var BgTotal;
(function(BgTotal) {
    let Balance;
    (function(Balance) {
        let Priced;
        (function(Priced) {
            let ByAddress;
            (function(ByAddress) {
                let Record;
                (function(Record) {
                    function key(coin) {
                        return "totalPricedBalanceByWallet/".concat(coin);
                    }
                    Record.key = key;
                    function schema(coin, storage) {
                        const indexer = async (states)=>{
                            var _states_current_real_data, _states_current_real;
                            const values = _hazae41_option__WEBPACK_IMPORTED_MODULE_3__/* .Option */ .W.wrap((_states_current_real = states.current.real) === null || _states_current_real === void 0 ? void 0 : (_states_current_real_data = _states_current_real.data) === null || _states_current_real_data === void 0 ? void 0 : _states_current_real_data.get()).unwrapOr({});
                            const total = Object.values(values).reduce((x, y)=>_hazae41_cubane__WEBPACK_IMPORTED_MODULE_4__/* .Fixed */ .g.from(y).add(x), new _hazae41_cubane__WEBPACK_IMPORTED_MODULE_4__/* .Fixed */ .g(0n, 0));
                            const totalQuery = Priced.schema(coin, storage);
                            await totalQuery.mutate(_libs_glacier_mutators__WEBPACK_IMPORTED_MODULE_0__/* .Mutators */ .g.data(total));
                        };
                        return (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_2__/* .createQuery */ .rP)({
                            key: key(coin),
                            indexer,
                            storage
                        });
                    }
                    Record.schema = schema;
                })(Record = ByAddress.Record || (ByAddress.Record = {}));
                function key(address, coin) {
                    return "totalWalletPricedBalance/".concat(address, "/").concat(coin);
                }
                ByAddress.key = key;
                function schema(address, coin, storage) {
                    const indexer = async (states)=>{
                        var _states_current_real_data, _states_current_real;
                        const indexQuery = Record.schema(coin, storage);
                        const value = _hazae41_option__WEBPACK_IMPORTED_MODULE_3__/* .Option */ .W.wrap((_states_current_real = states.current.real) === null || _states_current_real === void 0 ? void 0 : (_states_current_real_data = _states_current_real.data) === null || _states_current_real_data === void 0 ? void 0 : _states_current_real_data.get()).unwrapOr(new _hazae41_cubane__WEBPACK_IMPORTED_MODULE_4__/* .Fixed */ .g(0n, 0));
                        await indexQuery.mutate(_libs_glacier_mutators__WEBPACK_IMPORTED_MODULE_0__/* .Mutators */ .g.mapInnerData((p)=>({
                                ...p,
                                [address]: value
                            }), new _hazae41_glacier__WEBPACK_IMPORTED_MODULE_5__/* .Data */ .V({})));
                    };
                    return (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_2__/* .createQuery */ .rP)({
                        key: key(address, coin),
                        indexer,
                        storage
                    });
                }
                ByAddress.schema = schema;
            })(ByAddress = Priced.ByAddress || (Priced.ByAddress = {}));
            function key(currency) {
                return "totalPricedBalance/".concat(currency);
            }
            Priced.key = key;
            function schema(currency, storage) {
                return (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_2__/* .createQuery */ .rP)({
                    key: key(currency),
                    storage
                });
            }
            Priced.schema = schema;
        })(Priced = Balance.Priced || (Balance.Priced = {}));
    })(Balance = BgTotal.Balance || (BgTotal.Balance = {}));
})(BgTotal || (BgTotal = {}));


/***/ }),

/***/ 6340:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   U: function() { return /* binding */ BgWallet; },
/* harmony export */   V: function() { return /* binding */ WalletRef; }
/* harmony export */ });
/* harmony import */ var _libs_glacier_mutators__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2457);
/* harmony import */ var _hazae41_glacier__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6233);
/* harmony import */ var _hazae41_glacier__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8123);


var WalletRef;
(function(WalletRef) {
    function create(uuid) {
        return {
            ref: true,
            uuid
        };
    }
    WalletRef.create = create;
    function from(wallet) {
        return create(wallet.uuid);
    }
    WalletRef.from = from;
})(WalletRef || (WalletRef = {}));
var BgWallet;
(function(BgWallet) {
    let All;
    (function(All) {
        let BySeed;
        (function(BySeed) {
            function key(uuid) {
                return "walletsBySeed/".concat(uuid);
            }
            BySeed.key = key;
            function schema(uuid, storage) {
                return (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_1__/* .createQuery */ .rP)({
                    key: key(uuid),
                    storage
                });
            }
            BySeed.schema = schema;
        })(BySeed = All.BySeed || (All.BySeed = {}));
        All.key = "wallets";
        function schema(storage) {
            return (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_1__/* .createQuery */ .rP)({
                key: All.key,
                storage
            });
        }
        All.schema = schema;
    })(All = BgWallet.All || (BgWallet.All = {}));
    function key(uuid) {
        return "wallet/".concat(uuid);
    }
    BgWallet.key = key;
    function schema(uuid, storage) {
        const indexer = async (states)=>{
            var _previous_real, _current_real;
            const { current, previous = current } = states;
            const previousData = (_previous_real = previous.real) === null || _previous_real === void 0 ? void 0 : _previous_real.data;
            const currentData = (_current_real = current.real) === null || _current_real === void 0 ? void 0 : _current_real.data;
            await All.schema(storage).mutate(_libs_glacier_mutators__WEBPACK_IMPORTED_MODULE_0__/* .Mutators */ .g.mapData(function() {
                let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : new _hazae41_glacier__WEBPACK_IMPORTED_MODULE_2__/* .Data */ .V([]);
                if ((previousData === null || previousData === void 0 ? void 0 : previousData.inner.uuid) === (currentData === null || currentData === void 0 ? void 0 : currentData.inner.uuid)) return d;
                if (previousData != null) d = d.mapSync((p)=>p.filter((x)=>x.uuid !== previousData.inner.uuid));
                if (currentData != null) d = d.mapSync((p)=>[
                        ...p,
                        WalletRef.from(currentData.inner)
                    ]);
                return d;
            }));
            if ((currentData === null || currentData === void 0 ? void 0 : currentData.inner.type) === "seeded") {
                const { seed } = currentData.inner;
                const walletsBySeedQuery = All.BySeed.schema(seed.uuid, storage);
                await walletsBySeedQuery.mutate(_libs_glacier_mutators__WEBPACK_IMPORTED_MODULE_0__/* .Mutators */ .g.mapData(function() {
                    let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : new _hazae41_glacier__WEBPACK_IMPORTED_MODULE_2__/* .Data */ .V([]);
                    if ((previousData === null || previousData === void 0 ? void 0 : previousData.inner.uuid) === (currentData === null || currentData === void 0 ? void 0 : currentData.inner.uuid)) return d;
                    if (previousData != null) d = d.mapSync((p)=>p.filter((x)=>x.uuid !== previousData.inner.uuid));
                    if (currentData != null) d = d.mapSync((p)=>[
                            ...p,
                            WalletRef.from(currentData.inner)
                        ]);
                    return d;
                }));
            }
        };
        return (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_1__/* .createQuery */ .rP)({
            key: key(uuid),
            indexer,
            storage
        });
    }
    BgWallet.schema = schema;
})(BgWallet || (BgWallet = {}));


/***/ }),

/***/ 1023:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  aZ: function() { return /* binding */ useEnsLookup; },
  DB: function() { return /* binding */ useEnsReverse; },
  yh: function() { return /* binding */ useEnsReverseNoFetch; }
});

// UNUSED EXPORTS: FgEns

// EXTERNAL MODULE: ./src/libs/errors/errors.ts
var errors = __webpack_require__(9071);
// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/abi/types/function/function.mjs
var function_function = __webpack_require__(7205);
// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/abi/types/tuple/tuple.mjs
var tuple = __webpack_require__(5444);
// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/abi/types/bytes/static.mjs
var bytes_static = __webpack_require__(9914);
;// CONCATENATED MODULE: ./src/libs/abi/ens.abi.ts

var EnsAbi;
(function(EnsAbi) {
    EnsAbi.resolver = function_function/* FunctionSelectorAndArguments */.b0.create(function_function/* FunctionSelector */.xS.from([
        1,
        120,
        184,
        191
    ]), tuple/* Tuple */.p.create(bytes_static/* Bytes32 */.HM));
    EnsAbi.addr = function_function/* FunctionSelectorAndArguments */.b0.create(function_function/* FunctionSelector */.xS.from([
        59,
        59,
        87,
        222
    ]), tuple/* Tuple */.p.create(bytes_static/* Bytes32 */.HM));
    EnsAbi.name = function_function/* FunctionSelectorAndArguments */.b0.create(function_function/* FunctionSelector */.xS.from([
        105,
        31,
        52,
        49
    ]), tuple/* Tuple */.p.create(bytes_static/* Bytes32 */.HM));
})(EnsAbi || (EnsAbi = {}));

// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/abi/encode.mjs
var encode = __webpack_require__(6167);
// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/abi/types/address/address.mjs
var address_address = __webpack_require__(3831);
// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/abi/decode.mjs + 1 modules
var decode = __webpack_require__(7817);
// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/ens/index.mjs + 2 modules
var ens = __webpack_require__(2412);
// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/abi/types/string/string.mjs
var string = __webpack_require__(3997);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/fetched/data.mjs
var fetched_data = __webpack_require__(8123);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/fetched/fail.mjs
var fail = __webpack_require__(9164);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/queries/simple/query.mjs
var query = __webpack_require__(6233);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/errors.mjs
var result_errors = __webpack_require__(2564);
// EXTERNAL MODULE: ./src/mods/background/service_worker/context.ts + 4 modules
var context = __webpack_require__(2223);
;// CONCATENATED MODULE: ./src/mods/background/service_worker/entities/names/data.ts





var BgEns;
(function(BgEns) {
    let Resolver;
    (function(Resolver) {
        async function fetchOrFail(ethereum, namehash, more) {
            try {
                const registry = "0x00000000000C2E074eC69A0dFb2997BA6C7d2e1e";
                const data = encode/* encodeOrThrow */.YM(EnsAbi.resolver.from(namehash));
                const fetched = await context/* BgEthereumContext */.H.fetchOrFail(ethereum, {
                    method: "eth_call",
                    params: [
                        {
                            to: registry,
                            data: data
                        },
                        "pending"
                    ]
                }, more);
                if (fetched.isErr()) return fetched;
                const returns = tuple/* Tuple */.p.create(address_address/* Address */.kL);
                const [address] = decode/* decodeOrThrow */.Dt(returns, fetched.inner).intoOrThrow();
                return new fetched_data/* Data */.V(address);
            } catch (e) {
                return new fail/* Fail */.M(result_errors/* Catched */.$c.from(e));
            }
        }
        Resolver.fetchOrFail = fetchOrFail;
    })(Resolver = BgEns.Resolver || (BgEns.Resolver = {}));
    let Lookup;
    (function(Lookup) {
        Lookup.method = "ens_lookup";
        function key(name) {
            return {
                chainId: 1,
                method: Lookup.method,
                params: [
                    name
                ]
            };
        }
        Lookup.key = key;
        async function parseOrThrow(ethereum, request, storage) {
            const [name] = request.params;
            return schema(ethereum, name, storage);
        }
        Lookup.parseOrThrow = parseOrThrow;
        function schema(ethereum, name, storage) {
            const fetcher = (key, more)=>fetchOrFail(ethereum, name, more);
            return (0,query/* createQuery */.rP)({
                key: key(name),
                fetcher,
                storage
            });
        }
        Lookup.schema = schema;
        async function fetchOrFail(ethereum, name, more) {
            try {
                const namehash = ens/* namehashOrThrow */.Ez(name);
                const resolver = await Resolver.fetchOrFail(ethereum, namehash, more);
                if (resolver.isErr()) return resolver;
                const data = encode/* encodeOrThrow */.YM(EnsAbi.addr.from(namehash));
                const fetched = await context/* BgEthereumContext */.H.fetchOrFail(ethereum, {
                    method: "eth_call",
                    params: [
                        {
                            to: resolver.inner,
                            data: data
                        },
                        "pending"
                    ]
                }, more);
                if (fetched.isErr()) return fetched;
                const returns = tuple/* Tuple */.p.create(address_address/* Address */.kL);
                const [address] = decode/* decodeOrThrow */.Dt(returns, fetched.inner).intoOrThrow();
                return new fetched_data/* Data */.V(address);
            } catch (e) {
                return new fail/* Fail */.M(result_errors/* Catched */.$c.from(e));
            }
        }
        Lookup.fetchOrFail = fetchOrFail;
    })(Lookup = BgEns.Lookup || (BgEns.Lookup = {}));
    let Reverse;
    (function(Reverse) {
        Reverse.method = "ens_reverse";
        function key(address) {
            return {
                chainId: 1,
                method: Reverse.method,
                params: [
                    address
                ]
            };
        }
        Reverse.key = key;
        async function parseOrThrow(ethereum, request, storage) {
            const [address] = request.params;
            return schema(ethereum, address, storage);
        }
        Reverse.parseOrThrow = parseOrThrow;
        function schema(ethereum, address, storage) {
            const fetcher = (key, more)=>fetchOrFail(ethereum, address, more);
            return (0,query/* createQuery */.rP)({
                key: key(address),
                fetcher,
                storage
            });
        }
        Reverse.schema = schema;
        async function fetchUncheckedOrFail(ethereum, address, more) {
            try {
                const namehash = ens/* namehashOrThrow */.Ez("".concat(address.slice(2), ".addr.reverse"));
                const resolver = await Resolver.fetchOrFail(ethereum, namehash, more);
                if (resolver.isErr()) return resolver;
                const data = encode/* encodeOrThrow */.YM(EnsAbi.name.from(namehash));
                const fetched = await context/* BgEthereumContext */.H.fetchOrFail(ethereum, {
                    method: "eth_call",
                    params: [
                        {
                            to: resolver.inner,
                            data: data
                        },
                        "pending"
                    ]
                }, more);
                if (fetched.isErr()) return fetched;
                const returns = tuple/* Tuple */.p.create(string/* String */.L);
                const [name] = decode/* decodeOrThrow */.Dt(returns, fetched.inner).intoOrThrow();
                if (name.length === 0) return new fetched_data/* Data */.V(undefined);
                return new fetched_data/* Data */.V(name);
            } catch (e) {
                return new fail/* Fail */.M(result_errors/* Catched */.$c.from(e));
            }
        }
        Reverse.fetchUncheckedOrFail = fetchUncheckedOrFail;
        async function fetchOrFail(ethereum, address, more) {
            const name = await fetchUncheckedOrFail(ethereum, address, more);
            if (name.isErr()) return name;
            if (name.inner == null) return name;
            const address2 = await Lookup.fetchOrFail(ethereum, name.inner, more);
            if (address2.isErr()) return address2;
            if (address.toLowerCase() !== address2.inner.toLowerCase()) return new fetched_data/* Data */.V(undefined);
            return name;
        }
        Reverse.fetchOrFail = fetchOrFail;
    })(Reverse = BgEns.Reverse || (BgEns.Reverse = {}));
})(BgEns || (BgEns = {}));

// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/react/hooks/queries/simple.mjs + 1 modules
var simple = __webpack_require__(564);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/react/hooks/blocks/use-fetch.mjs
var use_fetch = __webpack_require__(4704);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/react/hooks/blocks/use-visible.mjs
var use_visible = __webpack_require__(7836);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/react/hooks/blocks/use-error.mjs
var use_error = __webpack_require__(3399);
// EXTERNAL MODULE: ./src/mods/foreground/storage/storage.ts
var storage_storage = __webpack_require__(921);
// EXTERNAL MODULE: ./src/mods/foreground/storage/user.tsx
var user = __webpack_require__(8777);
// EXTERNAL MODULE: ./src/mods/foreground/entities/wallets/data.ts
var data = __webpack_require__(9031);
;// CONCATENATED MODULE: ./src/mods/foreground/entities/names/data.ts






var FgEns;
(function(FgEns) {
    let Lookup;
    (function(Lookup) {
        Lookup.key = BgEns.Lookup.key;
        function schema(name, context, storage) {
            if (context == null) return;
            if (name == null) return;
            const fetcher = async (request)=>await (0,data/* customFetchOrFail */.Ky)(request, context);
            return (0,query/* createQuery */.rP)({
                key: BgEns.Lookup.key(name),
                fetcher,
                storage
            });
        }
        Lookup.schema = schema;
    })(Lookup = FgEns.Lookup || (FgEns.Lookup = {}));
    let Reverse;
    (function(Reverse) {
        function schema(address, context, storage) {
            if (context == null) return;
            if (address == null) return;
            const fetcher = async (request)=>await (0,data/* customFetchOrFail */.Ky)(request, context);
            return (0,query/* createQuery */.rP)({
                key: BgEns.Reverse.key(address),
                fetcher,
                storage
            });
        }
        Reverse.schema = schema;
    })(Reverse = FgEns.Reverse || (FgEns.Reverse = {}));
})(FgEns || (FgEns = {}));
function useEnsLookup(name, ethereum) {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(FgEns.Lookup.schema, [
        name,
        ethereum,
        storage
    ]);
    (0,use_fetch/* useFetch */.i)(query);
    (0,use_visible/* useVisible */.E)(query);
    (0,storage_storage/* useSubscribe */.Q)(query, storage);
    (0,use_error/* useError */.V)(query, errors/* Errors */.D.onQueryError);
    return query;
}
function useEnsReverse(address, ethereum) {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(FgEns.Reverse.schema, [
        address,
        ethereum,
        storage
    ]);
    (0,use_fetch/* useFetch */.i)(query);
    (0,use_visible/* useVisible */.E)(query);
    (0,storage_storage/* useSubscribe */.Q)(query, storage);
    (0,use_error/* useError */.V)(query, errors/* Errors */.D.onQueryError);
    return query;
}
/**
 * Used in the wallet list to display the ens name
 * @param address
 * @param ethereum
 * @returns
 */ function useEnsReverseNoFetch(address, ethereum) {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(FgEns.Reverse.schema, [
        address,
        ethereum,
        storage
    ]);
    (0,storage_storage/* useSubscribe */.Q)(query, storage);
    return query;
}


/***/ }),

/***/ 7489:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Vd: function() { return /* binding */ useAppRequest; },
  fU: function() { return /* binding */ useAppRequests; }
});

// UNUSED EXPORTS: FgAppRequest

// EXTERNAL MODULE: ./src/libs/glacier/mutators.ts
var mutators = __webpack_require__(2457);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/queries/simple/query.mjs
var query = __webpack_require__(6233);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/fetched/data.mjs
var data = __webpack_require__(8123);
;// CONCATENATED MODULE: ./src/mods/background/service_worker/entities/requests/data.tsx


var AppRequestRef;
(function(AppRequestRef) {
    function from(request) {
        return {
            ref: true,
            id: request.id
        };
    }
    AppRequestRef.from = from;
})(AppRequestRef || (AppRequestRef = {}));
var BgAppRequest;
(function(BgAppRequest) {
    let All;
    (function(All) {
        All.key = "requests";
        function schema() {
            return (0,query/* createQuery */.rP)({
                key: All.key
            });
        }
        All.schema = schema;
    })(All = BgAppRequest.All || (BgAppRequest.All = {}));
    function key(id) {
        return "request/".concat(id);
    }
    BgAppRequest.key = key;
    function schema(id) {
        const indexer = async (states)=>{
            var _previous_real, _current_real;
            const { current, previous = current } = states;
            const previousData = (_previous_real = previous.real) === null || _previous_real === void 0 ? void 0 : _previous_real.data;
            const currentData = (_current_real = current.real) === null || _current_real === void 0 ? void 0 : _current_real.data;
            await BgAppRequest.All.schema().mutate(mutators/* Mutators */.g.mapData(function() {
                let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : new data/* Data */.V([]);
                if ((previousData === null || previousData === void 0 ? void 0 : previousData.inner.id) === (currentData === null || currentData === void 0 ? void 0 : currentData.inner.id)) return d;
                if (previousData != null) d = d.mapSync((p)=>p.filter((x)=>x.id !== previousData.inner.id));
                if (currentData != null) d = d.mapSync((p)=>[
                        ...p,
                        AppRequestRef.from(currentData.inner)
                    ]);
                return d;
            }));
        };
        return (0,query/* createQuery */.rP)({
            key: key(id),
            indexer
        });
    }
    BgAppRequest.schema = schema;
})(BgAppRequest || (BgAppRequest = {}));

// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/react/hooks/queries/simple.mjs + 1 modules
var simple = __webpack_require__(564);
// EXTERNAL MODULE: ./src/mods/foreground/storage/storage.ts
var storage_storage = __webpack_require__(921);
// EXTERNAL MODULE: ./src/mods/foreground/storage/user.tsx
var user = __webpack_require__(8777);
;// CONCATENATED MODULE: ./src/mods/foreground/entities/requests/data.tsx





var FgAppRequest;
(function(FgAppRequest) {
    let All;
    (function(All) {
        All.key = BgAppRequest.All.key;
        function schema(storage) {
            return (0,query/* createQuery */.rP)({
                key: All.key,
                storage
            });
        }
        All.schema = schema;
    })(All = FgAppRequest.All || (FgAppRequest.All = {}));
    FgAppRequest.key = BgAppRequest.key;
    function schema(id, storage) {
        if (id == null) return;
        const indexer = async (states)=>{
            var _previous_real, _current_real;
            const { current, previous = current } = states;
            const previousData = (_previous_real = previous.real) === null || _previous_real === void 0 ? void 0 : _previous_real.data;
            const currentData = (_current_real = current.real) === null || _current_real === void 0 ? void 0 : _current_real.data;
            await All.schema(storage).mutate(mutators/* Mutators */.g.mapData(function() {
                let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : new data/* Data */.V([]);
                if ((previousData === null || previousData === void 0 ? void 0 : previousData.inner.id) === (currentData === null || currentData === void 0 ? void 0 : currentData.inner.id)) return d;
                if (previousData != null) d = d.mapSync((p)=>p.filter((x)=>x.id !== previousData.inner.id));
                if (currentData != null) d = d.mapSync((p)=>[
                        ...p,
                        AppRequestRef.from(currentData.inner)
                    ]);
                return d;
            }));
        };
        return (0,query/* createQuery */.rP)({
            key: FgAppRequest.key(id),
            indexer,
            storage
        });
    }
    FgAppRequest.schema = schema;
})(FgAppRequest || (FgAppRequest = {}));
function useAppRequest(id) {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(FgAppRequest.schema, [
        id,
        storage
    ]);
    (0,storage_storage/* useSubscribe */.Q)(query, storage);
    return query;
}
function useAppRequests() {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(FgAppRequest.All.schema, [
        storage
    ]);
    (0,storage_storage/* useSubscribe */.Q)(query, storage);
    return query;
}


/***/ }),

/***/ 7554:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Gz: function() { return /* binding */ SeedInstance; }
});

// UNUSED EXPORTS: AuthMnemonicSeedInstance, LedgerSeedInstance, UnauthMnemonicSeedInstance

// EXTERNAL MODULE: ./node_modules/@hazae41/base16/dist/esm/src/mods/base16/adapter.mjs
var adapter = __webpack_require__(2248);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/result.mjs
var result = __webpack_require__(918);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/ok.mjs
var ok = __webpack_require__(5591);
;// CONCATENATED MODULE: ./src/libs/ethereum/mods/signature.ts


var Hex;
(function(Hex) {
    function pad(text) {
        return text.padStart(text.length + text.length % 2, "0");
    }
    Hex.pad = pad;
})(Hex || (Hex = {}));
var Signature;
(function(Signature) {
    function tryFrom(init) {
        return result/* Result */.x.unthrowSync((t)=>{
            const { v, r, s } = init;
            const hv = Hex.pad(v.toString(16));
            const hr = adapter/* get */.U().tryEncode(r).throw(t);
            const hs = adapter/* get */.U().tryEncode(s).throw(t);
            return new ok.Ok("0x".concat(hr).concat(hs).concat(hv));
        });
    }
    Signature.tryFrom = tryFrom;
})(Signature || (Signature = {}));

// EXTERNAL MODULE: ./src/libs/ledger/index.ts + 9 modules
var ledger = __webpack_require__(2029);
// EXTERNAL MODULE: ./src/libs/webauthn/webauthn.ts
var webauthn = __webpack_require__(6177);
// EXTERNAL MODULE: ./node_modules/@hazae41/base64/dist/esm/src/mods/base64/adapter.mjs
var base64_adapter = __webpack_require__(9467);
// EXTERNAL MODULE: ./node_modules/@hazae41/bytes/dist/esm/mods/bytes/bytes.mjs + 3 modules
var bytes = __webpack_require__(1694);
// EXTERNAL MODULE: ./node_modules/@hazae41/option/dist/esm/mods/option/option.mjs
var option_option = __webpack_require__(5316);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/errors.mjs
var errors = __webpack_require__(2564);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/err.mjs
var err = __webpack_require__(166);
// EXTERNAL MODULE: ./node_modules/@scure/bip32/lib/esm/index.js + 15 modules
var esm = __webpack_require__(1141);
// EXTERNAL MODULE: ./node_modules/@scure/bip39/esm/index.js
var bip39_esm = __webpack_require__(4857);
// EXTERNAL MODULE: ./node_modules/@scure/bip39/esm/wordlists/english.js
var english = __webpack_require__(5957);
// EXTERNAL MODULE: ./node_modules/ethers/lib.esm/wallet/wallet.js + 35 modules
var wallet = __webpack_require__(8884);
// EXTERNAL MODULE: ./node_modules/ethers/lib.esm/hash/typed-data.js
var typed_data = __webpack_require__(1386);
;// CONCATENATED MODULE: ./src/mods/foreground/entities/seeds/all/helpers.tsx












var SeedInstance;
(function(SeedInstance) {
    async function tryFrom(seed, background) {
        if (seed.type === "mnemonic") return new ok.Ok(new UnauthMnemonicSeedInstance(seed));
        if (seed.type === "authMnemonic") return new ok.Ok(new AuthMnemonicSeedInstance(seed));
        if (seed.type === "ledger") return new ok.Ok(new LedgerSeedInstance(seed));
        throw new errors/* Panic */.F5();
    }
    SeedInstance.tryFrom = tryFrom;
})(SeedInstance || (SeedInstance = {}));
class UnauthMnemonicSeedInstance {
    async tryGetMnemonic(background) {
        return new ok.Ok(this.data.mnemonic);
    }
    async tryGetPrivateKey(path, background) {
        return await result/* Result */.x.unthrow(async (t)=>{
            const mnemonic = await this.tryGetMnemonic(background).then((r)=>r.throw(t));
            const masterSeed = await (0,bip39_esm/* mnemonicToSeed */.OI)(mnemonic);
            const root = esm/* HDKey */.B.fromMasterSeed(masterSeed);
            const child = root.derive(path);
            const privateKeyBytes = option_option/* Option */.W.wrap(child.privateKey).ok().throw(t);
            return new ok.Ok("0x".concat(adapter/* get */.U().tryEncode(privateKeyBytes).throw(t)));
        });
    }
    async trySignPersonalMessage(path, message, background) {
        return await result/* Result */.x.unthrow(async (t)=>{
            const privateKey = await this.tryGetPrivateKey(path, background).then((r)=>r.throw(t));
            const signature = await result/* Result */.x.runAndDoubleWrap(async ()=>{
                return await new wallet/* Wallet */.w(privateKey).signMessage(message);
            }).then((r)=>r.throw(t));
            return new ok.Ok(signature);
        });
    }
    async trySignTransaction(path, transaction, background) {
        return await result/* Result */.x.unthrow(async (t)=>{
            const privateKey = await this.tryGetPrivateKey(path, background).then((r)=>r.throw(t));
            const signature = result/* Result */.x.runAndDoubleWrapSync(()=>{
                return new wallet/* Wallet */.w(privateKey).signingKey.sign(transaction.unsignedHash).serialized;
            }).throw(t);
            return new ok.Ok(signature);
        });
    }
    async trySignEIP712HashedMessage(path, data, background) {
        return await result/* Result */.x.unthrow(async (t)=>{
            const privateKey = await this.tryGetPrivateKey(path, background).then((r)=>r.throw(t));
            delete data.types["EIP712Domain"];
            const signature = await result/* Result */.x.runAndDoubleWrap(async ()=>{
                return await new wallet/* Wallet */.w(privateKey).signTypedData(data.domain, data.types, data.message);
            }).then((r)=>r.throw(t));
            return new ok.Ok(signature);
        });
    }
    constructor(data){
        this.data = data;
    }
}
class AuthMnemonicSeedInstance {
    async tryGetMnemonic(background) {
        return await result/* Result */.x.unthrow(async (t)=>{
            const { idBase64, ivBase64 } = this.data.mnemonic;
            const id = base64_adapter/* get */.U().tryDecodePadded(idBase64).throw(t).copyAndDispose();
            const cipher = await webauthn/* WebAuthnStorage */.g.tryGet(id).then((r)=>r.throw(t));
            const cipherBase64 = base64_adapter/* get */.U().tryEncodePadded(cipher).throw(t);
            const entropyBase64 = await background.tryRequest({
                method: "brume_decrypt",
                params: [
                    ivBase64,
                    cipherBase64
                ]
            }).then((r)=>r.throw(t).throw(t));
            const entropy = base64_adapter/* get */.U().tryDecodePadded(entropyBase64).throw(t).copyAndDispose();
            return new ok.Ok((0,bip39_esm/* entropyToMnemonic */.JJ)(entropy, english/* wordlist */.U));
        });
    }
    async tryGetPrivateKey(path, background) {
        return await result/* Result */.x.unthrow(async (t)=>{
            const mnemonic = await this.tryGetMnemonic(background).then((r)=>r.throw(t));
            const masterSeed = await (0,bip39_esm/* mnemonicToSeed */.OI)(mnemonic);
            const root = esm/* HDKey */.B.fromMasterSeed(masterSeed);
            const child = root.derive(path);
            const privateKeyBytes = option_option/* Option */.W.wrap(child.privateKey).ok().throw(t);
            return new ok.Ok("0x".concat(adapter/* get */.U().tryEncode(privateKeyBytes).throw(t)));
        });
    }
    async trySignPersonalMessage(path, message, background) {
        return await result/* Result */.x.unthrow(async (t)=>{
            const privateKey = await this.tryGetPrivateKey(path, background).then((r)=>r.throw(t));
            const signature = await result/* Result */.x.runAndDoubleWrap(async ()=>{
                return await new wallet/* Wallet */.w(privateKey).signMessage(message);
            }).then((r)=>r.throw(t));
            return new ok.Ok(signature);
        });
    }
    async trySignTransaction(path, transaction, background) {
        return await result/* Result */.x.unthrow(async (t)=>{
            const privateKey = await this.tryGetPrivateKey(path, background).then((r)=>r.throw(t));
            const signature = result/* Result */.x.runAndDoubleWrapSync(()=>{
                return new wallet/* Wallet */.w(privateKey).signingKey.sign(transaction.unsignedHash).serialized;
            }).throw(t);
            return new ok.Ok(signature);
        });
    }
    async trySignEIP712HashedMessage(path, data, background) {
        return await result/* Result */.x.unthrow(async (t)=>{
            const privateKey = await this.tryGetPrivateKey(path, background).then((r)=>r.throw(t));
            delete data.types["EIP712Domain"];
            const signature = await result/* Result */.x.runAndDoubleWrap(async ()=>{
                return await new wallet/* Wallet */.w(privateKey).signTypedData(data.domain, data.types, data.message);
            }).then((r)=>r.throw(t));
            return new ok.Ok(signature);
        });
    }
    constructor(data){
        this.data = data;
    }
}
class LedgerSeedInstance {
    async tryGetMnemonic(background) {
        return new err/* Err */.U(new errors/* Unimplemented */.iJ());
    }
    async tryGetPrivateKey(path, background) {
        return new err/* Err */.U(new errors/* Unimplemented */.iJ());
    }
    async trySignPersonalMessage(path, message, background) {
        return await result/* Result */.x.unthrow(async (t)=>{
            const device = await ledger/* Ledger.USB.tryConnect */.P.vB.tryConnect().then((r)=>r.throw(t));
            const signature = await ledger/* Ledger.Ethereum.trySignPersonalMessage */.P.kJ.trySignPersonalMessage(device, path.slice(2), bytes/* Bytes */.J.fromUtf8(message)).then((r)=>r.throw(t));
            return Signature.tryFrom(signature);
        });
    }
    async trySignTransaction(path, transaction, background) {
        return await result/* Result */.x.unthrow(async (t)=>{
            const device = await ledger/* Ledger.USB.tryConnect */.P.vB.tryConnect().then((r)=>r.throw(t));
            const signature = await ledger/* Ledger.Ethereum.trySignTransaction */.P.kJ.trySignTransaction(device, path.slice(2), transaction).then((r)=>r.throw(t));
            return Signature.tryFrom(signature);
        });
    }
    async trySignEIP712HashedMessage(path, data, background) {
        return await result/* Result */.x.unthrow(async (t)=>{
            const device = await ledger/* Ledger.USB.tryConnect */.P.vB.tryConnect().then((r)=>r.throw(t));
            delete data.types["EIP712Domain"];
            const encoder = result/* Result */.x.runAndDoubleWrapSync(()=>{
                return new typed_data/* TypedDataEncoder */.E(data.types);
            }).throw(t);
            const domain = result/* Result */.x.runAndDoubleWrapSync(()=>{
                return adapter/* get */.U().tryPadStartAndDecode(typed_data/* TypedDataEncoder */.E.hashDomain(data.domain).slice(2)).unwrap().copyAndDispose();
            }).throw(t);
            const message = result/* Result */.x.runAndDoubleWrapSync(()=>{
                return adapter/* get */.U().tryPadStartAndDecode(encoder.hashStruct(data.primaryType, data.message).slice(2)).unwrap().copyAndDispose();
            }).throw(t);
            const signature = await ledger/* Ledger.Ethereum.trySignEIP712HashedMessage */.P.kJ.trySignEIP712HashedMessage(device, path.slice(2), domain, message).then((r)=>r.throw(t));
            return Signature.tryFrom(signature);
        });
    }
    constructor(data){
        this.data = data;
    }
}


/***/ }),

/***/ 1075:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   EU: function() { return /* binding */ FgSeed; },
/* harmony export */   Eu: function() { return /* binding */ useSeeds; },
/* harmony export */   WJ: function() { return /* binding */ useSeed; }
/* harmony export */ });
/* harmony import */ var _libs_glacier_mutators__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2457);
/* harmony import */ var _mods_background_service_worker_entities_seeds_data__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7254);
/* harmony import */ var _hazae41_glacier__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6233);
/* harmony import */ var _hazae41_glacier__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8123);
/* harmony import */ var _hazae41_glacier__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(564);
/* harmony import */ var _storage_storage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(921);
/* harmony import */ var _storage_user__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8777);





var FgSeed;
(function(FgSeed) {
    let All;
    (function(All) {
        All.key = _mods_background_service_worker_entities_seeds_data__WEBPACK_IMPORTED_MODULE_1__/* .BgSeed */ .K.All.key;
        function schema(storage) {
            return (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_4__/* .createQuery */ .rP)({
                key: All.key,
                storage
            });
        }
        All.schema = schema;
    })(All = FgSeed.All || (FgSeed.All = {}));
    FgSeed.key = _mods_background_service_worker_entities_seeds_data__WEBPACK_IMPORTED_MODULE_1__/* .BgSeed */ .K.key;
    function schema(uuid, storage) {
        if (uuid == null) return;
        const indexer = async (states)=>{
            var _previous_real, _current_real;
            const { current, previous = current } = states;
            const previousData = (_previous_real = previous.real) === null || _previous_real === void 0 ? void 0 : _previous_real.data;
            const currentData = (_current_real = current.real) === null || _current_real === void 0 ? void 0 : _current_real.data;
            await All.schema(storage).mutate(_libs_glacier_mutators__WEBPACK_IMPORTED_MODULE_0__/* .Mutators */ .g.mapData(function() {
                let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : new _hazae41_glacier__WEBPACK_IMPORTED_MODULE_5__/* .Data */ .V([]);
                if ((previousData === null || previousData === void 0 ? void 0 : previousData.inner.uuid) === (currentData === null || currentData === void 0 ? void 0 : currentData.inner.uuid)) return d;
                if (previousData != null) d = d.mapSync((p)=>p.filter((x)=>x.uuid !== previousData.inner.uuid));
                if (currentData != null) d = d.mapSync((p)=>[
                        ...p,
                        _mods_background_service_worker_entities_seeds_data__WEBPACK_IMPORTED_MODULE_1__/* .SeedRef */ .M.from(currentData.inner)
                    ]);
                return d;
            }));
        };
        return (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_4__/* .createQuery */ .rP)({
            key: FgSeed.key(uuid),
            indexer,
            storage
        });
    }
    FgSeed.schema = schema;
})(FgSeed || (FgSeed = {}));
function useSeed(uuid) {
    const storage = (0,_storage_user__WEBPACK_IMPORTED_MODULE_3__/* .useUserStorageContext */ .v6)().unwrap();
    const query = (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_6__/* .useQuery */ .aM)(FgSeed.schema, [
        uuid,
        storage
    ]);
    (0,_storage_storage__WEBPACK_IMPORTED_MODULE_2__/* .useSubscribe */ .Q)(query, storage);
    return query;
}
function useSeeds() {
    const storage = (0,_storage_user__WEBPACK_IMPORTED_MODULE_3__/* .useUserStorageContext */ .v6)().unwrap();
    const query = (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_6__/* .useQuery */ .aM)(FgSeed.All.schema, [
        storage
    ]);
    (0,_storage_storage__WEBPACK_IMPORTED_MODULE_2__/* .useSubscribe */ .Q)(query, storage);
    return query;
}


/***/ }),

/***/ 5830:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  k: function() { return /* binding */ useSession; }
});

// UNUSED EXPORTS: FgSession

// EXTERNAL MODULE: ./src/libs/glacier/mutators.ts
var mutators = __webpack_require__(2457);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/queries/simple/query.mjs
var query = __webpack_require__(6233);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/fetched/data.mjs
var data = __webpack_require__(8123);
;// CONCATENATED MODULE: ./src/mods/background/service_worker/entities/sessions/data.ts


var SessionRef;
(function(SessionRef) {
    function from(session) {
        return {
            ref: true,
            id: session.id,
            origin: session.origin
        };
    }
    SessionRef.from = from;
})(SessionRef || (SessionRef = {}));
class SessionStorage {
    getOrThrow(cacheKey) {
        return this.storage.getOrThrow(cacheKey);
    }
    setOrThrow(cacheKey, value) {
        var _value_data;
        if ((value === null || value === void 0 ? void 0 : (_value_data = value.data) === null || _value_data === void 0 ? void 0 : _value_data.data.persist) === false) return;
        return this.storage.setOrThrow(cacheKey, value);
    }
    constructor(storage){
        this.storage = storage;
    }
}
var BgSession;
(function(BgSession) {
    let All;
    (function(All) {
        let Temporary;
        (function(Temporary) {
            let ByWallet;
            (function(ByWallet) {
                function key(wallet) {
                    return "temporarySessionsByWallet/v2/".concat(wallet);
                }
                ByWallet.key = key;
                function schema(wallet) {
                    return (0,query/* createQuery */.rP)({
                        key: key(wallet)
                    });
                }
                ByWallet.schema = schema;
            })(ByWallet = Temporary.ByWallet || (Temporary.ByWallet = {}));
            Temporary.key = "temporarySessions/v2";
            function schema() {
                return (0,query/* createQuery */.rP)({
                    key: Temporary.key
                });
            }
            Temporary.schema = schema;
        })(Temporary = All.Temporary || (All.Temporary = {}));
        let Persistent;
        (function(Persistent) {
            let ByWallet;
            (function(ByWallet) {
                function key(wallet) {
                    return "persistentSessionsByWallet/v2/".concat(wallet);
                }
                ByWallet.key = key;
                function schema(wallet, storage) {
                    return (0,query/* createQuery */.rP)({
                        key: key(wallet),
                        storage
                    });
                }
                ByWallet.schema = schema;
            })(ByWallet = Persistent.ByWallet || (Persistent.ByWallet = {}));
            Persistent.key = "persistentSessions/v2";
            function schema(storage) {
                return (0,query/* createQuery */.rP)({
                    key: Persistent.key,
                    storage
                });
            }
            Persistent.schema = schema;
        })(Persistent = All.Persistent || (All.Persistent = {}));
    })(All = BgSession.All || (BgSession.All = {}));
    let ByOrigin;
    (function(ByOrigin) {
        function key(origin) {
            return "sessionByOrigin/".concat(origin);
        }
        ByOrigin.key = key;
        function schema(origin, storage) {
            return (0,query/* createQuery */.rP)({
                key: key(origin),
                storage
            });
        }
        ByOrigin.schema = schema;
    })(ByOrigin = BgSession.ByOrigin || (BgSession.ByOrigin = {}));
    function key(id) {
        return "session/v4/".concat(id);
    }
    BgSession.key = key;
    function schema(id, storage) {
        const indexer = async (states)=>{
            var _previous_real, _current_real;
            const { current, previous = current } = states;
            const previousData = (_previous_real = previous.real) === null || _previous_real === void 0 ? void 0 : _previous_real.data;
            const currentData = (_current_real = current.real) === null || _current_real === void 0 ? void 0 : _current_real.data;
            if (previousData != null) {
                if (previousData.inner.persist) {
                    const sessionByOrigin = ByOrigin.schema(previousData.inner.origin, storage);
                    await sessionByOrigin.delete();
                }
                const sessionsQuery = previousData.inner.persist ? All.Persistent.schema(storage) : All.Temporary.schema();
                await sessionsQuery.mutate(mutators/* Mutators */.g.mapData(function() {
                    let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : new data/* Data */.V([]);
                    return d.mapSync((p)=>p.filter((x)=>x.id !== previousData.inner.id));
                }));
                const previousWallets = new Set(previousData.inner.wallets);
                for (const wallet of previousWallets){
                    const sessionsByWalletQuery = previousData.inner.persist ? All.Persistent.ByWallet.schema(wallet.uuid, storage) : All.Temporary.ByWallet.schema(wallet.uuid);
                    await sessionsByWalletQuery.mutate(mutators/* Mutators */.g.mapData(function() {
                        let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : new data/* Data */.V([]);
                        return d.mapSync((p)=>p.filter((x)=>x.id !== previousData.inner.id));
                    }));
                }
            }
            if (currentData != null) {
                if (currentData.inner.persist) {
                    const sessionByOrigin = ByOrigin.schema(currentData.inner.origin, storage);
                    await sessionByOrigin.mutate(mutators/* Mutators */.g.data(SessionRef.from(currentData.inner)));
                }
                const sessionsQuery = currentData.inner.persist ? All.Persistent.schema(storage) : All.Temporary.schema();
                await sessionsQuery.mutate(mutators/* Mutators */.g.mapData(function() {
                    let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : new data/* Data */.V([]);
                    return d = d.mapSync((p)=>[
                            ...p,
                            SessionRef.from(currentData.inner)
                        ]);
                }));
                const currentWallets = new Set(currentData.inner.wallets);
                for (const wallet of currentWallets){
                    const sessionsByWalletQuery = currentData.inner.persist ? All.Persistent.ByWallet.schema(wallet.uuid, storage) : All.Temporary.ByWallet.schema(wallet.uuid);
                    await sessionsByWalletQuery.mutate(mutators/* Mutators */.g.mapData(function() {
                        let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : new data/* Data */.V([]);
                        return d.mapSync((p)=>[
                                ...p,
                                SessionRef.from(currentData.inner)
                            ]);
                    }));
                }
            }
        };
        return (0,query/* createQuery */.rP)({
            key: key(id),
            indexer,
            storage: new SessionStorage(storage)
        });
    }
    BgSession.schema = schema;
})(BgSession || (BgSession = {}));

// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/react/hooks/queries/simple.mjs + 1 modules
var simple = __webpack_require__(564);
// EXTERNAL MODULE: ./src/mods/foreground/storage/storage.ts
var storage_storage = __webpack_require__(921);
// EXTERNAL MODULE: ./src/mods/foreground/storage/user.tsx
var user = __webpack_require__(8777);
;// CONCATENATED MODULE: ./src/mods/foreground/entities/sessions/data.ts





var FgSession;
(function(FgSession) {
    let All;
    (function(All) {
        let Temporary;
        (function(Temporary) {
            let ByWallet;
            (function(ByWallet) {
                ByWallet.key = BgSession.All.Temporary.ByWallet.key;
                function schema(wallet, storage) {
                    if (wallet == null) return;
                    return (0,query/* createQuery */.rP)({
                        key: ByWallet.key(wallet),
                        storage
                    });
                }
                ByWallet.schema = schema;
            })(ByWallet = Temporary.ByWallet || (Temporary.ByWallet = {}));
            Temporary.key = BgSession.All.Temporary.key;
            function schema(storage) {
                return (0,query/* createQuery */.rP)({
                    key: Temporary.key,
                    storage
                });
            }
            Temporary.schema = schema;
        })(Temporary = All.Temporary || (All.Temporary = {}));
        let Persistent;
        (function(Persistent) {
            let ByWallet;
            (function(ByWallet) {
                ByWallet.key = BgSession.All.Persistent.ByWallet.key;
                function schema(wallet, storage) {
                    if (wallet == null) return;
                    return (0,query/* createQuery */.rP)({
                        key: ByWallet.key(wallet),
                        storage
                    });
                }
                ByWallet.schema = schema;
            })(ByWallet = Persistent.ByWallet || (Persistent.ByWallet = {}));
            Persistent.key = BgSession.All.Persistent.key;
            function schema(storage) {
                return (0,query/* createQuery */.rP)({
                    key: Persistent.key,
                    storage
                });
            }
            Persistent.schema = schema;
        })(Persistent = All.Persistent || (All.Persistent = {}));
    })(All = FgSession.All || (FgSession.All = {}));
    let ByOrigin;
    (function(ByOrigin) {
        ByOrigin.key = BgSession.ByOrigin.key;
        function schema(origin, storage) {
            return (0,query/* createQuery */.rP)({
                key: ByOrigin.key(origin),
                storage
            });
        }
        ByOrigin.schema = schema;
    })(ByOrigin = FgSession.ByOrigin || (FgSession.ByOrigin = {}));
    FgSession.key = BgSession.key;
    function shema(id, storage) {
        if (id == null) return;
        const indexer = async (states)=>{
            var _previous_real, _current_real;
            const { current, previous = current } = states;
            const previousData = (_previous_real = previous.real) === null || _previous_real === void 0 ? void 0 : _previous_real.data;
            const currentData = (_current_real = current.real) === null || _current_real === void 0 ? void 0 : _current_real.data;
            if (previousData != null) {
                if (previousData.inner.persist) {
                    const sessionByOrigin = ByOrigin.schema(previousData.inner.origin, storage);
                    await sessionByOrigin.delete();
                }
                const sessionsQuery = previousData.inner.persist ? All.Persistent.schema(storage) : All.Temporary.schema(storage);
                await sessionsQuery.mutate(mutators/* Mutators */.g.mapData(function() {
                    let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : new data/* Data */.V([]);
                    return d.mapSync((p)=>p.filter((x)=>x.id !== previousData.inner.id));
                }));
                const previousWallets = new Set(previousData.inner.wallets);
                for (const wallet of previousWallets){
                    const sessionsByWalletQuery = previousData.inner.persist ? All.Persistent.ByWallet.schema(wallet.uuid, storage) : All.Temporary.ByWallet.schema(wallet.uuid, storage);
                    await (sessionsByWalletQuery === null || sessionsByWalletQuery === void 0 ? void 0 : sessionsByWalletQuery.mutate(mutators/* Mutators */.g.mapData(function() {
                        let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : new data/* Data */.V([]);
                        return d.mapSync((p)=>p.filter((x)=>x.id !== previousData.inner.id));
                    })));
                }
            }
            if (currentData != null) {
                if (currentData.inner.persist) {
                    const sessionByOrigin = ByOrigin.schema(currentData.inner.origin, storage);
                    await sessionByOrigin.mutate(mutators/* Mutators */.g.data(SessionRef.from(currentData.inner)));
                }
                const sessionsQuery = currentData.inner.persist ? All.Persistent.schema(storage) : All.Temporary.schema(storage);
                await sessionsQuery.mutate(mutators/* Mutators */.g.mapData(function() {
                    let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : new data/* Data */.V([]);
                    return d = d.mapSync((p)=>[
                            ...p,
                            SessionRef.from(currentData.inner)
                        ]);
                }));
                const currentWallets = new Set(currentData.inner.wallets);
                for (const wallet of currentWallets){
                    const sessionsByWalletQuery = currentData.inner.persist ? All.Persistent.ByWallet.schema(wallet.uuid, storage) : All.Temporary.ByWallet.schema(wallet.uuid, storage);
                    await (sessionsByWalletQuery === null || sessionsByWalletQuery === void 0 ? void 0 : sessionsByWalletQuery.mutate(mutators/* Mutators */.g.mapData(function() {
                        let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : new data/* Data */.V([]);
                        return d.mapSync((p)=>[
                                ...p,
                                SessionRef.from(currentData.inner)
                            ]);
                    })));
                }
            }
        };
        return (0,query/* createQuery */.rP)({
            key: FgSession.key(id),
            indexer,
            storage
        });
    }
    FgSession.shema = shema;
})(FgSession || (FgSession = {}));
function useSession(id) {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(FgSession.shema, [
        id,
        storage
    ]);
    (0,storage_storage/* useSubscribe */.Q)(query, storage);
    return query;
}


/***/ }),

/***/ 4035:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  F: function() { return /* binding */ useSignature; }
});

// UNUSED EXPORTS: FgSignature

// EXTERNAL MODULE: ./src/libs/errors/errors.ts
var errors = __webpack_require__(9071);
// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/abi/encode.mjs
var encode = __webpack_require__(6167);
// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/abi/signature/signature.mjs + 3 modules
var signature = __webpack_require__(167);
// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/abi/types/tuple/tuple.mjs
var tuple = __webpack_require__(5444);
// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/abi/types/vector/vector.mjs
var vector = __webpack_require__(8904);
// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/abi/types/string/string.mjs
var string = __webpack_require__(3997);
// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/abi/decode.mjs + 1 modules
var decode = __webpack_require__(7817);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/fetched/data.mjs
var data = __webpack_require__(8123);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/fetched/fail.mjs
var fail = __webpack_require__(9164);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/queries/simple/query.mjs
var query = __webpack_require__(6233);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/result.mjs
var result = __webpack_require__(918);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/errors.mjs
var result_errors = __webpack_require__(2564);
// EXTERNAL MODULE: ./src/mods/background/service_worker/context.ts + 4 modules
var context = __webpack_require__(2223);
;// CONCATENATED MODULE: ./src/mods/background/service_worker/entities/signatures/data.ts




var BgSignature;
(function(BgSignature) {
    BgSignature.method = "sig_getSignatures";
    function key(hash) {
        return result/* Result */.x.runAndWrapSync(()=>({
                chainId: 100,
                method: "eth_call",
                params: [
                    {
                        to: "0xBB59B5Cc543746A16011BC011F4db742F918672F",
                        data: encode/* encodeOrThrow */.YM(signature/* FunctionSignature */.I.parseOrThrow("get(bytes4)").from(hash))
                    },
                    "latest"
                ]
            })).ok().inner;
    }
    BgSignature.key = key;
    function schema(hash, ethereum, storage) {
        const maybeKey = key(hash);
        if (maybeKey == null) return;
        const fetcher = async (request, more)=>{
            try {
                const fetched = await context/* BgEthereumContext */.H.fetchOrFail(ethereum, request);
                if (fetched.isErr()) return fetched;
                const returns = tuple/* Tuple */.p.create(vector/* Vector */.O.create(string/* String */.L));
                const [texts] = decode/* decodeOrThrow */.Dt(returns, fetched.inner).intoOrThrow();
                return new data/* Data */.V(texts);
            } catch (e) {
                return new fail/* Fail */.M(result_errors/* Catched */.$c.from(e));
            }
        };
        return (0,query/* createQuery */.rP)({
            key: maybeKey,
            fetcher,
            storage
        });
    }
    BgSignature.schema = schema;
})(BgSignature || (BgSignature = {}));

// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/react/hooks/queries/simple.mjs + 1 modules
var simple = __webpack_require__(564);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/react/hooks/blocks/use-fetch.mjs
var use_fetch = __webpack_require__(4704);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/react/hooks/blocks/use-visible.mjs
var use_visible = __webpack_require__(7836);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/react/hooks/blocks/use-error.mjs
var use_error = __webpack_require__(3399);
// EXTERNAL MODULE: ./src/mods/foreground/storage/storage.ts
var storage_storage = __webpack_require__(921);
// EXTERNAL MODULE: ./src/mods/foreground/storage/user.tsx
var user = __webpack_require__(8777);
// EXTERNAL MODULE: ./src/mods/foreground/entities/wallets/data.ts
var wallets_data = __webpack_require__(9031);
;// CONCATENATED MODULE: ./src/mods/foreground/entities/signatures/data.tsx








var FgSignature;
(function(FgSignature) {
    FgSignature.key = BgSignature.key;
    function schema(hash, ethereum, storage) {
        if (ethereum == null) return;
        if (hash == null) return;
        const maybeKey = FgSignature.key(hash);
        if (maybeKey == null) return;
        const fetcher = async (request)=>{
            try {
                const fetched = await (0,wallets_data/* fetchOrFail */.yR)(request, ethereum);
                if (fetched.isErr()) return fetched;
                const returns = tuple/* Tuple */.p.create(vector/* Vector */.O.create(string/* String */.L));
                const [texts] = decode/* decodeOrThrow */.Dt(returns, fetched.inner).intoOrThrow();
                return new data/* Data */.V(texts);
            } catch (e) {
                return new fail/* Fail */.M(result_errors/* Catched */.$c.from(e));
            }
        };
        return (0,query/* createQuery */.rP)({
            key: maybeKey,
            fetcher,
            storage
        });
    }
    FgSignature.schema = schema;
})(FgSignature || (FgSignature = {}));
function useSignature(hash, ethereum) {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(FgSignature.schema, [
        hash,
        ethereum,
        storage
    ]);
    (0,use_fetch/* useFetch */.i)(query);
    (0,use_visible/* useVisible */.E)(query);
    (0,storage_storage/* useSubscribe */.Q)(query, storage);
    (0,use_error/* useError */.V)(query, errors/* Errors */.D.onQueryError);
    return query;
}


/***/ }),

/***/ 5234:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Fh: function() { return /* binding */ useGasPrice; },
/* harmony export */   Nh: function() { return /* binding */ useEstimateGas; },
/* harmony export */   Q6: function() { return /* binding */ FgTotal; },
/* harmony export */   XE: function() { return /* binding */ useNonce; },
/* harmony export */   ZO: function() { return /* binding */ useTotalPricedBalance; },
/* harmony export */   h7: function() { return /* binding */ useTotalWalletPricedBalance; },
/* harmony export */   hy: function() { return /* binding */ useMaxPriorityFeePerGas; },
/* harmony export */   qK: function() { return /* binding */ FgEthereum; }
/* harmony export */ });
/* unused harmony export useUnknown */
/* harmony import */ var _libs_bigints_bigints__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7795);
/* harmony import */ var _libs_errors_errors__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9071);
/* harmony import */ var _libs_glacier_mutators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2457);
/* harmony import */ var _mods_background_service_worker_entities_unknown_data__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3499);
/* harmony import */ var _hazae41_cubane__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(8386);
/* harmony import */ var _hazae41_glacier__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6233);
/* harmony import */ var _hazae41_glacier__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(564);
/* harmony import */ var _hazae41_glacier__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4704);
/* harmony import */ var _hazae41_glacier__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7836);
/* harmony import */ var _hazae41_glacier__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8995);
/* harmony import */ var _hazae41_glacier__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3399);
/* harmony import */ var _hazae41_glacier__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(8123);
/* harmony import */ var _hazae41_option__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(5316);
/* harmony import */ var _storage_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(921);
/* harmony import */ var _storage_user__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8777);
/* harmony import */ var _wallets_data__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9031);










var FgEthereum;
(function(FgEthereum) {
    let Unknown;
    (function(Unknown) {
        Unknown.key = _mods_background_service_worker_entities_unknown_data__WEBPACK_IMPORTED_MODULE_3__/* .BgEthereum */ .$.Unknown.key;
        function schema(request, context, storage) {
            if (context == null) return;
            if (request == null) return;
            const fetcher = async (request)=>await (0,_wallets_data__WEBPACK_IMPORTED_MODULE_6__/* .fetchOrFail */ .yR)(request, context);
            return (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_7__/* .createQuery */ .rP)({
                key: Unknown.key(context.chain.chainId, request),
                fetcher,
                storage
            });
        }
        Unknown.schema = schema;
    })(Unknown = FgEthereum.Unknown || (FgEthereum.Unknown = {}));
    let EstimateGas;
    (function(EstimateGas) {
        function key(request, context) {
            return {
                chainId: context.chain.chainId,
                method: "eth_estimateGas",
                params: request.params,
                noCheck: true
            };
        }
        EstimateGas.key = key;
        function schema(request, context, storage) {
            if (context == null) return;
            if (request == null) return;
            const fetcher = async (request)=>await (0,_wallets_data__WEBPACK_IMPORTED_MODULE_6__/* .fetchOrFail */ .yR)(request, context).then((r)=>r.mapSync(BigInt));
            return (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_7__/* .createQuery */ .rP)({
                key: key(request, context),
                fetcher,
                storage,
                dataSerializer: _libs_bigints_bigints__WEBPACK_IMPORTED_MODULE_0__/* .BigIntToHex */ .W
            });
        }
        EstimateGas.schema = schema;
    })(EstimateGas = FgEthereum.EstimateGas || (FgEthereum.EstimateGas = {}));
    let MaxPriorityFeePerGas;
    (function(MaxPriorityFeePerGas) {
        function key(chain) {
            return {
                chainId: chain.chainId,
                method: "eth_maxPriorityFeePerGas",
                params: [],
                noCheck: true
            };
        }
        MaxPriorityFeePerGas.key = key;
        function schema(context, storage) {
            if (context == null) return;
            const fetcher = async (request)=>await (0,_wallets_data__WEBPACK_IMPORTED_MODULE_6__/* .fetchOrFail */ .yR)(request, context).then((r)=>r.mapSync(BigInt));
            return (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_7__/* .createQuery */ .rP)({
                key: key(context.chain),
                fetcher,
                storage,
                dataSerializer: _libs_bigints_bigints__WEBPACK_IMPORTED_MODULE_0__/* .BigIntToHex */ .W
            });
        }
        MaxPriorityFeePerGas.schema = schema;
    })(MaxPriorityFeePerGas = FgEthereum.MaxPriorityFeePerGas || (FgEthereum.MaxPriorityFeePerGas = {}));
    let GasPrice;
    (function(GasPrice) {
        function key(chain) {
            return {
                chainId: chain.chainId,
                method: "eth_gasPrice",
                params: [],
                noCheck: true
            };
        }
        GasPrice.key = key;
        function schema(context, storage) {
            if (context == null) return;
            const fetcher = async (request)=>await (0,_wallets_data__WEBPACK_IMPORTED_MODULE_6__/* .fetchOrFail */ .yR)(request, context).then((r)=>r.mapSync(BigInt));
            return (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_7__/* .createQuery */ .rP)({
                key: key(context.chain),
                fetcher,
                storage,
                dataSerializer: _libs_bigints_bigints__WEBPACK_IMPORTED_MODULE_0__/* .BigIntToHex */ .W
            });
        }
        GasPrice.schema = schema;
    })(GasPrice = FgEthereum.GasPrice || (FgEthereum.GasPrice = {}));
    let Nonce;
    (function(Nonce) {
        function key(address, chain) {
            return {
                chainId: chain.chainId,
                method: "eth_getTransactionCount",
                params: [
                    address,
                    "pending"
                ]
            };
        }
        Nonce.key = key;
        function schema(address, context, storage) {
            if (address == null) return;
            if (context == null) return;
            const fetcher = async function(request) {
                let more = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
                return await (0,_wallets_data__WEBPACK_IMPORTED_MODULE_6__/* .fetchOrFail */ .yR)(request, context).then((r)=>r.mapSync(BigInt));
            };
            return (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_7__/* .createQuery */ .rP)({
                key: key(address, context.chain),
                fetcher,
                storage,
                dataSerializer: _libs_bigints_bigints__WEBPACK_IMPORTED_MODULE_0__/* .BigIntToHex */ .W
            });
        }
        Nonce.schema = schema;
    })(Nonce = FgEthereum.Nonce || (FgEthereum.Nonce = {}));
})(FgEthereum || (FgEthereum = {}));
function useUnknown(request, context) {
    const storage = useUserStorageContext().unwrap();
    const query = useQuery(FgEthereum.Unknown.schema, [
        request,
        context,
        storage
    ]);
    useFetch(query);
    useVisible(query);
    useSubscribe(query, storage);
    useError(query, Errors.onQueryError);
    return query;
}
function useEstimateGas(request, context) {
    const storage = (0,_storage_user__WEBPACK_IMPORTED_MODULE_5__/* .useUserStorageContext */ .v6)().unwrap();
    const query = (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_8__/* .useQuery */ .aM)(FgEthereum.EstimateGas.schema, [
        request,
        context,
        storage
    ]);
    (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_9__/* .useFetch */ .i)(query);
    (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_10__/* .useVisible */ .E)(query);
    (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_11__/* .useInterval */ .Y)(query, 10 * 1000);
    (0,_storage_storage__WEBPACK_IMPORTED_MODULE_4__/* .useSubscribe */ .Q)(query, storage);
    (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_12__/* .useError */ .V)(query, _libs_errors_errors__WEBPACK_IMPORTED_MODULE_1__/* .Errors */ .D.onQueryError);
    return query;
}
function useMaxPriorityFeePerGas(context) {
    const storage = (0,_storage_user__WEBPACK_IMPORTED_MODULE_5__/* .useUserStorageContext */ .v6)().unwrap();
    const query = (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_8__/* .useQuery */ .aM)(FgEthereum.MaxPriorityFeePerGas.schema, [
        context,
        storage
    ]);
    (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_9__/* .useFetch */ .i)(query);
    (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_10__/* .useVisible */ .E)(query);
    (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_11__/* .useInterval */ .Y)(query, 10 * 1000);
    (0,_storage_storage__WEBPACK_IMPORTED_MODULE_4__/* .useSubscribe */ .Q)(query, storage);
    (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_12__/* .useError */ .V)(query, _libs_errors_errors__WEBPACK_IMPORTED_MODULE_1__/* .Errors */ .D.onQueryError);
    return query;
}
function useGasPrice(context) {
    const storage = (0,_storage_user__WEBPACK_IMPORTED_MODULE_5__/* .useUserStorageContext */ .v6)().unwrap();
    const query = (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_8__/* .useQuery */ .aM)(FgEthereum.GasPrice.schema, [
        context,
        storage
    ]);
    (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_9__/* .useFetch */ .i)(query);
    (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_10__/* .useVisible */ .E)(query);
    (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_11__/* .useInterval */ .Y)(query, 10 * 1000);
    (0,_storage_storage__WEBPACK_IMPORTED_MODULE_4__/* .useSubscribe */ .Q)(query, storage);
    (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_12__/* .useError */ .V)(query, _libs_errors_errors__WEBPACK_IMPORTED_MODULE_1__/* .Errors */ .D.onQueryError);
    return query;
}
function useNonce(address, context) {
    const storage = (0,_storage_user__WEBPACK_IMPORTED_MODULE_5__/* .useUserStorageContext */ .v6)().unwrap();
    const query = (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_8__/* .useQuery */ .aM)(FgEthereum.Nonce.schema, [
        address,
        context,
        storage
    ]);
    (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_9__/* .useFetch */ .i)(query);
    (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_10__/* .useVisible */ .E)(query);
    (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_11__/* .useInterval */ .Y)(query, 10 * 1000);
    (0,_storage_storage__WEBPACK_IMPORTED_MODULE_4__/* .useSubscribe */ .Q)(query, storage);
    (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_12__/* .useError */ .V)(query, _libs_errors_errors__WEBPACK_IMPORTED_MODULE_1__/* .Errors */ .D.onQueryError);
    return query;
}
var FgTotal;
(function(FgTotal) {
    let Balance;
    (function(Balance) {
        let Priced;
        (function(Priced) {
            let ByAddress;
            (function(ByAddress) {
                let Record;
                (function(Record) {
                    Record.key = _mods_background_service_worker_entities_unknown_data__WEBPACK_IMPORTED_MODULE_3__/* .BgTotal */ .f.Balance.Priced.ByAddress.Record.key;
                    function schema(coin, storage) {
                        const indexer = async (states)=>{
                            var _states_current_real_data, _states_current_real;
                            const values = _hazae41_option__WEBPACK_IMPORTED_MODULE_13__/* .Option */ .W.wrap((_states_current_real = states.current.real) === null || _states_current_real === void 0 ? void 0 : (_states_current_real_data = _states_current_real.data) === null || _states_current_real_data === void 0 ? void 0 : _states_current_real_data.get()).unwrapOr({});
                            const total = Object.values(values).reduce((x, y)=>_hazae41_cubane__WEBPACK_IMPORTED_MODULE_14__/* .Fixed */ .g.from(y).add(x), new _hazae41_cubane__WEBPACK_IMPORTED_MODULE_14__/* .Fixed */ .g(0n, 0));
                            const totalQuery = Priced.schema(coin, storage);
                            await totalQuery.mutate(_libs_glacier_mutators__WEBPACK_IMPORTED_MODULE_2__/* .Mutators */ .g.data(total));
                        };
                        return (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_7__/* .createQuery */ .rP)({
                            key: Record.key(coin),
                            indexer,
                            storage
                        });
                    }
                    Record.schema = schema;
                })(Record = ByAddress.Record || (ByAddress.Record = {}));
                function key(address, coin) {
                    return "totalWalletPricedBalance/".concat(address, "/").concat(coin);
                }
                ByAddress.key = key;
                function schema(address, coin, storage) {
                    if (address == null) return;
                    const indexer = async (states)=>{
                        var _states_current_real_data, _states_current_real;
                        const indexQuery = Record.schema(coin, storage);
                        const value = _hazae41_option__WEBPACK_IMPORTED_MODULE_13__/* .Option */ .W.wrap((_states_current_real = states.current.real) === null || _states_current_real === void 0 ? void 0 : (_states_current_real_data = _states_current_real.data) === null || _states_current_real_data === void 0 ? void 0 : _states_current_real_data.get()).unwrapOr(new _hazae41_cubane__WEBPACK_IMPORTED_MODULE_14__/* .Fixed */ .g(0n, 0));
                        await indexQuery.mutate(_libs_glacier_mutators__WEBPACK_IMPORTED_MODULE_2__/* .Mutators */ .g.mapInnerData((p)=>({
                                ...p,
                                [address]: value
                            }), new _hazae41_glacier__WEBPACK_IMPORTED_MODULE_15__/* .Data */ .V({})));
                    };
                    return (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_7__/* .createQuery */ .rP)({
                        key: key(address, coin),
                        indexer,
                        storage
                    });
                }
                ByAddress.schema = schema;
            })(ByAddress = Priced.ByAddress || (Priced.ByAddress = {}));
            function key(coin) {
                return "totalPricedBalance/".concat(coin);
            }
            Priced.key = key;
            function schema(coin, storage) {
                return (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_7__/* .createQuery */ .rP)({
                    key: key(coin),
                    storage
                });
            }
            Priced.schema = schema;
        })(Priced = Balance.Priced || (Balance.Priced = {}));
    })(Balance = FgTotal.Balance || (FgTotal.Balance = {}));
})(FgTotal || (FgTotal = {}));
function useTotalPricedBalance(coin) {
    const storage = (0,_storage_user__WEBPACK_IMPORTED_MODULE_5__/* .useUserStorageContext */ .v6)().unwrap();
    const query = (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_8__/* .useQuery */ .aM)(FgTotal.Balance.Priced.schema, [
        coin,
        storage
    ]);
    (0,_storage_storage__WEBPACK_IMPORTED_MODULE_4__/* .useSubscribe */ .Q)(query, storage);
    return query;
}
function useTotalWalletPricedBalance(address, coin) {
    const storage = (0,_storage_user__WEBPACK_IMPORTED_MODULE_5__/* .useUserStorageContext */ .v6)().unwrap();
    const query = (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_8__/* .useQuery */ .aM)(FgTotal.Balance.Priced.ByAddress.schema, [
        address,
        coin,
        storage
    ]);
    (0,_storage_storage__WEBPACK_IMPORTED_MODULE_4__/* .useSubscribe */ .Q)(query, storage);
    return query;
}


/***/ }),

/***/ 4439:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  _: function() { return /* binding */ WalletCreatorDialog; }
});

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/EyeIcon.js
var EyeIcon = __webpack_require__(2940);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/WalletIcon.js
var WalletIcon = __webpack_require__(5066);
// EXTERNAL MODULE: ./src/libs/ui/button.tsx + 8 modules
var ui_button = __webpack_require__(1258);
// EXTERNAL MODULE: ./src/libs/ui/dialog/dialog.tsx
var dialog = __webpack_require__(3868);
// EXTERNAL MODULE: ./node_modules/react/index.js
var react = __webpack_require__(7294);
// EXTERNAL MODULE: ./src/libs/colors/colors.ts
var colors = __webpack_require__(7457);
// EXTERNAL MODULE: ./src/libs/emojis/emojis.ts
var emojis = __webpack_require__(33);
// EXTERNAL MODULE: ./src/libs/errors/errors.ts
var errors = __webpack_require__(9071);
// EXTERNAL MODULE: ./src/libs/ethereum/mods/chain.tsx
var chain = __webpack_require__(9408);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/PlusIcon.js
var PlusIcon = __webpack_require__(8680);
// EXTERNAL MODULE: ./src/libs/modhash/modhash.ts
var modhash_modhash = __webpack_require__(6652);
// EXTERNAL MODULE: ./src/libs/react/callback.tsx
var callback = __webpack_require__(7174);
// EXTERNAL MODULE: ./src/libs/react/events.ts
var events = __webpack_require__(4714);
// EXTERNAL MODULE: ./src/libs/react/ref.ts + 1 modules
var ref = __webpack_require__(5351);
// EXTERNAL MODULE: ./src/libs/results/results.ts
var results = __webpack_require__(421);
// EXTERNAL MODULE: ./src/libs/ui/input.tsx + 4 modules
var input = __webpack_require__(9619);
// EXTERNAL MODULE: ./src/libs/ui/textarea.tsx + 2 modules
var ui_textarea = __webpack_require__(9722);
// EXTERNAL MODULE: ./src/mods/foreground/background/context.tsx + 3 modules
var context = __webpack_require__(7028);
// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/types/address/index.mjs
var types_address = __webpack_require__(7657);
// EXTERNAL MODULE: ./node_modules/@hazae41/option/dist/esm/mods/option/option.mjs
var option_option = __webpack_require__(5316);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/result.mjs
var result = __webpack_require__(918);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/err.mjs
var err = __webpack_require__(166);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/errors.mjs
var result_errors = __webpack_require__(2564);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/ok.mjs
var ok = __webpack_require__(5591);
// EXTERNAL MODULE: ./src/mods/foreground/entities/names/data.ts + 2 modules
var data = __webpack_require__(1023);
// EXTERNAL MODULE: ./src/mods/foreground/entities/wallets/avatar.tsx
var avatar = __webpack_require__(9685);
// EXTERNAL MODULE: ./src/mods/foreground/entities/wallets/data.ts
var wallets_data = __webpack_require__(9031);
;// CONCATENATED MODULE: ./src/mods/foreground/entities/wallets/all/create/readonly.tsx























function ReadonlyWalletCreatorDialog(props) {
    var _ensAddressQuery_data;
    const close = (0,dialog/* useCloseContext */.gX)().unwrap();
    const background = (0,context/* useBackgroundContext */.D_)().unwrap();
    const uuid = (0,ref/* useConstant */.hS)(()=>crypto.randomUUID());
    const mainnet = (0,wallets_data/* useEthereumContext */.Kn)(uuid, chain/* chainByChainId */.DH[1]);
    const modhash = (0,modhash_modhash/* useModhash */.jR)(uuid);
    const color = colors/* Colors */.w.mod(modhash);
    const emoji = emojis/* Emojis */.A.get(modhash);
    const [rawNameInput = "", setRawNameInput] = (0,react.useState)();
    const defNameInput = (0,react.useDeferredValue)(rawNameInput);
    const onNameInputChange = (0,events/* useInputChange */.Xy)((e)=>{
        setRawNameInput(e.currentTarget.value);
    }, []);
    const [rawAddressInput = "", setRawAddressInput] = (0,react.useState)();
    const defAddressInput = (0,react.useDeferredValue)(rawAddressInput);
    const onAddressInputChange = (0,events/* useTextAreaChange */.aN)((e)=>{
        setRawAddressInput(e.currentTarget.value);
    }, []);
    const maybeEnsInput = defAddressInput.endsWith(".eth") ? defAddressInput : undefined;
    const ensAddressQuery = (0,data/* useEnsLookup */.aZ)(maybeEnsInput, mainnet);
    const maybeAddress = defAddressInput.endsWith(".eth") ? (_ensAddressQuery_data = ensAddressQuery.data) === null || _ensAddressQuery_data === void 0 ? void 0 : _ensAddressQuery_data.get() : defAddressInput;
    const tryAdd = (0,callback/* useAsyncUniqueCallback */.T)(async ()=>{
        return await result/* Result */.x.unthrow(async (t)=>{
            if (!defNameInput) return new err/* Err */.U(new result_errors/* Panic */.F5());
            const address = option_option/* Option */.W.wrap(maybeAddress).okOrElseSync(()=>{
                return new errors/* UIError */.m("Could not fetch or parse address");
            }).mapSync((x)=>types_address/* Address */.k.from(x)).throw(t);
            const wallet = {
                coin: "ethereum",
                type: "readonly",
                uuid,
                name: defNameInput,
                color,
                emoji,
                address
            };
            await background.tryRequest({
                method: "brume_createWallet",
                params: [
                    wallet
                ]
            }).then((r)=>r.throw(t).throw(t));
            close();
            return ok.Ok.void();
        }).then(results/* Results */.u.logAndAlert);
    }, [
        defNameInput,
        maybeAddress,
        uuid,
        color,
        emoji,
        background,
        close
    ]);
    const addDisabled = (0,react.useMemo)(()=>{
        if (tryAdd.loading) return "Loading...";
        if (!defNameInput) return "Please enter a name";
        if (!defAddressInput) return "Please enter an address";
        return undefined;
    }, [
        tryAdd.loading,
        defNameInput,
        defAddressInput
    ]);
    const NameInput = /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "flex items-stretch gap-2",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "shrink-0",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(avatar/* WalletAvatar */.G, {
                    className: "size-12 text-2xl",
                    colorIndex: color,
                    emoji: emoji
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)(input/* Input.Contrast */.I.mn, {
                className: "w-full",
                placeholder: "Enter a name",
                value: rawNameInput,
                onChange: onNameInputChange
            })
        ]
    });
    const AddressInput = /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_textarea/* Textarea.Contrast */.g.m, {
        className: "w-full resize-none",
        placeholder: "vitalik.eth",
        value: rawAddressInput,
        onChange: onAddressInputChange,
        rows: 4
    });
    const AddButon = /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.Gradient */.z.ph, {
        className: "grow po-md",
        colorIndex: color,
        disabled: Boolean(addDisabled),
        onClick: tryAdd.run,
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsx)(PlusIcon/* default */.Z, {
                    className: "size-5"
                }),
                addDisabled || "Add"
            ]
        })
    });
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Dialog */.Vq.Title, {
                close: close,
                children: "New wallet"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-2"
            }),
            NameInput,
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-8"
            }),
            AddressInput,
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-8"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "flex items-center flex-wrap-reverse gap-2",
                children: AddButon
            })
        ]
    });
}

// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/KeyIcon.js
var KeyIcon = __webpack_require__(9878);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/LockClosedIcon.js
var LockClosedIcon = __webpack_require__(6186);
// EXTERNAL MODULE: ./src/libs/react/memo.ts + 1 modules
var memo = __webpack_require__(2387);
// EXTERNAL MODULE: ./src/libs/webauthn/webauthn.ts
var webauthn = __webpack_require__(6177);
// EXTERNAL MODULE: ./node_modules/@hazae41/base16/dist/esm/src/mods/base16/adapter.mjs
var adapter = __webpack_require__(2248);
// EXTERNAL MODULE: ./node_modules/@hazae41/base64/dist/esm/src/mods/base64/adapter.mjs
var base64_adapter = __webpack_require__(9467);
// EXTERNAL MODULE: ./node_modules/@hazae41/bytes/dist/esm/mods/bytes/bytes.mjs + 3 modules
var bytes = __webpack_require__(1694);
// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/types/zerohex/index.mjs
var zerohex = __webpack_require__(6113);
// EXTERNAL MODULE: ./node_modules/@noble/curves/esm/secp256k1.js + 5 modules
var secp256k1 = __webpack_require__(7835);
;// CONCATENATED MODULE: ./src/mods/foreground/entities/wallets/all/create/standalone.tsx

var __addDisposableResource = undefined && undefined.__addDisposableResource || function(env, value, async) {
    if (value !== null && value !== void 0) {
        if (typeof value !== "object" && typeof value !== "function") throw new TypeError("Object expected.");
        var dispose;
        if (async) {
            if (!Symbol.asyncDispose) throw new TypeError("Symbol.asyncDispose is not defined.");
            dispose = value[Symbol.asyncDispose];
        }
        if (dispose === void 0) {
            if (!Symbol.dispose) throw new TypeError("Symbol.dispose is not defined.");
            dispose = value[Symbol.dispose];
        }
        if (typeof dispose !== "function") throw new TypeError("Object not disposable.");
        env.stack.push({
            value: value,
            dispose: dispose,
            async: async
        });
    } else if (async) {
        env.stack.push({
            async: true
        });
    }
    return value;
};
var __disposeResources = undefined && undefined.__disposeResources || function(SuppressedError1) {
    return function(env) {
        function fail(e) {
            env.error = env.hasError ? new SuppressedError1(e, env.error, "An error was suppressed during disposal.") : e;
            env.hasError = true;
        }
        function next() {
            while(env.stack.length){
                var rec = env.stack.pop();
                try {
                    var result = rec.dispose && rec.dispose.call(rec.value);
                    if (rec.async) return Promise.resolve(result).then(next, function(e) {
                        fail(e);
                        return next();
                    });
                } catch (e) {
                    fail(e);
                }
            }
            if (env.hasError) throw env.error;
        }
        return next();
    };
}(typeof SuppressedError === "function" ? SuppressedError : function(error, suppressed, message) {
    var e = new Error(message);
    return e.name = "SuppressedError", e.error = error, e.suppressed = suppressed, e;
});























function StandaloneWalletCreatorDialog(props) {
    const close = (0,dialog/* useCloseContext */.gX)().unwrap();
    const background = (0,context/* useBackgroundContext */.D_)().unwrap();
    const uuid = (0,ref/* useConstant */.hS)(()=>crypto.randomUUID());
    const modhash = (0,modhash_modhash/* useModhash */.jR)(uuid);
    const color = colors/* Colors */.w.mod(modhash);
    const emoji = emojis/* Emojis */.A.get(modhash);
    const [rawNameInput = "", setRawNameInput] = (0,react.useState)();
    const defNameInput = (0,react.useDeferredValue)(rawNameInput);
    const onNameInputChange = (0,events/* useInputChange */.Xy)((e)=>{
        setRawNameInput(e.currentTarget.value);
    }, []);
    const [rawKeyInput = "", setRawKeyInput] = (0,react.useState)();
    const defKeyInput = (0,react.useDeferredValue)(rawKeyInput);
    const zeroHexKey = zerohex/* ZeroHexString */.T.from(defKeyInput);
    const onKeyInputChange = (0,events/* useTextAreaChange */.aN)((e)=>{
        setRawKeyInput(e.currentTarget.value);
    }, []);
    const doGenerate = (0,callback/* useAsyncUniqueCallback */.T)(async ()=>{
        const bytes = secp256k1/* secp256k1 */.kA.utils.randomPrivateKey();
        setRawKeyInput("0x".concat(adapter/* get */.U().tryEncode(bytes).unwrap()));
    }, []);
    const tryAddUnauthenticated = (0,callback/* useAsyncUniqueCallback */.T)(async ()=>{
        return await result/* Result */.x.unthrow(async (t)=>{
            if (!defNameInput) return new err/* Err */.U(new result_errors/* Panic */.F5());
            if (!secp256k1/* secp256k1 */.kA.utils.isValidPrivateKey(zeroHexKey.slice(2))) return new err/* Err */.U(new result_errors/* Panic */.F5());
            if (!confirm("Did you backup your private key?")) return ok.Ok.void();
            const privateKeyBytes = adapter/* get */.U().tryPadStartAndDecode(zeroHexKey.slice(2)).throw(t).copyAndDispose();
            // TODO: use adapter
            const uncompressedPublicKeyBytes = secp256k1/* secp256k1 */.kA.getPublicKey(privateKeyBytes, false);
            // const compressedPublicKeyBytes = secp256k1.getPublicKey(privateKeyBytes, true)
            const address = types_address/* Address */.k.compute(uncompressedPublicKeyBytes);
            // const uncompressedBitcoinAddress = await Bitcoin.Address.from(uncompressedPublicKeyBytes)
            // const compressedBitcoinAddress = await Bitcoin.Address.from(compressedPublicKeyBytes)
            const wallet = {
                coin: "ethereum",
                type: "privateKey",
                uuid,
                name: defNameInput,
                color,
                emoji,
                address,
                privateKey: zeroHexKey
            };
            await background.tryRequest({
                method: "brume_createWallet",
                params: [
                    wallet
                ]
            }).then((r)=>r.throw(t).throw(t));
            close();
            return ok.Ok.void();
        }).then(results/* Results */.u.logAndAlert);
    }, [
        defNameInput,
        zeroHexKey,
        uuid,
        color,
        emoji,
        background,
        close
    ]);
    const triedEncryptedPrivateKey = (0,memo/* useAsyncReplaceMemo */.EY)(async ()=>{
        return await result/* Result */.x.unthrow(async (t)=>{
            const env_1 = {
                stack: [],
                error: void 0,
                hasError: false
            };
            try {
                if (!defNameInput) return new err/* Err */.U(new result_errors/* Panic */.F5());
                if (!secp256k1/* secp256k1 */.kA.utils.isValidPrivateKey(zeroHexKey.slice(2))) return new err/* Err */.U(new result_errors/* Panic */.F5());
                const privateKeyMemory = __addDisposableResource(env_1, adapter/* get */.U().tryPadStartAndDecode(zeroHexKey.slice(2)).throw(t), false);
                const privateKeyBase64 = base64_adapter/* get */.U().tryEncodePadded(privateKeyMemory).throw(t);
                const [ivBase64, cipherBase64] = await background.tryRequest({
                    method: "brume_encrypt",
                    params: [
                        privateKeyBase64
                    ]
                }).then((r)=>r.throw(t).throw(t));
                return new ok.Ok([
                    ivBase64,
                    cipherBase64
                ]);
            } catch (e_1) {
                env_1.error = e_1;
                env_1.hasError = true;
            } finally{
                __disposeResources(env_1);
            }
        });
    }, [
        defNameInput,
        zeroHexKey,
        background
    ]);
    const [id, setId] = (0,react.useState)();
    (0,react.useEffect)(()=>{
        setId(undefined);
    }, [
        zeroHexKey
    ]);
    const tryAddAuthenticated1 = (0,callback/* useAsyncUniqueCallback */.T)(async ()=>{
        return await result/* Result */.x.unthrow(async (t)=>{
            if (!defNameInput) return new err/* Err */.U(new result_errors/* Panic */.F5());
            if (!secp256k1/* secp256k1 */.kA.utils.isValidPrivateKey(zeroHexKey.slice(2))) return new err/* Err */.U(new result_errors/* Panic */.F5());
            if (triedEncryptedPrivateKey == null) return new err/* Err */.U(new result_errors/* Panic */.F5());
            if (!confirm("Did you backup your private key?")) return ok.Ok.void();
            const [_, cipherBase64] = triedEncryptedPrivateKey.throw(t);
            const cipher = base64_adapter/* get */.U().tryDecodePadded(cipherBase64).throw(t).copyAndDispose();
            const id = await webauthn/* WebAuthnStorage */.g.tryCreate(defNameInput, cipher).then((r)=>r.throw(t));
            setId(id);
            return ok.Ok.void();
        }).then(results/* Results */.u.logAndAlert);
    }, [
        defNameInput,
        zeroHexKey,
        triedEncryptedPrivateKey,
        uuid,
        color,
        emoji,
        background
    ]);
    const tryAddAuthenticated2 = (0,callback/* useAsyncUniqueCallback */.T)(async ()=>{
        return await result/* Result */.x.unthrow(async (t)=>{
            if (!defNameInput) return new err/* Err */.U(new result_errors/* Panic */.F5());
            if (!secp256k1/* secp256k1 */.kA.utils.isValidPrivateKey(zeroHexKey.slice(2))) return new err/* Err */.U(new result_errors/* Panic */.F5());
            if (id == null) return new err/* Err */.U(new result_errors/* Panic */.F5());
            if (triedEncryptedPrivateKey == null) return new err/* Err */.U(new result_errors/* Panic */.F5());
            const privateKeyBytes = adapter/* get */.U().tryPadStartAndDecode(zeroHexKey.slice(2)).throw(t).copyAndDispose();
            const uncompressedPublicKeyBytes = secp256k1/* secp256k1 */.kA.getPublicKey(privateKeyBytes, false);
            // const compressedPublicKeyBytes = secp256k1.getPublicKey(privateKeyBytes, true)
            const address = types_address/* Address */.k.compute(uncompressedPublicKeyBytes);
            // const uncompressedBitcoinAddress = await Bitcoin.Address.from(uncompressedPublicKeyBytes)
            // const compressedBitcoinAddress = await Bitcoin.Address.from(compressedPublicKeyBytes)
            const [ivBase64, cipherBase64] = triedEncryptedPrivateKey.throw(t);
            const cipher = base64_adapter/* get */.U().tryDecodePadded(cipherBase64).throw(t).copyAndDispose();
            const cipher2 = await webauthn/* WebAuthnStorage */.g.tryGet(id).then((r)=>r.throw(t));
            if (!bytes/* Bytes */.J.equals(cipher, cipher2)) return new err/* Err */.U(new webauthn/* WebAuthnStorageError */.$());
            const idBase64 = base64_adapter/* get */.U().tryEncodePadded(id).throw(t);
            const privateKey = {
                ivBase64,
                idBase64
            };
            const wallet = {
                coin: "ethereum",
                type: "authPrivateKey",
                uuid,
                name: defNameInput,
                color,
                emoji,
                address,
                privateKey
            };
            await background.tryRequest({
                method: "brume_createWallet",
                params: [
                    wallet
                ]
            }).then((r)=>r.throw(t).throw(t));
            close();
            return ok.Ok.void();
        }).then(results/* Results */.u.logAndAlert);
    }, [
        defNameInput,
        zeroHexKey,
        id,
        triedEncryptedPrivateKey,
        uuid,
        color,
        emoji,
        background,
        close
    ]);
    const NameInput = /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "flex items-stretch gap-2",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "shrink-0",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(avatar/* WalletAvatar */.G, {
                    className: "size-12 text-2xl",
                    colorIndex: color,
                    emoji: emoji
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)(input/* Input.Contrast */.I.mn, {
                className: "w-full",
                placeholder: "Enter a name",
                value: rawNameInput,
                onChange: onNameInputChange
            })
        ]
    });
    const KeyInput = /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_textarea/* Textarea.Contrast */.g.m, {
        className: "w-full resize-none",
        placeholder: "Enter your private key",
        value: rawKeyInput,
        onChange: onKeyInputChange,
        rows: 4
    });
    const GenerateButton = /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.Contrast */.z.mn, {
        className: "flex-1 whitespace-nowrap po-md",
        onClick: doGenerate.run,
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsx)(KeyIcon/* default */.Z, {
                    className: "size-5"
                }),
                "Generate a private key"
            ]
        })
    });
    const canAdd = (0,react.useMemo)(()=>{
        if (!defNameInput) return false;
        if (!secp256k1/* secp256k1 */.kA.utils.isValidPrivateKey(zeroHexKey.slice(2))) return false;
        return true;
    }, [
        defNameInput,
        zeroHexKey
    ]);
    const AddUnauthButton = /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.Contrast */.z.mn, {
        className: "flex-1 whitespace-nowrap po-md",
        disabled: !canAdd,
        onClick: tryAddUnauthenticated.run,
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsx)(PlusIcon/* default */.Z, {
                    className: "size-5"
                }),
                "Add without authentication"
            ]
        })
    });
    const AddAuthButton1 = /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.Gradient */.z.ph, {
        className: "flex-1 whitespace-nowrap po-md",
        colorIndex: color,
        disabled: !canAdd,
        onClick: tryAddAuthenticated1.run,
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsx)(LockClosedIcon/* default */.Z, {
                    className: "size-5"
                }),
                "Add with authentication"
            ]
        })
    });
    const AddAuthButton2 = /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.Gradient */.z.ph, {
        className: "flex-1 whitespace-nowrap po-md",
        colorIndex: color,
        disabled: !canAdd,
        onClick: tryAddAuthenticated2.run,
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsx)(LockClosedIcon/* default */.Z, {
                    className: "size-5"
                }),
                "Add with authentication (1/2)"
            ]
        })
    });
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Dialog */.Vq.Title, {
                close: close,
                children: "New wallet"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-2"
            }),
            NameInput,
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-8"
            }),
            KeyInput,
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "flex items-center flex-wrap-reverse gap-2",
                children: GenerateButton
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-8"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "flex items-center flex-wrap-reverse gap-2",
                children: [
                    AddUnauthButton,
                    id == null ? AddAuthButton1 : AddAuthButton2
                ]
            })
        ]
    });
}

;// CONCATENATED MODULE: ./src/mods/foreground/entities/wallets/all/create/index.tsx







function WalletCreatorDialog(props) {
    const close = (0,dialog/* useCloseContext */.gX)().unwrap();
    const [type, setType] = (0,react.useState)();
    const onWatchonlyClick = (0,react.useCallback)(()=>{
        setType("readonly");
    }, []);
    const onPrivateKeyClick = (0,react.useCallback)(()=>{
        setType("privateKey");
    }, []);
    const onClose = (0,react.useCallback)(()=>{
        setType(undefined);
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            type === "readonly" && /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Dialog */.Vq, {
                close: onClose,
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(ReadonlyWalletCreatorDialog, {})
            }),
            type === "privateKey" && /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Dialog */.Vq, {
                close: onClose,
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(StandaloneWalletCreatorDialog, {})
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Dialog */.Vq.Title, {
                close: close,
                children: "New wallet"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-2"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "w-full flex items-center gap-2",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.Contrast */.z.mn, {
                        className: "flex-1 whitespace-nowrap p-4 rounded-xl",
                        onClick: onWatchonlyClick,
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "".concat(ui_button/* Button.Shrinker */.z.Np.className, " flex-col"),
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)(EyeIcon/* default */.Z, {
                                    className: "size-6"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                    children: "Watch-only"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.Contrast */.z.mn, {
                        className: "flex-1 whitespace-nowrap p-4 rounded-xl",
                        onClick: onPrivateKeyClick,
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "".concat(ui_button/* Button.Shrinker */.z.Np.className, " flex-col"),
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)(WalletIcon/* default */.Z, {
                                    className: "size-6"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                    children: "Private key"
                                })
                            ]
                        })
                    })
                ]
            })
        ]
    });
}


/***/ }),

/***/ 882:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FU: function() { return /* binding */ WalletsPage; },
/* harmony export */   Y7: function() { return /* binding */ SelectableWalletGrid; },
/* harmony export */   oS: function() { return /* binding */ ClickableWalletGrid; }
/* harmony export */ });
/* unused harmony exports CheckableWalletDataCard, ClickableWalletDataCard, NewWalletCard */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _libs_icons_icons__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(8680);
/* harmony import */ var _libs_react_handles_boolean__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5902);
/* harmony import */ var _libs_ui_button__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1258);
/* harmony import */ var _libs_ui_dialog_dialog__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3868);
/* harmony import */ var _libs_ui2_page_header__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1952);
/* harmony import */ var _libs_ui2_page_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3365);
/* harmony import */ var _mods_foreground_router_path_context__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7921);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7294);
/* harmony import */ var _card__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9475);
/* harmony import */ var _context__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5807);
/* harmony import */ var _data__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9031);
/* harmony import */ var _create__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4439);
/* eslint-disable @next/next/no-img-element */ 












function WalletsPage() {
    var _walletsQuery_data;
    const { go } = (0,_mods_foreground_router_path_context__WEBPACK_IMPORTED_MODULE_6__/* .usePathContext */ .td)().unwrap();
    const walletsQuery = (0,_data__WEBPACK_IMPORTED_MODULE_10__/* .useWallets */ .rB)();
    const maybeWallets = (_walletsQuery_data = walletsQuery.data) === null || _walletsQuery_data === void 0 ? void 0 : _walletsQuery_data.get();
    const creator = (0,_libs_react_handles_boolean__WEBPACK_IMPORTED_MODULE_1__/* .useBooleanHandle */ .x)(false);
    const onWalletClick = (0,react__WEBPACK_IMPORTED_MODULE_7__.useCallback)((wallet)=>{
        go("/wallet/".concat(wallet.uuid));
    }, [
        go
    ]);
    const Body = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_libs_ui2_page_header__WEBPACK_IMPORTED_MODULE_4__/* .PageBody */ .xV, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(ClickableWalletGrid, {
            ok: onWalletClick,
            create: creator.enable,
            wallets: maybeWallets
        })
    });
    const Header = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_libs_ui2_page_header__WEBPACK_IMPORTED_MODULE_4__/* .UserPageHeader */ .To, {
                title: "Wallets",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_libs_ui_button__WEBPACK_IMPORTED_MODULE_2__/* .Button.Base */ .z.XY, {
                    className: "size-8 hovered-or-clicked-or-focused:scale-105 !transition",
                    onClick: creator.enable,
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: "".concat(_libs_ui_button__WEBPACK_IMPORTED_MODULE_2__/* .Button.Shrinker */ .z.Np.className),
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_libs_icons_icons__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                            className: "size-5"
                        })
                    })
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "po-md flex items-center",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                    className: "text-contrast",
                    children: "Wallets allow you to hold funds and generate signatures. You can import wallets from a private key or generate them from a seed."
                })
            })
        ]
    });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_libs_ui2_page_page__WEBPACK_IMPORTED_MODULE_5__/* .Page */ .T, {
        children: [
            creator.current && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_libs_ui_dialog_dialog__WEBPACK_IMPORTED_MODULE_3__/* .Dialog */ .Vq, {
                close: creator.disable,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_create__WEBPACK_IMPORTED_MODULE_11__/* .WalletCreatorDialog */ ._, {})
            }),
            Header,
            Body
        ]
    });
}
function ClickableWalletGrid(props) {
    const { wallets, ok, create } = props;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "grid grow place-content-start gap-2 grid-cols-[repeat(auto-fill,minmax(10rem,1fr))]",
        children: [
            wallets === null || wallets === void 0 ? void 0 : wallets.map((wallet)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_context__WEBPACK_IMPORTED_MODULE_9__/* .WalletDataProvider */ .lp, {
                    uuid: wallet.uuid,
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(ClickableWalletDataCard, {
                        ok: ok
                    })
                }, wallet.uuid)),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(NewWalletCard, {
                ok: create
            })
        ]
    });
}
function SelectableWalletGrid(props) {
    const { wallets, ok, create, selecteds } = props;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "grid grow place-content-start gap-2 grid-cols-[repeat(auto-fill,minmax(10rem,1fr))]",
        children: [
            wallets === null || wallets === void 0 ? void 0 : wallets.map((wallet)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(CheckableWalletDataCard, {
                    wallet: wallet,
                    index: selecteds.indexOf(wallet),
                    ok: ok
                }, wallet.uuid)),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(NewWalletCard, {
                ok: create
            })
        ]
    });
}
function CheckableWalletDataCard(props) {
    const { wallet, ok, index } = props;
    const checked = index !== -1;
    const onClick = (0,react__WEBPACK_IMPORTED_MODULE_7__.useCallback)(()=>{
        ok(wallet);
    }, [
        ok,
        wallet
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        className: "w-full aspect-video rounded-xl overflow-hidden cursor-pointer aria-checked:outline aria-checked:outline-2 aria-checked:outline-blue-600 animate-vibrate-loop",
        role: "checkbox",
        "aria-checked": checked,
        onClick: onClick,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_context__WEBPACK_IMPORTED_MODULE_9__/* .WalletDataProvider */ .lp, {
            uuid: wallet.uuid,
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_card__WEBPACK_IMPORTED_MODULE_8__/* .WalletDataCard */ .e, {
                index: index
            })
        })
    });
}
function ClickableWalletDataCard(props) {
    const wallet = (0,_context__WEBPACK_IMPORTED_MODULE_9__/* .useWalletDataContext */ .zI)().unwrap();
    const { ok } = props;
    const onClick = (0,react__WEBPACK_IMPORTED_MODULE_7__.useCallback)(()=>{
        ok(wallet);
    }, [
        ok,
        wallet
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        className: "w-full aspect-video rounded-xl overflow-hidden cursor-pointer hovered-or-clicked-or-focused:scale-105 !transition-transform",
        role: "button",
        onClick: onClick,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_card__WEBPACK_IMPORTED_MODULE_8__/* .WalletDataCard */ .e, {})
    });
}
function NewWalletCard(props) {
    const { ok } = props;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
        className: "po-md w-full aspect-video rounded-xl flex gap-2 justify-center items-center border border-contrast border-dashed hovered-or-clicked-or-focused:scale-105 !transition-transform",
        onClick: ok,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_libs_icons_icons__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                className: "size-5"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "font-medium",
                children: "New wallet"
            })
        ]
    });
}


/***/ }),

/***/ 9685:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   G: function() { return /* binding */ WalletAvatar; },
/* harmony export */   o: function() { return /* binding */ WalletIcon; }
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _libs_colors_colors__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7457);


function WalletIcon(props) {
    const { emoji, className } = props;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
        className: className,
        children: emoji
    });
}
function WalletAvatar(props) {
    const { colorIndex: color, emoji, className } = props;
    const [color1, color2] = _libs_colors_colors__WEBPACK_IMPORTED_MODULE_1__/* .Gradients */ .R.get(color);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        className: "bg-gradient-to-br from-".concat(color1, " to-").concat(color2, " rounded-full flex justify-center items-center ").concat(className),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(WalletIcon, {
            className: "",
            emoji: emoji
        })
    });
}


/***/ }),

/***/ 9475:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   T: function() { return /* binding */ SimpleWalletDataCard; },
/* harmony export */   e: function() { return /* binding */ WalletDataCard; }
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _libs_colors_colors__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7457);
/* harmony import */ var _libs_copy_copy__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2306);
/* harmony import */ var _libs_ethereum_mods_chain__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9408);
/* harmony import */ var _libs_icons_icons__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(6812);
/* harmony import */ var _libs_react_events__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4714);
/* harmony import */ var _libs_ui_button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1258);
/* harmony import */ var _hazae41_cubane__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(7657);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7294);
/* harmony import */ var _names_data__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1023);
/* harmony import */ var _unknown_data__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5234);
/* harmony import */ var _avatar__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9685);
/* harmony import */ var _context__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5807);
/* harmony import */ var _data__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(9031);
/* harmony import */ var _page__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(7019);















function SimpleWalletDataCard() {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        className: "w-full aspect-video rounded-xl overflow-hidden",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(WalletDataCard, {})
    });
}
function WalletDataCard(props) {
    var _ens_data, _ens_data1;
    const wallet = (0,_context__WEBPACK_IMPORTED_MODULE_10__/* .useWalletDataContext */ .zI)().unwrap();
    const { index } = props;
    const mainnet = (0,_data__WEBPACK_IMPORTED_MODULE_11__/* .useEthereumContext */ .Kn)(wallet.uuid, _libs_ethereum_mods_chain__WEBPACK_IMPORTED_MODULE_3__/* .chainByChainId */ .DH[1]);
    const ens = (0,_names_data__WEBPACK_IMPORTED_MODULE_7__/* .useEnsReverseNoFetch */ .yh)(wallet.address, mainnet);
    const [color, color2] = _libs_colors_colors__WEBPACK_IMPORTED_MODULE_1__/* .Gradients */ .R.get(wallet.color);
    const onClickEllipsis = (0,_libs_react_events__WEBPACK_IMPORTED_MODULE_4__/* .useMouseCancel */ .I$)((e)=>{
    // TODO
    }, []);
    const address = (0,react__WEBPACK_IMPORTED_MODULE_6__.useMemo)(()=>{
        return _hazae41_cubane__WEBPACK_IMPORTED_MODULE_13__/* .Address */ .k.from(wallet.address);
    }, [
        wallet.address
    ]);
    var _ens_data_get;
    const ensOrAddress = (_ens_data_get = (_ens_data = ens.data) === null || _ens_data === void 0 ? void 0 : _ens_data.get()) !== null && _ens_data_get !== void 0 ? _ens_data_get : address;
    var _ens_data_get1;
    const ensOrAddressDisplay = (_ens_data_get1 = (_ens_data1 = ens.data) === null || _ens_data1 === void 0 ? void 0 : _ens_data1.get()) !== null && _ens_data_get1 !== void 0 ? _ens_data_get1 : _hazae41_cubane__WEBPACK_IMPORTED_MODULE_13__/* .Address */ .k.format(address);
    const copyEthereumAddress = (0,_libs_copy_copy__WEBPACK_IMPORTED_MODULE_2__/* .useCopy */ .F)(ensOrAddress);
    const onClickCopyEthereumAddress = (0,_libs_react_events__WEBPACK_IMPORTED_MODULE_4__/* .useMouseCancel */ .I$)(copyEthereumAddress.run);
    const totalBalanceQuery = (0,_unknown_data__WEBPACK_IMPORTED_MODULE_8__/* .useTotalWalletPricedBalance */ .h7)(wallet.address, "usd");
    const totalBalanceDisplay = (0,_page__WEBPACK_IMPORTED_MODULE_12__/* .useCompactDisplayUsd */ .jJ)(totalBalanceQuery.current);
    const First = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex items-center",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "shrink-0",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_avatar__WEBPACK_IMPORTED_MODULE_9__/* .WalletIcon */ .o, {
                    className: "text-xl",
                    emoji: wallet.emoji
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "w-2 grow"
            }),
            index == null && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", {
                className: "".concat(_libs_ui_button__WEBPACK_IMPORTED_MODULE_5__/* .Button.Base */ .z.XY.className, " ").concat(_libs_ui_button__WEBPACK_IMPORTED_MODULE_5__/* .Button.White */ .z.Ej.className, " text-").concat(color),
                onClick: onClickEllipsis,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                    className: "".concat(_libs_ui_button__WEBPACK_IMPORTED_MODULE_5__/* .Button.Shrinker */ .z.Np.className),
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_libs_icons_icons__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                        className: "size-5"
                    })
                })
            }),
            index != null && index !== -1 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "border-2 border-white flex items-center justify-center rounded-full overflow-hidden",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                    className: "bg-blue-600 flex items-center justify-center size-5 text-white font-medium",
                    children: index + 1
                })
            }),
            index != null && index === -1 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "border-2 border-contrast flex items-center justify-center rounded-full",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                    className: "size-5"
                })
            })
        ]
    });
    const Name = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex items-center text-white font-medium",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "truncate",
                children: wallet.name
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "w-2 grow"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "font-base text-white-high-contrast",
                children: totalBalanceDisplay
            })
        ]
    });
    const AddressDisplay = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex justify-between items-center text-sm",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "text-white-high-contrast",
                children: "ETH"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "cursor-pointer text-white-high-contrast",
                onClick: onClickCopyEthereumAddress,
                children: copyEthereumAddress.current ? "Copied" : ensOrAddressDisplay
            })
        ]
    });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "po-md w-full h-full flex flex-col text-white bg-gradient-to-br from-".concat(color, " to-").concat(color2),
        children: [
            First,
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "grow"
            }),
            Name,
            AddressDisplay
        ]
    });
}


/***/ }),

/***/ 5807:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   lp: function() { return /* binding */ WalletDataProvider; },
/* harmony export */   zI: function() { return /* binding */ useWalletDataContext; }
/* harmony export */ });
/* unused harmony export WalletDataContext */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _hazae41_option__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5316);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7294);
/* harmony import */ var _data__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9031);




const WalletDataContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)(undefined);
function useWalletDataContext() {
    return _hazae41_option__WEBPACK_IMPORTED_MODULE_3__/* .Option */ .W.wrap((0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(WalletDataContext));
}
function WalletDataProvider(props) {
    const { uuid, children } = props;
    const wallet = (0,_data__WEBPACK_IMPORTED_MODULE_2__/* .useWallet */ .Os)(uuid);
    if (wallet.data == null) return null;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(WalletDataContext.Provider, {
        value: wallet.data.get(),
        children: children
    });
}


/***/ }),

/***/ 9031:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   IL: function() { return /* binding */ useEthereumContext2; },
/* harmony export */   Kn: function() { return /* binding */ useEthereumContext; },
/* harmony export */   Ky: function() { return /* binding */ customFetchOrFail; },
/* harmony export */   Os: function() { return /* binding */ useWallet; },
/* harmony export */   QB: function() { return /* binding */ useWalletsBySeed; },
/* harmony export */   Vy: function() { return /* binding */ EthereumWalletInstance; },
/* harmony export */   rB: function() { return /* binding */ useWallets; },
/* harmony export */   yR: function() { return /* binding */ fetchOrFail; }
/* harmony export */ });
/* unused harmony exports FgWallet, EthereumSeededWalletInstance, EthereumUnauthPrivateKeyWalletInstance, EthereumAuthPrivateKeyWalletInstance */
/* harmony import */ var _libs_glacier_mutators__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2457);
/* harmony import */ var _libs_webauthn_webauthn__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6177);
/* harmony import */ var _mods_background_service_worker_entities_wallets_data__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6340);
/* harmony import */ var _hazae41_base16__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(2248);
/* harmony import */ var _hazae41_base64__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(9467);
/* harmony import */ var _hazae41_glacier__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6233);
/* harmony import */ var _hazae41_glacier__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8123);
/* harmony import */ var _hazae41_glacier__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(564);
/* harmony import */ var _hazae41_glacier__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(1458);
/* harmony import */ var _hazae41_option__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(5316);
/* harmony import */ var _hazae41_result__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(2564);
/* harmony import */ var _hazae41_result__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(918);
/* harmony import */ var _hazae41_result__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(5591);
/* harmony import */ var ethers__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(8884);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7294);
/* harmony import */ var _background_context__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7028);
/* harmony import */ var _storage_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(921);
/* harmony import */ var _storage_user__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8777);
/* harmony import */ var _seeds_all_helpers__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7554);
/* harmony import */ var _seeds_data__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1075);
var __addDisposableResource = undefined && undefined.__addDisposableResource || function(env, value, async) {
    if (value !== null && value !== void 0) {
        if (typeof value !== "object" && typeof value !== "function") throw new TypeError("Object expected.");
        var dispose;
        if (async) {
            if (!Symbol.asyncDispose) throw new TypeError("Symbol.asyncDispose is not defined.");
            dispose = value[Symbol.asyncDispose];
        }
        if (dispose === void 0) {
            if (!Symbol.dispose) throw new TypeError("Symbol.dispose is not defined.");
            dispose = value[Symbol.dispose];
        }
        if (typeof dispose !== "function") throw new TypeError("Object not disposable.");
        env.stack.push({
            value: value,
            dispose: dispose,
            async: async
        });
    } else if (async) {
        env.stack.push({
            async: true
        });
    }
    return value;
};
var __disposeResources = undefined && undefined.__disposeResources || function(SuppressedError1) {
    return function(env) {
        function fail(e) {
            env.error = env.hasError ? new SuppressedError1(e, env.error, "An error was suppressed during disposal.") : e;
            env.hasError = true;
        }
        function next() {
            while(env.stack.length){
                var rec = env.stack.pop();
                try {
                    var result = rec.dispose && rec.dispose.call(rec.value);
                    if (rec.async) return Promise.resolve(result).then(next, function(e) {
                        fail(e);
                        return next();
                    });
                } catch (e) {
                    fail(e);
                }
            }
            if (env.hasError) throw env.error;
        }
        return next();
    };
}(typeof SuppressedError === "function" ? SuppressedError : function(error, suppressed, message) {
    var e = new Error(message);
    return e.name = "SuppressedError", e.error = error, e.suppressed = suppressed, e;
});















var FgWallet;
(function(FgWallet) {
    let All;
    (function(All) {
        let BySeed;
        (function(BySeed) {
            BySeed.key = _mods_background_service_worker_entities_wallets_data__WEBPACK_IMPORTED_MODULE_2__/* .BgWallet */ .U.All.BySeed.key;
            function schema(uuid, storage) {
                if (uuid == null) return;
                return (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_9__/* .createQuery */ .rP)({
                    key: BySeed.key(uuid),
                    storage
                });
            }
            BySeed.schema = schema;
        })(BySeed = All.BySeed || (All.BySeed = {}));
        All.key = _mods_background_service_worker_entities_wallets_data__WEBPACK_IMPORTED_MODULE_2__/* .BgWallet */ .U.All.key;
        function schema(storage) {
            return (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_9__/* .createQuery */ .rP)({
                key: All.key,
                storage
            });
        }
        All.schema = schema;
    })(All = FgWallet.All || (FgWallet.All = {}));
    FgWallet.key = _mods_background_service_worker_entities_wallets_data__WEBPACK_IMPORTED_MODULE_2__/* .BgWallet */ .U.key;
    function schema(uuid, storage) {
        if (uuid == null) return;
        const indexer = async (states)=>{
            var _previous_real, _current_real;
            const { current, previous = current } = states;
            const previousData = (_previous_real = previous.real) === null || _previous_real === void 0 ? void 0 : _previous_real.data;
            const currentData = (_current_real = current.real) === null || _current_real === void 0 ? void 0 : _current_real.data;
            await All.schema(storage).mutate(_libs_glacier_mutators__WEBPACK_IMPORTED_MODULE_0__/* .Mutators */ .g.mapData(function() {
                let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : new _hazae41_glacier__WEBPACK_IMPORTED_MODULE_10__/* .Data */ .V([]);
                if ((previousData === null || previousData === void 0 ? void 0 : previousData.inner.uuid) === (currentData === null || currentData === void 0 ? void 0 : currentData.inner.uuid)) return d;
                if (previousData != null) d = d.mapSync((p)=>p.filter((x)=>x.uuid !== previousData.inner.uuid));
                if (currentData != null) d = d.mapSync((p)=>[
                        ...p,
                        _mods_background_service_worker_entities_wallets_data__WEBPACK_IMPORTED_MODULE_2__/* .WalletRef */ .V.from(currentData.inner)
                    ]);
                return d;
            }));
            if ((currentData === null || currentData === void 0 ? void 0 : currentData.inner.type) === "seeded") {
                const { seed } = currentData.inner;
                const walletsBySeedQuery = All.BySeed.schema(seed.uuid, storage);
                await (walletsBySeedQuery === null || walletsBySeedQuery === void 0 ? void 0 : walletsBySeedQuery.mutate(_libs_glacier_mutators__WEBPACK_IMPORTED_MODULE_0__/* .Mutators */ .g.mapData(function() {
                    let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : new _hazae41_glacier__WEBPACK_IMPORTED_MODULE_10__/* .Data */ .V([]);
                    if ((previousData === null || previousData === void 0 ? void 0 : previousData.inner.uuid) === (currentData === null || currentData === void 0 ? void 0 : currentData.inner.uuid)) return d;
                    if (previousData != null) d = d.mapSync((p)=>p.filter((x)=>x.uuid !== previousData.inner.uuid));
                    if (currentData != null) d = d.mapSync((p)=>[
                            ...p,
                            _mods_background_service_worker_entities_wallets_data__WEBPACK_IMPORTED_MODULE_2__/* .WalletRef */ .V.from(currentData.inner)
                        ]);
                    return d;
                })));
            }
        };
        return (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_9__/* .createQuery */ .rP)({
            key: FgWallet.key(uuid),
            indexer,
            storage
        });
    }
    FgWallet.schema = schema;
})(FgWallet || (FgWallet = {}));
function useWallet(uuid) {
    const storage = (0,_storage_user__WEBPACK_IMPORTED_MODULE_6__/* .useUserStorageContext */ .v6)().unwrap();
    const query = (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_11__/* .useQuery */ .aM)(FgWallet.schema, [
        uuid,
        storage
    ]);
    (0,_storage_storage__WEBPACK_IMPORTED_MODULE_5__/* .useSubscribe */ .Q)(query, storage);
    return query;
}
function useWallets() {
    const storage = (0,_storage_user__WEBPACK_IMPORTED_MODULE_6__/* .useUserStorageContext */ .v6)().unwrap();
    const query = (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_11__/* .useQuery */ .aM)(FgWallet.All.schema, [
        storage
    ]);
    (0,_storage_storage__WEBPACK_IMPORTED_MODULE_5__/* .useSubscribe */ .Q)(query, storage);
    return query;
}
function useWalletsBySeed(uuid) {
    const storage = (0,_storage_user__WEBPACK_IMPORTED_MODULE_6__/* .useUserStorageContext */ .v6)().unwrap();
    const query = (0,_hazae41_glacier__WEBPACK_IMPORTED_MODULE_11__/* .useQuery */ .aM)(FgWallet.All.BySeed.schema, [
        uuid,
        storage
    ]);
    (0,_storage_storage__WEBPACK_IMPORTED_MODULE_5__/* .useSubscribe */ .Q)(query, storage);
    return query;
}
var EthereumWalletInstance;
(function(EthereumWalletInstance) {
    async function tryFrom(wallet, background) {
        if (wallet.type === "privateKey") return await EthereumUnauthPrivateKeyWalletInstance.tryNew(wallet, background);
        if (wallet.type === "authPrivateKey") return await EthereumAuthPrivateKeyWalletInstance.tryNew(wallet, background);
        if (wallet.type === "seeded") return await EthereumSeededWalletInstance.tryNew(wallet, background);
        throw new _hazae41_result__WEBPACK_IMPORTED_MODULE_12__/* .Panic */ .F5();
    }
    EthereumWalletInstance.tryFrom = tryFrom;
})(EthereumWalletInstance || (EthereumWalletInstance = {}));
class EthereumSeededWalletInstance {
    static async tryNew(data, background) {
        return await _hazae41_result__WEBPACK_IMPORTED_MODULE_13__/* .Result */ .x.unthrow(async (t)=>{
            var _seedState_data;
            const storage = new _storage_user__WEBPACK_IMPORTED_MODULE_6__/* .UserStorage */ .Jt(background);
            const seedQuery = _seeds_data__WEBPACK_IMPORTED_MODULE_8__/* .FgSeed */ .EU.schema(data.seed.uuid, storage);
            const seedState = await (seedQuery === null || seedQuery === void 0 ? void 0 : seedQuery.state);
            const seedData = _hazae41_option__WEBPACK_IMPORTED_MODULE_14__/* .Option */ .W.wrap(seedState === null || seedState === void 0 ? void 0 : (_seedState_data = seedState.data) === null || _seedState_data === void 0 ? void 0 : _seedState_data.get()).ok().throw(t);
            const seed = await _seeds_all_helpers__WEBPACK_IMPORTED_MODULE_7__/* .SeedInstance */ .Gz.tryFrom(seedData, background).then((r)=>r.throw(t));
            return new _hazae41_result__WEBPACK_IMPORTED_MODULE_15__.Ok(new EthereumSeededWalletInstance(data, seed));
        });
    }
    async tryGetPrivateKey(background) {
        return await this.seed.tryGetPrivateKey(this.data.path, background);
    }
    async trySignPersonalMessage(message, background) {
        return await this.seed.trySignPersonalMessage(this.data.path, message, background);
    }
    async trySignTransaction(transaction, background) {
        return await this.seed.trySignTransaction(this.data.path, transaction, background);
    }
    async trySignEIP712HashedMessage(data, background) {
        return await this.seed.trySignEIP712HashedMessage(this.data.path, data, background);
    }
    constructor(data, seed){
        this.data = data;
        this.seed = seed;
    }
}
class EthereumUnauthPrivateKeyWalletInstance {
    static async tryNew(data, background) {
        return new _hazae41_result__WEBPACK_IMPORTED_MODULE_15__.Ok(new EthereumUnauthPrivateKeyWalletInstance(data));
    }
    async tryGetPrivateKey(background) {
        return new _hazae41_result__WEBPACK_IMPORTED_MODULE_15__.Ok(this.data.privateKey);
    }
    async trySignPersonalMessage(message, background) {
        return await _hazae41_result__WEBPACK_IMPORTED_MODULE_13__/* .Result */ .x.unthrow(async (t)=>{
            const privateKey = await this.tryGetPrivateKey(background).then((r)=>r.throw(t));
            const signature = await _hazae41_result__WEBPACK_IMPORTED_MODULE_13__/* .Result */ .x.runAndDoubleWrap(async ()=>{
                return await new ethers__WEBPACK_IMPORTED_MODULE_16__/* .Wallet */ .w(privateKey).signMessage(message);
            }).then((r)=>r.throw(t));
            return new _hazae41_result__WEBPACK_IMPORTED_MODULE_15__.Ok(signature);
        });
    }
    async trySignTransaction(transaction, background) {
        return await _hazae41_result__WEBPACK_IMPORTED_MODULE_13__/* .Result */ .x.unthrow(async (t)=>{
            const privateKey = await this.tryGetPrivateKey(background).then((r)=>r.throw(t));
            const signature = _hazae41_result__WEBPACK_IMPORTED_MODULE_13__/* .Result */ .x.runAndDoubleWrapSync(()=>{
                return new ethers__WEBPACK_IMPORTED_MODULE_16__/* .Wallet */ .w(privateKey).signingKey.sign(transaction.unsignedHash).serialized;
            }).throw(t);
            return new _hazae41_result__WEBPACK_IMPORTED_MODULE_15__.Ok(signature);
        });
    }
    async trySignEIP712HashedMessage(data, background) {
        return await _hazae41_result__WEBPACK_IMPORTED_MODULE_13__/* .Result */ .x.unthrow(async (t)=>{
            const privateKey = await this.tryGetPrivateKey(background).then((r)=>r.throw(t));
            delete data.types["EIP712Domain"];
            const signature = await _hazae41_result__WEBPACK_IMPORTED_MODULE_13__/* .Result */ .x.runAndDoubleWrap(async ()=>{
                return await new ethers__WEBPACK_IMPORTED_MODULE_16__/* .Wallet */ .w(privateKey).signTypedData(data.domain, data.types, data.message);
            }).then((r)=>r.throw(t));
            return new _hazae41_result__WEBPACK_IMPORTED_MODULE_15__.Ok(signature);
        });
    }
    constructor(data){
        this.data = data;
    }
}
class EthereumAuthPrivateKeyWalletInstance {
    static async tryNew(data, background) {
        return new _hazae41_result__WEBPACK_IMPORTED_MODULE_15__.Ok(new EthereumAuthPrivateKeyWalletInstance(data));
    }
    async tryGetPrivateKey(background) {
        return await _hazae41_result__WEBPACK_IMPORTED_MODULE_13__/* .Result */ .x.unthrow(async (t)=>{
            const env_1 = {
                stack: [],
                error: void 0,
                hasError: false
            };
            try {
                const { idBase64, ivBase64 } = this.data.privateKey;
                const id = _hazae41_base64__WEBPACK_IMPORTED_MODULE_17__/* .get */ .U().tryDecodePadded(idBase64).throw(t).copyAndDispose();
                const cipher = await _libs_webauthn_webauthn__WEBPACK_IMPORTED_MODULE_1__/* .WebAuthnStorage */ .g.tryGet(id).then((r)=>r.throw(t));
                const cipherBase64 = _hazae41_base64__WEBPACK_IMPORTED_MODULE_17__/* .get */ .U().tryEncodePadded(cipher).throw(t);
                const privateKeyBase64 = await background.tryRequest({
                    method: "brume_decrypt",
                    params: [
                        ivBase64,
                        cipherBase64
                    ]
                }).then((r)=>r.throw(t).throw(t));
                const privateKeyMemory = __addDisposableResource(env_1, _hazae41_base64__WEBPACK_IMPORTED_MODULE_17__/* .get */ .U().tryDecodePadded(privateKeyBase64).throw(t), false);
                return new _hazae41_result__WEBPACK_IMPORTED_MODULE_15__.Ok("0x".concat(_hazae41_base16__WEBPACK_IMPORTED_MODULE_18__/* .get */ .U().tryEncode(privateKeyMemory).throw(t)));
            } catch (e_1) {
                env_1.error = e_1;
                env_1.hasError = true;
            } finally{
                __disposeResources(env_1);
            }
        });
    }
    async trySignPersonalMessage(message, background) {
        return await _hazae41_result__WEBPACK_IMPORTED_MODULE_13__/* .Result */ .x.unthrow(async (t)=>{
            const privateKey = await this.tryGetPrivateKey(background).then((r)=>r.throw(t));
            const signature = await _hazae41_result__WEBPACK_IMPORTED_MODULE_13__/* .Result */ .x.runAndDoubleWrap(async ()=>{
                return await new ethers__WEBPACK_IMPORTED_MODULE_16__/* .Wallet */ .w(privateKey).signMessage(message);
            }).then((r)=>r.throw(t));
            return new _hazae41_result__WEBPACK_IMPORTED_MODULE_15__.Ok(signature);
        });
    }
    async trySignTransaction(transaction, background) {
        return await _hazae41_result__WEBPACK_IMPORTED_MODULE_13__/* .Result */ .x.unthrow(async (t)=>{
            const privateKey = await this.tryGetPrivateKey(background).then((r)=>r.throw(t));
            const signature = _hazae41_result__WEBPACK_IMPORTED_MODULE_13__/* .Result */ .x.runAndDoubleWrapSync(()=>{
                return new ethers__WEBPACK_IMPORTED_MODULE_16__/* .Wallet */ .w(privateKey).signingKey.sign(transaction.unsignedHash).serialized;
            }).throw(t);
            return new _hazae41_result__WEBPACK_IMPORTED_MODULE_15__.Ok(signature);
        });
    }
    async trySignEIP712HashedMessage(data, background) {
        return await _hazae41_result__WEBPACK_IMPORTED_MODULE_13__/* .Result */ .x.unthrow(async (t)=>{
            const privateKey = await this.tryGetPrivateKey(background).then((r)=>r.throw(t));
            delete data.types["EIP712Domain"];
            const signature = await _hazae41_result__WEBPACK_IMPORTED_MODULE_13__/* .Result */ .x.runAndDoubleWrap(async ()=>{
                return await new ethers__WEBPACK_IMPORTED_MODULE_16__/* .Wallet */ .w(privateKey).signTypedData(data.domain, data.types, data.message);
            }).then((r)=>r.throw(t));
            return new _hazae41_result__WEBPACK_IMPORTED_MODULE_15__.Ok(signature);
        });
    }
    constructor(data){
        this.data = data;
    }
}
function useEthereumContext(uuid, chain) {
    const background = (0,_background_context__WEBPACK_IMPORTED_MODULE_4__/* .useBackgroundContext */ .D_)().unwrap();
    const maybeContext = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(()=>{
        if (uuid == null) return;
        if (chain == null) return;
        return {
            uuid,
            chain,
            background
        };
    }, [
        uuid,
        chain,
        background
    ]);
    return maybeContext;
}
function useEthereumContext2(uuid, chain) {
    const background = (0,_background_context__WEBPACK_IMPORTED_MODULE_4__/* .useBackgroundContext */ .D_)().unwrap();
    const maybeContext = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(()=>{
        if (uuid == null) return;
        if (chain == null) return;
        return {
            uuid,
            chain,
            background
        };
    }, [
        uuid,
        chain,
        background
    ]);
    return _hazae41_option__WEBPACK_IMPORTED_MODULE_14__/* .Option */ .W.wrap(maybeContext);
}
async function customFetchOrFail(request, ethereum) {
    const { uuid, background, chain } = ethereum;
    return await background.tryRequest({
        method: "brume_eth_custom_fetch",
        params: [
            uuid,
            chain.chainId,
            request
        ]
    }).then((r)=>_hazae41_glacier__WEBPACK_IMPORTED_MODULE_19__/* .Fetched */ .F.rewrap(r.unwrap()));
}
async function fetchOrFail(request, ethereum) {
    const { uuid, background, chain } = ethereum;
    return await background.tryRequest({
        method: "brume_eth_fetch",
        params: [
            uuid,
            chain.chainId,
            request
        ]
    }).then((r)=>_hazae41_glacier__WEBPACK_IMPORTED_MODULE_19__/* .Fetched */ .F.rewrap(r.unwrap()));
}


/***/ }),

/***/ 7019:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Zi: function() { return /* binding */ PriceResolver; },
  ds: function() { return /* binding */ WalletPage; },
  jJ: function() { return /* binding */ useCompactDisplayUsd; },
  iZ: function() { return /* binding */ useDisplayUsd; }
});

// UNUSED EXPORTS: ButtonCard, DivLikeButton, LinkCard, useDisplay

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
// EXTERNAL MODULE: ./src/libs/colors/colors.ts
var colors = __webpack_require__(7457);
// EXTERNAL MODULE: ./src/libs/errors/errors.ts
var errors = __webpack_require__(9071);
// EXTERNAL MODULE: ./src/libs/ethereum/mods/chain.tsx
var mods_chain = __webpack_require__(9408);
// EXTERNAL MODULE: ./src/libs/glacier/mutators.ts
var mutators = __webpack_require__(2457);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/QrCodeIcon.js
var QrCodeIcon = __webpack_require__(4435);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/LinkIcon.js
var LinkIcon = __webpack_require__(23);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/EyeIcon.js
var EyeIcon = __webpack_require__(2940);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/BanknotesIcon.js
var BanknotesIcon = __webpack_require__(2435);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/PaperAirplaneIcon.js
var PaperAirplaneIcon = __webpack_require__(7778);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/TrophyIcon.js
var TrophyIcon = __webpack_require__(8022);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/CheckIcon.js
var CheckIcon = __webpack_require__(2911);
// EXTERNAL MODULE: ./src/libs/modhash/modhash.ts
var modhash = __webpack_require__(6652);
// EXTERNAL MODULE: ./src/libs/react/events.ts
var events = __webpack_require__(4714);
// EXTERNAL MODULE: ./src/libs/react/handles/boolean.tsx
var handles_boolean = __webpack_require__(5902);
// EXTERNAL MODULE: ./src/libs/results/results.ts
var results = __webpack_require__(421);
// EXTERNAL MODULE: ./src/libs/ui/button.tsx + 8 modules
var ui_button = __webpack_require__(1258);
// EXTERNAL MODULE: ./src/libs/ui/dialog/dialog.tsx
var dialog = __webpack_require__(3868);
// EXTERNAL MODULE: ./node_modules/@hazae41/base16/dist/esm/src/mods/base16/adapter.mjs
var adapter = __webpack_require__(2248);
// EXTERNAL MODULE: ./node_modules/@hazae41/bytes/dist/esm/mods/bytes/bytes.mjs + 3 modules
var bytes_bytes = __webpack_require__(1694);
// EXTERNAL MODULE: ./node_modules/@hazae41/option/dist/esm/mods/option/option.mjs
var option_option = __webpack_require__(5316);
// EXTERNAL MODULE: ./node_modules/@hazae41/option/dist/esm/mods/option/none.mjs
var none = __webpack_require__(1371);
// EXTERNAL MODULE: ./node_modules/@hazae41/option/dist/esm/mods/option/some.mjs
var some = __webpack_require__(8862);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/result.mjs
var result = __webpack_require__(918);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/ok.mjs
var ok = __webpack_require__(5591);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/err.mjs
var err = __webpack_require__(166);
// EXTERNAL MODULE: ./node_modules/@hazae41/x25519/dist/esm/src/mods/x25519/adapter.mjs
var x25519_adapter = __webpack_require__(7747);
// EXTERNAL MODULE: ./node_modules/@swc/helpers/esm/_class_private_field_get.js + 1 modules
var _class_private_field_get = __webpack_require__(7121);
// EXTERNAL MODULE: ./node_modules/@swc/helpers/esm/_class_private_field_init.js
var _class_private_field_init = __webpack_require__(9886);
// EXTERNAL MODULE: ./node_modules/@swc/helpers/esm/_class_private_field_set.js + 1 modules
var _class_private_field_set = __webpack_require__(5321);
// EXTERNAL MODULE: ./node_modules/@swc/helpers/esm/_class_private_method_get.js
var _class_private_method_get = __webpack_require__(6723);
// EXTERNAL MODULE: ./node_modules/@swc/helpers/esm/_class_private_method_init.js
var _class_private_method_init = __webpack_require__(9979);
// EXTERNAL MODULE: ./node_modules/@hazae41/binary/dist/esm/mods/binary/writable.mjs
var writable = __webpack_require__(2008);
// EXTERNAL MODULE: ./node_modules/@hazae41/binary/dist/esm/mods/binary/opaque.mjs
var opaque = __webpack_require__(2794);
;// CONCATENATED MODULE: ./src/libs/wconn/mods/crypto/crypto.ts



var _a, _b, _c;


var _class = /*#__PURE__*/ new WeakMap();
class CryptoError extends Error {
    static from(cause) {
        return new _a(undefined, {
            cause
        });
    }
    constructor(...args){
        super(...args);
        (0,_class_private_field_init._)(this, _class, {
            writable: true,
            value: void 0
        });
        (0,_class_private_field_set._)(this, _class, _a);
        this.name = (0,_class_private_field_get._)(this, _class).name;
    }
}
_a = CryptoError;
class Plaintext {
    encryptOrThrow(key, iv) {
        const plain = writable/* Writable */.c.writeToBytesOrThrow(this.fragment);
        const cipher = key.tryEncrypt(plain, iv).unwrap().copyAndDispose();
        return new Ciphertext(iv, cipher);
    }
    tryEncrypt(key, iv) {
        return result/* Result */.x.runAndDoubleWrapSync(()=>this.encryptOrThrow(key, iv));
    }
    constructor(fragment){
        this.fragment = fragment;
    }
}
class Ciphertext {
    decryptOrThrow(key) {
        const plain = key.tryDecrypt(this.inner, this.iv).unwrap().copyAndDispose();
        return new Plaintext(new opaque/* Opaque */.lD(plain));
    }
    tryDecrypt(key) {
        return result/* Result */.x.runAndDoubleWrapSync(()=>this.decryptOrThrow(key));
    }
    sizeOrThrow() {
        return this.iv.length + this.inner.length;
    }
    writeOrThrow(cursor) {
        cursor.writeOrThrow(this.iv);
        cursor.writeOrThrow(this.inner);
    }
    static readOrThrow(cursor) {
        const iv = cursor.readAndCopyOrThrow(12);
        const inner = cursor.readAndCopyOrThrow(cursor.remaining);
        return new Ciphertext(iv, inner);
    }
    constructor(iv, inner){
        this.iv = iv;
        this.inner = inner;
    }
}
var Envelope;
(function(Envelope) {
    var _d;
    var _class = /*#__PURE__*/ new WeakMap();
    class UnknownTypeError extends Error {
        constructor(type){
            super("Unknown type ".concat(type));
            (0,_class_private_field_init._)(this, _class, {
                writable: true,
                value: void 0
            });
            (0,_class_private_field_set._)(this, _class, _d);
            this.name = (0,_class_private_field_get._)(this, _class).name;
            this.type = type;
        }
    }
    _d = UnknownTypeError;
    Envelope.UnknownTypeError = UnknownTypeError;
    function readOrThrow(cursor) {
        const type = cursor.getUint8OrThrow();
        if (type === 0) return EnvelopeTypeZero.readOrThrow(cursor);
        if (type === 1) return EnvelopeTypeOne.readOrThrow(cursor);
        throw new UnknownTypeError(type);
    }
    Envelope.readOrThrow = readOrThrow;
})(Envelope || (Envelope = {}));
var _class1 = /*#__PURE__*/ new WeakMap();
class EnvelopeTypeZero {
    sizeOrThrow() {
        return 1 + this.fragment.sizeOrThrow();
    }
    writeOrThrow(cursor) {
        cursor.writeUint8OrThrow(this.type);
        this.fragment.writeOrThrow(cursor);
    }
    static readOrThrow(cursor) {
        const type = cursor.readUint8OrThrow();
        if (type !== _b.type) throw new Error("Invalid type-0 type ".concat(type));
        const bytes = cursor.readAndCopyOrThrow(cursor.remaining);
        const fragment = new opaque/* Opaque */.lD(bytes);
        return new _b(fragment);
    }
    constructor(fragment){
        (0,_class_private_field_init._)(this, _class1, {
            writable: true,
            value: void 0
        });
        (0,_class_private_field_set._)(this, _class1, _b);
        this.type = (0,_class_private_field_get._)(this, _class1).type;
        this.fragment = fragment;
    }
}
EnvelopeTypeZero.type = 0;
_b = EnvelopeTypeZero;
var _class2 = /*#__PURE__*/ new WeakMap();
class EnvelopeTypeOne {
    sizeOrThrow() {
        return 1 + this.sender.length + this.fragment.sizeOrThrow();
    }
    writeOrThrow(cursor) {
        cursor.writeUint8OrThrow(this.type);
        cursor.writeOrThrow(this.sender);
        this.fragment.writeOrThrow(cursor);
    }
    static readOrThrow(cursor) {
        const type = cursor.readUint8OrThrow();
        if (type !== _c.type) throw new Error("Invalid type ".concat(type));
        const sender = cursor.readAndCopyOrThrow(32);
        const bytes = cursor.readAndCopyOrThrow(cursor.remaining);
        const fragment = new opaque/* Opaque */.lD(bytes);
        return new _c(sender, fragment);
    }
    constructor(sender, fragment){
        (0,_class_private_field_init._)(this, _class2, {
            writable: true,
            value: void 0
        });
        (0,_class_private_field_set._)(this, _class2, _c);
        this.type = (0,_class_private_field_get._)(this, _class2).type;
        this.sender = sender;
        this.fragment = fragment;
    }
}
EnvelopeTypeOne.type = 1;
_c = EnvelopeTypeOne;

;// CONCATENATED MODULE: ./src/libs/wconn/mods/json/json.ts
var BigJson;
(function(BigJson) {
    /**
     * Bigger than MAX_SAFE_INTEGER
     */ const BIG_REGEX = /([\[:])?(\d{17,}|(?:[9](?:[1-9]07199254740991|0[1-9]7199254740991|00[8-9]199254740991|007[2-9]99254740991|007199[3-9]54740991|0071992[6-9]4740991|00719925[5-9]740991|007199254[8-9]40991|0071992547[5-9]0991|00719925474[1-9]991|00719925474099[2-9])))([,\}\]])/g;
    function stringify(value) {
        function replacer(key, value) {
            if (typeof value !== "bigint") return value;
            return "".concat(value.toString(), "n");
        }
        return JSON.stringify(value, replacer);
    }
    BigJson.stringify = stringify;
    function parse(text) {
        const replaced = text.replace(BIG_REGEX, '$1"$2n"$3');
        function reviver(key, value) {
            if (typeof value !== "string") return value;
            if (!value.match(/^\d+n$/)) return value;
            return BigInt(value.slice(0, -1));
        }
        return JSON.parse(replaced, reviver);
    }
    BigJson.parse = parse;
})(BigJson || (BigJson = {}));
var SafeJson;
(function(SafeJson) {
    function stringify(value) {
        if (typeof value === "string") return value;
        return BigJson.stringify(value);
    }
    SafeJson.stringify = stringify;
    function parse(text) {
        try {
            return BigJson.parse(text);
        } catch (e) {
            return text;
        }
    }
    SafeJson.parse = parse;
})(SafeJson || (SafeJson = {}));

// EXTERNAL MODULE: ./node_modules/@hazae41/base64/dist/esm/src/mods/base64/adapter.mjs
var base64_adapter = __webpack_require__(9467);
// EXTERNAL MODULE: ./node_modules/@hazae41/binary/dist/esm/mods/binary/readable.mjs
var readable = __webpack_require__(1916);
// EXTERNAL MODULE: ./node_modules/@hazae41/chacha20poly1305/dist/esm/src/mods/chacha20poly1305/adapter.mjs
var chacha20poly1305_adapter = __webpack_require__(5751);
// EXTERNAL MODULE: ./node_modules/@hazae41/future/dist/esm/mods/future/future.mjs
var future_future = __webpack_require__(6071);
// EXTERNAL MODULE: ./node_modules/@hazae41/jsonrpc/dist/esm/mods/rpc/response.mjs
var rpc_response = __webpack_require__(5457);
// EXTERNAL MODULE: ./node_modules/@hazae41/plume/dist/esm/src/mods/target.mjs
var target = __webpack_require__(4232);
// EXTERNAL MODULE: ./node_modules/@hazae41/jsonrpc/dist/esm/mods/rpc/request.mjs
var request = __webpack_require__(4356);
// EXTERNAL MODULE: ./node_modules/@hazae41/plume/dist/esm/src/mods/errors.mjs
var mods_errors = __webpack_require__(9107);
;// CONCATENATED MODULE: ./src/libs/wconn/mods/rpc/rpc.ts





var SafeRpc;
(function(SafeRpc) {
    function prepare(init) {
        const id = Date.now() + Math.floor(Math.random() * 1000);
        return new request/* RpcRequest */.a(id, init.method, init.params);
    }
    SafeRpc.prepare = prepare;
    async function tryRequest(socket, init, signal) {
        const request = prepare(init);
        socket.send(SafeJson.stringify(request));
        const future = new future_future/* Future */.o();
        const onMessage = async (event)=>{
            if (typeof event.data !== "string") return;
            const response = rpc_response/* RpcResponse */.S.from(SafeJson.parse(event.data));
            if (response.id !== request.id) return;
            future.resolve(new ok.Ok(response));
        };
        const onError = (e)=>{
            future.resolve(new err/* Err */.U(mods_errors/* ErroredError */.kN.from(e)));
        };
        const onClose = (e)=>{
            future.resolve(new err/* Err */.U(mods_errors/* ClosedError */.$A.from(e)));
        };
        const onAbort = ()=>{
            future.resolve(new err/* Err */.U(mods_errors/* AbortedError */.pe.from(signal.reason)));
        };
        try {
            socket.addEventListener("message", onMessage, {
                passive: true
            });
            socket.addEventListener("close", onClose, {
                passive: true
            });
            socket.addEventListener("error", onError, {
                passive: true
            });
            signal.addEventListener("abort", onAbort, {
                passive: true
            });
            return await future.promise;
        } finally{
            socket.removeEventListener("message", onMessage);
            socket.removeEventListener("close", onClose);
            socket.removeEventListener("error", onError);
            signal.removeEventListener("abort", onAbort);
        }
    }
    SafeRpc.tryRequest = tryRequest;
})(SafeRpc || (SafeRpc = {}));

;// CONCATENATED MODULE: ./src/libs/wconn/mods/crypto/client.ts





var __addDisposableResource = undefined && undefined.__addDisposableResource || function(env, value, async) {
    if (value !== null && value !== void 0) {
        if (typeof value !== "object" && typeof value !== "function") throw new TypeError("Object expected.");
        var dispose;
        if (async) {
            if (!Symbol.asyncDispose) throw new TypeError("Symbol.asyncDispose is not defined.");
            dispose = value[Symbol.asyncDispose];
        }
        if (dispose === void 0) {
            if (!Symbol.dispose) throw new TypeError("Symbol.dispose is not defined.");
            dispose = value[Symbol.dispose];
        }
        if (typeof dispose !== "function") throw new TypeError("Object not disposable.");
        env.stack.push({
            value: value,
            dispose: dispose,
            async: async
        });
    } else if (async) {
        env.stack.push({
            async: true
        });
    }
    return value;
};
var __disposeResources = undefined && undefined.__disposeResources || function(SuppressedError1) {
    return function(env) {
        function fail(e) {
            env.error = env.hasError ? new SuppressedError1(e, env.error, "An error was suppressed during disposal.") : e;
            env.hasError = true;
        }
        function next() {
            while(env.stack.length){
                var rec = env.stack.pop();
                try {
                    var result = rec.dispose && rec.dispose.call(rec.value);
                    if (rec.async) return Promise.resolve(result).then(next, function(e) {
                        fail(e);
                        return next();
                    });
                } catch (e) {
                    fail(e);
                }
            }
            if (env.hasError) throw env.error;
        }
        return next();
    };
}(typeof SuppressedError === "function" ? SuppressedError : function(error, suppressed, message) {
    var e = new Error(message);
    return e.name = "SuppressedError", e.error = error, e.suppressed = suppressed, e;
});












const ENGINE_RPC_OPTS = {
    wc_sessionPropose: {
        req: {
            ttl: 5 * 60,
            prompt: true,
            tag: 1100
        },
        res: {
            ttl: 5 * 60,
            prompt: false,
            tag: 1101
        }
    },
    wc_sessionSettle: {
        req: {
            ttl: 5 * 60,
            prompt: false,
            tag: 1102
        },
        res: {
            ttl: 5 * 60,
            prompt: false,
            tag: 1103
        }
    },
    wc_sessionUpdate: {
        req: {
            ttl: 24 * 60 * 60,
            prompt: false,
            tag: 1104
        },
        res: {
            ttl: 24 * 60 * 60,
            prompt: false,
            tag: 1105
        }
    },
    wc_sessionExtend: {
        req: {
            ttl: 24 * 60 * 60,
            prompt: false,
            tag: 1106
        },
        res: {
            ttl: 24 * 60 * 60,
            prompt: false,
            tag: 1107
        }
    },
    wc_sessionRequest: {
        req: {
            ttl: 5 * 60,
            prompt: true,
            tag: 1108
        },
        res: {
            ttl: 5 * 60,
            prompt: false,
            tag: 1109
        }
    },
    wc_sessionEvent: {
        req: {
            ttl: 5 * 60,
            prompt: true,
            tag: 1110
        },
        res: {
            ttl: 5 * 60,
            prompt: false,
            tag: 1111
        }
    },
    wc_sessionDelete: {
        req: {
            ttl: 24 * 60 * 60,
            prompt: false,
            tag: 1112
        },
        res: {
            ttl: 24 * 60 * 60,
            prompt: false,
            tag: 1113
        }
    },
    wc_sessionPing: {
        req: {
            ttl: 30,
            prompt: false,
            tag: 1114
        },
        res: {
            ttl: 30,
            prompt: false,
            tag: 1115
        }
    }
};
var _ack = /*#__PURE__*/ new WeakMap(), _onIrnRequest = /*#__PURE__*/ new WeakSet(), _onIrnSubscription = /*#__PURE__*/ new WeakSet(), _onMessage = /*#__PURE__*/ new WeakSet(), _onRequest = /*#__PURE__*/ new WeakSet(), _tryRouteRequest = /*#__PURE__*/ new WeakSet(), _onResponse = /*#__PURE__*/ new WeakSet(), _tryEncrypt = /*#__PURE__*/ new WeakSet();
class CryptoClient {
    static tryNew(topic, key, irn) {
        return result/* Result */.x.unthrowSync((t)=>{
            const cipher = chacha20poly1305_adapter/* get */.U().Cipher.tryImport(key).throw(t);
            const client = new CryptoClient(topic, key, irn, cipher);
            return new ok.Ok(client);
        });
    }
    async tryRequestAndWait(init) {
        return await this.tryRequest(init).then((r)=>r.andThen((x)=>x.promise));
    }
    async tryRequest(init) {
        return result/* Result */.x.unthrow(async (t)=>{
            const request = SafeRpc.prepare(init);
            // console.log("relay", "<-", request)
            const { topic } = this;
            const message = (0,_class_private_method_get._)(this, _tryEncrypt, tryEncrypt).call(this, request).throw(t);
            const { prompt, tag, ttl } = ENGINE_RPC_OPTS[init.method].req;
            const { id } = request;
            const end = Date.now() + ttl * 1000;
            const receipt = {
                id,
                end
            };
            const promise = this.tryWait(receipt);
            await this.irn.tryPublish({
                topic,
                message,
                prompt,
                tag,
                ttl
            }).then((r)=>r.throw(t));
            return new ok.Ok({
                receipt,
                promise
            });
        });
    }
    async waitOrThrow(receipt) {
        const future = new future_future/* Future */.o();
        const signal = AbortSignal.timeout(receipt.end - Date.now());
        const onResponse = (init)=>{
            if (init.id !== receipt.id) return new none/* None */.H();
            const response = rpc_response/* RpcResponse */.S.from(init);
            future.resolve(response);
            return new some/* Some */.b(undefined);
        };
        const onAbort = ()=>{
            future.reject(new Error("Timed out"));
        };
        try {
            this.events.on("response", onResponse, {
                passive: true
            });
            signal.addEventListener("abort", onAbort, {
                passive: true
            });
            return await future.promise;
        } finally{
            this.events.off("response", onResponse);
            signal.removeEventListener("abort", onAbort);
        }
    }
    async tryWait(receipt) {
        return await result/* Result */.x.runAndDoubleWrap(async ()=>this.waitOrThrow(receipt));
    }
    constructor(topic, key, irn, cipher){
        (0,_class_private_method_init._)(this, _onIrnRequest);
        (0,_class_private_method_init._)(this, _onIrnSubscription);
        (0,_class_private_method_init._)(this, _onMessage);
        (0,_class_private_method_init._)(this, _onRequest);
        (0,_class_private_method_init._)(this, _tryRouteRequest);
        (0,_class_private_method_init._)(this, _onResponse);
        (0,_class_private_method_init._)(this, _tryEncrypt);
        (0,_class_private_field_init._)(this, _ack, {
            writable: true,
            value: void 0
        });
        this.events = new target/* SuperEventTarget */.v();
        (0,_class_private_field_set._)(this, _ack, new Set());
        this.topic = topic;
        this.key = key;
        this.irn = irn;
        this.cipher = cipher;
        irn.events.on("request", (0,_class_private_method_get._)(this, _onIrnRequest, onIrnRequest).bind(this));
    }
}
async function onIrnRequest(request) {
    if (request.method === "irn_subscription") return await (0,_class_private_method_get._)(this, _onIrnSubscription, onIrnSubscription).call(this, request);
    return new none/* None */.H();
}
async function onIrnSubscription(request) {
    const { data } = request.params;
    if (data.topic !== this.topic) return new none/* None */.H();
    return new some/* Some */.b(await (0,_class_private_method_get._)(this, _onMessage, onMessage).call(this, data.message));
}
async function onMessage(message) {
    return result/* Result */.x.unthrow(async (t)=>{
        const env_1 = {
            stack: [],
            error: void 0,
            hasError: false
        };
        try {
            const slice = __addDisposableResource(env_1, base64_adapter/* get */.U().tryDecodePadded(message).throw(t), false);
            const envelope = readable/* Readable */.$.tryReadFromBytes(Envelope, slice.bytes).throw(t);
            const cipher = envelope.fragment.tryReadInto(Ciphertext).throw(t);
            const plain = cipher.tryDecrypt(this.cipher).throw(t);
            const plaintext = bytes_bytes/* Bytes */.J.toUtf8(plain.fragment.bytes);
            const data = SafeJson.parse(plaintext);
            if ("method" in data) (0,_class_private_method_get._)(this, _onRequest, onRequest).call(this, data).then((r)=>r.unwrap()).catch(console.warn);
            else (0,_class_private_method_get._)(this, _onResponse, onResponse).call(this, data).then((r)=>r.unwrap()).catch(console.warn);
            return new ok.Ok(true);
        } catch (e_1) {
            env_1.error = e_1;
            env_1.hasError = true;
        } finally{
            __disposeResources(env_1);
        }
    });
}
async function onRequest(request) {
    return result/* Result */.x.unthrow(async (t)=>{
        // console.log("relay request", "->", request)
        if (typeof request.id !== "number") return ok.Ok.void();
        if ((0,_class_private_field_get._)(this, _ack).has(request.id)) return ok.Ok.void();
        (0,_class_private_field_get._)(this, _ack).add(request.id);
        const result = await (0,_class_private_method_get._)(this, _tryRouteRequest, tryRouteRequest).call(this, request);
        const response = rpc_response/* RpcResponse */.S.rewrap(request.id, result);
        // console.log("relay", "<-", response)
        const { topic } = this;
        const message = (0,_class_private_method_get._)(this, _tryEncrypt, tryEncrypt).call(this, response).throw(t);
        const { prompt, tag, ttl } = ENGINE_RPC_OPTS[request.method].res;
        await this.irn.tryPublish({
            topic,
            message,
            prompt,
            tag,
            ttl
        }).then((r)=>r.throw(t));
        return ok.Ok.void();
    });
}
async function tryRouteRequest(request) {
    const returned = await this.events.emit("request", [
        request
    ]);
    if (returned.isSome()) return returned.inner;
    return new err/* Err */.U(new Error("Unhandled"));
}
async function onResponse(response) {
    // console.log("relay response", "->", response)
    const returned = await this.events.emit("response", [
        response
    ]);
    if (returned.isSome()) return ok.Ok.void();
    return new err/* Err */.U(new Error("Unhandled"));
}
function tryEncrypt(data) {
    return result/* Result */.x.unthrowSync((t)=>{
        const plaintext = SafeJson.stringify(data);
        const plain = new Plaintext(new opaque/* Opaque */.lD(bytes_bytes/* Bytes */.J.fromUtf8(plaintext)));
        const iv = bytes_bytes/* Bytes */.J.random(12); // TODO maybe use a counter
        const cipher = plain.tryEncrypt(this.cipher, iv).throw(t);
        const envelope = new EnvelopeTypeZero(cipher);
        const bytes = writable/* Writable */.c.tryWriteToBytes(envelope).throw(t);
        const message = base64_adapter/* get */.U().tryEncodePadded(bytes).throw(t);
        return new ok.Ok(message);
    });
}

;// CONCATENATED MODULE: ./src/libs/wconn/mods/wc/wc.ts
var wc_addDisposableResource = undefined && undefined.__addDisposableResource || function(env, value, async) {
    if (value !== null && value !== void 0) {
        if (typeof value !== "object" && typeof value !== "function") throw new TypeError("Object expected.");
        var dispose;
        if (async) {
            if (!Symbol.asyncDispose) throw new TypeError("Symbol.asyncDispose is not defined.");
            dispose = value[Symbol.asyncDispose];
        }
        if (dispose === void 0) {
            if (!Symbol.dispose) throw new TypeError("Symbol.dispose is not defined.");
            dispose = value[Symbol.dispose];
        }
        if (typeof dispose !== "function") throw new TypeError("Object not disposable.");
        env.stack.push({
            value: value,
            dispose: dispose,
            async: async
        });
    } else if (async) {
        env.stack.push({
            async: true
        });
    }
    return value;
};
var wc_disposeResources = undefined && undefined.__disposeResources || function(SuppressedError1) {
    return function(env) {
        function fail(e) {
            env.error = env.hasError ? new SuppressedError1(e, env.error, "An error was suppressed during disposal.") : e;
            env.hasError = true;
        }
        function next() {
            while(env.stack.length){
                var rec = env.stack.pop();
                try {
                    var result = rec.dispose && rec.dispose.call(rec.value);
                    if (rec.async) return Promise.resolve(result).then(next, function(e) {
                        fail(e);
                        return next();
                    });
                } catch (e) {
                    fail(e);
                }
            }
            if (env.hasError) throw env.error;
        }
        return next();
    };
}(typeof SuppressedError === "function" ? SuppressedError : function(error, suppressed, message) {
    var e = new Error(message);
    return e.name = "SuppressedError", e.error = error, e.suppressed = suppressed, e;
});







class WcProposal {
    constructor(client, metadata){
        this.client = client;
        this.metadata = metadata;
    }
}
class WcSession {
    async tryClose(reason) {
        return await result/* Result */.x.unthrow(async (t)=>{
            await this.client.tryRequest({
                method: "wc_sessionDelete",
                params: {
                    code: 6000,
                    message: "User disconnected."
                }
            }).then((r)=>r.throw(t));
            await this.client.irn.tryClose(reason).then((r)=>r.throw(t));
            return ok.Ok.void();
        });
    }
    constructor(client, metadata){
        this.client = client;
        this.metadata = metadata;
    }
}
var Wc;
(function(Wc) {
    Wc.RELAY = "wss://relay.walletconnect.org";
    function tryParse(url) {
        return result/* Result */.x.unthrow(async (t)=>{
            const { protocol, pathname, searchParams } = url;
            if (protocol !== "wc:") return new err/* Err */.U(new Error("Invalid protocol"));
            const [pairingTopic, version] = pathname.split("@");
            if (version !== "2") return new err/* Err */.U(new Error("Invalid version"));
            const relayProtocol = option_option/* Option */.W.wrap(searchParams.get("relay-protocol")).ok().throw(t);
            if (relayProtocol !== "irn") return new err/* Err */.U(new Error("Invalid relay protocol"));
            const symKeyHex = option_option/* Option */.W.wrap(searchParams.get("symKey")).ok().throw(t);
            const symKeyRaw = adapter/* get */.U().tryPadStartAndDecode(symKeyHex).throw(t).copyAndDispose();
            const symKey = bytes_bytes/* Bytes */.J.tryCast(symKeyRaw, 32).throw(t);
            return new ok.Ok({
                protocol,
                pairingTopic,
                version,
                relayProtocol,
                symKey
            });
        });
    }
    Wc.tryParse = tryParse;
    async function tryPair(irn, params, address) {
        return await result/* Result */.x.unthrow(async (t)=>{
            const env_1 = {
                stack: [],
                error: void 0,
                hasError: false
            };
            try {
                const { pairingTopic, symKey } = params;
                const pairing = CryptoClient.tryNew(pairingTopic, symKey, irn).throw(t);
                const relay = {
                    protocol: "irn"
                };
                const selfPrivate = await x25519_adapter/* get */.U().PrivateKey.tryRandom().then((r)=>r.throw(t));
                const selfPublic = selfPrivate.tryGetPublicKey().throw(t);
                const selfPublicMemory = wc_addDisposableResource(env_1, await selfPublic.tryExport().then((r)=>r.throw(t)), false);
                const selfPublicHex = adapter/* get */.U().tryEncode(selfPublicMemory).throw(t);
                await irn.trySubscribe(pairingTopic).then((r)=>r.throw(t));
                const proposal = await pairing.events.wait("request", async (future, request)=>{
                    if (request.method !== "wc_sessionPropose") return new none/* None */.H();
                    future.resolve(request);
                    return new some/* Some */.b(new ok.Ok({
                        relay,
                        responderPublicKey: selfPublicHex
                    }));
                }).inner;
                const peerPublicMemory = wc_addDisposableResource(env_1, adapter/* get */.U().tryPadStartAndDecode(proposal.params.proposer.publicKey).throw(t), false);
                const peerPublic = await x25519_adapter/* get */.U().PublicKey.tryImport(peerPublicMemory).then((r)=>r.throw(t));
                const sharedRef = await selfPrivate.tryCompute(peerPublic).then((r)=>r.throw(t));
                const sharedSlice = wc_addDisposableResource(env_1, sharedRef.tryExport().throw(t), false);
                const hdfk_key = await crypto.subtle.importKey("raw", sharedSlice.bytes, "HKDF", false, [
                    "deriveBits"
                ]);
                const hkdf_params = {
                    name: "HKDF",
                    hash: "SHA-256",
                    info: new Uint8Array(),
                    salt: new Uint8Array()
                };
                const sessionKey = new Uint8Array(await crypto.subtle.deriveBits(hkdf_params, hdfk_key, 8 * 32));
                const sessionDigest = new Uint8Array(await crypto.subtle.digest("SHA-256", sessionKey));
                const sessionTopic = adapter/* get */.U().tryEncode(sessionDigest).throw(t);
                const session = CryptoClient.tryNew(sessionTopic, sessionKey, irn).throw(t);
                await irn.trySubscribe(sessionTopic).then((r)=>r.throw(t));
                {
                    const { proposer, requiredNamespaces, optionalNamespaces } = proposal.params;
                    const namespaces = {
                        eip155: {
                            chains: Object.values(mods_chain/* chainByChainId */.DH).map((chain)=>"eip155:".concat(chain.chainId)),
                            methods: [
                                "eth_sendTransaction",
                                "personal_sign",
                                "eth_signTypedData",
                                "eth_signTypedData_v4"
                            ],
                            events: [
                                "chainChanged",
                                "accountsChanged"
                            ],
                            accounts: Object.values(mods_chain/* chainByChainId */.DH).map((chain)=>"eip155:".concat(chain.chainId, ":").concat(address))
                        }
                    };
                    const metadata = {
                        name: "Brume",
                        description: "Brume",
                        url: location.origin,
                        icons: []
                    };
                    const controller = {
                        publicKey: selfPublicHex,
                        metadata
                    };
                    const expiry = Math.floor((Date.now() + 7 * 24 * 60 * 60 * 1000) / 1000);
                    const params = {
                        relay,
                        namespaces,
                        requiredNamespaces,
                        optionalNamespaces,
                        pairingTopic,
                        controller,
                        expiry
                    };
                    const settlement = await session.tryRequest({
                        method: "wc_sessionSettle",
                        params
                    }).then((r)=>r.throw(t));
                    return new ok.Ok([
                        new WcSession(session, proposer.metadata),
                        settlement
                    ]);
                }
            } catch (e_1) {
                env_1.error = e_1;
                env_1.hasError = true;
            } finally{
                wc_disposeResources(env_1);
            }
        });
    }
    Wc.tryPair = tryPair;
})(Wc || (Wc = {}));

// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/abi/types/function/function.mjs
var function_function = __webpack_require__(7205);
// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/abi/types/tuple/tuple.mjs
var tuple = __webpack_require__(5444);
// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/abi/types/address/address.mjs
var address = __webpack_require__(3831);
// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/abi/types/int/int.mjs
var int_int = __webpack_require__(5790);
;// CONCATENATED MODULE: ./src/libs/abi/erc20.abi.ts

var TokenAbi;
(function(TokenAbi) {
    TokenAbi.balanceOf = function_function/* FunctionSelectorAndArguments */.b0.create(function_function/* FunctionSelector */.xS.from([
        112,
        160,
        130,
        49
    ]), tuple/* Tuple */.p.create(address/* Address */.kL));
    TokenAbi.transfer = function_function/* FunctionSelectorAndArguments */.b0.create(function_function/* FunctionSelector */.xS.from([
        169,
        5,
        156,
        187
    ]), tuple/* Tuple */.p.create(address/* Address */.kL, int_int/* Int256 */.R4));
    TokenAbi.approve = function_function/* FunctionSelectorAndArguments */.b0.create(function_function/* FunctionSelector */.xS.from([
        9,
        94,
        167,
        179
    ]), tuple/* Tuple */.p.create(address/* Address */.kL, int_int/* Int256 */.R4));
})(TokenAbi || (TokenAbi = {}));

// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/types/fixed/index.mjs
var types_fixed = __webpack_require__(8386);
// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/abi/encode.mjs
var encode = __webpack_require__(6167);
// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/abi/types/uint/uint.mjs
var uint = __webpack_require__(24);
// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/abi/decode.mjs + 1 modules
var decode = __webpack_require__(7817);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/queries/simple/query.mjs
var query = __webpack_require__(6233);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/fetched/data.mjs
var fetched_data = __webpack_require__(8123);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/fetched/fail.mjs
var fail = __webpack_require__(9164);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/errors.mjs
var result_errors = __webpack_require__(2564);
// EXTERNAL MODULE: ./src/mods/background/service_worker/context.ts + 4 modules
var service_worker_context = __webpack_require__(2223);
// EXTERNAL MODULE: ./src/mods/background/service_worker/entities/unknown/data.ts
var data = __webpack_require__(3499);
;// CONCATENATED MODULE: ./src/libs/abi/pair.abi.ts

var PairAbi;
(function(PairAbi) {
    PairAbi.getReserves = function_function/* FunctionSelectorAndArguments */.b0.create(function_function/* FunctionSelector */.xS.from([
        9,
        2,
        241,
        172
    ]), tuple/* Tuple */.p.create());
})(PairAbi || (PairAbi = {}));

// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/fetched/fetched.mjs
var fetched = __webpack_require__(1458);
;// CONCATENATED MODULE: ./src/mods/background/service_worker/entities/tokens/pairs/data.ts






var BgPair;
(function(BgPair) {
    let Price;
    (function(Price) {
        function key(pair, block) {
            return result/* Result */.x.runAndWrapSync(()=>({
                    chainId: pair.chainId,
                    method: "eth_call",
                    params: [
                        {
                            to: pair.address,
                            data: encode/* encodeOrThrow */.YM(PairAbi.getReserves.from())
                        },
                        block
                    ]
                })).ok().inner;
        }
        Price.key = key;
        function schema(ethereum, pair, block, storage) {
            const maybeKey = key(pair, block);
            if (maybeKey == null) return;
            const fetcher = (request, more)=>fetched/* Fetched */.F.runOrDoubleWrap(async ()=>{
                    try {
                        const fetched = await service_worker_context/* BgEthereumContext */.H.fetchOrFail(ethereum, request, more);
                        if (fetched.isErr()) return fetched;
                        const returns = tuple/* Tuple */.p.create(uint/* Uint112 */.jZ, uint/* Uint112 */.jZ, uint/* Uint32 */.cf);
                        const [a, b] = decode/* decodeOrThrow */.Dt(returns, fetched.inner).intoOrThrow();
                        const price = computeOrThrow(pair, [
                            a,
                            b
                        ]);
                        return new fetched_data/* Data */.V(price);
                    } catch (e) {
                        return new fail/* Fail */.M(result_errors/* Catched */.$c.from(e));
                    }
                });
            return (0,query/* createQuery */.rP)({
                key: maybeKey,
                fetcher,
                storage
            });
        }
        Price.schema = schema;
        function computeOrThrow(pair, reserves) {
            const decimals0 = mods_chain/* tokenByAddress */.q2[pair.token0].decimals;
            const decimals1 = mods_chain/* tokenByAddress */.q2[pair.token1].decimals;
            const [reserve0, reserve1] = reserves;
            const quantity0 = new types_fixed/* Fixed */.g(reserve0, decimals0);
            const quantity1 = new types_fixed/* Fixed */.g(reserve1, decimals1);
            if (pair.reversed) return quantity0.div(quantity1);
            return quantity1.div(quantity0);
        }
        Price.computeOrThrow = computeOrThrow;
    })(Price = BgPair.Price || (BgPair.Price = {}));
})(BgPair || (BgPair = {}));

;// CONCATENATED MODULE: ./src/mods/background/service_worker/entities/tokens/data.ts










var TokenRef;
(function(TokenRef) {
    function from(token) {
        if (token.type === "native") return NativeTokenRef.from(token);
        if (token.type === "contract") return ContractTokenRef.from(token);
        throw new result_errors/* Panic */.F5();
    }
    TokenRef.from = from;
})(TokenRef || (TokenRef = {}));
var NativeTokenRef;
(function(NativeTokenRef) {
    function from(token) {
        const { uuid, type, chainId } = token;
        return {
            ref: true,
            uuid,
            type,
            chainId
        };
    }
    NativeTokenRef.from = from;
})(NativeTokenRef || (NativeTokenRef = {}));
var ContractTokenRef;
(function(ContractTokenRef) {
    function from(token) {
        const { uuid, type, chainId, address } = token;
        return {
            ref: true,
            uuid,
            type,
            chainId,
            address
        };
    }
    ContractTokenRef.from = from;
})(ContractTokenRef || (ContractTokenRef = {}));
var BgToken;
(function(BgToken) {
    let Balance;
    (function(Balance) {
        function key(address, currency) {
            return "pricedBalanceByToken/".concat(address, "/").concat(currency);
        }
        Balance.key = key;
        function schema(address, currency, storage) {
            const indexer = async (states)=>{
                var _states_current_real;
                const values = option_option/* Option */.W.wrap((_states_current_real = states.current.real) === null || _states_current_real === void 0 ? void 0 : _states_current_real.data).mapSync((d)=>d.inner).unwrapOr({});
                const total = Object.values(values).reduce((x, y)=>types_fixed/* Fixed */.g.from(y).add(x), new types_fixed/* Fixed */.g(0n, 0));
                const totalBalance = data/* BgTotal */.f.Balance.Priced.ByAddress.schema(address, currency, storage);
                await totalBalance.mutate(mutators/* Mutators */.g.data(total));
            };
            return (0,query/* createQuery */.rP)({
                key: key(address, currency),
                indexer,
                storage
            });
        }
        Balance.schema = schema;
    })(Balance = BgToken.Balance || (BgToken.Balance = {}));
    let Native;
    (function(Native) {
        let Balance;
        (function(Balance) {
            let Priced;
            (function(Priced) {
                function key(address, currency, chain) {
                    return {
                        chainId: chain.chainId,
                        method: "eth_getPricedBalance",
                        params: [
                            address,
                            currency
                        ]
                    };
                }
                Priced.key = key;
                function schema(account, coin, ethereum, storage) {
                    const indexer = async (states)=>{
                        var _states_current_real_data, _states_current_real;
                        const key = "".concat(ethereum.chain.chainId);
                        const value = option_option/* Option */.W.wrap((_states_current_real = states.current.real) === null || _states_current_real === void 0 ? void 0 : (_states_current_real_data = _states_current_real.data) === null || _states_current_real_data === void 0 ? void 0 : _states_current_real_data.get()).unwrapOr(new types_fixed/* Fixed */.g(0n, 0));
                        const indexQuery = BgToken.Balance.schema(account, coin, storage);
                        await indexQuery.mutate(mutators/* Mutators */.g.mapInnerData((p)=>({
                                ...p,
                                [key]: value
                            }), new fetched_data/* Data */.V({})));
                    };
                    return (0,query/* createQuery */.rP)({
                        key: key(account, coin, ethereum.chain),
                        indexer,
                        storage
                    });
                }
                Priced.schema = schema;
            })(Priced = Balance.Priced || (Balance.Priced = {}));
            function key(account, block, chain) {
                return {
                    version: 2,
                    chainId: chain.chainId,
                    method: "eth_getBalance",
                    params: [
                        account,
                        block
                    ]
                };
            }
            Balance.key = key;
            async function parseOrThrow(request, ethereum, storage) {
                const [account, block] = request.params;
                return schema(account, block, ethereum, storage);
            }
            Balance.parseOrThrow = parseOrThrow;
            function schema(account, block, context, storage) {
                const fetcher = async (request, more)=>await service_worker_context/* BgEthereumContext */.H.fetchOrFail(context, request, more).then((f)=>f.mapSync((x)=>new types_fixed/* ZeroHexFixed */.B(x, context.chain.token.decimals)));
                const indexer = async (states)=>{
                    var _states_current_real_data, _states_current_real;
                    if (block !== "pending") return;
                    const pricedBalance = await option_option/* Option */.W.wrap((_states_current_real = states.current.real) === null || _states_current_real === void 0 ? void 0 : (_states_current_real_data = _states_current_real.data) === null || _states_current_real_data === void 0 ? void 0 : _states_current_real_data.get()).andThen(async (balance)=>{
                        if (context.chain.token.pairs == null) return new none/* None */.H();
                        let pricedBalance = types_fixed/* Fixed */.g.from(balance);
                        for (const pairAddress of context.chain.token.pairs){
                            const pair = mods_chain/* pairByAddress */.ne[pairAddress];
                            const chain = mods_chain/* chainByChainId */.DH[pair.chainId];
                            const price = BgPair.Price.schema({
                                ...context,
                                chain
                            }, pair, block, storage);
                            const priceState = await (price === null || price === void 0 ? void 0 : price.state);
                            if ((priceState === null || priceState === void 0 ? void 0 : priceState.data) == null) return new none/* None */.H();
                            pricedBalance = pricedBalance.mul(types_fixed/* Fixed */.g.from(priceState.data.get()));
                        }
                        return new some/* Some */.b(pricedBalance);
                    }).then((o)=>o.unwrapOr(new types_fixed/* Fixed */.g(0n, 0)));
                    const pricedBalanceQuery = Priced.schema(account, "usd", context, storage);
                    await pricedBalanceQuery.mutate(mutators/* Mutators */.g.set(new fetched_data/* Data */.V(pricedBalance)));
                };
                return (0,query/* createQuery */.rP)({
                    key: key(account, block, context.chain),
                    fetcher,
                    indexer,
                    storage
                });
            }
            Balance.schema = schema;
        })(Balance = Native.Balance || (Native.Balance = {}));
    })(Native = BgToken.Native || (BgToken.Native = {}));
    let Contract;
    (function(Contract) {
        let All;
        (function(All) {
            All.key = "contractTokens";
            function schema(storage) {
                return (0,query/* createQuery */.rP)({
                    key: All.key,
                    storage
                });
            }
            All.schema = schema;
        })(All = Contract.All || (Contract.All = {}));
        let Balance;
        (function(Balance) {
            let Priced;
            (function(Priced) {
                function key(address, token, currency, chain) {
                    return {
                        chainId: chain.chainId,
                        method: "eth_getTokenPricedBalance",
                        params: [
                            address,
                            token.address,
                            currency
                        ]
                    };
                }
                Priced.key = key;
                function schema(ethereum, account, token, coin, storage) {
                    const indexer = async (states)=>{
                        var _states_current_real_data, _states_current_real;
                        const key = "".concat(ethereum.chain.chainId, "/").concat(token.address);
                        const value = option_option/* Option */.W.wrap((_states_current_real = states.current.real) === null || _states_current_real === void 0 ? void 0 : (_states_current_real_data = _states_current_real.data) === null || _states_current_real_data === void 0 ? void 0 : _states_current_real_data.get()).unwrapOr(new types_fixed/* Fixed */.g(0n, 0));
                        const indexQuery = BgToken.Balance.schema(account, coin, storage);
                        await indexQuery.mutate(mutators/* Mutators */.g.mapInnerData((p)=>({
                                ...p,
                                [key]: value
                            }), new fetched_data/* Data */.V({})));
                    };
                    return (0,query/* createQuery */.rP)({
                        key: key(account, token, coin, ethereum.chain),
                        indexer,
                        storage
                    });
                }
                Priced.schema = schema;
            })(Priced = Balance.Priced || (Balance.Priced = {}));
            function key(account, token, block, chain) {
                return result/* Result */.x.runAndWrapSync(()=>({
                        chainId: chain.chainId,
                        method: "eth_call",
                        params: [
                            {
                                to: token.address,
                                data: encode/* encodeOrThrow */.YM(TokenAbi.balanceOf.from(account))
                            },
                            block
                        ]
                    })).ok().inner;
            }
            Balance.key = key;
            function schema(ethereum, account, token, block, storage) {
                const maybeKey = key(account, token, block, ethereum.chain);
                if (maybeKey == null) return undefined;
                const fetcher = async (request, more)=>{
                    try {
                        const fetched = await service_worker_context/* BgEthereumContext */.H.fetchOrFail(ethereum, request, more);
                        if (fetched.isErr()) return fetched;
                        const returns = tuple/* Tuple */.p.create(uint/* Uint256 */.kq);
                        const [balance] = decode/* decodeOrThrow */.Dt(returns, fetched.inner).inner;
                        const fixed = new types_fixed/* Fixed */.g(balance.intoOrThrow(), token.decimals);
                        return new fetched_data/* Data */.V(fixed);
                    } catch (e) {
                        return new fail/* Fail */.M(result_errors/* Catched */.$c.from(e));
                    }
                };
                const indexer = async (states)=>{
                    var _states_current_real_data, _states_current_real;
                    if (block !== "pending") return;
                    const pricedBalance = await option_option/* Option */.W.wrap((_states_current_real = states.current.real) === null || _states_current_real === void 0 ? void 0 : (_states_current_real_data = _states_current_real.data) === null || _states_current_real_data === void 0 ? void 0 : _states_current_real_data.get()).andThen(async (balance)=>{
                        if (token.pairs == null) return new none/* None */.H();
                        let pricedBalance = types_fixed/* Fixed */.g.from(balance);
                        for (const pairAddress of token.pairs){
                            const pair = mods_chain/* pairByAddress */.ne[pairAddress];
                            const chain = mods_chain/* chainByChainId */.DH[pair.chainId];
                            const price = BgPair.Price.schema({
                                ...ethereum,
                                chain
                            }, pair, block, storage);
                            const priceState = await (price === null || price === void 0 ? void 0 : price.state);
                            if ((priceState === null || priceState === void 0 ? void 0 : priceState.data) == null) return new none/* None */.H();
                            pricedBalance = pricedBalance.mul(types_fixed/* Fixed */.g.from(priceState.data.get()));
                        }
                        return new some/* Some */.b(pricedBalance);
                    }).then((o)=>o.unwrapOr(new types_fixed/* Fixed */.g(0n, 0)));
                    const pricedBalanceQuery = Priced.schema(ethereum, account, token, "usd", storage);
                    await pricedBalanceQuery.mutate(mutators/* Mutators */.g.set(new fetched_data/* Data */.V(pricedBalance)));
                };
                return (0,query/* createQuery */.rP)({
                    key: maybeKey,
                    fetcher,
                    indexer,
                    storage
                });
            }
            Balance.schema = schema;
        })(Balance = Contract.Balance || (Contract.Balance = {}));
        function key(chainId, address) {
            return "contractToken/".concat(chainId, "/").concat(address);
        }
        Contract.key = key;
        function schema(chainId, address, storage) {
            const indexer = async (states)=>{
                var _previous_real_data, _previous_real, _current_real_data, _current_real;
                const { current, previous } = states;
                const previousData = previous === null || previous === void 0 ? void 0 : (_previous_real = previous.real) === null || _previous_real === void 0 ? void 0 : (_previous_real_data = _previous_real.data) === null || _previous_real_data === void 0 ? void 0 : _previous_real_data.get();
                const currentData = (_current_real = current.real) === null || _current_real === void 0 ? void 0 : (_current_real_data = _current_real.data) === null || _current_real_data === void 0 ? void 0 : _current_real_data.get();
                if ((previousData === null || previousData === void 0 ? void 0 : previousData.uuid) === (currentData === null || currentData === void 0 ? void 0 : currentData.uuid)) return;
                if (previousData != null) {
                    var _All_schema;
                    await ((_All_schema = All.schema(storage)) === null || _All_schema === void 0 ? void 0 : _All_schema.mutate(mutators/* Mutators */.g.mapData(function() {
                        let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : new fetched_data/* Data */.V([]);
                        return d.mapSync((p)=>p.filter((x)=>x.uuid !== previousData.uuid));
                    })));
                }
                if (currentData != null) {
                    var _All_schema1;
                    await ((_All_schema1 = All.schema(storage)) === null || _All_schema1 === void 0 ? void 0 : _All_schema1.mutate(mutators/* Mutators */.g.mapData(function() {
                        let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : new fetched_data/* Data */.V([]);
                        return d.mapSync((p)=>[
                                ...p,
                                ContractTokenRef.from(currentData)
                            ]);
                    })));
                }
            };
            return (0,query/* createQuery */.rP)({
                key: key(chainId, address),
                indexer,
                storage
            });
        }
        Contract.schema = schema;
    })(Contract = BgToken.Contract || (BgToken.Contract = {}));
})(BgToken || (BgToken = {}));

// EXTERNAL MODULE: ./src/mods/background/service_worker/entities/wallets/data.ts
var wallets_data = __webpack_require__(6340);
// EXTERNAL MODULE: ./node_modules/react/index.js
var react = __webpack_require__(7294);
// EXTERNAL MODULE: ./src/libs/ui2/page/header.tsx
var header = __webpack_require__(1952);
// EXTERNAL MODULE: ./src/libs/ui2/page/page.tsx
var page = __webpack_require__(3365);
// EXTERNAL MODULE: ./src/mods/foreground/background/context.tsx + 3 modules
var context = __webpack_require__(7028);
// EXTERNAL MODULE: ./src/mods/foreground/router/path/context.tsx
var path_context = __webpack_require__(7921);
// EXTERNAL MODULE: ./src/mods/foreground/entities/names/data.ts + 2 modules
var names_data = __webpack_require__(1023);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/PlusIcon.js
var PlusIcon = __webpack_require__(8680);
// EXTERNAL MODULE: ./src/libs/react/callback.tsx
var callback = __webpack_require__(7174);
// EXTERNAL MODULE: ./src/libs/ui/input.tsx + 4 modules
var input = __webpack_require__(9619);
// EXTERNAL MODULE: ./src/mods/foreground/storage/user.tsx
var user = __webpack_require__(8777);
// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/types/zerohex/index.mjs
var zerohex = __webpack_require__(6113);
// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/abi/signature/signature.mjs + 3 modules
var signature_signature = __webpack_require__(167);
// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/abi/types/string/string.mjs
var string = __webpack_require__(3997);
// EXTERNAL MODULE: ./src/mods/foreground/entities/unknown/data.ts
var unknown_data = __webpack_require__(5234);
// EXTERNAL MODULE: ./src/mods/foreground/entities/wallets/context.tsx
var wallets_context = __webpack_require__(5807);
;// CONCATENATED MODULE: ./src/libs/react/effect.tsx

function useEffectButOnlyFirstTime(callback, deps) {
    const first = useRef(true);
    useEffect(()=>{
        if (first.current) {
            first.current = false;
            return callback();
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, deps);
}
function useEffectButNotFirstTime(callback, deps) {
    const first = (0,react.useRef)(true);
    (0,react.useEffect)(()=>{
        if (first.current) {
            first.current = false;
            return;
        }
        return callback();
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, deps);
}

// EXTERNAL MODULE: ./src/mods/foreground/storage/storage.ts
var storage_storage = __webpack_require__(921);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/react/hooks/queries/simple.mjs + 1 modules
var simple = __webpack_require__(564);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/react/hooks/blocks/use-fetch.mjs
var use_fetch = __webpack_require__(4704);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/react/hooks/blocks/use-visible.mjs
var use_visible = __webpack_require__(7836);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/react/hooks/blocks/use-interval.mjs
var use_interval = __webpack_require__(8995);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/react/hooks/blocks/use-error.mjs
var use_error = __webpack_require__(3399);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/core/core.mjs + 4 modules
var core = __webpack_require__(4952);
// EXTERNAL MODULE: ./src/mods/foreground/entities/wallets/data.ts
var entities_wallets_data = __webpack_require__(9031);
;// CONCATENATED MODULE: ./src/mods/foreground/entities/tokens/pairs/data.ts








var FgPair;
(function(FgPair) {
    let Price;
    (function(Price) {
        Price.key = BgPair.Price.key;
        function schema(pair, block, context, storage) {
            if (context == null) return;
            if (pair == null) return;
            if (block == null) return;
            const maybeKey = Price.key(pair, block);
            if (maybeKey == null) return;
            const fetcher = async function(request) {
                let more = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
                try {
                    const fetched = await (0,entities_wallets_data/* fetchOrFail */.yR)(request, context);
                    if (fetched.isErr()) return fetched;
                    const returns = tuple/* Tuple */.p.create(uint/* Uint112 */.jZ, uint/* Uint112 */.jZ, uint/* Uint32 */.cf);
                    const [a, b] = decode/* decodeOrThrow */.Dt(returns, fetched.inner).intoOrThrow();
                    const price = BgPair.Price.computeOrThrow(pair, [
                        a,
                        b
                    ]);
                    return new fetched_data/* Data */.V(price);
                } catch (e) {
                    return new fail/* Fail */.M(result_errors/* Catched */.$c.from(e));
                }
            };
            return (0,query/* createQuery */.rP)({
                key: maybeKey,
                fetcher,
                storage
            });
        }
        Price.schema = schema;
    })(Price = FgPair.Price || (FgPair.Price = {}));
})(FgPair || (FgPair = {}));
function usePairPrice(pair, block, context) {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(FgPair.Price.schema, [
        pair,
        block,
        context,
        storage
    ]);
    (0,use_fetch/* useFetch */.i)(query);
    (0,use_visible/* useVisible */.E)(query);
    (0,storage_storage/* useSubscribe */.Q)(query, storage);
    (0,use_error/* useError */.V)(query, errors/* Errors */.D.onQueryError);
    return query;
}

;// CONCATENATED MODULE: ./src/mods/foreground/entities/tokens/data.ts














var FgToken;
(function(FgToken) {
    let Balance;
    (function(Balance) {
        Balance.key = BgToken.Balance.key;
        function schema(address, currency, storage) {
            if (address == null) return;
            const indexer = async (states)=>{
                var _states_current_real;
                const values = option_option/* Option */.W.wrap((_states_current_real = states.current.real) === null || _states_current_real === void 0 ? void 0 : _states_current_real.data).mapSync((d)=>d.inner).unwrapOr({});
                const total = Object.values(values).reduce((x, y)=>types_fixed/* Fixed */.g.from(y).add(x), new types_fixed/* Fixed */.g(0n, 0));
                const totalBalance = unknown_data/* FgTotal */.Q6.Balance.Priced.ByAddress.schema(address, currency, storage);
                await (totalBalance === null || totalBalance === void 0 ? void 0 : totalBalance.mutate(mutators/* Mutators */.g.data(total)));
            };
            return (0,query/* createQuery */.rP)({
                key: Balance.key(address, currency),
                indexer,
                storage
            });
        }
        Balance.schema = schema;
    })(Balance = FgToken.Balance || (FgToken.Balance = {}));
    let Native;
    (function(Native) {
        let Balance;
        (function(Balance) {
            let Priced;
            (function(Priced) {
                Priced.key = BgToken.Native.Balance.Priced.key;
                function schema(address, coin, context, storage) {
                    if (context == null) return;
                    if (address == null) return;
                    const indexer = async (states)=>{
                        var _states_current_real_data, _states_current_real;
                        const key = "".concat(context.chain.chainId);
                        const value = option_option/* Option */.W.wrap((_states_current_real = states.current.real) === null || _states_current_real === void 0 ? void 0 : (_states_current_real_data = _states_current_real.data) === null || _states_current_real_data === void 0 ? void 0 : _states_current_real_data.get()).unwrapOr(new types_fixed/* Fixed */.g(0n, 0));
                        const indexQuery = FgToken.Balance.schema(address, coin, storage);
                        await (indexQuery === null || indexQuery === void 0 ? void 0 : indexQuery.mutate(mutators/* Mutators */.g.mapInnerData((p)=>({
                                ...p,
                                [key]: value
                            }), new fetched_data/* Data */.V({}))));
                    };
                    return (0,query/* createQuery */.rP)({
                        key: Priced.key(address, coin, context.chain),
                        indexer,
                        storage
                    });
                }
                Priced.schema = schema;
            })(Priced = Balance.Priced || (Balance.Priced = {}));
            Balance.key = BgToken.Native.Balance.key;
            function schema(address, block, context, storage) {
                if (address == null) return;
                if (context == null) return;
                if (block == null) return;
                const fetcher = async function(request) {
                    let more = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
                    return await (0,entities_wallets_data/* fetchOrFail */.yR)(request, context).then((f)=>f.mapSync((x)=>new types_fixed/* ZeroHexFixed */.B(x, context.chain.token.decimals)));
                };
                const indexer = async (states)=>{
                    var _states_current_real_data, _states_current_real;
                    if (block !== "pending") return;
                    const pricedBalance = await option_option/* Option */.W.wrap((_states_current_real = states.current.real) === null || _states_current_real === void 0 ? void 0 : (_states_current_real_data = _states_current_real.data) === null || _states_current_real_data === void 0 ? void 0 : _states_current_real_data.get()).andThen(async (balance)=>{
                        if (context.chain.token.pairs == null) return new none/* None */.H();
                        let pricedBalance = types_fixed/* Fixed */.g.from(balance);
                        for (const pairAddress of context.chain.token.pairs){
                            const pair = mods_chain/* pairByAddress */.ne[pairAddress];
                            const chain = mods_chain/* chainByChainId */.DH[pair.chainId];
                            const price = FgPair.Price.schema(pair, block, {
                                ...context,
                                chain
                            }, storage);
                            const priceState = await (price === null || price === void 0 ? void 0 : price.state);
                            if ((priceState === null || priceState === void 0 ? void 0 : priceState.data) == null) return new none/* None */.H();
                            pricedBalance = pricedBalance.mul(types_fixed/* Fixed */.g.from(priceState.data.get()));
                        }
                        return new some/* Some */.b(pricedBalance);
                    }).then((o)=>o.unwrapOr(new types_fixed/* Fixed */.g(0n, 0)));
                    const pricedBalanceQuery = Priced.schema(address, "usd", context, storage);
                    await (pricedBalanceQuery === null || pricedBalanceQuery === void 0 ? void 0 : pricedBalanceQuery.mutate(mutators/* Mutators */.g.set(new fetched_data/* Data */.V(pricedBalance))));
                };
                return (0,query/* createQuery */.rP)({
                    key: Balance.key(address, block, context.chain),
                    fetcher,
                    indexer,
                    storage
                });
            }
            Balance.schema = schema;
        })(Balance = Native.Balance || (Native.Balance = {}));
    })(Native = FgToken.Native || (FgToken.Native = {}));
    let Contract;
    (function(Contract) {
        let Balance;
        (function(Balance) {
            let Priced;
            (function(Priced) {
                Priced.key = BgToken.Contract.Balance.Priced.key;
                function schema(account, token, coin, context, storage) {
                    if (context == null) return;
                    if (account == null) return;
                    if (token == null) return;
                    const indexer = async (states)=>{
                        var _states_current_real_data, _states_current_real;
                        const key = "".concat(context.chain.chainId, "/").concat(token.address);
                        const value = option_option/* Option */.W.wrap((_states_current_real = states.current.real) === null || _states_current_real === void 0 ? void 0 : (_states_current_real_data = _states_current_real.data) === null || _states_current_real_data === void 0 ? void 0 : _states_current_real_data.get()).unwrapOr(new types_fixed/* Fixed */.g(0n, 0));
                        const indexQuery = FgToken.Balance.schema(account, coin, storage);
                        await (indexQuery === null || indexQuery === void 0 ? void 0 : indexQuery.mutate(mutators/* Mutators */.g.mapInnerData((p)=>({
                                ...p,
                                [key]: value
                            }), new fetched_data/* Data */.V({}))));
                    };
                    return (0,query/* createQuery */.rP)({
                        key: Priced.key(account, token, coin, context.chain),
                        indexer,
                        storage
                    });
                }
                Priced.schema = schema;
            })(Priced = Balance.Priced || (Balance.Priced = {}));
            Balance.key = BgToken.Contract.Balance.key;
            function schema(address, token, block, context, storage) {
                if (address == null) return;
                if (token == null) return;
                if (context == null) return;
                if (block == null) return;
                const maybeKey = Balance.key(address, token, block, context.chain);
                if (maybeKey == null) return;
                const fetcher = async function(request) {
                    let more = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
                    try {
                        const fetched = await (0,entities_wallets_data/* fetchOrFail */.yR)(request, context);
                        if (fetched.isErr()) return fetched;
                        const returns = tuple/* Tuple */.p.create(uint/* Uint256 */.kq);
                        const [balance] = decode/* decodeOrThrow */.Dt(returns, fetched.inner).inner;
                        const fixed = new types_fixed/* Fixed */.g(balance.intoOrThrow(), token.decimals);
                        return new fetched_data/* Data */.V(fixed);
                    } catch (e) {
                        return new fail/* Fail */.M(result_errors/* Catched */.$c.from(e));
                    }
                };
                const indexer = async (states)=>{
                    var _states_current_real_data, _states_current_real;
                    if (block !== "pending") return;
                    const pricedBalance = await option_option/* Option */.W.wrap((_states_current_real = states.current.real) === null || _states_current_real === void 0 ? void 0 : (_states_current_real_data = _states_current_real.data) === null || _states_current_real_data === void 0 ? void 0 : _states_current_real_data.get()).andThen(async (balance)=>{
                        if (token.pairs == null) return new none/* None */.H();
                        let pricedBalance = types_fixed/* Fixed */.g.from(balance);
                        for (const pairAddress of token.pairs){
                            const pair = mods_chain/* pairByAddress */.ne[pairAddress];
                            const chain = mods_chain/* chainByChainId */.DH[pair.chainId];
                            const price = FgPair.Price.schema(pair, block, {
                                ...context,
                                chain
                            }, storage);
                            const priceState = await (price === null || price === void 0 ? void 0 : price.state);
                            if ((priceState === null || priceState === void 0 ? void 0 : priceState.data) == null) return new none/* None */.H();
                            pricedBalance = pricedBalance.mul(types_fixed/* Fixed */.g.from(priceState.data.get()));
                        }
                        return new some/* Some */.b(pricedBalance);
                    }).then((o)=>o.unwrapOr(new types_fixed/* Fixed */.g(0n, 0)));
                    const pricedBalanceQuery = Priced.schema(address, token, "usd", context, storage);
                    await (pricedBalanceQuery === null || pricedBalanceQuery === void 0 ? void 0 : pricedBalanceQuery.mutate(mutators/* Mutators */.g.set(new fetched_data/* Data */.V(pricedBalance))));
                };
                return (0,query/* createQuery */.rP)({
                    key: maybeKey,
                    fetcher,
                    indexer,
                    storage
                });
            }
            Balance.schema = schema;
        })(Balance = Contract.Balance || (Contract.Balance = {}));
        let All;
        (function(All) {
            All.key = BgToken.Contract.All.key;
            function schema(storage) {
                return (0,query/* createQuery */.rP)({
                    key: All.key,
                    storage
                });
            }
            All.schema = schema;
        })(All = Contract.All || (Contract.All = {}));
        Contract.key = BgToken.Contract.key;
        function schema(chainId, address, storage) {
            if (chainId == null) return;
            if (address == null) return;
            const indexer = async (states)=>{
                var _previous_real_data, _previous_real, _current_real_data, _current_real;
                const { current, previous } = states;
                const previousData = previous === null || previous === void 0 ? void 0 : (_previous_real = previous.real) === null || _previous_real === void 0 ? void 0 : (_previous_real_data = _previous_real.data) === null || _previous_real_data === void 0 ? void 0 : _previous_real_data.get();
                const currentData = (_current_real = current.real) === null || _current_real === void 0 ? void 0 : (_current_real_data = _current_real.data) === null || _current_real_data === void 0 ? void 0 : _current_real_data.get();
                if ((previousData === null || previousData === void 0 ? void 0 : previousData.uuid) === (currentData === null || currentData === void 0 ? void 0 : currentData.uuid)) return;
                if (previousData != null) {
                    var _All_schema;
                    await ((_All_schema = All.schema(storage)) === null || _All_schema === void 0 ? void 0 : _All_schema.mutate(mutators/* Mutators */.g.mapData(function() {
                        let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : new fetched_data/* Data */.V([]);
                        return d.mapSync((p)=>p.filter((x)=>x.uuid !== previousData.uuid));
                    })));
                }
                if (currentData != null) {
                    var _All_schema1;
                    await ((_All_schema1 = All.schema(storage)) === null || _All_schema1 === void 0 ? void 0 : _All_schema1.mutate(mutators/* Mutators */.g.mapData(function() {
                        let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : new fetched_data/* Data */.V([]);
                        return d.mapSync((p)=>[
                                ...p,
                                ContractTokenRef.from(currentData)
                            ]);
                    })));
                }
            };
            return (0,query/* createQuery */.rP)({
                key: Contract.key(chainId, address),
                indexer,
                storage
            });
        }
        Contract.schema = schema;
    })(Contract = FgToken.Contract || (FgToken.Contract = {}));
})(FgToken || (FgToken = {}));
function useToken(chainId, address) {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(FgToken.Contract.schema, [
        chainId,
        address,
        storage
    ]);
    (0,storage_storage/* useSubscribe */.Q)(query, storage);
    return query;
}
function useTokens() {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(FgToken.Contract.All.schema, [
        storage
    ]);
    (0,storage_storage/* useSubscribe */.Q)(query, storage);
    return query;
}
function useNativeBalance(address, block, context, prices) {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(FgToken.Native.Balance.schema, [
        address,
        block,
        context,
        storage
    ]);
    (0,use_fetch/* useFetch */.i)(query);
    (0,use_visible/* useVisible */.E)(query);
    (0,use_interval/* useInterval */.Y)(query, 10 * 1000);
    (0,storage_storage/* useSubscribe */.Q)(query, storage);
    (0,use_error/* useError */.V)(query, errors/* Errors */.D.onQueryError);
    useEffectButNotFirstTime(()=>{
        if (context == null) return;
        if (query.cacheKey == null) return;
        core/* core */.vE.reindexOrThrow(query.cacheKey, query).catch(console.warn);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        context,
        prices
    ]);
    return query;
}
function useContractBalance(address, token, block, context, prices) {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(FgToken.Contract.Balance.schema, [
        address,
        token,
        block,
        context,
        storage
    ]);
    (0,use_fetch/* useFetch */.i)(query);
    (0,use_visible/* useVisible */.E)(query);
    (0,use_interval/* useInterval */.Y)(query, 10 * 1000);
    (0,storage_storage/* useSubscribe */.Q)(query, storage);
    (0,use_error/* useError */.V)(query, errors/* Errors */.D.onQueryError);
    useEffectButNotFirstTime(()=>{
        if (context == null) return;
        if (query.cacheKey == null) return;
        core/* core */.vE.reindexOrThrow(query.cacheKey, query).catch(console.warn);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        context,
        prices
    ]);
    return query;
}
function useNativePricedBalance(address, coin, context) {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(FgToken.Native.Balance.Priced.schema, [
        address,
        coin,
        context,
        storage
    ]);
    (0,storage_storage/* useSubscribe */.Q)(query, storage);
    return query;
}
function useContractPricedBalance(address, token, coin, context) {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(FgToken.Contract.Balance.Priced.schema, [
        address,
        token,
        coin,
        context,
        storage
    ]);
    (0,storage_storage/* useSubscribe */.Q)(query, storage);
    return query;
}

;// CONCATENATED MODULE: ./src/mods/foreground/entities/tokens/add/dialog.tsx




















function TokenAddDialog(props) {
    const close = (0,dialog/* useCloseContext */.gX)().unwrap();
    const wallet = (0,wallets_context/* useWalletDataContext */.zI)().unwrap();
    const background = (0,context/* useBackgroundContext */.D_)().unwrap();
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const [chain, setChain] = (0,react.useState)(mods_chain/* chainByChainId */.DH[1]);
    const [rawAddress = "", setRawAddress] = (0,react.useState)();
    const defAddress = (0,react.useDeferredValue)(rawAddress);
    const onAddressChange = (0,events/* useInputChange */.Xy)((e)=>{
        setRawAddress(e.currentTarget.value);
    }, []);
    const token = useToken(chain.chainId, defAddress);
    const onAddClick = (0,callback/* useAsyncUniqueCallback */.T)(async ()=>{
        return await result/* Result */.x.unthrow(async (t)=>{
            if (!zerohex/* ZeroHexString */.T.is(defAddress)) return new err/* Err */.U(new errors/* UIError */.m("Invalid address"));
            const name = await result/* Result */.x.unthrow(async (t)=>{
                const context = {
                    uuid: wallet.uuid,
                    background,
                    chain
                };
                const signature = signature_signature/* FunctionSignature */.I.tryParse("name()").throw(t);
                const data = encode/* tryEncode */.eK(signature.from()).throw(t);
                const schema = unknown_data/* FgEthereum */.qK.Unknown.schema({
                    method: "eth_call",
                    params: [
                        {
                            to: defAddress,
                            data: data
                        },
                        "pending"
                    ]
                }, context, storage);
                if (schema == null) throw new result_errors/* Panic */.F5();
                const result = await schema.refetch().then((r)=>{
                    var _r_real;
                    return (_r_real = r.real) === null || _r_real === void 0 ? void 0 : _r_real.current.throw(t);
                });
                const returns = tuple/* Tuple */.p.create(string/* String */.L);
                const [name] = decode/* tryDecode */.bB(returns, result).throw(t).intoOrThrow();
                return new ok.Ok(name);
            }).then((r)=>r.throw(t));
            const symbol = await result/* Result */.x.unthrow(async (t)=>{
                const context = {
                    uuid: wallet.uuid,
                    background,
                    chain
                };
                const signature = signature_signature/* FunctionSignature */.I.tryParse("symbol()").throw(t);
                const data = encode/* tryEncode */.eK(signature.from()).throw(t);
                const schema = unknown_data/* FgEthereum */.qK.Unknown.schema({
                    method: "eth_call",
                    params: [
                        {
                            to: defAddress,
                            data: data
                        },
                        "pending"
                    ]
                }, context, storage);
                if (schema == null) throw new result_errors/* Panic */.F5();
                const result = await schema.refetch().then((r)=>{
                    var _r_real;
                    return (_r_real = r.real) === null || _r_real === void 0 ? void 0 : _r_real.current.throw(t);
                });
                const returns = tuple/* Tuple */.p.create(string/* String */.L);
                const [symbol] = decode/* tryDecode */.bB(returns, result).throw(t).intoOrThrow();
                return new ok.Ok(symbol);
            }).then((r)=>r.throw(t));
            const decimals = await result/* Result */.x.unthrow(async (t)=>{
                const context = {
                    uuid: wallet.uuid,
                    background,
                    chain
                };
                const signature = signature_signature/* FunctionSignature */.I.tryParse("decimals()").throw(t);
                const data = encode/* tryEncode */.eK(signature.from()).throw(t);
                const schema = unknown_data/* FgEthereum */.qK.Unknown.schema({
                    method: "eth_call",
                    params: [
                        {
                            to: defAddress,
                            data: data
                        },
                        "pending"
                    ]
                }, context, storage);
                if (schema == null) throw new result_errors/* Panic */.F5();
                const result = await schema.refetch().then((r)=>{
                    var _r_real;
                    return (_r_real = r.real) === null || _r_real === void 0 ? void 0 : _r_real.current.throw(t);
                });
                const returns = tuple/* Tuple */.p.create(uint/* Uint8 */.bz);
                const [decimals] = decode/* tryDecode */.bB(returns, result).throw(t).intoOrThrow();
                return new ok.Ok(Number(decimals));
            }).then((r)=>r.throw(t));
            await token.mutate((s)=>{
                const data = new fetched_data/* Data */.V({
                    uuid: crypto.randomUUID(),
                    type: "contract",
                    chainId: chain.chainId,
                    address: defAddress,
                    name: name,
                    symbol: symbol,
                    decimals: decimals
                });
                return new some/* Some */.b(data);
            });
            close();
            return ok.Ok.void();
        }).then(results/* Results */.u.logAndAlert);
    }, [
        background,
        close,
        chain,
        defAddress
    ]);
    const addDisabled = (0,react.useMemo)(()=>{
        if (!defAddress) return "Please enter an address";
        return;
    }, [
        defAddress
    ]);
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Dialog */.Vq.Title, {
                close: close,
                children: "New token"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-2"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "flex flex-wrap items-center overflow-hidden gap-2",
                children: Object.values(mods_chain/* chainByChainId */.DH).map((x)=>/*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                        className: "".concat(ui_button/* Button.Base */.z.XY.className, " po-sm border border-contrast shrink-0 data-[selected=true]:border-opposite transition-colors"),
                        onClick: ()=>setChain(x),
                        "data-selected": chain === x,
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
                            children: x.name
                        })
                    }, x.chainId))
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-2"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)(input/* Input.Contrast */.I.mn, {
                className: "w-full",
                placeholder: "Contract address",
                value: rawAddress,
                onChange: onAddressChange
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-4"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.Gradient */.z.ph, {
                className: "w-full po-md",
                colorIndex: wallet.color,
                disabled: Boolean(addDisabled),
                onClick: onAddClick.run,
                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                    className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime.jsx)(PlusIcon/* default */.Z, {
                            className: "size-5"
                        }),
                        addDisabled || "Send"
                    ]
                })
            })
        ]
    });
}

// EXTERNAL MODULE: ./src/libs/copy/copy.tsx
var copy = __webpack_require__(2306);
// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/types/address/index.mjs
var types_address = __webpack_require__(7657);
// EXTERNAL MODULE: ./node_modules/@paulmillr/qr/index.js
var qr = __webpack_require__(3181);
;// CONCATENATED MODULE: ./src/mods/foreground/entities/wallets/actions/receive/receive.tsx
/* eslint-disable @next/next/no-img-element */ 








function WalletDataReceiveScreen(props) {
    const close = (0,dialog/* useCloseContext */.gX)().unwrap();
    const wallet = (0,wallets_context/* useWalletDataContext */.zI)().unwrap();
    const address = (0,react.useMemo)(()=>{
        return types_address/* Address */.k.from(wallet.address);
    }, [
        wallet.address
    ]);
    const url = (0,react.useMemo)(()=>{
        const bytes = (0,qr/* default */.ZP)(address, "gif", {
            ecc: "medium",
            scale: 10
        });
        const blob = new Blob([
            bytes
        ], {
            type: "image/gif"
        });
        return URL.createObjectURL(blob);
    }, [
        address
    ]);
    const onCopyClick = (0,copy/* useCopy */.F)(address);
    const onShareClick = (0,react.useCallback)(async ()=>{
        await result/* Result */.x.runAndWrap(async ()=>{
            await navigator.share({
                text: address
            });
        }).then((r)=>r.ignore());
    }, [
        address
    ]);
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Dialog */.Vq.Title, {
                close: close,
                children: "Receive"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "grow flex flex-col items-center justify-center",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "text-xl font-medium",
                        children: wallet.name
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                        className: "text-contrast text-center cursor-pointer",
                        onClick: onCopyClick.run,
                        children: onCopyClick.current ? "Copied" : types_address/* Address */.k.format(address)
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-4"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "bg-white rounded-xl p-1",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("img", {
                            className: "",
                            alt: "QR code",
                            src: url
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-4"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "text-contrast text-center max-w-xs",
                        children: "This is an Ethereum address, only send Ethereum-compatible stuff to this address"
                    })
                ]
            }),
            typeof navigator.share === "function" && /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                className: "".concat(ui_button/* Button.Base */.z.XY.className, " ").concat(ui_button/* Button.Contrast */.z.mn.className, " bg-high-contrast po-md"),
                onClick: onShareClick,
                children: "Share"
            })
        ]
    });
}

// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/ClipboardIcon.js
var ClipboardIcon = __webpack_require__(3306);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/XMarkIcon.js
var XMarkIcon = __webpack_require__(1415);
// EXTERNAL MODULE: ./src/libs/react/ref.ts + 1 modules
var ref = __webpack_require__(5351);
// EXTERNAL MODULE: ./src/libs/url/url.ts
var url = __webpack_require__(5731);
;// CONCATENATED MODULE: ./src/libs/glacier/hooks.ts

/**
 * Do a request on interval until data is available
 * @see useRetry for error retry
 * @param query
 * @param interval
 */ function useWait(query, interval) {
    const { fetcher, ready, data, fetch } = query;
    (0,react.useEffect)(()=>{
        if (!ready) return;
        if (fetcher == null) return;
        if (!interval) return;
        if (data != null) return;
        const f = ()=>fetch().catch(console.warn);
        const i = setInterval(f, interval);
        return ()=>clearInterval(i);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        ready,
        data,
        fetch,
        interval
    ]);
}

;// CONCATENATED MODULE: ./src/mods/background/service_worker/entities/transactions/data.tsx



var TransactionRef;
(function(TransactionRef) {
    function create(uuid) {
        return {
            ref: true,
            uuid
        };
    }
    TransactionRef.create = create;
    function from(tx) {
        return create(tx.uuid);
    }
    TransactionRef.from = from;
})(TransactionRef || (TransactionRef = {}));
var TransactionTrialRef;
(function(TransactionTrialRef) {
    function create(uuid) {
        return {
            ref: true,
            uuid
        };
    }
    TransactionTrialRef.create = create;
    function from(tx) {
        return create(tx.uuid);
    }
    TransactionTrialRef.from = from;
})(TransactionTrialRef || (TransactionTrialRef = {}));
var BgTransaction;
(function(BgTransaction) {
    let All;
    (function(All) {
        let ByAddress;
        (function(ByAddress) {
            function key(address) {
                return "transaction/v0/all/byAddress/".concat(address);
            }
            ByAddress.key = key;
            function schema(address, storage) {
                return (0,query/* createQuery */.rP)({
                    key: key(address),
                    storage
                });
            }
            ByAddress.schema = schema;
        })(ByAddress = All.ByAddress || (All.ByAddress = {}));
    })(All = BgTransaction.All || (BgTransaction.All = {}));
    function key(uuid) {
        return "transaction/v0/".concat(uuid);
    }
    BgTransaction.key = key;
    function schema(uuid, storage) {
        const indexer = async (states)=>{
            var _previous_real_data, _previous_real, _current_real_data, _current_real;
            const { current, previous } = states;
            const previousData = previous === null || previous === void 0 ? void 0 : (_previous_real = previous.real) === null || _previous_real === void 0 ? void 0 : (_previous_real_data = _previous_real.data) === null || _previous_real_data === void 0 ? void 0 : _previous_real_data.get();
            const currentData = (_current_real = current.real) === null || _current_real === void 0 ? void 0 : (_current_real_data = _current_real.data) === null || _current_real_data === void 0 ? void 0 : _current_real_data.get();
            if ((previousData === null || previousData === void 0 ? void 0 : previousData.uuid) !== (currentData === null || currentData === void 0 ? void 0 : currentData.uuid)) {
                if (previousData != null) {
                    var _BgTransactionTrial_schema, _All_ByAddress_schema;
                    await ((_BgTransactionTrial_schema = BgTransactionTrial.schema(previousData.trial.uuid, storage)) === null || _BgTransactionTrial_schema === void 0 ? void 0 : _BgTransactionTrial_schema.mutate((s)=>{
                        var _s_real;
                        const current = (_s_real = s.real) === null || _s_real === void 0 ? void 0 : _s_real.current;
                        if (current == null) return new none/* None */.H();
                        if (current.isErr()) return new none/* None */.H();
                        return new some/* Some */.b(current.mapSync((d)=>({
                                ...d,
                                transactions: d.transactions.filter((t)=>t.uuid !== uuid)
                            })));
                    }));
                    await ((_All_ByAddress_schema = All.ByAddress.schema(previousData.params.from, storage)) === null || _All_ByAddress_schema === void 0 ? void 0 : _All_ByAddress_schema.mutate((s)=>{
                        var _s_real;
                        const current = (_s_real = s.real) === null || _s_real === void 0 ? void 0 : _s_real.current;
                        if (current == null) return new none/* None */.H();
                        if (current.isErr()) return new none/* None */.H();
                        return new some/* Some */.b(current.mapSync((d)=>d.filter((t)=>t.uuid !== uuid)));
                    }));
                }
                if (currentData != null) {
                    var _All_ByAddress_schema1;
                    await BgTransactionTrial.schema(currentData.trial.uuid, storage).mutate((s)=>{
                        var _s_real;
                        const current = (_s_real = s.real) === null || _s_real === void 0 ? void 0 : _s_real.current;
                        if (current == null) {
                            const uuid = currentData.trial.uuid;
                            const nonce = currentData.params.nonce;
                            const transactions = [
                                TransactionRef.from(currentData)
                            ];
                            const inner = {
                                type: "draft",
                                uuid,
                                nonce,
                                transactions
                            };
                            return new some/* Some */.b(new fetched_data/* Data */.V(inner));
                        }
                        if (current.isErr()) return new none/* None */.H();
                        return new some/* Some */.b(current.mapSync((d)=>({
                                ...d,
                                transactions: [
                                    ...d.transactions,
                                    TransactionRef.from(currentData)
                                ]
                            })));
                    });
                    await ((_All_ByAddress_schema1 = All.ByAddress.schema(currentData.params.from, storage)) === null || _All_ByAddress_schema1 === void 0 ? void 0 : _All_ByAddress_schema1.mutate((s)=>{
                        var _s_real;
                        const current = (_s_real = s.real) === null || _s_real === void 0 ? void 0 : _s_real.current;
                        if (current == null) return new some/* Some */.b(new fetched_data/* Data */.V([
                            TransactionRef.from(currentData)
                        ]));
                        if (current.isErr()) return new none/* None */.H();
                        return new some/* Some */.b(current.mapSync((d)=>[
                                ...d,
                                TransactionRef.from(currentData)
                            ]));
                    }));
                }
            }
            if ((currentData === null || currentData === void 0 ? void 0 : currentData.type) === "executed") {
                await BgTransactionTrial.schema(currentData.trial.uuid, storage).mutate((s)=>{
                    var _s_real;
                    const current = (_s_real = s.real) === null || _s_real === void 0 ? void 0 : _s_real.current;
                    if (current == null) return new none/* None */.H();
                    if (current.isErr()) return new none/* None */.H();
                    return new some/* Some */.b(current.mapSync((d)=>({
                            ...d,
                            transaction: TransactionRef.from(currentData)
                        })));
                });
            }
        };
        return (0,query/* createQuery */.rP)({
            key: key(uuid),
            storage,
            indexer
        });
    }
    BgTransaction.schema = schema;
})(BgTransaction || (BgTransaction = {}));
var BgTransactionTrial;
(function(BgTransactionTrial) {
    let All;
    (function(All) {
        let ByAddress;
        (function(ByAddress) {
            function key(address) {
                return "transactionTrial/v0/all/byAddress/".concat(address);
            }
            ByAddress.key = key;
            function schema(address, storage) {
                return (0,query/* createQuery */.rP)({
                    key: key(address),
                    storage
                });
            }
            ByAddress.schema = schema;
        })(ByAddress = All.ByAddress || (All.ByAddress = {}));
    })(All = BgTransactionTrial.All || (BgTransactionTrial.All = {}));
    function key(uuid) {
        return "transactionTrial/v0/".concat(uuid);
    }
    BgTransactionTrial.key = key;
    function schema(uuid, storage) {
        return (0,query/* createQuery */.rP)({
            key: key(uuid),
            storage
        });
    }
    BgTransactionTrial.schema = schema;
})(BgTransactionTrial || (BgTransactionTrial = {}));
var BgTransactionReceipt;
(function(BgTransactionReceipt) {
    function key(hash, chain) {
        return {
            chainId: chain.chainId,
            method: "eth_getTransactionReceipt",
            params: [
                hash
            ],
            noCheck: true
        };
    }
    BgTransactionReceipt.key = key;
    function schema(uuid, hash, ethereum, storage) {
        const fetcher = async (request, more)=>await service_worker_context/* BgEthereumContext */.H.fetchOrFail(ethereum, request, more);
        const indexer = async (states)=>{
            var _previous_real_data, _previous_real, _current_real_data, _current_real;
            const { current, previous } = states;
            const previousData = previous === null || previous === void 0 ? void 0 : (_previous_real = previous.real) === null || _previous_real === void 0 ? void 0 : (_previous_real_data = _previous_real.data) === null || _previous_real_data === void 0 ? void 0 : _previous_real_data.get();
            const currentData = (_current_real = current.real) === null || _current_real === void 0 ? void 0 : (_current_real_data = _current_real.data) === null || _current_real_data === void 0 ? void 0 : _current_real_data.get();
            if (previousData == null && currentData != null) {
                var _BgTransaction_schema;
                await ((_BgTransaction_schema = BgTransaction.schema(uuid, storage)) === null || _BgTransaction_schema === void 0 ? void 0 : _BgTransaction_schema.mutate((s)=>{
                    var _s_real;
                    const current = (_s_real = s.real) === null || _s_real === void 0 ? void 0 : _s_real.current;
                    if (current == null) return new none/* None */.H();
                    if (current.isErr()) return new none/* None */.H();
                    return new some/* Some */.b(current.mapSync((d)=>({
                            ...d,
                            type: "executed",
                            receipt: currentData
                        })));
                }));
            }
        };
        return (0,query/* createQuery */.rP)({
            key: key(hash, ethereum.chain),
            fetcher,
            indexer,
            storage
        });
    }
    BgTransactionReceipt.schema = schema;
})(BgTransactionReceipt || (BgTransactionReceipt = {}));

;// CONCATENATED MODULE: ./src/mods/foreground/entities/transactions/data.ts








var FgTransaction;
(function(FgTransaction) {
    let All;
    (function(All) {
        let ByAddress;
        (function(ByAddress) {
            ByAddress.key = BgTransaction.All.ByAddress.key;
            function schema(address, storage) {
                if (address == null) return;
                return (0,query/* createQuery */.rP)({
                    key: ByAddress.key(address),
                    storage
                });
            }
            ByAddress.schema = schema;
        })(ByAddress = All.ByAddress || (All.ByAddress = {}));
    })(All = FgTransaction.All || (FgTransaction.All = {}));
    FgTransaction.key = BgTransaction.key;
    function schema(uuid, storage) {
        if (uuid == null) return;
        const indexer = async (states)=>{
            var _previous_real_data, _previous_real, _current_real_data, _current_real;
            const { current, previous } = states;
            const previousData = previous === null || previous === void 0 ? void 0 : (_previous_real = previous.real) === null || _previous_real === void 0 ? void 0 : (_previous_real_data = _previous_real.data) === null || _previous_real_data === void 0 ? void 0 : _previous_real_data.get();
            const currentData = (_current_real = current.real) === null || _current_real === void 0 ? void 0 : (_current_real_data = _current_real.data) === null || _current_real_data === void 0 ? void 0 : _current_real_data.get();
            if ((previousData === null || previousData === void 0 ? void 0 : previousData.uuid) !== (currentData === null || currentData === void 0 ? void 0 : currentData.uuid)) {
                if (previousData != null) {
                    var _FgTransactionTrial_schema, _All_ByAddress_schema;
                    await ((_FgTransactionTrial_schema = FgTransactionTrial.schema(previousData.trial.uuid, storage)) === null || _FgTransactionTrial_schema === void 0 ? void 0 : _FgTransactionTrial_schema.mutate((s)=>{
                        var _s_real;
                        const current = (_s_real = s.real) === null || _s_real === void 0 ? void 0 : _s_real.current;
                        if (current == null) return new none/* None */.H();
                        if (current.isErr()) return new none/* None */.H();
                        return new some/* Some */.b(current.mapSync((d)=>({
                                ...d,
                                transactions: d.transactions.filter((t)=>t.uuid !== uuid)
                            })));
                    }));
                    await ((_All_ByAddress_schema = All.ByAddress.schema(previousData.params.from, storage)) === null || _All_ByAddress_schema === void 0 ? void 0 : _All_ByAddress_schema.mutate((s)=>{
                        var _s_real;
                        const current = (_s_real = s.real) === null || _s_real === void 0 ? void 0 : _s_real.current;
                        if (current == null) return new none/* None */.H();
                        if (current.isErr()) return new none/* None */.H();
                        return new some/* Some */.b(current.mapSync((d)=>d.filter((t)=>t.uuid !== uuid)));
                    }));
                }
                if (currentData != null) {
                    var _FgTransactionTrial_schema1, _All_ByAddress_schema1;
                    await ((_FgTransactionTrial_schema1 = FgTransactionTrial.schema(currentData.trial.uuid, storage)) === null || _FgTransactionTrial_schema1 === void 0 ? void 0 : _FgTransactionTrial_schema1.mutate((s)=>{
                        var _s_real;
                        const current = (_s_real = s.real) === null || _s_real === void 0 ? void 0 : _s_real.current;
                        if (current == null) {
                            const uuid = currentData.trial.uuid;
                            const nonce = currentData.params.nonce;
                            const transactions = [
                                TransactionRef.from(currentData)
                            ];
                            const inner = {
                                type: "draft",
                                uuid,
                                nonce,
                                transactions
                            };
                            return new some/* Some */.b(new fetched_data/* Data */.V(inner));
                        }
                        if (current.isErr()) return new none/* None */.H();
                        return new some/* Some */.b(current.mapSync((d)=>({
                                ...d,
                                transactions: [
                                    ...d.transactions,
                                    TransactionRef.from(currentData)
                                ]
                            })));
                    }));
                    await ((_All_ByAddress_schema1 = All.ByAddress.schema(currentData.params.from, storage)) === null || _All_ByAddress_schema1 === void 0 ? void 0 : _All_ByAddress_schema1.mutate((s)=>{
                        var _s_real;
                        const current = (_s_real = s.real) === null || _s_real === void 0 ? void 0 : _s_real.current;
                        if (current == null) return new some/* Some */.b(new fetched_data/* Data */.V([
                            TransactionRef.from(currentData)
                        ]));
                        if (current.isErr()) return new none/* None */.H();
                        return new some/* Some */.b(current.mapSync((d)=>[
                                ...d,
                                TransactionRef.from(currentData)
                            ]));
                    }));
                }
            }
            if ((currentData === null || currentData === void 0 ? void 0 : currentData.type) === "executed") {
                var _FgTransactionTrial_schema2;
                await ((_FgTransactionTrial_schema2 = FgTransactionTrial.schema(currentData.trial.uuid, storage)) === null || _FgTransactionTrial_schema2 === void 0 ? void 0 : _FgTransactionTrial_schema2.mutate((s)=>{
                    var _s_real;
                    const current = (_s_real = s.real) === null || _s_real === void 0 ? void 0 : _s_real.current;
                    if (current == null) return new none/* None */.H();
                    if (current.isErr()) return new none/* None */.H();
                    return new some/* Some */.b(current.mapSync((d)=>({
                            ...d,
                            transaction: TransactionRef.from(currentData)
                        })));
                }));
            }
        };
        return (0,query/* createQuery */.rP)({
            key: FgTransaction.key(uuid),
            storage,
            indexer
        });
    }
    FgTransaction.schema = schema;
})(FgTransaction || (FgTransaction = {}));
function useTransactions(address) {
    const storage = useUserStorageContext().unwrap();
    const query = useQuery(FgTransaction.All.ByAddress.schema, [
        address,
        storage
    ]);
    useSubscribe(query, storage);
    return query;
}
function useTransactionWithReceipt(uuid, context) {
    var _transactionQuery_current;
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const transactionQuery = (0,simple/* useQuery */.aM)(FgTransaction.schema, [
        uuid,
        storage
    ]);
    const maybeTransaction = (_transactionQuery_current = transactionQuery.current) === null || _transactionQuery_current === void 0 ? void 0 : _transactionQuery_current.ok().get();
    (0,storage_storage/* useSubscribe */.Q)(transactionQuery, storage);
    const receiptQuery = (0,simple/* useQuery */.aM)(FgTransactionReceipt.schema, [
        uuid,
        maybeTransaction === null || maybeTransaction === void 0 ? void 0 : maybeTransaction.hash,
        context,
        storage
    ]);
    useWait(receiptQuery, 1000);
    (0,storage_storage/* useSubscribe */.Q)(receiptQuery, storage);
    (0,use_error/* useError */.V)(receiptQuery, errors/* Errors */.D.onQueryError);
    return transactionQuery;
}
var FgTransactionTrial;
(function(FgTransactionTrial) {
    FgTransactionTrial.key = BgTransactionTrial.key;
    function schema(uuid, storage) {
        if (uuid == null) return;
        return (0,query/* createQuery */.rP)({
            key: FgTransactionTrial.key(uuid),
            storage
        });
    }
    FgTransactionTrial.schema = schema;
})(FgTransactionTrial || (FgTransactionTrial = {}));
function useTransactionTrial(uuid) {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(FgTransactionTrial.schema, [
        uuid,
        storage
    ]);
    (0,storage_storage/* useSubscribe */.Q)(query, storage);
    return query;
}
var FgTransactionReceipt;
(function(FgTransactionReceipt) {
    FgTransactionReceipt.key = BgTransactionReceipt.key;
    function schema(uuid, hash, context, storage) {
        if (context == null) return;
        if (hash == null) return;
        const fetcher = async (request)=>await (0,entities_wallets_data/* fetchOrFail */.yR)(request, context);
        const indexer = async (states)=>{
            var _previous_real_current_ok, _previous_real, _current_real_current_ok, _current_real;
            const { current, previous } = states;
            const previousData = previous === null || previous === void 0 ? void 0 : (_previous_real = previous.real) === null || _previous_real === void 0 ? void 0 : (_previous_real_current_ok = _previous_real.current.ok()) === null || _previous_real_current_ok === void 0 ? void 0 : _previous_real_current_ok.get();
            const currentData = (_current_real = current.real) === null || _current_real === void 0 ? void 0 : (_current_real_current_ok = _current_real.current.ok()) === null || _current_real_current_ok === void 0 ? void 0 : _current_real_current_ok.get();
            if (previousData == null && currentData != null) {
                var _FgTransaction_schema;
                await ((_FgTransaction_schema = FgTransaction.schema(uuid, storage)) === null || _FgTransaction_schema === void 0 ? void 0 : _FgTransaction_schema.mutate((s)=>{
                    var _s_real;
                    const current = (_s_real = s.real) === null || _s_real === void 0 ? void 0 : _s_real.current;
                    if (current == null) return new none/* None */.H();
                    if (current.isErr()) return new none/* None */.H();
                    return new some/* Some */.b(current.mapSync((d)=>({
                            ...d,
                            type: "executed",
                            receipt: currentData
                        })));
                }));
            }
        };
        return (0,query/* createQuery */.rP)({
            key: FgTransactionReceipt.key(hash, context.chain),
            fetcher,
            indexer,
            storage
        });
    }
    FgTransactionReceipt.schema = schema;
})(FgTransactionReceipt || (FgTransactionReceipt = {}));

;// CONCATENATED MODULE: ./src/mods/foreground/entities/wallets/actions/eth_sendTransaction/nonce.tsx













function WalletTransactionScreenNonce(props) {
    var _pendingNonceQuery_current;
    const wallet = (0,wallets_context/* useWalletDataContext */.zI)().unwrap();
    const close = (0,dialog/* useCloseContext */.gX)().unwrap();
    const $state = (0,path_context/* usePathState */.qf)();
    const [maybeStep, setStep] = (0,path_context/* useSearchState */.XN)("step", $state);
    const [maybeChain, setChain] = (0,path_context/* useSearchState */.XN)("chain", $state);
    const [maybeNonce, setNonce] = (0,path_context/* useSearchState */.XN)("nonce", $state);
    const chain = option_option/* Option */.W.unwrap(maybeChain);
    const chainData = mods_chain/* chainByChainId */.DH[Number(chain)];
    const tokenData = chainData.token;
    const context = (0,entities_wallets_data/* useEthereumContext */.Kn)(wallet.uuid, chainData);
    const pendingNonceQuery = (0,unknown_data/* useNonce */.XE)(wallet.address, context);
    const maybePendingNonce = (_pendingNonceQuery_current = pendingNonceQuery.current) === null || _pendingNonceQuery_current === void 0 ? void 0 : _pendingNonceQuery_current.ok().get();
    const [rawNonceInput = "", setRawNonceInput] = (0,react.useState)(maybeNonce);
    const onInputChange = (0,events/* useInputChange */.Xy)((e)=>{
        setRawNonceInput(e.target.value);
    }, []);
    const nonceInput = (0,react.useDeferredValue)(rawNonceInput);
    useEffectButNotFirstTime(()=>{
        setNonce(nonceInput);
    }, [
        nonceInput
    ]);
    const onSubmit = (0,react.useCallback)(async ()=>{
        setStep("value");
    }, [
        setStep
    ]);
    const onEnter = (0,events/* useKeyboardEnter */.Fj)(()=>{
        onSubmit();
    }, [
        onSubmit
    ]);
    const onClear = (0,react.useCallback)((e)=>{
        setRawNonceInput("");
    }, []);
    const onPaste = (0,react.useCallback)(async ()=>{
        setNonce(await navigator.clipboard.readText());
        setStep("value");
    }, [
        setNonce,
        setStep
    ]);
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(dialog/* Dialog */.Vq.Title, {
                close: close,
                children: [
                    "Send ",
                    tokenData.symbol,
                    " on ",
                    chainData.name
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-4"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(SimpleBox, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "",
                        children: "Nonce"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-4"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(SimpleInput, {
                        autoFocus: true,
                        value: rawNonceInput,
                        onChange: onInputChange,
                        onKeyDown: onEnter,
                        placeholder: maybePendingNonce === null || maybePendingNonce === void 0 ? void 0 : maybePendingNonce.toString()
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-1"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "flex items-center",
                        children: [
                            rawNonceInput.length === 0 ? /*#__PURE__*/ (0,jsx_runtime.jsx)(ShrinkableNakedButtonInInputBox, {
                                onClick: onPaste,
                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(ClipboardIcon/* default */.Z, {
                                    className: "size-4"
                                })
                            }) : /*#__PURE__*/ (0,jsx_runtime.jsx)(ShrinkableNakedButtonInInputBox, {
                                onClick: onClear,
                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(XMarkIcon/* default */.Z, {
                                    className: "size-4"
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "w-1"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(ShrinkableContrastButtonInInputBox, {
                                onClick: onSubmit,
                                children: "OK"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-4"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "text-lg font-medium",
                children: "Pending transactions"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "grow flex flex-col items-center justify-center",
                children: "Coming soon..."
            })
        ]
    });
}

// EXTERNAL MODULE: ./src/libs/bigints/bigints.ts
var bigints = __webpack_require__(7795);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/MagnifyingGlassIcon.js
var MagnifyingGlassIcon = __webpack_require__(9633);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/PencilIcon.js
var PencilIcon = __webpack_require__(8974);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/ArrowTopRightOnSquareIcon.js
var ArrowTopRightOnSquareIcon = __webpack_require__(1902);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/BoltIcon.js
var BoltIcon = __webpack_require__(4510);
// EXTERNAL MODULE: ./src/libs/ui/loading/loading.tsx
var loading = __webpack_require__(6291);
// EXTERNAL MODULE: ./node_modules/ethers/lib.esm/transaction/transaction.js + 2 modules
var transaction = __webpack_require__(5418);
;// CONCATENATED MODULE: ./src/mods/foreground/entities/blocks/data.ts





var FgBlock;
(function(FgBlock) {
    let ByNumber;
    (function(ByNumber) {
        function key(chain, number) {
            return {
                chainId: chain.chainId,
                method: "eth_getBlockByNumber",
                params: [
                    number,
                    false
                ],
                noCheck: true
            };
        }
        ByNumber.key = key;
        function schema(number, context, storage) {
            if (context == null) return;
            if (number == null) return;
            const fetcher = async (request)=>await (0,entities_wallets_data/* fetchOrFail */.yR)(request, context);
            return (0,query/* createQuery */.rP)({
                key: key(context.chain, number),
                fetcher,
                storage
            });
        }
        ByNumber.schema = schema;
    })(ByNumber = FgBlock.ByNumber || (FgBlock.ByNumber = {}));
})(FgBlock || (FgBlock = {}));
function useBlockByNumber(number, ethereum) {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(FgBlock.ByNumber.schema, [
        number,
        ethereum,
        storage
    ]);
    (0,use_fetch/* useFetch */.i)(query);
    (0,use_visible/* useVisible */.E)(query);
    (0,use_interval/* useInterval */.Y)(query, 10 * 1000);
    (0,storage_storage/* useSubscribe */.Q)(query, storage);
    (0,use_error/* useError */.V)(query, errors/* Errors */.D.onQueryError);
    return query;
}

// EXTERNAL MODULE: ./src/mods/foreground/entities/signatures/data.tsx + 1 modules
var signatures_data = __webpack_require__(4035);
;// CONCATENATED MODULE: ./src/mods/foreground/entities/wallets/actions/eth_sendTransaction/decode.tsx













function WalletDecodeScreen(props) {
    const wallet = (0,wallets_context/* useWalletDataContext */.zI)().unwrap();
    const close = (0,dialog/* useCloseContext */.gX)().unwrap();
    const $state = (0,path_context/* usePathState */.qf)();
    const [maybeData, setData] = (0,path_context/* useSearchState */.XN)("data", $state);
    const maybeHash = option_option/* Option */.W.wrap(maybeData).mapSync((x)=>{
        return x.slice(0, 10);
    }).inner;
    const gnosis = (0,entities_wallets_data/* useEthereumContext2 */.IL)(wallet.uuid, mods_chain/* chainByChainId */.DH[100]).unwrap();
    const signaturesQuery = (0,signatures_data/* useSignature */.F)(maybeHash, gnosis);
    const triedSignatures = signaturesQuery.current;
    if (maybeData == null) return null;
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Dialog */.Vq.Title, {
                close: close,
                children: "Decode transaction data"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-4"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "po-md bg-contrast rounded-xl text-contrast whitespace-pre-wrap break-all",
                children: maybeData || "0x0"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-4"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "text-lg font-medium",
                children: "Matching functions"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-2"
            }),
            triedSignatures == null && /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "grow flex flex-col items-center justify-center",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(loading/* Loading */.g, {
                    className: "size-10"
                })
            }),
            (triedSignatures === null || triedSignatures === void 0 ? void 0 : triedSignatures.isErr()) && /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "grow flex flex-col items-center justify-center",
                children: "Could not fetch signatures"
            }),
            (triedSignatures === null || triedSignatures === void 0 ? void 0 : triedSignatures.isOk()) && triedSignatures.get().length === 0 && /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "grow flex flex-col items-center justify-center",
                children: "No matching function found"
            }),
            (triedSignatures === null || triedSignatures === void 0 ? void 0 : triedSignatures.isOk()) && triedSignatures.get().length > 0 && /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "grow flex flex-col gap-2",
                children: triedSignatures.get().toReversed().map((text)=>/*#__PURE__*/ (0,jsx_runtime.jsx)(SignatureRow, {
                        data: maybeData,
                        text: text
                    }, text))
            })
        ]
    });
}
function SignatureRow(props) {
    const { text, data } = props;
    const triedArgs = (0,react.useMemo)(()=>result/* Result */.x.runAndDoubleWrapSync(()=>{
            function stringifyOrThrow(x) {
                if (typeof x === "string") return x;
                if (typeof x === "boolean") return String(x);
                if (typeof x === "number") return String(x);
                if (typeof x === "bigint") return String(x);
                if (x instanceof Uint8Array) return zerohex/* ZeroHexString */.T.from(adapter/* get */.U().encodeOrThrow(x));
                if (Array.isArray(x)) return "(".concat(x.map(stringifyOrThrow).join(", "), ")");
                return "unknown";
            }
            return decode/* decodeOrThrow */.Dt(signature_signature/* FunctionSignature */.I.parseOrThrow(text), data).intoOrThrow().map(stringifyOrThrow);
        }), [
        text,
        data
    ]);
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "po-md bg-contrast rounded-xl",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "break-words",
                children: text
            }),
            triedArgs.isErr() && /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "text-contrast",
                children: "Could not decode arguments"
            }),
            triedArgs.isOk() && triedArgs.get().length === 0 && /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "text-contrast",
                children: "No arguments"
            }),
            triedArgs.isOk() && triedArgs.get().length > 0 && /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "text-contrast whitespace-pre-wrap break-all",
                children: triedArgs.get().map((arg, i)=>/*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        children: [
                            "- ",
                            arg
                        ]
                    }, i))
            })
        ]
    }, text);
}

;// CONCATENATED MODULE: ./src/mods/foreground/entities/wallets/actions/eth_sendTransaction/value.tsx






























function WalletTransactionScreenValue(props) {
    var _transactionQuery_current, _pendingNonceQuery_current, _ensTargetQuery_current, _fetchedGasPriceQuery_current, _fetchedMaxPriorityFeePerGasQuery_current, _pendingBlockQuery_current, _legacyGasLimitQuery_current, _eip1559GasLimitQuery_current, _tokenData_pairs, _maybeTriedEip1559GasLimitKey_getErr, _maybeTriedLegacyGasLimitKey_getErr, _eip1559GasLimitQuery_current1, _eip1559GasLimitQuery_current_getErr, _legacyGasLimitQuery_current1, _legacyGasLimitQuery_current_getErr, _maybeTriedEip1559GasLimitKey_getErr1, _maybeTriedLegacyGasLimitKey_getErr1, _eip1559GasLimitQuery_current2, _eip1559GasLimitQuery_current_getErr1, _legacyGasLimitQuery_current2, _legacyGasLimitQuery_current_getErr1;
    const wallet = (0,wallets_context/* useWalletDataContext */.zI)().unwrap();
    const close = (0,dialog/* useCloseContext */.gX)().unwrap();
    const subpath = (0,path_context/* useSubpath */._u)();
    const $state = (0,path_context/* usePathState */.qf)();
    const [maybeTrial, setTrial] = (0,path_context/* useSearchState */.XN)("trial", $state);
    const [maybeStep, setStep] = (0,path_context/* useSearchState */.XN)("step", $state);
    const [maybeChain, setChain] = (0,path_context/* useSearchState */.XN)("chain", $state);
    const [maybeTarget, setTarget] = (0,path_context/* useSearchState */.XN)("target", $state);
    const [maybeValue, setValue] = (0,path_context/* useSearchState */.XN)("value", $state);
    const [maybeNonce, setNonce] = (0,path_context/* useSearchState */.XN)("nonce", $state);
    const [maybeData, setData] = (0,path_context/* useSearchState */.XN)("data", $state);
    const [maybeGasMode, setGasMode] = (0,path_context/* useSearchState */.XN)("gasMode", $state);
    const [maybeGasLimit, setGasLimit] = (0,path_context/* useSearchState */.XN)("gasLimit", $state);
    const [maybeGasPrice, setGasPrice] = (0,path_context/* useSearchState */.XN)("gasPrice", $state);
    const [maybeBaseFeePerGas, setBaseFeePerGas] = (0,path_context/* useSearchState */.XN)("baseFeePerGas", $state);
    const [maybeMaxPriorityFeePerGas, setMaxPriorityFeePerGas] = (0,path_context/* useSearchState */.XN)("maxPriorityFeePerGas", $state);
    const [maybeDisableData, setDisableData] = (0,path_context/* useSearchState */.XN)("disableData", $state);
    const [maybeDisableSign, setDisableSign] = (0,path_context/* useSearchState */.XN)("disableSign", $state);
    const gasMode = option_option/* Option */.W.wrap(maybeGasMode).unwrapOr("normal");
    const trialUuidFallback = (0,ref/* useConstant */.hS)(()=>crypto.randomUUID());
    const trialUuid = option_option/* Option */.W.wrap(maybeTrial).unwrapOr(trialUuidFallback);
    const disableData = Boolean(maybeDisableData);
    const disableSign = Boolean(maybeDisableSign);
    const chain = option_option/* Option */.W.unwrap(maybeChain);
    const chainData = mods_chain/* chainByChainId */.DH[Number(chain)];
    const tokenData = chainData.token;
    const context = (0,entities_wallets_data/* useEthereumContext2 */.IL)(wallet.uuid, chainData).unwrap();
    const transactionUuid = (0,ref/* useConstant */.hS)(()=>crypto.randomUUID());
    const transactionQuery = useTransactionWithReceipt(transactionUuid, context);
    const maybeTransaction = (_transactionQuery_current = transactionQuery.current) === null || _transactionQuery_current === void 0 ? void 0 : _transactionQuery_current.ok().get();
    const pendingNonceQuery = (0,unknown_data/* useNonce */.XE)(wallet.address, context);
    const maybePendingNonce = (_pendingNonceQuery_current = pendingNonceQuery.current) === null || _pendingNonceQuery_current === void 0 ? void 0 : _pendingNonceQuery_current.ok().get();
    const [prices, setPrices] = (0,react.useState)(()=>{
        if (tokenData.pairs == null) return;
        return new Array(tokenData.pairs.length);
    });
    const onPrice = (0,react.useCallback)((param)=>{
        let [index, data] = param;
        setPrices((prices)=>{
            if (prices == null) return;
            prices[index] = data;
            return [
                ...prices
            ];
        });
    }, []);
    const maybePrice = (0,react.useMemo)(()=>{
        return prices === null || prices === void 0 ? void 0 : prices.reduce((a, b)=>{
            if (b == null) return a;
            return a.mul(types_fixed/* Fixed */.g.from(b));
        }, types_fixed/* Fixed */.g.unit(tokenData.decimals));
    }, [
        prices,
        tokenData
    ]);
    const getRawPricedInput = (0,react.useCallback)((rawValuedInput)=>{
        try {
            if (rawValuedInput.trim().length === 0) return undefined;
            if (maybePrice == null) return undefined;
            const priced = types_fixed/* Fixed */.g.fromString(rawValuedInput, tokenData.decimals).mul(maybePrice);
            if (priced.value === 0n) return undefined;
            return priced.toString();
        } catch (e) {
            return undefined;
        }
    }, [
        maybePrice,
        tokenData
    ]);
    const [rawValuedInput = ""] = (0,react.useMemo)(()=>{
        return [
            maybeValue
        ];
    }, [
        maybeValue
    ]);
    const [rawPricedInput = ""] = (0,react.useMemo)(()=>{
        return [
            getRawPricedInput(rawValuedInput)
        ];
    }, [
        getRawPricedInput,
        rawValuedInput
    ]);
    const onNonceClick = (0,react.useCallback)(()=>{
        setStep("nonce");
    }, [
        setStep
    ]);
    const onDecodeClick = (0,react.useCallback)(()=>{
        if (maybeData == null) return;
        subpath.go((0,url/* qurl */.d)("/decode", {
            data: maybeData
        }));
    }, [
        maybeData,
        subpath
    ]);
    const mainnet = (0,entities_wallets_data/* useEthereumContext */.Kn)(wallet.uuid, mods_chain/* chainByChainId */.DH[1]);
    const maybeEnsQueryKey = (maybeTarget === null || maybeTarget === void 0 ? void 0 : maybeTarget.endsWith(".eth")) ? maybeTarget : undefined;
    const ensTargetQuery = (0,names_data/* useEnsLookup */.aZ)(maybeEnsQueryKey, mainnet);
    const maybeEnsTarget = (_ensTargetQuery_current = ensTargetQuery.current) === null || _ensTargetQuery_current === void 0 ? void 0 : _ensTargetQuery_current.ok().get();
    const maybeFinalTarget = (0,react.useMemo)(()=>{
        if (maybeTarget == null) return undefined;
        if (types_address/* Address */.k.from(maybeTarget) != null) return maybeTarget;
        if (maybeEnsTarget != null) return maybeEnsTarget;
        return undefined;
    }, [
        maybeTarget,
        maybeEnsTarget
    ]);
    const rawValue = (0,react.useMemo)(()=>{
        return (maybeValue === null || maybeValue === void 0 ? void 0 : maybeValue.trim().length) ? maybeValue.trim() : "0";
    }, [
        maybeValue
    ]);
    const maybeFinalValue = (0,react.useMemo)(()=>{
        try {
            return types_fixed/* Fixed */.g.fromString(rawValue, tokenData.decimals);
        } catch (e) {}
    }, [
        rawValue,
        tokenData
    ]);
    const [rawNonceInput = "", setRawNonceInput] = (0,react.useState)(maybeNonce);
    const onNonceInputChange = (0,events/* useInputChange */.Xy)((e)=>{
        setRawNonceInput(e.target.value);
    }, []);
    const nonceInput = (0,react.useDeferredValue)(rawNonceInput);
    useEffectButNotFirstTime(()=>{
        setNonce(nonceInput);
    }, [
        nonceInput
    ]);
    const maybeCustomNonce = (0,react.useMemo)(()=>{
        try {
            return (maybeNonce === null || maybeNonce === void 0 ? void 0 : maybeNonce.trim().length) ? BigInt(maybeNonce.trim()) : undefined;
        } catch (e) {}
    }, [
        maybeNonce
    ]);
    const maybeFinalNonce = (0,react.useMemo)(()=>{
        if (maybeCustomNonce != null) return maybeCustomNonce;
        if (maybePendingNonce != null) return maybePendingNonce;
        return undefined;
    }, [
        maybeCustomNonce,
        maybePendingNonce
    ]);
    const [rawDataInput = "", setRawDataInput] = (0,react.useState)(maybeData);
    const onDataInputChange = (0,events/* useTextAreaChange */.aN)((e)=>{
        setRawDataInput(e.target.value);
    }, []);
    const dataInput = (0,react.useDeferredValue)(rawDataInput);
    useEffectButNotFirstTime(()=>{
        setData(dataInput);
    }, [
        dataInput
    ]);
    const maybeTriedMaybeFinalData = (0,react.useMemo)(()=>result/* Result */.x.runAndDoubleWrapSync(()=>{
            return (maybeData === null || maybeData === void 0 ? void 0 : maybeData.trim().length) ? zerohex/* ZeroHexString */.T.from(maybeData.trim()) : undefined;
        }), [
        maybeData
    ]);
    const onGasModeChange = (0,react.useCallback)((e)=>{
        setGasMode(e.currentTarget.value);
    }, [
        setGasMode
    ]);
    const fetchedGasPriceQuery = (0,unknown_data/* useGasPrice */.Fh)(context);
    const maybeFetchedGasPrice = (_fetchedGasPriceQuery_current = fetchedGasPriceQuery.current) === null || _fetchedGasPriceQuery_current === void 0 ? void 0 : _fetchedGasPriceQuery_current.ok().get();
    const fetchedMaxPriorityFeePerGasQuery = (0,unknown_data/* useMaxPriorityFeePerGas */.hy)(context);
    const maybeFetchedMaxPriorityFeePerGas = (_fetchedMaxPriorityFeePerGasQuery_current = fetchedMaxPriorityFeePerGasQuery.current) === null || _fetchedMaxPriorityFeePerGasQuery_current === void 0 ? void 0 : _fetchedMaxPriorityFeePerGasQuery_current.ok().get();
    const pendingBlockQuery = useBlockByNumber("pending", context);
    const maybePendingBlock = (_pendingBlockQuery_current = pendingBlockQuery.current) === null || _pendingBlockQuery_current === void 0 ? void 0 : _pendingBlockQuery_current.ok().get();
    const maybeFetchedBaseFeePerGas = (0,react.useMemo)(()=>{
        try {
            return (maybePendingBlock === null || maybePendingBlock === void 0 ? void 0 : maybePendingBlock.baseFeePerGas) != null ? bigints/* BigIntToHex */.W.decodeOrThrow(maybePendingBlock.baseFeePerGas) : undefined;
        } catch (e) {}
    }, [
        maybePendingBlock
    ]);
    const maybeIsEip1559 = (0,react.useMemo)(()=>{
        return (maybePendingBlock === null || maybePendingBlock === void 0 ? void 0 : maybePendingBlock.baseFeePerGas) != null;
    }, [
        maybePendingBlock
    ]);
    const [rawGasLimitInput = "", setRawGasLimitInput] = (0,react.useState)(maybeGasLimit);
    const onGasLimitInputChange = (0,events/* useInputChange */.Xy)((e)=>{
        setRawGasLimitInput(e.target.value);
    }, []);
    const gasLimitInput = (0,react.useDeferredValue)(rawGasLimitInput);
    useEffectButNotFirstTime(()=>{
        setGasLimit(gasLimitInput);
    }, [
        gasLimitInput
    ]);
    const [rawGasPriceInput = "", setRawGasPriceInput] = (0,react.useState)(maybeGasPrice);
    const onGasPriceInputChange = (0,events/* useInputChange */.Xy)((e)=>{
        setRawGasPriceInput(e.target.value);
    }, []);
    const gasPriceInput = (0,react.useDeferredValue)(rawGasPriceInput);
    useEffectButNotFirstTime(()=>{
        setGasPrice(gasPriceInput);
    }, [
        gasPriceInput
    ]);
    const [rawBaseFeePerGasInput = "", setRawBaseFeePerGasInput] = (0,react.useState)(maybeBaseFeePerGas);
    const onBaseFeePerGasInputChange = (0,events/* useInputChange */.Xy)((e)=>{
        setRawBaseFeePerGasInput(e.target.value);
    }, []);
    const baseFeePerGasInput = (0,react.useDeferredValue)(rawBaseFeePerGasInput);
    useEffectButNotFirstTime(()=>{
        setBaseFeePerGas(baseFeePerGasInput);
    }, [
        baseFeePerGasInput
    ]);
    const [rawMaxPriorityFeePerGasInput = "", setRawMaxPriorityFeePerGasInput] = (0,react.useState)(maybeMaxPriorityFeePerGas);
    const onMaxPriorityFeePerGasInputChange = (0,events/* useInputChange */.Xy)((e)=>{
        setRawMaxPriorityFeePerGasInput(e.target.value);
    }, []);
    const maxPriorityFeePerGasInput = (0,react.useDeferredValue)(rawMaxPriorityFeePerGasInput);
    useEffectButNotFirstTime(()=>{
        setMaxPriorityFeePerGas(maxPriorityFeePerGasInput);
    }, [
        maxPriorityFeePerGasInput
    ]);
    function useMaybeMemo(f, param) {
        let [x] = param;
        return (0,react.useMemo)(()=>{
            if (x == null) return undefined;
            return f(x);
        // eslint-disable-next-line react-hooks/exhaustive-deps
        }, [
            x
        ]);
    }
    const maybeNormalBaseFeePerGas = useMaybeMemo((baseFeePerGas)=>{
        return baseFeePerGas;
    }, [
        maybeFetchedBaseFeePerGas
    ]);
    const maybeFastBaseFeePerGas = useMaybeMemo((baseFeePerGas)=>{
        return baseFeePerGas + 1n * 10n ** 9n;
    }, [
        maybeFetchedBaseFeePerGas
    ]);
    const maybeUrgentBaseFeePerGas = useMaybeMemo((baseFeePerGas)=>{
        return baseFeePerGas + 2n * 10n ** 9n;
    }, [
        maybeFetchedBaseFeePerGas
    ]);
    const maybeCustomBaseFeePerGas = (0,react.useMemo)(()=>{
        try {
            return (maybeBaseFeePerGas === null || maybeBaseFeePerGas === void 0 ? void 0 : maybeBaseFeePerGas.trim().length) ? BigInt(maybeBaseFeePerGas.trim()) : maybeNormalBaseFeePerGas;
        } catch (e) {}
    }, [
        maybeBaseFeePerGas,
        maybeNormalBaseFeePerGas
    ]);
    const maybeNormalMaxPriorityFeePerGas = useMaybeMemo((maxPriorityFeePerGas)=>{
        return maxPriorityFeePerGas / 4n;
    }, [
        maybeFetchedMaxPriorityFeePerGas
    ]);
    const maybeFastMaxPriorityFeePerGas = useMaybeMemo((maxPriorityFeePerGas)=>{
        return maxPriorityFeePerGas / 2n;
    }, [
        maybeFetchedMaxPriorityFeePerGas
    ]);
    const maybeUrgentMaxPriorityFeePerGas = useMaybeMemo((maxPriorityFeePerGas)=>{
        return maxPriorityFeePerGas;
    }, [
        maybeFetchedMaxPriorityFeePerGas
    ]);
    const maybeCustomMaxPriorityFeePerGas = (0,react.useMemo)(()=>{
        try {
            return (maybeMaxPriorityFeePerGas === null || maybeMaxPriorityFeePerGas === void 0 ? void 0 : maybeMaxPriorityFeePerGas.trim().length) ? BigInt(maybeMaxPriorityFeePerGas.trim()) : maybeNormalMaxPriorityFeePerGas;
        } catch (e) {}
    }, [
        maybeMaxPriorityFeePerGas,
        maybeNormalMaxPriorityFeePerGas
    ]);
    const maybeNormalGasPrice = useMaybeMemo((gasPrice)=>{
        return gasPrice;
    }, [
        maybeFetchedGasPrice
    ]);
    const maybeFastGasPrice = useMaybeMemo((gasPrice)=>{
        return gasPrice * 110n / 100n;
    }, [
        maybeFetchedGasPrice
    ]);
    const maybeUrgentGasPrice = useMaybeMemo((gasPrice)=>{
        return gasPrice * 120n / 100n;
    }, [
        maybeFetchedGasPrice
    ]);
    const maybeCustomGasPrice = (0,react.useMemo)(()=>{
        try {
            return (maybeGasPrice === null || maybeGasPrice === void 0 ? void 0 : maybeGasPrice.trim().length) ? BigInt(maybeGasPrice.trim()) : maybeNormalGasPrice;
        } catch (e) {}
    }, [
        maybeGasPrice,
        maybeNormalGasPrice
    ]);
    const maybeNormalMinFeePerGas = (0,react.useMemo)(()=>{
        if (maybeNormalBaseFeePerGas == null) return undefined;
        if (maybeNormalMaxPriorityFeePerGas == null) return undefined;
        return maybeNormalBaseFeePerGas + maybeNormalMaxPriorityFeePerGas;
    }, [
        maybeNormalBaseFeePerGas,
        maybeNormalMaxPriorityFeePerGas
    ]);
    const maybeFastMinFeePerGas = (0,react.useMemo)(()=>{
        if (maybeFastBaseFeePerGas == null) return undefined;
        if (maybeFastMaxPriorityFeePerGas == null) return undefined;
        return maybeFastBaseFeePerGas + maybeFastMaxPriorityFeePerGas;
    }, [
        maybeFastBaseFeePerGas,
        maybeFastMaxPriorityFeePerGas
    ]);
    const maybeUrgentMinFeePerGas = (0,react.useMemo)(()=>{
        if (maybeUrgentBaseFeePerGas == null) return undefined;
        if (maybeUrgentMaxPriorityFeePerGas == null) return undefined;
        return maybeUrgentBaseFeePerGas + maybeUrgentMaxPriorityFeePerGas;
    }, [
        maybeUrgentBaseFeePerGas,
        maybeUrgentMaxPriorityFeePerGas
    ]);
    const maybeCustomMinFeePerGas = (0,react.useMemo)(()=>{
        if (maybeCustomBaseFeePerGas == null) return undefined;
        if (maybeCustomMaxPriorityFeePerGas == null) return undefined;
        return maybeCustomBaseFeePerGas + maybeCustomMaxPriorityFeePerGas;
    }, [
        maybeCustomBaseFeePerGas,
        maybeCustomMaxPriorityFeePerGas
    ]);
    const maybeNormalMaxFeePerGas = (0,react.useMemo)(()=>{
        if (maybeNormalBaseFeePerGas == null) return undefined;
        if (maybeNormalMaxPriorityFeePerGas == null) return undefined;
        return maybeNormalBaseFeePerGas * 2n + maybeNormalMaxPriorityFeePerGas;
    }, [
        maybeNormalBaseFeePerGas,
        maybeNormalMaxPriorityFeePerGas
    ]);
    const maybeFastMaxFeePerGas = (0,react.useMemo)(()=>{
        if (maybeFastBaseFeePerGas == null) return undefined;
        if (maybeFastMaxPriorityFeePerGas == null) return undefined;
        return maybeFastBaseFeePerGas * 2n + maybeFastMaxPriorityFeePerGas;
    }, [
        maybeFastBaseFeePerGas,
        maybeFastMaxPriorityFeePerGas
    ]);
    const maybeUrgentMaxFeePerGas = (0,react.useMemo)(()=>{
        if (maybeUrgentBaseFeePerGas == null) return undefined;
        if (maybeUrgentMaxPriorityFeePerGas == null) return undefined;
        return maybeUrgentBaseFeePerGas * 2n + maybeUrgentMaxPriorityFeePerGas;
    }, [
        maybeUrgentBaseFeePerGas,
        maybeUrgentMaxPriorityFeePerGas
    ]);
    const maybeCustomMaxFeePerGas = (0,react.useMemo)(()=>{
        if (maybeCustomBaseFeePerGas == null) return undefined;
        if (maybeCustomMaxPriorityFeePerGas == null) return undefined;
        return maybeCustomBaseFeePerGas * 2n + maybeCustomMaxPriorityFeePerGas;
    }, [
        maybeCustomBaseFeePerGas,
        maybeCustomMaxPriorityFeePerGas
    ]);
    function useMode(normal, fast, urgent, custom) {
        return (0,react.useMemo)(()=>{
            if (gasMode === "normal") return normal;
            if (gasMode === "fast") return fast;
            if (gasMode === "urgent") return urgent;
            if (gasMode === "custom") return custom;
            return undefined;
        // eslint-disable-next-line react-hooks/exhaustive-deps
        }, [
            gasMode,
            normal,
            fast,
            urgent,
            custom
        ]);
    }
    function useGasDisplay(gasPrice) {
        return (0,react.useMemo)(()=>{
            if (gasPrice == null) return "???";
            return Number(new types_fixed/* Fixed */.g(gasPrice, 9).move(4).toString()).toLocaleString(undefined, {
                maximumSignificantDigits: 2
            });
        }, [
            gasPrice
        ]);
    }
    function useCompactUsdDisplay(fixed) {
        return (0,react.useMemo)(()=>{
            if (fixed == null) return "???";
            return Number(fixed.move(2).toString()).toLocaleString(undefined, {
                style: "currency",
                currency: "USD",
                notation: "compact"
            });
        }, [
            fixed
        ]);
    }
    const maybeFinalGasPrice = useMode(maybeNormalGasPrice, maybeFastGasPrice, maybeUrgentGasPrice, maybeCustomGasPrice);
    const maybeFinalMaxFeePerGas = useMode(maybeNormalMaxFeePerGas, maybeFastMaxFeePerGas, maybeUrgentMaxFeePerGas, maybeCustomMaxFeePerGas);
    const maybeFinalMaxPriorityFeePerGas = useMode(maybeNormalMaxPriorityFeePerGas, maybeFastMaxPriorityFeePerGas, maybeUrgentMaxPriorityFeePerGas, maybeCustomMaxPriorityFeePerGas);
    const maybeTriedLegacyGasLimitKey = (0,react.useMemo)(()=>{
        if (maybeIsEip1559 !== false) return undefined;
        if (maybeFinalTarget == null) return undefined;
        if (maybeFinalValue == null) return undefined;
        if (maybeFinalNonce == null) return undefined;
        if (maybeFinalGasPrice == null) return undefined;
        if (maybeTriedMaybeFinalData == null) return undefined;
        if (maybeTriedMaybeFinalData.isErr()) return maybeTriedMaybeFinalData;
        const key = {
            method: "eth_estimateGas",
            params: [
                {
                    chainId: zerohex/* ZeroHexString */.T.from(chainData.chainId),
                    from: wallet.address,
                    to: maybeFinalTarget,
                    gasPrice: zerohex/* ZeroHexString */.T.from(maybeFinalGasPrice),
                    value: zerohex/* ZeroHexString */.T.from(maybeFinalValue.value),
                    nonce: zerohex/* ZeroHexString */.T.from(maybeFinalNonce),
                    data: maybeTriedMaybeFinalData.get()
                },
                "latest"
            ]
        };
        return new ok.Ok(key);
    }, [
        wallet,
        chainData,
        maybeIsEip1559,
        maybeFinalTarget,
        maybeFinalValue,
        maybeFinalNonce,
        maybeTriedMaybeFinalData,
        maybeFinalGasPrice
    ]);
    const maybeTriedEip1559GasLimitKey = (0,react.useMemo)(()=>{
        if (maybeIsEip1559 !== true) return undefined;
        if (maybeFinalTarget == null) return undefined;
        if (maybeFinalValue == null) return undefined;
        if (maybeFinalNonce == null) return undefined;
        if (maybeFinalMaxFeePerGas == null) return undefined;
        if (maybeFinalMaxPriorityFeePerGas == null) return undefined;
        if (maybeTriedMaybeFinalData == null) return undefined;
        if (maybeTriedMaybeFinalData.isErr()) return maybeTriedMaybeFinalData;
        const key = {
            method: "eth_estimateGas",
            params: [
                {
                    chainId: zerohex/* ZeroHexString */.T.from(chainData.chainId),
                    from: wallet.address,
                    to: maybeFinalTarget,
                    maxFeePerGas: zerohex/* ZeroHexString */.T.from(maybeFinalMaxFeePerGas),
                    maxPriorityFeePerGas: zerohex/* ZeroHexString */.T.from(maybeFinalMaxPriorityFeePerGas),
                    value: zerohex/* ZeroHexString */.T.from(maybeFinalValue.value),
                    nonce: zerohex/* ZeroHexString */.T.from(maybeFinalNonce),
                    data: maybeTriedMaybeFinalData.get()
                },
                "latest"
            ]
        };
        return new ok.Ok(key);
    }, [
        wallet,
        chainData,
        maybeIsEip1559,
        maybeFinalTarget,
        maybeFinalValue,
        maybeFinalNonce,
        maybeTriedMaybeFinalData,
        maybeFinalMaxFeePerGas,
        maybeFinalMaxPriorityFeePerGas
    ]);
    const maybeLegacyGasLimitKey = maybeTriedLegacyGasLimitKey === null || maybeTriedLegacyGasLimitKey === void 0 ? void 0 : maybeTriedLegacyGasLimitKey.ok().get();
    const maybeEip1559GasLimitKey = maybeTriedEip1559GasLimitKey === null || maybeTriedEip1559GasLimitKey === void 0 ? void 0 : maybeTriedEip1559GasLimitKey.ok().get();
    const legacyGasLimitQuery = (0,unknown_data/* useEstimateGas */.Nh)(maybeLegacyGasLimitKey, context);
    const maybeLegacyGasLimit = (_legacyGasLimitQuery_current = legacyGasLimitQuery.current) === null || _legacyGasLimitQuery_current === void 0 ? void 0 : _legacyGasLimitQuery_current.ok().get();
    const eip1559GasLimitQuery = (0,unknown_data/* useEstimateGas */.Nh)(maybeEip1559GasLimitKey, context);
    const maybeEip1559GasLimit = (_eip1559GasLimitQuery_current = eip1559GasLimitQuery.current) === null || _eip1559GasLimitQuery_current === void 0 ? void 0 : _eip1559GasLimitQuery_current.ok().get();
    const maybeFetchedGasLimit = (0,react.useMemo)(()=>{
        if (maybeIsEip1559 == null) return undefined;
        if (maybeLegacyGasLimit != null) return maybeLegacyGasLimit;
        if (maybeEip1559GasLimit != null) return maybeEip1559GasLimit;
        return undefined;
    }, [
        maybeIsEip1559,
        maybeLegacyGasLimit,
        maybeEip1559GasLimit
    ]);
    const maybeCustomGasLimit = (0,react.useMemo)(()=>{
        try {
            return (maybeGasLimit === null || maybeGasLimit === void 0 ? void 0 : maybeGasLimit.trim().length) ? BigInt(maybeGasLimit.trim()) : maybeFetchedGasLimit;
        } catch (e) {}
    }, [
        maybeGasLimit,
        maybeFetchedGasLimit
    ]);
    const maybeFinalGasLimit = (0,react.useMemo)(()=>{
        if (gasMode === "custom") return maybeCustomGasLimit;
        return maybeFetchedGasLimit;
    }, [
        gasMode,
        maybeCustomGasLimit,
        maybeFetchedGasLimit
    ]);
    const maybeNormalLegacyGasCost = (0,react.useMemo)(()=>{
        if (maybeLegacyGasLimit == null) return undefined;
        if (maybeNormalGasPrice == null) return undefined;
        if (maybePrice == null) return undefined;
        return new types_fixed/* Fixed */.g(maybeLegacyGasLimit * maybeNormalGasPrice, 18).mul(maybePrice);
    }, [
        maybeLegacyGasLimit,
        maybeNormalGasPrice,
        maybePrice
    ]);
    const maybeFastLegacyGasCost = (0,react.useMemo)(()=>{
        if (maybeLegacyGasLimit == null) return undefined;
        if (maybeFastGasPrice == null) return undefined;
        if (maybePrice == null) return undefined;
        return new types_fixed/* Fixed */.g(maybeLegacyGasLimit * maybeFastGasPrice, 18).mul(maybePrice);
    }, [
        maybeLegacyGasLimit,
        maybeFastGasPrice,
        maybePrice
    ]);
    const maybeUrgentLegacyGasCost = (0,react.useMemo)(()=>{
        if (maybeLegacyGasLimit == null) return undefined;
        if (maybeUrgentGasPrice == null) return undefined;
        if (maybePrice == null) return undefined;
        return new types_fixed/* Fixed */.g(maybeLegacyGasLimit * maybeUrgentGasPrice, 18).mul(maybePrice);
    }, [
        maybeLegacyGasLimit,
        maybeUrgentGasPrice,
        maybePrice
    ]);
    const maybeCustomLegacyGasCost = (0,react.useMemo)(()=>{
        if (maybeCustomGasLimit == null) return undefined;
        if (maybeCustomGasPrice == null) return undefined;
        if (maybePrice == null) return undefined;
        return new types_fixed/* Fixed */.g(maybeCustomGasLimit * maybeCustomGasPrice, 18).mul(maybePrice);
    }, [
        maybeCustomGasLimit,
        maybeCustomGasPrice,
        maybePrice
    ]);
    const maybeNormalMinEip1559GasCost = (0,react.useMemo)(()=>{
        if (maybeEip1559GasLimit == null) return undefined;
        if (maybeNormalMinFeePerGas == null) return undefined;
        if (maybePrice == null) return undefined;
        return new types_fixed/* Fixed */.g(maybeEip1559GasLimit * maybeNormalMinFeePerGas, 18).mul(maybePrice);
    }, [
        maybeEip1559GasLimit,
        maybeNormalMinFeePerGas,
        maybePrice
    ]);
    const maybeFastMinEip1559GasCost = (0,react.useMemo)(()=>{
        if (maybeEip1559GasLimit == null) return undefined;
        if (maybeFastMinFeePerGas == null) return undefined;
        if (maybePrice == null) return undefined;
        return new types_fixed/* Fixed */.g(maybeEip1559GasLimit * maybeFastMinFeePerGas, 18).mul(maybePrice);
    }, [
        maybeEip1559GasLimit,
        maybeFastMinFeePerGas,
        maybePrice
    ]);
    const maybeUrgentMinEip1559GasCost = (0,react.useMemo)(()=>{
        if (maybeEip1559GasLimit == null) return undefined;
        if (maybeUrgentMinFeePerGas == null) return undefined;
        if (maybePrice == null) return undefined;
        return new types_fixed/* Fixed */.g(maybeEip1559GasLimit * maybeUrgentMinFeePerGas, 18).mul(maybePrice);
    }, [
        maybeEip1559GasLimit,
        maybeUrgentMinFeePerGas,
        maybePrice
    ]);
    const maybeCustomMinEip1559GasCost = (0,react.useMemo)(()=>{
        if (maybeCustomGasLimit == null) return undefined;
        if (maybeCustomMinFeePerGas == null) return undefined;
        if (maybePrice == null) return undefined;
        return new types_fixed/* Fixed */.g(maybeCustomGasLimit * maybeCustomMinFeePerGas, 18).mul(maybePrice);
    }, [
        maybeCustomGasLimit,
        maybeCustomMinFeePerGas,
        maybePrice
    ]);
    const maybeNormalMaxEip1559GasCost = (0,react.useMemo)(()=>{
        if (maybeEip1559GasLimit == null) return undefined;
        if (maybeNormalMaxFeePerGas == null) return undefined;
        if (maybePrice == null) return undefined;
        return new types_fixed/* Fixed */.g(maybeEip1559GasLimit * maybeNormalMaxFeePerGas, 18).mul(maybePrice);
    }, [
        maybeEip1559GasLimit,
        maybeNormalMaxFeePerGas,
        maybePrice
    ]);
    const maybeFastMaxEip1559GasCost = (0,react.useMemo)(()=>{
        if (maybeEip1559GasLimit == null) return undefined;
        if (maybeFastMaxFeePerGas == null) return undefined;
        if (maybePrice == null) return undefined;
        return new types_fixed/* Fixed */.g(maybeEip1559GasLimit * maybeFastMaxFeePerGas, 18).mul(maybePrice);
    }, [
        maybeEip1559GasLimit,
        maybeFastMaxFeePerGas,
        maybePrice
    ]);
    const maybeUrgentMaxEip1559GasCost = (0,react.useMemo)(()=>{
        if (maybeEip1559GasLimit == null) return undefined;
        if (maybeUrgentMaxFeePerGas == null) return undefined;
        if (maybePrice == null) return undefined;
        return new types_fixed/* Fixed */.g(maybeEip1559GasLimit * maybeUrgentMaxFeePerGas, 18).mul(maybePrice);
    }, [
        maybeEip1559GasLimit,
        maybeUrgentMaxFeePerGas,
        maybePrice
    ]);
    const maybeCustomMaxEip1559GasCost = (0,react.useMemo)(()=>{
        if (maybeCustomGasLimit == null) return undefined;
        if (maybeCustomMaxFeePerGas == null) return undefined;
        if (maybePrice == null) return undefined;
        return new types_fixed/* Fixed */.g(maybeCustomGasLimit * maybeCustomMaxFeePerGas, 18).mul(maybePrice);
    }, [
        maybeCustomGasLimit,
        maybeCustomMaxFeePerGas,
        maybePrice
    ]);
    const maybeFinalLegacyGasCost = useMode(maybeNormalLegacyGasCost, maybeFastLegacyGasCost, maybeUrgentLegacyGasCost, maybeCustomLegacyGasCost);
    const maybeFinalMinEip1559GasCost = useMode(maybeNormalMinEip1559GasCost, maybeFastMinEip1559GasCost, maybeUrgentMinEip1559GasCost, maybeCustomMinEip1559GasCost);
    const maybeFinalMaxEip1559GasCost = useMode(maybeNormalMaxEip1559GasCost, maybeFastMaxEip1559GasCost, maybeUrgentMaxEip1559GasCost, maybeCustomMaxEip1559GasCost);
    const normalLegacyGasCostDisplay = useCompactUsdDisplay(maybeNormalLegacyGasCost);
    const fastLegacyGasCostDisplay = useCompactUsdDisplay(maybeFastLegacyGasCost);
    const urgentLegacyGasCostDisplay = useCompactUsdDisplay(maybeUrgentLegacyGasCost);
    const finalLegacyGasCostDisplay = useCompactUsdDisplay(maybeFinalLegacyGasCost);
    const normalMinEip1559GasCostDisplay = useCompactUsdDisplay(maybeNormalMinEip1559GasCost);
    const fastMinEip1559GasCostDisplay = useCompactUsdDisplay(maybeFastMinEip1559GasCost);
    const urgentMinEip1559GasCostDisplay = useCompactUsdDisplay(maybeUrgentMinEip1559GasCost);
    const finalMinEip1559GasCostDisplay = useCompactUsdDisplay(maybeFinalMinEip1559GasCost);
    const normalMaxEip1559GasCostDisplay = useCompactUsdDisplay(maybeNormalMaxEip1559GasCost);
    const fastMaxEip1559GasCostDisplay = useCompactUsdDisplay(maybeFastMaxEip1559GasCost);
    const urgentMaxEip1559GasCostDisplay = useCompactUsdDisplay(maybeUrgentMaxEip1559GasCost);
    const finalMaxEip1559GasCostDisplay = useCompactUsdDisplay(maybeFinalMaxEip1559GasCost);
    const normalGasPriceDisplay = useGasDisplay(maybeNormalGasPrice);
    const fastGasPriceDisplay = useGasDisplay(maybeFastGasPrice);
    const urgentGasPriceDisplay = useGasDisplay(maybeUrgentGasPrice);
    const normalBaseFeePerGasDisplay = useGasDisplay(maybeNormalBaseFeePerGas);
    const fastBaseFeePerGasDisplay = useGasDisplay(maybeFastBaseFeePerGas);
    const urgentBaseFeePerGasDisplay = useGasDisplay(maybeUrgentBaseFeePerGas);
    const normalMaxPriorityFeePerGasDisplay = useGasDisplay(maybeNormalMaxPriorityFeePerGas);
    const fastMaxPriorityFeePerGasDisplay = useGasDisplay(maybeFastMaxPriorityFeePerGas);
    const urgentMaxPriorityFeePerGasDisplay = useGasDisplay(maybeUrgentMaxPriorityFeePerGas);
    const signOrSend = (0,react.useCallback)(async (action)=>{
        try {
            if (maybeIsEip1559 == null) return;
            const target = option_option/* Option */.W.wrap(maybeFinalTarget).okOrElseSync(()=>{
                return new errors/* UIError */.m("Could not parse or fetch address");
            }).unwrap();
            const value = option_option/* Option */.W.wrap(maybeFinalValue).okOrElseSync(()=>{
                return new errors/* UIError */.m("Could not parse value");
            }).unwrap();
            const nonce = option_option/* Option */.W.wrap(maybeFinalNonce).okOrElseSync(()=>{
                return new errors/* UIError */.m("Could not parse or fetch nonce");
            }).unwrap();
            const data = option_option/* Option */.W.wrap(maybeTriedMaybeFinalData).andThenSync((x)=>x.ok()).okOrElseSync(()=>{
                return new errors/* UIError */.m("Could not parse or encode data");
            }).unwrap();
            const gasLimit = option_option/* Option */.W.wrap(maybeFinalGasLimit).okOrElseSync(()=>{
                return new errors/* UIError */.m("Could not fetch gasLimit");
            }).unwrap();
            let tx;
            let params;
            /**
             * EIP-1559
             */ if (maybeIsEip1559) {
                const maxFeePerGas = option_option/* Option */.W.wrap(maybeFinalMaxFeePerGas).okOrElseSync(()=>{
                    return new errors/* UIError */.m("Could not fetch baseFeePerGas");
                }).unwrap();
                const maxPriorityFeePerGas = option_option/* Option */.W.wrap(maybeFinalMaxPriorityFeePerGas).okOrElseSync(()=>{
                    return new errors/* UIError */.m("Could not fetch maxPriorityFeePerGas");
                }).unwrap();
                tx = transaction/* Transaction */.Y.from({
                    to: types_address/* Address */.k.fromOrThrow(target),
                    gasLimit: gasLimit,
                    chainId: chainData.chainId,
                    maxFeePerGas: maxFeePerGas,
                    maxPriorityFeePerGas: maxPriorityFeePerGas,
                    nonce: Number(nonce),
                    value: value.value,
                    data: data
                });
                params = {
                    from: wallet.address,
                    to: types_address/* Address */.k.fromOrThrow(target),
                    gas: zerohex/* ZeroHexString */.T.from(gasLimit),
                    maxFeePerGas: zerohex/* ZeroHexString */.T.from(maxFeePerGas),
                    maxPriorityFeePerGas: zerohex/* ZeroHexString */.T.from(maxPriorityFeePerGas),
                    value: zerohex/* ZeroHexString */.T.from(value.value),
                    nonce: zerohex/* ZeroHexString */.T.from(nonce),
                    data: data
                };
            } else {
                const gasPrice = option_option/* Option */.W.wrap(maybeFinalGasPrice).okOrElseSync(()=>{
                    return new errors/* UIError */.m("Could not fetch gasPrice");
                }).unwrap();
                tx = transaction/* Transaction */.Y.from({
                    to: types_address/* Address */.k.from(target),
                    gasLimit: gasLimit,
                    chainId: chainData.chainId,
                    gasPrice: gasPrice,
                    nonce: Number(nonce),
                    value: value.value,
                    data: data
                });
                params = {
                    from: wallet.address,
                    to: types_address/* Address */.k.fromOrThrow(target),
                    gas: zerohex/* ZeroHexString */.T.from(gasLimit),
                    gasPrice: zerohex/* ZeroHexString */.T.from(gasPrice),
                    value: zerohex/* ZeroHexString */.T.from(value.value),
                    nonce: zerohex/* ZeroHexString */.T.from(nonce),
                    data: data
                };
            }
            const instance = await entities_wallets_data/* EthereumWalletInstance */.Vy.tryFrom(wallet, context.background).then((r)=>r.unwrap());
            const signature = await instance.trySignTransaction(tx, context.background).then((r)=>r.unwrap());
            tx.signature = signature;
            if (action === "sign") {
                const { chainId } = chainData;
                const uuid = transactionUuid;
                const hash = tx.hash;
                const data = tx.serialized;
                const trial = TransactionTrialRef.create(trialUuid);
                await transactionQuery.mutate(mutators/* Mutators */.g.data({
                    type: "signed",
                    uuid,
                    trial,
                    chainId,
                    hash,
                    data,
                    params
                }));
                return;
            }
            if (action === "send") {
                const { chainId } = chainData;
                const uuid = transactionUuid;
                const hash = tx.hash;
                const data = tx.serialized;
                const trial = TransactionTrialRef.create(trialUuid);
                await context.background.tryRequest({
                    method: "brume_eth_fetch",
                    params: [
                        context.uuid,
                        context.chain.chainId,
                        {
                            method: "eth_sendRawTransaction",
                            params: [
                                data
                            ],
                            noCheck: true
                        }
                    ]
                }).then((r)=>r.unwrap().unwrap());
                await transactionQuery.mutate(mutators/* Mutators */.g.data({
                    type: "pending",
                    uuid,
                    trial,
                    chainId,
                    hash,
                    data,
                    params
                }));
                return;
            }
        } catch (e) {
            errors/* Errors */.D.logAndAlert(e);
        }
    }, [
        wallet,
        context,
        trialUuid,
        transactionUuid,
        transactionQuery,
        chainData,
        maybeFinalTarget,
        maybeFinalValue,
        maybeFinalNonce,
        maybeTriedMaybeFinalData,
        maybeIsEip1559,
        maybeFinalGasLimit,
        maybeFinalMaxFeePerGas,
        maybeFinalMaxPriorityFeePerGas,
        maybeFinalGasPrice
    ]);
    const onSignClick = (0,callback/* useAsyncUniqueCallback */.T)(async ()=>{
        return await signOrSend("sign");
    }, [
        signOrSend
    ]);
    const onSendClick = (0,callback/* useAsyncUniqueCallback */.T)(async ()=>{
        return await signOrSend("send");
    }, [
        signOrSend
    ]);
    const onClose = (0,react.useCallback)(()=>{
        subpath.go("/");
    }, [
        subpath
    ]);
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(path_context/* PathContext */.FM.Provider, {
                value: subpath,
                children: subpath.url.pathname === "/decode" && /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Screen */.lL, {
                    close: onClose,
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)(WalletDecodeScreen, {})
                })
            }),
            (_tokenData_pairs = tokenData.pairs) === null || _tokenData_pairs === void 0 ? void 0 : _tokenData_pairs.map((address, i)=>/*#__PURE__*/ (0,jsx_runtime.jsx)(PriceResolver, {
                    index: i,
                    address: address,
                    ok: onPrice
                }, i)),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(dialog/* Dialog */.Vq.Title, {
                close: close,
                children: [
                    "Transact on ",
                    chainData.name
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-4"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(SimpleBox, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "",
                        children: "Target"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-4"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(SimpleInput, {
                        readOnly: true,
                        value: maybeTarget
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-2"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(SimpleBox, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "",
                        children: "Value"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-4"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "grow flex flex-col overflow-hidden",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "flex items-center",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)(SimpleInput, {
                                        readOnly: true,
                                        value: rawValuedInput,
                                        placeholder: "0.0"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "w-1"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "text-contrast",
                                        children: tokenData.symbol
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "flex items-center cursor-pointer",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "text-contrast truncate",
                                        children: rawPricedInput || "0.0"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "grow"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "text-contrast",
                                        children: "USD"
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-4"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "font-medium",
                children: "Advanced"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-2"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(SimpleBox, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "",
                        children: "Nonce"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-4"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(SimpleInput, {
                        value: rawNonceInput,
                        onChange: onNonceInputChange,
                        placeholder: maybePendingNonce === null || maybePendingNonce === void 0 ? void 0 : maybePendingNonce.toString()
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-1"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(ShrinkableContrastButtonInInputBox, {
                        onClick: onNonceClick,
                        children: "Select"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-2"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "po-md flex flex-col bg-contrast rounded-xl",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "flex items-start",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "",
                                children: "Data"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "w-4"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(SimpleTextarea, {
                                readOnly: disableData,
                                rows: 3,
                                value: rawDataInput,
                                onChange: onDataInputChange,
                                placeholder: "0x0"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-2"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(ShrinkableContrastButtonInTextareaBox, {
                        onClick: onDecodeClick,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(MagnifyingGlassIcon/* default */.Z, {
                                className: "size-4"
                            }),
                            "Decode"
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-4"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "font-medium",
                children: "Gas"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-2"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(SimpleBox, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "",
                        children: "Gas"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-4"
                    }),
                    maybeIsEip1559 === true && /*#__PURE__*/ (0,jsx_runtime.jsxs)("select", {
                        className: "w-full my-0.5 bg-transparent outline-none",
                        value: gasMode,
                        onChange: onGasModeChange,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("option", {
                                value: "urgent",
                                children: "Urgent — ".concat(urgentBaseFeePerGasDisplay, ":").concat(urgentMaxPriorityFeePerGasDisplay, " Gwei — ").concat(urgentMinEip1559GasCostDisplay, "-").concat(urgentMaxEip1559GasCostDisplay)
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("option", {
                                value: "fast",
                                children: "Fast — ".concat(fastBaseFeePerGasDisplay, ":").concat(fastMaxPriorityFeePerGasDisplay, " Gwei — ").concat(fastMinEip1559GasCostDisplay, "-").concat(fastMaxEip1559GasCostDisplay)
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("option", {
                                value: "normal",
                                children: "Normal — ".concat(normalBaseFeePerGasDisplay, ":").concat(normalMaxPriorityFeePerGasDisplay, " Gwei — ").concat(normalMinEip1559GasCostDisplay, "-").concat(normalMaxEip1559GasCostDisplay)
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("option", {
                                value: "custom",
                                children: "Custom"
                            })
                        ]
                    }),
                    maybeIsEip1559 === false && /*#__PURE__*/ (0,jsx_runtime.jsxs)("select", {
                        className: "w-full my-0.5 bg-transparent outline-none",
                        value: gasMode,
                        onChange: onGasModeChange,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("option", {
                                value: "urgent",
                                children: "Urgent — ".concat(urgentGasPriceDisplay, " Gwei — ").concat(urgentLegacyGasCostDisplay)
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("option", {
                                value: "fast",
                                children: "Fast — ".concat(fastGasPriceDisplay, " Gwei — ").concat(fastLegacyGasCostDisplay)
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("option", {
                                value: "normal",
                                children: "Normal — ".concat(normalGasPriceDisplay, " Gwei — ").concat(normalLegacyGasCostDisplay)
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("option", {
                                value: "custom",
                                children: "Custom"
                            })
                        ]
                    })
                ]
            }),
            gasMode === "custom" && maybeIsEip1559 === false && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-2"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(SimpleBox, {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "",
                                children: "Gas Limit"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "w-4"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(SimpleInput, {
                                value: rawGasLimitInput,
                                onChange: onGasLimitInputChange,
                                placeholder: maybeFetchedGasLimit === null || maybeFetchedGasLimit === void 0 ? void 0 : maybeFetchedGasLimit.toString()
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-2"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(SimpleBox, {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "",
                                children: "Gas Price"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "w-4"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(SimpleInput, {
                                value: rawGasPriceInput,
                                onChange: onGasPriceInputChange,
                                placeholder: maybeFetchedGasPrice === null || maybeFetchedGasPrice === void 0 ? void 0 : maybeFetchedGasPrice.toString()
                            })
                        ]
                    })
                ]
            }),
            gasMode === "custom" && maybeIsEip1559 === true && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-2"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(SimpleBox, {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "",
                                children: "Gas Limit"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "w-4"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(SimpleInput, {
                                value: rawGasLimitInput,
                                onChange: onGasLimitInputChange,
                                placeholder: maybeFetchedGasLimit === null || maybeFetchedGasLimit === void 0 ? void 0 : maybeFetchedGasLimit.toString()
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-2"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(SimpleBox, {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "",
                                children: "Base Fee Per Gas"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "w-4"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(SimpleInput, {
                                value: rawBaseFeePerGasInput,
                                onChange: onBaseFeePerGasInputChange,
                                placeholder: maybeFetchedBaseFeePerGas === null || maybeFetchedBaseFeePerGas === void 0 ? void 0 : maybeFetchedBaseFeePerGas.toString()
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-2"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(SimpleBox, {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "",
                                children: "Max Priority Fee Per Gas"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "w-4"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(SimpleInput, {
                                value: rawMaxPriorityFeePerGasInput,
                                onChange: onMaxPriorityFeePerGasInputChange,
                                placeholder: maybeFetchedMaxPriorityFeePerGas === null || maybeFetchedMaxPriorityFeePerGas === void 0 ? void 0 : maybeFetchedMaxPriorityFeePerGas.toString()
                            })
                        ]
                    })
                ]
            }),
            maybeIsEip1559 === false && maybeFinalLegacyGasCost != null && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-2"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "text-contrast",
                        children: [
                            "This transaction is expected to cost ",
                            finalLegacyGasCostDisplay
                        ]
                    })
                ]
            }),
            maybeIsEip1559 === true && maybeFinalMinEip1559GasCost != null && maybeFinalMaxEip1559GasCost != null && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-2"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "text-contrast",
                        children: [
                            "This transaction is expected to cost ",
                            finalMinEip1559GasCostDisplay,
                            " but can cost up to ",
                            finalMaxEip1559GasCostDisplay
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-4 grow"
            }),
            (maybeTransaction === null || maybeTransaction === void 0 ? void 0 : maybeTransaction.type) === "signed" && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(SignedTransactionCard, {
                        data: maybeTransaction,
                        onSend: ()=>{}
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-2"
                    }),
                    (maybeTriedEip1559GasLimitKey === null || maybeTriedEip1559GasLimitKey === void 0 ? void 0 : maybeTriedEip1559GasLimitKey.isErr()) && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "po-md flex items-center bg-contrast rounded-xl text-red-500",
                                children: (_maybeTriedEip1559GasLimitKey_getErr = maybeTriedEip1559GasLimitKey.getErr()) === null || _maybeTriedEip1559GasLimitKey_getErr === void 0 ? void 0 : _maybeTriedEip1559GasLimitKey_getErr.message
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "h-2"
                            })
                        ]
                    }),
                    (maybeTriedLegacyGasLimitKey === null || maybeTriedLegacyGasLimitKey === void 0 ? void 0 : maybeTriedLegacyGasLimitKey.isErr()) && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "po-md flex items-center bg-contrast rounded-xl text-red-500",
                                children: (_maybeTriedLegacyGasLimitKey_getErr = maybeTriedLegacyGasLimitKey.getErr()) === null || _maybeTriedLegacyGasLimitKey_getErr === void 0 ? void 0 : _maybeTriedLegacyGasLimitKey_getErr.message
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "h-2"
                            })
                        ]
                    }),
                    ((_eip1559GasLimitQuery_current1 = eip1559GasLimitQuery.current) === null || _eip1559GasLimitQuery_current1 === void 0 ? void 0 : _eip1559GasLimitQuery_current1.isErr()) && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "po-md flex items-center bg-contrast rounded-xl text-red-500",
                                children: (_eip1559GasLimitQuery_current_getErr = eip1559GasLimitQuery.current.getErr()) === null || _eip1559GasLimitQuery_current_getErr === void 0 ? void 0 : _eip1559GasLimitQuery_current_getErr.message
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "h-2"
                            })
                        ]
                    }),
                    ((_legacyGasLimitQuery_current1 = legacyGasLimitQuery.current) === null || _legacyGasLimitQuery_current1 === void 0 ? void 0 : _legacyGasLimitQuery_current1.isErr()) && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "po-md flex items-center bg-contrast rounded-xl text-red-500",
                                children: (_legacyGasLimitQuery_current_getErr = legacyGasLimitQuery.current.getErr()) === null || _legacyGasLimitQuery_current_getErr === void 0 ? void 0 : _legacyGasLimitQuery_current_getErr.message
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "h-2"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "flex items-center gap-2",
                        children: [
                            !disableSign && /*#__PURE__*/ (0,jsx_runtime.jsxs)(WideShrinkableContrastButton, {
                                disabled: onSignClick.loading,
                                onClick: onSignClick.run,
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)(PencilIcon/* default */.Z, {
                                        className: "size-5"
                                    }),
                                    "Sign"
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)(WideShrinkableOppositeButton, {
                                disabled: onSendClick.loading,
                                onClick: onSendClick.run,
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)(PaperAirplaneIcon/* default */.Z, {
                                        className: "size-5"
                                    }),
                                    "Send"
                                ]
                            })
                        ]
                    })
                ]
            }),
            (maybeTransaction === null || maybeTransaction === void 0 ? void 0 : maybeTransaction.type) === "pending" && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(PendingTransactionCard, {
                        data: maybeTransaction,
                        onRetry: ()=>{}
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-2"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "flex items-center gap-2",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)(WideShrinkableOppositeButton, {
                            onClick: close,
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)(CheckIcon/* default */.Z, {
                                    className: "size-5"
                                }),
                                "Close"
                            ]
                        })
                    })
                ]
            }),
            (maybeTransaction === null || maybeTransaction === void 0 ? void 0 : maybeTransaction.type) === "executed" && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(ExecutedTransactionCard, {
                        data: maybeTransaction
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-2"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "flex items-center gap-2",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)(WideShrinkableOppositeButton, {
                            onClick: close,
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)(CheckIcon/* default */.Z, {
                                    className: "size-5"
                                }),
                                "Close"
                            ]
                        })
                    })
                ]
            }),
            maybeTransaction == null && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                children: [
                    (maybeTriedEip1559GasLimitKey === null || maybeTriedEip1559GasLimitKey === void 0 ? void 0 : maybeTriedEip1559GasLimitKey.isErr()) && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "po-md flex items-center bg-contrast rounded-xl text-red-500",
                                children: (_maybeTriedEip1559GasLimitKey_getErr1 = maybeTriedEip1559GasLimitKey.getErr()) === null || _maybeTriedEip1559GasLimitKey_getErr1 === void 0 ? void 0 : _maybeTriedEip1559GasLimitKey_getErr1.message
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "h-2"
                            })
                        ]
                    }),
                    (maybeTriedLegacyGasLimitKey === null || maybeTriedLegacyGasLimitKey === void 0 ? void 0 : maybeTriedLegacyGasLimitKey.isErr()) && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "po-md flex items-center bg-contrast rounded-xl text-red-500",
                                children: (_maybeTriedLegacyGasLimitKey_getErr1 = maybeTriedLegacyGasLimitKey.getErr()) === null || _maybeTriedLegacyGasLimitKey_getErr1 === void 0 ? void 0 : _maybeTriedLegacyGasLimitKey_getErr1.message
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "h-2"
                            })
                        ]
                    }),
                    ((_eip1559GasLimitQuery_current2 = eip1559GasLimitQuery.current) === null || _eip1559GasLimitQuery_current2 === void 0 ? void 0 : _eip1559GasLimitQuery_current2.isErr()) && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "po-md flex items-center bg-contrast rounded-xl text-red-500",
                                children: (_eip1559GasLimitQuery_current_getErr1 = eip1559GasLimitQuery.current.getErr()) === null || _eip1559GasLimitQuery_current_getErr1 === void 0 ? void 0 : _eip1559GasLimitQuery_current_getErr1.message
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "h-2"
                            })
                        ]
                    }),
                    ((_legacyGasLimitQuery_current2 = legacyGasLimitQuery.current) === null || _legacyGasLimitQuery_current2 === void 0 ? void 0 : _legacyGasLimitQuery_current2.isErr()) && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "po-md flex items-center bg-contrast rounded-xl text-red-500",
                                children: (_legacyGasLimitQuery_current_getErr1 = legacyGasLimitQuery.current.getErr()) === null || _legacyGasLimitQuery_current_getErr1 === void 0 ? void 0 : _legacyGasLimitQuery_current_getErr1.message
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "h-2"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "flex items-center gap-2",
                        children: [
                            !disableSign && /*#__PURE__*/ (0,jsx_runtime.jsxs)(WideShrinkableContrastButton, {
                                disabled: onSignClick.loading,
                                onClick: onSignClick.run,
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)(PencilIcon/* default */.Z, {
                                        className: "size-5"
                                    }),
                                    "Sign"
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)(WideShrinkableOppositeButton, {
                                disabled: onSendClick.loading,
                                onClick: onSendClick.run,
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)(PaperAirplaneIcon/* default */.Z, {
                                        className: "size-5"
                                    }),
                                    "Send"
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    });
}
function ExecutedTransactionCard(props) {
    const { data } = props;
    const onCopy = (0,copy/* useCopy */.F)(data.hash);
    const chainData = mods_chain/* chainByChainId */.DH[data.chainId];
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
        className: "po-md flex items-center bg-contrast rounded-xl",
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "flex flex-col truncate",
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                    className: "flex items-center",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime.jsx)(CheckIcon/* default */.Z, {
                            className: "size-4 shrink-0"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "w-2"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "font-medium",
                            children: "Transaction confirmed"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "text-contrast truncate",
                    children: data.hash
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "h-2"
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                    className: "flex items-center gap-1",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                            className: "group px-2 bg-contrast rounded-full outline-none disabled:opacity-50 transition-opacity",
                            onClick: onCopy.run,
                            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "h-full w-full flex items-center justify-center gap-2 group-active:scale-90 transition-transform",
                                children: [
                                    "Copy",
                                    onCopy.current ? /*#__PURE__*/ (0,jsx_runtime.jsx)(CheckIcon/* default */.Z, {
                                        className: "size-4"
                                    }) : /*#__PURE__*/ (0,jsx_runtime.jsx)(ClipboardIcon/* default */.Z, {
                                        className: "size-4"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsx)("a", {
                            className: "group px-2 bg-contrast rounded-full",
                            target: "_blank",
                            rel: "noreferrer",
                            href: "".concat(chainData.etherscan, "/tx/").concat(data.hash),
                            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "h-full w-full flex items-center justify-center gap-2 group-active:scale-90 transition-transform",
                                children: [
                                    "Open",
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)(ArrowTopRightOnSquareIcon/* default */.Z, {
                                        className: "size-4"
                                    })
                                ]
                            })
                        })
                    ]
                })
            ]
        })
    });
}
function TransactionCard(props) {
    const { data, onSend, onRetry } = props;
    if ((data === null || data === void 0 ? void 0 : data.type) === "signed") return /*#__PURE__*/ (0,jsx_runtime.jsx)(SignedTransactionCard, {
        onSend: onSend,
        data: data
    });
    if ((data === null || data === void 0 ? void 0 : data.type) === "pending") return /*#__PURE__*/ (0,jsx_runtime.jsx)(PendingTransactionCard, {
        onRetry: onRetry,
        data: data
    });
    if ((data === null || data === void 0 ? void 0 : data.type) === "executed") return /*#__PURE__*/ (0,jsx_runtime.jsx)(ExecutedTransactionCard, {
        data: data
    });
    return null;
}
function PendingTransactionCard(props) {
    const { data, onRetry } = props;
    const onCopy = (0,copy/* useCopy */.F)(data.hash);
    const onRetryClick = (0,react.useCallback)(()=>{
        onRetry(data);
    }, [
        data,
        onRetry
    ]);
    const chainData = mods_chain/* chainByChainId */.DH[data.chainId];
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
        className: "po-md flex items-center bg-contrast rounded-xl",
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "flex flex-col truncate",
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                    className: "flex items-center",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime.jsx)(loading/* Loading */.g, {
                            className: "size-4 shrink-0"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "w-2"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "font-medium",
                            children: "Transaction sent"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "text-contrast truncate",
                    children: data.hash
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "h-2"
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                    className: "flex items-center gap-1",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                            className: "group px-2 bg-contrast rounded-full outline-none disabled:opacity-50 transition-opacity",
                            onClick: onCopy.run,
                            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "h-full w-full flex items-center justify-center gap-2 group-active:scale-90 transition-transform",
                                children: [
                                    "Copy",
                                    onCopy.current ? /*#__PURE__*/ (0,jsx_runtime.jsx)(CheckIcon/* default */.Z, {
                                        className: "size-4"
                                    }) : /*#__PURE__*/ (0,jsx_runtime.jsx)(ClipboardIcon/* default */.Z, {
                                        className: "size-4"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsx)("a", {
                            className: "group px-2 bg-contrast rounded-full",
                            target: "_blank",
                            rel: "noreferrer",
                            href: "".concat(chainData.etherscan, "/tx/").concat(data.hash),
                            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "h-full w-full flex items-center justify-center gap-2 group-active:scale-90 transition-transform",
                                children: [
                                    "Open",
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)(ArrowTopRightOnSquareIcon/* default */.Z, {
                                        className: "size-4"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                            className: "group px-2 bg-contrast rounded-full outline-none disabled:opacity-50 transition-opacity",
                            onClick: onRetryClick,
                            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "h-full w-full flex items-center justify-center gap-2 group-active:scale-90 transition-transform",
                                children: [
                                    "Retry",
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)(BoltIcon/* default */.Z, {
                                        className: "size-4"
                                    })
                                ]
                            })
                        })
                    ]
                })
            ]
        })
    });
}
function SignedTransactionCard(props) {
    const { data, onSend } = props;
    const onCopy = (0,copy/* useCopy */.F)(data.data);
    const onSendClick = (0,react.useCallback)(()=>{
        onSend(data);
    }, [
        data,
        onSend
    ]);
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
        className: "po-md flex items-center bg-contrast rounded-xl",
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "flex flex-col truncate",
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "flex items-center",
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "font-medium",
                        children: "Transaction signed"
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "text-contrast truncate",
                    children: data.data
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "h-2"
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                    className: "flex items-center gap-1",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                            className: "group px-2 bg-contrast rounded-full outline-none disabled:opacity-50 transition-opacity",
                            onClick: onCopy.run,
                            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "h-full w-full flex items-center justify-center gap-2 group-active:scale-90 transition-transform",
                                children: [
                                    "Copy",
                                    onCopy.current ? /*#__PURE__*/ (0,jsx_runtime.jsx)(CheckIcon/* default */.Z, {
                                        className: "size-4"
                                    }) : /*#__PURE__*/ (0,jsx_runtime.jsx)(ClipboardIcon/* default */.Z, {
                                        className: "size-4"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                            className: "group px-2 bg-contrast rounded-full outline-none disabled:opacity-50 transition-opacity",
                            onClick: onSendClick,
                            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "h-full w-full flex items-center justify-center gap-2 group-active:scale-90 transition-transform",
                                children: [
                                    "Send",
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)(PaperAirplaneIcon/* default */.Z, {
                                        className: "size-4"
                                    })
                                ]
                            })
                        })
                    ]
                })
            ]
        })
    });
}

;// CONCATENATED MODULE: ./src/mods/foreground/entities/wallets/actions/eth_sendTransaction/index.tsx




function WalletTransactionScreen(props) {
    const $path = (0,path_context/* usePathState */.qf)();
    const [step] = (0,path_context/* useSearchState */.XN)("step", $path);
    if (step === "value") return /*#__PURE__*/ (0,jsx_runtime.jsx)(WalletTransactionScreenValue, {});
    if (step === "nonce") return /*#__PURE__*/ (0,jsx_runtime.jsx)(WalletTransactionScreenNonce, {});
    return null;
}

;// CONCATENATED MODULE: ./src/mods/foreground/entities/wallets/actions/send/direct/contract.tsx






















function WalletDirectSendScreenContractValue(props) {
    var _tokenQuery_current, _valuedBalanceQuery_current, _pricedBalanceQuery_current, _ensTargetQuery_current, _trialQuery_current, _transactionQuery_current, _tokenData_pairs;
    const wallet = (0,wallets_context/* useWalletDataContext */.zI)().unwrap();
    const close = (0,dialog/* useCloseContext */.gX)().unwrap();
    const subpath = (0,path_context/* useSubpath */._u)();
    const $state = (0,path_context/* usePathState */.qf)();
    const [maybeStep, setStep] = (0,path_context/* useSearchState */.XN)("step", $state);
    const [maybeChain, setChain] = (0,path_context/* useSearchState */.XN)("chain", $state);
    const [maybeToken, setToken] = (0,path_context/* useSearchState */.XN)("token", $state);
    const [maybeTarget, setTarget] = (0,path_context/* useSearchState */.XN)("target", $state);
    const [maybeValue, setValue] = (0,path_context/* useSearchState */.XN)("value", $state);
    const [maybeTrial0, setTrial0] = (0,path_context/* useSearchState */.XN)("trial0", $state);
    const trial0UuidFallback = (0,ref/* useConstant */.hS)(()=>crypto.randomUUID());
    const trial0Uuid = option_option/* Option */.W.wrap(maybeTrial0).unwrapOr(trial0UuidFallback);
    (0,react.useEffect)(()=>{
        if (maybeTrial0 === trial0Uuid) return;
        setTrial0(trial0Uuid);
    }, [
        maybeTrial0,
        setTrial0,
        trial0Uuid
    ]);
    const chain = option_option/* Option */.W.unwrap(maybeChain);
    const chainData = mods_chain/* chainByChainId */.DH[Number(chain)];
    const tokenQuery = useToken(chainData.chainId, maybeToken);
    const maybeTokenData = option_option/* Option */.W.wrap((_tokenQuery_current = tokenQuery.current) === null || _tokenQuery_current === void 0 ? void 0 : _tokenQuery_current.ok().get());
    const maybeTokenDef = option_option/* Option */.W.wrap(mods_chain/* tokenByAddress */.q2[maybeToken]);
    const tokenData = maybeTokenData.or(maybeTokenDef).unwrap();
    const context = (0,entities_wallets_data/* useEthereumContext2 */.IL)(wallet.uuid, chainData).unwrap();
    const [prices, setPrices] = (0,react.useState)(()=>{
        if (tokenData.pairs == null) return;
        return new Array(tokenData.pairs.length);
    });
    const onPrice = (0,react.useCallback)((param)=>{
        let [index, data] = param;
        setPrices((prices)=>{
            if (prices == null) return;
            prices[index] = data;
            return [
                ...prices
            ];
        });
    }, []);
    const maybePrice = (0,react.useMemo)(()=>{
        return prices === null || prices === void 0 ? void 0 : prices.reduce((a, b)=>{
            if (b == null) return a;
            return a.mul(types_fixed/* Fixed */.g.from(b));
        }, types_fixed/* Fixed */.g.unit(tokenData.decimals));
    }, [
        prices,
        tokenData
    ]);
    const [rawValuedInput = "", setRawValuedInput] = (0,react.useState)(maybeValue);
    const [rawPricedInput = "", setRawPricedInput] = (0,react.useState)();
    const valuedInput = (0,react.useDeferredValue)(rawValuedInput);
    const getRawPricedInput = (0,react.useCallback)((rawValuedInput)=>{
        try {
            if (rawValuedInput.trim().length === 0) return undefined;
            if (maybePrice == null) return undefined;
            const priced = types_fixed/* Fixed */.g.fromString(rawValuedInput, tokenData.decimals).mul(maybePrice);
            if (priced.value === 0n) return undefined;
            return priced.toString();
        } catch (e) {
            return undefined;
        }
    }, [
        maybePrice,
        tokenData
    ]);
    const getRawValuedInput = (0,react.useCallback)((rawPricedInput)=>{
        try {
            if (rawPricedInput.trim().length === 0) return undefined;
            if (maybePrice == null) return undefined;
            const valued = types_fixed/* Fixed */.g.fromString(rawPricedInput, tokenData.decimals).div(maybePrice);
            if (valued.value === 0n) return undefined;
            return valued.toString();
        } catch (e) {
            return undefined;
        }
    }, [
        maybePrice,
        tokenData
    ]);
    const onValuedChange = (0,react.useCallback)((input)=>{
        setRawPricedInput(getRawPricedInput(input));
    }, [
        getRawPricedInput
    ]);
    const onPricedChange = (0,react.useCallback)((input)=>{
        setRawValuedInput(getRawValuedInput(input));
    }, [
        getRawValuedInput
    ]);
    const setRawValued = (0,react.useCallback)((input)=>{
        setRawValuedInput(input);
        onValuedChange(input);
    }, [
        onValuedChange
    ]);
    const setRawPriced = (0,react.useCallback)((input)=>{
        setRawPricedInput(input);
        onPricedChange(input);
    }, [
        onPricedChange
    ]);
    const onValuedInputChange = (0,events/* useInputChange */.Xy)((e)=>{
        setRawValued(e.target.value);
    }, [
        setRawValued
    ]);
    const onPricedInputChange = (0,events/* useInputChange */.Xy)((e)=>{
        setRawPriced(e.target.value);
    }, [
        setRawPriced
    ]);
    (0,react.useEffect)(()=>{
        if (maybePrice == null) return;
        onValuedChange(valuedInput);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        maybePrice
    ]);
    (0,react.useEffect)(()=>{
        setValue(valuedInput);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        valuedInput
    ]);
    const [mode, setMode] = (0,react.useState)("valued");
    const valuedBalanceQuery = useNativeBalance(wallet.address, "pending", context, prices);
    const pricedBalanceQuery = useNativePricedBalance(wallet.address, "usd", context);
    const valuedBalanceData = (_valuedBalanceQuery_current = valuedBalanceQuery.current) === null || _valuedBalanceQuery_current === void 0 ? void 0 : _valuedBalanceQuery_current.ok().get();
    const pricedBalanceData = (_pricedBalanceQuery_current = pricedBalanceQuery.current) === null || _pricedBalanceQuery_current === void 0 ? void 0 : _pricedBalanceQuery_current.ok().get();
    const onValueMaxClick = (0,react.useCallback)(()=>{
        if (valuedBalanceData == null) return;
        setRawValued(types_fixed/* Fixed */.g.from(valuedBalanceData).toString());
    }, [
        valuedBalanceData,
        setRawValued
    ]);
    const onPricedMaxClick = (0,react.useCallback)(()=>{
        if (pricedBalanceData == null) return;
        setRawPriced(types_fixed/* Fixed */.g.from(pricedBalanceData).toString());
    }, [
        pricedBalanceData,
        setRawPriced
    ]);
    const onValuedPaste = (0,react.useCallback)(async ()=>{
        setRawValued(await navigator.clipboard.readText());
    }, [
        setRawValued
    ]);
    const onPricedPaste = (0,react.useCallback)(async ()=>{
        setRawPriced(await navigator.clipboard.readText());
    }, [
        setRawPriced
    ]);
    const onValuedClear = (0,react.useCallback)(async ()=>{
        setRawValued("");
    }, [
        setRawValued
    ]);
    const onPricedClear = (0,react.useCallback)(async ()=>{
        setRawPriced("");
    }, [
        setRawPriced
    ]);
    const onTargetFocus = (0,react.useCallback)(()=>{
        setStep("target");
    }, [
        setStep
    ]);
    const onPricedClick = (0,react.useCallback)(()=>{
        setMode("priced");
    }, []);
    const onValuedClick = (0,react.useCallback)(()=>{
        setMode("valued");
    }, []);
    const mainnet = (0,entities_wallets_data/* useEthereumContext */.Kn)(wallet.uuid, mods_chain/* chainByChainId */.DH[1]);
    const maybeEnsQueryKey = (maybeTarget === null || maybeTarget === void 0 ? void 0 : maybeTarget.endsWith(".eth")) ? maybeTarget : undefined;
    const ensTargetQuery = (0,names_data/* useEnsLookup */.aZ)(maybeEnsQueryKey, mainnet);
    const maybeEnsTarget = (_ensTargetQuery_current = ensTargetQuery.current) === null || _ensTargetQuery_current === void 0 ? void 0 : _ensTargetQuery_current.ok().get();
    const maybeFinalTarget = (0,react.useMemo)(()=>{
        if (maybeTarget == null) return undefined;
        if (types_address/* Address */.k.from(maybeTarget) != null) return maybeTarget;
        if (maybeEnsTarget != null) return maybeEnsTarget;
        return undefined;
    }, [
        maybeTarget,
        maybeEnsTarget
    ]);
    const rawValue = (0,react.useMemo)(()=>{
        return (maybeValue === null || maybeValue === void 0 ? void 0 : maybeValue.trim().length) ? maybeValue.trim() : "0";
    }, [
        maybeValue
    ]);
    const maybeFinalValue = (0,react.useMemo)(()=>{
        try {
            return types_fixed/* Fixed */.g.fromString(rawValue, tokenData.decimals);
        } catch (e) {}
    }, [
        rawValue,
        tokenData
    ]);
    const maybeTriedMaybeFinalData = (0,react.useMemo)(()=>{
        if (maybeFinalTarget == null) return undefined;
        if (maybeFinalValue == null) return undefined;
        return result/* Result */.x.runAndDoubleWrapSync(()=>{
            const address = types_address/* Address */.k.fromOrThrow(maybeFinalTarget);
            const value = maybeFinalValue.value;
            const abi = TokenAbi.transfer.from(address, value);
            const hex = encode/* encodeOrThrow */.YM(abi);
            return hex;
        });
    }, [
        maybeFinalTarget,
        maybeFinalValue
    ]);
    const onSendTransactionClick = (0,react.useCallback)(()=>{
        subpath.go((0,url/* qurl */.d)("/eth_sendTransaction", {
            trial: trial0Uuid,
            step: "value",
            chain: chainData.chainId,
            target: tokenData.address,
            data: maybeTriedMaybeFinalData === null || maybeTriedMaybeFinalData === void 0 ? void 0 : maybeTriedMaybeFinalData.ok().get(),
            disableTarget: true,
            disableValue: true,
            disableData: true
        }));
    }, [
        subpath,
        trial0Uuid,
        chainData,
        tokenData,
        maybeTriedMaybeFinalData
    ]);
    const onClose = (0,react.useCallback)(()=>{
        subpath.go("/");
    }, [
        subpath
    ]);
    const trialQuery = useTransactionTrial(trial0Uuid);
    const maybeTrialData = (_trialQuery_current = trialQuery.current) === null || _trialQuery_current === void 0 ? void 0 : _trialQuery_current.ok().get();
    const transactionQuery = useTransactionWithReceipt(maybeTrialData === null || maybeTrialData === void 0 ? void 0 : maybeTrialData.transactions[0].uuid, context);
    const maybeTransaction = (_transactionQuery_current = transactionQuery.current) === null || _transactionQuery_current === void 0 ? void 0 : _transactionQuery_current.ok().get();
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(path_context/* PathContext */.FM.Provider, {
                value: subpath,
                children: subpath.url.pathname === "/eth_sendTransaction" && /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Screen */.lL, {
                    close: onClose,
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)(WalletTransactionScreen, {})
                })
            }),
            (_tokenData_pairs = tokenData.pairs) === null || _tokenData_pairs === void 0 ? void 0 : _tokenData_pairs.map((address, i)=>/*#__PURE__*/ (0,jsx_runtime.jsx)(PriceResolver, {
                    index: i,
                    address: address,
                    ok: onPrice
                }, i)),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(dialog/* Dialog */.Vq.Title, {
                close: close,
                children: [
                    "Send ",
                    tokenData.symbol,
                    " on ",
                    chainData.name
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-4"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(SimpleBox, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "",
                        children: "Target"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-4"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(SimpleInput, {
                        readOnly: true,
                        onFocus: onTargetFocus,
                        value: maybeTarget
                    }, "target")
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-2"
            }),
            mode === "valued" && /*#__PURE__*/ (0,jsx_runtime.jsxs)(SimpleBox, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "",
                        children: "Value"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-4"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "grow flex flex-col overflow-hidden",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "flex items-center",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)(SimpleInput, {
                                        autoFocus: true,
                                        value: rawValuedInput,
                                        onChange: onValuedInputChange,
                                        placeholder: "0.0"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "w-1"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "text-contrast",
                                        children: tokenData.symbol
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "flex items-center cursor-pointer",
                                role: "button",
                                onClick: onPricedClick,
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "text-contrast truncate",
                                        children: rawPricedInput || "0.0"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "grow"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "text-contrast",
                                        children: "USD"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-2"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "flex items-center",
                        children: [
                            rawValuedInput.length === 0 ? /*#__PURE__*/ (0,jsx_runtime.jsx)(ShrinkableNakedButtonInInputBox, {
                                onClick: onValuedPaste,
                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(ClipboardIcon/* default */.Z, {
                                    className: "size-4"
                                })
                            }) : /*#__PURE__*/ (0,jsx_runtime.jsx)(ShrinkableNakedButtonInInputBox, {
                                onClick: onValuedClear,
                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(XMarkIcon/* default */.Z, {
                                    className: "size-4"
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "w-1"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(ShrinkableContrastButtonInInputBox, {
                                disabled: valuedBalanceQuery.data == null,
                                onClick: onValueMaxClick,
                                children: "100%"
                            })
                        ]
                    })
                ]
            }),
            mode === "priced" && /*#__PURE__*/ (0,jsx_runtime.jsxs)(SimpleBox, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "",
                        children: "Value"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-4"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "grow flex flex-col overflow-hidden",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "flex items-center",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)(SimpleInput, {
                                        autoFocus: true,
                                        value: rawPricedInput,
                                        onChange: onPricedInputChange,
                                        placeholder: "0.0"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "w-1"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "text-contrast",
                                        children: "USD"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "flex items-center cursor-pointer",
                                role: "button",
                                onClick: onValuedClick,
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "text-contrast truncate",
                                        children: rawValuedInput || "0.0"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "grow"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "text-contrast",
                                        children: tokenData.symbol
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-2"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "flex items-center",
                        children: [
                            rawPricedInput.length === 0 ? /*#__PURE__*/ (0,jsx_runtime.jsx)(ShrinkableNakedButtonInInputBox, {
                                onClick: onPricedPaste,
                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(ClipboardIcon/* default */.Z, {
                                    className: "size-4"
                                })
                            }) : /*#__PURE__*/ (0,jsx_runtime.jsx)(ShrinkableNakedButtonInInputBox, {
                                onClick: onPricedClear,
                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(XMarkIcon/* default */.Z, {
                                    className: "size-4"
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "w-1"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(ShrinkableContrastButtonInInputBox, {
                                disabled: pricedBalanceQuery.data == null,
                                onClick: onPricedMaxClick,
                                children: "100%"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-4"
            }),
            maybeTransaction != null && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "font-medium",
                        children: "Transfer"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-2"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(TransactionCard, {
                        data: maybeTransaction,
                        onSend: ()=>{},
                        onRetry: ()=>{}
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-4"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-4 grow"
            }),
            maybeTransaction == null && /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "flex items-center",
                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)(WideShrinkableOppositeButton, {
                    onClick: onSendTransactionClick,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime.jsx)(PaperAirplaneIcon/* default */.Z, {
                            className: "size-5"
                        }),
                        "Transact"
                    ]
                })
            }),
            maybeTransaction != null && /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "flex items-center gap-2",
                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)(WideShrinkableOppositeButton, {
                    onClick: close,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime.jsx)(CheckIcon/* default */.Z, {
                            className: "size-5"
                        }),
                        "Close"
                    ]
                })
            })
        ]
    });
}

;// CONCATENATED MODULE: ./src/mods/foreground/entities/wallets/actions/send/direct/screen.tsx





















function WalletDirectSendScreenNativeValue(props) {
    var _valuedBalanceQuery_current, _pricedBalanceQuery_current, _ensTargetQuery_current, _trialQuery_current, _transactionQuery_current, _tokenData_pairs;
    const wallet = (0,wallets_context/* useWalletDataContext */.zI)().unwrap();
    const close = (0,dialog/* useCloseContext */.gX)().unwrap();
    const subpath = (0,path_context/* useSubpath */._u)();
    const $state = (0,path_context/* usePathState */.qf)();
    const [maybeStep, setStep] = (0,path_context/* useSearchState */.XN)("step", $state);
    const [maybeChain, setChain] = (0,path_context/* useSearchState */.XN)("chain", $state);
    const [maybeTarget, setTarget] = (0,path_context/* useSearchState */.XN)("target", $state);
    const [maybeValue, setValue] = (0,path_context/* useSearchState */.XN)("value", $state);
    const [maybeTrial0, setTrial0] = (0,path_context/* useSearchState */.XN)("trial0", $state);
    const trial0UuidFallback = (0,ref/* useConstant */.hS)(()=>crypto.randomUUID());
    const trial0Uuid = option_option/* Option */.W.wrap(maybeTrial0).unwrapOr(trial0UuidFallback);
    (0,react.useEffect)(()=>{
        if (maybeTrial0 === trial0Uuid) return;
        setTrial0(trial0Uuid);
    }, [
        maybeTrial0,
        setTrial0,
        trial0Uuid
    ]);
    const chain = option_option/* Option */.W.unwrap(maybeChain);
    const chainData = mods_chain/* chainByChainId */.DH[Number(chain)];
    const tokenData = chainData.token;
    const context = (0,entities_wallets_data/* useEthereumContext2 */.IL)(wallet.uuid, chainData).unwrap();
    const [prices, setPrices] = (0,react.useState)(()=>{
        if (tokenData.pairs == null) return;
        return new Array(tokenData.pairs.length);
    });
    const onPrice = (0,react.useCallback)((param)=>{
        let [index, data] = param;
        setPrices((prices)=>{
            if (prices == null) return;
            prices[index] = data;
            return [
                ...prices
            ];
        });
    }, []);
    const maybePrice = (0,react.useMemo)(()=>{
        return prices === null || prices === void 0 ? void 0 : prices.reduce((a, b)=>{
            if (b == null) return a;
            return a.mul(types_fixed/* Fixed */.g.from(b));
        }, types_fixed/* Fixed */.g.unit(tokenData.decimals));
    }, [
        prices,
        tokenData
    ]);
    const [rawValuedInput = "", setRawValuedInput] = (0,react.useState)(maybeValue);
    const [rawPricedInput = "", setRawPricedInput] = (0,react.useState)();
    const valuedInput = (0,react.useDeferredValue)(rawValuedInput);
    const getRawPricedInput = (0,react.useCallback)((rawValuedInput)=>{
        try {
            if (rawValuedInput.trim().length === 0) return undefined;
            if (maybePrice == null) return undefined;
            const priced = types_fixed/* Fixed */.g.fromString(rawValuedInput, tokenData.decimals).mul(maybePrice);
            if (priced.value === 0n) return undefined;
            return priced.toString();
        } catch (e) {
            return undefined;
        }
    }, [
        maybePrice,
        tokenData
    ]);
    const getRawValuedInput = (0,react.useCallback)((rawPricedInput)=>{
        try {
            if (rawPricedInput.trim().length === 0) return undefined;
            if (maybePrice == null) return undefined;
            const valued = types_fixed/* Fixed */.g.fromString(rawPricedInput, tokenData.decimals).div(maybePrice);
            if (valued.value === 0n) return undefined;
            return valued.toString();
        } catch (e) {
            return undefined;
        }
    }, [
        maybePrice,
        tokenData
    ]);
    const onValuedChange = (0,react.useCallback)((input)=>{
        setRawPricedInput(getRawPricedInput(input));
    }, [
        getRawPricedInput
    ]);
    const onPricedChange = (0,react.useCallback)((input)=>{
        setRawValuedInput(getRawValuedInput(input));
    }, [
        getRawValuedInput
    ]);
    const setRawValued = (0,react.useCallback)((input)=>{
        setRawValuedInput(input);
        onValuedChange(input);
    }, [
        onValuedChange
    ]);
    const setRawPriced = (0,react.useCallback)((input)=>{
        setRawPricedInput(input);
        onPricedChange(input);
    }, [
        onPricedChange
    ]);
    const onValuedInputChange = (0,events/* useInputChange */.Xy)((e)=>{
        setRawValued(e.target.value);
    }, [
        setRawValued
    ]);
    const onPricedInputChange = (0,events/* useInputChange */.Xy)((e)=>{
        setRawPriced(e.target.value);
    }, [
        setRawPriced
    ]);
    (0,react.useEffect)(()=>{
        if (maybePrice == null) return;
        onValuedChange(valuedInput);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        maybePrice
    ]);
    (0,react.useEffect)(()=>{
        setValue(valuedInput);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        valuedInput
    ]);
    const [mode, setMode] = (0,react.useState)("valued");
    const valuedBalanceQuery = useNativeBalance(wallet.address, "pending", context, prices);
    const pricedBalanceQuery = useNativePricedBalance(wallet.address, "usd", context);
    const valuedBalanceData = (_valuedBalanceQuery_current = valuedBalanceQuery.current) === null || _valuedBalanceQuery_current === void 0 ? void 0 : _valuedBalanceQuery_current.ok().get();
    const pricedBalanceData = (_pricedBalanceQuery_current = pricedBalanceQuery.current) === null || _pricedBalanceQuery_current === void 0 ? void 0 : _pricedBalanceQuery_current.ok().get();
    const onValueMaxClick = (0,react.useCallback)(()=>{
        if (valuedBalanceData == null) return;
        setRawValued(types_fixed/* Fixed */.g.from(valuedBalanceData).toString());
    }, [
        valuedBalanceData,
        setRawValued
    ]);
    const onPricedMaxClick = (0,react.useCallback)(()=>{
        if (pricedBalanceData == null) return;
        setRawPriced(types_fixed/* Fixed */.g.from(pricedBalanceData).toString());
    }, [
        pricedBalanceData,
        setRawPriced
    ]);
    const onValuedPaste = (0,react.useCallback)(async ()=>{
        setRawValued(await navigator.clipboard.readText());
    }, [
        setRawValued
    ]);
    const onPricedPaste = (0,react.useCallback)(async ()=>{
        setRawPriced(await navigator.clipboard.readText());
    }, [
        setRawPriced
    ]);
    const onValuedClear = (0,react.useCallback)(async ()=>{
        setRawValued("");
    }, [
        setRawValued
    ]);
    const onPricedClear = (0,react.useCallback)(async ()=>{
        setRawPriced("");
    }, [
        setRawPriced
    ]);
    const onTargetFocus = (0,react.useCallback)(()=>{
        setStep("target");
    }, [
        setStep
    ]);
    const onNonceClick = (0,react.useCallback)(()=>{
        setStep("nonce");
    }, [
        setStep
    ]);
    const onPricedClick = (0,react.useCallback)(()=>{
        setMode("priced");
    }, []);
    const onValuedClick = (0,react.useCallback)(()=>{
        setMode("valued");
    }, []);
    const mainnet = (0,entities_wallets_data/* useEthereumContext */.Kn)(wallet.uuid, mods_chain/* chainByChainId */.DH[1]);
    const maybeEnsQueryKey = (maybeTarget === null || maybeTarget === void 0 ? void 0 : maybeTarget.endsWith(".eth")) ? maybeTarget : undefined;
    const ensTargetQuery = (0,names_data/* useEnsLookup */.aZ)(maybeEnsQueryKey, mainnet);
    const maybeEnsTarget = (_ensTargetQuery_current = ensTargetQuery.current) === null || _ensTargetQuery_current === void 0 ? void 0 : _ensTargetQuery_current.ok().get();
    const maybeFinalTarget = (0,react.useMemo)(()=>{
        if (maybeTarget == null) return undefined;
        if (types_address/* Address */.k.from(maybeTarget) != null) return maybeTarget;
        if (maybeEnsTarget != null) return maybeEnsTarget;
        return undefined;
    }, [
        maybeTarget,
        maybeEnsTarget
    ]);
    const rawValue = (0,react.useMemo)(()=>{
        return (maybeValue === null || maybeValue === void 0 ? void 0 : maybeValue.trim().length) ? maybeValue.trim() : "0";
    }, [
        maybeValue
    ]);
    const maybeFinalValue = (0,react.useMemo)(()=>{
        try {
            return types_fixed/* Fixed */.g.fromString(rawValue, tokenData.decimals);
        } catch (e) {}
    }, [
        rawValue,
        tokenData
    ]);
    const onSendTransactionClick = (0,react.useCallback)(()=>{
        subpath.go((0,url/* qurl */.d)("/eth_sendTransaction", {
            trial: trial0Uuid,
            step: "value",
            chain: chainData.chainId,
            target: maybeFinalTarget,
            value: maybeFinalValue === null || maybeFinalValue === void 0 ? void 0 : maybeFinalValue.toString(),
            disableTarget: true,
            disableValue: true
        }));
    }, [
        subpath,
        trial0Uuid,
        chainData.chainId,
        maybeFinalValue,
        maybeFinalTarget
    ]);
    const onClose = (0,react.useCallback)(()=>{
        subpath.go("/");
    }, [
        subpath
    ]);
    const trialQuery = useTransactionTrial(trial0Uuid);
    const maybeTrialData = (_trialQuery_current = trialQuery.current) === null || _trialQuery_current === void 0 ? void 0 : _trialQuery_current.ok().get();
    const transactionQuery = useTransactionWithReceipt(maybeTrialData === null || maybeTrialData === void 0 ? void 0 : maybeTrialData.transactions[0].uuid, context);
    const maybeTransaction = (_transactionQuery_current = transactionQuery.current) === null || _transactionQuery_current === void 0 ? void 0 : _transactionQuery_current.ok().get();
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(path_context/* PathContext */.FM.Provider, {
                value: subpath,
                children: subpath.url.pathname === "/eth_sendTransaction" && /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Screen */.lL, {
                    close: onClose,
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)(WalletTransactionScreen, {})
                })
            }),
            (_tokenData_pairs = tokenData.pairs) === null || _tokenData_pairs === void 0 ? void 0 : _tokenData_pairs.map((address, i)=>/*#__PURE__*/ (0,jsx_runtime.jsx)(PriceResolver, {
                    index: i,
                    address: address,
                    ok: onPrice
                }, i)),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(dialog/* Dialog */.Vq.Title, {
                close: close,
                children: [
                    "Transact on ",
                    chainData.name
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-4"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(SimpleBox, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "",
                        children: "Target"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-4"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(SimpleInput, {
                        readOnly: true,
                        onFocus: onTargetFocus,
                        value: maybeTarget
                    }, "target")
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-2"
            }),
            mode === "valued" && /*#__PURE__*/ (0,jsx_runtime.jsxs)(SimpleBox, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "",
                        children: "Value"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-4"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "grow flex flex-col overflow-hidden",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "flex items-center",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)(SimpleInput, {
                                        autoFocus: true,
                                        value: rawValuedInput,
                                        onChange: onValuedInputChange,
                                        placeholder: "0.0"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "w-1"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "text-contrast",
                                        children: tokenData.symbol
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "flex items-center cursor-pointer",
                                role: "button",
                                onClick: onPricedClick,
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "text-contrast truncate",
                                        children: rawPricedInput || "0.0"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "grow"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "text-contrast",
                                        children: "USD"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-2"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "flex items-center",
                        children: [
                            rawValuedInput.length === 0 ? /*#__PURE__*/ (0,jsx_runtime.jsx)(ShrinkableNakedButtonInInputBox, {
                                onClick: onValuedPaste,
                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(ClipboardIcon/* default */.Z, {
                                    className: "size-4"
                                })
                            }) : /*#__PURE__*/ (0,jsx_runtime.jsx)(ShrinkableNakedButtonInInputBox, {
                                onClick: onValuedClear,
                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(XMarkIcon/* default */.Z, {
                                    className: "size-4"
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "w-1"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(ShrinkableContrastButtonInInputBox, {
                                disabled: valuedBalanceQuery.data == null,
                                onClick: onValueMaxClick,
                                children: "100%"
                            })
                        ]
                    })
                ]
            }),
            mode === "priced" && /*#__PURE__*/ (0,jsx_runtime.jsxs)(SimpleBox, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "",
                        children: "Value"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-4"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "grow flex flex-col overflow-hidden",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "flex items-center",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)(SimpleInput, {
                                        autoFocus: true,
                                        value: rawPricedInput,
                                        onChange: onPricedInputChange,
                                        placeholder: "0.0"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "w-1"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "text-contrast",
                                        children: "USD"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "flex items-center cursor-pointer",
                                role: "button",
                                onClick: onValuedClick,
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "text-contrast truncate",
                                        children: rawValuedInput || "0.0"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "grow"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "text-contrast",
                                        children: tokenData.symbol
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-2"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "flex items-center",
                        children: [
                            rawPricedInput.length === 0 ? /*#__PURE__*/ (0,jsx_runtime.jsx)(ShrinkableNakedButtonInInputBox, {
                                onClick: onPricedPaste,
                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(ClipboardIcon/* default */.Z, {
                                    className: "size-4"
                                })
                            }) : /*#__PURE__*/ (0,jsx_runtime.jsx)(ShrinkableNakedButtonInInputBox, {
                                onClick: onPricedClear,
                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(XMarkIcon/* default */.Z, {
                                    className: "size-4"
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "w-1"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(ShrinkableContrastButtonInInputBox, {
                                disabled: pricedBalanceQuery.data == null,
                                onClick: onPricedMaxClick,
                                children: "100%"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-4"
            }),
            maybeTransaction != null && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "font-medium",
                        children: "Transfer"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-2"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(screen_TransactionCard, {
                        data: maybeTransaction,
                        onSend: ()=>{},
                        onRetry: ()=>{}
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-4"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-4 grow"
            }),
            maybeTransaction == null && /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "flex items-center",
                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)(WideShrinkableOppositeButton, {
                    onClick: onSendTransactionClick,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime.jsx)(PaperAirplaneIcon/* default */.Z, {
                            className: "size-5"
                        }),
                        "Transact"
                    ]
                })
            }),
            maybeTransaction != null && /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "flex items-center gap-2",
                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)(WideShrinkableOppositeButton, {
                    onClick: close,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime.jsx)(CheckIcon/* default */.Z, {
                            className: "size-5"
                        }),
                        "Close"
                    ]
                })
            })
        ]
    });
}
function screen_ExecutedTransactionCard(props) {
    const { data } = props;
    const onCopy = (0,copy/* useCopy */.F)(data.hash);
    const chainData = mods_chain/* chainByChainId */.DH[data.chainId];
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
        className: "po-md flex items-center bg-contrast rounded-xl",
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "flex flex-col truncate",
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                    className: "flex items-center",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime.jsx)(CheckIcon/* default */.Z, {
                            className: "size-4 shrink-0"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "w-2"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "font-medium",
                            children: "Transaction confirmed"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "text-contrast truncate",
                    children: data.hash
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "h-2"
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                    className: "flex items-center gap-1",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                            className: "group px-2 bg-contrast rounded-full outline-none disabled:opacity-50 transition-opacity",
                            onClick: onCopy.run,
                            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "h-full w-full flex items-center justify-center gap-2 group-active:scale-90 transition-transform",
                                children: [
                                    "Copy",
                                    onCopy.current ? /*#__PURE__*/ (0,jsx_runtime.jsx)(CheckIcon/* default */.Z, {
                                        className: "size-4"
                                    }) : /*#__PURE__*/ (0,jsx_runtime.jsx)(ClipboardIcon/* default */.Z, {
                                        className: "size-4"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsx)("a", {
                            className: "group px-2 bg-contrast rounded-full",
                            target: "_blank",
                            rel: "noreferrer",
                            href: "".concat(chainData.etherscan, "/tx/").concat(data.hash),
                            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "h-full w-full flex items-center justify-center gap-2 group-active:scale-90 transition-transform",
                                children: [
                                    "Open",
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)(ArrowTopRightOnSquareIcon/* default */.Z, {
                                        className: "size-4"
                                    })
                                ]
                            })
                        })
                    ]
                })
            ]
        })
    });
}
function screen_TransactionCard(props) {
    const { data, onSend, onRetry } = props;
    if ((data === null || data === void 0 ? void 0 : data.type) === "signed") return /*#__PURE__*/ (0,jsx_runtime.jsx)(screen_SignedTransactionCard, {
        onSend: onSend,
        data: data
    });
    if ((data === null || data === void 0 ? void 0 : data.type) === "pending") return /*#__PURE__*/ (0,jsx_runtime.jsx)(screen_PendingTransactionCard, {
        onRetry: onRetry,
        data: data
    });
    if ((data === null || data === void 0 ? void 0 : data.type) === "executed") return /*#__PURE__*/ (0,jsx_runtime.jsx)(screen_ExecutedTransactionCard, {
        data: data
    });
    return null;
}
function screen_PendingTransactionCard(props) {
    const { data, onRetry } = props;
    const onCopy = (0,copy/* useCopy */.F)(data.hash);
    const onRetryClick = (0,react.useCallback)(()=>{
        onRetry(data);
    }, [
        data,
        onRetry
    ]);
    const chainData = mods_chain/* chainByChainId */.DH[data.chainId];
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
        className: "po-md flex items-center bg-contrast rounded-xl",
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "flex flex-col truncate",
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                    className: "flex items-center",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime.jsx)(loading/* Loading */.g, {
                            className: "size-4 shrink-0"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "w-2"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "font-medium",
                            children: "Transaction sent"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "text-contrast truncate",
                    children: data.hash
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "h-2"
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                    className: "flex items-center gap-1",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                            className: "group px-2 bg-contrast rounded-full outline-none disabled:opacity-50 transition-opacity",
                            onClick: onCopy.run,
                            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "h-full w-full flex items-center justify-center gap-2 group-active:scale-90 transition-transform",
                                children: [
                                    "Copy",
                                    onCopy.current ? /*#__PURE__*/ (0,jsx_runtime.jsx)(CheckIcon/* default */.Z, {
                                        className: "size-4"
                                    }) : /*#__PURE__*/ (0,jsx_runtime.jsx)(ClipboardIcon/* default */.Z, {
                                        className: "size-4"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsx)("a", {
                            className: "group px-2 bg-contrast rounded-full",
                            target: "_blank",
                            rel: "noreferrer",
                            href: "".concat(chainData.etherscan, "/tx/").concat(data.hash),
                            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "h-full w-full flex items-center justify-center gap-2 group-active:scale-90 transition-transform",
                                children: [
                                    "Open",
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)(ArrowTopRightOnSquareIcon/* default */.Z, {
                                        className: "size-4"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                            className: "group px-2 bg-contrast rounded-full outline-none disabled:opacity-50 transition-opacity",
                            onClick: onRetryClick,
                            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "h-full w-full flex items-center justify-center gap-2 group-active:scale-90 transition-transform",
                                children: [
                                    "Retry",
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)(BoltIcon/* default */.Z, {
                                        className: "size-4"
                                    })
                                ]
                            })
                        })
                    ]
                })
            ]
        })
    });
}
function screen_SignedTransactionCard(props) {
    const { data, onSend } = props;
    const onCopy = (0,copy/* useCopy */.F)(data.data);
    const onSendClick = (0,react.useCallback)(()=>{
        onSend(data);
    }, [
        data,
        onSend
    ]);
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
        className: "po-md flex items-center bg-contrast rounded-xl",
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "flex flex-col truncate",
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "flex items-center",
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "font-medium",
                        children: "Transaction signed"
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "text-contrast truncate",
                    children: data.data
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "h-2"
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                    className: "flex items-center gap-1",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                            className: "group px-2 bg-contrast rounded-full outline-none disabled:opacity-50 transition-opacity",
                            onClick: onCopy.run,
                            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "h-full w-full flex items-center justify-center gap-2 group-active:scale-90 transition-transform",
                                children: [
                                    "Copy",
                                    onCopy.current ? /*#__PURE__*/ (0,jsx_runtime.jsx)(CheckIcon/* default */.Z, {
                                        className: "size-4"
                                    }) : /*#__PURE__*/ (0,jsx_runtime.jsx)(ClipboardIcon/* default */.Z, {
                                        className: "size-4"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                            className: "group px-2 bg-contrast rounded-full outline-none disabled:opacity-50 transition-opacity",
                            onClick: onSendClick,
                            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "h-full w-full flex items-center justify-center gap-2 group-active:scale-90 transition-transform",
                                children: [
                                    "Send",
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)(PaperAirplaneIcon/* default */.Z, {
                                        className: "size-4"
                                    })
                                ]
                            })
                        })
                    ]
                })
            ]
        })
    });
}

;// CONCATENATED MODULE: ./src/libs/abi/peanut.abi.ts

var PeanutAbi;
(function(PeanutAbi) {
    PeanutAbi.makeDeposit = function_function/* FunctionSelectorAndArguments */.b0.create(function_function/* FunctionSelector */.xS.from([
        243,
        71,
        128,
        17
    ]), tuple/* Tuple */.p.create(address/* Address */.kL, int_int/* Int8 */.tJ, int_int/* Int256 */.R4, int_int/* Int256 */.R4, address/* Address */.kL));
})(PeanutAbi || (PeanutAbi = {}));

;// CONCATENATED MODULE: ./src/libs/peanut/contracts.json
var contracts_namespaceObject = JSON.parse('{"1":{"name":"ethereum-mainnet","mainnet":"true","v3":"0xdB60C736A30C41D9df0081057Eae73C3eb119895","v4":"0x40F3548E54a55B9cC21D5EeC3ddcAc151782c7E0","Bv4":"0x05C94c7A5f2FD53F3DC5E0a3F62F2E31F0013bc3"},"5":{"name":"ethereum-goerli","mainnet":"false","v1":"0x616d197A29E50EBD08a4287b26e47041286F171D","v2":"0xd4964Df4dc2eb6B2fD4157DFda264AA9dd720C92","v3":"0xd068b1F6F0623CbCC7ADC7545290f8991C9B8Ec9","v4":"0x891021b34fedc18e36c015bffaa64a2421738906","Bv4":"0xD605357aBbAF57d118c8DeDf6F2d71aEFa3ba9c5","v5":"0x690481Ce72b1080Bd928A35A0ECF329BE902cD6a","v4.2":"0xda92eaf9f557fa9997Eb597a8624256E920AE735","Rv4.2":"0xc2b7869b5963FEBF801c11ccE8D165D0572061Ba"},"10":{"name":"optimism-mainnet","mainnet":"true","v1":"0x9B0817fA08b46670B92300B58AA1f4AB155701ea","v3":"0x1aBe03DC4706aE47c4F2ae04EEBe5c8607c74e17","Bv4":"0x8471d15dE1f44c66cBDc30CBA8ce5cedf546DB8E","v4":"0xc430C74f02670823bB231DeD2c6bFd4e8C54F970","v5":"0x690481Ce72b1080Bd928A35A0ECF329BE902cD6a"},"56":{"name":"bsc-mainnet","mainnet":"true","v3":"0x8d1a17A3A4504aEB17515645BA8098f1D75237f7","v4":"0x0abfA78f307920e0C1a463BCf5A16cA3F586c43c","Bv4":"0x287b67a4D320c15CE5569A09de4D8f6Cea1198f6"},"97":{"name":"bsc-testnet","mainnet":"false"},"100":{"name":"xdai-mainnet","mainnet":"true","v1":"0x8d1a17A3A4504aEB17515645BA8098f1D75237f7","v3":"0x897F8EDdB345F0d16081615823F76055Ad60A00c","v4":"0x0D3492437E86dabb67F2bCfAE5c597D2edA67D65","Bv4":"0x3857D844514f3c5230d2e05A7eC87593F2180A78"},"137":{"name":"polygon-mainnet","mainnet":"true","v1":"0xB184b7D19d747Db9084C355b5B6a093d7063B710","v2":"0x45fd48f58c47d929E9D181837fBB7Cda1974a773","v3":"0xCEd763C2Ff8d5B726b8a5D480c17C24B6686837F","v4":"0x86e2ab83ac9d91c618a3258653063beba0ff9461","Bv4":"0x3f3166f35dCb5F397bd16d7e40918c1c4A52BDb5","v5":"0x690481Ce72b1080Bd928A35A0ECF329BE902cD6a","v4.2":"0xb600a2B1bD58781e91B3bad3622EdF630089F13C","Rv4.2":"0xBF9688FF5302Ad722343140cEd16EBE30db86c25"},"420":{"name":"optimism-goerli","mainnet":"false","v3":"0xDC608f2Bc4f0AFf02D12d51Ca8b543B343525c8a","v4":"0xD3fBCb1AF168e985c5Ab20B0D2dbe39840043291","Bv4":"0x131562e5b24F1aE3931750114fC541c104b835Ff","v5":"0x690481Ce72b1080Bd928A35A0ECF329BE902cD6a"},"1442":{"name":"polygon-zkevm-testnet","mainnet":"false","v4":"0x8d1a17A3A4504aEB17515645BA8098f1D75237f7","Bv4":"0x7B36e10AA3ff44576efF4b1AfB80587B9b3BA3a5","v5":"0x690481Ce72b1080Bd928A35A0ECF329BE902cD6a"},"2001":{"name":"milkomeda-c1","mainnet":"true","v3":"0x897F8EDdB345F0d16081615823F76055Ad60A00c","v4":"0x1851359AB8B002217cf4D108d7F027B63563754C"},"5001":{"name":"mantle-testnet","mainnet":"false","v5":"0x690481Ce72b1080Bd928A35A0ECF329BE902cD6a"},"8453":{"name":"base","mainnet":"true","v4":"0x5c1b67ED2809e371aabbc58D934282E8Aa7E3fd4","Bv4":"0xa1F413760E942dbbBDD36589526A11f4C013085b","v5":"0x690481Ce72b1080Bd928A35A0ECF329BE902cD6a","v4.2":"0x6D0F2572bD08d83c065214b35e7322C111ffEd21","Rv4.2":"0x67ec70F9660b0d9C1Fb0A4C6B562ebc46F0aC3E3"},"10200":{"name":"gnosis chiado testnet","mainnet":"false","v4":"0x8d1a17A3A4504aEB17515645BA8098f1D75237f7","Bv4":"0x7B36e10AA3ff44576efF4b1AfB80587B9b3BA3a5","v5":"0x690481Ce72b1080Bd928A35A0ECF329BE902cD6a"},"17000":{"name":"ethereum holesky testnet","mainnet":"false","v4":"0x8d1a17A3A4504aEB17515645BA8098f1D75237f7","Bv4":"0x7B36e10AA3ff44576efF4b1AfB80587B9b3BA3a5","v5":"0x690481Ce72b1080Bd928A35A0ECF329BE902cD6a","v4.2":"0xA79369EeB1022E7805aF681dbf7f2dee318f80B0","Rv4.2":"0x0b2B87bc6F5D93BBEE6B02011d4174bEa1F1eB89"},"42161":{"name":"arbitrum-mainnet","mainnet":"true","v1":"0x8d1a17A3A4504aEB17515645BA8098f1D75237f7","v3":"0x9B0817fA08b46670B92300B58AA1f4AB155701ea","Bv4":"0x61b1139B385d8F24b6708fC657afAf3d5D34252c","v4":"0x831D561607516Dfb11D06393FFE8336f84d625BD","v5":"0x690481Ce72b1080Bd928A35A0ECF329BE902cD6a"},"43113":{"name":"avalanche-fuji","mainnet":"false"},"43114":{"name":"avalanche-mainnet","mainnet":"true","v1":"0x8d1a17A3A4504aEB17515645BA8098f1D75237f7","v4":"0x7B36e10AA3ff44576efF4b1AfB80587B9b3BA3a5","Bv4":"0x897F8EDdB345F0d16081615823F76055Ad60A00c"},"59140":{"name":"linea-testnet","mainnet":"false","v4":"0x897F8EDdB345F0d16081615823F76055Ad60A00c","Bv4":"0x7B36e10AA3ff44576efF4b1AfB80587B9b3BA3a5","v5":"0x690481Ce72b1080Bd928A35A0ECF329BE902cD6a"},"59144":{"name":"linea","mainnet":"true","v4":"0x8d1a17A3A4504aEB17515645BA8098f1D75237f7","Bv4":"0x7B36e10AA3ff44576efF4b1AfB80587B9b3BA3a5"},"80001":{"name":"polygon-mumbai","mainnet":"false","v3":"0x1da738d367dd369cf95f53a51b213a9cc9146afb","v4":"0xec8f9a7f47dd6031e27ff9cef9d0f33e81fcece9","Bv4":"0x1CcD80448cD0Eb21b2912c54B4E61dafD01Ab3C5","v5":"0x690481Ce72b1080Bd928A35A0ECF329BE902cD6a","v4.2":"0x8230697B79C2F1b0b64629F67cE30B2cAa354e3d","Rv4.2":"0xd7a425dc8D50bF8A8c69BfE8c892D9B2CFA2Dd22"},"84531":{"name":"base-goerli","mainnet":"false","v4":"0x897F8EDdB345F0d16081615823F76055Ad60A00c","Bv4":"0x1851359AB8B002217cf4D108d7F027B63563754C","v5":"0x690481Ce72b1080Bd928A35A0ECF329BE902cD6a"},"200101":{"name":"milkomeda-c1-testnet","mainnet":"false","v3":"0x7B36e10AA3ff44576efF4b1AfB80587B9b3BA3a5","v4":"0x897F8EDdB345F0d16081615823F76055Ad60A00c"},"11155111":{"name":"sepolia testnet","mainnet":"false","v4":"0x897F8EDdB345F0d16081615823F76055Ad60A00c","Bv4":"0x1851359AB8B002217cf4D108d7F027B63563754C","v5":"0x690481Ce72b1080Bd928A35A0ECF329BE902cD6a","v4.2":"0x220dFaac5348Eb2187F982A40845c7e93be4c672","Rv4.2":"0x9498304c22E40c4Dcc34c72414b19684c26f64eE"}}');
var peanut_contracts_namespaceObject = /*#__PURE__*/__webpack_require__.t(contracts_namespaceObject, 2);
;// CONCATENATED MODULE: ./src/libs/peanut/contracts.ts

const contracts = peanut_contracts_namespaceObject;

;// CONCATENATED MODULE: ./src/libs/peanut/index.ts



// EXTERNAL MODULE: ./node_modules/@hazae41/cursor/dist/esm/mods/cursor/cursor.mjs + 5 modules
var cursor_cursor = __webpack_require__(6677);
// EXTERNAL MODULE: ./node_modules/@hazae41/keccak256/dist/esm/src/mods/keccak256/adapter.mjs
var keccak256_adapter = __webpack_require__(561);
// EXTERNAL MODULE: ./node_modules/@hazae41/secp256k1/dist/esm/src/mods/secp256k1/adapter.mjs
var secp256k1_adapter = __webpack_require__(9347);
;// CONCATENATED MODULE: ./src/mods/foreground/entities/wallets/actions/send/peanut/contract.tsx

var contract_addDisposableResource = undefined && undefined.__addDisposableResource || function(env, value, async) {
    if (value !== null && value !== void 0) {
        if (typeof value !== "object" && typeof value !== "function") throw new TypeError("Object expected.");
        var dispose;
        if (async) {
            if (!Symbol.asyncDispose) throw new TypeError("Symbol.asyncDispose is not defined.");
            dispose = value[Symbol.asyncDispose];
        }
        if (dispose === void 0) {
            if (!Symbol.dispose) throw new TypeError("Symbol.dispose is not defined.");
            dispose = value[Symbol.dispose];
        }
        if (typeof dispose !== "function") throw new TypeError("Object not disposable.");
        env.stack.push({
            value: value,
            dispose: dispose,
            async: async
        });
    } else if (async) {
        env.stack.push({
            async: true
        });
    }
    return value;
};
var contract_disposeResources = undefined && undefined.__disposeResources || function(SuppressedError1) {
    return function(env) {
        function fail(e) {
            env.error = env.hasError ? new SuppressedError1(e, env.error, "An error was suppressed during disposal.") : e;
            env.hasError = true;
        }
        function next() {
            while(env.stack.length){
                var rec = env.stack.pop();
                try {
                    var result = rec.dispose && rec.dispose.call(rec.value);
                    if (rec.async) return Promise.resolve(result).then(next, function(e) {
                        fail(e);
                        return next();
                    });
                } catch (e) {
                    fail(e);
                }
            }
            if (env.hasError) throw env.error;
        }
        return next();
    };
}(typeof SuppressedError === "function" ? SuppressedError : function(error, suppressed, message) {
    var e = new Error(message);
    return e.name = "SuppressedError", e.error = error, e.suppressed = suppressed, e;
});




























function WalletPeanutSendScreenContractValue(props) {
    var _tokenQuery_current, _valuedBalanceQuery_current, _pricedBalanceQuery_current, _trial1Query_current, _transaction1Query_current, _trial0Query_current, _transaction0Query_current, _tokenData_pairs;
    const wallet = (0,wallets_context/* useWalletDataContext */.zI)().unwrap();
    const close = (0,dialog/* useCloseContext */.gX)().unwrap();
    const subpath = (0,path_context/* useSubpath */._u)();
    const $state = (0,path_context/* usePathState */.qf)();
    const [maybeStep, setStep] = (0,path_context/* useSearchState */.XN)("step", $state);
    const [maybeChain, setChain] = (0,path_context/* useSearchState */.XN)("chain", $state);
    const [maybeToken, setToken] = (0,path_context/* useSearchState */.XN)("token", $state);
    const [maybeValue, setValue] = (0,path_context/* useSearchState */.XN)("value", $state);
    const [maybePassword, setPassword] = (0,path_context/* useSearchState */.XN)("password", $state);
    const [maybeTrial0, setTrial0] = (0,path_context/* useSearchState */.XN)("trial0", $state);
    const [maybeTrial1, setTrial1] = (0,path_context/* useSearchState */.XN)("trial1", $state);
    const trial0UuidFallback = (0,ref/* useConstant */.hS)(()=>crypto.randomUUID());
    const trial0Uuid = option_option/* Option */.W.wrap(maybeTrial0).unwrapOr(trial0UuidFallback);
    (0,react.useEffect)(()=>{
        if (maybeTrial0 === trial0Uuid) return;
        setTrial0(trial0Uuid);
    }, [
        maybeTrial0,
        setTrial0,
        trial0Uuid
    ]);
    const trial1UuidFallback = (0,ref/* useConstant */.hS)(()=>crypto.randomUUID());
    const trial1Uuid = option_option/* Option */.W.wrap(maybeTrial1).unwrapOr(trial1UuidFallback);
    (0,react.useEffect)(()=>{
        if (maybeTrial1 === trial1Uuid) return;
        setTrial1(trial1Uuid);
    }, [
        maybeTrial1,
        setTrial1,
        trial1Uuid
    ]);
    const chain = option_option/* Option */.W.unwrap(maybeChain);
    const chainData = mods_chain/* chainByChainId */.DH[Number(chain)];
    const tokenQuery = useToken(chainData.chainId, maybeToken);
    const maybeTokenData = option_option/* Option */.W.wrap((_tokenQuery_current = tokenQuery.current) === null || _tokenQuery_current === void 0 ? void 0 : _tokenQuery_current.ok().get());
    const maybeTokenDef = option_option/* Option */.W.wrap(mods_chain/* tokenByAddress */.q2[maybeToken]);
    const tokenData = maybeTokenData.or(maybeTokenDef).unwrap();
    const context = (0,entities_wallets_data/* useEthereumContext2 */.IL)(wallet.uuid, chainData).unwrap();
    const [prices, setPrices] = (0,react.useState)(()=>{
        if (tokenData.pairs == null) return;
        return new Array(tokenData.pairs.length);
    });
    const onPrice = (0,react.useCallback)((param)=>{
        let [index, data] = param;
        setPrices((prices)=>{
            if (prices == null) return;
            prices[index] = data;
            return [
                ...prices
            ];
        });
    }, []);
    const maybePrice = (0,react.useMemo)(()=>{
        return prices === null || prices === void 0 ? void 0 : prices.reduce((a, b)=>{
            if (b == null) return a;
            return a.mul(types_fixed/* Fixed */.g.from(b));
        }, types_fixed/* Fixed */.g.unit(tokenData.decimals));
    }, [
        prices,
        tokenData
    ]);
    const [rawValuedInput = "", setRawValuedInput] = (0,react.useState)(maybeValue);
    const [rawPricedInput = "", setRawPricedInput] = (0,react.useState)();
    const valuedInput = (0,react.useDeferredValue)(rawValuedInput);
    const getRawPricedInput = (0,react.useCallback)((rawValuedInput)=>{
        try {
            if (rawValuedInput.trim().length === 0) return undefined;
            if (maybePrice == null) return undefined;
            const priced = types_fixed/* Fixed */.g.fromString(rawValuedInput, tokenData.decimals).mul(maybePrice);
            if (priced.value === 0n) return undefined;
            return priced.toString();
        } catch (e) {
            return undefined;
        }
    }, [
        maybePrice,
        tokenData
    ]);
    const getRawValuedInput = (0,react.useCallback)((rawPricedInput)=>{
        try {
            if (rawPricedInput.trim().length === 0) return undefined;
            if (maybePrice == null) return undefined;
            const valued = types_fixed/* Fixed */.g.fromString(rawPricedInput, tokenData.decimals).div(maybePrice);
            if (valued.value === 0n) return undefined;
            return valued.toString();
        } catch (e) {
            return undefined;
        }
    }, [
        maybePrice,
        tokenData
    ]);
    const onValuedChange = (0,react.useCallback)((input)=>{
        setRawPricedInput(getRawPricedInput(input));
    }, [
        getRawPricedInput
    ]);
    const onPricedChange = (0,react.useCallback)((input)=>{
        setRawValuedInput(getRawValuedInput(input));
    }, [
        getRawValuedInput
    ]);
    const setRawValued = (0,react.useCallback)((input)=>{
        setRawValuedInput(input);
        onValuedChange(input);
    }, [
        onValuedChange
    ]);
    const setRawPriced = (0,react.useCallback)((input)=>{
        setRawPricedInput(input);
        onPricedChange(input);
    }, [
        onPricedChange
    ]);
    const onValuedInputChange = (0,events/* useInputChange */.Xy)((e)=>{
        setRawValued(e.target.value);
    }, [
        setRawValued
    ]);
    const onPricedInputChange = (0,events/* useInputChange */.Xy)((e)=>{
        setRawPriced(e.target.value);
    }, [
        setRawPriced
    ]);
    (0,react.useEffect)(()=>{
        if (maybePrice == null) return;
        onValuedChange(valuedInput);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        maybePrice
    ]);
    (0,react.useEffect)(()=>{
        setValue(valuedInput);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        valuedInput
    ]);
    const [mode, setMode] = (0,react.useState)("valued");
    const valuedBalanceQuery = useNativeBalance(wallet.address, "pending", context, prices);
    const pricedBalanceQuery = useNativePricedBalance(wallet.address, "usd", context);
    const valuedBalanceData = (_valuedBalanceQuery_current = valuedBalanceQuery.current) === null || _valuedBalanceQuery_current === void 0 ? void 0 : _valuedBalanceQuery_current.ok().get();
    const pricedBalanceData = (_pricedBalanceQuery_current = pricedBalanceQuery.current) === null || _pricedBalanceQuery_current === void 0 ? void 0 : _pricedBalanceQuery_current.ok().get();
    const onValueMaxClick = (0,react.useCallback)(()=>{
        if (valuedBalanceData == null) return;
        setRawValued(types_fixed/* Fixed */.g.from(valuedBalanceData).toString());
    }, [
        valuedBalanceData,
        setRawValued
    ]);
    const onPricedMaxClick = (0,react.useCallback)(()=>{
        if (pricedBalanceData == null) return;
        setRawPriced(types_fixed/* Fixed */.g.from(pricedBalanceData).toString());
    }, [
        pricedBalanceData,
        setRawPriced
    ]);
    const onValuedPaste = (0,react.useCallback)(async ()=>{
        setRawValued(await navigator.clipboard.readText());
    }, [
        setRawValued
    ]);
    const onPricedPaste = (0,react.useCallback)(async ()=>{
        setRawPriced(await navigator.clipboard.readText());
    }, [
        setRawPriced
    ]);
    const onValuedClear = (0,react.useCallback)(async ()=>{
        setRawValued("");
    }, [
        setRawValued
    ]);
    const onPricedClear = (0,react.useCallback)(async ()=>{
        setRawPriced("");
    }, [
        setRawPriced
    ]);
    const onTargetFocus = (0,react.useCallback)(()=>{
        setStep("target");
    }, [
        setStep
    ]);
    const onPricedClick = (0,react.useCallback)(()=>{
        setMode("priced");
    }, []);
    const onValuedClick = (0,react.useCallback)(()=>{
        setMode("valued");
    }, []);
    const maybeContract = (0,react.useMemo)(()=>{
        var _Peanut_contracts_chainData_chainId;
        return (_Peanut_contracts_chainData_chainId = contracts[chainData.chainId]) === null || _Peanut_contracts_chainData_chainId === void 0 ? void 0 : _Peanut_contracts_chainData_chainId.v4;
    }, [
        chainData
    ]);
    const password = (0,react.useMemo)(()=>{
        if (maybePassword != null) return maybePassword;
        const byte = new Uint8Array(1);
        const bytes = new Uint8Array(32);
        const cursor = new cursor_cursor/* Cursor */.C(bytes);
        function isAlphanumeric(byte) {
            if (byte >= 97 /*a*/  && byte <= 122 /*z*/ ) return true;
            if (byte >= 65 /*A*/  && byte <= 90 /*Z*/ ) return true;
            if (byte >= 48 /*0*/  && byte <= 57 /*9*/ ) return true;
            return false;
        }
        while(cursor.remaining){
            if (!isAlphanumeric(crypto.getRandomValues(byte)[0])) continue;
            cursor.writeOrThrow(byte);
        }
        return bytes_bytes/* Bytes */.J.toUtf8(bytes);
    }, [
        maybePassword
    ]);
    (0,react.useEffect)(()=>{
        if (maybePassword === password) return;
        setPassword(password);
    }, [
        maybePassword,
        password,
        setPassword
    ]);
    const rawValue = (0,react.useMemo)(()=>{
        return (maybeValue === null || maybeValue === void 0 ? void 0 : maybeValue.trim().length) ? maybeValue.trim() : "0";
    }, [
        maybeValue
    ]);
    const maybeFinalValue = (0,react.useMemo)(()=>{
        try {
            return types_fixed/* Fixed */.g.fromString(rawValue, tokenData.decimals);
        } catch (e) {}
    }, [
        rawValue,
        tokenData
    ]);
    const maybeTriedMaybeFinalData1 = (0,react.useMemo)(()=>{
        if (maybeContract == null) return undefined;
        if (maybeFinalValue == null) return undefined;
        return result/* Result */.x.runAndDoubleWrapSync(()=>{
            const abi = TokenAbi.approve.from(maybeContract, maybeFinalValue.value);
            const hex = encode/* encodeOrThrow */.YM(abi);
            return hex;
        });
    }, [
        maybeContract,
        maybeFinalValue
    ]);
    const onSendTransaction1Click = (0,react.useCallback)(()=>{
        subpath.go((0,url/* qurl */.d)("/eth_sendTransaction", {
            trial: trial1Uuid,
            step: "value",
            chain: chainData.chainId,
            target: tokenData.address,
            data: maybeTriedMaybeFinalData1 === null || maybeTriedMaybeFinalData1 === void 0 ? void 0 : maybeTriedMaybeFinalData1.ok().get(),
            disableTarget: true,
            disableValue: true,
            disableData: true,
            disableSign: true
        }));
    }, [
        subpath,
        trial1Uuid,
        chainData,
        tokenData,
        maybeTriedMaybeFinalData1
    ]);
    const maybeTriedMaybeFinalData0 = (0,react.useMemo)(()=>{
        if (maybeFinalValue == null) return undefined;
        return result/* Result */.x.runAndDoubleWrapSync(()=>{
            const token = tokenData.address;
            const value = maybeFinalValue.value;
            const passwordBytes = bytes_bytes/* Bytes */.J.fromUtf8(password);
            const hashSlice = keccak256_adapter/* get */.U().hashOrThrow(passwordBytes);
            const privateKey = secp256k1_adapter/* get */.U().PrivateKey.tryImport(hashSlice).unwrap();
            const publicKey = privateKey.tryGetPublicKey().unwrap().tryExportUncompressed().unwrap().copyAndDispose();
            const address = types_address/* Address */.k.compute(publicKey);
            const abi = PeanutAbi.makeDeposit.from(token, 1, value, 0, address);
            const hex = encode/* encodeOrThrow */.YM(abi);
            return hex;
        });
    }, [
        maybeFinalValue,
        password,
        tokenData
    ]);
    const onSendTransaction0Click = (0,react.useCallback)(()=>{
        subpath.go((0,url/* qurl */.d)("/eth_sendTransaction", {
            trial: trial0Uuid,
            step: "value",
            chain: chainData.chainId,
            target: maybeContract,
            data: maybeTriedMaybeFinalData0 === null || maybeTriedMaybeFinalData0 === void 0 ? void 0 : maybeTriedMaybeFinalData0.ok().get(),
            disableTarget: true,
            disableValue: true,
            disableData: true,
            disableSign: true
        }));
    }, [
        subpath,
        trial0Uuid,
        chainData,
        maybeContract,
        maybeTriedMaybeFinalData0
    ]);
    const onClose = (0,react.useCallback)(()=>{
        subpath.go("/");
    }, [
        subpath
    ]);
    const trial1Query = useTransactionTrial(trial1Uuid);
    const maybeTrial1Data = (_trial1Query_current = trial1Query.current) === null || _trial1Query_current === void 0 ? void 0 : _trial1Query_current.ok().get();
    const transaction1Query = useTransactionWithReceipt(maybeTrial1Data === null || maybeTrial1Data === void 0 ? void 0 : maybeTrial1Data.transactions[0].uuid, context);
    const maybeTransaction1 = (_transaction1Query_current = transaction1Query.current) === null || _transaction1Query_current === void 0 ? void 0 : _transaction1Query_current.ok().get();
    const trial0Query = useTransactionTrial(trial0Uuid);
    const maybeTrial0Data = (_trial0Query_current = trial0Query.current) === null || _trial0Query_current === void 0 ? void 0 : _trial0Query_current.ok().get();
    const transaction0Query = useTransactionWithReceipt(maybeTrial0Data === null || maybeTrial0Data === void 0 ? void 0 : maybeTrial0Data.transactions[0].uuid, context);
    const maybeTransaction0 = (_transaction0Query_current = transaction0Query.current) === null || _transaction0Query_current === void 0 ? void 0 : _transaction0Query_current.ok().get();
    const maybeTriedLink = (0,react.useMemo)(()=>{
        if (maybeTransaction0 == null) return;
        if (maybeTransaction0.type !== "executed") return;
        return result/* Result */.x.runAndDoubleWrapSync(()=>{
            const env_1 = {
                stack: [],
                error: void 0,
                hasError: false
            };
            try {
                const signatureUtf8 = "DepositEvent(uint256,uint8,uint256,address)";
                const signatureBytes = bytes_bytes/* Bytes */.J.fromUtf8(signatureUtf8);
                const hashSlice = contract_addDisposableResource(env_1, keccak256_adapter/* get */.U().hashOrThrow(signatureBytes), false);
                const hashHex = "0x".concat(adapter/* get */.U().encodeOrThrow(hashSlice));
                const log = maybeTransaction0.receipt.logs.find((log)=>log.topics[0] === hashHex);
                if (log == null) throw new Error("Could not find log");
                const index = BigInt(log.topics[1]);
                return "https://peanut.to/claim?c=".concat(chainData.chainId, "&i=").concat(index, "&v=v4&t=ui#p=").concat(password);
            } catch (e_1) {
                env_1.error = e_1;
                env_1.hasError = true;
            } finally{
                contract_disposeResources(env_1);
            }
        });
    }, [
        maybeTransaction0,
        password,
        chainData.chainId
    ]);
    const onLinkCopy = (0,copy/* useCopy */.F)(maybeTriedLink === null || maybeTriedLink === void 0 ? void 0 : maybeTriedLink.ok().inner);
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(path_context/* PathContext */.FM.Provider, {
                value: subpath,
                children: subpath.url.pathname === "/eth_sendTransaction" && /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Screen */.lL, {
                    close: onClose,
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)(WalletTransactionScreen, {})
                })
            }),
            (_tokenData_pairs = tokenData.pairs) === null || _tokenData_pairs === void 0 ? void 0 : _tokenData_pairs.map((address, i)=>/*#__PURE__*/ (0,jsx_runtime.jsx)(PriceResolver, {
                    index: i,
                    address: address,
                    ok: onPrice
                }, i)),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(dialog/* Dialog */.Vq.Title, {
                close: close,
                children: [
                    "Send ",
                    tokenData.symbol,
                    " on ",
                    chainData.name
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-4"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(SimpleBox, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "",
                        children: "Target"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-4"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(SimpleInput, {
                        readOnly: true,
                        onFocus: onTargetFocus,
                        value: "Peanut"
                    }, "target")
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-2"
            }),
            mode === "valued" && /*#__PURE__*/ (0,jsx_runtime.jsxs)(SimpleBox, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "",
                        children: "Value"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-4"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "grow flex flex-col overflow-hidden",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "flex items-center",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)(SimpleInput, {
                                        autoFocus: true,
                                        value: rawValuedInput,
                                        onChange: onValuedInputChange,
                                        placeholder: "0.0"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "w-1"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "text-contrast",
                                        children: tokenData.symbol
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "flex items-center cursor-pointer",
                                role: "button",
                                onClick: onPricedClick,
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "text-contrast truncate",
                                        children: rawPricedInput || "0.0"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "grow"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "text-contrast",
                                        children: "USD"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-2"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "flex items-center",
                        children: [
                            rawValuedInput.length === 0 ? /*#__PURE__*/ (0,jsx_runtime.jsx)(ShrinkableNakedButtonInInputBox, {
                                onClick: onValuedPaste,
                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(ClipboardIcon/* default */.Z, {
                                    className: "size-4"
                                })
                            }) : /*#__PURE__*/ (0,jsx_runtime.jsx)(ShrinkableNakedButtonInInputBox, {
                                onClick: onValuedClear,
                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(XMarkIcon/* default */.Z, {
                                    className: "size-4"
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "w-1"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(ShrinkableContrastButtonInInputBox, {
                                disabled: valuedBalanceQuery.data == null,
                                onClick: onValueMaxClick,
                                children: "100%"
                            })
                        ]
                    })
                ]
            }),
            mode === "priced" && /*#__PURE__*/ (0,jsx_runtime.jsxs)(SimpleBox, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "",
                        children: "Value"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-4"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "grow flex flex-col overflow-hidden",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "flex items-center",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)(SimpleInput, {
                                        autoFocus: true,
                                        value: rawPricedInput,
                                        onChange: onPricedInputChange,
                                        placeholder: "0.0"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "w-1"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "text-contrast",
                                        children: "USD"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "flex items-center cursor-pointer",
                                role: "button",
                                onClick: onValuedClick,
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "text-contrast truncate",
                                        children: rawValuedInput || "0.0"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "grow"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "text-contrast",
                                        children: tokenData.symbol
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-2"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "flex items-center",
                        children: [
                            rawPricedInput.length === 0 ? /*#__PURE__*/ (0,jsx_runtime.jsx)(ShrinkableNakedButtonInInputBox, {
                                onClick: onPricedPaste,
                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(ClipboardIcon/* default */.Z, {
                                    className: "size-4"
                                })
                            }) : /*#__PURE__*/ (0,jsx_runtime.jsx)(ShrinkableNakedButtonInInputBox, {
                                onClick: onPricedClear,
                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(XMarkIcon/* default */.Z, {
                                    className: "size-4"
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "w-1"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(ShrinkableContrastButtonInInputBox, {
                                disabled: pricedBalanceQuery.data == null,
                                onClick: onPricedMaxClick,
                                children: "100%"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-4"
            }),
            maybeTransaction1 != null && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "font-medium",
                        children: "Approval"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-2"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(TransactionCard, {
                        data: maybeTransaction1,
                        onSend: ()=>{},
                        onRetry: ()=>{}
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-4"
                    })
                ]
            }),
            maybeTransaction0 != null && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "font-medium",
                        children: "Deposit"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-2"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(TransactionCard, {
                        data: maybeTransaction0,
                        onSend: ()=>{},
                        onRetry: ()=>{}
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-4"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-4 grow"
            }),
            (maybeTriedLink === null || maybeTriedLink === void 0 ? void 0 : maybeTriedLink.isOk()) && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "po-md flex items-center bg-contrast rounded-xl",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "flex flex-col truncate",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    className: "flex items-center",
                                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "font-medium",
                                        children: "Link created"
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    className: "text-contrast truncate",
                                    children: maybeTriedLink.get()
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    className: "h-2"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: "flex items-center gap-1",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                                            className: "group px-2 bg-contrast rounded-full outline-none disabled:opacity-50 transition-opacity",
                                            onClick: onLinkCopy.run,
                                            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                className: "h-full w-full flex items-center justify-center gap-2 group-active:scale-90 transition-transform",
                                                children: [
                                                    "Copy",
                                                    onLinkCopy.current ? /*#__PURE__*/ (0,jsx_runtime.jsx)(CheckIcon/* default */.Z, {
                                                        className: "size-4"
                                                    }) : /*#__PURE__*/ (0,jsx_runtime.jsx)(ClipboardIcon/* default */.Z, {
                                                        className: "size-4"
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("a", {
                                            className: "group px-2 bg-contrast rounded-full",
                                            target: "_blank",
                                            rel: "noreferrer",
                                            href: maybeTriedLink.get(),
                                            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                className: "h-full w-full flex items-center justify-center gap-2 group-active:scale-90 transition-transform",
                                                children: [
                                                    "Open",
                                                    /*#__PURE__*/ (0,jsx_runtime.jsx)(ArrowTopRightOnSquareIcon/* default */.Z, {
                                                        className: "size-4"
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-2"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "flex items-center",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)(WideShrinkableOppositeButton, {
                            onClick: close,
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)(CheckIcon/* default */.Z, {
                                    className: "size-5"
                                }),
                                "Close"
                            ]
                        })
                    })
                ]
            }),
            maybeTransaction1 == null && /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "flex items-center",
                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)(WideShrinkableOppositeButton, {
                    onClick: onSendTransaction1Click,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime.jsx)(PaperAirplaneIcon/* default */.Z, {
                            className: "size-5"
                        }),
                        "Transact (1/2)"
                    ]
                })
            }),
            (maybeTransaction1 === null || maybeTransaction1 === void 0 ? void 0 : maybeTransaction1.type) === "executed" && maybeTransaction0 == null && /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "flex items-center",
                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)(WideShrinkableOppositeButton, {
                    onClick: onSendTransaction0Click,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime.jsx)(PaperAirplaneIcon/* default */.Z, {
                            className: "size-5"
                        }),
                        "Transact (2/2)"
                    ]
                })
            })
        ]
    });
}

;// CONCATENATED MODULE: ./src/mods/foreground/entities/wallets/actions/send/peanut/native.tsx

var native_addDisposableResource = undefined && undefined.__addDisposableResource || function(env, value, async) {
    if (value !== null && value !== void 0) {
        if (typeof value !== "object" && typeof value !== "function") throw new TypeError("Object expected.");
        var dispose;
        if (async) {
            if (!Symbol.asyncDispose) throw new TypeError("Symbol.asyncDispose is not defined.");
            dispose = value[Symbol.asyncDispose];
        }
        if (dispose === void 0) {
            if (!Symbol.dispose) throw new TypeError("Symbol.dispose is not defined.");
            dispose = value[Symbol.dispose];
        }
        if (typeof dispose !== "function") throw new TypeError("Object not disposable.");
        env.stack.push({
            value: value,
            dispose: dispose,
            async: async
        });
    } else if (async) {
        env.stack.push({
            async: true
        });
    }
    return value;
};
var native_disposeResources = undefined && undefined.__disposeResources || function(SuppressedError1) {
    return function(env) {
        function fail(e) {
            env.error = env.hasError ? new SuppressedError1(e, env.error, "An error was suppressed during disposal.") : e;
            env.hasError = true;
        }
        function next() {
            while(env.stack.length){
                var rec = env.stack.pop();
                try {
                    var result = rec.dispose && rec.dispose.call(rec.value);
                    if (rec.async) return Promise.resolve(result).then(next, function(e) {
                        fail(e);
                        return next();
                    });
                } catch (e) {
                    fail(e);
                }
            }
            if (env.hasError) throw env.error;
        }
        return next();
    };
}(typeof SuppressedError === "function" ? SuppressedError : function(error, suppressed, message) {
    var e = new Error(message);
    return e.name = "SuppressedError", e.error = error, e.suppressed = suppressed, e;
});



























function WalletPeanutSendScreenNativeValue(props) {
    var _valuedBalanceQuery_current, _pricedBalanceQuery_current, _trial0Query_current, _transaction0Query_current, _tokenData_pairs;
    const wallet = (0,wallets_context/* useWalletDataContext */.zI)().unwrap();
    const close = (0,dialog/* useCloseContext */.gX)().unwrap();
    const subpath = (0,path_context/* useSubpath */._u)();
    const $state = (0,path_context/* usePathState */.qf)();
    const [maybeStep, setStep] = (0,path_context/* useSearchState */.XN)("step", $state);
    const [maybeChain, setChain] = (0,path_context/* useSearchState */.XN)("chain", $state);
    const [maybeValue, setValue] = (0,path_context/* useSearchState */.XN)("value", $state);
    const [maybePassword, setPassword] = (0,path_context/* useSearchState */.XN)("password", $state);
    const [maybeTrial0, setTrial0] = (0,path_context/* useSearchState */.XN)("trial0", $state);
    const trial0UuidFallback = (0,ref/* useConstant */.hS)(()=>crypto.randomUUID());
    const trial0Uuid = option_option/* Option */.W.wrap(maybeTrial0).unwrapOr(trial0UuidFallback);
    (0,react.useEffect)(()=>{
        if (maybeTrial0 === trial0Uuid) return;
        setTrial0(trial0Uuid);
    }, [
        maybeTrial0,
        setTrial0,
        trial0Uuid
    ]);
    const chain = option_option/* Option */.W.unwrap(maybeChain);
    const chainData = mods_chain/* chainByChainId */.DH[Number(chain)];
    const tokenData = chainData.token;
    const context = (0,entities_wallets_data/* useEthereumContext2 */.IL)(wallet.uuid, chainData).unwrap();
    const [prices, setPrices] = (0,react.useState)(()=>{
        if (tokenData.pairs == null) return;
        return new Array(tokenData.pairs.length);
    });
    const onPrice = (0,react.useCallback)((param)=>{
        let [index, data] = param;
        setPrices((prices)=>{
            if (prices == null) return;
            prices[index] = data;
            return [
                ...prices
            ];
        });
    }, []);
    const maybePrice = (0,react.useMemo)(()=>{
        return prices === null || prices === void 0 ? void 0 : prices.reduce((a, b)=>{
            if (b == null) return a;
            return a.mul(types_fixed/* Fixed */.g.from(b));
        }, types_fixed/* Fixed */.g.unit(tokenData.decimals));
    }, [
        prices,
        tokenData
    ]);
    const [rawValuedInput = "", setRawValuedInput] = (0,react.useState)(maybeValue);
    const [rawPricedInput = "", setRawPricedInput] = (0,react.useState)();
    const valuedInput = (0,react.useDeferredValue)(rawValuedInput);
    const getRawPricedInput = (0,react.useCallback)((rawValuedInput)=>{
        try {
            if (rawValuedInput.trim().length === 0) return undefined;
            if (maybePrice == null) return undefined;
            const priced = types_fixed/* Fixed */.g.fromString(rawValuedInput, tokenData.decimals).mul(maybePrice);
            if (priced.value === 0n) return undefined;
            return priced.toString();
        } catch (e) {
            return undefined;
        }
    }, [
        maybePrice,
        tokenData
    ]);
    const getRawValuedInput = (0,react.useCallback)((rawPricedInput)=>{
        try {
            if (rawPricedInput.trim().length === 0) return undefined;
            if (maybePrice == null) return undefined;
            const valued = types_fixed/* Fixed */.g.fromString(rawPricedInput, tokenData.decimals).div(maybePrice);
            if (valued.value === 0n) return undefined;
            return valued.toString();
        } catch (e) {
            return undefined;
        }
    }, [
        maybePrice,
        tokenData
    ]);
    const onValuedChange = (0,react.useCallback)((input)=>{
        setRawPricedInput(getRawPricedInput(input));
    }, [
        getRawPricedInput
    ]);
    const onPricedChange = (0,react.useCallback)((input)=>{
        setRawValuedInput(getRawValuedInput(input));
    }, [
        getRawValuedInput
    ]);
    const setRawValued = (0,react.useCallback)((input)=>{
        setRawValuedInput(input);
        onValuedChange(input);
    }, [
        onValuedChange
    ]);
    const setRawPriced = (0,react.useCallback)((input)=>{
        setRawPricedInput(input);
        onPricedChange(input);
    }, [
        onPricedChange
    ]);
    const onValuedInputChange = (0,events/* useInputChange */.Xy)((e)=>{
        setRawValued(e.target.value);
    }, [
        setRawValued
    ]);
    const onPricedInputChange = (0,events/* useInputChange */.Xy)((e)=>{
        setRawPriced(e.target.value);
    }, [
        setRawPriced
    ]);
    (0,react.useEffect)(()=>{
        if (maybePrice == null) return;
        onValuedChange(valuedInput);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        maybePrice
    ]);
    (0,react.useEffect)(()=>{
        setValue(valuedInput);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        valuedInput
    ]);
    const [mode, setMode] = (0,react.useState)("valued");
    const valuedBalanceQuery = useNativeBalance(wallet.address, "pending", context, prices);
    const pricedBalanceQuery = useNativePricedBalance(wallet.address, "usd", context);
    const valuedBalanceData = (_valuedBalanceQuery_current = valuedBalanceQuery.current) === null || _valuedBalanceQuery_current === void 0 ? void 0 : _valuedBalanceQuery_current.ok().get();
    const pricedBalanceData = (_pricedBalanceQuery_current = pricedBalanceQuery.current) === null || _pricedBalanceQuery_current === void 0 ? void 0 : _pricedBalanceQuery_current.ok().get();
    const onValueMaxClick = (0,react.useCallback)(()=>{
        if (valuedBalanceData == null) return;
        setRawValued(types_fixed/* Fixed */.g.from(valuedBalanceData).toString());
    }, [
        valuedBalanceData,
        setRawValued
    ]);
    const onPricedMaxClick = (0,react.useCallback)(()=>{
        if (pricedBalanceData == null) return;
        setRawPriced(types_fixed/* Fixed */.g.from(pricedBalanceData).toString());
    }, [
        pricedBalanceData,
        setRawPriced
    ]);
    const onValuedPaste = (0,react.useCallback)(async ()=>{
        setRawValued(await navigator.clipboard.readText());
    }, [
        setRawValued
    ]);
    const onPricedPaste = (0,react.useCallback)(async ()=>{
        setRawPriced(await navigator.clipboard.readText());
    }, [
        setRawPriced
    ]);
    const onValuedClear = (0,react.useCallback)(async ()=>{
        setRawValued("");
    }, [
        setRawValued
    ]);
    const onPricedClear = (0,react.useCallback)(async ()=>{
        setRawPriced("");
    }, [
        setRawPriced
    ]);
    const onTargetFocus = (0,react.useCallback)(()=>{
        setStep("target");
    }, [
        setStep
    ]);
    const onPricedClick = (0,react.useCallback)(()=>{
        setMode("priced");
    }, []);
    const onValuedClick = (0,react.useCallback)(()=>{
        setMode("valued");
    }, []);
    const maybeContract = (0,react.useMemo)(()=>{
        var _Peanut_contracts_chainData_chainId;
        return (_Peanut_contracts_chainData_chainId = contracts[chainData.chainId]) === null || _Peanut_contracts_chainData_chainId === void 0 ? void 0 : _Peanut_contracts_chainData_chainId.v4;
    }, [
        chainData
    ]);
    const password = (0,react.useMemo)(()=>{
        if (maybePassword != null) return maybePassword;
        const byte = new Uint8Array(1);
        const bytes = new Uint8Array(32);
        const cursor = new cursor_cursor/* Cursor */.C(bytes);
        function isAlphanumeric(byte) {
            if (byte >= 97 /*a*/  && byte <= 122 /*z*/ ) return true;
            if (byte >= 65 /*A*/  && byte <= 90 /*Z*/ ) return true;
            if (byte >= 48 /*0*/  && byte <= 57 /*9*/ ) return true;
            return false;
        }
        while(cursor.remaining){
            if (!isAlphanumeric(crypto.getRandomValues(byte)[0])) continue;
            cursor.writeOrThrow(byte);
        }
        return bytes_bytes/* Bytes */.J.toUtf8(bytes);
    }, [
        maybePassword
    ]);
    (0,react.useEffect)(()=>{
        if (maybePassword === password) return;
        setPassword(password);
    }, [
        maybePassword,
        password,
        setPassword
    ]);
    const rawValue = (0,react.useMemo)(()=>{
        return (maybeValue === null || maybeValue === void 0 ? void 0 : maybeValue.trim().length) ? maybeValue.trim() : "0";
    }, [
        maybeValue
    ]);
    const maybeFinalValue = (0,react.useMemo)(()=>{
        try {
            return types_fixed/* Fixed */.g.fromString(rawValue, tokenData.decimals);
        } catch (e) {}
    }, [
        rawValue,
        tokenData
    ]);
    const maybeTriedMaybeFinalData = (0,react.useMemo)(()=>{
        if (maybeFinalValue == null) return undefined;
        return result/* Result */.x.runAndDoubleWrapSync(()=>{
            const token = "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee";
            const value = maybeFinalValue.value;
            const passwordBytes = bytes_bytes/* Bytes */.J.fromUtf8(password);
            const hashSlice = keccak256_adapter/* get */.U().hashOrThrow(passwordBytes);
            const privateKey = secp256k1_adapter/* get */.U().PrivateKey.tryImport(hashSlice).unwrap();
            const publicKey = privateKey.tryGetPublicKey().unwrap().tryExportUncompressed().unwrap().copyAndDispose();
            const address = types_address/* Address */.k.compute(publicKey);
            const abi = PeanutAbi.makeDeposit.from(token, 0, value, 0, address);
            const hex = encode/* encodeOrThrow */.YM(abi);
            return hex;
        });
    }, [
        maybeFinalValue,
        password
    ]);
    const onSendTransactionClick = (0,react.useCallback)(()=>{
        subpath.go((0,url/* qurl */.d)("/eth_sendTransaction", {
            trial: trial0Uuid,
            step: "value",
            chain: chainData.chainId,
            target: maybeContract,
            value: rawValue,
            data: maybeTriedMaybeFinalData === null || maybeTriedMaybeFinalData === void 0 ? void 0 : maybeTriedMaybeFinalData.ok().get(),
            disableTarget: true,
            disableValue: true,
            disableData: true,
            disableSign: true
        }));
    }, [
        subpath,
        trial0Uuid,
        chainData,
        maybeContract,
        rawValue,
        maybeTriedMaybeFinalData
    ]);
    const onClose = (0,react.useCallback)(()=>{
        subpath.go("/");
    }, [
        subpath
    ]);
    const trial0Query = useTransactionTrial(trial0Uuid);
    const maybeTrial0Data = (_trial0Query_current = trial0Query.current) === null || _trial0Query_current === void 0 ? void 0 : _trial0Query_current.ok().get();
    const transaction0Query = useTransactionWithReceipt(maybeTrial0Data === null || maybeTrial0Data === void 0 ? void 0 : maybeTrial0Data.transactions[0].uuid, context);
    const maybeTransaction0 = (_transaction0Query_current = transaction0Query.current) === null || _transaction0Query_current === void 0 ? void 0 : _transaction0Query_current.ok().get();
    const maybeTriedLink = (0,react.useMemo)(()=>{
        if (maybeTransaction0 == null) return;
        if (maybeTransaction0.type !== "executed") return;
        return result/* Result */.x.runAndDoubleWrapSync(()=>{
            const env_1 = {
                stack: [],
                error: void 0,
                hasError: false
            };
            try {
                const signatureUtf8 = "DepositEvent(uint256,uint8,uint256,address)";
                const signatureBytes = bytes_bytes/* Bytes */.J.fromUtf8(signatureUtf8);
                const hashSlice = native_addDisposableResource(env_1, keccak256_adapter/* get */.U().hashOrThrow(signatureBytes), false);
                const hashHex = "0x".concat(adapter/* get */.U().encodeOrThrow(hashSlice));
                const log = maybeTransaction0.receipt.logs.find((log)=>log.topics[0] === hashHex);
                if (log == null) throw new Error("Could not find log");
                const index = BigInt(log.topics[1]);
                return "https://peanut.to/claim?c=".concat(chainData.chainId, "&i=").concat(index, "&v=v4&t=ui#p=").concat(password);
            } catch (e_1) {
                env_1.error = e_1;
                env_1.hasError = true;
            } finally{
                native_disposeResources(env_1);
            }
        });
    }, [
        maybeTransaction0,
        password,
        chainData.chainId
    ]);
    const onLinkCopy = (0,copy/* useCopy */.F)(maybeTriedLink === null || maybeTriedLink === void 0 ? void 0 : maybeTriedLink.ok().inner);
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(path_context/* PathContext */.FM.Provider, {
                value: subpath,
                children: subpath.url.pathname === "/eth_sendTransaction" && /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Screen */.lL, {
                    close: onClose,
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)(WalletTransactionScreen, {})
                })
            }),
            (_tokenData_pairs = tokenData.pairs) === null || _tokenData_pairs === void 0 ? void 0 : _tokenData_pairs.map((address, i)=>/*#__PURE__*/ (0,jsx_runtime.jsx)(PriceResolver, {
                    index: i,
                    address: address,
                    ok: onPrice
                }, i)),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(dialog/* Dialog */.Vq.Title, {
                close: close,
                children: [
                    "Send ",
                    tokenData.symbol,
                    " on ",
                    chainData.name
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-4"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(SimpleBox, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "",
                        children: "Target"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-4"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(SimpleInput, {
                        readOnly: true,
                        onFocus: onTargetFocus,
                        value: "Peanut"
                    }, "target")
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-2"
            }),
            mode === "valued" && /*#__PURE__*/ (0,jsx_runtime.jsxs)(SimpleBox, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "",
                        children: "Value"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-4"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "grow flex flex-col overflow-hidden",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "flex items-center",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)(SimpleInput, {
                                        autoFocus: true,
                                        value: rawValuedInput,
                                        onChange: onValuedInputChange,
                                        placeholder: "0.0"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "w-1"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "text-contrast",
                                        children: tokenData.symbol
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "flex items-center cursor-pointer",
                                role: "button",
                                onClick: onPricedClick,
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "text-contrast truncate",
                                        children: rawPricedInput || "0.0"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "grow"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "text-contrast",
                                        children: "USD"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-2"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "flex items-center",
                        children: [
                            rawValuedInput.length === 0 ? /*#__PURE__*/ (0,jsx_runtime.jsx)(ShrinkableNakedButtonInInputBox, {
                                onClick: onValuedPaste,
                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(ClipboardIcon/* default */.Z, {
                                    className: "size-4"
                                })
                            }) : /*#__PURE__*/ (0,jsx_runtime.jsx)(ShrinkableNakedButtonInInputBox, {
                                onClick: onValuedClear,
                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(XMarkIcon/* default */.Z, {
                                    className: "size-4"
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "w-1"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(ShrinkableContrastButtonInInputBox, {
                                disabled: valuedBalanceQuery.data == null,
                                onClick: onValueMaxClick,
                                children: "100%"
                            })
                        ]
                    })
                ]
            }),
            mode === "priced" && /*#__PURE__*/ (0,jsx_runtime.jsxs)(SimpleBox, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "",
                        children: "Value"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-4"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "grow flex flex-col overflow-hidden",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "flex items-center",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)(SimpleInput, {
                                        autoFocus: true,
                                        value: rawPricedInput,
                                        onChange: onPricedInputChange,
                                        placeholder: "0.0"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "w-1"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "text-contrast",
                                        children: "USD"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "flex items-center cursor-pointer",
                                role: "button",
                                onClick: onValuedClick,
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "text-contrast truncate",
                                        children: rawValuedInput || "0.0"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "grow"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "text-contrast",
                                        children: tokenData.symbol
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-2"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "flex items-center",
                        children: [
                            rawPricedInput.length === 0 ? /*#__PURE__*/ (0,jsx_runtime.jsx)(ShrinkableNakedButtonInInputBox, {
                                onClick: onPricedPaste,
                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(ClipboardIcon/* default */.Z, {
                                    className: "size-4"
                                })
                            }) : /*#__PURE__*/ (0,jsx_runtime.jsx)(ShrinkableNakedButtonInInputBox, {
                                onClick: onPricedClear,
                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(XMarkIcon/* default */.Z, {
                                    className: "size-4"
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "w-1"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(ShrinkableContrastButtonInInputBox, {
                                disabled: pricedBalanceQuery.data == null,
                                onClick: onPricedMaxClick,
                                children: "100%"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-4"
            }),
            maybeTransaction0 != null && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "font-medium",
                        children: "Deposit"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-2"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(TransactionCard, {
                        data: maybeTransaction0,
                        onSend: ()=>{},
                        onRetry: ()=>{}
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-4"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-4 grow"
            }),
            (maybeTriedLink === null || maybeTriedLink === void 0 ? void 0 : maybeTriedLink.isOk()) && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "po-md flex items-center bg-contrast rounded-xl",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "flex flex-col truncate",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    className: "flex items-center",
                                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "font-medium",
                                        children: "Link created"
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    className: "text-contrast truncate",
                                    children: maybeTriedLink.get()
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    className: "h-2"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: "flex items-center gap-1",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                                            className: "group px-2 bg-contrast rounded-full outline-none disabled:opacity-50 transition-opacity",
                                            onClick: onLinkCopy.run,
                                            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                className: "h-full w-full flex items-center justify-center gap-2 group-active:scale-90 transition-transform",
                                                children: [
                                                    "Copy",
                                                    onLinkCopy.current ? /*#__PURE__*/ (0,jsx_runtime.jsx)(CheckIcon/* default */.Z, {
                                                        className: "size-4"
                                                    }) : /*#__PURE__*/ (0,jsx_runtime.jsx)(ClipboardIcon/* default */.Z, {
                                                        className: "size-4"
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("a", {
                                            className: "group px-2 bg-contrast rounded-full",
                                            target: "_blank",
                                            rel: "noreferrer",
                                            href: maybeTriedLink.get(),
                                            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                className: "h-full w-full flex items-center justify-center gap-2 group-active:scale-90 transition-transform",
                                                children: [
                                                    "Open",
                                                    /*#__PURE__*/ (0,jsx_runtime.jsx)(ArrowTopRightOnSquareIcon/* default */.Z, {
                                                        className: "size-4"
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-2"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "flex items-center",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)(WideShrinkableOppositeButton, {
                            onClick: close,
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)(CheckIcon/* default */.Z, {
                                    className: "size-5"
                                }),
                                "Close"
                            ]
                        })
                    })
                ]
            }),
            maybeTransaction0 == null && /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "flex items-center",
                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)(WideShrinkableOppositeButton, {
                    onClick: onSendTransactionClick,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime.jsx)(PaperAirplaneIcon/* default */.Z, {
                            className: "size-5"
                        }),
                        "Transact"
                    ]
                })
            })
        ]
    });
}

;// CONCATENATED MODULE: ./src/mods/foreground/entities/wallets/actions/send/target.tsx
/* eslint-disable @next/next/no-img-element */ 














function WalletSendScreenTarget(props) {
    var _tokenQuery_current, _ensQuery_current;
    const wallet = (0,wallets_context/* useWalletDataContext */.zI)().unwrap();
    const close = (0,dialog/* useCloseContext */.gX)().unwrap();
    const $state = (0,path_context/* usePathState */.qf)();
    const [maybeStep, setStep] = (0,path_context/* useSearchState */.XN)("step", $state);
    const [maybeChain, setChain] = (0,path_context/* useSearchState */.XN)("chain", $state);
    const [maybeTarget, setTarget] = (0,path_context/* useSearchState */.XN)("target", $state);
    const [maybeType, setType] = (0,path_context/* useSearchState */.XN)("type", $state);
    const [maybeToken, setToken] = (0,path_context/* useSearchState */.XN)("token", $state);
    const chain = option_option/* Option */.W.unwrap(maybeChain);
    const chainData = mods_chain/* chainByChainId */.DH[Number(chain)];
    const tokenQuery = useToken(chainData.chainId, maybeToken);
    const maybeTokenData = option_option/* Option */.W.wrap((_tokenQuery_current = tokenQuery.current) === null || _tokenQuery_current === void 0 ? void 0 : _tokenQuery_current.ok().get());
    const maybeTokenDef = option_option/* Option */.W.wrap(mods_chain/* tokenByAddress */.q2[maybeToken]);
    const tokenData = maybeTokenData.or(maybeTokenDef).unwrapOr(chainData.token);
    const mainnet = (0,entities_wallets_data/* useEthereumContext */.Kn)(wallet.uuid, mods_chain/* chainByChainId */.DH[1]);
    const [rawTargetInput = "", setRawTargetInput] = (0,react.useState)(maybeTarget);
    const onTargetInputChange = (0,events/* useInputChange */.Xy)((e)=>{
        setRawTargetInput(e.target.value);
    }, []);
    const targetInput = (0,react.useDeferredValue)(rawTargetInput);
    useEffectButNotFirstTime(()=>{
        setType(undefined);
        setTarget(targetInput);
    }, [
        targetInput
    ]);
    const maybeEnsInput = (maybeTarget === null || maybeTarget === void 0 ? void 0 : maybeTarget.endsWith(".eth")) ? targetInput : undefined;
    const ensQuery = (0,names_data/* useEnsLookup */.aZ)(maybeEnsInput, mainnet);
    const maybeEns = (_ensQuery_current = ensQuery.current) === null || _ensQuery_current === void 0 ? void 0 : _ensQuery_current.ok().get();
    const onSubmit = (0,react.useCallback)(async ()=>{
        if (maybeTarget == null) return;
        if (types_address/* Address */.k.from(maybeTarget) == null && !maybeTarget.endsWith(".eth")) return;
        setStep("value");
    }, [
        maybeTarget,
        setStep
    ]);
    const onEnter = (0,events/* useKeyboardEnter */.Fj)(()=>{
        onSubmit();
    }, [
        onSubmit
    ]);
    const onClear = (0,react.useCallback)((e)=>{
        setRawTargetInput("");
    }, []);
    const onPaste = (0,react.useCallback)(async ()=>{
        const input = await navigator.clipboard.readText();
        if (types_address/* Address */.k.from(input) == null && !input.endsWith(".eth")) return;
        setType(undefined);
        setTarget(input);
        setStep("value");
    }, [
        setType,
        setStep,
        setTarget
    ]);
    const [mode, setMode] = (0,react.useState)("recents");
    const onRecentsClick = (0,react.useCallback)(()=>{
        setMode("recents");
    }, []);
    const onContactsClick = (0,react.useCallback)(()=>{
        setMode("contacts");
    }, []);
    const onPeanutClick = (0,react.useCallback)(()=>{
        setType("peanut");
        setTarget(undefined);
        setStep("value");
    }, [
        setType,
        setStep,
        setTarget
    ]);
    const onBrumeClick = (0,react.useCallback)(()=>{
        setType(undefined);
        setTarget("brume.eth");
        setStep("value");
    }, [
        setType,
        setStep,
        setTarget
    ]);
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(dialog/* Dialog */.Vq.Title, {
                close: close,
                children: [
                    "Send ",
                    tokenData.symbol,
                    " on ",
                    chainData.name
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-4"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(SimpleBox, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "",
                        children: "Target"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-4"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(SimpleInput, {
                        autoFocus: true,
                        value: rawTargetInput,
                        onChange: onTargetInputChange,
                        onKeyDown: onEnter,
                        placeholder: "brume.eth"
                    }, "target"),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-1"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "flex items-center",
                        children: [
                            rawTargetInput.length === 0 ? /*#__PURE__*/ (0,jsx_runtime.jsx)(ShrinkableNakedButtonInInputBox, {
                                onClick: onPaste,
                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(ClipboardIcon/* default */.Z, {
                                    className: "size-4"
                                })
                            }) : /*#__PURE__*/ (0,jsx_runtime.jsx)(ShrinkableNakedButtonInInputBox, {
                                onClick: onClear,
                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(XMarkIcon/* default */.Z, {
                                    className: "size-4"
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "w-1"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(ShrinkableContrastButtonInInputBox, {
                                onClick: onSubmit,
                                children: "OK"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-2"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "flex items-center",
                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)(WideShrinkableContrastButton, {
                    onClick: onPeanutClick,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime.jsx)(LinkIcon/* default */.Z, {
                            className: "size-4"
                        }),
                        "Create Peanut link (beta)"
                    ]
                })
            }),
            maybeEns != null && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-2"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "po-md flex items-center bg-contrast rounded-xl cursor-pointer",
                        role: "button",
                        onClick: onSubmit,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "size-12 shrink-0 rounded-full bg-contrast"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "w-4"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "flex flex-col truncate",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "font-medium",
                                        children: targetInput
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "text-contrast truncate",
                                        children: maybeEns
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-4"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "flex items-center",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                        className: "text-lg font-medium text-contrast data-[active=true]:text-default",
                        onClick: onRecentsClick,
                        "data-active": mode === "recents",
                        children: "Recents"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "grow"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                        className: "text-contrast font-medium text-contrast data-[active=true]:text-default",
                        onClick: onContactsClick,
                        "data-active": mode === "contacts",
                        children: "Contacts"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-2"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "po-md flex items-center bg-contrast rounded-xl cursor-pointer",
                role: "button",
                onClick: onBrumeClick,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("img", {
                        className: "size-12 shrink-0 rounded-full bg-contrast",
                        src: "/square.png",
                        alt: "logo"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-4"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "flex flex-col truncate",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "font-medium",
                                children: "Brume Wallet"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "text-contrast truncate",
                                children: "brume.eth"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "grow flex flex-col items-center justify-center",
                children: "Coming soon..."
            })
        ]
    });
}

;// CONCATENATED MODULE: ./src/mods/foreground/entities/wallets/actions/send/index.tsx







function WalletSendScreen(props) {
    const $path = (0,path_context/* usePathState */.qf)();
    const [step] = (0,path_context/* useSearchState */.XN)("step", $path);
    const [type] = (0,path_context/* useSearchState */.XN)("type", $path);
    const [token] = (0,path_context/* useSearchState */.XN)("token", $path);
    if (step === "target") return /*#__PURE__*/ (0,jsx_runtime.jsx)(WalletSendScreenTarget, {});
    if (step === "value" && token == null && type == null) return /*#__PURE__*/ (0,jsx_runtime.jsx)(WalletDirectSendScreenNativeValue, {});
    if (step === "value" && token == null && type == "peanut") return /*#__PURE__*/ (0,jsx_runtime.jsx)(WalletPeanutSendScreenNativeValue, {});
    if (step === "value" && token != null && type == null) return /*#__PURE__*/ (0,jsx_runtime.jsx)(WalletDirectSendScreenContractValue, {});
    if (step === "value" && token != null && type == "peanut") return /*#__PURE__*/ (0,jsx_runtime.jsx)(WalletPeanutSendScreenContractValue, {});
    return null;
}
function SimpleBox(props) {
    const { children } = props;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
        className: "po-md flex items-start bg-contrast rounded-xl",
        children: children
    });
}
function SimpleInput(props) {
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("input", {
        className: "grow bg-transparent outline-none min-w-0 disabled:text-contrast",
        ...props
    });
}
function SimpleTextarea(props) {
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("textarea", {
        className: "grow bg-transparent outline-none min-w-0 disabled:text-contrast",
        ...props
    });
}
function ShrinkableNakedButtonInInputBox(props) {
    const { children, ...rest } = props;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
        className: "group rounded-full outline-none disabled:opacity-50 transition-opacity",
        ...rest,
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
            className: "h-full w-full flex items-center justify-center gap-2 group-enabled:group-active:scale-90 transition-transform",
            children: children
        })
    });
}
function ShrinkableContrastButtonInInputBox(props) {
    const { children, ...rest } = props;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
        className: "group px-2 bg-contrast rounded-full outline-none disabled:opacity-50 transition-opacity",
        ...rest,
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
            className: "h-full w-full flex items-center justify-center gap-2 group-enabled:group-active:scale-90 transition-transform",
            children: children
        })
    });
}
function ShrinkableContrastButtonInTextareaBox(props) {
    const { children, ...rest } = props;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
        className: "group po-sm bg-contrast rounded-xl outline-none disabled:opacity-50 transition-opacity",
        ...rest,
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
            className: "h-full w-full flex items-center justify-center gap-2 group-enabled:group-active:scale-90 transition-transform",
            children: children
        })
    });
}
function WideShrinkableOppositeButton(props) {
    const { children, ...rest } = props;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
        className: "grow group po-md bg-opposite text-opposite rounded-xl outline-none disabled:opacity-50 transition-opacity",
        ...rest,
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
            className: "h-full w-full flex items-center justify-center gap-2 group-enabled:group-active:scale-90 transition-transform",
            children: children
        })
    });
}
function WideShrinkableContrastButton(props) {
    const { children, ...rest } = props;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
        className: "grow group po-md bg-contrast rounded-xl outline-none disabled:opacity-50 transition-opacity",
        ...rest,
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
            className: "h-full w-full flex items-center justify-center gap-2 group-enabled:group-active:scale-90 transition-transform",
            children: children
        })
    });
}

// EXTERNAL MODULE: ./src/mods/foreground/entities/wallets/card.tsx
var card = __webpack_require__(9475);
;// CONCATENATED MODULE: ./src/mods/background/service_worker/entities/wallets/tokens/data.ts



var TokenSettingsRef;
(function(TokenSettingsRef) {
    function from(settings) {
        const { uuid, wallet, token } = settings;
        return {
            ref: true,
            uuid,
            wallet,
            token
        };
    }
    TokenSettingsRef.from = from;
})(TokenSettingsRef || (TokenSettingsRef = {}));
var BgTokenSettings;
(function(BgTokenSettings) {
    let ByWallet;
    (function(ByWallet) {
        function key(wallet) {
            return "tokenSettingsByWallet/".concat(wallet.uuid);
        }
        ByWallet.key = key;
        function schema(wallet, storage) {
            if (wallet == null) return;
            return (0,query/* createQuery */.rP)({
                key: key(wallet),
                storage
            });
        }
        ByWallet.schema = schema;
    })(ByWallet = BgTokenSettings.ByWallet || (BgTokenSettings.ByWallet = {}));
    function key(wallet, token) {
        if (token.type === "native") return "tokenSettings/".concat(wallet.uuid, "/").concat(token.chainId, "/native");
        if (token.type === "contract") return "tokenSettings/".concat(wallet.uuid, "/").concat(token.chainId, "/").concat(token.address);
        throw new result_errors/* Panic */.F5();
    }
    BgTokenSettings.key = key;
    function schema(wallet, token, storage) {
        if (wallet == null) return;
        if (token == null) return;
        const indexer = async (states)=>{
            var _previous_real_data, _previous_real, _current_real_data, _current_real;
            const { current, previous } = states;
            const previousData = previous === null || previous === void 0 ? void 0 : (_previous_real = previous.real) === null || _previous_real === void 0 ? void 0 : (_previous_real_data = _previous_real.data) === null || _previous_real_data === void 0 ? void 0 : _previous_real_data.get();
            const currentData = (_current_real = current.real) === null || _current_real === void 0 ? void 0 : (_current_real_data = _current_real.data) === null || _current_real_data === void 0 ? void 0 : _current_real_data.get();
            if ((previousData === null || previousData === void 0 ? void 0 : previousData.uuid) === (currentData === null || currentData === void 0 ? void 0 : currentData.uuid)) return;
            if (previousData != null) {
                var _ByWallet_schema;
                await ((_ByWallet_schema = ByWallet.schema(previousData.wallet, storage)) === null || _ByWallet_schema === void 0 ? void 0 : _ByWallet_schema.mutate(mutators/* Mutators */.g.mapData(function() {
                    let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : new fetched_data/* Data */.V([]);
                    return d.mapSync((p)=>p.filter((x)=>x.uuid !== previousData.uuid));
                })));
            }
            if (currentData != null) {
                var _ByWallet_schema1;
                await ((_ByWallet_schema1 = ByWallet.schema(currentData.wallet, storage)) === null || _ByWallet_schema1 === void 0 ? void 0 : _ByWallet_schema1.mutate(mutators/* Mutators */.g.mapData(function() {
                    let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : new fetched_data/* Data */.V([]);
                    return d.mapSync((p)=>[
                            ...p,
                            TokenSettingsRef.from(currentData)
                        ]);
                })));
            }
        };
        return (0,query/* createQuery */.rP)({
            key: key(wallet, token),
            storage,
            indexer
        });
    }
    BgTokenSettings.schema = schema;
})(BgTokenSettings || (BgTokenSettings = {}));

;// CONCATENATED MODULE: ./src/mods/foreground/entities/wallets/tokens/data.ts





var FgTokenSettings;
(function(FgTokenSettings) {
    let ByWallet;
    (function(ByWallet) {
        ByWallet.key = BgTokenSettings.ByWallet.key;
        function schema(wallet, storage) {
            if (wallet == null) return;
            return (0,query/* createQuery */.rP)({
                key: ByWallet.key(wallet),
                storage
            });
        }
        ByWallet.schema = schema;
    })(ByWallet = FgTokenSettings.ByWallet || (FgTokenSettings.ByWallet = {}));
    FgTokenSettings.key = BgTokenSettings.key;
    function schema(wallet, token, storage) {
        if (wallet == null) return;
        if (token == null) return;
        const indexer = async (states)=>{
            var _previous_real_data, _previous_real, _current_real_data, _current_real;
            const { current, previous } = states;
            const previousData = previous === null || previous === void 0 ? void 0 : (_previous_real = previous.real) === null || _previous_real === void 0 ? void 0 : (_previous_real_data = _previous_real.data) === null || _previous_real_data === void 0 ? void 0 : _previous_real_data.get();
            const currentData = (_current_real = current.real) === null || _current_real === void 0 ? void 0 : (_current_real_data = _current_real.data) === null || _current_real_data === void 0 ? void 0 : _current_real_data.get();
            if ((previousData === null || previousData === void 0 ? void 0 : previousData.uuid) === (currentData === null || currentData === void 0 ? void 0 : currentData.uuid)) return;
            if (previousData != null) {
                var _ByWallet_schema;
                await ((_ByWallet_schema = ByWallet.schema(previousData.wallet, storage)) === null || _ByWallet_schema === void 0 ? void 0 : _ByWallet_schema.mutate(mutators/* Mutators */.g.mapData(function() {
                    let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : new fetched_data/* Data */.V([]);
                    return d.mapSync((p)=>p.filter((x)=>x.uuid !== previousData.uuid));
                })));
            }
            if (currentData != null) {
                var _ByWallet_schema1;
                await ((_ByWallet_schema1 = ByWallet.schema(currentData.wallet, storage)) === null || _ByWallet_schema1 === void 0 ? void 0 : _ByWallet_schema1.mutate(mutators/* Mutators */.g.mapData(function() {
                    let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : new fetched_data/* Data */.V([]);
                    return d.mapSync((p)=>[
                            ...p,
                            TokenSettingsRef.from(currentData)
                        ]);
                })));
            }
        };
        return (0,query/* createQuery */.rP)({
            key: FgTokenSettings.key(wallet, token),
            storage,
            indexer
        });
    }
    FgTokenSettings.schema = schema;
})(FgTokenSettings || (FgTokenSettings = {}));
function useTokenSettings(wallet, token) {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(FgTokenSettings.schema, [
        wallet,
        token,
        storage
    ]);
    (0,storage_storage/* useSubscribe */.Q)(query, storage);
    return query;
}
function useTokenSettingsByWallet(wallet) {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(FgTokenSettings.ByWallet.schema, [
        wallet,
        storage
    ]);
    (0,storage_storage/* useSubscribe */.Q)(query, storage);
    return query;
}

;// CONCATENATED MODULE: ./src/mods/foreground/entities/wallets/page.tsx
/* eslint-disable @next/next/no-img-element */ 
































function WalletPage(props) {
    const { uuid } = props;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(wallets_context/* WalletDataProvider */.lp, {
        uuid: uuid,
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(WalletDataPage, {})
    });
}
function useDisplay(result) {
    return (0,react.useMemo)(()=>{
        if (result == null) return "0.00";
        if (result.isErr()) return "0.00";
        const number = Number(types_fixed/* Fixed */.g.from(result.unwrap()).move(5).toString());
        return number.toLocaleString(undefined);
    }, [
        result
    ]);
}
function useDisplayUsd(result) {
    return (0,react.useMemo)(()=>{
        if (result == null) return "0.00";
        if (result.isErr()) return "Error";
        const number = Number(types_fixed/* Fixed */.g.from(result.unwrap()).move(2).toString());
        return number.toLocaleString(undefined, {
            style: "currency",
            currency: "USD",
            notation: "standard"
        });
    }, [
        result
    ]);
}
function useCompactDisplayUsd(result) {
    return (0,react.useMemo)(()=>{
        if (result == null) return "0.00";
        if (result.isErr()) return "Error";
        const number = Number(types_fixed/* Fixed */.g.from(result.unwrap()).move(2).toString());
        return number.toLocaleString(undefined, {
            style: "currency",
            currency: "USD",
            notation: "compact"
        });
    }, [
        result
    ]);
}
function LinkCard(props) {
    const { children, ...rest } = props;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("a", {
        className: "grow group p-4 bg-contrast rounded-xl cursor-pointer focus:outline-black focus:outline-1",
        ...rest,
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
            className: "h-full w-full flex items-center justify-center gap-2 group-active:scale-90 transition-transform",
            children: children
        })
    });
}
function ButtonCard(props) {
    const { children, ...rest } = props;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
        className: "grow group p-4 bg-contrast rounded-xl cursor-pointer focus:outline-black focus:outline-1",
        ...rest,
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
            className: "h-full w-full flex items-center justify-center gap-2 group-active:scale-90 transition-transform",
            children: children
        })
    });
}
function DivLikeButton(props) {
    const { children, onClick, className } = props;
    const onEnter = useKeyboardEnter(()=>{
        onClick();
    }, [
        onClick
    ]);
    return /*#__PURE__*/ _jsx("div", {
        className: className,
        role: "button",
        onClick: onClick,
        onKeyDown: onEnter,
        tabIndex: 0,
        children: children
    });
}
function WalletDataPage() {
    var _walletTokens_data, _userTokens_data;
    const wallet = (0,wallets_context/* useWalletDataContext */.zI)().unwrap();
    const background = (0,context/* useBackgroundContext */.D_)().unwrap();
    const subpath = (0,path_context/* useSubpath */._u)();
    const mainnet = (0,entities_wallets_data/* useEthereumContext2 */.IL)(wallet.uuid, mods_chain/* chainByChainId */.DH[1]).unwrap();
    (0,names_data/* useEnsReverse */.DB)(wallet.address, mainnet);
    const onSubpathClose = (0,react.useCallback)(()=>{
        subpath.go("/");
    }, [
        subpath
    ]);
    const receiveDialog = (0,handles_boolean/* useBooleanHandle */.x)(false);
    const [color, color2] = colors/* Gradients */.R.get(wallet.color);
    const [all, setAll] = (0,react.useState)(false);
    const [edit, setEdit] = (0,react.useState)(false);
    const add = (0,handles_boolean/* useBooleanHandle */.x)(false);
    const walletTokens = useTokenSettingsByWallet(wallet);
    const userTokens = useTokens();
    const allTokens = (0,react.useMemo)(()=>{
        const natives = Object.values(mods_chain/* chainByChainId */.DH).map((x)=>x.token);
        const contracts = Object.values(mods_chain/* tokenByAddress */.q2);
        const all = [
            ...natives,
            ...contracts
        ];
        return all.sort((a, b)=>a.chainId - b.chainId);
    }, []);
    const onBackClick = (0,react.useCallback)(()=>{
        path_context/* Paths */.nB.go("/wallets");
    }, []);
    const onCameraClick = (0,react.useCallback)(()=>{
        path_context/* Paths */.nB.go("/wallet/".concat(wallet.uuid, "/camera"));
    }, [
        wallet
    ]);
    const onLinkClick = (0,react.useCallback)(async ()=>{
        return await result/* Result */.x.unthrow(async (t)=>{
            const clipboard = await result/* Result */.x.runAndWrap(async ()=>{
                return await navigator.clipboard.readText();
            }).then((r)=>r.orElseSync(()=>{
                    return option_option/* Option */.W.wrap(prompt("Paste a WalletConnect link here")).ok();
                }).throw(t));
            const url = result/* Result */.x.runAndDoubleWrapSync(()=>new URL(clipboard)).setErr(new errors/* UIError */.m("You must copy a WalletConnect link")).throw(t);
            await Wc.tryParse(url).then((r)=>r.setErr(new errors/* UIError */.m("You must copy a WalletConnect link")).throw(t));
            alert("Connecting...");
            const metadata = await background.tryRequest({
                method: "brume_wc_connect",
                params: [
                    clipboard,
                    wallet.uuid
                ]
            }).then((r)=>r.throw(t).throw(t));
            alert("Connected to ".concat(metadata.name));
            return ok.Ok.void();
        }).then(results/* Results */.u.logAndAlert);
    }, [
        wallet,
        background
    ]);
    const Header = /*#__PURE__*/ (0,jsx_runtime.jsx)(header/* UserPageHeader */.To, {
        title: "Wallet",
        back: onBackClick,
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
            className: "flex gap-2",
            children: background.isWebsite() && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.Base */.z.XY, {
                        className: "size-8 hovered-or-clicked-or-focused:scale-105 !transition",
                        onClick: onCameraClick,
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
                            children: /*#__PURE__*/ (0,jsx_runtime.jsx)(QrCodeIcon/* default */.Z, {
                                className: "size-5"
                            })
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.Base */.z.XY, {
                        className: "size-8 hovered-or-clicked-or-focused:scale-105 !transition",
                        onClick: onLinkClick,
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
                            children: /*#__PURE__*/ (0,jsx_runtime.jsx)(LinkIcon/* default */.Z, {
                                className: "size-5"
                            })
                        })
                    })
                ]
            })
        })
    });
    const Card = /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
        className: "p-4 flex justify-center",
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "w-full max-w-sm",
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsx)(card/* SimpleWalletDataCard */.T, {}),
                wallet.type === "readonly" && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "h-2"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "po-sm bg-contrast text-contrast rounded-xl flex items-center justify-center",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)(EyeIcon/* default */.Z, {
                                    className: "size-5"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    className: "w-2"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    children: "This is a watch-only wallet"
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
    const Apps = /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "po-md grid place-content-start gap-2 grid-cols-[repeat(auto-fill,minmax(10rem,1fr))]",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(LinkCard, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(BanknotesIcon/* default */.Z, {
                        className: "size-4"
                    }),
                    "Tokens"
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(LinkCard, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(PaperAirplaneIcon/* default */.Z, {
                        className: "size-4"
                    }),
                    "Transactions"
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(ButtonCard, {
                onClick: receiveDialog.enable,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(QrCodeIcon/* default */.Z, {
                        className: "size-4"
                    }),
                    "Receive"
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(LinkCard, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(TrophyIcon/* default */.Z, {
                        className: "size-4"
                    }),
                    "NFTs"
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(LinkCard, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(LinkIcon/* default */.Z, {
                        className: "size-4"
                    }),
                    "Links"
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(LinkCard, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(CheckIcon/* default */.Z, {
                        className: "size-4"
                    }),
                    "Approvals"
                ]
            })
        ]
    });
    const Body = /*#__PURE__*/ (0,jsx_runtime.jsxs)(header/* PageBody */.xV, {
        children: [
            add.current && /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Dialog */.Vq, {
                close: add.disable,
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(TokenAddDialog, {})
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "font-medium text-xl",
                children: "Tokens"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-4"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "flex flex-col gap-4",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(TokenRowRouter, {
                        token: mods_chain/* chainByChainId */.DH[1].token
                    }),
                    !edit && ((_walletTokens_data = walletTokens.data) === null || _walletTokens_data === void 0 ? void 0 : _walletTokens_data.get().map((tokenSettings)=>/*#__PURE__*/ (0,jsx_runtime.jsx)(AddedTokenRow, {
                            settingsRef: tokenSettings
                        }, tokenSettings.uuid)))
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-4"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "flex items-center gap-2",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                        className: "".concat(ui_button/* Button.Base */.z.XY.className, " po-sm bg-gradient-to-r from-").concat(color, " to-").concat(color2, " text-white self-center hovered-or-clicked-or-focused:scale-105 !transition"),
                        onClick: ()=>setAll(!all),
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
                            children: all ? "Show less" : "Show more"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "grow"
                    }),
                    all && /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                        className: "".concat(ui_button/* Button.Base */.z.XY.className, " po-sm bg-gradient-to-r from-").concat(color, " to-").concat(color2, " text-white self-center hovered-or-clicked-or-focused:scale-105 !transition"),
                        onClick: ()=>setEdit(!edit),
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
                            children: edit ? "Done" : "Edit"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                        className: "".concat(ui_button/* Button.Base */.z.XY.className, " po-sm bg-gradient-to-r from-").concat(color, " to-").concat(color2, " text-white self-center hovered-or-clicked-or-focused:scale-105 !transition"),
                        onClick: add.enable,
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
                            children: "Add"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-4"
            }),
            all && /*#__PURE__*/ (0,jsx_runtime.jsx)(TokensEditContext.Provider, {
                value: edit,
                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                    className: "flex flex-col gap-4",
                    children: [
                        allTokens.map((token)=>/*#__PURE__*/ (0,jsx_runtime.jsx)(react.Fragment, {
                                children: token.uuid !== mods_chain/* chainByChainId */.DH[1].token.uuid && /*#__PURE__*/ (0,jsx_runtime.jsx)(UnaddedTokenRow, {
                                    token: token
                                })
                            }, token.uuid)),
                        (_userTokens_data = userTokens.data) === null || _userTokens_data === void 0 ? void 0 : _userTokens_data.get().map((token)=>/*#__PURE__*/ (0,jsx_runtime.jsx)(UnaddedTokenRow, {
                                token: token
                            }, token.uuid))
                    ]
                })
            })
        ]
    });
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(page/* Page */.T, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(path_context/* PathContext */.FM.Provider, {
                value: subpath,
                children: subpath.url.pathname === "/send" && wallet.type !== "readonly" && /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Screen */.lL, {
                    close: onSubpathClose,
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)(WalletSendScreen, {})
                })
            }),
            receiveDialog.current && /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Screen */.lL, {
                dark: true,
                close: receiveDialog.disable,
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(WalletDataReceiveScreen, {})
            }),
            Header,
            Card,
            Apps,
            Body
        ]
    });
}
const TokensEditContext = /*#__PURE__*/ (0,react.createContext)(false);
function useTokensEditContext() {
    return option_option/* Option */.W.wrap((0,react.useContext)(TokensEditContext));
}
function AddedTokenRow(props) {
    var _settings_data;
    const wallet = (0,wallets_context/* useWalletDataContext */.zI)().unwrap();
    const { settingsRef } = props;
    const { token } = settingsRef;
    const settings = useTokenSettings(wallet, token);
    if (token.type === "native" && token.chainId === 1) return null;
    if (!((_settings_data = settings.data) === null || _settings_data === void 0 ? void 0 : _settings_data.get().enabled)) return null;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(TokenRowRouter, {
        token: settings.data.get().token
    });
}
function UnaddedTokenRow(props) {
    var _settings_data;
    const edit = useTokensEditContext().unwrap();
    const wallet = (0,wallets_context/* useWalletDataContext */.zI)().unwrap();
    const { token } = props;
    const settings = useTokenSettings(wallet, token);
    if (((_settings_data = settings.data) === null || _settings_data === void 0 ? void 0 : _settings_data.get().enabled) && !edit) return null;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(TokenRowRouter, {
        token: token
    });
}
function TokenRowRouter(props) {
    const { token } = props;
    if (token.type === "native") return /*#__PURE__*/ (0,jsx_runtime.jsx)(NativeTokenResolver, {
        token: token
    });
    if (token.type === "contract") return /*#__PURE__*/ (0,jsx_runtime.jsx)(ContractTokenResolver, {
        token: token
    });
    return null;
}
function NativeTokenResolver(props) {
    const { token } = props;
    const chainData = mods_chain/* chainByChainId */.DH[token.chainId];
    const tokenData = chainData.token;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(NativeTokenRow, {
        token: tokenData,
        chain: chainData
    });
}
function ContractTokenResolver(props) {
    var _tokenQuery_data;
    const { token } = props;
    const tokenQuery = useToken(token.chainId, token.address);
    var _tokenQuery_data_get;
    const tokenData = (_tokenQuery_data_get = (_tokenQuery_data = tokenQuery.data) === null || _tokenQuery_data === void 0 ? void 0 : _tokenQuery_data.get()) !== null && _tokenQuery_data_get !== void 0 ? _tokenQuery_data_get : mods_chain/* tokenByAddress */.q2[token.address];
    const chainData = mods_chain/* chainByChainId */.DH[token.chainId];
    if (tokenData == null) return null;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(ContractTokenRow, {
        token: tokenData,
        chain: chainData
    });
}
function NativeTokenRow(props) {
    var _token_pairs, _chain_token_pairs;
    const { token, chain } = props;
    const wallet = (0,wallets_context/* useWalletDataContext */.zI)().unwrap();
    const edit = useTokensEditContext().unwrap();
    const subpath = (0,path_context/* useSubpath */._u)();
    const context = (0,entities_wallets_data/* useEthereumContext2 */.IL)(wallet.uuid, chain).unwrap();
    const onClick = (0,react.useCallback)(()=>{
        subpath.go("/send?step=target&chain=".concat(context === null || context === void 0 ? void 0 : context.chain.chainId));
    }, [
        subpath,
        context
    ]);
    var _token_pairs_length;
    const [prices, setPrices] = (0,react.useState)(new Array((_token_pairs_length = (_token_pairs = token.pairs) === null || _token_pairs === void 0 ? void 0 : _token_pairs.length) !== null && _token_pairs_length !== void 0 ? _token_pairs_length : 0));
    const balanceQuery = useNativeBalance(wallet.address, "pending", context, prices);
    const balanceDisplay = useDisplay(balanceQuery.current);
    const balanceUsdFixed = useNativePricedBalance(wallet.address, "usd", context);
    const balanceUsdDisplay = useDisplayUsd(balanceUsdFixed.current);
    const onPrice = (0,react.useCallback)((param)=>{
        let [index, data] = param;
        setPrices((prices)=>{
            prices[index] = data;
            return [
                ...prices
            ];
        });
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            (_chain_token_pairs = chain.token.pairs) === null || _chain_token_pairs === void 0 ? void 0 : _chain_token_pairs.map((address, i)=>/*#__PURE__*/ (0,jsx_runtime.jsx)(PriceResolver, {
                    index: i,
                    address: address,
                    ok: onPrice
                }, i)),
            !edit && /*#__PURE__*/ (0,jsx_runtime.jsx)(ClickableTokenRow, {
                ok: onClick,
                token: token,
                chain: chain,
                balanceDisplay: balanceDisplay,
                balanceUsdDisplay: balanceUsdDisplay
            }),
            edit && /*#__PURE__*/ (0,jsx_runtime.jsx)(CheckableTokenRow, {
                token: token,
                chain: chain,
                balanceDisplay: balanceDisplay,
                balanceUsdDisplay: balanceUsdDisplay
            })
        ]
    });
}
function ContractTokenRow(props) {
    var _token_pairs, _token_pairs1;
    const { token, chain } = props;
    const wallet = (0,wallets_context/* useWalletDataContext */.zI)().unwrap();
    const edit = useTokensEditContext().unwrap();
    const subpath = (0,path_context/* useSubpath */._u)();
    const context = (0,entities_wallets_data/* useEthereumContext2 */.IL)(wallet.uuid, chain).unwrap();
    var _token_pairs_length;
    const [prices, setPrices] = (0,react.useState)(new Array((_token_pairs_length = (_token_pairs = token.pairs) === null || _token_pairs === void 0 ? void 0 : _token_pairs.length) !== null && _token_pairs_length !== void 0 ? _token_pairs_length : 0));
    const balanceQuery = useContractBalance(wallet.address, token, "pending", context, prices);
    const balanceDisplay = useDisplay(balanceQuery.current);
    const onSendClick = (0,react.useCallback)(()=>{
        subpath.go("/send?step=target&chain=".concat(context === null || context === void 0 ? void 0 : context.chain.chainId, "&token=").concat(token.address));
    }, [
        subpath,
        context,
        token
    ]);
    const balanceUsdFixed = useContractPricedBalance(wallet.address, token, "usd", context);
    const balanceUsdDisplay = useDisplayUsd(balanceUsdFixed.current);
    const onPrice = (0,react.useCallback)((param)=>{
        let [index, data] = param;
        setPrices((prices)=>{
            prices[index] = data;
            return [
                ...prices
            ];
        });
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            (_token_pairs1 = token.pairs) === null || _token_pairs1 === void 0 ? void 0 : _token_pairs1.map((address, i)=>/*#__PURE__*/ (0,jsx_runtime.jsx)(PriceResolver, {
                    index: i,
                    address: address,
                    ok: onPrice
                }, i)),
            !edit && /*#__PURE__*/ (0,jsx_runtime.jsx)(ClickableTokenRow, {
                ok: onSendClick,
                token: token,
                chain: chain,
                balanceDisplay: balanceDisplay,
                balanceUsdDisplay: balanceUsdDisplay
            }),
            edit && /*#__PURE__*/ (0,jsx_runtime.jsx)(CheckableTokenRow, {
                token: token,
                chain: chain,
                balanceDisplay: balanceDisplay,
                balanceUsdDisplay: balanceUsdDisplay
            })
        ]
    });
}
function PriceResolver(props) {
    const { ok, index, address } = props;
    const wallet = (0,wallets_context/* useWalletDataContext */.zI)().unwrap();
    const pairData = mods_chain/* pairByAddress */.ne[address];
    const chainData = mods_chain/* chainByChainId */.DH[pairData.chainId];
    const context = (0,entities_wallets_data/* useEthereumContext */.Kn)(wallet.uuid, chainData);
    const { data } = usePairPrice(pairData, "pending", context);
    (0,react.useEffect)(()=>{
        ok([
            index,
            data === null || data === void 0 ? void 0 : data.inner
        ]);
    }, [
        index,
        data,
        ok
    ]);
    return null;
}
function ClickableTokenRow(props) {
    const { ok, token, chain, balanceDisplay, balanceUsdDisplay } = props;
    const onClick = (0,events/* useMouse */.ii)((e)=>{
        ok(e);
    }, [
        ok
    ]);
    const tokenId = token.type === "native" ? token.chainId + token.symbol : token.chainId + token.address + token.symbol;
    const modtoken = colors/* Colors */.w.get((0,modhash/* useModhash */.jR)("".concat(tokenId)));
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("button", {
        className: "po-sm group flex items-center text-left",
        onClick: onClick,
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "relative h-12 w-12 flex items-center justify-center bg-".concat(modtoken, " text-white rounded-full"),
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "",
                        style: {
                            fontSize: "".concat(Math.min(20 - 2 * token.symbol.length, 16), "px")
                        },
                        children: token.symbol
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "absolute -bottom-2 -left-2",
                        children: chain.icon()
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "w-4"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "grow",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "flex items-center",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "grow flex items-center gap-1",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                        className: "",
                                        children: token.name
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                        className: "text-contrast",
                                        children: "on"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                        className: "",
                                        children: chain.name
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "",
                                children: balanceUsdDisplay
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "text-contrast",
                        children: [
                            balanceDisplay,
                            " ",
                            token.symbol
                        ]
                    })
                ]
            })
        ]
    });
}
function CheckableTokenRow(props) {
    var _settings_data;
    const { token, chain, balanceDisplay, balanceUsdDisplay } = props;
    const wallet = (0,wallets_context/* useWalletDataContext */.zI)().unwrap();
    const settings = useTokenSettings(wallet, token);
    const checked = (_settings_data = settings.data) === null || _settings_data === void 0 ? void 0 : _settings_data.get().enabled;
    const onToggle = (0,events/* useInputChange */.Xy)(async (e)=>{
        const enabled = e.currentTarget.checked;
        await settings.mutate((s)=>{
            var _s_real;
            const data = mutators/* Mutators */.g.Datas.mapOrNew(function() {
                let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {
                    uuid: crypto.randomUUID(),
                    token: TokenRef.from(token),
                    wallet: wallets_data/* WalletRef */.V.from(wallet),
                    enabled
                };
                return {
                    ...d,
                    enabled
                };
            }, (_s_real = s.real) === null || _s_real === void 0 ? void 0 : _s_real.data);
            return new some/* Some */.b(data);
        });
    }, []);
    const tokenId = token.type === "native" ? token.chainId + token.symbol : token.chainId + token.address + token.symbol;
    const modtoken = colors/* Colors */.w.get((0,modhash/* useModhash */.jR)("".concat(tokenId)));
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("label", {
        className: "po-sm group flex items-center",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)("input", {
                className: "appearance-none",
                type: "checkbox",
                checked: checked,
                onChange: onToggle
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-6 w-6 border border-contrast rounded-full aria-checked:bg-blue-500 flex items-center justify-center transition-colors",
                "aria-checked": checked,
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "text-white invisible aria-checked:visible",
                    "aria-checked": checked,
                    children: "✓"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "w-4"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "relative h-12 w-12 flex items-center justify-center bg-".concat(modtoken, " text-white rounded-full"),
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "",
                        style: {
                            fontSize: "".concat(Math.min(20 - 2 * token.symbol.length, 16), "px")
                        },
                        children: token.symbol
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "absolute -bottom-2 -left-2",
                        children: chain.icon()
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "w-4"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "grow",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "flex items-center",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "grow flex items-center gap-1",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                        className: "",
                                        children: token.name
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                        className: "text-contrast",
                                        children: "on"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                        className: "",
                                        children: chain.name
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "",
                                children: balanceUsdDisplay
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "text-contrast",
                        children: [
                            balanceDisplay,
                            " ",
                            token.symbol
                        ]
                    })
                ]
            })
        ]
    });
}


/***/ }),

/***/ 8422:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Ai: function() { return /* binding */ UserRejectedError; }
/* harmony export */ });
/* unused harmony exports UnauthorizedError, UnsupportedMethodError, DisconnectedError, ChainDisconnectedError */
/* harmony import */ var _swc_helpers_class_private_field_get__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7121);
/* harmony import */ var _swc_helpers_class_private_field_init__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9886);
/* harmony import */ var _swc_helpers_class_private_field_set__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5321);
/* harmony import */ var _hazae41_jsonrpc__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(667);



var _a, _b, _c, _d, _e;

var _class = /*#__PURE__*/ new WeakMap();
class UserRejectedError extends _hazae41_jsonrpc__WEBPACK_IMPORTED_MODULE_0__/* .RpcError */ .lt {
    static new() {
        return new _a();
    }
    constructor(){
        super(4001, "The user rejected the request.");
        (0,_swc_helpers_class_private_field_init__WEBPACK_IMPORTED_MODULE_1__._)(this, _class, {
            writable: true,
            value: void 0
        });
        (0,_swc_helpers_class_private_field_set__WEBPACK_IMPORTED_MODULE_2__._)(this, _class, _a);
        this.name = (0,_swc_helpers_class_private_field_get__WEBPACK_IMPORTED_MODULE_3__._)(this, _class).name;
    }
}
_a = UserRejectedError;
var _class1 = /*#__PURE__*/ new WeakMap();
class UnauthorizedError extends _hazae41_jsonrpc__WEBPACK_IMPORTED_MODULE_0__/* .RpcError */ .lt {
    static new() {
        return new _b();
    }
    constructor(){
        super(4100, "The requested method and/or account has not been authorized by the user.");
        (0,_swc_helpers_class_private_field_init__WEBPACK_IMPORTED_MODULE_1__._)(this, _class1, {
            writable: true,
            value: void 0
        });
        (0,_swc_helpers_class_private_field_set__WEBPACK_IMPORTED_MODULE_2__._)(this, _class1, _b);
        this.name = (0,_swc_helpers_class_private_field_get__WEBPACK_IMPORTED_MODULE_3__._)(this, _class1).name;
    }
}
_b = UnauthorizedError;
var _class2 = /*#__PURE__*/ new WeakMap();
class UnsupportedMethodError extends _hazae41_jsonrpc__WEBPACK_IMPORTED_MODULE_0__/* .RpcError */ .lt {
    static new() {
        return new _c();
    }
    constructor(){
        super(4200, "The Provider does not support the requested method.");
        (0,_swc_helpers_class_private_field_init__WEBPACK_IMPORTED_MODULE_1__._)(this, _class2, {
            writable: true,
            value: void 0
        });
        (0,_swc_helpers_class_private_field_set__WEBPACK_IMPORTED_MODULE_2__._)(this, _class2, _c);
        this.name = (0,_swc_helpers_class_private_field_get__WEBPACK_IMPORTED_MODULE_3__._)(this, _class2).name;
    }
}
_c = UnsupportedMethodError;
var _class3 = /*#__PURE__*/ new WeakMap();
class DisconnectedError extends _hazae41_jsonrpc__WEBPACK_IMPORTED_MODULE_0__/* .RpcError */ .lt {
    static new() {
        return new _d();
    }
    constructor(){
        super(4900, "The Provider is disconnected from all chains.");
        (0,_swc_helpers_class_private_field_init__WEBPACK_IMPORTED_MODULE_1__._)(this, _class3, {
            writable: true,
            value: void 0
        });
        (0,_swc_helpers_class_private_field_set__WEBPACK_IMPORTED_MODULE_2__._)(this, _class3, _d);
        this.name = (0,_swc_helpers_class_private_field_get__WEBPACK_IMPORTED_MODULE_3__._)(this, _class3).name;
    }
}
_d = DisconnectedError;
var _class4 = /*#__PURE__*/ new WeakMap();
class ChainDisconnectedError extends _hazae41_jsonrpc__WEBPACK_IMPORTED_MODULE_0__/* .RpcError */ .lt {
    static new() {
        return new _e();
    }
    constructor(){
        super(4901, "The Provider is not connected to the requested chain.");
        (0,_swc_helpers_class_private_field_init__WEBPACK_IMPORTED_MODULE_1__._)(this, _class4, {
            writable: true,
            value: void 0
        });
        (0,_swc_helpers_class_private_field_set__WEBPACK_IMPORTED_MODULE_2__._)(this, _class4, _e);
        this.name = (0,_swc_helpers_class_private_field_get__WEBPACK_IMPORTED_MODULE_3__._)(this, _class4).name;
    }
}
_e = ChainDisconnectedError;


/***/ }),

/***/ 9609:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  z: function() { return /* binding */ Bottom; }
});

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/HomeIcon.js
var HomeIcon = __webpack_require__(2237);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/WalletIcon.js
var WalletIcon = __webpack_require__(5066);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/SparklesIcon.js
var SparklesIcon = __webpack_require__(5083);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/GlobeAltIcon.js
var GlobeAltIcon = __webpack_require__(307);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/CheckIcon.js
var CheckIcon = __webpack_require__(2911);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/PuzzlePieceIcon.js
var PuzzlePieceIcon = __webpack_require__(3225);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/CogIcon.js
var CogIcon = __webpack_require__(7272);
// EXTERNAL MODULE: ./src/libs/ui/anchor/anchor.tsx
var anchor_anchor = __webpack_require__(6826);
;// CONCATENATED MODULE: ./src/libs/ui/anchor/shrinker.tsx
var Shrinker;
(function(Shrinker) {
    Shrinker.className = "h-full w-full flex justify-center items-center gap-2 group-active:scale-90 transition-transform";
})(Shrinker || (Shrinker = {}));

;// CONCATENATED MODULE: ./src/libs/ui/anchor/index.tsx



;// CONCATENATED MODULE: ./src/libs/ui/anchor.tsx



// EXTERNAL MODULE: ./src/mods/foreground/entities/requests/data.tsx + 1 modules
var data = __webpack_require__(7489);
// EXTERNAL MODULE: ./src/mods/foreground/router/path/context.tsx
var context = __webpack_require__(7921);
;// CONCATENATED MODULE: ./src/mods/foreground/overlay/bottom.tsx





function Bottom() {
    var _requestsQuery_data;
    const { url } = (0,context/* usePathContext */.td)().unwrap();
    const requestsQuery = (0,data/* useAppRequests */.fU)();
    const requests = (_requestsQuery_data = requestsQuery.data) === null || _requestsQuery_data === void 0 ? void 0 : _requestsQuery_data.get();
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("nav", {
        className: "h-16 w-full shrink-0 border-t border-t-contrast",
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "w-full h-16 px-4 m-auto max-w-3xl flex items-center",
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsx)("a", {
                    className: "group grow text-contrast data-[selected=true]:text-default",
                    "data-selected": url.pathname === "/",
                    href: "#/",
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "".concat(Shrinker.className),
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(HomeIcon/* default */.Z, {
                            className: "size-6"
                        })
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("a", {
                    className: "group grow text-contrast data-[selected=true]:text-default",
                    "data-selected": url.pathname === "/wallets",
                    href: "#/wallets",
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "".concat(Shrinker.className),
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(WalletIcon/* default */.Z, {
                            className: "size-6"
                        })
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("a", {
                    className: "group grow text-contrast data-[selected=true]:text-default",
                    "data-selected": url.pathname === "/seeds",
                    href: "#/seeds",
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "".concat(Shrinker.className),
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(SparklesIcon/* default */.Z, {
                            className: "size-6"
                        })
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("a", {
                    className: "group grow text-contrast data-[selected=true]:text-default",
                    "data-selected": url.pathname === "/sessions",
                    href: "#/sessions",
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "".concat(Shrinker.className),
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(GlobeAltIcon/* default */.Z, {
                            className: "size-6"
                        })
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("a", {
                    className: "group grow text-contrast data-[selected=true]:text-default",
                    "data-selected": url.pathname === "/requests",
                    href: "#/requests",
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "".concat(Shrinker.className),
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "relative",
                            children: [
                                Boolean(requests === null || requests === void 0 ? void 0 : requests.length) && /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    className: "absolute top-0 -right-2",
                                    children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("span", {
                                        className: "relative flex w-2 h-2",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                                className: "animate-ping absolute inline-flex h-full w-full rounded-full bg-purple-400 opacity-75"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                                className: "relative inline-flex rounded-full w-2 h-2 bg-purple-400"
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)(CheckIcon/* default */.Z, {
                                    className: "size-6"
                                })
                            ]
                        })
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("a", {
                    className: "group grow text-contrast data-[selected=true]:text-default",
                    "data-selected": url.pathname === "/plugins",
                    href: "#/plugins",
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "".concat(Shrinker.className),
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(PuzzlePieceIcon/* default */.Z, {
                            className: "size-6"
                        })
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("a", {
                    className: "group grow text-contrast data-[selected=true]:text-default",
                    "data-selected": url.pathname === "/settings",
                    href: "#/settings",
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "".concat(Shrinker.className),
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(CogIcon/* default */.Z, {
                            className: "size-6"
                        })
                    })
                })
            ]
        })
    });
}


/***/ }),

/***/ 74:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   l: function() { return /* binding */ NavBar; }
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _libs_browser_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5681);
/* harmony import */ var _libs_icons_icons__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1902);
/* harmony import */ var _libs_results_results__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(421);
/* harmony import */ var _libs_ui_button__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1258);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7294);
/* harmony import */ var _router_path_context__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7921);







function NavBar() {
    const { url } = (0,_router_path_context__WEBPACK_IMPORTED_MODULE_5__/* .usePathContext */ .td)().unwrap();
    const onOpen = (0,react__WEBPACK_IMPORTED_MODULE_4__.useCallback)(async ()=>{
        await _libs_browser_browser__WEBPACK_IMPORTED_MODULE_1__/* .BrowserError */ .v.tryRun(async ()=>{
            return await _libs_browser_browser__WEBPACK_IMPORTED_MODULE_1__/* .browser */ .X.tabs.create({
                url: "index.html#".concat(url.pathname)
            });
        }).then(_libs_results_results__WEBPACK_IMPORTED_MODULE_2__/* .Results */ .u.logAndAlert);
    }, [
        url
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        className: "w-full po-md border-b border-b-contrast",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
            className: "w-full max-w-[400px] m-auto flex items-center",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "bg-contrast rounded-xl po-sm grow flex items-center min-w-0",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "grow whitespace-nowrap overflow-hidden text-ellipsis text-sm",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                className: "text-contrast",
                                children: "brume://"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                children: url.pathname.slice(1)
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: "w-2"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_libs_ui_button__WEBPACK_IMPORTED_MODULE_3__/* .Button.Base */ .z.XY, {
                        className: "text-contrast hovered-or-clicked-or-focused:scale-105 !transition",
                        onClick: onOpen,
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                            className: "".concat(_libs_ui_button__WEBPACK_IMPORTED_MODULE_3__/* .Button.Shrinker */ .z.Np.className),
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_libs_icons_icons__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                className: "size-4"
                            })
                        })
                    })
                ]
            })
        })
    });
}


/***/ }),

/***/ 8220:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  aV: function() { return /* binding */ Overlay; }
});

// UNUSED EXPORTS: ExtensionOverlay, UpdateBanner, WebsiteOverlay

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
// EXTERNAL MODULE: ./src/libs/browser/browser.ts
var browser = __webpack_require__(5681);
;// CONCATENATED MODULE: ./src/libs/fetch/fetch.ts

async function tryFetchAsJson(input, init) {
    return Result.runAndDoubleWrap(()=>fetchAsJsonOrThrow(input, init));
}
async function fetchAsJsonOrThrow(input, init) {
    const res = await fetch(input, init);
    if (!res.ok) throw new Error(await res.text());
    return await res.json();
}
async function tryFetchAsBlob(input, init) {
    return Result.runAndDoubleWrap(()=>fetchAsBlobOrThrow(input, init));
}
async function fetchAsBlobOrThrow(input, init) {
    const res = await fetch(input, init);
    if (!res.ok) throw new Error(await res.text());
    return await res.blob();
}

// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/ArrowPathIcon.js
var ArrowPathIcon = __webpack_require__(5973);
;// CONCATENATED MODULE: ./src/libs/semver/semver.ts
var Semver;
(function(Semver) {
    function isGreater(left, right) {
        const [la, lb, lc] = left.split(".").map((x)=>parseInt(x));
        const [ra, rb, rc] = right.split(".").map((x)=>parseInt(x));
        if (la > ra) return true;
        if (lb > rb) return true;
        if (lc > rc) return true;
        return false;
    }
    Semver.isGreater = isGreater;
})(Semver || (Semver = {}));

// EXTERNAL MODULE: ./src/libs/ui/button.tsx + 8 modules
var ui_button = __webpack_require__(1258);
// EXTERNAL MODULE: ./node_modules/@hazae41/option/dist/esm/mods/option/none.mjs
var none = __webpack_require__(1371);
// EXTERNAL MODULE: ./node_modules/react/index.js
var react = __webpack_require__(7294);
// EXTERNAL MODULE: ./src/mods/foreground/background/context.tsx + 3 modules
var context = __webpack_require__(7028);
;// CONCATENATED MODULE: ./src/mods/foreground/overlay/overlay.tsx









const MAIN_PACKAGE_URL = "https://raw.githubusercontent.com/brumewallet/wallet/main/package.json";
function UpdateBanner(props) {
    const { ok } = props;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
        className: "w-full text-white bg-green-500 po-sm",
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "w-full max-w-[400px] m-auto flex flex-wrap gap-2 items-center text-sm",
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "grow",
                    children: "An update is available"
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.Base */.z.XY, {
                    className: "hovered-or-clicked-or-focused:scale-105 !transition",
                    onClick: ok,
                    children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(ArrowPathIcon/* default */.Z, {
                                className: "size-5"
                            }),
                            "Update"
                        ]
                    })
                })
            ]
        })
    });
}
function Overlay(props) {
    const { children } = props;
    const background = (0,context/* useBackgroundContext */.D_)().unwrap();
    if (background.isExtension()) return /*#__PURE__*/ (0,jsx_runtime.jsx)(ExtensionOverlay, {
        children: children
    });
    if (background.isWebsite()) return /*#__PURE__*/ (0,jsx_runtime.jsx)(WebsiteOverlay, {
        children: children
    });
    return null;
}
async function checkWebsiteUpdateOrThrow() {
    const cached = await fetchAsJsonOrThrow("/manifest.json");
    const current = await fetchAsJsonOrThrow("/manifest.json?");
    if (current.version !== cached.version) return false; // Will be handled by SW
    const main = await fetchAsJsonOrThrow(MAIN_PACKAGE_URL);
    return Semver.isGreater(main.version, cached.version);
}
function WebsiteOverlay(props) {
    const { children } = props;
    const background = (0,context/* useBackgroundContext */.D_)().unwrap();
    const [updating, setUpdating] = (0,react.useState)();
    (0,react.useEffect)(()=>{
        if (!background.isWebsite()) return;
        const onUpdate = (sw)=>{
            setUpdating(sw);
            return new none/* None */.H();
        };
        return background.sw.on("update", onUpdate);
    }, [
        background
    ]);
    const update = (0,react.useCallback)(()=>{
        updating === null || updating === void 0 ? void 0 : updating.postMessage("SKIP_WAITING");
    }, [
        updating
    ]);
    const [updatable, setUpdatable] = (0,react.useState)(false);
    (0,react.useEffect)(()=>{
        checkWebsiteUpdateOrThrow().then(setUpdatable).catch(console.warn);
    }, []);
    const update2 = (0,react.useCallback)(()=>{
        open("https://github.com/brumewallet/wallet/releases", "_blank", "noreferrer");
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            updating && /*#__PURE__*/ (0,jsx_runtime.jsx)(UpdateBanner, {
                ok: update
            }),
            updatable && /*#__PURE__*/ (0,jsx_runtime.jsx)(UpdateBanner, {
                ok: update2
            }),
            children
        ]
    });
}
async function checkDevExtensionUpdateOrThrow(self) {
    const main = await fetchAsJsonOrThrow(MAIN_PACKAGE_URL);
    return Semver.isGreater(main.version, self.version);
}
async function checkExtensionUpdateOrThrow() {
    const self = await browser/* BrowserError */.v.runOrThrow(()=>browser/* browser */.X.management.getSelf());
    if (self.installType === "development") return await checkDevExtensionUpdateOrThrow(self);
    return false;
}
function ExtensionOverlay(props) {
    const { children } = props;
    const [updatable, setUpdatable] = (0,react.useState)(false);
    (0,react.useEffect)(()=>{
        checkExtensionUpdateOrThrow().then(setUpdatable).catch(console.warn);
    }, []);
    const update = (0,react.useCallback)(()=>{
        open("https://github.com/brumewallet/wallet/releases", "_blank", "noreferrer");
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            updatable && /*#__PURE__*/ (0,jsx_runtime.jsx)(UpdateBanner, {
                ok: update
            }),
            children
        ]
    });
}


/***/ }),

/***/ 2932:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  F: function() { return /* binding */ Router; }
});

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
// EXTERNAL MODULE: ./pages/popup.tsx
var popup = __webpack_require__(2726);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/TrashIcon.js
var TrashIcon = __webpack_require__(6249);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/CubeTransparentIcon.js
var CubeTransparentIcon = __webpack_require__(3490);
// EXTERNAL MODULE: ./src/libs/react/callback.tsx
var callback = __webpack_require__(7174);
// EXTERNAL MODULE: ./src/libs/results/results.ts
var results = __webpack_require__(421);
// EXTERNAL MODULE: ./src/libs/ui/button.tsx + 8 modules
var ui_button = __webpack_require__(1258);
// EXTERNAL MODULE: ./node_modules/react/index.js
var react = __webpack_require__(7294);
;// CONCATENATED MODULE: ./src/libs/ui/image/image_with_fallback.tsx


function ImageWithFallback(props) {
    const { children, src, onError, ...img } = props;
    const [error, setError] = (0,react.useState)(false);
    (0,react.useEffect)(()=>setError(false), [
        src
    ]);
    const onError2 = (0,react.useCallback)((event)=>{
        setError(true);
        return onError === null || onError === void 0 ? void 0 : onError(event);
    }, [
        onError
    ]);
    if (error) return /*#__PURE__*/ (0,jsx_runtime.jsx)(jsx_runtime.Fragment, {
        children: children
    });
    if (src == null) return /*#__PURE__*/ (0,jsx_runtime.jsx)(jsx_runtime.Fragment, {
        children: children
    });
    // eslint-disable-next-line jsx-a11y/alt-text, @next/next/no-img-element
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("img", {
        src: src,
        onError: onError2,
        ...img
    });
}

// EXTERNAL MODULE: ./src/libs/ui2/page/header.tsx
var header = __webpack_require__(1952);
// EXTERNAL MODULE: ./src/libs/ui2/page/page.tsx
var page = __webpack_require__(3365);
// EXTERNAL MODULE: ./src/libs/url/url.ts
var url = __webpack_require__(5731);
// EXTERNAL MODULE: ./src/mods/foreground/background/context.tsx + 3 modules
var context = __webpack_require__(7028);
// EXTERNAL MODULE: ./src/mods/foreground/errors/errors.ts
var errors = __webpack_require__(8422);
// EXTERNAL MODULE: ./src/mods/foreground/router/path/context.tsx
var path_context = __webpack_require__(7921);
// EXTERNAL MODULE: ./node_modules/@hazae41/jsonrpc/dist/esm/mods/rpc/err.mjs
var err = __webpack_require__(667);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/result.mjs
var result = __webpack_require__(918);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/ok.mjs
var ok = __webpack_require__(5591);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/err.mjs
var result_err = __webpack_require__(166);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/queries/simple/query.mjs
var query = __webpack_require__(6233);
;// CONCATENATED MODULE: ./src/mods/background/service_worker/entities/blobbys/data.ts

var BlobbyRef;
(function(BlobbyRef) {
    function create(id) {
        return {
            ref: true,
            id
        };
    }
    BlobbyRef.create = create;
    function from(blobby) {
        return create(blobby.id);
    }
    BlobbyRef.from = from;
})(BlobbyRef || (BlobbyRef = {}));
var BgBlobby;
(function(BgBlobby) {
    function key(id) {
        return "blobby/".concat(id);
    }
    BgBlobby.key = key;
    function schema(id, storage) {
        return (0,query/* createQuery */.rP)({
            key: key(id),
            storage
        });
    }
    BgBlobby.schema = schema;
})(BgBlobby || (BgBlobby = {}));

// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/react/hooks/queries/simple.mjs + 1 modules
var simple = __webpack_require__(564);
// EXTERNAL MODULE: ./src/mods/foreground/storage/storage.ts
var storage_storage = __webpack_require__(921);
// EXTERNAL MODULE: ./src/mods/foreground/storage/user.tsx
var user = __webpack_require__(8777);
;// CONCATENATED MODULE: ./src/mods/foreground/entities/blobbys/data.ts




var FgBlobby;
(function(FgBlobby) {
    FgBlobby.key = BgBlobby.key;
    function schema(id, storage) {
        if (id == null) return;
        return (0,query/* createQuery */.rP)({
            key: FgBlobby.key(id),
            storage
        });
    }
    FgBlobby.schema = schema;
})(FgBlobby || (FgBlobby = {}));
function useBlobby(id) {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(FgBlobby.schema, [
        id,
        storage
    ]);
    (0,storage_storage/* useSubscribe */.Q)(query, storage);
    return query;
}

;// CONCATENATED MODULE: ./src/mods/background/service_worker/entities/origins/data.ts

var BgOrigin;
(function(BgOrigin) {
    function key(origin) {
        return "origins/".concat(origin);
    }
    BgOrigin.key = key;
    function schema(origin, storage) {
        return (0,query/* createQuery */.rP)({
            key: key(origin),
            storage
        });
    }
    BgOrigin.schema = schema;
})(BgOrigin || (BgOrigin = {}));

;// CONCATENATED MODULE: ./src/mods/foreground/entities/origins/data.ts




var FgOrigin;
(function(FgOrigin) {
    FgOrigin.key = BgOrigin.key;
    function schema(origin, storage) {
        if (origin == null) return;
        return (0,query/* createQuery */.rP)({
            key: FgOrigin.key(origin),
            storage
        });
    }
    FgOrigin.schema = schema;
})(FgOrigin || (FgOrigin = {}));
function useOrigin(origin) {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(FgOrigin.schema, [
        origin,
        storage
    ]);
    (0,storage_storage/* useSubscribe */.Q)(query, storage);
    return query;
}

// EXTERNAL MODULE: ./src/mods/foreground/entities/requests/data.tsx + 1 modules
var data = __webpack_require__(7489);
;// CONCATENATED MODULE: ./src/mods/foreground/entities/requests/all/page.tsx
/* eslint-disable @next/next/no-img-element */ 

















function RequestsPage() {
    var _requestsQuery_data;
    const background = (0,context/* useBackgroundContext */.D_)().unwrap();
    const requestsQuery = (0,data/* useAppRequests */.fU)();
    const maybeRequests = (_requestsQuery_data = requestsQuery.data) === null || _requestsQuery_data === void 0 ? void 0 : _requestsQuery_data.get();
    const tryRejectAll = (0,callback/* useAsyncUniqueCallback */.T)(async ()=>{
        return await result/* Result */.x.unthrow(async (t)=>{
            if (maybeRequests == null) return ok.Ok.void();
            if (!confirm("Do you want to reject all requests?")) return ok.Ok.void();
            for (const { id } of maybeRequests)await background.tryRequest({
                method: "brume_respond",
                params: [
                    err/* RpcErr */.s6.rewrap(id, new result_err/* Err */.U(new errors/* UserRejectedError */.Ai()))
                ]
            }).then((r)=>r.throw(t).throw(t));
            return ok.Ok.void();
        }).then(results/* Results */.u.logAndAlert);
    }, [
        background,
        maybeRequests
    ]);
    const Body = /*#__PURE__*/ (0,jsx_runtime.jsx)(header/* PageBody */.xV, {
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
            className: "flex flex-col gap-2",
            children: maybeRequests === null || maybeRequests === void 0 ? void 0 : maybeRequests.map((request)=>/*#__PURE__*/ (0,jsx_runtime.jsx)(RequestRow, {
                    request: request
                }, request.id))
        })
    });
    const Header = /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(header/* UserPageHeader */.To, {
                title: "Requests",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.Base */.z.XY, {
                    className: "size-8 hovered-or-clicked-or-focused:scale-105 !transition",
                    disabled: tryRejectAll.loading || !Boolean(maybeRequests === null || maybeRequests === void 0 ? void 0 : maybeRequests.length),
                    onClick: tryRejectAll.run,
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(TrashIcon/* default */.Z, {
                            className: "size-5"
                        })
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "po-md flex items-center",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "text-contrast",
                    children: "Request allow you to approve various actions such as transactions and signatures. These requests are sent by applications through sessions."
                })
            })
        ]
    });
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(page/* Page */.T, {
        children: [
            Header,
            Body
        ]
    });
}
function RequestRow(props) {
    var _requestQuery_data, _originQuery_data, _maybeOriginData_icons, _iconDatas_find;
    const requestQuery = (0,data/* useAppRequest */.Vd)(props.request.id);
    const maybeRequestData = (_requestQuery_data = requestQuery.data) === null || _requestQuery_data === void 0 ? void 0 : _requestQuery_data.get();
    const originQuery = useOrigin(maybeRequestData === null || maybeRequestData === void 0 ? void 0 : maybeRequestData.origin);
    const maybeOriginData = (_originQuery_data = originQuery.data) === null || _originQuery_data === void 0 ? void 0 : _originQuery_data.get();
    const [iconDatas, setIconDatas] = (0,react.useState)([]);
    const onIconData = (0,react.useCallback)((param)=>{
        let [index, data] = param;
        setIconDatas((iconDatas)=>{
            iconDatas[index] = data;
            return [
                ...iconDatas
            ];
        });
    }, []);
    const open = (0,react.useCallback)(async ()=>{
        if (maybeRequestData == null) return;
        const { id, method, params } = maybeRequestData;
        path_context/* Paths */.nB.go((0,url/* qurl */.d)("/".concat(method, "?id=").concat(id), params));
    }, [
        maybeRequestData
    ]);
    if (maybeOriginData == null) return null;
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        role: "button",
        className: "po-md rounded-xl flex items-center gap-4",
        onClick: open,
        children: [
            (_maybeOriginData_icons = maybeOriginData.icons) === null || _maybeOriginData_icons === void 0 ? void 0 : _maybeOriginData_icons.map((x, i)=>/*#__PURE__*/ (0,jsx_runtime.jsx)(IndexedBlobbyLoader, {
                    index: i,
                    id: x.id,
                    ok: onIconData
                }, x.id)),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "shrink-0",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(ImageWithFallback, {
                    className: "size-10",
                    alt: "icon",
                    src: (_iconDatas_find = iconDatas.find(Boolean)) === null || _iconDatas_find === void 0 ? void 0 : _iconDatas_find.data,
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)(CubeTransparentIcon/* default */.Z, {
                        className: "size-10"
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "grow",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "font-medium",
                        children: maybeOriginData.title
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "text-contrast",
                        children: maybeOriginData.origin
                    })
                ]
            })
        ]
    });
}
function IndexedBlobbyLoader(props) {
    const { index, id, ok } = props;
    const { data } = useBlobby(id);
    (0,react.useEffect)(()=>{
        ok([
            index,
            data === null || data === void 0 ? void 0 : data.inner
        ]);
    }, [
        index,
        data,
        ok
    ]);
    return null;
}

// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/PlusIcon.js
var PlusIcon = __webpack_require__(8680);
// EXTERNAL MODULE: ./src/libs/react/handles/boolean.tsx
var handles_boolean = __webpack_require__(5902);
// EXTERNAL MODULE: ./src/libs/ui/dialog/dialog.tsx
var dialog = __webpack_require__(3868);
// EXTERNAL MODULE: ./src/libs/colors/colors.ts
var colors = __webpack_require__(7457);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/EllipsisHorizontalIcon.js
var EllipsisHorizontalIcon = __webpack_require__(6812);
// EXTERNAL MODULE: ./src/mods/foreground/entities/wallets/avatar.tsx
var avatar = __webpack_require__(9685);
// EXTERNAL MODULE: ./node_modules/@hazae41/option/dist/esm/mods/option/option.mjs
var option_option = __webpack_require__(5316);
// EXTERNAL MODULE: ./src/mods/foreground/entities/seeds/data.tsx
var seeds_data = __webpack_require__(1075);
;// CONCATENATED MODULE: ./src/mods/foreground/entities/seeds/context.tsx




const SeedDataContext = /*#__PURE__*/ (0,react.createContext)(undefined);
function useSeedDataContext() {
    return option_option/* Option */.W.unwrap((0,react.useContext)(SeedDataContext));
}
function SeedDataProvider(props) {
    const { uuid, children } = props;
    const seed = (0,seeds_data/* useSeed */.WJ)(uuid);
    if (seed.current == null) return null;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(SeedDataContext.Provider, {
        value: seed.current.get(),
        children: children
    });
}

;// CONCATENATED MODULE: ./src/mods/foreground/entities/seeds/card.tsx






function SeedDataCard() {
    const seed = useSeedDataContext();
    const [color, color2] = colors/* Gradients */.R.get(seed.color);
    const First = /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "flex items-center",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "shrink-0",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(avatar/* WalletIcon */.o, {
                    className: "text-xl",
                    emoji: seed.emoji
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "w-2 grow"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.White */.z.Ej, {
                className: "text-".concat(color),
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)(EllipsisHorizontalIcon/* default */.Z, {
                        className: "size-5"
                    })
                })
            })
        ]
    });
    const Name = /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
        className: "flex items-center text-white font-medium",
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
            className: "truncate",
            children: seed.name
        })
    });
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "po-md w-full aspect-video rounded-xl flex flex-col text-white bg-gradient-to-br from-".concat(color, " to-").concat(color2),
        children: [
            First,
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "grow"
            }),
            Name
        ]
    });
}

// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/DocumentTextIcon.js
var DocumentTextIcon = __webpack_require__(8523);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/SwatchIcon.js
var SwatchIcon = __webpack_require__(341);
// EXTERNAL MODULE: ./src/libs/emojis/emojis.ts
var emojis = __webpack_require__(33);
// EXTERNAL MODULE: ./src/libs/ledger/index.ts + 9 modules
var ledger = __webpack_require__(2029);
// EXTERNAL MODULE: ./src/libs/modhash/modhash.ts
var modhash_modhash = __webpack_require__(6652);
// EXTERNAL MODULE: ./src/libs/react/events.ts
var events = __webpack_require__(4714);
// EXTERNAL MODULE: ./src/libs/react/ref.ts + 1 modules
var ref = __webpack_require__(5351);
// EXTERNAL MODULE: ./src/libs/ui/input.tsx + 4 modules
var input = __webpack_require__(9619);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/errors.mjs
var result_errors = __webpack_require__(2564);
;// CONCATENATED MODULE: ./src/mods/foreground/entities/seeds/all/create/ledger.tsx

















function LedgerSeedCreatorDialog(props) {
    const close = (0,dialog/* useCloseContext */.gX)().unwrap();
    const background = (0,context/* useBackgroundContext */.D_)().unwrap();
    const uuid = (0,ref/* useConstant */.hS)(()=>crypto.randomUUID());
    const modhash = (0,modhash_modhash/* useModhash */.jR)(uuid);
    const color = colors/* Colors */.w.mod(modhash);
    const emoji = emojis/* Emojis */.A.get(modhash);
    const [rawNameInput = "", setRawNameInput] = (0,react.useState)();
    const defNameInput = (0,react.useDeferredValue)(rawNameInput);
    const onNameInputChange = (0,events/* useInputChange */.Xy)((e)=>{
        setRawNameInput(e.currentTarget.value);
    }, []);
    const tryAdd = (0,callback/* useAsyncUniqueCallback */.T)(async ()=>{
        return await result/* Result */.x.unthrow(async (t)=>{
            if (!defNameInput) return new result_err/* Err */.U(new result_errors/* Panic */.F5());
            const device = await ledger/* Ledger.USB.tryConnect */.P.vB.tryConnect().then((r)=>r.throw(t));
            const { address } = await ledger/* Ledger.Ethereum.tryGetAddress */.P.kJ.tryGetAddress(device, "44'/60'/0'/0/0").then((r)=>r.throw(t));
            const seed = {
                type: "ledger",
                uuid,
                name: defNameInput,
                color,
                emoji,
                address
            };
            await background.tryRequest({
                method: "brume_createSeed",
                params: [
                    seed
                ]
            }).then((r)=>r.throw(t).throw(t));
            close();
            return ok.Ok.void();
        }).then(results/* Results */.u.logAndAlert);
    }, [
        defNameInput,
        uuid,
        color,
        emoji,
        background,
        close
    ]);
    const NameInput = /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "flex items-stretch gap-2",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "shrink-0",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(avatar/* WalletAvatar */.G, {
                    className: "size-12 text-2xl",
                    colorIndex: color,
                    emoji: emoji
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)(input/* Input.Contrast */.I.mn, {
                className: "w-full",
                placeholder: "Enter a name",
                value: rawNameInput,
                onChange: onNameInputChange
            })
        ]
    });
    const canAdd = (0,react.useMemo)(()=>{
        if (!defNameInput) return false;
        return true;
    }, [
        defNameInput
    ]);
    const AddButton = /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.Gradient */.z.ph, {
        className: "flex-1 whitespace-nowrap po-md",
        colorIndex: color,
        disabled: !canAdd,
        onClick: tryAdd.run,
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsx)(PlusIcon/* default */.Z, {
                    className: "size-5"
                }),
                "Add"
            ]
        })
    });
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Dialog */.Vq.Title, {
                close: close,
                children: "New seed"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-2"
            }),
            NameInput,
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-8"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "flex items-center flex-wrap-reverse gap-2",
                children: AddButton
            })
        ]
    });
}

// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/KeyIcon.js
var KeyIcon = __webpack_require__(9878);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/LockClosedIcon.js
var LockClosedIcon = __webpack_require__(6186);
// EXTERNAL MODULE: ./src/libs/react/memo.ts + 1 modules
var memo = __webpack_require__(2387);
// EXTERNAL MODULE: ./src/libs/ui/textarea.tsx + 2 modules
var ui_textarea = __webpack_require__(9722);
// EXTERNAL MODULE: ./src/libs/webauthn/webauthn.ts
var webauthn = __webpack_require__(6177);
// EXTERNAL MODULE: ./node_modules/@hazae41/base64/dist/esm/src/mods/base64/adapter.mjs
var adapter = __webpack_require__(9467);
// EXTERNAL MODULE: ./node_modules/@hazae41/bytes/dist/esm/mods/bytes/bytes.mjs + 3 modules
var bytes = __webpack_require__(1694);
// EXTERNAL MODULE: ./node_modules/@scure/bip39/esm/index.js
var esm = __webpack_require__(4857);
// EXTERNAL MODULE: ./node_modules/@scure/bip39/esm/wordlists/english.js
var english = __webpack_require__(5957);
;// CONCATENATED MODULE: ./src/mods/foreground/entities/seeds/all/create/standalone.tsx

var __addDisposableResource = undefined && undefined.__addDisposableResource || function(env, value, async) {
    if (value !== null && value !== void 0) {
        if (typeof value !== "object" && typeof value !== "function") throw new TypeError("Object expected.");
        var dispose;
        if (async) {
            if (!Symbol.asyncDispose) throw new TypeError("Symbol.asyncDispose is not defined.");
            dispose = value[Symbol.asyncDispose];
        }
        if (dispose === void 0) {
            if (!Symbol.dispose) throw new TypeError("Symbol.dispose is not defined.");
            dispose = value[Symbol.dispose];
        }
        if (typeof dispose !== "function") throw new TypeError("Object not disposable.");
        env.stack.push({
            value: value,
            dispose: dispose,
            async: async
        });
    } else if (async) {
        env.stack.push({
            async: true
        });
    }
    return value;
};
var __disposeResources = undefined && undefined.__disposeResources || function(SuppressedError1) {
    return function(env) {
        function fail(e) {
            env.error = env.hasError ? new SuppressedError1(e, env.error, "An error was suppressed during disposal.") : e;
            env.hasError = true;
        }
        function next() {
            while(env.stack.length){
                var rec = env.stack.pop();
                try {
                    var result = rec.dispose && rec.dispose.call(rec.value);
                    if (rec.async) return Promise.resolve(result).then(next, function(e) {
                        fail(e);
                        return next();
                    });
                } catch (e) {
                    fail(e);
                }
            }
            if (env.hasError) throw env.error;
        }
        return next();
    };
}(typeof SuppressedError === "function" ? SuppressedError : function(error, suppressed, message) {
    var e = new Error(message);
    return e.name = "SuppressedError", e.error = error, e.suppressed = suppressed, e;
});






















function StandaloneSeedCreatorDialog(props) {
    const close = (0,dialog/* useCloseContext */.gX)().unwrap();
    const background = (0,context/* useBackgroundContext */.D_)().unwrap();
    const uuid = (0,ref/* useConstant */.hS)(()=>crypto.randomUUID());
    const modhash = (0,modhash_modhash/* useModhash */.jR)(uuid);
    const color = colors/* Colors */.w.mod(modhash);
    const emoji = emojis/* Emojis */.A.get(modhash);
    const [rawNameInput = "", setRawNameInput] = (0,react.useState)();
    const defNameInput = (0,react.useDeferredValue)(rawNameInput);
    const onNameInputChange = (0,events/* useInputChange */.Xy)((e)=>{
        setRawNameInput(e.currentTarget.value);
    }, []);
    const [rawPhraseInput = "", setRawPhraseInput] = (0,react.useState)();
    const defPhraseInput = (0,react.useDeferredValue)(rawPhraseInput);
    const onInputChange = (0,events/* useTextAreaChange */.aN)((e)=>{
        setRawPhraseInput(e.currentTarget.value);
    }, []);
    const doGenerate12 = (0,callback/* useAsyncUniqueCallback */.T)(async ()=>{
        setRawPhraseInput((0,esm/* generateMnemonic */.OF)(english/* wordlist */.U, 128));
    }, []);
    const doGenerate24 = (0,callback/* useAsyncUniqueCallback */.T)(async ()=>{
        setRawPhraseInput((0,esm/* generateMnemonic */.OF)(english/* wordlist */.U, 256));
    }, []);
    const tryAddUnauthenticated = (0,callback/* useAsyncUniqueCallback */.T)(async ()=>{
        return await result/* Result */.x.unthrow(async (t)=>{
            if (!defNameInput) return new result_err/* Err */.U(new result_errors/* Panic */.F5());
            if (!defPhraseInput) return new result_err/* Err */.U(new result_errors/* Panic */.F5());
            if (!confirm("Did you backup your seed phrase?")) return ok.Ok.void();
            const seed = {
                type: "mnemonic",
                uuid,
                name: defNameInput,
                color,
                emoji,
                mnemonic: defPhraseInput
            };
            await background.tryRequest({
                method: "brume_createSeed",
                params: [
                    seed
                ]
            }).then((r)=>r.throw(t).throw(t));
            close();
            return ok.Ok.void();
        }).then(results/* Results */.u.logAndAlert);
    }, [
        defNameInput,
        defPhraseInput,
        uuid,
        color,
        emoji,
        background,
        close
    ]);
    const triedEncryptedPhrase = (0,memo/* useAsyncReplaceMemo */.EY)(async ()=>{
        return await result/* Result */.x.unthrow(async (t)=>{
            if (!defNameInput) return new result_err/* Err */.U(new result_errors/* Panic */.F5());
            if (!defPhraseInput) return new result_err/* Err */.U(new result_errors/* Panic */.F5());
            try {
                const entropyBytes = (0,esm/* mnemonicToEntropy */.oy)(defPhraseInput, english/* wordlist */.U);
                const entropyBase64 = adapter/* get */.U().tryEncodePadded(entropyBytes).throw(t);
                const [ivBase64, cipherBase64] = await background.tryRequest({
                    method: "brume_encrypt",
                    params: [
                        entropyBase64
                    ]
                }).then((r)=>r.throw(t).throw(t));
                return new ok.Ok([
                    ivBase64,
                    cipherBase64
                ]);
            } catch (e) {
                return new result_err/* Err */.U(new result_errors/* Panic */.F5());
            }
        });
    }, [
        defNameInput,
        defPhraseInput,
        background
    ]);
    const [id, setId] = (0,react.useState)();
    (0,react.useEffect)(()=>{
        setId(undefined);
    }, [
        defPhraseInput
    ]);
    const tryAddAuthenticated1 = (0,callback/* useAsyncUniqueCallback */.T)(async ()=>{
        return await result/* Result */.x.unthrow(async (t)=>{
            if (!defNameInput) return new result_err/* Err */.U(new result_errors/* Panic */.F5());
            if (!defPhraseInput) return new result_err/* Err */.U(new result_errors/* Panic */.F5());
            if (triedEncryptedPhrase == null) return new result_err/* Err */.U(new result_errors/* Panic */.F5());
            if (!confirm("Did you backup your seed phrase?")) return ok.Ok.void();
            const [_, cipherBase64] = triedEncryptedPhrase.throw(t);
            const cipher = adapter/* get */.U().tryDecodePadded(cipherBase64).throw(t).copyAndDispose();
            const id = await webauthn/* WebAuthnStorage */.g.tryCreate(defNameInput, cipher).then((r)=>r.throw(t));
            setId(id);
            return ok.Ok.void();
        }).then(results/* Results */.u.logAndAlert);
    }, [
        defNameInput,
        defPhraseInput,
        triedEncryptedPhrase,
        uuid,
        color,
        emoji,
        background
    ]);
    const tryAddAuthenticated2 = (0,callback/* useAsyncUniqueCallback */.T)(async ()=>{
        return await result/* Result */.x.unthrow(async (t)=>{
            const env_1 = {
                stack: [],
                error: void 0,
                hasError: false
            };
            try {
                if (!defNameInput) return new result_err/* Err */.U(new result_errors/* Panic */.F5());
                if (!defPhraseInput) return new result_err/* Err */.U(new result_errors/* Panic */.F5());
                if (id == null) return new result_err/* Err */.U(new result_errors/* Panic */.F5());
                if (triedEncryptedPhrase == null) return new result_err/* Err */.U(new result_errors/* Panic */.F5());
                const [ivBase64, cipherBase64] = triedEncryptedPhrase.throw(t);
                const cipherSlice = __addDisposableResource(env_1, adapter/* get */.U().tryDecodePadded(cipherBase64).throw(t), false);
                const cipherBytes2 = await webauthn/* WebAuthnStorage */.g.tryGet(id).then((r)=>r.throw(t));
                if (!bytes/* Bytes */.J.equals(cipherSlice.bytes, cipherBytes2)) return new result_err/* Err */.U(new webauthn/* WebAuthnStorageError */.$());
                const idBase64 = adapter/* get */.U().tryEncodePadded(id).throw(t);
                const mnemonic = {
                    ivBase64,
                    idBase64
                };
                const seed = {
                    type: "authMnemonic",
                    uuid,
                    name: defNameInput,
                    color,
                    emoji,
                    mnemonic
                };
                await background.tryRequest({
                    method: "brume_createSeed",
                    params: [
                        seed
                    ]
                }).then((r)=>r.throw(t).throw(t));
                close();
                return ok.Ok.void();
            } catch (e_1) {
                env_1.error = e_1;
                env_1.hasError = true;
            } finally{
                __disposeResources(env_1);
            }
        }).then(results/* Results */.u.logAndAlert);
    }, [
        defNameInput,
        defPhraseInput,
        id,
        triedEncryptedPhrase,
        uuid,
        color,
        emoji,
        background,
        close
    ]);
    const NameInput = /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "flex items-stretch gap-2",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "shrink-0",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(avatar/* WalletAvatar */.G, {
                    className: "size-12 text-2xl",
                    colorIndex: color,
                    emoji: emoji
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)(input/* Input.Contrast */.I.mn, {
                className: "w-full",
                placeholder: "Enter a name",
                value: rawNameInput,
                onChange: onNameInputChange
            })
        ]
    });
    const PhraseInput = /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_textarea/* Textarea.Contrast */.g.m, {
        className: "w-full resize-none",
        placeholder: "Enter your seed phrase",
        value: rawPhraseInput,
        onChange: onInputChange,
        rows: 4
    });
    const Generate12Button = /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.Contrast */.z.mn, {
        className: "flex-1 whitespace-nowrap po-md",
        onClick: doGenerate12.run,
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsx)(KeyIcon/* default */.Z, {
                    className: "size-5"
                }),
                "Generate 12 random words"
            ]
        })
    });
    const Generate24Button = /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.Gradient */.z.ph, {
        className: "flex-1 whitespace-nowrap po-md",
        colorIndex: color,
        onClick: doGenerate24.run,
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsx)(KeyIcon/* default */.Z, {
                    className: "size-5"
                }),
                "Generate 24 random words"
            ]
        })
    });
    const canAdd = (0,react.useMemo)(()=>{
        if (!defNameInput) return false;
        if (!(0,esm/* validateMnemonic */._I)(defPhraseInput, english/* wordlist */.U)) return false;
        return true;
    }, [
        defNameInput,
        defPhraseInput
    ]);
    const AddUnauthButton = /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.Contrast */.z.mn, {
        className: "flex-1 whitespace-nowrap po-md",
        disabled: !canAdd,
        onClick: tryAddUnauthenticated.run,
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsx)(PlusIcon/* default */.Z, {
                    className: "size-5"
                }),
                "Add without authentication"
            ]
        })
    });
    const AddAuthButton1 = /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.Gradient */.z.ph, {
        className: "flex-1 whitespace-nowrap po-md",
        colorIndex: color,
        disabled: !canAdd,
        onClick: tryAddAuthenticated1.run,
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsx)(LockClosedIcon/* default */.Z, {
                    className: "size-5"
                }),
                "Add with authentication"
            ]
        })
    });
    const AddAuthButton2 = /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.Gradient */.z.ph, {
        className: "flex-1 whitespace-nowrap po-md",
        colorIndex: color,
        disabled: !canAdd,
        onClick: tryAddAuthenticated2.run,
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsx)(LockClosedIcon/* default */.Z, {
                    className: "size-5"
                }),
                "Add with authentication (1/2)"
            ]
        })
    });
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Dialog */.Vq.Title, {
                close: close,
                children: "New seed"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-2"
            }),
            NameInput,
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-8"
            }),
            PhraseInput,
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "flex items-center flex-wrap-reverse gap-2",
                children: [
                    Generate12Button,
                    Generate24Button
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-8"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "flex items-center flex-wrap-reverse gap-2",
                children: [
                    AddUnauthButton,
                    id == null ? AddAuthButton1 : AddAuthButton2
                ]
            })
        ]
    });
}

;// CONCATENATED MODULE: ./src/mods/foreground/entities/seeds/all/create/index.tsx











function SeedCreatorDialog(props) {
    const close = (0,dialog/* useCloseContext */.gX)().unwrap();
    const { url } = (0,path_context/* usePathContext */.td)().unwrap();
    const background = (0,context/* useBackgroundContext */.D_)().unwrap();
    const [type, setType] = (0,react.useState)();
    const onLedgerClick = (0,react.useCallback)(async ()=>{
        return result/* Result */.x.unthrow(async (t)=>{
            if (location.pathname !== "/" && location.pathname !== "/index.html") {
                await background.tryRequest({
                    method: "brume_open",
                    params: [
                        url.pathname
                    ]
                }).then((r)=>r.throw(t).throw(t));
                return ok.Ok.void();
            }
            setType("ledger");
            return ok.Ok.void();
        }).then(results/* Results */.u.logAndAlert);
    }, [
        url,
        background
    ]);
    const onMnemonicClick = (0,react.useCallback)(()=>{
        setType("mnemonic");
    }, []);
    const onClose = (0,react.useCallback)(()=>{
        setType(undefined);
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            type === "mnemonic" && /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Dialog */.Vq, {
                close: onClose,
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(StandaloneSeedCreatorDialog, {})
            }),
            type === "ledger" && /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Dialog */.Vq, {
                close: onClose,
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(LedgerSeedCreatorDialog, {})
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Dialog */.Vq.Title, {
                close: close,
                children: "New seed"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-2"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "w-full flex items-center gap-2",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.Contrast */.z.mn, {
                        className: "flex-1 whitespace-nowrap p-4 rounded-xl",
                        onClick: onMnemonicClick,
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "".concat(ui_button/* Button.Shrinker */.z.Np.className, " flex-col"),
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)(DocumentTextIcon/* default */.Z, {
                                    className: "size-6"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                    children: "Mnemonic phrase"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.Contrast */.z.mn, {
                        className: "flex-1 whitespace-nowrap p-4 rounded-xl",
                        onClick: onLedgerClick,
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "".concat(ui_button/* Button.Shrinker */.z.Np.className, " flex-col"),
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)(SwatchIcon/* default */.Z, {
                                    className: "size-6"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                    children: "Ledger"
                                })
                            ]
                        })
                    })
                ]
            })
        ]
    });
}

;// CONCATENATED MODULE: ./src/mods/foreground/entities/seeds/all/page.tsx













function SeedsPage() {
    var _seedsQuery_data;
    const seedsQuery = (0,seeds_data/* useSeeds */.Eu)();
    const maybeSeeds = (_seedsQuery_data = seedsQuery.data) === null || _seedsQuery_data === void 0 ? void 0 : _seedsQuery_data.get();
    const creator = (0,handles_boolean/* useBooleanHandle */.x)(false);
    const onSeedClick = (0,react.useCallback)((seed)=>{
        path_context/* Paths */.nB.go("/seed/".concat(seed.uuid));
    }, []);
    const Body = /*#__PURE__*/ (0,jsx_runtime.jsx)(header/* PageBody */.xV, {
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(ClickableSeedGrid, {
            ok: onSeedClick,
            create: creator.enable,
            maybeSeeds: maybeSeeds
        })
    });
    const Header = /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(header/* UserPageHeader */.To, {
                title: "Seeds",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.Base */.z.XY, {
                    className: "size-8 hovered-or-clicked-or-focused:scale-105 !transition",
                    onClick: creator.enable,
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(PlusIcon/* default */.Z, {
                            className: "size-5"
                        })
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "po-md flex items-center",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "text-contrast",
                    children: "Seeds allow you to generate wallets from a single secret. You can import a seed from a mnemonic phrase or connect a hardware wallet."
                })
            })
        ]
    });
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(page/* Page */.T, {
        children: [
            creator.current && /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Dialog */.Vq, {
                close: creator.disable,
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(SeedCreatorDialog, {})
            }),
            Header,
            Body
        ]
    });
}
function ClickableSeedGrid(props) {
    const { ok, create, maybeSeeds } = props;
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "grid grow place-content-start gap-2 grid-cols-[repeat(auto-fill,minmax(10rem,1fr))]",
        children: [
            maybeSeeds === null || maybeSeeds === void 0 ? void 0 : maybeSeeds.map((seed)=>/*#__PURE__*/ (0,jsx_runtime.jsx)(SeedDataProvider, {
                    uuid: seed.uuid,
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)(ClickableSeedDataCard, {
                        ok: ok
                    })
                }, seed.uuid)),
            /*#__PURE__*/ (0,jsx_runtime.jsx)(NewSeedCard, {
                ok: create
            })
        ]
    });
}
function ClickableSeedDataCard(props) {
    const seed = useSeedDataContext();
    const { ok } = props;
    const onClick = (0,react.useCallback)(()=>{
        ok(seed);
    }, [
        ok,
        seed
    ]);
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
        className: "w-full hovered-or-clicked-or-focused:scale-105 !transition-transform",
        onClick: onClick,
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(SeedDataCard, {})
    });
}
function NewSeedCard(props) {
    const { ok } = props;
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("button", {
        className: "po-md w-full aspect-video rounded-xl flex gap-2 justify-center items-center border border-contrast border-dashed hovered-or-clicked-or-focused:scale-105 !transition-transform",
        onClick: ok,
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(PlusIcon/* default */.Z, {
                className: "size-5"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "font-medium",
                children: "New seed"
            })
        ]
    });
}

// EXTERNAL MODULE: ./src/libs/errors/errors.ts
var errors_errors = __webpack_require__(9071);
// EXTERNAL MODULE: ./src/mods/background/service_worker/entities/seeds/data.tsx
var entities_seeds_data = __webpack_require__(7254);
// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/types/zerohex/index.mjs
var zerohex = __webpack_require__(6113);
// EXTERNAL MODULE: ./node_modules/@hazae41/cubane/dist/esm/src/mods/types/address/index.mjs
var types_address = __webpack_require__(7657);
// EXTERNAL MODULE: ./node_modules/@noble/curves/esm/secp256k1.js + 5 modules
var secp256k1 = __webpack_require__(7835);
// EXTERNAL MODULE: ./node_modules/@scure/bip32/lib/esm/index.js + 15 modules
var lib_esm = __webpack_require__(1141);
// EXTERNAL MODULE: ./src/mods/foreground/entities/seeds/all/helpers.tsx + 1 modules
var helpers = __webpack_require__(7554);
;// CONCATENATED MODULE: ./src/mods/foreground/entities/wallets/all/create/seeded.tsx


























function SeededWalletCreatorDialog(props) {
    const close = (0,dialog/* useCloseContext */.gX)().unwrap();
    const background = (0,context/* useBackgroundContext */.D_)().unwrap();
    const seedData = useSeedDataContext();
    const uuid = (0,ref/* useConstant */.hS)(()=>crypto.randomUUID());
    const modhash = (0,modhash_modhash/* useModhash */.jR)(uuid);
    const color = colors/* Colors */.w.mod(modhash);
    const emoji = emojis/* Emojis */.A.get(modhash);
    const [rawNameInput = "", setRawNameInput] = (0,react.useState)();
    const defNameInput = (0,react.useDeferredValue)(rawNameInput);
    const onNameInputChange = (0,events/* useInputChange */.Xy)((e)=>{
        setRawNameInput(e.currentTarget.value);
    }, []);
    const [rawPathInput = "", setRawPathInput] = (0,react.useState)("m/44'/60'/0'/0/0");
    const defPathInput = (0,react.useDeferredValue)(rawPathInput);
    const onPathInputChange = (0,events/* useInputChange */.Xy)((e)=>{
        setRawPathInput(e.currentTarget.value);
    }, []);
    const [coin, setCoin] = (0,react.useState)("eth");
    const onCoinChange = (0,react.useCallback)((e)=>{
        setCoin(e.currentTarget.value);
    }, []);
    const [app, setApp] = (0,react.useState)("metamask");
    const onAppChange = (0,react.useCallback)((e)=>{
        setApp(e.currentTarget.value);
    }, []);
    const [rawIndexInput = "", setRawIndexInput] = (0,react.useState)("0");
    const defIndexInput = (0,react.useDeferredValue)(rawIndexInput);
    const onIndexInputChange = (0,events/* useInputChange */.Xy)((e)=>{
        setRawIndexInput(e.currentTarget.value);
    }, [
        coin,
        app
    ]);
    (0,react.useEffect)(()=>{
        if (coin === "custom") return setRawPathInput("m/44'/60'/0'/0/0");
        const rawCoin = coin === "eth" ? "60" : "61";
        if (app === "custom") return setRawPathInput("m/44'/".concat(rawCoin, "'/0'/0/0"));
        const rawInput = Number(defIndexInput).toFixed();
        if (app === "ledger") return setRawPathInput("m/44'/".concat(rawCoin, "'/").concat(rawInput, "'/0/0"));
        if (app === "metamask") return setRawPathInput("m/44'/".concat(rawCoin, "'/0'/0/").concat(rawInput));
    }, [
        coin,
        app,
        defIndexInput
    ]);
    const canAdd = (0,react.useMemo)(()=>{
        if (!defNameInput) return false;
        if (!defPathInput) return false;
        return true;
    }, [
        defNameInput,
        defPathInput
    ]);
    const tryAdd = (0,callback/* useAsyncUniqueCallback */.T)(async ()=>{
        return await result/* Result */.x.unthrow(async (t)=>{
            if (!defNameInput) return new result_err/* Err */.U(new result_errors/* Panic */.F5());
            if (seedData.type === "ledger") {
                const device = await ledger/* Ledger.USB.tryConnect */.P.vB.tryConnect().then((r)=>r.mapErrSync((cause)=>{
                        return new errors_errors/* UIError */.m("Could not connect to the device", {
                            cause
                        });
                    }).throw(t));
                const { address } = await ledger/* Ledger.Ethereum.tryGetAddress */.P.kJ.tryGetAddress(device, defPathInput.slice(2)).then((r)=>r.mapErrSync((cause)=>{
                        return new errors_errors/* UIError */.m("Could not get the address of the device", {
                            cause
                        });
                    }).throw(t));
                if (!zerohex/* ZeroHexString */.T.is(address)) return new result_err/* Err */.U(new errors_errors/* UIError */.m("Could not get the address of the device"));
                const seed = entities_seeds_data/* SeedRef */.M.from(seedData);
                const wallet = {
                    coin: "ethereum",
                    type: "seeded",
                    uuid,
                    name: defNameInput,
                    color,
                    emoji,
                    address,
                    seed,
                    path: defPathInput
                };
                await background.tryRequest({
                    method: "brume_createWallet",
                    params: [
                        wallet
                    ]
                }).then((r)=>r.mapErrSync((cause)=>{
                        return new errors_errors/* UIError */.m("Could not communicate with the backend", {
                            cause
                        });
                    }).throw(t).mapErrSync((cause)=>{
                        return new errors_errors/* UIError */.m("Could not create the wallet", {
                            cause
                        });
                    }).throw(t));
            } else {
                const instance = await helpers/* SeedInstance */.Gz.tryFrom(seedData, background).then((r)=>r.get());
                const mnemonic = await instance.tryGetMnemonic(background).then((r)=>r.mapErrSync((cause)=>{
                        return new errors_errors/* UIError */.m("Could not get mnemonic", {
                            cause
                        });
                    }).throw(t));
                const masterSeed = await result/* Result */.x.runAndDoubleWrap(async ()=>{
                    return await (0,esm/* mnemonicToSeed */.OI)(mnemonic);
                }).then((r)=>r.throw(t));
                const root = result/* Result */.x.runAndDoubleWrapSync(()=>{
                    return lib_esm/* HDKey */.B.fromMasterSeed(masterSeed);
                }).throw(t);
                const child = result/* Result */.x.runAndWrapSync(()=>{
                    return root.derive(defPathInput);
                }).mapErrSync((cause)=>{
                    return new errors_errors/* UIError */.m("Invalid derivation path", {
                        cause
                    });
                }).throw(t);
                const privateKeyBytes = option_option/* Option */.W.wrap(child.privateKey).ok().throw(t);
                const uncompressedPublicKeyBytes = secp256k1/* secp256k1 */.kA.getPublicKey(privateKeyBytes, false);
                const address = types_address/* Address */.k.compute(uncompressedPublicKeyBytes);
                const seed = entities_seeds_data/* SeedRef */.M.from(seedData);
                const wallet = {
                    coin: "ethereum",
                    type: "seeded",
                    uuid,
                    name: defNameInput,
                    color,
                    emoji,
                    address,
                    seed,
                    path: defPathInput
                };
                await background.tryRequest({
                    method: "brume_createWallet",
                    params: [
                        wallet
                    ]
                }).then((r)=>r.mapErrSync((cause)=>{
                        return new errors_errors/* UIError */.m("Could not communicate with the backend", {
                            cause
                        });
                    }).throw(t).mapErrSync((cause)=>{
                        return new errors_errors/* UIError */.m("Could not create the wallet", {
                            cause
                        });
                    }).throw(t));
            }
            close();
            return ok.Ok.void();
        }).then(results/* Results */.u.logAndAlert);
    }, [
        defNameInput,
        defPathInput,
        seedData,
        defPathInput,
        uuid,
        color,
        emoji,
        background,
        close
    ]);
    const NameInput = /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "flex items-stretch gap-2",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "shrink-0",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(avatar/* WalletAvatar */.G, {
                    className: "size-12 text-2xl",
                    colorIndex: color,
                    emoji: emoji
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)(input/* Input.Contrast */.I.mn, {
                className: "w-full",
                placeholder: "Enter a name",
                value: rawNameInput,
                onChange: onNameInputChange
            })
        ]
    });
    const PathInput = /*#__PURE__*/ (0,jsx_runtime.jsx)(input/* Input.Contrast */.I.mn, {
        className: "w-full",
        placeholder: "m/44'/60'/0'/0/0",
        value: rawPathInput,
        onChange: onPathInputChange
    });
    const IndexInput = /*#__PURE__*/ (0,jsx_runtime.jsx)(input/* Input.Contrast */.I.mn, {
        className: "w-full",
        placeholder: "0",
        type: "number",
        min: 0,
        value: rawIndexInput,
        onChange: onIndexInputChange
    });
    const AddButon = /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.Gradient */.z.ph, {
        className: "grow po-md",
        colorIndex: color,
        disabled: !defNameInput || !canAdd,
        onClick: tryAdd.run,
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsx)(PlusIcon/* default */.Z, {
                    className: "size-5"
                }),
                "Add"
            ]
        })
    });
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Dialog */.Vq.Title, {
                close: close,
                children: "New wallet"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-2"
            }),
            NameInput,
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-4"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "font-medium",
                children: "Choose an account type"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-2"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("select", {
                className: "",
                value: coin,
                onChange: onCoinChange,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("option", {
                        value: "eth",
                        children: "Ethereum"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("option", {
                        value: "etc",
                        children: "Ethereum Classic"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("option", {
                        value: "custom",
                        children: "Other"
                    })
                ]
            }),
            coin === "custom" && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-4"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "font-medium",
                        children: "Choose a derivation path"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-2"
                    }),
                    PathInput
                ]
            }),
            coin !== "custom" && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-2"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("select", {
                        value: app,
                        onChange: onAppChange,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("option", {
                                value: "metamask",
                                children: "MetaMask"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("option", {
                                value: "ledger",
                                children: "Ledger Live"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("option", {
                                value: "custom",
                                children: "Other"
                            })
                        ]
                    }),
                    app === "custom" && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "h-4"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "font-medium",
                                children: "Choose a derivation path"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "h-2"
                            }),
                            PathInput
                        ]
                    }),
                    app !== "custom" && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "h-4"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "font-medium",
                                children: "Choose an account index"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "h-2"
                            }),
                            IndexInput,
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "h-2"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "text-contrast",
                                children: [
                                    "Your derivation path will be ",
                                    rawPathInput
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-8"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "flex items-center flex-wrap-reverse gap-2",
                children: AddButon
            })
        ]
    });
}

// EXTERNAL MODULE: ./src/mods/foreground/entities/wallets/all/page.tsx
var all_page = __webpack_require__(882);
// EXTERNAL MODULE: ./src/mods/foreground/entities/wallets/data.ts
var wallets_data = __webpack_require__(9031);
;// CONCATENATED MODULE: ./src/mods/foreground/entities/seeds/page.tsx
/* eslint-disable @next/next/no-img-element */ 











function SeedPage(props) {
    const { uuid } = props;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(SeedDataProvider, {
        uuid: uuid,
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(SeedDataPage, {})
    });
}
function SeedDataPage() {
    var _walletsQuery_data;
    const seed = useSeedDataContext();
    const walletsQuery = (0,wallets_data/* useWalletsBySeed */.QB)(seed.uuid);
    const maybeWallets = (_walletsQuery_data = walletsQuery.data) === null || _walletsQuery_data === void 0 ? void 0 : _walletsQuery_data.get();
    const creator = (0,handles_boolean/* useBooleanHandle */.x)(false);
    const onBackClick = (0,react.useCallback)(()=>{
        path_context/* Paths */.nB.go("/seeds");
    }, []);
    const onWalletClick = (0,react.useCallback)((wallet)=>{
        path_context/* Paths */.nB.go("/wallet/".concat(wallet.uuid));
    }, []);
    const Header = /*#__PURE__*/ (0,jsx_runtime.jsx)(header/* UserPageHeader */.To, {
        title: "Seed",
        back: onBackClick
    });
    const Card = /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
        className: "p-4 flex justify-center",
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
            className: "w-full max-w-sm",
            children: /*#__PURE__*/ (0,jsx_runtime.jsx)(SeedDataCard, {})
        })
    });
    const Body = /*#__PURE__*/ (0,jsx_runtime.jsx)(header/* PageBody */.xV, {
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(all_page/* ClickableWalletGrid */.oS, {
            ok: onWalletClick,
            create: creator.enable,
            wallets: maybeWallets
        })
    });
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(page/* Page */.T, {
        children: [
            creator.current && /*#__PURE__*/ (0,jsx_runtime.jsx)(dialog/* Dialog */.Vq, {
                close: creator.disable,
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(SeededWalletCreatorDialog, {})
            }),
            Header,
            Card,
            Body
        ]
    });
}

// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/EllipsisVerticalIcon.js
var EllipsisVerticalIcon = __webpack_require__(787);
// EXTERNAL MODULE: ./src/mods/foreground/entities/sessions/data.ts + 1 modules
var sessions_data = __webpack_require__(5830);
;// CONCATENATED MODULE: ./src/mods/background/service_worker/entities/sessions/status/data.ts

var Status;
(function(Status) {
    function key(id) {
        return "session/status/v4/".concat(id);
    }
    Status.key = key;
    function schema(id) {
        return (0,query/* createQuery */.rP)({
            key: key(id)
        });
    }
    Status.schema = schema;
})(Status || (Status = {}));

;// CONCATENATED MODULE: ./src/mods/foreground/entities/sessions/status/data.ts




function getStatus(id, storage) {
    if (id == null) return undefined;
    return (0,query/* createQuery */.rP)({
        key: Status.key(id),
        storage
    });
}
function useStatus(id) {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(getStatus, [
        id,
        storage
    ]);
    (0,storage_storage/* useSubscribe */.Q)(query, storage);
    return query;
}

;// CONCATENATED MODULE: ./src/mods/foreground/entities/sessions/all/data.ts



function getPersistentSessions(storage) {
    return (0,query/* createQuery */.rP)({
        key: "persistentSessions/v2",
        storage
    });
}
function usePersistentSessions() {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(getPersistentSessions, [
        storage
    ]);
    (0,storage_storage/* useSubscribe */.Q)(query, storage);
    return query;
}
function getTemporarySessions(storage) {
    return (0,query/* createQuery */.rP)({
        key: "temporarySessions/v2",
        storage
    });
}
function useTemporarySessions() {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(getTemporarySessions, [
        storage
    ]);
    (0,storage_storage/* useSubscribe */.Q)(query, storage);
    return query;
}

;// CONCATENATED MODULE: ./src/mods/foreground/entities/sessions/all/page.tsx
/* eslint-disable @next/next/no-img-element */ 
















function SessionsPage() {
    var _tempSessionsQuery_data, _persSessionsQuery_data;
    const background = (0,context/* useBackgroundContext */.D_)().unwrap();
    const tempSessionsQuery = useTemporarySessions();
    const maybeTempSessions = (_tempSessionsQuery_data = tempSessionsQuery.data) === null || _tempSessionsQuery_data === void 0 ? void 0 : _tempSessionsQuery_data.get();
    const persSessionsQuery = usePersistentSessions();
    const maybePersSessions = (_persSessionsQuery_data = persSessionsQuery.data) === null || _persSessionsQuery_data === void 0 ? void 0 : _persSessionsQuery_data.get();
    const length = (0,react.useMemo)(()=>{
        const temp = (maybeTempSessions === null || maybeTempSessions === void 0 ? void 0 : maybeTempSessions.length) || 0;
        const pers = (maybePersSessions === null || maybePersSessions === void 0 ? void 0 : maybePersSessions.length) || 0;
        return temp + pers;
    }, [
        maybeTempSessions,
        maybePersSessions
    ]);
    const tryDisconnectAll = (0,callback/* useAsyncUniqueCallback */.T)(async ()=>{
        return await result/* Result */.x.unthrow(async (t)=>{
            if (!confirm("Do you want to disconnect all sessions?")) return ok.Ok.void();
            for (const session of option_option/* Option */.W.wrap(maybeTempSessions).unwrapOr([]))await background.tryRequest({
                method: "brume_disconnect",
                params: [
                    session.id
                ]
            }).then((r)=>r.throw(t).throw(t));
            for (const session of option_option/* Option */.W.wrap(maybePersSessions).unwrapOr([]))await background.tryRequest({
                method: "brume_disconnect",
                params: [
                    session.id
                ]
            }).then((r)=>r.throw(t).throw(t));
            return ok.Ok.void();
        }).then(results/* Results */.u.logAndAlert);
    }, [
        background,
        maybePersSessions
    ]);
    const Body = /*#__PURE__*/ (0,jsx_runtime.jsx)(header/* PageBody */.xV, {
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "flex flex-col gap-2",
            children: [
                maybeTempSessions === null || maybeTempSessions === void 0 ? void 0 : maybeTempSessions.map((session)=>/*#__PURE__*/ (0,jsx_runtime.jsx)(SessionRow, {
                        session: session
                    }, session.id)),
                maybePersSessions === null || maybePersSessions === void 0 ? void 0 : maybePersSessions.map((session)=>/*#__PURE__*/ (0,jsx_runtime.jsx)(SessionRow, {
                        session: session
                    }, session.id))
            ]
        })
    });
    const Header = /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(header/* UserPageHeader */.To, {
                title: "Sessions",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.Base */.z.XY, {
                    className: "size-8 hovered-or-clicked-or-focused:scale-105 !transition",
                    disabled: tryDisconnectAll.loading || !length,
                    onClick: tryDisconnectAll.run,
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(TrashIcon/* default */.Z, {
                            className: "size-5"
                        })
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "po-md flex items-center",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "text-contrast",
                    children: "Sessions allow you to connect to applications. These applications can then make requests for you to approve."
                })
            })
        ]
    });
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(page/* Page */.T, {
        children: [
            Header,
            Body
        ]
    });
}
function SessionRow(props) {
    var _sessionQuery_data, _originQuery_data, _statusQuery_data, _maybeOriginData_icons, _iconDatas_find;
    const background = (0,context/* useBackgroundContext */.D_)().unwrap();
    const sessionQuery = (0,sessions_data/* useSession */.k)(props.session.id);
    const maybeSessionData = (_sessionQuery_data = sessionQuery.data) === null || _sessionQuery_data === void 0 ? void 0 : _sessionQuery_data.get();
    const originQuery = useOrigin(maybeSessionData === null || maybeSessionData === void 0 ? void 0 : maybeSessionData.origin);
    const maybeOriginData = (_originQuery_data = originQuery.data) === null || _originQuery_data === void 0 ? void 0 : _originQuery_data.get();
    const statusQuery = useStatus(props.session.id);
    const maybeStatusData = (_statusQuery_data = statusQuery.data) === null || _statusQuery_data === void 0 ? void 0 : _statusQuery_data.get();
    const [iconDatas, setIconDatas] = (0,react.useState)([]);
    const onIconData = (0,react.useCallback)((param)=>{
        let [index, data] = param;
        setIconDatas((iconDatas)=>{
            iconDatas[index] = data;
            return [
                ...iconDatas
            ];
        });
    }, []);
    const tryDisconnect = (0,callback/* useAsyncUniqueCallback */.T)(async ()=>{
        return await result/* Result */.x.unthrow(async (t)=>{
            if (maybeSessionData == null) return ok.Ok.void();
            if (!confirm("Do you want to disconnect this session?")) return ok.Ok.void();
            await background.tryRequest({
                method: "brume_disconnect",
                params: [
                    maybeSessionData.id
                ]
            }).then((r)=>r.throw(t).throw(t));
            return ok.Ok.void();
        }).then(results/* Results */.u.logAndAlert);
    }, [
        background,
        maybeSessionData
    ]);
    if (maybeOriginData == null) return null;
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        role: "button",
        className: "po-md rounded-xl flex items-center gap-4",
        onClick: tryDisconnect.run,
        children: [
            (_maybeOriginData_icons = maybeOriginData.icons) === null || _maybeOriginData_icons === void 0 ? void 0 : _maybeOriginData_icons.map((x, i)=>/*#__PURE__*/ (0,jsx_runtime.jsx)(page_IndexedBlobbyLoader, {
                    index: i,
                    id: x.id,
                    ok: onIconData
                }, x.id)),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "relative shrink-0",
                children: [
                    (()=>{
                        if (maybeStatusData == null) return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "absolute top-0 -right-2 bg-blue-400 rounded-full w-2 h-2"
                        });
                        if (maybeStatusData.error == null) return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "absolute top-0 -right-2 bg-green-400 rounded-full w-2 h-2"
                        });
                        return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "absolute top-0 -right-2 bg-red-400 rounded-full w-2 h-2"
                        });
                    })(),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(ImageWithFallback, {
                        className: "size-10",
                        alt: "icon",
                        src: (_iconDatas_find = iconDatas.find(Boolean)) === null || _iconDatas_find === void 0 ? void 0 : _iconDatas_find.data,
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(CubeTransparentIcon/* default */.Z, {
                            className: "size-10"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "grow",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "font-medium",
                        children: maybeOriginData.title
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "text-contrast",
                        children: maybeOriginData.origin
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button.Base */.z.XY, {
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)(EllipsisVerticalIcon/* default */.Z, {
                        className: "size-5"
                    })
                })
            })
        ]
    });
}
function page_IndexedBlobbyLoader(props) {
    const { index, id, ok } = props;
    const { data } = useBlobby(id);
    (0,react.useEffect)(()=>{
        ok([
            index,
            data === null || data === void 0 ? void 0 : data.inner
        ]);
    }, [
        index,
        data,
        ok
    ]);
    return null;
}

// EXTERNAL MODULE: ./src/libs/ui/anchor/anchor.tsx
var anchor_anchor = __webpack_require__(6826);
// EXTERNAL MODULE: ./node_modules/@hazae41/glacier/dist/esm/mods/fetched/data.mjs
var fetched_data = __webpack_require__(8123);
// EXTERNAL MODULE: ./node_modules/@hazae41/option/dist/esm/mods/option/some.mjs
var some = __webpack_require__(8862);
;// CONCATENATED MODULE: ./src/mods/background/service_worker/entities/settings/data.ts

var BgSettings;
(function(BgSettings) {
    let Logs;
    (function(Logs) {
        Logs.key = "settings/logs";
        function schema(storage) {
            return (0,query/* createQuery */.rP)({
                key: Logs.key,
                storage
            });
        }
        Logs.schema = schema;
    })(Logs = BgSettings.Logs || (BgSettings.Logs = {}));
})(BgSettings || (BgSettings = {}));

;// CONCATENATED MODULE: ./src/mods/foreground/entities/settings/data.ts




var FgSettings;
(function(FgSettings) {
    let Logs;
    (function(Logs) {
        Logs.key = BgSettings.Logs.key;
        function schema(storage) {
            return (0,query/* createQuery */.rP)({
                key: Logs.key,
                storage
            });
        }
        Logs.schema = schema;
    })(Logs = FgSettings.Logs || (FgSettings.Logs = {}));
})(FgSettings || (FgSettings = {}));
function useLogs() {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(FgSettings.Logs.schema, [
        storage
    ]);
    (0,storage_storage/* useSubscribe */.Q)(query, storage);
    return query;
}

;// CONCATENATED MODULE: ./src/mods/foreground/entities/settings/page.tsx








function SettingsPage() {
    var _logs_real;
    const logs = useLogs();
    const onLogsChange = (0,events/* useInputChange */.Xy)((e)=>{
        const checked = e.currentTarget.checked;
        logs.mutate(()=>new some/* Some */.b(new fetched_data/* Data */.V(checked)));
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(page/* Page */.T, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(header/* UserPageHeader */.To, {
                title: "Settings"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(header/* PageBody */.xV, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "po-md text-sm text-contrast uppercase",
                        children: "Others"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("label", {
                        className: "po-md bg-contrast rounded-xl flex items-center justify-between",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "",
                                children: "Enable logs"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("input", {
                                className: "",
                                type: "checkbox",
                                checked: Boolean((_logs_real = logs.real) === null || _logs_real === void 0 ? void 0 : _logs_real.current.get()),
                                onChange: onLogsChange
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "po-md text-sm text-contrast",
                        children: [
                            "All your requests will be seen on ",
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(anchor_anchor/* TextAnchor */.U, {
                                href: "https://logs.brume.money"
                            })
                        ]
                    })
                ]
            })
        ]
    });
}

// EXTERNAL MODULE: ./node_modules/@swc/helpers/esm/_class_private_field_get.js + 1 modules
var _class_private_field_get = __webpack_require__(7121);
// EXTERNAL MODULE: ./node_modules/@swc/helpers/esm/_class_private_field_init.js
var _class_private_field_init = __webpack_require__(9886);
// EXTERNAL MODULE: ./node_modules/@swc/helpers/esm/_class_private_field_set.js + 1 modules
var _class_private_field_set = __webpack_require__(5321);
;// CONCATENATED MODULE: ./src/mods/background/service_worker/entities/snaps/data.ts





var _a;




var SnapRef;
(function(SnapRef) {
    function create(uuid) {
        return {
            ref: true,
            uuid
        };
    }
    SnapRef.create = create;
    function from(snap) {
        return create(snap.uuid);
    }
    SnapRef.from = from;
})(SnapRef || (SnapRef = {}));
var BgSnap;
(function(BgSnap) {
    let All;
    (function(All) {
        All.key = "snaps";
        function schema(storage) {
            return (0,query/* createQuery */.rP)({
                key: All.key,
                storage
            });
        }
        All.schema = schema;
    })(All = BgSnap.All || (BgSnap.All = {}));
    function key(uuid) {
        return "snap/".concat(uuid);
    }
    BgSnap.key = key;
    function schema(id, storage) {
        return (0,query/* createQuery */.rP)({
            key: key(id),
            storage
        });
    }
    BgSnap.schema = schema;
})(BgSnap || (BgSnap = {}));
var _class = /*#__PURE__*/ new WeakMap();
class SnapError extends Error {
    static from(cause) {
        return new _a({
            cause
        });
    }
    constructor(options){
        super("Could not execute", options);
        (0,_class_private_field_init._)(this, _class, {
            writable: true,
            value: void 0
        });
        (0,_class_private_field_set._)(this, _class, _a);
        this.name = (0,_class_private_field_get._)(this, _class).name;
    }
}
_a = SnapError;
class RustSnapFactory {
    create(context) {
        const snap = new this.snap(context);
        return new RustSnapWrapper(snap);
    }
    constructor(bytecode){
        this.bytecode = bytecode;
        this.snap = createSnap(this.bytecode);
    }
}
var _onRequest = /*#__PURE__*/ new WeakSet();
class RustSnapContext {
    request(req) {
        const request = JSON.parse(req);
        const response = Result.runAndWrap(()=>{
            return _class_private_method_get(this, _onRequest, onRequest).call(this, request);
        }).then((r)=>RpcResponse.rewrap(null, r));
        return JSON.stringify(response);
    }
    constructor(){
        _class_private_method_init(this, _onRequest);
    }
}
function onRequest(request) {
    if (request.method === "log") {
        console.log(...request.params);
        return;
    }
    if (request.method === "brume_addChain") {
    // const [logo] = (request as RpcRequestInit<[]>).params
    }
    throw new Error("Unknown method ".concat(request.method));
}
class RustSnapWrapper {
    request(request) {
        try {
            const req = JSON.stringify(request);
            const ret = this.inner.on_request(req);
            const res = JSON.parse(ret);
            return new RpcOk(request.id, res);
        } catch (e) {
            return new RpcErr(request.id, RpcError.rewrap(e));
        }
    }
    constructor(/**
     * The WebAssembly module
     */ inner){
        this.inner = inner;
    }
}

;// CONCATENATED MODULE: ./src/mods/foreground/entities/snaps/data.tsx




var FgSnap;
(function(FgSnap) {
    let All;
    (function(All) {
        All.key = BgSnap.All.key;
        function schema(storage) {
            return (0,query/* createQuery */.rP)({
                key: All.key,
                storage
            });
        }
        All.schema = schema;
    })(All = FgSnap.All || (FgSnap.All = {}));
    FgSnap.key = BgSnap.key;
    function schema(uuid, storage) {
        if (uuid == null) return;
        return (0,query/* createQuery */.rP)({
            key: FgSnap.key(uuid),
            storage
        });
    }
    FgSnap.schema = schema;
})(FgSnap || (FgSnap = {}));
function useSnap(uuid) {
    const storage = useUserStorageContext().unwrap();
    const query = useQuery(FgSnap.schema, [
        uuid,
        storage
    ]);
    useSubscribe(query, storage);
    return query;
}
function useSnaps() {
    const storage = (0,user/* useUserStorageContext */.v6)().unwrap();
    const query = (0,simple/* useQuery */.aM)(FgSnap.All.schema, [
        storage
    ]);
    (0,storage_storage/* useSubscribe */.Q)(query, storage);
    return query;
}

;// CONCATENATED MODULE: ./src/mods/foreground/entities/snaps/all/page.tsx







function SnapsPage() {
    const snapsQuery = useSnaps();
    const onAdd = (0,react.useCallback)(()=>{
        snapsQuery;
    }, []);
    const Body = /*#__PURE__*/ (0,jsx_runtime.jsx)(header/* PageBody */.xV, {
        children: "Coming soon..."
    });
    const Header = /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(header/* UserPageHeader */.To, {
                title: "Plugins",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                    className: "".concat(ui_button/* Button.Base */.z.XY.className, " size-8 hovered-or-clicked-or-focused:scale-105 !transition"),
                    onClick: onAdd,
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "".concat(ui_button/* Button.Shrinker */.z.Np.className),
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(PlusIcon/* default */.Z, {
                            className: "size-5"
                        })
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "po-md flex items-center",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "text-contrast",
                    children: "Plugins allow you to securely extend the features. These features can then be used by applications you connect to."
                })
            })
        ]
    });
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(page/* Page */.T, {
        children: [
            Header,
            Body
        ]
    });
}

// EXTERNAL MODULE: ./node_modules/@nuintun/qrcode/esm/qrcode/decoder/Reader.js + 15 modules
var Reader = __webpack_require__(845);
// EXTERNAL MODULE: ./src/mods/foreground/entities/wallets/context.tsx
var wallets_context = __webpack_require__(5807);
;// CONCATENATED MODULE: ./src/mods/foreground/entities/wallets/camera/page.tsx
/* eslint-disable @next/next/no-img-element */ 








function WalletCameraPage(props) {
    const { uuid } = props;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(wallets_context/* WalletDataProvider */.lp, {
        uuid: uuid,
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(WalletDataCameraPage, {})
    });
}
function WalletDataCameraPage() {
    const wallet = (0,wallets_context/* useWalletDataContext */.zI)().unwrap();
    const background = (0,context/* useBackgroundContext */.D_)().unwrap();
    const mounted = (0,react.useRef)(true);
    (0,react.useEffect)(()=>()=>{
            mounted.current = false;
        }, []);
    const video = (0,react.useRef)(null);
    const sight = (0,react.useRef)(null);
    const [text, setText] = (0,react.useState)();
    const onStream = (0,react.useCallback)((stream)=>{
        if (!video.current) return;
        if (!sight.current) return;
        video.current.addEventListener("canplay", ()=>{
            if (!video.current) return;
            if (!sight.current) return;
            const yratio = video.current.videoHeight / video.current.clientHeight;
            const xratio = video.current.videoWidth / video.current.clientWidth;
            const ratio = Math.min(yratio, xratio);
            const cw = video.current.clientWidth * ratio;
            const ch = video.current.clientHeight * ratio;
            const cx = video.current.videoWidth / 2 - cw / 2;
            const cy = video.current.videoHeight / 2 - ch / 2;
            const sx = cx + sight.current.offsetLeft * ratio;
            const sy = cy + sight.current.offsetTop * ratio;
            const sw = sight.current.offsetWidth * ratio;
            const sh = sight.current.offsetHeight * ratio;
            const canvas = document.createElement("canvas");
            canvas.width = sw;
            canvas.height = sh;
            const canvasCtx = canvas.getContext("2d");
            if (!canvasCtx) return;
            function loop() {
                if (!mounted.current) return;
                if (!video.current) return;
                if (!sight.current) return;
                if (!canvasCtx) return;
                canvasCtx.drawImage(video.current, sx, sy, sw, sh, 0, 0, canvas.width, canvas.height);
                const image = canvasCtx.getImageData(0, 0, sw, sh);
                let result = null;
                try {
                    result = new Reader/* Decoder */.h().decode(image.data, canvas.width, canvas.height);
                } catch (e) {}
                if (result != null) setText(result.data);
                setTimeout(loop, 1000);
            }
            setTimeout(loop, 1000);
        });
        video.current.srcObject = stream;
        video.current.play();
    }, []);
    (0,react.useEffect)(()=>{
        const video = {
            width: {
                ideal: 1080
            },
            height: {
                ideal: 1080
            },
            facingMode: {
                exact: "environment"
            }
        };
        navigator.mediaDevices.getUserMedia({
            video
        }).then(onStream).catch(errors_errors/* Errors */.D.logAndAlert);
    }, [
        onStream
    ]);
    const tryConnect = (0,callback/* useAsyncUniqueCallback */.T)(async (uri)=>{
        return await result/* Result */.x.unthrow(async (t)=>{
            alert("Connecting...");
            const metadata = await background.tryRequest({
                method: "brume_wc_connect",
                params: [
                    uri,
                    wallet.uuid
                ]
            }).then((r)=>r.throw(t).throw(t));
            alert("Connected to ".concat(metadata.name));
            return ok.Ok.void();
        }).then(results/* Results */.u.logAndAlert);
    }, [
        background,
        wallet
    ]);
    (0,react.useEffect)(()=>{
        if (text) tryConnect.run(text);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        text
    ]);
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(jsx_runtime.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "grow relative flex flex-col",
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "absolute w-full h-full flex flex-col items-center justify-center",
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)("img", {
                        className: "h-16 w-16",
                        src: "/assets/wc.svg",
                        alt: "WalletConnect"
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "absolute w-full h-full flex flex-col items-center justify-center",
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)("img", {
                        className: "h-64 w-64",
                        ref: sight,
                        src: "/assets/sight.svg",
                        alt: "sight"
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("video", {
                    className: "grow w-full object-cover",
                    ref: video,
                    playsInline: true,
                    muted: true
                })
            ]
        })
    });
}

// EXTERNAL MODULE: ./src/mods/foreground/entities/wallets/page.tsx + 34 modules
var wallets_page = __webpack_require__(7019);
// EXTERNAL MODULE: ./src/mods/foreground/entities/unknown/data.ts
var unknown_data = __webpack_require__(5234);
// EXTERNAL MODULE: ./src/mods/foreground/entities/users/context.tsx
var users_context = __webpack_require__(6676);
;// CONCATENATED MODULE: ./src/mods/foreground/home/page.tsx
/* eslint-disable @next/next/no-img-element */ 







function HomePage() {
    const userData = (0,users_context/* useUserContext */.SE)().unwrap();
    const background = (0,context/* useBackgroundContext */.D_)().unwrap();
    const totalPricedBalanceQuery = (0,unknown_data/* useTotalPricedBalance */.ZO)("usd");
    const totalPricedBalanceDisplay = (0,wallets_page/* useDisplayUsd */.iZ)(totalPricedBalanceQuery.current);
    (0,react.useEffect)(()=>{
        background.tryRequest({
            method: "brume_log"
        }).then((r)=>r.inspectErrSync(console.warn));
    }, [
        background
    ]);
    const [persisted, setPersisted] = (0,react.useState)();
    const getPersisted = (0,react.useCallback)(async ()=>{
        setPersisted(await navigator.storage.persist());
    }, []);
    (0,react.useEffect)(()=>{
        getPersisted();
        if (background.isExtension()) return;
        if (navigator.userAgent.toLowerCase().includes("firefox")) return;
        const t = setInterval(getPersisted, 1000);
        return ()=>clearTimeout(t);
    }, [
        background,
        getPersisted
    ]);
    const Body = /*#__PURE__*/ (0,jsx_runtime.jsxs)(header/* PageBody */.xV, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "text-center text-4xl font-medium",
                children: "Hi, ".concat(userData.name)
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-8"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "text-lg font-medium",
                children: "Total balance"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "text-2xl font-bold",
                children: totalPricedBalanceDisplay
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-4"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "po-md border border-contrast h-[300px] rounded-xl flex flex-col items-center justify-center",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("img", {
                        src: "/favicon.png",
                        alt: "logo",
                        className: "h-24 w-auto"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "",
                        children: "Coming soon..."
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "h-8"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "grow"
            }),
            persisted === false && background.isWebsite() && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "text-lg font-medium",
                        children: "Alerts"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-2"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "po-md border border-contrast rounded-xl",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("h3", {
                                className: "text-lg font-medium",
                                children: "Your storage is not persistent yet"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                                className: "text-contrast",
                                children: "Please add this website to your favorites or to your home screen in order to enable persistent storage"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "h-2"
                            })
                        ]
                    })
                ]
            })
        ]
    });
    const Header = /*#__PURE__*/ (0,jsx_runtime.jsx)(header/* UserPageHeader */.To, {
        title: "Home"
    });
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(page/* Page */.T, {
        children: [
            Header,
            Body
        ]
    });
}

;// CONCATENATED MODULE: ./src/mods/foreground/router/router.tsx













function Router() {
    const { url } = (0,path_context/* usePathContext */.td)().unwrap();
    let matches;
    if (url.pathname === "") return /*#__PURE__*/ (0,jsx_runtime.jsx)(HomePage, {});
    if (matches = url.pathname.match(/^\/$/)) return /*#__PURE__*/ (0,jsx_runtime.jsx)(HomePage, {});
    if (matches = url.pathname.match(/^\/wallets(\/)?$/)) return /*#__PURE__*/ (0,jsx_runtime.jsx)(all_page/* WalletsPage */.FU, {});
    if (matches = url.pathname.match(/^\/seeds(\/)?$/)) return /*#__PURE__*/ (0,jsx_runtime.jsx)(SeedsPage, {});
    if (matches = url.pathname.match(/^\/sessions(\/)?$/)) return /*#__PURE__*/ (0,jsx_runtime.jsx)(SessionsPage, {});
    if (matches = url.pathname.match(/^\/requests(\/)?$/)) return /*#__PURE__*/ (0,jsx_runtime.jsx)(RequestsPage, {});
    if (matches = url.pathname.match(/^\/plugins(\/)?$/)) return /*#__PURE__*/ (0,jsx_runtime.jsx)(SnapsPage, {});
    if (matches = url.pathname.match(/^\/wallet\/([^\/]+)(\/)?$/)) return /*#__PURE__*/ (0,jsx_runtime.jsx)(wallets_page/* WalletPage */.ds, {
        uuid: matches[1]
    });
    if (matches = url.pathname.match(/^\/wallet\/([^\/]+)\/camera(\/)?$/)) return /*#__PURE__*/ (0,jsx_runtime.jsx)(WalletCameraPage, {
        uuid: matches[1]
    });
    if (matches = url.pathname.match(/^\/seed\/([^\/]+)(\/)?$/)) return /*#__PURE__*/ (0,jsx_runtime.jsx)(SeedPage, {
        uuid: matches[1]
    });
    if (matches = url.pathname.match(/^\/settings(\/)?$/)) return /*#__PURE__*/ (0,jsx_runtime.jsx)(SettingsPage, {});
    if (matches = url.pathname.match(/^\/eth_requestAccounts(\/)?$/)) return /*#__PURE__*/ (0,jsx_runtime.jsx)(popup.WalletAndChainSelectPage, {});
    if (matches = url.pathname.match(/^\/eth_sendTransaction(\/)?$/)) return /*#__PURE__*/ (0,jsx_runtime.jsx)(popup.TransactPage, {});
    if (matches = url.pathname.match(/^\/wallet_switchEthereumChain(\/)?$/)) return /*#__PURE__*/ (0,jsx_runtime.jsx)(popup.SwitchPage, {});
    if (matches = url.pathname.match(/^\/personal_sign(\/)?$/)) return /*#__PURE__*/ (0,jsx_runtime.jsx)(popup.PersonalSignPage, {});
    if (matches = url.pathname.match(/^\/eth_signTypedData_v4(\/)?$/)) return /*#__PURE__*/ (0,jsx_runtime.jsx)(popup.TypedSignPage, {});
    if (matches = url.pathname.match(/^\/done(\/)?$/)) return /*#__PURE__*/ (0,jsx_runtime.jsx)(popup.DonePage, {});
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(jsx_runtime.Fragment, {
        children: "Error 404"
    });
}


/***/ })

}]);