(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[405],{

/***/ 9494:
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


    (window.__NEXT_P = window.__NEXT_P || []).push([
      "/",
      function () {
        return __webpack_require__(4199);
      }
    ]);
    if(false) {}
  

/***/ }),

/***/ 4199:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ Index; }
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _mods_foreground_background_context__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5855);
/* harmony import */ var _mods_foreground_entities_users_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1677);
/* harmony import */ var _mods_foreground_overlay_bottom__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9403);
/* harmony import */ var _mods_foreground_overlay_overlay__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(938);
/* harmony import */ var _mods_foreground_router_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5310);






function Index() {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("main", {
        id: "main",
        className: "p-safe grow w-full flex flex-col overflow-hidden",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mods_foreground_overlay_overlay__WEBPACK_IMPORTED_MODULE_4__/* .Overlay */ .aV, {
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mods_foreground_background_context__WEBPACK_IMPORTED_MODULE_1__/* .BackgroundGuard */ .bI, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mods_foreground_entities_users_context__WEBPACK_IMPORTED_MODULE_2__/* .UserGuard */ .ds, {
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                            className: "grow w-full flex flex-col overflow-y-scroll",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                className: "grow w-full m-auto max-w-3xl flex flex-col",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mods_foreground_router_router__WEBPACK_IMPORTED_MODULE_5__/* .Router */ .F, {})
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mods_foreground_overlay_bottom__WEBPACK_IMPORTED_MODULE_3__/* .Bottom */ .z, {})
                    ]
                })
            })
        })
    });
}


/***/ })

},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
/******/ __webpack_require__.O(0, [67,801,376,570,250,751,774,888,179], function() { return __webpack_exec__(9494); });
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ _N_E = __webpack_exports__;
/******/ }
]);