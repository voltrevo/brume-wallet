/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
var __webpack_exports__ = {};

;// CONCATENATED MODULE: ./node_modules/@hazae41/future/dist/esm/mods/future/future.mjs
class Future {
    #resolve;
    #reject;
    promise;
    /**
     * Just like a Promise but you can manually resolve or reject it
     */
    constructor() {
        this.promise = new Promise((subresolve, subreject) => {
            this.#resolve = subresolve;
            this.#reject = subreject;
        });
    }
    get resolve() {
        return this.#resolve;
    }
    get reject() {
        return this.#reject;
    }
}


//# sourceMappingURL=future.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/result/dist/esm/mods/debug/debug.mjs
var Debug;
(function (Debug) {
    Debug.debug = false;
})(Debug || (Debug = {}));


//# sourceMappingURL=debug.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/errors.mjs
class Unimplemented extends (/* unused pure expression or super */ null && (Error)) {
    #class = Unimplemented;
    name = this.#class.name;
}
class Panic extends Error {
    #class = Panic;
    name = this.#class.name;
    static from(cause) {
        return new Panic(undefined, { cause });
    }
    static fromAndThrow(cause) {
        throw Panic.from(cause);
    }
}
class errors_Catched extends Error {
    #class = errors_Catched;
    name = this.#class.name;
    static from(cause) {
        return new errors_Catched(undefined, { cause });
    }
    static fromAndThrow(cause) {
        throw errors_Catched.from(cause);
    }
}


//# sourceMappingURL=errors.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/err.mjs




class err_Err {
    #inner;
    #timeout;
    /**
     * A failure
     * @param inner
     */
    constructor(inner) {
        this.#inner = inner;
        if (!Debug.debug)
            return;
        const error = new Panic(`Unhandled result`, { cause: this });
        this.#timeout = setTimeout(async () => { throw error; }, 1000);
    }
    /**
     * Create an empty `Err`
     * @returns `Err(void)`
     */
    static void() {
        return new err_Err(undefined);
    }
    /**
     * Create an `Err`
     * @param inner
     * @returns `Err(inner)`
     */
    static new(inner) {
        return new err_Err(inner);
    }
    /**
     * Create an `Err` with an `Error` inside
     * @param message
     * @param options
     * @returns `Err<Error>`
     */
    static error(message, options) {
        return new err_Err(new Error(message, options));
    }
    get inner() {
        return this.#inner;
    }
    /**
     * Set this result as handled
     */
    ignore() {
        if (!this.#timeout)
            return this;
        clearTimeout(this.#timeout);
        this.#timeout = undefined;
        return this;
    }
    /**
     * Type guard for `Ok`
     * @returns `true` if `Ok`, `false` if `Err`
     */
    isOk() {
        return false;
    }
    /**
     * Returns true if the result is `Ok` and the value inside of it matches a predicate
     * @param okPredicate
     * @returns `true` if `Ok` and `await okPredicate(this.inner)`, `false` otherwise
     */
    async isOkAnd(okPredicate) {
        return false;
    }
    /**
     * Returns true if the result is `Ok` and the value inside of it matches a predicate
     * @param okPredicate
     * @returns `true` if `Ok` and `await okPredicate(this.inner)`, `false` otherwise
     */
    isOkAndSync(okPredicate) {
        return false;
    }
    /**
     * Type guard for `Err`
     * @returns `true` if `Err`, `false` if `Ok`
     */
    isErr() {
        return true;
    }
    /**
     * Returns true if the result is `Err` and the value inside of it matches a predicate
     * @param errPredicate
     * @returns `true` if `Err` and `await errPredicate(this.inner)`, `false` otherwise
     */
    async isErrAnd(errPredicate) {
        return await errPredicate(this.inner);
    }
    /**
     * Returns true if the result is `Err` and the value inside of it matches a predicate
     * @param errPredicate
     * @returns `true` if `Err` and `await errPredicate(this.inner)`, `false` otherwise
     */
    isErrAndSync(errPredicate) {
        return errPredicate(this.inner);
    }
    /**
     * Compile-time safely get `this.inner`
     * @returns `this.inner`
     */
    get() {
        this.ignore();
        return this.inner;
    }
    /**
     * Transform `Result<T, E>` into `Option<T>`
     * @returns `Some(this.inner)` if `Ok`, `None` if `Err`
     */
    ok() {
        this.ignore();
        return new none_None();
    }
    /**
     * Transform `Result<T, E>` into `Option<E>`
     * @returns `Some(this.inner)` if `Err`, `None` if `Ok`
     */
    err() {
        this.ignore();
        return new some_Some(this.inner);
    }
    /**
     * Returns an iterator over the possibly contained value
     * @yields `this.inner` if `Ok`
     */
    *[Symbol.iterator]() {
        this.ignore();
        return;
    }
    /**
     * Transform `Result<T,E>` into `[T,E]`
     * @returns `[this.inner, undefined]` if `Ok`, `[undefined, this.inner]` if `Err`
     */
    split() {
        this.ignore();
        return [undefined, this.inner];
    }
    /**
     * Returns true if the result is an `Ok` value containing the given value
     * @param value
     * @returns `true` if `Ok` and `this.inner === value`, `false` otherwise
     */
    contains(value) {
        return false;
    }
    /**
     * Returns true if the result is an `Err` value containing the given value
     * @param value
     * @returns `true` if `Err` and `this.inner === value`, `false` otherwise
     */
    containsErr(value) {
        return this.inner === value;
    }
    /**
     * Get the inner value or throw to the closest `Result.unthrow`
     * @param thrower The thrower from `Result.unthrow`
     * @returns `this.inner` if `Ok`
     * @throws `undefined` if `Err`
     * @see Result.unthrow
     * @see Result.unthrowSync
     */
    throw(thrower) {
        thrower(this);
        throw new Panic(`Thrown result was try-catched`);
    }
    /**
     * Get the inner value or throw the inner error wrapped inside another Error
     * @param message
     * @returns `this.inner` if `Ok`, `Error(message, { cause: this.inner })` if `Err`
     */
    expect(message) {
        this.ignore();
        throw new Panic(message, { cause: this.inner });
    }
    /**
     * Get the inner error or throw the inner value wrapped inside another Error
     * @param message
     * @returns `this.inner` if `Err`, `Error(message, { cause: this.inner })` if `Ok`
     */
    expectErr(message) {
        this.ignore();
        return this.inner;
    }
    /**
     * Get the inner value or throw the inner error
     * @returns `this.inner` if `Ok`
     * @throws `this.inner` if `Err`
     */
    unwrap() {
        this.ignore();
        throw new Panic(undefined, { cause: this.inner });
    }
    /**
     * Throw the inner value or get the inner error
     * @returns `this.inner` if `Err`
     * @throws `this.inner` if `Ok`
     */
    unwrapErr() {
        this.ignore();
        return this.inner;
    }
    /**
     * Get the inner value or a default one
     * @param value
     * @returns `this.inner` if `Ok`, `value` if `Err`
     */
    unwrapOr(value) {
        this.ignore();
        return value;
    }
    /**
     * Get the inner value or compute a default one from the inner error
     * @param errMapper
     * @returns `this.inner` if `Ok`, `await errMapper(this.inner)` if `Err`
     * @throws if `await errMapper(this.inner)` throws
     */
    async unwrapOrElse(errMapper) {
        this.ignore();
        return await errMapper(this.inner);
    }
    /**
     * Get the inner value or compute a default one from the inner error
     * @param errMapper
     * @returns `this.inner` if `Ok`, `errMapper(this.inner)` if `Err`
     * @throws if `errMapper(this.inner)` throws
     */
    unwrapOrElseSync(errMapper) {
        this.ignore();
        return errMapper(this.inner);
    }
    /**
     * Transform Result<Promise<T>, E> into Promise<Result<T, E>>
     * @returns `await this.inner` if `Ok`, `this` if `Err`
     */
    async await() {
        return this;
    }
    /**
     * Transform Result<T, Promise<E>> into Promise<Result<T, E>>
     * @returns `await this.inner` if `Err`, `this` if `Ok`
     */
    async awaitErr() {
        return new err_Err(await this.inner);
    }
    /**
     * Transform Result<Promise<T>, Promise<E>> into Promise<Result<T, E>>
     * @returns `await this.inner`
     */
    async awaitAll() {
        return await this.awaitErr();
    }
    /**
     * Transform `Result<T, E>` into `Result<void, E>`
     * @returns `Ok<void>` if `Ok<T>`, `Err<E>` if `E<E>`
     */
    clear() {
        return this;
    }
    /**
     * Transform `Result<T, E>` into `Result<T, void>`
     * @returns `Ok<T>` if `Ok<T>`, `Err<void>` if `E<E>`
     */
    clearErr() {
        this.ignore();
        return err_Err.void();
    }
    /**
     * Calls the given callback with the inner value if `Ok`
     * @param okCallback
     * @returns `this`
     */
    async inspect(okCallback) {
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Ok`
     * @param okCallback
     * @returns `this`
     */
    inspectSync(okCallback) {
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Err`
     * @param errCallback
     * @returns `this`
     */
    async inspectErr(errCallback) {
        await errCallback(this.inner);
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Err`
     * @param errCallback
     * @returns `this`
     */
    inspectErrSync(errCallback) {
        errCallback(this.inner);
        return this;
    }
    /**
     * Return a new `Ok` but with the given `inner`
     * @param inner
     * @returns `Ok(inner)` if `Ok`, `this` if `Err`
     */
    set(inner) {
        return this;
    }
    /**
     * Return a new `Err` but with the given `inner`
     * @param inner
     * @returns `Err(inner)` if `Err`, `this` if `Ok`
     */
    setErr(inner) {
        return new err_Err(inner);
    }
    /**
     * Map the inner value into another
     * @param okMapper
     * @returns `Ok(await okMapper(this.inner))` if `Ok`, `this` if `Err`
     * @throws if `await okMapper(this.inner)` throws
     */
    async map(okMapper) {
        return this;
    }
    /**
     * Map the inner value into another
     * @param okMapper
     * @returns `Ok(okMapper(this.inner))` if `Ok`, `this` if `Err`
     * @throws if `okMapper(this.inner)` throws
     */
    mapSync(okMapper) {
        return this;
    }
    /**
     * Map the inner error into another
     * @param errMapper
     * @returns `Err(await errMapper(this.inner))` if `Err`, `this` if `Ok`
     * @throws if `await errMapper(this.inner)` throws
     */
    async mapErr(errMapper) {
        this.ignore();
        return new err_Err(await errMapper(this.inner));
    }
    /**
     * Map the inner error into another
     * @param errMapper
     * @returns `Err(errMapper(this.inner))` if `Err`, `this` if `Ok`
     * @throws if `errMapper(this.inner)` throws
     */
    mapErrSync(errMapper) {
        this.ignore();
        return new err_Err(errMapper(this.inner));
    }
    /**
     * Map the inner value into another, or a default one
     * @param value
     * @param okMapper
     * @returns `await okMapper(this.inner)` if `Ok`, `value` if `Err`
     * @throws if `await okMapper(this.inner)` throws
     */
    async mapOr(value, okMapper) {
        this.ignore();
        return value;
    }
    /**
     * Map the inner value into another, or a default one
     * @param value
     * @param okMapper
     * @returns `okMapper(this.inner)` if `Ok`, `value` if `Err`
     * @throws if `okMapper(this.inner)` throws
     */
    mapOrSync(value, okMapper) {
        this.ignore();
        return value;
    }
    /**
     * Map the inner value into another, or a default one
     * @param errMapper
     * @param okMapper
     * @returns `await okMapper(this.inner)` if `Ok`, `await errMapper(this.inner)` if `Err`
     * @throws if `await okMapper(this.inner)` or `await errMapper(this.inner)` throws
     */
    async mapOrElse(errMapper, okMapper) {
        this.ignore();
        return await errMapper(this.inner);
    }
    /**
     * Map the inner value into another, or a default one
     * @param errMapper
     * @param okMapper
     * @returns `okMapper(this.inner)` if `Ok`, `errMapper(this.inner)` if `Err`
     * @throws if `okMapper(this.inner)` or `errMapper(this.inner)` throws
     */
    mapOrElseSync(errMapper, okMapper) {
        this.ignore();
        return errMapper(this.inner);
    }
    /**
     * Return `value` if `Ok`, return `this` if `Err`
     * @param value
     * @returns `value` if `Ok`, `this` if `Err`
     */
    and(value) {
        return this;
    }
    /**
     * Return `await okMapper(this.inner)` if `Ok`, return `this` if `Err`
     * @param okMapper
     * @returns `await okMapper(this.inner)` if `Ok`, `this` if `Err`
     * @throws if `await okMapper(this.inner)` throws
     */
    async andThen(okMapper) {
        return this;
    }
    /**
     * Return `okMapper(this.inner)` if `Ok`, return `this` if `Err`
     * @param okMapper
     * @returns `okMapper(this.inner)` if `Ok`, `this` if `Err`
     * @throws if `okMapper(this.inner)` throws
     */
    andThenSync(okMapper) {
        return this;
    }
    /**
     * Return `value` if `Err`, return `this` if `Ok`
     * @param value
     * @returns `value` if `Err`, `this` if `Ok`
     */
    or(value) {
        this.ignore();
        return value;
    }
    /**
     * Return `await errMapper(this.inner)` if `Err`, return `this` if `Ok`
     * @param errMapper
     * @returns `await errMapper(this.inner)` if `Err`, `this` if `Ok`
     * @throws if `await errMapper(this.inner)` throws
     */
    async orElse(errMapper) {
        this.ignore();
        return await errMapper(this.inner);
    }
    /**
     * Return `errMapper(this.inner)` if `Err`, return `this` if `Ok`
     * @param errMapper
     * @returns `errMapper(this.inner)` if `Err`, `this` if `Ok`
     * @throws if `errMapper(this.inner)` throws
     */
    orElseSync(errMapper) {
        this.ignore();
        return errMapper(this.inner);
    }
}


//# sourceMappingURL=err.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/option/dist/esm/mods/option/none.mjs


class NoneError extends Error {
    constructor() {
        super(`Option is a None`);
    }
}
class none_None {
    inner;
    /**
     * An empty value
     */
    constructor(inner = undefined) {
        this.inner = inner;
    }
    /**
     * Create a `None`
     * @returns `None`
     */
    static new() {
        return new none_None();
    }
    static from(init) {
        return new none_None();
    }
    /**
     * Type guard for `Some`
     * @returns `true` if `Some`, `false` if `None`
     */
    isSome() {
        return false;
    }
    /**
     * Returns `true` if the option is a `Some` and the value inside of it matches a predicate
     * @param somePredicate
     * @returns `true` if `Some` and `await somePredicate(this.inner)`, `None` otherwise
     */
    async isSomeAnd(somePredicate) {
        return false;
    }
    /**
     * Returns `true` if the option is a `Some` and the value inside of it matches a predicate
     * @param somePredicate
     * @returns `true` if `Some` and `somePredicate(this.inner)`, `None` otherwise
     */
    isSomeAndSync(somePredicate) {
        return false;
    }
    /**
     * Type guard for `None`
     * @returns `true` if `None`, `false` if `Some`
     */
    isNone() {
        return true;
    }
    /**
     * Compile-time safely get `this.inner`
     * @returns `this.inner`
     */
    get() {
        return this.inner;
    }
    /**
     * Returns an iterator over the possibly contained value
     * @yields `this.inner` if `Some`
     */
    *[Symbol.iterator]() {
        return;
    }
    /**
     * Get the inner value if `Some`, throw `Error(message)` otherwise
     * @param message
     * @returns `this.inner` if `Some`
     * @throws `Error(message)` if `None`
     */
    expect(message) {
        throw new Error(message, { cause: new NoneError() });
    }
    /**
     * Get the inner value or throw a NoneError
     * @returns `this.inner` if `Some`
     * @throws `NoneError` if `None`
     */
    unwrap() {
        throw new NoneError();
    }
    /**
     * Get the inner value or a default one
     * @param value
     * @returns `this.inner` if `Some`, `value` if `None`
     */
    unwrapOr(value) {
        return value;
    }
    /**
     * Returns the contained `Some` value or computes it from a closure
     * @param noneCallback
     * @returns `this.inner` if `Some`, `await noneCallback()` if `None`
     */
    async unwrapOrElse(noneCallback) {
        return await noneCallback();
    }
    /**
     * Returns the contained `Some` value or computes it from a closure
     * @param noneCallback
     * @returns `this.inner` if `Some`, `noneCallback()` if `None`
     */
    unwrapOrElseSync(noneCallback) {
        return noneCallback();
    }
    /**
     * Transform `Option<T>` into `Result<T, NoneError>`
     * @returns `Ok(this.inner)` if `Some`, `Err(NoneError)` if `None`
     */
    ok() {
        return new err_Err(new NoneError());
    }
    /**
     * Transform `Option<T>` into `Result<T, E>`
     * @param error
     * @returns `Ok(this.inner)` if `Some`, `Err(error)` if `None`
     */
    okOr(error) {
        return new err_Err(error);
    }
    /**
     * Transforms the `Option<T>` into a `Result<T, E>`, mapping `Some(v)` to `Ok(v)` and `None` to `Err(err())`
     * @param noneCallback
     * @returns `Ok(this.inner)` if `Some`, `Err(await noneCallback())` is `None`
     */
    async okOrElse(noneCallback) {
        return new err_Err(await noneCallback());
    }
    /**
     * Transforms the `Option<T>` into a `Result<T, E>`, mapping `Some(v)` to `Ok(v)` and `None` to `Err(err())`
     * @param noneCallback
     * @returns `Ok(this.inner)` if `Some`, `Err(noneCallback())` is `None`
     */
    okOrElseSync(noneCallback) {
        return new err_Err(noneCallback());
    }
    /**
     * Returns `None` if the option is `None`, otherwise calls `somePredicate` with the wrapped value
     * @param somePredicate
     * @returns `Some` if `Some` and `await somePredicate(this.inner)`, `None` otherwise
     */
    async filter(somePredicate) {
        return this;
    }
    /**
     * Returns `None` if the option is `None`, otherwise calls `somePredicate` with the wrapped value
     * @param somePredicate
     * @returns `Some` if `Some` and `somePredicate(this.inner)`, `None` otherwise
     */
    filterSync(somePredicate) {
        return this;
    }
    /**
     * Transform `Option<Promise<T>>` into `Promise<Option<T>>`
     * @returns `Promise<Option<T>>`
     */
    async await() {
        return this;
    }
    /**
     * Returns `true` if the option is a `Some` value containing the given value
     * @param value
     * @returns `true` if `Some` and `this.inner === value`, `None` otherwise
     */
    contains(value) {
        return false;
    }
    /**
     * Calls the given callback with the inner value if `Ok`
     * @param someCallback
     * @returns `this`
     */
    async inspect(someCallback) {
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Ok`
     * @param someCallback
     * @returns `this`
     */
    inspectSync(someCallback) {
        return this;
    }
    /**
     * Maps an `Option<T>` to `Option<U>` by applying a function to a contained value (if `Some`) or returns `None` (if `None`)
     * @param someMapper
     * @returns `Some(await someMapper(this.inner))` if `Some`, `this` if `None`
     */
    async map(someMapper) {
        return this;
    }
    /**
     * Maps an `Option<T>` to `Option<U>` by applying a function to a contained value (if `Some`) or returns `None` (if `None`)
     * @param someMapper
     * @returns `Some(someMapper(this.inner))` if `Some`, `this` if `None`
     */
    mapSync(someMapper) {
        return this;
    }
    /**
     * Returns the provided default result (if none), or applies a function to the contained value (if any)
     * @param value
     * @param someMapper
     * @returns `value` if `None`, `await someMapper(this.inner)` if `Some`
     */
    async mapOr(value, someMapper) {
        return value;
    }
    /**
     * Returns the provided default result (if none), or applies a function to the contained value (if any)
     * @param value
     * @param someMapper
     * @returns `value` if `None`, `someMapper(this.inner)` if `Some`
     */
    mapOrSync(value, someMapper) {
        return value;
    }
    /**
     * Computes a default function result (if none), or applies a different function to the contained value (if any)
     * @param noneCallback
     * @param someMapper
     * @returns `await someMapper(this.inner)` if `Some`, `await noneCallback()` if `None`
     */
    async mapOrElse(noneCallback, someMapper) {
        return await noneCallback();
    }
    /**
     * Computes a default function result (if none), or applies a different function to the contained value (if any)
     * @param noneCallback
     * @param someMapper
     * @returns `someMapper(this.inner)` if `Some`, `noneCallback()` if `None`
     */
    mapOrElseSync(noneCallback, someMapper) {
        return noneCallback();
    }
    /**
     * Returns `None` if the option is `None`, otherwise returns `value`
     * @param value
     * @returns `None` if `None`, `value` if `Some`
     */
    and(value) {
        return this;
    }
    /**
     * Returns `None` if the option is `None`, otherwise calls `someMapper` with the wrapped value and returns the result
     * @param someMapper
     * @returns `None` if `None`, `await someMapper(this.inner)` if `Some`
     */
    async andThen(someMapper) {
        return this;
    }
    /**
     * Returns `None` if the option is `None`, otherwise calls `someMapper` with the wrapped value and returns the result
     * @param someMapper
     * @returns `None` if `None`, `someMapper(this.inner)` if `Some`
     */
    andThenSync(someMapper) {
        return this;
    }
    /**
     * Returns `this` if `Some`, otherwise returns `value`
     * @param value
     * @returns `this` if `Some`, `value` if `None`
     */
    or(value) {
        return value;
    }
    /**
     * Returns `this` if `Some`, otherwise calls `noneCallback` and returns the result
     * @param noneCallback
     * @returns `this` if `Some`, `await noneCallback()` if `None`
     */
    async orElse(noneCallback) {
        return await noneCallback();
    }
    /**
     * Returns `this` if `Some`, otherwise calls `noneCallback` and returns the result
     * @param noneCallback
     * @returns `this` if `Some`, `noneCallback()` if `None`
     */
    orElseSync(noneCallback) {
        return noneCallback();
    }
    /**
     * Returns `Some` if exactly one of the options is `Some`, otherwise returns `None`
     * @param value
     * @returns `None` if both are `Some` or both are `None`, the only `Some` otherwise
     */
    xor(value) {
        return value;
    }
    /**
     * Zips `this` with another `Option`
     * @param other
     * @returns `Some([this.inner, other.inner])` if both are `Some`, `None` if one of them is `None`
     */
    zip(other) {
        return this;
    }
}


//# sourceMappingURL=none.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/option/dist/esm/mods/option/some.mjs



class some_Some {
    inner;
    /**
     * An existing value
     * @param inner
     */
    constructor(inner) {
        this.inner = inner;
    }
    /**
     * Create a `Some`
     * @param inner
     * @returns `Some(inner)`
     */
    static new(inner) {
        return new this(inner);
    }
    static from(init) {
        return new some_Some(init.inner);
    }
    /**
     * Type guard for `Some`
     * @returns `true` if `Some`, `false` if `None`
     */
    isSome() {
        return true;
    }
    /**
     * Returns `true` if the option is a `Some` and the value inside of it matches a predicate
     * @param somePredicate
     * @returns `true` if `Some` and `await somePredicate(this.inner)`, `None` otherwise
     */
    async isSomeAnd(somePredicate) {
        return await somePredicate(this.inner);
    }
    /**
     * Returns `true` if the option is a `Some` and the value inside of it matches a predicate
     * @param somePredicate
     * @returns `true` if `Some` and `somePredicate(this.inner)`, `None` otherwise
     */
    isSomeAndSync(somePredicate) {
        return somePredicate(this.inner);
    }
    /**
     * Type guard for `None`
     * @returns `true` if `None`, `false` if `Some`
     */
    isNone() {
        return false;
    }
    /**
     * Compile-time safely get `this.inner`
     * @returns `this.inner`
     */
    get() {
        return this.inner;
    }
    /**
     * Returns an iterator over the possibly contained value
     * @yields `this.inner` if `Some`
     */
    *[Symbol.iterator]() {
        yield this.inner;
    }
    /**
     * Get the inner value if `Some`, throw `Error(message)` otherwise
     * @param message
     * @returns `this.inner` if `Some`
     * @throws `Error(message)` if `None`
     */
    expect(message) {
        return this.inner;
    }
    /**
     * Get the inner value or throw a NoneError
     * @returns `this.inner` if `Some`
     * @throws `NoneError` if `None`
     */
    unwrap() {
        return this.inner;
    }
    /**
     * Get the inner value or a default one
     * @param value
     * @returns `this.inner` if `Some`, `value` if `None`
     */
    unwrapOr(value) {
        return this.inner;
    }
    /**
     * Returns the contained `Some` value or computes it from a closure
     * @param noneCallback
     * @returns `this.inner` if `Some`, `await noneCallback()` if `None`
     */
    async unwrapOrElse(noneCallback) {
        return this.inner;
    }
    /**
     * Returns the contained `Some` value or computes it from a closure
     * @param noneCallback
     * @returns `this.inner` if `Some`, `noneCallback()` if `None`
     */
    unwrapOrElseSync(noneCallback) {
        return this.inner;
    }
    /**
     * Transform `Option<T>` into `Result<T, NoneError>`
     * @returns `Ok(this.inner)` if `Some`, `Err(NoneError)` if `None`
     */
    ok() {
        return new ok_Ok(this.inner);
    }
    /**
     * Transform `Option<T>` into `Result<T, E>`
     * @param error
     * @returns `Ok(this.inner)` if `Some`, `Err(error)` if `None`
     */
    okOr(error) {
        return new ok_Ok(this.inner);
    }
    /**
     * Transforms the `Option<T>` into a `Result<T, E>`, mapping `Some(v)` to `Ok(v)` and `None` to `Err(err())`
     * @param noneCallback
     * @returns `Ok(this.inner)` if `Some`, `Err(await noneCallback())` is `None`
     */
    async okOrElse(noneCallback) {
        return new ok_Ok(this.inner);
    }
    /**
     * Transforms the `Option<T>` into a `Result<T, E>`, mapping `Some(v)` to `Ok(v)` and `None` to `Err(err())`
     * @param noneCallback
     * @returns `Ok(this.inner)` if `Some`, `Err(noneCallback())` is `None`
     */
    okOrElseSync(noneCallback) {
        return new ok_Ok(this.inner);
    }
    /**
     * Returns `None` if the option is `None`, otherwise calls `somePredicate` with the wrapped value
     * @param somePredicate
     * @returns `Some` if `Some` and `await somePredicate(this.inner)`, `None` otherwise
     */
    async filter(somePredicate) {
        if (await somePredicate(this.inner))
            return this;
        else
            return new none_None();
    }
    /**
     * Returns `None` if the option is `None`, otherwise calls `somePredicate` with the wrapped value
     * @param somePredicate
     * @returns `Some` if `Some` and `somePredicate(this.inner)`, `None` otherwise
     */
    filterSync(somePredicate) {
        if (somePredicate(this.inner))
            return this;
        else
            return new none_None();
    }
    /**
     * Transform `Option<Promise<T>>` into `Promise<Option<T>>`
     * @returns `Promise<Option<T>>`
     */
    async await() {
        return new some_Some(await this.inner);
    }
    /**
     * Returns `true` if the option is a `Some` value containing the given value
     * @param value
     * @returns `true` if `Some` and `this.inner === value`, `None` otherwise
     */
    contains(value) {
        return this.inner === value;
    }
    /**
     * Calls the given callback with the inner value if `Ok`
     * @param someCallback
     * @returns `this`
     */
    async inspect(someCallback) {
        await someCallback(this.inner);
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Ok`
     * @param someCallback
     * @returns `this`
     */
    inspectSync(someCallback) {
        someCallback(this.inner);
        return this;
    }
    /**
     * Maps an `Option<T>` to `Option<U>` by applying a function to a contained value (if `Some`) or returns `None` (if `None`)
     * @param someMapper
     * @returns `Some(await someMapper(this.inner))` if `Some`, `this` if `None`
     */
    async map(someMapper) {
        return new some_Some(await someMapper(this.inner));
    }
    /**
     * Maps an `Option<T>` to `Option<U>` by applying a function to a contained value (if `Some`) or returns `None` (if `None`)
     * @param someMapper
     * @returns `Some(someMapper(this.inner))` if `Some`, `this` if `None`
     */
    mapSync(someMapper) {
        return new some_Some(someMapper(this.inner));
    }
    /**
     * Returns the provided default result (if none), or applies a function to the contained value (if any)
     * @param value
     * @param someMapper
     * @returns `value` if `None`, `await someMapper(this.inner)` if `Some`
     */
    async mapOr(value, someMapper) {
        return await someMapper(this.inner);
    }
    /**
     * Returns the provided default result (if none), or applies a function to the contained value (if any)
     * @param value
     * @param someMapper
     * @returns `value` if `None`, `someMapper(this.inner)` if `Some`
     */
    mapOrSync(value, someMapper) {
        return someMapper(this.inner);
    }
    /**
     * Computes a default function result (if none), or applies a different function to the contained value (if any)
     * @param noneCallback
     * @param someMapper
     * @returns `await someMapper(this.inner)` if `Some`, `await noneCallback()` if `None`
     */
    async mapOrElse(noneCallback, someMapper) {
        return await someMapper(this.inner);
    }
    /**
     * Computes a default function result (if none), or applies a different function to the contained value (if any)
     * @param noneCallback
     * @param someMapper
     * @returns `someMapper(this.inner)` if `Some`, `noneCallback()` if `None`
     */
    mapOrElseSync(noneCallback, someMapper) {
        return someMapper(this.inner);
    }
    /**
     * Returns `None` if the option is `None`, otherwise returns `value`
     * @param value
     * @returns `None` if `None`, `value` if `Some`
     */
    and(value) {
        return value;
    }
    /**
     * Returns `None` if the option is `None`, otherwise calls `someMapper` with the wrapped value and returns the result
     * @param someMapper
     * @returns `None` if `None`, `await someMapper(this.inner)` if `Some`
     */
    async andThen(someMapper) {
        return await someMapper(this.inner);
    }
    /**
     * Returns `None` if the option is `None`, otherwise calls `someMapper` with the wrapped value and returns the result
     * @param someMapper
     * @returns `None` if `None`, `someMapper(this.inner)` if `Some`
     */
    andThenSync(someMapper) {
        return someMapper(this.inner);
    }
    /**
     * Returns `this` if `Some`, otherwise returns `value`
     * @param value
     * @returns `this` if `Some`, `value` if `None`
     */
    or(value) {
        return this;
    }
    /**
     * Returns `this` if `Some`, otherwise calls `noneCallback` and returns the result
     * @param noneCallback
     * @returns `this` if `Some`, `await noneCallback()` if `None`
     */
    async orElse(noneCallback) {
        return this;
    }
    /**
     * Returns `this` if `Some`, otherwise calls `noneCallback` and returns the result
     * @param noneCallback
     * @returns `this` if `Some`, `noneCallback()` if `None`
     */
    orElseSync(noneCallback) {
        return this;
    }
    /**
     * Returns `Some` if exactly one of the options is `Some`, otherwise returns `None`
     * @param value
     * @returns `None` if both are `Some` or both are `None`, the only `Some` otherwise
     */
    xor(value) {
        if (value.isSome())
            return new none_None();
        else
            return this;
    }
    /**
     * Zips `this` with another `Option`
     * @param other
     * @returns `Some([this.inner, other.inner])` if both are `Some`, `None` if one of them is `None`
     */
    zip(other) {
        if (other.isSome())
            return new some_Some([this.inner, other.inner]);
        else
            return other;
    }
}


//# sourceMappingURL=some.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/ok.mjs




class ok_Ok {
    #inner;
    #timeout;
    /**
     * A success
     * @param inner
     */
    constructor(inner) {
        this.#inner = inner;
        if (!Debug.debug)
            return;
        const error = new Panic(`Unhandled result`, { cause: this });
        this.#timeout = setTimeout(async () => { throw error; }, 1000);
    }
    /**
     * Create an empty `Ok`
     * @returns `Ok(void)`
     */
    static void() {
        return new ok_Ok(undefined);
    }
    /**
     * Create an `Ok`
     * @param inner
     * @returns `Ok(inner)`
     */
    static new(inner) {
        return new ok_Ok(inner);
    }
    get inner() {
        return this.#inner;
    }
    /**
     * Set this result as handled
     */
    ignore() {
        if (!this.#timeout)
            return this;
        clearTimeout(this.#timeout);
        this.#timeout = undefined;
        return this;
    }
    /**
     * Type guard for `Ok`
     * @returns `true` if `Ok`, `false` if `Err`
     */
    isOk() {
        return true;
    }
    /**
     * Returns true if the result is `Ok` and the value inside of it matches a predicate
     * @param okPredicate
     * @returns `true` if `Ok` and `await okPredicate(this.inner)`, `false` otherwise
     */
    async isOkAnd(okPredicate) {
        return await okPredicate(this.inner);
    }
    /**
     * Returns true if the result is `Ok` and the value inside of it matches a predicate
     * @param okPredicate
     * @returns `true` if `Ok` and `await okPredicate(this.inner)`, `false` otherwise
     */
    isOkAndSync(okPredicate) {
        return okPredicate(this.inner);
    }
    /**
     * Type guard for `Err`
     * @returns `true` if `Err`, `false` if `Ok`
     */
    isErr() {
        return false;
    }
    /**
     * Returns true if the result is `Err` and the value inside of it matches a predicate
     * @param errPredicate
     * @returns `true` if `Err` and `await errPredicate(this.inner)`, `false` otherwise
     */
    async isErrAnd(errPredicate) {
        return false;
    }
    /**
     * Returns true if the result is `Err` and the value inside of it matches a predicate
     * @param errPredicate
     * @returns `true` if `Err` and `await errPredicate(this.inner)`, `false` otherwise
     */
    isErrAndSync(errPredicate) {
        return false;
    }
    /**
     * Compile-time safely get `this.inner`
     * @returns `this.inner`
     */
    get() {
        this.ignore();
        return this.inner;
    }
    /**
     * Transform `Result<T, E>` into `Option<T>`
     * @returns `Some(this.inner)` if `Ok`, `None` if `Err`
     */
    ok() {
        this.ignore();
        return new some_Some(this.inner);
    }
    /**
     * Transform `Result<T, E>` into `Option<E>`
     * @returns `Some(this.inner)` if `Err`, `None` if `Ok`
     */
    err() {
        this.ignore();
        return new none_None();
    }
    /**
     * Returns an iterator over the possibly contained value
     * @yields `this.inner` if `Ok`
     */
    *[Symbol.iterator]() {
        this.ignore();
        yield this.inner;
    }
    /**
     * Transform `Result<T,E>` into `[T,E]`
     * @returns `[this.inner, undefined]` if `Ok`, `[undefined, this.inner]` if `Err`
     */
    split() {
        this.ignore();
        return [this.inner, undefined];
    }
    /**
     * Returns true if the result is an `Ok` value containing the given value
     * @param value
     * @returns `true` if `Ok` and `this.inner === value`, `false` otherwise
     */
    contains(value) {
        return this.inner === value;
    }
    /**
     * Returns true if the result is an `Err` value containing the given value
     * @param value
     * @returns `true` if `Err` and `this.inner === value`, `false` otherwise
     */
    containsErr(value) {
        return false;
    }
    /**
     * Just like `unwrap` but it throws to the closest `Result.unthrow`
     * @returns `this.inner` if `Ok`
     * @throws `this` if `Err`
     * @see Result.unthrow
     * @see Result.unthrowSync
     */
    throw(thrower) {
        this.ignore();
        return this.inner;
    }
    /**
     * Get the inner value or throw the inner error wrapped inside another Error
     * @param message
     * @returns `this.inner` if `Ok`, `Error(message, { cause: this.inner })` if `Err`
     */
    expect(message) {
        this.ignore();
        return this.inner;
    }
    /**
     * Get the inner error or throw the inner value wrapped inside another Error
     * @param message
     * @returns `this.inner` if `Err`, `Error(message, { cause: this.inner })` if `Ok`
     */
    expectErr(message) {
        this.ignore();
        throw new Panic(message, { cause: this.inner });
    }
    /**
     * Get the inner value or throw the inner error
     * @returns `this.inner` if `Ok`
     * @throws `this.inner` if `Err`
     */
    unwrap() {
        this.ignore();
        return this.inner;
    }
    /**
     * Throw the inner value or get the inner error
     * @returns `this.inner` if `Err`
     * @throws `this.inner` if `Ok`
     */
    unwrapErr() {
        this.ignore();
        throw new Panic(undefined, { cause: this.inner });
    }
    /**
     * Get the inner value or a default one
     * @param value
     * @returns `this.inner` if `Ok`, `value` if `Err`
     */
    unwrapOr(value) {
        this.ignore();
        return this.inner;
    }
    /**
     * Get the inner value or compute a default one from the inner error
     * @param errMapper
     * @returns `this.inner` if `Ok`, `await errMapper(this.inner)` if `Err`
     * @throws if `await errMapper(this.inner)` throws
     */
    async unwrapOrElse(errMapper) {
        this.ignore();
        return this.inner;
    }
    /**
     * Get the inner value or compute a default one from the inner error
     * @param errMapper
     * @returns `this.inner` if `Ok`, `errMapper(this.inner)` if `Err`
     * @throws if `errMapper(this.inner)` throws
     */
    unwrapOrElseSync(errMapper) {
        this.ignore();
        return this.inner;
    }
    /**
     * Transform Result<Promise<T>, E> into Promise<Result<T, E>>
     * @returns `await this.inner` if `Ok`, `this` if `Err`
     */
    async await() {
        return new ok_Ok(await this.inner);
    }
    /**
     * Transform Result<T, Promise<E>> into Promise<Result<T, E>>
     * @returns `await this.inner` if `Err`, `this` if `Ok`
     */
    async awaitErr() {
        return this;
    }
    /**
     * Transform Result<Promise<T>, Promise<E>> into Promise<Result<T, E>>
     * @returns `await this.inner`
     */
    async awaitAll() {
        return await this.await();
    }
    /**
     * Transform `Result<T, E>` into `Result<void, E>`
     * @returns `Ok<void>` if `Ok<T>`, `Err<E>` if `E<E>`
     */
    clear() {
        this.ignore();
        return ok_Ok.void();
    }
    /**
     * Transform `Result<T, E>` into `Result<T, void>`
     * @returns `Ok<T>` if `Ok<T>`, `Err<void>` if `E<E>`
     */
    clearErr() {
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Ok`
     * @param okCallback
     * @returns `this`
     */
    async inspect(okCallback) {
        await okCallback(this.inner);
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Ok`
     * @param okCallback
     * @returns `this`
     */
    inspectSync(okCallback) {
        okCallback(this.inner);
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Err`
     * @param errCallback
     * @returns `this`
     */
    async inspectErr(errCallback) {
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Err`
     * @param errCallback
     * @returns `this`
     */
    inspectErrSync(errCallback) {
        return this;
    }
    /**
     * Return a new `Ok` but with the given `inner`
     * @param inner
     * @returns `Ok(inner)` if `Ok`, `this` if `Err`
     */
    set(inner) {
        return new ok_Ok(inner);
    }
    /**
     * Return a new `Err` but with the given `inner`
     * @param inner
     * @returns `Err(inner)` if `Err`, `this` if `Ok`
     */
    setErr(inner) {
        return this;
    }
    /**
     * Map the inner value into another
     * @param okMapper
     * @returns `Ok(await okMapper(this.inner))` if `Ok`, `this` if `Err`
     * @throws if `await okMapper(this.inner)` throws
     */
    async map(okMapper) {
        this.ignore();
        return new ok_Ok(await okMapper(this.inner));
    }
    /**
     * Map the inner value into another
     * @param okMapper
     * @returns `Ok(okMapper(this.inner))` if `Ok`, `this` if `Err`
     * @throws if `okMapper(this.inner)` throws
     */
    mapSync(okMapper) {
        this.ignore();
        return new ok_Ok(okMapper(this.inner));
    }
    /**
     * Map the inner error into another
     * @param errMapper
     * @returns `Err(await errMapper(this.inner))` if `Err`, `this` if `Ok`
     * @throws if `await errMapper(this.inner)` throws
     */
    async mapErr(errMapper) {
        return this;
    }
    /**
     * Map the inner error into another
     * @param errMapper
     * @returns `Err(errMapper(this.inner))` if `Err`, `this` if `Ok`
     * @throws if `errMapper(this.inner)` throws
     */
    mapErrSync(errMapper) {
        return this;
    }
    /**
     * Map the inner value into another, or a default one
     * @param value
     * @param okMapper
     * @returns `await okMapper(this.inner)` if `Ok`, `value` if `Err`
     * @throws if `await okMapper(this.inner)` throws
     */
    async mapOr(value, okMapper) {
        this.ignore();
        return await okMapper(this.inner);
    }
    /**
     * Map the inner value into another, or a default one
     * @param value
     * @param okMapper
     * @returns `okMapper(this.inner)` if `Ok`, `value` if `Err`
     * @throws if `okMapper(this.inner)` throws
     */
    mapOrSync(value, okMapper) {
        this.ignore();
        return okMapper(this.inner);
    }
    /**
     * Map the inner value into another, or a default one
     * @param errMapper
     * @param okMapper
     * @returns `await okMapper(this.inner)` if `Ok`, `await errMapper(this.inner)` if `Err`
     * @throws if `await okMapper(this.inner)` or `await errMapper(this.inner)` throws
     */
    async mapOrElse(errMapper, okMapper) {
        this.ignore();
        return await okMapper(this.inner);
    }
    /**
     * Map the inner value into another, or a default one
     * @param errMapper
     * @param okMapper
     * @returns `okMapper(this.inner)` if `Ok`, `errMapper(this.inner)` if `Err`
     * @throws if `okMapper(this.inner)` or `errMapper(this.inner)` throws
     */
    mapOrElseSync(errMapper, okMapper) {
        this.ignore();
        return okMapper(this.inner);
    }
    /**
     * Return `value` if `Ok`, return `this` if `Err`
     * @param value
     * @returns `value` if `Ok`, `this` if `Err`
     */
    and(value) {
        this.ignore();
        return value;
    }
    /**
     * Return `await okMapper(this.inner)` if `Ok`, return `this` if `Err`
     * @param okMapper
     * @returns `await okMapper(this.inner)` if `Ok`, `this` if `Err`
     * @throws if `await okMapper(this.inner)` throws
     */
    async andThen(okMapper) {
        this.ignore();
        return await okMapper(this.inner);
    }
    /**
     * Return `okMapper(this.inner)` if `Ok`, return `this` if `Err`
     * @param okMapper
     * @returns `okMapper(this.inner)` if `Ok`, `this` if `Err`
     * @throws if `okMapper(this.inner)` throws
     */
    andThenSync(okMapper) {
        this.ignore();
        return okMapper(this.inner);
    }
    /**
     * Return `value` if `Err`, return `this` if `Ok`
     * @param value
     * @returns `value` if `Err`, `this` if `Ok`
     */
    or(value) {
        return this;
    }
    /**
     * Return `await errMapper(this.inner)` if `Err`, return `this` if `Ok`
     * @param errMapper
     * @returns `await errMapper(this.inner)` if `Err`, `this` if `Ok`
     * @throws if `await errMapper(this.inner)` throws
     */
    async orElse(errMapper) {
        return this;
    }
    /**
     * Return `errMapper(this.inner)` if `Err`, return `this` if `Ok`
     * @param errMapper
     * @returns `errMapper(this.inner)` if `Err`, `this` if `Ok`
     * @throws if `errMapper(this.inner)` throws
     */
    orElseSync(errMapper) {
        return this;
    }
}


//# sourceMappingURL=ok.mjs.map

;// CONCATENATED MODULE: ./src/libs/blob/blob.ts


var Blobs;
(function(Blobs) {
    async function toData(blob) {
        const future = new Future();
        const reader = new FileReader();
        const onLoadEnd = ()=>{
            future.resolve(new ok_Ok(reader.result));
        };
        const onError = ()=>{
            future.resolve(new err_Err(reader.error));
        };
        const onAbort = ()=>{
            future.resolve(new err_Err(new Error("Aborted")));
        };
        try {
            reader.addEventListener("loadend", onLoadEnd, {
                passive: true
            });
            reader.addEventListener("error", onError, {
                passive: true
            });
            reader.addEventListener("abort", onAbort, {
                passive: true
            });
            reader.readAsDataURL(blob);
            return await future.promise;
        } finally{
            reader.removeEventListener("loadend", onLoadEnd);
            reader.removeEventListener("error", onError);
            reader.removeEventListener("abort", onAbort);
        }
    }
    Blobs.toData = toData;
})(Blobs || (Blobs = {}));

;// CONCATENATED MODULE: ./node_modules/@swc/helpers/esm/_class_apply_descriptor_get.js
function _class_apply_descriptor_get(receiver, descriptor) {
    if (descriptor.get) return descriptor.get.call(receiver);

    return descriptor.value;
}


;// CONCATENATED MODULE: ./node_modules/@swc/helpers/esm/_class_extract_field_descriptor.js
function _class_extract_field_descriptor(receiver, privateMap, action) {
    if (!privateMap.has(receiver)) throw new TypeError("attempted to " + action + " private field on non-instance");

    return privateMap.get(receiver);
}


;// CONCATENATED MODULE: ./node_modules/@swc/helpers/esm/_class_private_field_get.js



function _class_private_field_get(receiver, privateMap) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "get");
    return _class_apply_descriptor_get(receiver, descriptor);
}


;// CONCATENATED MODULE: ./node_modules/@swc/helpers/esm/_check_private_redeclaration.js
function _check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}


;// CONCATENATED MODULE: ./node_modules/@swc/helpers/esm/_class_private_field_init.js


function _class_private_field_init(obj, privateMap, value) {
    _check_private_redeclaration(obj, privateMap);
    privateMap.set(obj, value);
}


;// CONCATENATED MODULE: ./node_modules/@swc/helpers/esm/_class_apply_descriptor_set.js
function _class_apply_descriptor_set(receiver, descriptor, value) {
    if (descriptor.set) descriptor.set.call(receiver, value);
    else {
        if (!descriptor.writable) {
            // This should only throw in strict mode, but class bodies are
            // always strict and private fields can only be used inside
            // class bodies.
            throw new TypeError("attempted to set read only private field");
        }
        descriptor.value = value;
    }
}


;// CONCATENATED MODULE: ./node_modules/@swc/helpers/esm/_class_private_field_set.js



function _class_private_field_set(receiver, privateMap, value) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "set");
    _class_apply_descriptor_set(receiver, descriptor, value);
    return value;
}


;// CONCATENATED MODULE: ./src/libs/browser/browser.ts




var _globalThis_browser;
const browser = (_globalThis_browser = globalThis.browser) !== null && _globalThis_browser !== void 0 ? _globalThis_browser : globalThis.chrome;
var _class = /*#__PURE__*/ new WeakMap();
class BrowserError extends Error {
    static from(cause) {
        return new BrowserError(undefined, {
            cause
        });
    }
    constructor(...args){
        super(...args);
        _class_private_field_init(this, _class, {
            writable: true,
            value: void 0
        });
        _class_private_field_set(this, _class, BrowserError);
        this.name = _class_private_field_get(this, _class).name;
    }
}
async function tryBrowser(callback) {
    try {
        const result = await callback();
        if (browser.runtime.lastError) return new err_Err(new BrowserError());
        return new ok_Ok(result);
    } catch (e) {
        return new err_Err(new BrowserError());
    }
}
function tryBrowserSync(callback) {
    try {
        const result = callback();
        const error = browser.runtime.lastError;
        if (error) return new err_Err(BrowserError.from(error));
        return new ok_Ok(result);
    } catch (e) {
        return new err_Err(BrowserError.from(e));
    }
}

;// CONCATENATED MODULE: ./node_modules/@hazae41/cleaner/dist/esm/mods/cleaner/cleaner.mjs
var Cleanable;
(function (Cleanable) {
    async function runWith(cleanable, callback) {
        try {
            return await callback(cleanable);
        }
        finally {
            cleanable?.clean();
        }
    }
    Cleanable.runWith = runWith;
    function runWithSync(cleanable, callback) {
        try {
            return callback(cleanable);
        }
        finally {
            cleanable?.clean();
        }
    }
    Cleanable.runWithSync = runWithSync;
})(Cleanable = Cleanable || (Cleanable = {}));
class cleaner_Cleaner {
    inner;
    clean;
    constructor(inner, clean) {
        this.inner = inner;
        this.clean = clean;
    }
}
(function (Cleaner) {
    async function wait(cleaner) {
        try {
            return await cleaner.inner;
        }
        finally {
            cleaner.clean();
        }
    }
    Cleaner.wait = wait;
    async function race(cleaners) {
        const promises = new Array(cleaners.length);
        const cleanups = new Array(cleaners.length);
        for (let i = 0; i < cleaners.length; i++) {
            promises[i] = cleaners[i].inner;
            cleanups[i] = cleaners[i].clean;
        }
        try {
            return await Promise.race(promises);
        }
        finally {
            cleanups.forEach(cleanup => cleanup());
        }
    }
    Cleaner.race = race;
})(cleaner_Cleaner = cleaner_Cleaner || (cleaner_Cleaner = {}));


//# sourceMappingURL=cleaner.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/plume/dist/esm/mods/errors.mjs





class errors_AbortedError extends Error {
    #class = errors_AbortedError;
    name = this.#class.name;
    static from(cause) {
        return new errors_AbortedError(`Aborted`, { cause });
    }
    static wait(signal) {
        const future = new Future();
        const onAbort = (event) => {
            future.resolve(new err_Err(errors_AbortedError.from(event)));
        };
        signal.addEventListener("abort", onAbort, { passive: true });
        const off = () => signal.removeEventListener("abort", onAbort);
        return new cleaner_Cleaner(future.promise, off);
    }
}
class errors_ErroredError extends Error {
    #class = errors_ErroredError;
    name = this.#class.name;
    static from(cause) {
        return new errors_ErroredError(`Errored`, { cause });
    }
    static wait(target) {
        return target.wait("error", (future, event) => {
            const error = errors_ErroredError.from(event);
            future.resolve(new err_Err(error));
            return new none_None();
        });
    }
}
class errors_ClosedError extends Error {
    #class = errors_ClosedError;
    name = this.#class.name;
    static from(cause) {
        return new errors_ClosedError(`Closed`, { cause });
    }
    static wait(target) {
        return target.wait("close", (future, event) => {
            const error = errors_ClosedError.from(event);
            future.resolve(new err_Err(error));
            return new none_None();
        });
    }
}


//# sourceMappingURL=errors.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/plume/dist/esm/mods/waiters.mjs



async function tryWaitOrSignal(target, type, callback, signal) {
    const abort = AbortedError.wait(signal);
    const event = target.wait(type, callback);
    return await Cleaner.race([abort, event]);
}
async function tryWaitOrCloseOrError(target, type, callback) {
    const error = errors_ErroredError.wait(target);
    const close = errors_ClosedError.wait(target);
    const event = target.wait(type, callback);
    return await cleaner_Cleaner.race([error, close, event]);
}
async function tryWaitOrCloseOrErrorOrSignal(target, type, callback, signal) {
    const abort = AbortedError.wait(signal);
    const error = ErroredError.wait(target);
    const close = ClosedError.wait(target);
    const event = target.wait(type, callback);
    return await Cleaner.race([abort, error, close, event]);
}


//# sourceMappingURL=waiters.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/plume/dist/esm/mods/target.mjs




class EventError extends (/* unused pure expression or super */ null && (Error)) {
    #class = EventError;
    name = this.#class.name;
    constructor(cause) {
        super(`Event failed`, { cause });
    }
    static new(cause) {
        return new EventError(cause);
    }
}
class target_SuperEventTarget {
    #listeners = new Map();
    get listeners() {
        return this.#listeners;
    }
    /**
     * Add a listener to an event
     * @param type Event type //  "abort", "error", "message", "close"
     * @param listener Event listener // (e) => new Some(123)
     * @param options Options // { passive: true }
     * @returns
     */
    on(type, listener, options = {}) {
        let listeners = this.#listeners.get(type);
        if (listeners === undefined) {
            listeners = new Map();
            this.#listeners.set(type, listeners);
        }
        const off = () => this.off(type, listener);
        const internalOptions = { ...options, off };
        internalOptions.signal?.addEventListener("abort", off, { passive: true });
        listeners.set(listener, internalOptions);
        return off;
    }
    /**
     * Remove a listener from an event
     * @param type Event type //  "abort", "error", "message", "close"
     * @param listener Event listener // (e) => console.log("hello")
     * @param options Just to look like DOM's EventTarget
     * @returns
     */
    off(type, listener) {
        const listeners = this.#listeners.get(type);
        if (!listeners)
            return;
        const options = listeners.get(listener);
        if (!options)
            return;
        options.signal?.removeEventListener("abort", options.off);
        listeners.delete(listener);
        if (listeners.size > 0)
            return;
        this.#listeners.delete(type);
    }
    /**
     * Dispatch an event to its listeners
     *
     * - Dispatch to active listeners sequencially
     * - Return if one of the listeners returned something
     * - Dispatch to passive listeners concurrently
     * - Return if one of the listeners returned something
     * - Return nothing
     * @param value The object to emit
     * @returns `Some` if the event
     */
    async emit(type, value) {
        const listeners = this.#listeners.get(type);
        if (!listeners)
            return new none_None();
        const promises = new Array();
        for (const [listener, options] of listeners) {
            if (options.passive)
                continue;
            if (options.once)
                this.off(type, listener);
            const returned = await listener(...value);
            if (returned.isNone())
                continue;
            return returned;
        }
        for (const [listener, options] of listeners) {
            if (!options.passive)
                continue;
            if (options.once)
                this.off(type, listener);
            const returned = listener(...value);
            if (returned instanceof Promise) {
                promises.push(returned);
                continue;
            }
            if (returned.isNone())
                continue;
            return returned;
        }
        const returneds = await Promise.all(promises);
        for (const returned of returneds)
            if (returned.isSome())
                return returned;
        return new none_None();
    }
    /**
     * Like `.on`, but instead of returning to the target, capture the returned value in a future, and return nothing to the target
     * @param type
     * @param callback
     * @returns
     */
    wait(type, callback) {
        const future = new Future();
        const onEvent = async (...params) => {
            try {
                return await callback(future, ...params);
            }
            catch (e) {
                future.reject(e);
                throw e;
            }
        };
        const off = this.on(type, onEvent, { passive: true });
        return new cleaner_Cleaner(future.promise, off);
    }
}


//# sourceMappingURL=target.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/option/dist/esm/mods/option/option.mjs



var Option;
(function (Option) {
    function from(init) {
        if ("inner" in init)
            return new some_Some(init.inner);
        return new none_None();
    }
    Option.from = from;
    /**
     * Create an Option from a maybe undefined value
     * @param inner
     * @returns `Some<T>` if `T`, `None` if `undefined`
     */
    function wrap(inner) {
        if (inner == null)
            return new none_None();
        return new some_Some(inner);
    }
    Option.wrap = wrap;
    async function map(inner, mapper) {
        return Option.wrap(inner).map(mapper).then(o => o.get());
    }
    Option.map = map;
    function mapSync(inner, mapper) {
        return Option.wrap(inner).mapSync(mapper).get();
    }
    Option.mapSync = mapSync;
    function unwrap(inner) {
        return Option.wrap(inner).unwrap();
    }
    Option.unwrap = unwrap;
})(Option || (Option = {}));


//# sourceMappingURL=option.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/result.mjs





var Result;
(function (Result) {
    /**
     * Create a Result from a maybe Error value
     * @param inner
     * @returns `Ok<T>` if `T`, `Err<Error>` if `Error`
     */
    function from(inner) {
        if (inner instanceof Error)
            return new err_Err(inner);
        else
            return new ok_Ok(inner);
    }
    Result.from = from;
    /**
     * Create a Result from a boolean
     * @param value
     * @returns
     */
    function assert(value) {
        if (value)
            return new ok_Ok(undefined);
        else
            return new err_Err(undefined);
    }
    Result.assert = assert;
    function rewrap(wrapper) {
        try {
            return new ok_Ok(wrapper.unwrap());
        }
        catch (error) {
            return new err_Err(error);
        }
    }
    Result.rewrap = rewrap;
    /**
     * Catch an Err thrown from Err.throw
     * @param callback
     * @param type
     * @returns `Ok<T>` if no `Err` was thrown, `Err<E>` otherwise
     * @see Err.throw
     */
    async function unthrow(callback) {
        let ref;
        try {
            return await callback((e) => ref = e);
        }
        catch (e) {
            if (ref !== undefined)
                return ref;
            throw e;
        }
    }
    Result.unthrow = unthrow;
    /**
     * Catch an Err thrown from Err.throw
     * @param callback
     * @param type
     * @returns `Ok<T>` if no `Err` was thrown, `Err<E>` otherwise
     * @see Err.throw
     */
    function unthrowSync(callback) {
        let ref;
        try {
            return callback((e) => ref = e);
        }
        catch (e) {
            if (ref !== undefined)
                return ref;
            throw e;
        }
    }
    Result.unthrowSync = unthrowSync;
    /**
     * Wrap with catching
     * @param callback
     * @returns
     */
    async function catchAndWrap(callback) {
        try {
            return new ok_Ok(await callback());
        }
        catch (e) {
            return new err_Err(errors_Catched.from(e));
        }
    }
    Result.catchAndWrap = catchAndWrap;
    /**
     * Wrap with catching
     * @param callback
     * @returns
     */
    function catchAndWrapSync(callback) {
        try {
            return new ok_Ok(callback());
        }
        catch (e) {
            return new err_Err(errors_Catched.from(e));
        }
    }
    Result.catchAndWrapSync = catchAndWrapSync;
    /**
     * Catch
     * @param callback
     * @returns
     */
    async function recatch(callback) {
        try {
            return await callback();
        }
        catch (e) {
            return new err_Err(errors_Catched.from(e));
        }
    }
    Result.recatch = recatch;
    /**
     * Catch
     * @param callback
     * @returns
     */
    function recatchSync(callback) {
        try {
            return callback();
        }
        catch (e) {
            return new err_Err(errors_Catched.from(e));
        }
    }
    Result.recatchSync = recatchSync;
    /**
     * Transform `Iterable<Result<T,E>` into `Result<Array<T>, E>`
     * @param iterable
     * @returns `Result<Array<T>, E>`
     */
    function all(iterable) {
        return collect(iterate(iterable));
    }
    Result.all = all;
    function maybeAll(iterable) {
        return maybeCollect(maybeIterate(iterable));
    }
    Result.maybeAll = maybeAll;
    /**
     * Transform `Iterable<Result<T,E>` into `Iterator<T, Result<void, E>>`
     * @param iterable
     * @returns `Iterator<T, Result<void, E>>`
     */
    function* iterate(iterable) {
        for (const result of iterable) {
            if (result.isOk())
                yield result.get();
            else
                return result;
        }
        return ok_Ok.void();
    }
    Result.iterate = iterate;
    function* maybeIterate(iterable) {
        for (const result of iterable) {
            if (result == null)
                return result;
            else if (result.isOk())
                yield result.get();
            else
                return result;
        }
        return ok_Ok.void();
    }
    Result.maybeIterate = maybeIterate;
    /**
     * Transform `Iterator<T, Result<void, E>>` into `Result<Array<T>, E>`
     * @param iterator `Result<Array<T>, E>`
     */
    function collect(iterator) {
        const array = new Array();
        let result = iterator.next();
        for (; !result.done; result = iterator.next())
            array.push(result.value);
        return result.value.set(array);
    }
    Result.collect = collect;
    function maybeCollect(iterator) {
        const array = new Array();
        let result = iterator.next();
        for (; !result.done; result = iterator.next())
            array.push(result.value);
        return Option.mapSync(result.value, result => result.set(array));
    }
    Result.maybeCollect = maybeCollect;
    /**
     * Call the callback:
     * - if it throws, wrap the thrown error into `Catched` and throw it
     * - if the result is `Err`, unwrap it and throw it
     * - if the result is `Ok`, unwrap it and return it
     * @param callback
     * @returns `T` if `Ok`
     * @throws `Catched` if `callback()` throws, `E` if `Err`
     */
    async function catchAndUnwrap(callback) {
        let result;
        try {
            result = await callback();
        }
        catch (e) {
            throw errors_Catched.from(e);
        }
        return result.unwrap();
    }
    Result.catchAndUnwrap = catchAndUnwrap;
    /**
     * Call the callback:
     * - if it throws, wrap the thrown error into `Catched` and throw it
     * - if the result is `Err`, unwrap it and throw it
     * - if the result is `Ok`, unwrap it and return it
     * @param callback
     * @returns `T` if `Ok`
     * @throws `Catched` if `callback()` throws, `E` if `Err`
     */
    function catchAndUnwrapSync(callback) {
        let result;
        try {
            result = callback();
        }
        catch (e) {
            throw errors_Catched.from(e);
        }
        return result.unwrap();
    }
    Result.catchAndUnwrapSync = catchAndUnwrapSync;
    /**
     * Rethrow `CatchedError`
     * @param error
     * @returns `Err(error)` if not `CatchedError`
     * @throws `error.cause` if `CatchedError`
     */
    function rethrow(error) {
        if (error instanceof errors_Catched)
            throw error.cause;
        return new err_Err(error);
    }
    Result.rethrow = rethrow;
})(Result || (Result = {}));


//# sourceMappingURL=result.mjs.map

;// CONCATENATED MODULE: ./src/libs/rpc/ok.ts

var RpcOkInit;
(function(RpcOkInit) {
    function clone(init) {
        const { jsonrpc, id, result } = init;
        return {
            jsonrpc,
            id,
            result
        };
    }
    RpcOkInit.clone = clone;
})(RpcOkInit || (RpcOkInit = {}));
(function(RpcOkInit) {
    function from(response) {
        const { jsonrpc, id, result } = response;
        return {
            jsonrpc,
            id,
            result
        };
    }
    RpcOkInit.from = from;
})(RpcOkInit || (RpcOkInit = {}));
class RpcOk extends ok_Ok {
    static from(init) {
        return new RpcOk(init.id, init.result);
    }
    constructor(id, result){
        super(result);
        this.id = id;
        this.result = result;
        this.jsonrpc = "2.0";
    }
}

;// CONCATENATED MODULE: ./src/libs/rpc/request.ts
var RpcRequestInit;
(function(RpcRequestInit) {
    function clone(init) {
        const { id, method, params } = init;
        return {
            id,
            method,
            params
        };
    }
    RpcRequestInit.clone = clone;
})(RpcRequestInit || (RpcRequestInit = {}));
class RpcRequest {
    static from(init) {
        const { id, method, params } = init;
        return new RpcRequest(id, method, params);
    }
    constructor(id, method, params){
        this.id = id;
        this.method = method;
        this.params = params;
        this.jsonrpc = "2.0";
    }
}

;// CONCATENATED MODULE: ./src/libs/rpc/err.ts

class RpcError extends Error {
    static from(error) {
        return new RpcError(error.message);
    }
    toJSON() {
        const { message } = this;
        return {
            message
        };
    }
}
class RpcErr extends err_Err {
    static from(init) {
        return new RpcErr(init.id, new RpcError(init.error.message));
    }
    constructor(id, error){
        super(error);
        this.id = id;
        this.error = error;
        this.jsonrpc = "2.0";
    }
}

;// CONCATENATED MODULE: ./src/libs/rpc/response.ts


var response_RpcResponse;
(function(RpcResponse) {
    function from(init) {
        if ("error" in init) return RpcErr.from(init);
        return RpcOk.from(init);
    }
    RpcResponse.from = from;
    function rewrap(id, result) {
        result.ignore();
        if (result.isOk()) return new RpcOk(id, result.inner);
        if (result.inner instanceof Error) return new RpcErr(id, RpcError.from(result.inner));
        return new RpcErr(id, new RpcError());
    }
    RpcResponse.rewrap = rewrap;
})(response_RpcResponse || (response_RpcResponse = {}));

;// CONCATENATED MODULE: ./src/libs/rpc/rpc.ts





class rpc_RpcClient {
    create(init) {
        const { method, params } = init;
        const id = this.id++;
        return {
            jsonrpc: "2.0",
            id,
            method,
            params
        };
    }
    async tryFetchWithCircuit(input, init) {
        const { method, params, ...rest } = init;
        const request = this.create({
            method,
            params
        });
        return Rpc.tryFetchWithCircuit(input, {
            ...rest,
            ...request
        });
    }
    async tryFetchWithSocket(socket, request, signal) {
        return await Rpc.tryFetchWithSocket(socket, this.create(request), signal);
    }
    constructor(){
        this.id = 0;
    }
}
var Rpc;
(function(Rpc) {
    async function tryFetchWithCircuit(input, init) {
        const { id, method, params, circuit, ...rest } = init;
        const headers = new Headers(rest.headers);
        headers.set("Content-Type", "application/json");
        const request = new RpcRequest(id, method, params);
        const body = JSON.stringify(request);
        const res = await circuit.tryFetch(input, {
            ...rest,
            method: "POST",
            headers,
            body
        });
        if (!res.isOk()) return res;
        if (!res.inner.ok) return new err_Err(new Error(await res.inner.text()));
        const response = response_RpcResponse.from(await res.inner.json());
        if (response.id !== request.id) console.warn("Invalid response ID", response.id, "expected", request.id);
        return new ok_Ok(response);
    }
    Rpc.tryFetchWithCircuit = tryFetchWithCircuit;
    async function tryFetchWithSocket(socket, request, signal) {
        const { id, method, params = [] } = request;
        socket.send(JSON.stringify(new RpcRequest(id, method, params)));
        const future = new Future();
        const onMessage = async (event)=>{
            const msgEvent = event;
            const response = response_RpcResponse.from(JSON.parse(msgEvent.data));
            if (response.id !== request.id) return;
            future.resolve(new ok_Ok(response));
        };
        const onError = (e)=>{
            const result = new err_Err(errors_ErroredError.from(e));
            future.resolve(result);
        };
        const onClose = (e)=>{
            const result = new err_Err(errors_ClosedError.from(e));
            future.resolve(result);
        };
        const onAbort = ()=>{
            socket.close();
            const result = new err_Err(errors_AbortedError.from(signal.reason));
            future.resolve(result);
        };
        try {
            socket.addEventListener("message", onMessage, {
                passive: true
            });
            socket.addEventListener("close", onClose, {
                passive: true
            });
            socket.addEventListener("error", onError, {
                passive: true
            });
            signal.addEventListener("abort", onAbort, {
                passive: true
            });
            return await future.promise;
        } finally{
            socket.removeEventListener("message", onMessage);
            socket.removeEventListener("close", onClose);
            socket.removeEventListener("error", onError);
            signal.removeEventListener("abort", onAbort);
        }
    }
    Rpc.tryFetchWithSocket = tryFetchWithSocket;
})(Rpc || (Rpc = {}));

;// CONCATENATED MODULE: ./src/libs/rpc/index.ts






;// CONCATENATED MODULE: ./src/libs/channel/channel.ts





class WebsitePort {
    async runPingLoop() {
        while(true){
            const result = await this.tryRequestOrSignal({
                method: "brume_ping"
            }, AbortSignal.timeout(1000));
            if (result.isErr()) {
                await this.events.emit("close", [
                    undefined
                ]);
                return;
            }
            await new Promise((ok)=>setTimeout(ok, 1000));
        }
    }
    async tryRouteRequest(request) {
        if (request.method === "brume_ping") return Ok.void();
        const returned = await this.events.emit("request", [
            request
        ]);
        if (returned.isSome()) return returned.inner;
        return new Err(new Error("Unhandled JSON-RPC request ".concat(request)));
    }
    async onRequest(request) {
        console.debug(this.name, "->", request);
        const result = await this.tryRouteRequest(request);
        const response = RpcResponse.rewrap(request.id, result);
        console.debug(this.name, "<-", response);
        this.port.postMessage(JSON.stringify(response));
    }
    async onResponse(response) {
        const returned = await this.events.emit("response", [
            response
        ]);
        if (returned.isSome()) return returned.inner;
        return new Err(new Error("Unhandled JSON-RPC response ".concat(response)));
    }
    async onMessage(message) {
        const data = JSON.parse(message.data);
        if ("method" in data) return await this.onRequest(data);
        return await this.onResponse(data);
    }
    async tryRequest(init) {
        const request = this.client.create(init);
        this.port.postMessage(JSON.stringify(request));
        return Plume.tryWaitOrCloseOrError(this.events, "response", (future, init)=>{
            if (init.id !== request.id) return new None();
            const response = RpcResponse.from(init);
            future.resolve(new Ok(response));
            return new Some(undefined);
        });
    }
    async tryRequestOrSignal(init, signal) {
        const request = this.client.create(init);
        this.port.postMessage(JSON.stringify(request));
        return Plume.tryWaitOrCloseOrErrorOrSignal(this.events, "response", (future, init)=>{
            if (init.id !== request.id) return new None();
            const response = RpcResponse.from(init);
            future.resolve(new Ok(response));
            return new Some(undefined);
        }, signal);
    }
    constructor(name, port){
        this.name = name;
        this.port = port;
        this.client = new RpcClient();
        this.uuid = crypto.randomUUID();
        this.events = new SuperEventTarget();
        const onMessage = this.onMessage.bind(this);
        this.port.addEventListener("message", onMessage, {
            passive: true
        });
        this.clean = ()=>{
            this.port.removeEventListener("message", onMessage);
        };
    }
}
class ExtensionPort {
    async tryRouteRequest(request) {
        if (request.method === "brume_ping") return ok_Ok.void();
        const returned = await this.events.emit("request", [
            request
        ]);
        if (returned.isSome()) return returned.inner;
        return new err_Err(new Error("Unhandled JSON-RPC request ".concat(request)));
    }
    async onRequest(request) {
        console.debug(this.name, "->", request);
        const result = await this.tryRouteRequest(request);
        const response = response_RpcResponse.rewrap(request.id, result);
        console.debug(this.name, "<-", response);
        tryBrowserSync(()=>{
            this.port.postMessage(JSON.stringify(response));
        }).ignore();
    }
    async onResponse(response) {
        const returned = await this.events.emit("response", [
            response
        ]);
        if (returned.isSome()) return returned.inner;
        return new err_Err(new Error("Unhandled JSON-RPC response ".concat(response)));
    }
    async onMessage(message) {
        const data = JSON.parse(message);
        if ("method" in data) return await this.onRequest(data);
        return await this.onResponse(data);
    }
    async onDisconnect() {
        await this.events.emit("close", [
            undefined
        ]);
    }
    async tryRequest(init) {
        return await Result.unthrow(async (t)=>{
            const request = this.client.create(init);
            tryBrowserSync(()=>{
                this.port.postMessage(JSON.stringify(request));
            }).throw(t);
            return tryWaitOrCloseOrError(this.events, "response", (future, init)=>{
                if (init.id !== request.id) return new none_None();
                const response = response_RpcResponse.from(init);
                future.resolve(new ok_Ok(response));
                return new some_Some(undefined);
            });
        });
    }
    constructor(name, port){
        this.name = name;
        this.port = port;
        this.client = new rpc_RpcClient();
        this.uuid = crypto.randomUUID();
        this.events = new target_SuperEventTarget();
        const onMessage = this.onMessage.bind(this);
        const onDisconnect = this.onDisconnect.bind(this);
        this.port.onMessage.addListener(onMessage);
        this.port.onDisconnect.addListener(onDisconnect);
        this.clean = ()=>{
            this.port.onMessage.removeListener(onMessage);
            this.port.onDisconnect.removeListener(onDisconnect);
        };
    }
}

;// CONCATENATED MODULE: ./src/libs/fetch/fetch.ts

async function tryFetch(input, init) {
    try {
        const res = await fetch(input, init);
        if (!res.ok) return new Err(new Error(await res.text()));
        return new Ok(res);
    } catch (e) {
        return new Err(Catched.from(e));
    }
}
async function tryFetchAsJson(input, init) {
    try {
        const res = await fetch(input, init);
        if (!res.ok) return new err_Err(new Error(await res.text()));
        return new ok_Ok(await res.json());
    } catch (e) {
        return new err_Err(errors_Catched.from(e));
    }
}
async function tryFetchAsBlob(input, init) {
    try {
        const res = await fetch(input, init);
        if (!res.ok) return new err_Err(new Error(await res.text()));
        return new ok_Ok(await res.blob());
    } catch (e) {
        return new err_Err(errors_Catched.from(e));
    }
}

;// CONCATENATED MODULE: ./node_modules/@hazae41/arrays/dist/esm/mods/arrays/arrays.mjs
/**
 * Get the last value
 * @param array
 * @returns
 */
function last(array) {
    if (array.length === 0)
        return undefined;
    return array[lastIndex(array)];
}
/**
 * Get the last index
 * @param array
 * @returns
 */
function lastIndex(array) {
    return array.length - 1;
}
/**
 * Get a random value using Math's PRNG
 * @param array
 * @returns
 */
function random(array) {
    if (array.length === 0)
        return undefined;
    return array[randomIndex(array)];
}
/**
 * Get a random index using Math's PRNG
 * @param array
 * @returns
 */
function randomIndex(array) {
    return Math.floor(Math.random() * array.length);
}
/**
 * Get a random value using WebCrypto's CSPRNG
 * @param array
 * @returns
 */
function cryptoRandom(array) {
    if (array.length === 0)
        return undefined;
    return array[cryptoRandomIndex(array)];
}
/**
 * Get a random value using WebCrypto's CSPRNG
 * @param array
 * @returns
 */
function cryptoRandomIndex(array) {
    const values = new Uint32Array(1);
    crypto.getRandomValues(values);
    return values[0] % array.length;
}
/**
 * Get a random value using Math's PRNG and delete it from the array
 * @param array
 * @returns
 */
function takeRandom(array) {
    if (array.length === 0)
        return undefined;
    const index = randomIndex(array);
    const element = array[index];
    array.splice(index, 1);
    return element;
}
/**
 * Get a random value using WebCrypto's CSPRNG and delete it from the array
 * @param array
 * @returns
 */
function takeCryptoRandom(array) {
    if (array.length === 0)
        return undefined;
    const index = cryptoRandomIndex(array);
    const element = array[index];
    array.splice(index, 1);
    return element;
}


//# sourceMappingURL=arrays.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/piscine/dist/esm/libs/signals/signals.mjs
var AbortSignals;
(function (AbortSignals) {
    function timeout(delay, parent) {
        return merge(AbortSignal.timeout(delay), parent);
    }
    AbortSignals.timeout = timeout;
    function merge(a, b) {
        if (b === undefined)
            return a;
        const c = new AbortController();
        const onAbort = (reason) => {
            c.abort(reason);
            a.removeEventListener("abort", onAbort);
            b.removeEventListener("abort", onAbort);
        };
        a.addEventListener("abort", onAbort, { passive: true });
        b.addEventListener("abort", onAbort, { passive: true });
        return c.signal;
    }
    AbortSignals.merge = merge;
})(AbortSignals || (AbortSignals = {}));


//# sourceMappingURL=signals.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/piscine/dist/esm/mods/pool/pool.mjs





var PoolOkEntry;
(function (PoolOkEntry) {
    function is(x) {
        return x.result.isOk();
    }
    PoolOkEntry.is = is;
})(PoolOkEntry || (PoolOkEntry = {}));
class EmptyPoolError extends Error {
    #class = EmptyPoolError;
    name = this.#class.name;
    constructor() {
        super(`Empty pool`);
    }
}
class EmptySlotError extends Error {
    #class = EmptySlotError;
    name = this.#class.name;
    constructor() {
        super(`Empty pool slot`);
    }
}
class Pool {
    create;
    params;
    events = new target_SuperEventTarget();
    capacity;
    signal;
    #controller;
    #allEntries;
    #allCleanups;
    #allPromises;
    #okEntries = new Set();
    /**
     * A pool of circuits
     * @param tor
     * @param params
     */
    constructor(create, params = {}) {
        this.create = create;
        this.params = params;
        const { capacity = 3 } = params;
        this.capacity = capacity;
        this.#controller = new AbortController();
        this.signal = AbortSignals.merge(this.#controller.signal, params.signal);
        this.#allEntries = new Array(capacity);
        this.#allCleanups = new Array(capacity);
        this.#allPromises = new Array(capacity);
        for (let index = 0; index < capacity; index++)
            this.#start(index);
    }
    abort(reason) {
        this.#controller.abort(reason);
    }
    #start(index) {
        const promise = this.#createAndUnwrap(index);
        this.#allPromises[index] = promise;
        promise.catch(e => console.debug({ e }));
    }
    async #tryCreate(index) {
        const { signal } = this;
        if (signal.aborted)
            return new err_Err(errors_AbortedError.from(signal.reason));
        return await this.create({ pool: this, index, signal });
    }
    async #createAndUnwrap(index) {
        const result = await Result.recatch(() => this.#tryCreate(index));
        if (result.isOk()) {
            const ok = new ok_Ok(result.inner.inner);
            const clean = () => result.inner.clean();
            const entry = { index, result: ok };
            this.#allEntries[index] = entry;
            this.#allCleanups[index] = clean;
            this.#okEntries.add(entry);
            this.events.emit("created", [entry]).catch(e => console.error({ e }));
        }
        else {
            const entry = { index, result };
            this.#allEntries[index] = entry;
            this.events.emit("created", [entry]).catch(e => console.error({ e }));
        }
        return result.clear().unwrap();
    }
    /**
     * Delete the index, restart the index, and return the entry
     * @param element
     * @returns
     */
    delete(index) {
        const entry = this.#allEntries.at(index);
        if (entry === undefined)
            return undefined;
        if (PoolOkEntry.is(entry)) {
            this.#okEntries.delete(entry);
            this.#allCleanups[index]();
            delete this.#allCleanups[index];
        }
        delete this.#allEntries[index];
        this.#start(index);
        this.events.emit("deleted", [entry]).catch(e => console.error({ e }));
        return entry;
    }
    /**
     * Number of open elements
     */
    get size() {
        return this.#okEntries.size;
    }
    /**
     * Iterator on open elements
     * @returns
     */
    [Symbol.iterator]() {
        return this.#okEntries.values();
    }
    /**
     * Get the element at index
     * @param index
     * @returns
     */
    async tryGet(index) {
        try {
            await this.#allPromises[index];
        }
        catch (e) { }
        return this.tryGetSync(index).unwrap();
    }
    /**
     * Get the element at index
     * @param index
     * @returns
     */
    tryGetSync(index) {
        const entry = this.#allEntries.at(index);
        if (entry === undefined)
            return new err_Err(new EmptySlotError());
        return new ok_Ok(entry.result);
    }
    /**
     * Wait for any element to be created, then get a random one using Math's PRNG
     * @returns
     */
    async tryGetRandom() {
        return await Result
            .catchAndWrap(() => Promise.any(this.#allPromises))
            .then(r => r.mapErrSync(e => e.cause))
            .then(r => r.mapSync(() => this.tryGetRandomSync().unwrap()));
    }
    /**
     * Get a random element from the pool using Math's PRNG, throws if none available
     * @returns
     */
    tryGetRandomSync() {
        if (!this.#okEntries.size)
            return new err_Err(new EmptyPoolError());
        const entries = [...this.#okEntries];
        const entry = random(entries);
        return new ok_Ok(entry);
    }
    /**
     * Wait for any circuit to be created, then get a random one using WebCrypto's CSPRNG
     * @returns
     */
    async tryGetCryptoRandom() {
        return await Result
            .catchAndWrap(() => Promise.any(this.#allPromises))
            .then(r => r.mapErrSync(e => e.cause))
            .then(r => r.mapSync(() => this.tryGetCryptoRandomSync().unwrap()));
    }
    /**
     * Get a random circuit from the pool using WebCrypto's CSPRNG, throws if none available
     * @returns
     */
    tryGetCryptoRandomSync() {
        if (!this.#okEntries.size)
            return new err_Err(new EmptyPoolError());
        const entries = [...this.#okEntries];
        const entry = cryptoRandom(entries);
        return new ok_Ok(entry);
    }
    static async takeRandom(pool) {
        return await pool.lock(async (pool) => {
            const result = await pool.tryGetRandom();
            if (result.isOk())
                pool.delete(result.inner.index);
            return result;
        });
    }
    static async takeCryptoRandom(pool) {
        return await pool.lock(async (pool) => {
            const result = await pool.tryGetCryptoRandom();
            if (result.isOk())
                pool.delete(result.inner.index);
            return result;
        });
    }
}


//# sourceMappingURL=pool.mjs.map

;// CONCATENATED MODULE: ./src/mods/background/content_script/index.ts









const mouse = {
    x: window.screen.width / 2,
    y: window.screen.height / 2
};
addEventListener("mousemove", (e)=>{
    mouse.x = e.screenX;
    mouse.y = e.screenY;
}, {
    passive: true
});
if (false || true) {
    const container = document.documentElement;
    const scriptBody = atob("LyoqKioqKi8gKCgpID0+IHsgLy8gd2VicGFja0Jvb3RzdHJhcAovKioqKioqLyAJInVzZSBzdHJpY3QiOwp2YXIgX193ZWJwYWNrX2V4cG9ydHNfXyA9IHt9OwoKOy8vIENPTkNBVEVOQVRFRCBNT0RVTEU6IC4vbm9kZV9tb2R1bGVzL0BoYXphZTQxL3Jlc3VsdC9kaXN0L2VzbS9tb2RzL2RlYnVnL2RlYnVnLm1qcwp2YXIgRGVidWc7CihmdW5jdGlvbiAoRGVidWcpIHsKICAgIERlYnVnLmRlYnVnID0gZmFsc2U7Cn0pKERlYnVnIHx8IChEZWJ1ZyA9IHt9KSk7CgoKLy8jIHNvdXJjZU1hcHBpbmdVUkw9ZGVidWcubWpzLm1hcAoKOy8vIENPTkNBVEVOQVRFRCBNT0RVTEU6IC4vbm9kZV9tb2R1bGVzL0BoYXphZTQxL3Jlc3VsdC9kaXN0L2VzbS9tb2RzL3Jlc3VsdC9lcnJvcnMubWpzCmNsYXNzIFVuaW1wbGVtZW50ZWQgZXh0ZW5kcyAoLyogdW51c2VkIHB1cmUgZXhwcmVzc2lvbiBvciBzdXBlciAqLyBudWxsICYmIChFcnJvcikpIHsKICAgICNjbGFzcyA9IFVuaW1wbGVtZW50ZWQ7CiAgICBuYW1lID0gdGhpcy4jY2xhc3MubmFtZTsKfQpjbGFzcyBQYW5pYyBleHRlbmRzIEVycm9yIHsKICAgICNjbGFzcyA9IFBhbmljOwogICAgbmFtZSA9IHRoaXMuI2NsYXNzLm5hbWU7CiAgICBzdGF0aWMgZnJvbShjYXVzZSkgewogICAgICAgIHJldHVybiBuZXcgUGFuaWModW5kZWZpbmVkLCB7IGNhdXNlIH0pOwogICAgfQogICAgc3RhdGljIGZyb21BbmRUaHJvdyhjYXVzZSkgewogICAgICAgIHRocm93IFBhbmljLmZyb20oY2F1c2UpOwogICAgfQp9CmNsYXNzIENhdGNoZWQgZXh0ZW5kcyAoLyogdW51c2VkIHB1cmUgZXhwcmVzc2lvbiBvciBzdXBlciAqLyBudWxsICYmIChFcnJvcikpIHsKICAgICNjbGFzcyA9IENhdGNoZWQ7CiAgICBuYW1lID0gdGhpcy4jY2xhc3MubmFtZTsKICAgIHN0YXRpYyBmcm9tKGNhdXNlKSB7CiAgICAgICAgcmV0dXJuIG5ldyBDYXRjaGVkKHVuZGVmaW5lZCwgeyBjYXVzZSB9KTsKICAgIH0KICAgIHN0YXRpYyBmcm9tQW5kVGhyb3coY2F1c2UpIHsKICAgICAgICB0aHJvdyBDYXRjaGVkLmZyb20oY2F1c2UpOwogICAgfQp9CgoKLy8jIHNvdXJjZU1hcHBpbmdVUkw9ZXJyb3JzLm1qcy5tYXAKCjsvLyBDT05DQVRFTkFURUQgTU9EVUxFOiAuL25vZGVfbW9kdWxlcy9AaGF6YWU0MS9yZXN1bHQvZGlzdC9lc20vbW9kcy9yZXN1bHQvZXJyLm1qcwoKCgoKY2xhc3MgRXJyIHsKICAgICNpbm5lcjsKICAgICN0aW1lb3V0OwogICAgLyoqCiAgICAgKiBBIGZhaWx1cmUKICAgICAqIEBwYXJhbSBpbm5lcgogICAgICovCiAgICBjb25zdHJ1Y3Rvcihpbm5lcikgewogICAgICAgIHRoaXMuI2lubmVyID0gaW5uZXI7CiAgICAgICAgaWYgKCFEZWJ1Zy5kZWJ1ZykKICAgICAgICAgICAgcmV0dXJuOwogICAgICAgIGNvbnN0IGVycm9yID0gbmV3IFBhbmljKGBVbmhhbmRsZWQgcmVzdWx0YCwgeyBjYXVzZTogdGhpcyB9KTsKICAgICAgICB0aGlzLiN0aW1lb3V0ID0gc2V0VGltZW91dChhc3luYyAoKSA9PiB7IHRocm93IGVycm9yOyB9LCAxMDAwKTsKICAgIH0KICAgIC8qKgogICAgICogQ3JlYXRlIGFuIGVtcHR5IGBFcnJgCiAgICAgKiBAcmV0dXJucyBgRXJyKHZvaWQpYAogICAgICovCiAgICBzdGF0aWMgdm9pZCgpIHsKICAgICAgICByZXR1cm4gbmV3IEVycih1bmRlZmluZWQpOwogICAgfQogICAgLyoqCiAgICAgKiBDcmVhdGUgYW4gYEVycmAKICAgICAqIEBwYXJhbSBpbm5lcgogICAgICogQHJldHVybnMgYEVycihpbm5lcilgCiAgICAgKi8KICAgIHN0YXRpYyBuZXcoaW5uZXIpIHsKICAgICAgICByZXR1cm4gbmV3IEVycihpbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIENyZWF0ZSBhbiBgRXJyYCB3aXRoIGFuIGBFcnJvcmAgaW5zaWRlCiAgICAgKiBAcGFyYW0gbWVzc2FnZQogICAgICogQHBhcmFtIG9wdGlvbnMKICAgICAqIEByZXR1cm5zIGBFcnI8RXJyb3I+YAogICAgICovCiAgICBzdGF0aWMgZXJyb3IobWVzc2FnZSwgb3B0aW9ucykgewogICAgICAgIHJldHVybiBuZXcgRXJyKG5ldyBFcnJvcihtZXNzYWdlLCBvcHRpb25zKSk7CiAgICB9CiAgICBnZXQgaW5uZXIoKSB7CiAgICAgICAgcmV0dXJuIHRoaXMuI2lubmVyOwogICAgfQogICAgLyoqCiAgICAgKiBTZXQgdGhpcyByZXN1bHQgYXMgaGFuZGxlZAogICAgICovCiAgICBpZ25vcmUoKSB7CiAgICAgICAgaWYgKCF0aGlzLiN0aW1lb3V0KQogICAgICAgICAgICByZXR1cm4gdGhpczsKICAgICAgICBjbGVhclRpbWVvdXQodGhpcy4jdGltZW91dCk7CiAgICAgICAgdGhpcy4jdGltZW91dCA9IHVuZGVmaW5lZDsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogVHlwZSBndWFyZCBmb3IgYE9rYAogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBPa2AsIGBmYWxzZWAgaWYgYEVycmAKICAgICAqLwogICAgaXNPaygpIHsKICAgICAgICByZXR1cm4gZmFsc2U7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgdHJ1ZSBpZiB0aGUgcmVzdWx0IGlzIGBPa2AgYW5kIHRoZSB2YWx1ZSBpbnNpZGUgb2YgaXQgbWF0Y2hlcyBhIHByZWRpY2F0ZQogICAgICogQHBhcmFtIG9rUHJlZGljYXRlCiAgICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYE9rYCBhbmQgYGF3YWl0IG9rUHJlZGljYXRlKHRoaXMuaW5uZXIpYCwgYGZhbHNlYCBvdGhlcndpc2UKICAgICAqLwogICAgYXN5bmMgaXNPa0FuZChva1ByZWRpY2F0ZSkgewogICAgICAgIHJldHVybiBmYWxzZTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyB0cnVlIGlmIHRoZSByZXN1bHQgaXMgYE9rYCBhbmQgdGhlIHZhbHVlIGluc2lkZSBvZiBpdCBtYXRjaGVzIGEgcHJlZGljYXRlCiAgICAgKiBAcGFyYW0gb2tQcmVkaWNhdGUKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgT2tgIGFuZCBgYXdhaXQgb2tQcmVkaWNhdGUodGhpcy5pbm5lcilgLCBgZmFsc2VgIG90aGVyd2lzZQogICAgICovCiAgICBpc09rQW5kU3luYyhva1ByZWRpY2F0ZSkgewogICAgICAgIHJldHVybiBmYWxzZTsKICAgIH0KICAgIC8qKgogICAgICogVHlwZSBndWFyZCBmb3IgYEVycmAKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgRXJyYCwgYGZhbHNlYCBpZiBgT2tgCiAgICAgKi8KICAgIGlzRXJyKCkgewogICAgICAgIHJldHVybiB0cnVlOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIHRydWUgaWYgdGhlIHJlc3VsdCBpcyBgRXJyYCBhbmQgdGhlIHZhbHVlIGluc2lkZSBvZiBpdCBtYXRjaGVzIGEgcHJlZGljYXRlCiAgICAgKiBAcGFyYW0gZXJyUHJlZGljYXRlCiAgICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYEVycmAgYW5kIGBhd2FpdCBlcnJQcmVkaWNhdGUodGhpcy5pbm5lcilgLCBgZmFsc2VgIG90aGVyd2lzZQogICAgICovCiAgICBhc3luYyBpc0VyckFuZChlcnJQcmVkaWNhdGUpIHsKICAgICAgICByZXR1cm4gYXdhaXQgZXJyUHJlZGljYXRlKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIHRydWUgaWYgdGhlIHJlc3VsdCBpcyBgRXJyYCBhbmQgdGhlIHZhbHVlIGluc2lkZSBvZiBpdCBtYXRjaGVzIGEgcHJlZGljYXRlCiAgICAgKiBAcGFyYW0gZXJyUHJlZGljYXRlCiAgICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYEVycmAgYW5kIGBhd2FpdCBlcnJQcmVkaWNhdGUodGhpcy5pbm5lcilgLCBgZmFsc2VgIG90aGVyd2lzZQogICAgICovCiAgICBpc0VyckFuZFN5bmMoZXJyUHJlZGljYXRlKSB7CiAgICAgICAgcmV0dXJuIGVyclByZWRpY2F0ZSh0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogQ29tcGlsZS10aW1lIHNhZmVseSBnZXQgYHRoaXMuaW5uZXJgCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAKICAgICAqLwogICAgZ2V0KCkgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIHRoaXMuaW5uZXI7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBgUmVzdWx0PFQsIEU+YCBpbnRvIGBPcHRpb248VD5gCiAgICAgKiBAcmV0dXJucyBgU29tZSh0aGlzLmlubmVyKWAgaWYgYE9rYCwgYE5vbmVgIGlmIGBFcnJgCiAgICAgKi8KICAgIG9rKCkgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIG5ldyBOb25lKCk7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBgUmVzdWx0PFQsIEU+YCBpbnRvIGBPcHRpb248RT5gCiAgICAgKiBAcmV0dXJucyBgU29tZSh0aGlzLmlubmVyKWAgaWYgYEVycmAsIGBOb25lYCBpZiBgT2tgCiAgICAgKi8KICAgIGVycigpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiBuZXcgU29tZSh0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBhbiBpdGVyYXRvciBvdmVyIHRoZSBwb3NzaWJseSBjb250YWluZWQgdmFsdWUKICAgICAqIEB5aWVsZHMgYHRoaXMuaW5uZXJgIGlmIGBPa2AKICAgICAqLwogICAgKltTeW1ib2wuaXRlcmF0b3JdKCkgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm0gYFJlc3VsdDxULEU+YCBpbnRvIGBbVCxFXWAKICAgICAqIEByZXR1cm5zIGBbdGhpcy5pbm5lciwgdW5kZWZpbmVkXWAgaWYgYE9rYCwgYFt1bmRlZmluZWQsIHRoaXMuaW5uZXJdYCBpZiBgRXJyYAogICAgICovCiAgICBzcGxpdCgpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiBbdW5kZWZpbmVkLCB0aGlzLmlubmVyXTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyB0cnVlIGlmIHRoZSByZXN1bHQgaXMgYW4gYE9rYCB2YWx1ZSBjb250YWluaW5nIHRoZSBnaXZlbiB2YWx1ZQogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYE9rYCBhbmQgYHRoaXMuaW5uZXIgPT09IHZhbHVlYCwgYGZhbHNlYCBvdGhlcndpc2UKICAgICAqLwogICAgY29udGFpbnModmFsdWUpIHsKICAgICAgICByZXR1cm4gZmFsc2U7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgdHJ1ZSBpZiB0aGUgcmVzdWx0IGlzIGFuIGBFcnJgIHZhbHVlIGNvbnRhaW5pbmcgdGhlIGdpdmVuIHZhbHVlCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgRXJyYCBhbmQgYHRoaXMuaW5uZXIgPT09IHZhbHVlYCwgYGZhbHNlYCBvdGhlcndpc2UKICAgICAqLwogICAgY29udGFpbnNFcnIodmFsdWUpIHsKICAgICAgICByZXR1cm4gdGhpcy5pbm5lciA9PT0gdmFsdWU7CiAgICB9CiAgICAvKioKICAgICAqIEdldCB0aGUgaW5uZXIgdmFsdWUgb3IgdGhyb3cgdG8gdGhlIGNsb3Nlc3QgYFJlc3VsdC51bnRocm93YAogICAgICogQHBhcmFtIHRocm93ZXIgVGhlIHRocm93ZXIgZnJvbSBgUmVzdWx0LnVudGhyb3dgCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAgaWYgYE9rYAogICAgICogQHRocm93cyBgdW5kZWZpbmVkYCBpZiBgRXJyYAogICAgICogQHNlZSBSZXN1bHQudW50aHJvdwogICAgICogQHNlZSBSZXN1bHQudW50aHJvd1N5bmMKICAgICAqLwogICAgdGhyb3codGhyb3dlcikgewogICAgICAgIHRocm93ZXIodGhpcyk7CiAgICAgICAgdGhyb3cgbmV3IFBhbmljKGBUaHJvd24gcmVzdWx0IHdhcyB0cnktY2F0Y2hlZGApOwogICAgfQogICAgLyoqCiAgICAgKiBHZXQgdGhlIGlubmVyIHZhbHVlIG9yIHRocm93IHRoZSBpbm5lciBlcnJvciB3cmFwcGVkIGluc2lkZSBhbm90aGVyIEVycm9yCiAgICAgKiBAcGFyYW0gbWVzc2FnZQogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBPa2AsIGBFcnJvcihtZXNzYWdlLCB7IGNhdXNlOiB0aGlzLmlubmVyIH0pYCBpZiBgRXJyYAogICAgICovCiAgICBleHBlY3QobWVzc2FnZSkgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgdGhyb3cgbmV3IFBhbmljKG1lc3NhZ2UsIHsgY2F1c2U6IHRoaXMuaW5uZXIgfSk7CiAgICB9CiAgICAvKioKICAgICAqIEdldCB0aGUgaW5uZXIgZXJyb3Igb3IgdGhyb3cgdGhlIGlubmVyIHZhbHVlIHdyYXBwZWQgaW5zaWRlIGFub3RoZXIgRXJyb3IKICAgICAqIEBwYXJhbSBtZXNzYWdlCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAgaWYgYEVycmAsIGBFcnJvcihtZXNzYWdlLCB7IGNhdXNlOiB0aGlzLmlubmVyIH0pYCBpZiBgT2tgCiAgICAgKi8KICAgIGV4cGVjdEVycihtZXNzYWdlKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gdGhpcy5pbm5lcjsKICAgIH0KICAgIC8qKgogICAgICogR2V0IHRoZSBpbm5lciB2YWx1ZSBvciB0aHJvdyB0aGUgaW5uZXIgZXJyb3IKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgT2tgCiAgICAgKiBAdGhyb3dzIGB0aGlzLmlubmVyYCBpZiBgRXJyYAogICAgICovCiAgICB1bndyYXAoKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICB0aHJvdyBuZXcgUGFuaWModW5kZWZpbmVkLCB7IGNhdXNlOiB0aGlzLmlubmVyIH0pOwogICAgfQogICAgLyoqCiAgICAgKiBUaHJvdyB0aGUgaW5uZXIgdmFsdWUgb3IgZ2V0IHRoZSBpbm5lciBlcnJvcgogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBFcnJgCiAgICAgKiBAdGhyb3dzIGB0aGlzLmlubmVyYCBpZiBgT2tgCiAgICAgKi8KICAgIHVud3JhcEVycigpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiB0aGlzLmlubmVyOwogICAgfQogICAgLyoqCiAgICAgKiBHZXQgdGhlIGlubmVyIHZhbHVlIG9yIGEgZGVmYXVsdCBvbmUKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBPa2AsIGB2YWx1ZWAgaWYgYEVycmAKICAgICAqLwogICAgdW53cmFwT3IodmFsdWUpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiB2YWx1ZTsKICAgIH0KICAgIC8qKgogICAgICogR2V0IHRoZSBpbm5lciB2YWx1ZSBvciBjb21wdXRlIGEgZGVmYXVsdCBvbmUgZnJvbSB0aGUgaW5uZXIgZXJyb3IKICAgICAqIEBwYXJhbSBlcnJNYXBwZXIKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgT2tgLCBgYXdhaXQgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgRXJyYAogICAgICogQHRocm93cyBpZiBgYXdhaXQgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgYXN5bmMgdW53cmFwT3JFbHNlKGVyck1hcHBlcikgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIGF3YWl0IGVyck1hcHBlcih0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogR2V0IHRoZSBpbm5lciB2YWx1ZSBvciBjb21wdXRlIGEgZGVmYXVsdCBvbmUgZnJvbSB0aGUgaW5uZXIgZXJyb3IKICAgICAqIEBwYXJhbSBlcnJNYXBwZXIKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgT2tgLCBgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgRXJyYAogICAgICogQHRocm93cyBpZiBgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgdW53cmFwT3JFbHNlU3luYyhlcnJNYXBwZXIpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiBlcnJNYXBwZXIodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBSZXN1bHQ8UHJvbWlzZTxUPiwgRT4gaW50byBQcm9taXNlPFJlc3VsdDxULCBFPj4KICAgICAqIEByZXR1cm5zIGBhd2FpdCB0aGlzLmlubmVyYCBpZiBgT2tgLCBgdGhpc2AgaWYgYEVycmAKICAgICAqLwogICAgYXN5bmMgYXdhaXQoKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBSZXN1bHQ8VCwgUHJvbWlzZTxFPj4gaW50byBQcm9taXNlPFJlc3VsdDxULCBFPj4KICAgICAqIEByZXR1cm5zIGBhd2FpdCB0aGlzLmlubmVyYCBpZiBgRXJyYCwgYHRoaXNgIGlmIGBPa2AKICAgICAqLwogICAgYXN5bmMgYXdhaXRFcnIoKSB7CiAgICAgICAgcmV0dXJuIG5ldyBFcnIoYXdhaXQgdGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBSZXN1bHQ8UHJvbWlzZTxUPiwgUHJvbWlzZTxFPj4gaW50byBQcm9taXNlPFJlc3VsdDxULCBFPj4KICAgICAqIEByZXR1cm5zIGBhd2FpdCB0aGlzLmlubmVyYAogICAgICovCiAgICBhc3luYyBhd2FpdEFsbCgpIHsKICAgICAgICByZXR1cm4gYXdhaXQgdGhpcy5hd2FpdEVycigpOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm0gYFJlc3VsdDxULCBFPmAgaW50byBgUmVzdWx0PHZvaWQsIEU+YAogICAgICogQHJldHVybnMgYE9rPHZvaWQ+YCBpZiBgT2s8VD5gLCBgRXJyPEU+YCBpZiBgRTxFPmAKICAgICAqLwogICAgY2xlYXIoKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBgUmVzdWx0PFQsIEU+YCBpbnRvIGBSZXN1bHQ8VCwgdm9pZD5gCiAgICAgKiBAcmV0dXJucyBgT2s8VD5gIGlmIGBPazxUPmAsIGBFcnI8dm9pZD5gIGlmIGBFPEU+YAogICAgICovCiAgICBjbGVhckVycigpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiBFcnIudm9pZCgpOwogICAgfQogICAgLyoqCiAgICAgKiBDYWxscyB0aGUgZ2l2ZW4gY2FsbGJhY2sgd2l0aCB0aGUgaW5uZXIgdmFsdWUgaWYgYE9rYAogICAgICogQHBhcmFtIG9rQ2FsbGJhY2sKICAgICAqIEByZXR1cm5zIGB0aGlzYAogICAgICovCiAgICBhc3luYyBpbnNwZWN0KG9rQ2FsbGJhY2spIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogQ2FsbHMgdGhlIGdpdmVuIGNhbGxiYWNrIHdpdGggdGhlIGlubmVyIHZhbHVlIGlmIGBPa2AKICAgICAqIEBwYXJhbSBva0NhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgdGhpc2AKICAgICAqLwogICAgaW5zcGVjdFN5bmMob2tDYWxsYmFjaykgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBDYWxscyB0aGUgZ2l2ZW4gY2FsbGJhY2sgd2l0aCB0aGUgaW5uZXIgdmFsdWUgaWYgYEVycmAKICAgICAqIEBwYXJhbSBlcnJDYWxsYmFjawogICAgICogQHJldHVybnMgYHRoaXNgCiAgICAgKi8KICAgIGFzeW5jIGluc3BlY3RFcnIoZXJyQ2FsbGJhY2spIHsKICAgICAgICBhd2FpdCBlcnJDYWxsYmFjayh0aGlzLmlubmVyKTsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogQ2FsbHMgdGhlIGdpdmVuIGNhbGxiYWNrIHdpdGggdGhlIGlubmVyIHZhbHVlIGlmIGBFcnJgCiAgICAgKiBAcGFyYW0gZXJyQ2FsbGJhY2sKICAgICAqIEByZXR1cm5zIGB0aGlzYAogICAgICovCiAgICBpbnNwZWN0RXJyU3luYyhlcnJDYWxsYmFjaykgewogICAgICAgIGVyckNhbGxiYWNrKHRoaXMuaW5uZXIpOwogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm4gYSBuZXcgYE9rYCBidXQgd2l0aCB0aGUgZ2l2ZW4gYGlubmVyYAogICAgICogQHBhcmFtIGlubmVyCiAgICAgKiBAcmV0dXJucyBgT2soaW5uZXIpYCBpZiBgT2tgLCBgdGhpc2AgaWYgYEVycmAKICAgICAqLwogICAgc2V0KGlubmVyKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybiBhIG5ldyBgRXJyYCBidXQgd2l0aCB0aGUgZ2l2ZW4gYGlubmVyYAogICAgICogQHBhcmFtIGlubmVyCiAgICAgKiBAcmV0dXJucyBgRXJyKGlubmVyKWAgaWYgYEVycmAsIGB0aGlzYCBpZiBgT2tgCiAgICAgKi8KICAgIHNldEVycihpbm5lcikgewogICAgICAgIHJldHVybiBuZXcgRXJyKGlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogTWFwIHRoZSBpbm5lciB2YWx1ZSBpbnRvIGFub3RoZXIKICAgICAqIEBwYXJhbSBva01hcHBlcgogICAgICogQHJldHVybnMgYE9rKGF3YWl0IG9rTWFwcGVyKHRoaXMuaW5uZXIpKWAgaWYgYE9rYCwgYHRoaXNgIGlmIGBFcnJgCiAgICAgKiBAdGhyb3dzIGlmIGBhd2FpdCBva01hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIGFzeW5jIG1hcChva01hcHBlcikgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBNYXAgdGhlIGlubmVyIHZhbHVlIGludG8gYW5vdGhlcgogICAgICogQHBhcmFtIG9rTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgT2sob2tNYXBwZXIodGhpcy5pbm5lcikpYCBpZiBgT2tgLCBgdGhpc2AgaWYgYEVycmAKICAgICAqIEB0aHJvd3MgaWYgYG9rTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgbWFwU3luYyhva01hcHBlcikgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBNYXAgdGhlIGlubmVyIGVycm9yIGludG8gYW5vdGhlcgogICAgICogQHBhcmFtIGVyck1hcHBlcgogICAgICogQHJldHVybnMgYEVycihhd2FpdCBlcnJNYXBwZXIodGhpcy5pbm5lcikpYCBpZiBgRXJyYCwgYHRoaXNgIGlmIGBPa2AKICAgICAqIEB0aHJvd3MgaWYgYGF3YWl0IGVyck1hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIGFzeW5jIG1hcEVycihlcnJNYXBwZXIpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiBuZXcgRXJyKGF3YWl0IGVyck1hcHBlcih0aGlzLmlubmVyKSk7CiAgICB9CiAgICAvKioKICAgICAqIE1hcCB0aGUgaW5uZXIgZXJyb3IgaW50byBhbm90aGVyCiAgICAgKiBAcGFyYW0gZXJyTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgRXJyKGVyck1hcHBlcih0aGlzLmlubmVyKSlgIGlmIGBFcnJgLCBgdGhpc2AgaWYgYE9rYAogICAgICogQHRocm93cyBpZiBgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgbWFwRXJyU3luYyhlcnJNYXBwZXIpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiBuZXcgRXJyKGVyck1hcHBlcih0aGlzLmlubmVyKSk7CiAgICB9CiAgICAvKioKICAgICAqIE1hcCB0aGUgaW5uZXIgdmFsdWUgaW50byBhbm90aGVyLCBvciBhIGRlZmF1bHQgb25lCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEBwYXJhbSBva01hcHBlcgogICAgICogQHJldHVybnMgYGF3YWl0IG9rTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgT2tgLCBgdmFsdWVgIGlmIGBFcnJgCiAgICAgKiBAdGhyb3dzIGlmIGBhd2FpdCBva01hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIGFzeW5jIG1hcE9yKHZhbHVlLCBva01hcHBlcikgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIHZhbHVlOwogICAgfQogICAgLyoqCiAgICAgKiBNYXAgdGhlIGlubmVyIHZhbHVlIGludG8gYW5vdGhlciwgb3IgYSBkZWZhdWx0IG9uZQogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcGFyYW0gb2tNYXBwZXIKICAgICAqIEByZXR1cm5zIGBva01hcHBlcih0aGlzLmlubmVyKWAgaWYgYE9rYCwgYHZhbHVlYCBpZiBgRXJyYAogICAgICogQHRocm93cyBpZiBgb2tNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICBtYXBPclN5bmModmFsdWUsIG9rTWFwcGVyKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gdmFsdWU7CiAgICB9CiAgICAvKioKICAgICAqIE1hcCB0aGUgaW5uZXIgdmFsdWUgaW50byBhbm90aGVyLCBvciBhIGRlZmF1bHQgb25lCiAgICAgKiBAcGFyYW0gZXJyTWFwcGVyCiAgICAgKiBAcGFyYW0gb2tNYXBwZXIKICAgICAqIEByZXR1cm5zIGBhd2FpdCBva01hcHBlcih0aGlzLmlubmVyKWAgaWYgYE9rYCwgYGF3YWl0IGVyck1hcHBlcih0aGlzLmlubmVyKWAgaWYgYEVycmAKICAgICAqIEB0aHJvd3MgaWYgYGF3YWl0IG9rTWFwcGVyKHRoaXMuaW5uZXIpYCBvciBgYXdhaXQgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgYXN5bmMgbWFwT3JFbHNlKGVyck1hcHBlciwgb2tNYXBwZXIpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiBhd2FpdCBlcnJNYXBwZXIodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIE1hcCB0aGUgaW5uZXIgdmFsdWUgaW50byBhbm90aGVyLCBvciBhIGRlZmF1bHQgb25lCiAgICAgKiBAcGFyYW0gZXJyTWFwcGVyCiAgICAgKiBAcGFyYW0gb2tNYXBwZXIKICAgICAqIEByZXR1cm5zIGBva01hcHBlcih0aGlzLmlubmVyKWAgaWYgYE9rYCwgYGVyck1hcHBlcih0aGlzLmlubmVyKWAgaWYgYEVycmAKICAgICAqIEB0aHJvd3MgaWYgYG9rTWFwcGVyKHRoaXMuaW5uZXIpYCBvciBgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgbWFwT3JFbHNlU3luYyhlcnJNYXBwZXIsIG9rTWFwcGVyKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gZXJyTWFwcGVyKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm4gYHZhbHVlYCBpZiBgT2tgLCByZXR1cm4gYHRoaXNgIGlmIGBFcnJgCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEByZXR1cm5zIGB2YWx1ZWAgaWYgYE9rYCwgYHRoaXNgIGlmIGBFcnJgCiAgICAgKi8KICAgIGFuZCh2YWx1ZSkgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm4gYGF3YWl0IG9rTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgT2tgLCByZXR1cm4gYHRoaXNgIGlmIGBFcnJgCiAgICAgKiBAcGFyYW0gb2tNYXBwZXIKICAgICAqIEByZXR1cm5zIGBhd2FpdCBva01hcHBlcih0aGlzLmlubmVyKWAgaWYgYE9rYCwgYHRoaXNgIGlmIGBFcnJgCiAgICAgKiBAdGhyb3dzIGlmIGBhd2FpdCBva01hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIGFzeW5jIGFuZFRoZW4ob2tNYXBwZXIpIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJuIGBva01hcHBlcih0aGlzLmlubmVyKWAgaWYgYE9rYCwgcmV0dXJuIGB0aGlzYCBpZiBgRXJyYAogICAgICogQHBhcmFtIG9rTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgb2tNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBPa2AsIGB0aGlzYCBpZiBgRXJyYAogICAgICogQHRocm93cyBpZiBgb2tNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICBhbmRUaGVuU3luYyhva01hcHBlcikgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm4gYHZhbHVlYCBpZiBgRXJyYCwgcmV0dXJuIGB0aGlzYCBpZiBgT2tgCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEByZXR1cm5zIGB2YWx1ZWAgaWYgYEVycmAsIGB0aGlzYCBpZiBgT2tgCiAgICAgKi8KICAgIG9yKHZhbHVlKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gdmFsdWU7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybiBgYXdhaXQgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgRXJyYCwgcmV0dXJuIGB0aGlzYCBpZiBgT2tgCiAgICAgKiBAcGFyYW0gZXJyTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgYXdhaXQgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgRXJyYCwgYHRoaXNgIGlmIGBPa2AKICAgICAqIEB0aHJvd3MgaWYgYGF3YWl0IGVyck1hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIGFzeW5jIG9yRWxzZShlcnJNYXBwZXIpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiBhd2FpdCBlcnJNYXBwZXIodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybiBgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgRXJyYCwgcmV0dXJuIGB0aGlzYCBpZiBgT2tgCiAgICAgKiBAcGFyYW0gZXJyTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgRXJyYCwgYHRoaXNgIGlmIGBPa2AKICAgICAqIEB0aHJvd3MgaWYgYGVyck1hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIG9yRWxzZVN5bmMoZXJyTWFwcGVyKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gZXJyTWFwcGVyKHRoaXMuaW5uZXIpOwogICAgfQp9CgoKLy8jIHNvdXJjZU1hcHBpbmdVUkw9ZXJyLm1qcy5tYXAKCjsvLyBDT05DQVRFTkFURUQgTU9EVUxFOiAuL25vZGVfbW9kdWxlcy9AaGF6YWU0MS9vcHRpb24vZGlzdC9lc20vbW9kcy9vcHRpb24vbm9uZS5tanMKCgpjbGFzcyBOb25lRXJyb3IgZXh0ZW5kcyBFcnJvciB7CiAgICBjb25zdHJ1Y3RvcigpIHsKICAgICAgICBzdXBlcihgT3B0aW9uIGlzIGEgTm9uZWApOwogICAgfQp9CmNsYXNzIE5vbmUgewogICAgaW5uZXI7CiAgICAvKioKICAgICAqIEFuIGVtcHR5IHZhbHVlCiAgICAgKi8KICAgIGNvbnN0cnVjdG9yKGlubmVyID0gdW5kZWZpbmVkKSB7CiAgICAgICAgdGhpcy5pbm5lciA9IGlubmVyOwogICAgfQogICAgLyoqCiAgICAgKiBDcmVhdGUgYSBgTm9uZWAKICAgICAqIEByZXR1cm5zIGBOb25lYAogICAgICovCiAgICBzdGF0aWMgbmV3KCkgewogICAgICAgIHJldHVybiBuZXcgTm9uZSgpOwogICAgfQogICAgc3RhdGljIGZyb20oaW5pdCkgewogICAgICAgIHJldHVybiBuZXcgTm9uZSgpOwogICAgfQogICAgLyoqCiAgICAgKiBUeXBlIGd1YXJkIGZvciBgU29tZWAKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgU29tZWAsIGBmYWxzZWAgaWYgYE5vbmVgCiAgICAgKi8KICAgIGlzU29tZSgpIHsKICAgICAgICByZXR1cm4gZmFsc2U7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYHRydWVgIGlmIHRoZSBvcHRpb24gaXMgYSBgU29tZWAgYW5kIHRoZSB2YWx1ZSBpbnNpZGUgb2YgaXQgbWF0Y2hlcyBhIHByZWRpY2F0ZQogICAgICogQHBhcmFtIHNvbWVQcmVkaWNhdGUKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgU29tZWAgYW5kIGBhd2FpdCBzb21lUHJlZGljYXRlKHRoaXMuaW5uZXIpYCwgYE5vbmVgIG90aGVyd2lzZQogICAgICovCiAgICBhc3luYyBpc1NvbWVBbmQoc29tZVByZWRpY2F0ZSkgewogICAgICAgIHJldHVybiBmYWxzZTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBgdHJ1ZWAgaWYgdGhlIG9wdGlvbiBpcyBhIGBTb21lYCBhbmQgdGhlIHZhbHVlIGluc2lkZSBvZiBpdCBtYXRjaGVzIGEgcHJlZGljYXRlCiAgICAgKiBAcGFyYW0gc29tZVByZWRpY2F0ZQogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBTb21lYCBhbmQgYHNvbWVQcmVkaWNhdGUodGhpcy5pbm5lcilgLCBgTm9uZWAgb3RoZXJ3aXNlCiAgICAgKi8KICAgIGlzU29tZUFuZFN5bmMoc29tZVByZWRpY2F0ZSkgewogICAgICAgIHJldHVybiBmYWxzZTsKICAgIH0KICAgIC8qKgogICAgICogVHlwZSBndWFyZCBmb3IgYE5vbmVgCiAgICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYE5vbmVgLCBgZmFsc2VgIGlmIGBTb21lYAogICAgICovCiAgICBpc05vbmUoKSB7CiAgICAgICAgcmV0dXJuIHRydWU7CiAgICB9CiAgICAvKioKICAgICAqIENvbXBpbGUtdGltZSBzYWZlbHkgZ2V0IGB0aGlzLmlubmVyYAogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgCiAgICAgKi8KICAgIGdldCgpIHsKICAgICAgICByZXR1cm4gdGhpcy5pbm5lcjsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBhbiBpdGVyYXRvciBvdmVyIHRoZSBwb3NzaWJseSBjb250YWluZWQgdmFsdWUKICAgICAqIEB5aWVsZHMgYHRoaXMuaW5uZXJgIGlmIGBTb21lYAogICAgICovCiAgICAqW1N5bWJvbC5pdGVyYXRvcl0oKSB7CiAgICAgICAgcmV0dXJuOwogICAgfQogICAgLyoqCiAgICAgKiBHZXQgdGhlIGlubmVyIHZhbHVlIGlmIGBTb21lYCwgdGhyb3cgYEVycm9yKG1lc3NhZ2UpYCBvdGhlcndpc2UKICAgICAqIEBwYXJhbSBtZXNzYWdlCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAgaWYgYFNvbWVgCiAgICAgKiBAdGhyb3dzIGBFcnJvcihtZXNzYWdlKWAgaWYgYE5vbmVgCiAgICAgKi8KICAgIGV4cGVjdChtZXNzYWdlKSB7CiAgICAgICAgdGhyb3cgbmV3IEVycm9yKG1lc3NhZ2UsIHsgY2F1c2U6IG5ldyBOb25lRXJyb3IoKSB9KTsKICAgIH0KICAgIC8qKgogICAgICogR2V0IHRoZSBpbm5lciB2YWx1ZSBvciB0aHJvdyBhIE5vbmVFcnJvcgogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBTb21lYAogICAgICogQHRocm93cyBgTm9uZUVycm9yYCBpZiBgTm9uZWAKICAgICAqLwogICAgdW53cmFwKCkgewogICAgICAgIHRocm93IG5ldyBOb25lRXJyb3IoKTsKICAgIH0KICAgIC8qKgogICAgICogR2V0IHRoZSBpbm5lciB2YWx1ZSBvciBhIGRlZmF1bHQgb25lCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgU29tZWAsIGB2YWx1ZWAgaWYgYE5vbmVgCiAgICAgKi8KICAgIHVud3JhcE9yKHZhbHVlKSB7CiAgICAgICAgcmV0dXJuIHZhbHVlOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIHRoZSBjb250YWluZWQgYFNvbWVgIHZhbHVlIG9yIGNvbXB1dGVzIGl0IGZyb20gYSBjbG9zdXJlCiAgICAgKiBAcGFyYW0gbm9uZUNhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAgaWYgYFNvbWVgLCBgYXdhaXQgbm9uZUNhbGxiYWNrKClgIGlmIGBOb25lYAogICAgICovCiAgICBhc3luYyB1bndyYXBPckVsc2Uobm9uZUNhbGxiYWNrKSB7CiAgICAgICAgcmV0dXJuIGF3YWl0IG5vbmVDYWxsYmFjaygpOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIHRoZSBjb250YWluZWQgYFNvbWVgIHZhbHVlIG9yIGNvbXB1dGVzIGl0IGZyb20gYSBjbG9zdXJlCiAgICAgKiBAcGFyYW0gbm9uZUNhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAgaWYgYFNvbWVgLCBgbm9uZUNhbGxiYWNrKClgIGlmIGBOb25lYAogICAgICovCiAgICB1bndyYXBPckVsc2VTeW5jKG5vbmVDYWxsYmFjaykgewogICAgICAgIHJldHVybiBub25lQ2FsbGJhY2soKTsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtIGBPcHRpb248VD5gIGludG8gYFJlc3VsdDxULCBOb25lRXJyb3I+YAogICAgICogQHJldHVybnMgYE9rKHRoaXMuaW5uZXIpYCBpZiBgU29tZWAsIGBFcnIoTm9uZUVycm9yKWAgaWYgYE5vbmVgCiAgICAgKi8KICAgIG9rKCkgewogICAgICAgIHJldHVybiBuZXcgRXJyKG5ldyBOb25lRXJyb3IoKSk7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBgT3B0aW9uPFQ+YCBpbnRvIGBSZXN1bHQ8VCwgRT5gCiAgICAgKiBAcGFyYW0gZXJyb3IKICAgICAqIEByZXR1cm5zIGBPayh0aGlzLmlubmVyKWAgaWYgYFNvbWVgLCBgRXJyKGVycm9yKWAgaWYgYE5vbmVgCiAgICAgKi8KICAgIG9rT3IoZXJyb3IpIHsKICAgICAgICByZXR1cm4gbmV3IEVycihlcnJvcik7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybXMgdGhlIGBPcHRpb248VD5gIGludG8gYSBgUmVzdWx0PFQsIEU+YCwgbWFwcGluZyBgU29tZSh2KWAgdG8gYE9rKHYpYCBhbmQgYE5vbmVgIHRvIGBFcnIoZXJyKCkpYAogICAgICogQHBhcmFtIG5vbmVDYWxsYmFjawogICAgICogQHJldHVybnMgYE9rKHRoaXMuaW5uZXIpYCBpZiBgU29tZWAsIGBFcnIoYXdhaXQgbm9uZUNhbGxiYWNrKCkpYCBpcyBgTm9uZWAKICAgICAqLwogICAgYXN5bmMgb2tPckVsc2Uobm9uZUNhbGxiYWNrKSB7CiAgICAgICAgcmV0dXJuIG5ldyBFcnIoYXdhaXQgbm9uZUNhbGxiYWNrKCkpOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm1zIHRoZSBgT3B0aW9uPFQ+YCBpbnRvIGEgYFJlc3VsdDxULCBFPmAsIG1hcHBpbmcgYFNvbWUodilgIHRvIGBPayh2KWAgYW5kIGBOb25lYCB0byBgRXJyKGVycigpKWAKICAgICAqIEBwYXJhbSBub25lQ2FsbGJhY2sKICAgICAqIEByZXR1cm5zIGBPayh0aGlzLmlubmVyKWAgaWYgYFNvbWVgLCBgRXJyKG5vbmVDYWxsYmFjaygpKWAgaXMgYE5vbmVgCiAgICAgKi8KICAgIG9rT3JFbHNlU3luYyhub25lQ2FsbGJhY2spIHsKICAgICAgICByZXR1cm4gbmV3IEVycihub25lQ2FsbGJhY2soKSk7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYE5vbmVgIGlmIHRoZSBvcHRpb24gaXMgYE5vbmVgLCBvdGhlcndpc2UgY2FsbHMgYHNvbWVQcmVkaWNhdGVgIHdpdGggdGhlIHdyYXBwZWQgdmFsdWUKICAgICAqIEBwYXJhbSBzb21lUHJlZGljYXRlCiAgICAgKiBAcmV0dXJucyBgU29tZWAgaWYgYFNvbWVgIGFuZCBgYXdhaXQgc29tZVByZWRpY2F0ZSh0aGlzLmlubmVyKWAsIGBOb25lYCBvdGhlcndpc2UKICAgICAqLwogICAgYXN5bmMgZmlsdGVyKHNvbWVQcmVkaWNhdGUpIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBgTm9uZWAgaWYgdGhlIG9wdGlvbiBpcyBgTm9uZWAsIG90aGVyd2lzZSBjYWxscyBgc29tZVByZWRpY2F0ZWAgd2l0aCB0aGUgd3JhcHBlZCB2YWx1ZQogICAgICogQHBhcmFtIHNvbWVQcmVkaWNhdGUKICAgICAqIEByZXR1cm5zIGBTb21lYCBpZiBgU29tZWAgYW5kIGBzb21lUHJlZGljYXRlKHRoaXMuaW5uZXIpYCwgYE5vbmVgIG90aGVyd2lzZQogICAgICovCiAgICBmaWx0ZXJTeW5jKHNvbWVQcmVkaWNhdGUpIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtIGBPcHRpb248UHJvbWlzZTxUPj5gIGludG8gYFByb21pc2U8T3B0aW9uPFQ+PmAKICAgICAqIEByZXR1cm5zIGBQcm9taXNlPE9wdGlvbjxUPj5gCiAgICAgKi8KICAgIGFzeW5jIGF3YWl0KCkgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGB0cnVlYCBpZiB0aGUgb3B0aW9uIGlzIGEgYFNvbWVgIHZhbHVlIGNvbnRhaW5pbmcgdGhlIGdpdmVuIHZhbHVlCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgU29tZWAgYW5kIGB0aGlzLmlubmVyID09PSB2YWx1ZWAsIGBOb25lYCBvdGhlcndpc2UKICAgICAqLwogICAgY29udGFpbnModmFsdWUpIHsKICAgICAgICByZXR1cm4gZmFsc2U7CiAgICB9CiAgICAvKioKICAgICAqIENhbGxzIHRoZSBnaXZlbiBjYWxsYmFjayB3aXRoIHRoZSBpbm5lciB2YWx1ZSBpZiBgT2tgCiAgICAgKiBAcGFyYW0gc29tZUNhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgdGhpc2AKICAgICAqLwogICAgYXN5bmMgaW5zcGVjdChzb21lQ2FsbGJhY2spIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogQ2FsbHMgdGhlIGdpdmVuIGNhbGxiYWNrIHdpdGggdGhlIGlubmVyIHZhbHVlIGlmIGBPa2AKICAgICAqIEBwYXJhbSBzb21lQ2FsbGJhY2sKICAgICAqIEByZXR1cm5zIGB0aGlzYAogICAgICovCiAgICBpbnNwZWN0U3luYyhzb21lQ2FsbGJhY2spIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogTWFwcyBhbiBgT3B0aW9uPFQ+YCB0byBgT3B0aW9uPFU+YCBieSBhcHBseWluZyBhIGZ1bmN0aW9uIHRvIGEgY29udGFpbmVkIHZhbHVlIChpZiBgU29tZWApIG9yIHJldHVybnMgYE5vbmVgIChpZiBgTm9uZWApCiAgICAgKiBAcGFyYW0gc29tZU1hcHBlcgogICAgICogQHJldHVybnMgYFNvbWUoYXdhaXQgc29tZU1hcHBlcih0aGlzLmlubmVyKSlgIGlmIGBTb21lYCwgYHRoaXNgIGlmIGBOb25lYAogICAgICovCiAgICBhc3luYyBtYXAoc29tZU1hcHBlcikgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBNYXBzIGFuIGBPcHRpb248VD5gIHRvIGBPcHRpb248VT5gIGJ5IGFwcGx5aW5nIGEgZnVuY3Rpb24gdG8gYSBjb250YWluZWQgdmFsdWUgKGlmIGBTb21lYCkgb3IgcmV0dXJucyBgTm9uZWAgKGlmIGBOb25lYCkKICAgICAqIEBwYXJhbSBzb21lTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgU29tZShzb21lTWFwcGVyKHRoaXMuaW5uZXIpKWAgaWYgYFNvbWVgLCBgdGhpc2AgaWYgYE5vbmVgCiAgICAgKi8KICAgIG1hcFN5bmMoc29tZU1hcHBlcikgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIHRoZSBwcm92aWRlZCBkZWZhdWx0IHJlc3VsdCAoaWYgbm9uZSksIG9yIGFwcGxpZXMgYSBmdW5jdGlvbiB0byB0aGUgY29udGFpbmVkIHZhbHVlIChpZiBhbnkpCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEBwYXJhbSBzb21lTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgdmFsdWVgIGlmIGBOb25lYCwgYGF3YWl0IHNvbWVNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBTb21lYAogICAgICovCiAgICBhc3luYyBtYXBPcih2YWx1ZSwgc29tZU1hcHBlcikgewogICAgICAgIHJldHVybiB2YWx1ZTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyB0aGUgcHJvdmlkZWQgZGVmYXVsdCByZXN1bHQgKGlmIG5vbmUpLCBvciBhcHBsaWVzIGEgZnVuY3Rpb24gdG8gdGhlIGNvbnRhaW5lZCB2YWx1ZSAoaWYgYW55KQogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcGFyYW0gc29tZU1hcHBlcgogICAgICogQHJldHVybnMgYHZhbHVlYCBpZiBgTm9uZWAsIGBzb21lTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgU29tZWAKICAgICAqLwogICAgbWFwT3JTeW5jKHZhbHVlLCBzb21lTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIHZhbHVlOwogICAgfQogICAgLyoqCiAgICAgKiBDb21wdXRlcyBhIGRlZmF1bHQgZnVuY3Rpb24gcmVzdWx0IChpZiBub25lKSwgb3IgYXBwbGllcyBhIGRpZmZlcmVudCBmdW5jdGlvbiB0byB0aGUgY29udGFpbmVkIHZhbHVlIChpZiBhbnkpCiAgICAgKiBAcGFyYW0gbm9uZUNhbGxiYWNrCiAgICAgKiBAcGFyYW0gc29tZU1hcHBlcgogICAgICogQHJldHVybnMgYGF3YWl0IHNvbWVNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBTb21lYCwgYGF3YWl0IG5vbmVDYWxsYmFjaygpYCBpZiBgTm9uZWAKICAgICAqLwogICAgYXN5bmMgbWFwT3JFbHNlKG5vbmVDYWxsYmFjaywgc29tZU1hcHBlcikgewogICAgICAgIHJldHVybiBhd2FpdCBub25lQ2FsbGJhY2soKTsKICAgIH0KICAgIC8qKgogICAgICogQ29tcHV0ZXMgYSBkZWZhdWx0IGZ1bmN0aW9uIHJlc3VsdCAoaWYgbm9uZSksIG9yIGFwcGxpZXMgYSBkaWZmZXJlbnQgZnVuY3Rpb24gdG8gdGhlIGNvbnRhaW5lZCB2YWx1ZSAoaWYgYW55KQogICAgICogQHBhcmFtIG5vbmVDYWxsYmFjawogICAgICogQHBhcmFtIHNvbWVNYXBwZXIKICAgICAqIEByZXR1cm5zIGBzb21lTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgU29tZWAsIGBub25lQ2FsbGJhY2soKWAgaWYgYE5vbmVgCiAgICAgKi8KICAgIG1hcE9yRWxzZVN5bmMobm9uZUNhbGxiYWNrLCBzb21lTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIG5vbmVDYWxsYmFjaygpOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGBOb25lYCBpZiB0aGUgb3B0aW9uIGlzIGBOb25lYCwgb3RoZXJ3aXNlIHJldHVybnMgYHZhbHVlYAogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcmV0dXJucyBgTm9uZWAgaWYgYE5vbmVgLCBgdmFsdWVgIGlmIGBTb21lYAogICAgICovCiAgICBhbmQodmFsdWUpIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBgTm9uZWAgaWYgdGhlIG9wdGlvbiBpcyBgTm9uZWAsIG90aGVyd2lzZSBjYWxscyBgc29tZU1hcHBlcmAgd2l0aCB0aGUgd3JhcHBlZCB2YWx1ZSBhbmQgcmV0dXJucyB0aGUgcmVzdWx0CiAgICAgKiBAcGFyYW0gc29tZU1hcHBlcgogICAgICogQHJldHVybnMgYE5vbmVgIGlmIGBOb25lYCwgYGF3YWl0IHNvbWVNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBTb21lYAogICAgICovCiAgICBhc3luYyBhbmRUaGVuKHNvbWVNYXBwZXIpIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBgTm9uZWAgaWYgdGhlIG9wdGlvbiBpcyBgTm9uZWAsIG90aGVyd2lzZSBjYWxscyBgc29tZU1hcHBlcmAgd2l0aCB0aGUgd3JhcHBlZCB2YWx1ZSBhbmQgcmV0dXJucyB0aGUgcmVzdWx0CiAgICAgKiBAcGFyYW0gc29tZU1hcHBlcgogICAgICogQHJldHVybnMgYE5vbmVgIGlmIGBOb25lYCwgYHNvbWVNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBTb21lYAogICAgICovCiAgICBhbmRUaGVuU3luYyhzb21lTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYHRoaXNgIGlmIGBTb21lYCwgb3RoZXJ3aXNlIHJldHVybnMgYHZhbHVlYAogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcmV0dXJucyBgdGhpc2AgaWYgYFNvbWVgLCBgdmFsdWVgIGlmIGBOb25lYAogICAgICovCiAgICBvcih2YWx1ZSkgewogICAgICAgIHJldHVybiB2YWx1ZTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBgdGhpc2AgaWYgYFNvbWVgLCBvdGhlcndpc2UgY2FsbHMgYG5vbmVDYWxsYmFja2AgYW5kIHJldHVybnMgdGhlIHJlc3VsdAogICAgICogQHBhcmFtIG5vbmVDYWxsYmFjawogICAgICogQHJldHVybnMgYHRoaXNgIGlmIGBTb21lYCwgYGF3YWl0IG5vbmVDYWxsYmFjaygpYCBpZiBgTm9uZWAKICAgICAqLwogICAgYXN5bmMgb3JFbHNlKG5vbmVDYWxsYmFjaykgewogICAgICAgIHJldHVybiBhd2FpdCBub25lQ2FsbGJhY2soKTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBgdGhpc2AgaWYgYFNvbWVgLCBvdGhlcndpc2UgY2FsbHMgYG5vbmVDYWxsYmFja2AgYW5kIHJldHVybnMgdGhlIHJlc3VsdAogICAgICogQHBhcmFtIG5vbmVDYWxsYmFjawogICAgICogQHJldHVybnMgYHRoaXNgIGlmIGBTb21lYCwgYG5vbmVDYWxsYmFjaygpYCBpZiBgTm9uZWAKICAgICAqLwogICAgb3JFbHNlU3luYyhub25lQ2FsbGJhY2spIHsKICAgICAgICByZXR1cm4gbm9uZUNhbGxiYWNrKCk7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYFNvbWVgIGlmIGV4YWN0bHkgb25lIG9mIHRoZSBvcHRpb25zIGlzIGBTb21lYCwgb3RoZXJ3aXNlIHJldHVybnMgYE5vbmVgCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEByZXR1cm5zIGBOb25lYCBpZiBib3RoIGFyZSBgU29tZWAgb3IgYm90aCBhcmUgYE5vbmVgLCB0aGUgb25seSBgU29tZWAgb3RoZXJ3aXNlCiAgICAgKi8KICAgIHhvcih2YWx1ZSkgewogICAgICAgIHJldHVybiB2YWx1ZTsKICAgIH0KICAgIC8qKgogICAgICogWmlwcyBgdGhpc2Agd2l0aCBhbm90aGVyIGBPcHRpb25gCiAgICAgKiBAcGFyYW0gb3RoZXIKICAgICAqIEByZXR1cm5zIGBTb21lKFt0aGlzLmlubmVyLCBvdGhlci5pbm5lcl0pYCBpZiBib3RoIGFyZSBgU29tZWAsIGBOb25lYCBpZiBvbmUgb2YgdGhlbSBpcyBgTm9uZWAKICAgICAqLwogICAgemlwKG90aGVyKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9Cn0KCgovLyMgc291cmNlTWFwcGluZ1VSTD1ub25lLm1qcy5tYXAKCjsvLyBDT05DQVRFTkFURUQgTU9EVUxFOiAuL25vZGVfbW9kdWxlcy9AaGF6YWU0MS9vcHRpb24vZGlzdC9lc20vbW9kcy9vcHRpb24vc29tZS5tanMKCgoKY2xhc3MgU29tZSB7CiAgICBpbm5lcjsKICAgIC8qKgogICAgICogQW4gZXhpc3RpbmcgdmFsdWUKICAgICAqIEBwYXJhbSBpbm5lcgogICAgICovCiAgICBjb25zdHJ1Y3Rvcihpbm5lcikgewogICAgICAgIHRoaXMuaW5uZXIgPSBpbm5lcjsKICAgIH0KICAgIC8qKgogICAgICogQ3JlYXRlIGEgYFNvbWVgCiAgICAgKiBAcGFyYW0gaW5uZXIKICAgICAqIEByZXR1cm5zIGBTb21lKGlubmVyKWAKICAgICAqLwogICAgc3RhdGljIG5ldyhpbm5lcikgewogICAgICAgIHJldHVybiBuZXcgdGhpcyhpbm5lcik7CiAgICB9CiAgICBzdGF0aWMgZnJvbShpbml0KSB7CiAgICAgICAgcmV0dXJuIG5ldyBTb21lKGluaXQuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBUeXBlIGd1YXJkIGZvciBgU29tZWAKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgU29tZWAsIGBmYWxzZWAgaWYgYE5vbmVgCiAgICAgKi8KICAgIGlzU29tZSgpIHsKICAgICAgICByZXR1cm4gdHJ1ZTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBgdHJ1ZWAgaWYgdGhlIG9wdGlvbiBpcyBhIGBTb21lYCBhbmQgdGhlIHZhbHVlIGluc2lkZSBvZiBpdCBtYXRjaGVzIGEgcHJlZGljYXRlCiAgICAgKiBAcGFyYW0gc29tZVByZWRpY2F0ZQogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBTb21lYCBhbmQgYGF3YWl0IHNvbWVQcmVkaWNhdGUodGhpcy5pbm5lcilgLCBgTm9uZWAgb3RoZXJ3aXNlCiAgICAgKi8KICAgIGFzeW5jIGlzU29tZUFuZChzb21lUHJlZGljYXRlKSB7CiAgICAgICAgcmV0dXJuIGF3YWl0IHNvbWVQcmVkaWNhdGUodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYHRydWVgIGlmIHRoZSBvcHRpb24gaXMgYSBgU29tZWAgYW5kIHRoZSB2YWx1ZSBpbnNpZGUgb2YgaXQgbWF0Y2hlcyBhIHByZWRpY2F0ZQogICAgICogQHBhcmFtIHNvbWVQcmVkaWNhdGUKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgU29tZWAgYW5kIGBzb21lUHJlZGljYXRlKHRoaXMuaW5uZXIpYCwgYE5vbmVgIG90aGVyd2lzZQogICAgICovCiAgICBpc1NvbWVBbmRTeW5jKHNvbWVQcmVkaWNhdGUpIHsKICAgICAgICByZXR1cm4gc29tZVByZWRpY2F0ZSh0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogVHlwZSBndWFyZCBmb3IgYE5vbmVgCiAgICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYE5vbmVgLCBgZmFsc2VgIGlmIGBTb21lYAogICAgICovCiAgICBpc05vbmUoKSB7CiAgICAgICAgcmV0dXJuIGZhbHNlOwogICAgfQogICAgLyoqCiAgICAgKiBDb21waWxlLXRpbWUgc2FmZWx5IGdldCBgdGhpcy5pbm5lcmAKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYAogICAgICovCiAgICBnZXQoKSB7CiAgICAgICAgcmV0dXJuIHRoaXMuaW5uZXI7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYW4gaXRlcmF0b3Igb3ZlciB0aGUgcG9zc2libHkgY29udGFpbmVkIHZhbHVlCiAgICAgKiBAeWllbGRzIGB0aGlzLmlubmVyYCBpZiBgU29tZWAKICAgICAqLwogICAgKltTeW1ib2wuaXRlcmF0b3JdKCkgewogICAgICAgIHlpZWxkIHRoaXMuaW5uZXI7CiAgICB9CiAgICAvKioKICAgICAqIEdldCB0aGUgaW5uZXIgdmFsdWUgaWYgYFNvbWVgLCB0aHJvdyBgRXJyb3IobWVzc2FnZSlgIG90aGVyd2lzZQogICAgICogQHBhcmFtIG1lc3NhZ2UKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgU29tZWAKICAgICAqIEB0aHJvd3MgYEVycm9yKG1lc3NhZ2UpYCBpZiBgTm9uZWAKICAgICAqLwogICAgZXhwZWN0KG1lc3NhZ2UpIHsKICAgICAgICByZXR1cm4gdGhpcy5pbm5lcjsKICAgIH0KICAgIC8qKgogICAgICogR2V0IHRoZSBpbm5lciB2YWx1ZSBvciB0aHJvdyBhIE5vbmVFcnJvcgogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBTb21lYAogICAgICogQHRocm93cyBgTm9uZUVycm9yYCBpZiBgTm9uZWAKICAgICAqLwogICAgdW53cmFwKCkgewogICAgICAgIHJldHVybiB0aGlzLmlubmVyOwogICAgfQogICAgLyoqCiAgICAgKiBHZXQgdGhlIGlubmVyIHZhbHVlIG9yIGEgZGVmYXVsdCBvbmUKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBTb21lYCwgYHZhbHVlYCBpZiBgTm9uZWAKICAgICAqLwogICAgdW53cmFwT3IodmFsdWUpIHsKICAgICAgICByZXR1cm4gdGhpcy5pbm5lcjsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyB0aGUgY29udGFpbmVkIGBTb21lYCB2YWx1ZSBvciBjb21wdXRlcyBpdCBmcm9tIGEgY2xvc3VyZQogICAgICogQHBhcmFtIG5vbmVDYWxsYmFjawogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBTb21lYCwgYGF3YWl0IG5vbmVDYWxsYmFjaygpYCBpZiBgTm9uZWAKICAgICAqLwogICAgYXN5bmMgdW53cmFwT3JFbHNlKG5vbmVDYWxsYmFjaykgewogICAgICAgIHJldHVybiB0aGlzLmlubmVyOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIHRoZSBjb250YWluZWQgYFNvbWVgIHZhbHVlIG9yIGNvbXB1dGVzIGl0IGZyb20gYSBjbG9zdXJlCiAgICAgKiBAcGFyYW0gbm9uZUNhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAgaWYgYFNvbWVgLCBgbm9uZUNhbGxiYWNrKClgIGlmIGBOb25lYAogICAgICovCiAgICB1bndyYXBPckVsc2VTeW5jKG5vbmVDYWxsYmFjaykgewogICAgICAgIHJldHVybiB0aGlzLmlubmVyOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm0gYE9wdGlvbjxUPmAgaW50byBgUmVzdWx0PFQsIE5vbmVFcnJvcj5gCiAgICAgKiBAcmV0dXJucyBgT2sodGhpcy5pbm5lcilgIGlmIGBTb21lYCwgYEVycihOb25lRXJyb3IpYCBpZiBgTm9uZWAKICAgICAqLwogICAgb2soKSB7CiAgICAgICAgcmV0dXJuIG5ldyBPayh0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtIGBPcHRpb248VD5gIGludG8gYFJlc3VsdDxULCBFPmAKICAgICAqIEBwYXJhbSBlcnJvcgogICAgICogQHJldHVybnMgYE9rKHRoaXMuaW5uZXIpYCBpZiBgU29tZWAsIGBFcnIoZXJyb3IpYCBpZiBgTm9uZWAKICAgICAqLwogICAgb2tPcihlcnJvcikgewogICAgICAgIHJldHVybiBuZXcgT2sodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybXMgdGhlIGBPcHRpb248VD5gIGludG8gYSBgUmVzdWx0PFQsIEU+YCwgbWFwcGluZyBgU29tZSh2KWAgdG8gYE9rKHYpYCBhbmQgYE5vbmVgIHRvIGBFcnIoZXJyKCkpYAogICAgICogQHBhcmFtIG5vbmVDYWxsYmFjawogICAgICogQHJldHVybnMgYE9rKHRoaXMuaW5uZXIpYCBpZiBgU29tZWAsIGBFcnIoYXdhaXQgbm9uZUNhbGxiYWNrKCkpYCBpcyBgTm9uZWAKICAgICAqLwogICAgYXN5bmMgb2tPckVsc2Uobm9uZUNhbGxiYWNrKSB7CiAgICAgICAgcmV0dXJuIG5ldyBPayh0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtcyB0aGUgYE9wdGlvbjxUPmAgaW50byBhIGBSZXN1bHQ8VCwgRT5gLCBtYXBwaW5nIGBTb21lKHYpYCB0byBgT2sodilgIGFuZCBgTm9uZWAgdG8gYEVycihlcnIoKSlgCiAgICAgKiBAcGFyYW0gbm9uZUNhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgT2sodGhpcy5pbm5lcilgIGlmIGBTb21lYCwgYEVycihub25lQ2FsbGJhY2soKSlgIGlzIGBOb25lYAogICAgICovCiAgICBva09yRWxzZVN5bmMobm9uZUNhbGxiYWNrKSB7CiAgICAgICAgcmV0dXJuIG5ldyBPayh0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBgTm9uZWAgaWYgdGhlIG9wdGlvbiBpcyBgTm9uZWAsIG90aGVyd2lzZSBjYWxscyBgc29tZVByZWRpY2F0ZWAgd2l0aCB0aGUgd3JhcHBlZCB2YWx1ZQogICAgICogQHBhcmFtIHNvbWVQcmVkaWNhdGUKICAgICAqIEByZXR1cm5zIGBTb21lYCBpZiBgU29tZWAgYW5kIGBhd2FpdCBzb21lUHJlZGljYXRlKHRoaXMuaW5uZXIpYCwgYE5vbmVgIG90aGVyd2lzZQogICAgICovCiAgICBhc3luYyBmaWx0ZXIoc29tZVByZWRpY2F0ZSkgewogICAgICAgIGlmIChhd2FpdCBzb21lUHJlZGljYXRlKHRoaXMuaW5uZXIpKQogICAgICAgICAgICByZXR1cm4gdGhpczsKICAgICAgICBlbHNlCiAgICAgICAgICAgIHJldHVybiBuZXcgTm9uZSgpOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGBOb25lYCBpZiB0aGUgb3B0aW9uIGlzIGBOb25lYCwgb3RoZXJ3aXNlIGNhbGxzIGBzb21lUHJlZGljYXRlYCB3aXRoIHRoZSB3cmFwcGVkIHZhbHVlCiAgICAgKiBAcGFyYW0gc29tZVByZWRpY2F0ZQogICAgICogQHJldHVybnMgYFNvbWVgIGlmIGBTb21lYCBhbmQgYHNvbWVQcmVkaWNhdGUodGhpcy5pbm5lcilgLCBgTm9uZWAgb3RoZXJ3aXNlCiAgICAgKi8KICAgIGZpbHRlclN5bmMoc29tZVByZWRpY2F0ZSkgewogICAgICAgIGlmIChzb21lUHJlZGljYXRlKHRoaXMuaW5uZXIpKQogICAgICAgICAgICByZXR1cm4gdGhpczsKICAgICAgICBlbHNlCiAgICAgICAgICAgIHJldHVybiBuZXcgTm9uZSgpOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm0gYE9wdGlvbjxQcm9taXNlPFQ+PmAgaW50byBgUHJvbWlzZTxPcHRpb248VD4+YAogICAgICogQHJldHVybnMgYFByb21pc2U8T3B0aW9uPFQ+PmAKICAgICAqLwogICAgYXN5bmMgYXdhaXQoKSB7CiAgICAgICAgcmV0dXJuIG5ldyBTb21lKGF3YWl0IHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGB0cnVlYCBpZiB0aGUgb3B0aW9uIGlzIGEgYFNvbWVgIHZhbHVlIGNvbnRhaW5pbmcgdGhlIGdpdmVuIHZhbHVlCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgU29tZWAgYW5kIGB0aGlzLmlubmVyID09PSB2YWx1ZWAsIGBOb25lYCBvdGhlcndpc2UKICAgICAqLwogICAgY29udGFpbnModmFsdWUpIHsKICAgICAgICByZXR1cm4gdGhpcy5pbm5lciA9PT0gdmFsdWU7CiAgICB9CiAgICAvKioKICAgICAqIENhbGxzIHRoZSBnaXZlbiBjYWxsYmFjayB3aXRoIHRoZSBpbm5lciB2YWx1ZSBpZiBgT2tgCiAgICAgKiBAcGFyYW0gc29tZUNhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgdGhpc2AKICAgICAqLwogICAgYXN5bmMgaW5zcGVjdChzb21lQ2FsbGJhY2spIHsKICAgICAgICBhd2FpdCBzb21lQ2FsbGJhY2sodGhpcy5pbm5lcik7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIENhbGxzIHRoZSBnaXZlbiBjYWxsYmFjayB3aXRoIHRoZSBpbm5lciB2YWx1ZSBpZiBgT2tgCiAgICAgKiBAcGFyYW0gc29tZUNhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgdGhpc2AKICAgICAqLwogICAgaW5zcGVjdFN5bmMoc29tZUNhbGxiYWNrKSB7CiAgICAgICAgc29tZUNhbGxiYWNrKHRoaXMuaW5uZXIpOwogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBNYXBzIGFuIGBPcHRpb248VD5gIHRvIGBPcHRpb248VT5gIGJ5IGFwcGx5aW5nIGEgZnVuY3Rpb24gdG8gYSBjb250YWluZWQgdmFsdWUgKGlmIGBTb21lYCkgb3IgcmV0dXJucyBgTm9uZWAgKGlmIGBOb25lYCkKICAgICAqIEBwYXJhbSBzb21lTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgU29tZShhd2FpdCBzb21lTWFwcGVyKHRoaXMuaW5uZXIpKWAgaWYgYFNvbWVgLCBgdGhpc2AgaWYgYE5vbmVgCiAgICAgKi8KICAgIGFzeW5jIG1hcChzb21lTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIG5ldyBTb21lKGF3YWl0IHNvbWVNYXBwZXIodGhpcy5pbm5lcikpOwogICAgfQogICAgLyoqCiAgICAgKiBNYXBzIGFuIGBPcHRpb248VD5gIHRvIGBPcHRpb248VT5gIGJ5IGFwcGx5aW5nIGEgZnVuY3Rpb24gdG8gYSBjb250YWluZWQgdmFsdWUgKGlmIGBTb21lYCkgb3IgcmV0dXJucyBgTm9uZWAgKGlmIGBOb25lYCkKICAgICAqIEBwYXJhbSBzb21lTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgU29tZShzb21lTWFwcGVyKHRoaXMuaW5uZXIpKWAgaWYgYFNvbWVgLCBgdGhpc2AgaWYgYE5vbmVgCiAgICAgKi8KICAgIG1hcFN5bmMoc29tZU1hcHBlcikgewogICAgICAgIHJldHVybiBuZXcgU29tZShzb21lTWFwcGVyKHRoaXMuaW5uZXIpKTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyB0aGUgcHJvdmlkZWQgZGVmYXVsdCByZXN1bHQgKGlmIG5vbmUpLCBvciBhcHBsaWVzIGEgZnVuY3Rpb24gdG8gdGhlIGNvbnRhaW5lZCB2YWx1ZSAoaWYgYW55KQogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcGFyYW0gc29tZU1hcHBlcgogICAgICogQHJldHVybnMgYHZhbHVlYCBpZiBgTm9uZWAsIGBhd2FpdCBzb21lTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgU29tZWAKICAgICAqLwogICAgYXN5bmMgbWFwT3IodmFsdWUsIHNvbWVNYXBwZXIpIHsKICAgICAgICByZXR1cm4gYXdhaXQgc29tZU1hcHBlcih0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyB0aGUgcHJvdmlkZWQgZGVmYXVsdCByZXN1bHQgKGlmIG5vbmUpLCBvciBhcHBsaWVzIGEgZnVuY3Rpb24gdG8gdGhlIGNvbnRhaW5lZCB2YWx1ZSAoaWYgYW55KQogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcGFyYW0gc29tZU1hcHBlcgogICAgICogQHJldHVybnMgYHZhbHVlYCBpZiBgTm9uZWAsIGBzb21lTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgU29tZWAKICAgICAqLwogICAgbWFwT3JTeW5jKHZhbHVlLCBzb21lTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIHNvbWVNYXBwZXIodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIENvbXB1dGVzIGEgZGVmYXVsdCBmdW5jdGlvbiByZXN1bHQgKGlmIG5vbmUpLCBvciBhcHBsaWVzIGEgZGlmZmVyZW50IGZ1bmN0aW9uIHRvIHRoZSBjb250YWluZWQgdmFsdWUgKGlmIGFueSkKICAgICAqIEBwYXJhbSBub25lQ2FsbGJhY2sKICAgICAqIEBwYXJhbSBzb21lTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgYXdhaXQgc29tZU1hcHBlcih0aGlzLmlubmVyKWAgaWYgYFNvbWVgLCBgYXdhaXQgbm9uZUNhbGxiYWNrKClgIGlmIGBOb25lYAogICAgICovCiAgICBhc3luYyBtYXBPckVsc2Uobm9uZUNhbGxiYWNrLCBzb21lTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIGF3YWl0IHNvbWVNYXBwZXIodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIENvbXB1dGVzIGEgZGVmYXVsdCBmdW5jdGlvbiByZXN1bHQgKGlmIG5vbmUpLCBvciBhcHBsaWVzIGEgZGlmZmVyZW50IGZ1bmN0aW9uIHRvIHRoZSBjb250YWluZWQgdmFsdWUgKGlmIGFueSkKICAgICAqIEBwYXJhbSBub25lQ2FsbGJhY2sKICAgICAqIEBwYXJhbSBzb21lTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgc29tZU1hcHBlcih0aGlzLmlubmVyKWAgaWYgYFNvbWVgLCBgbm9uZUNhbGxiYWNrKClgIGlmIGBOb25lYAogICAgICovCiAgICBtYXBPckVsc2VTeW5jKG5vbmVDYWxsYmFjaywgc29tZU1hcHBlcikgewogICAgICAgIHJldHVybiBzb21lTWFwcGVyKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGBOb25lYCBpZiB0aGUgb3B0aW9uIGlzIGBOb25lYCwgb3RoZXJ3aXNlIHJldHVybnMgYHZhbHVlYAogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcmV0dXJucyBgTm9uZWAgaWYgYE5vbmVgLCBgdmFsdWVgIGlmIGBTb21lYAogICAgICovCiAgICBhbmQodmFsdWUpIHsKICAgICAgICByZXR1cm4gdmFsdWU7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYE5vbmVgIGlmIHRoZSBvcHRpb24gaXMgYE5vbmVgLCBvdGhlcndpc2UgY2FsbHMgYHNvbWVNYXBwZXJgIHdpdGggdGhlIHdyYXBwZWQgdmFsdWUgYW5kIHJldHVybnMgdGhlIHJlc3VsdAogICAgICogQHBhcmFtIHNvbWVNYXBwZXIKICAgICAqIEByZXR1cm5zIGBOb25lYCBpZiBgTm9uZWAsIGBhd2FpdCBzb21lTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgU29tZWAKICAgICAqLwogICAgYXN5bmMgYW5kVGhlbihzb21lTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIGF3YWl0IHNvbWVNYXBwZXIodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYE5vbmVgIGlmIHRoZSBvcHRpb24gaXMgYE5vbmVgLCBvdGhlcndpc2UgY2FsbHMgYHNvbWVNYXBwZXJgIHdpdGggdGhlIHdyYXBwZWQgdmFsdWUgYW5kIHJldHVybnMgdGhlIHJlc3VsdAogICAgICogQHBhcmFtIHNvbWVNYXBwZXIKICAgICAqIEByZXR1cm5zIGBOb25lYCBpZiBgTm9uZWAsIGBzb21lTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgU29tZWAKICAgICAqLwogICAgYW5kVGhlblN5bmMoc29tZU1hcHBlcikgewogICAgICAgIHJldHVybiBzb21lTWFwcGVyKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGB0aGlzYCBpZiBgU29tZWAsIG90aGVyd2lzZSByZXR1cm5zIGB2YWx1ZWAKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHJldHVybnMgYHRoaXNgIGlmIGBTb21lYCwgYHZhbHVlYCBpZiBgTm9uZWAKICAgICAqLwogICAgb3IodmFsdWUpIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBgdGhpc2AgaWYgYFNvbWVgLCBvdGhlcndpc2UgY2FsbHMgYG5vbmVDYWxsYmFja2AgYW5kIHJldHVybnMgdGhlIHJlc3VsdAogICAgICogQHBhcmFtIG5vbmVDYWxsYmFjawogICAgICogQHJldHVybnMgYHRoaXNgIGlmIGBTb21lYCwgYGF3YWl0IG5vbmVDYWxsYmFjaygpYCBpZiBgTm9uZWAKICAgICAqLwogICAgYXN5bmMgb3JFbHNlKG5vbmVDYWxsYmFjaykgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGB0aGlzYCBpZiBgU29tZWAsIG90aGVyd2lzZSBjYWxscyBgbm9uZUNhbGxiYWNrYCBhbmQgcmV0dXJucyB0aGUgcmVzdWx0CiAgICAgKiBAcGFyYW0gbm9uZUNhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgdGhpc2AgaWYgYFNvbWVgLCBgbm9uZUNhbGxiYWNrKClgIGlmIGBOb25lYAogICAgICovCiAgICBvckVsc2VTeW5jKG5vbmVDYWxsYmFjaykgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGBTb21lYCBpZiBleGFjdGx5IG9uZSBvZiB0aGUgb3B0aW9ucyBpcyBgU29tZWAsIG90aGVyd2lzZSByZXR1cm5zIGBOb25lYAogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcmV0dXJucyBgTm9uZWAgaWYgYm90aCBhcmUgYFNvbWVgIG9yIGJvdGggYXJlIGBOb25lYCwgdGhlIG9ubHkgYFNvbWVgIG90aGVyd2lzZQogICAgICovCiAgICB4b3IodmFsdWUpIHsKICAgICAgICBpZiAodmFsdWUuaXNTb21lKCkpCiAgICAgICAgICAgIHJldHVybiBuZXcgTm9uZSgpOwogICAgICAgIGVsc2UKICAgICAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIFppcHMgYHRoaXNgIHdpdGggYW5vdGhlciBgT3B0aW9uYAogICAgICogQHBhcmFtIG90aGVyCiAgICAgKiBAcmV0dXJucyBgU29tZShbdGhpcy5pbm5lciwgb3RoZXIuaW5uZXJdKWAgaWYgYm90aCBhcmUgYFNvbWVgLCBgTm9uZWAgaWYgb25lIG9mIHRoZW0gaXMgYE5vbmVgCiAgICAgKi8KICAgIHppcChvdGhlcikgewogICAgICAgIGlmIChvdGhlci5pc1NvbWUoKSkKICAgICAgICAgICAgcmV0dXJuIG5ldyBTb21lKFt0aGlzLmlubmVyLCBvdGhlci5pbm5lcl0pOwogICAgICAgIGVsc2UKICAgICAgICAgICAgcmV0dXJuIG90aGVyOwogICAgfQp9CgoKLy8jIHNvdXJjZU1hcHBpbmdVUkw9c29tZS5tanMubWFwCgo7Ly8gQ09OQ0FURU5BVEVEIE1PRFVMRTogLi9ub2RlX21vZHVsZXMvQGhhemFlNDEvcmVzdWx0L2Rpc3QvZXNtL21vZHMvcmVzdWx0L29rLm1qcwoKCgoKY2xhc3MgT2sgewogICAgI2lubmVyOwogICAgI3RpbWVvdXQ7CiAgICAvKioKICAgICAqIEEgc3VjY2VzcwogICAgICogQHBhcmFtIGlubmVyCiAgICAgKi8KICAgIGNvbnN0cnVjdG9yKGlubmVyKSB7CiAgICAgICAgdGhpcy4jaW5uZXIgPSBpbm5lcjsKICAgICAgICBpZiAoIURlYnVnLmRlYnVnKQogICAgICAgICAgICByZXR1cm47CiAgICAgICAgY29uc3QgZXJyb3IgPSBuZXcgUGFuaWMoYFVuaGFuZGxlZCByZXN1bHRgLCB7IGNhdXNlOiB0aGlzIH0pOwogICAgICAgIHRoaXMuI3RpbWVvdXQgPSBzZXRUaW1lb3V0KGFzeW5jICgpID0+IHsgdGhyb3cgZXJyb3I7IH0sIDEwMDApOwogICAgfQogICAgLyoqCiAgICAgKiBDcmVhdGUgYW4gZW1wdHkgYE9rYAogICAgICogQHJldHVybnMgYE9rKHZvaWQpYAogICAgICovCiAgICBzdGF0aWMgdm9pZCgpIHsKICAgICAgICByZXR1cm4gbmV3IE9rKHVuZGVmaW5lZCk7CiAgICB9CiAgICAvKioKICAgICAqIENyZWF0ZSBhbiBgT2tgCiAgICAgKiBAcGFyYW0gaW5uZXIKICAgICAqIEByZXR1cm5zIGBPayhpbm5lcilgCiAgICAgKi8KICAgIHN0YXRpYyBuZXcoaW5uZXIpIHsKICAgICAgICByZXR1cm4gbmV3IE9rKGlubmVyKTsKICAgIH0KICAgIGdldCBpbm5lcigpIHsKICAgICAgICByZXR1cm4gdGhpcy4jaW5uZXI7CiAgICB9CiAgICAvKioKICAgICAqIFNldCB0aGlzIHJlc3VsdCBhcyBoYW5kbGVkCiAgICAgKi8KICAgIGlnbm9yZSgpIHsKICAgICAgICBpZiAoIXRoaXMuI3RpbWVvdXQpCiAgICAgICAgICAgIHJldHVybiB0aGlzOwogICAgICAgIGNsZWFyVGltZW91dCh0aGlzLiN0aW1lb3V0KTsKICAgICAgICB0aGlzLiN0aW1lb3V0ID0gdW5kZWZpbmVkOwogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBUeXBlIGd1YXJkIGZvciBgT2tgCiAgICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYE9rYCwgYGZhbHNlYCBpZiBgRXJyYAogICAgICovCiAgICBpc09rKCkgewogICAgICAgIHJldHVybiB0cnVlOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIHRydWUgaWYgdGhlIHJlc3VsdCBpcyBgT2tgIGFuZCB0aGUgdmFsdWUgaW5zaWRlIG9mIGl0IG1hdGNoZXMgYSBwcmVkaWNhdGUKICAgICAqIEBwYXJhbSBva1ByZWRpY2F0ZQogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBPa2AgYW5kIGBhd2FpdCBva1ByZWRpY2F0ZSh0aGlzLmlubmVyKWAsIGBmYWxzZWAgb3RoZXJ3aXNlCiAgICAgKi8KICAgIGFzeW5jIGlzT2tBbmQob2tQcmVkaWNhdGUpIHsKICAgICAgICByZXR1cm4gYXdhaXQgb2tQcmVkaWNhdGUodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgdHJ1ZSBpZiB0aGUgcmVzdWx0IGlzIGBPa2AgYW5kIHRoZSB2YWx1ZSBpbnNpZGUgb2YgaXQgbWF0Y2hlcyBhIHByZWRpY2F0ZQogICAgICogQHBhcmFtIG9rUHJlZGljYXRlCiAgICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYE9rYCBhbmQgYGF3YWl0IG9rUHJlZGljYXRlKHRoaXMuaW5uZXIpYCwgYGZhbHNlYCBvdGhlcndpc2UKICAgICAqLwogICAgaXNPa0FuZFN5bmMob2tQcmVkaWNhdGUpIHsKICAgICAgICByZXR1cm4gb2tQcmVkaWNhdGUodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFR5cGUgZ3VhcmQgZm9yIGBFcnJgCiAgICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYEVycmAsIGBmYWxzZWAgaWYgYE9rYAogICAgICovCiAgICBpc0VycigpIHsKICAgICAgICByZXR1cm4gZmFsc2U7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgdHJ1ZSBpZiB0aGUgcmVzdWx0IGlzIGBFcnJgIGFuZCB0aGUgdmFsdWUgaW5zaWRlIG9mIGl0IG1hdGNoZXMgYSBwcmVkaWNhdGUKICAgICAqIEBwYXJhbSBlcnJQcmVkaWNhdGUKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgRXJyYCBhbmQgYGF3YWl0IGVyclByZWRpY2F0ZSh0aGlzLmlubmVyKWAsIGBmYWxzZWAgb3RoZXJ3aXNlCiAgICAgKi8KICAgIGFzeW5jIGlzRXJyQW5kKGVyclByZWRpY2F0ZSkgewogICAgICAgIHJldHVybiBmYWxzZTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyB0cnVlIGlmIHRoZSByZXN1bHQgaXMgYEVycmAgYW5kIHRoZSB2YWx1ZSBpbnNpZGUgb2YgaXQgbWF0Y2hlcyBhIHByZWRpY2F0ZQogICAgICogQHBhcmFtIGVyclByZWRpY2F0ZQogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBFcnJgIGFuZCBgYXdhaXQgZXJyUHJlZGljYXRlKHRoaXMuaW5uZXIpYCwgYGZhbHNlYCBvdGhlcndpc2UKICAgICAqLwogICAgaXNFcnJBbmRTeW5jKGVyclByZWRpY2F0ZSkgewogICAgICAgIHJldHVybiBmYWxzZTsKICAgIH0KICAgIC8qKgogICAgICogQ29tcGlsZS10aW1lIHNhZmVseSBnZXQgYHRoaXMuaW5uZXJgCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAKICAgICAqLwogICAgZ2V0KCkgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIHRoaXMuaW5uZXI7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBgUmVzdWx0PFQsIEU+YCBpbnRvIGBPcHRpb248VD5gCiAgICAgKiBAcmV0dXJucyBgU29tZSh0aGlzLmlubmVyKWAgaWYgYE9rYCwgYE5vbmVgIGlmIGBFcnJgCiAgICAgKi8KICAgIG9rKCkgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIG5ldyBTb21lKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm0gYFJlc3VsdDxULCBFPmAgaW50byBgT3B0aW9uPEU+YAogICAgICogQHJldHVybnMgYFNvbWUodGhpcy5pbm5lcilgIGlmIGBFcnJgLCBgTm9uZWAgaWYgYE9rYAogICAgICovCiAgICBlcnIoKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gbmV3IE5vbmUoKTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBhbiBpdGVyYXRvciBvdmVyIHRoZSBwb3NzaWJseSBjb250YWluZWQgdmFsdWUKICAgICAqIEB5aWVsZHMgYHRoaXMuaW5uZXJgIGlmIGBPa2AKICAgICAqLwogICAgKltTeW1ib2wuaXRlcmF0b3JdKCkgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgeWllbGQgdGhpcy5pbm5lcjsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtIGBSZXN1bHQ8VCxFPmAgaW50byBgW1QsRV1gCiAgICAgKiBAcmV0dXJucyBgW3RoaXMuaW5uZXIsIHVuZGVmaW5lZF1gIGlmIGBPa2AsIGBbdW5kZWZpbmVkLCB0aGlzLmlubmVyXWAgaWYgYEVycmAKICAgICAqLwogICAgc3BsaXQoKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gW3RoaXMuaW5uZXIsIHVuZGVmaW5lZF07CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgdHJ1ZSBpZiB0aGUgcmVzdWx0IGlzIGFuIGBPa2AgdmFsdWUgY29udGFpbmluZyB0aGUgZ2l2ZW4gdmFsdWUKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBPa2AgYW5kIGB0aGlzLmlubmVyID09PSB2YWx1ZWAsIGBmYWxzZWAgb3RoZXJ3aXNlCiAgICAgKi8KICAgIGNvbnRhaW5zKHZhbHVlKSB7CiAgICAgICAgcmV0dXJuIHRoaXMuaW5uZXIgPT09IHZhbHVlOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIHRydWUgaWYgdGhlIHJlc3VsdCBpcyBhbiBgRXJyYCB2YWx1ZSBjb250YWluaW5nIHRoZSBnaXZlbiB2YWx1ZQogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYEVycmAgYW5kIGB0aGlzLmlubmVyID09PSB2YWx1ZWAsIGBmYWxzZWAgb3RoZXJ3aXNlCiAgICAgKi8KICAgIGNvbnRhaW5zRXJyKHZhbHVlKSB7CiAgICAgICAgcmV0dXJuIGZhbHNlOwogICAgfQogICAgLyoqCiAgICAgKiBKdXN0IGxpa2UgYHVud3JhcGAgYnV0IGl0IHRocm93cyB0byB0aGUgY2xvc2VzdCBgUmVzdWx0LnVudGhyb3dgCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAgaWYgYE9rYAogICAgICogQHRocm93cyBgdGhpc2AgaWYgYEVycmAKICAgICAqIEBzZWUgUmVzdWx0LnVudGhyb3cKICAgICAqIEBzZWUgUmVzdWx0LnVudGhyb3dTeW5jCiAgICAgKi8KICAgIHRocm93KHRocm93ZXIpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiB0aGlzLmlubmVyOwogICAgfQogICAgLyoqCiAgICAgKiBHZXQgdGhlIGlubmVyIHZhbHVlIG9yIHRocm93IHRoZSBpbm5lciBlcnJvciB3cmFwcGVkIGluc2lkZSBhbm90aGVyIEVycm9yCiAgICAgKiBAcGFyYW0gbWVzc2FnZQogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBPa2AsIGBFcnJvcihtZXNzYWdlLCB7IGNhdXNlOiB0aGlzLmlubmVyIH0pYCBpZiBgRXJyYAogICAgICovCiAgICBleHBlY3QobWVzc2FnZSkgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIHRoaXMuaW5uZXI7CiAgICB9CiAgICAvKioKICAgICAqIEdldCB0aGUgaW5uZXIgZXJyb3Igb3IgdGhyb3cgdGhlIGlubmVyIHZhbHVlIHdyYXBwZWQgaW5zaWRlIGFub3RoZXIgRXJyb3IKICAgICAqIEBwYXJhbSBtZXNzYWdlCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAgaWYgYEVycmAsIGBFcnJvcihtZXNzYWdlLCB7IGNhdXNlOiB0aGlzLmlubmVyIH0pYCBpZiBgT2tgCiAgICAgKi8KICAgIGV4cGVjdEVycihtZXNzYWdlKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICB0aHJvdyBuZXcgUGFuaWMobWVzc2FnZSwgeyBjYXVzZTogdGhpcy5pbm5lciB9KTsKICAgIH0KICAgIC8qKgogICAgICogR2V0IHRoZSBpbm5lciB2YWx1ZSBvciB0aHJvdyB0aGUgaW5uZXIgZXJyb3IKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgT2tgCiAgICAgKiBAdGhyb3dzIGB0aGlzLmlubmVyYCBpZiBgRXJyYAogICAgICovCiAgICB1bndyYXAoKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gdGhpcy5pbm5lcjsKICAgIH0KICAgIC8qKgogICAgICogVGhyb3cgdGhlIGlubmVyIHZhbHVlIG9yIGdldCB0aGUgaW5uZXIgZXJyb3IKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgRXJyYAogICAgICogQHRocm93cyBgdGhpcy5pbm5lcmAgaWYgYE9rYAogICAgICovCiAgICB1bndyYXBFcnIoKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICB0aHJvdyBuZXcgUGFuaWModW5kZWZpbmVkLCB7IGNhdXNlOiB0aGlzLmlubmVyIH0pOwogICAgfQogICAgLyoqCiAgICAgKiBHZXQgdGhlIGlubmVyIHZhbHVlIG9yIGEgZGVmYXVsdCBvbmUKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBPa2AsIGB2YWx1ZWAgaWYgYEVycmAKICAgICAqLwogICAgdW53cmFwT3IodmFsdWUpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiB0aGlzLmlubmVyOwogICAgfQogICAgLyoqCiAgICAgKiBHZXQgdGhlIGlubmVyIHZhbHVlIG9yIGNvbXB1dGUgYSBkZWZhdWx0IG9uZSBmcm9tIHRoZSBpbm5lciBlcnJvcgogICAgICogQHBhcmFtIGVyck1hcHBlcgogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBPa2AsIGBhd2FpdCBlcnJNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBFcnJgCiAgICAgKiBAdGhyb3dzIGlmIGBhd2FpdCBlcnJNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICBhc3luYyB1bndyYXBPckVsc2UoZXJyTWFwcGVyKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gdGhpcy5pbm5lcjsKICAgIH0KICAgIC8qKgogICAgICogR2V0IHRoZSBpbm5lciB2YWx1ZSBvciBjb21wdXRlIGEgZGVmYXVsdCBvbmUgZnJvbSB0aGUgaW5uZXIgZXJyb3IKICAgICAqIEBwYXJhbSBlcnJNYXBwZXIKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgT2tgLCBgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgRXJyYAogICAgICogQHRocm93cyBpZiBgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgdW53cmFwT3JFbHNlU3luYyhlcnJNYXBwZXIpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiB0aGlzLmlubmVyOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm0gUmVzdWx0PFByb21pc2U8VD4sIEU+IGludG8gUHJvbWlzZTxSZXN1bHQ8VCwgRT4+CiAgICAgKiBAcmV0dXJucyBgYXdhaXQgdGhpcy5pbm5lcmAgaWYgYE9rYCwgYHRoaXNgIGlmIGBFcnJgCiAgICAgKi8KICAgIGFzeW5jIGF3YWl0KCkgewogICAgICAgIHJldHVybiBuZXcgT2soYXdhaXQgdGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBSZXN1bHQ8VCwgUHJvbWlzZTxFPj4gaW50byBQcm9taXNlPFJlc3VsdDxULCBFPj4KICAgICAqIEByZXR1cm5zIGBhd2FpdCB0aGlzLmlubmVyYCBpZiBgRXJyYCwgYHRoaXNgIGlmIGBPa2AKICAgICAqLwogICAgYXN5bmMgYXdhaXRFcnIoKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBSZXN1bHQ8UHJvbWlzZTxUPiwgUHJvbWlzZTxFPj4gaW50byBQcm9taXNlPFJlc3VsdDxULCBFPj4KICAgICAqIEByZXR1cm5zIGBhd2FpdCB0aGlzLmlubmVyYAogICAgICovCiAgICBhc3luYyBhd2FpdEFsbCgpIHsKICAgICAgICByZXR1cm4gYXdhaXQgdGhpcy5hd2FpdCgpOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm0gYFJlc3VsdDxULCBFPmAgaW50byBgUmVzdWx0PHZvaWQsIEU+YAogICAgICogQHJldHVybnMgYE9rPHZvaWQ+YCBpZiBgT2s8VD5gLCBgRXJyPEU+YCBpZiBgRTxFPmAKICAgICAqLwogICAgY2xlYXIoKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gT2sudm9pZCgpOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm0gYFJlc3VsdDxULCBFPmAgaW50byBgUmVzdWx0PFQsIHZvaWQ+YAogICAgICogQHJldHVybnMgYE9rPFQ+YCBpZiBgT2s8VD5gLCBgRXJyPHZvaWQ+YCBpZiBgRTxFPmAKICAgICAqLwogICAgY2xlYXJFcnIoKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIENhbGxzIHRoZSBnaXZlbiBjYWxsYmFjayB3aXRoIHRoZSBpbm5lciB2YWx1ZSBpZiBgT2tgCiAgICAgKiBAcGFyYW0gb2tDYWxsYmFjawogICAgICogQHJldHVybnMgYHRoaXNgCiAgICAgKi8KICAgIGFzeW5jIGluc3BlY3Qob2tDYWxsYmFjaykgewogICAgICAgIGF3YWl0IG9rQ2FsbGJhY2sodGhpcy5pbm5lcik7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIENhbGxzIHRoZSBnaXZlbiBjYWxsYmFjayB3aXRoIHRoZSBpbm5lciB2YWx1ZSBpZiBgT2tgCiAgICAgKiBAcGFyYW0gb2tDYWxsYmFjawogICAgICogQHJldHVybnMgYHRoaXNgCiAgICAgKi8KICAgIGluc3BlY3RTeW5jKG9rQ2FsbGJhY2spIHsKICAgICAgICBva0NhbGxiYWNrKHRoaXMuaW5uZXIpOwogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBDYWxscyB0aGUgZ2l2ZW4gY2FsbGJhY2sgd2l0aCB0aGUgaW5uZXIgdmFsdWUgaWYgYEVycmAKICAgICAqIEBwYXJhbSBlcnJDYWxsYmFjawogICAgICogQHJldHVybnMgYHRoaXNgCiAgICAgKi8KICAgIGFzeW5jIGluc3BlY3RFcnIoZXJyQ2FsbGJhY2spIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogQ2FsbHMgdGhlIGdpdmVuIGNhbGxiYWNrIHdpdGggdGhlIGlubmVyIHZhbHVlIGlmIGBFcnJgCiAgICAgKiBAcGFyYW0gZXJyQ2FsbGJhY2sKICAgICAqIEByZXR1cm5zIGB0aGlzYAogICAgICovCiAgICBpbnNwZWN0RXJyU3luYyhlcnJDYWxsYmFjaykgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm4gYSBuZXcgYE9rYCBidXQgd2l0aCB0aGUgZ2l2ZW4gYGlubmVyYAogICAgICogQHBhcmFtIGlubmVyCiAgICAgKiBAcmV0dXJucyBgT2soaW5uZXIpYCBpZiBgT2tgLCBgdGhpc2AgaWYgYEVycmAKICAgICAqLwogICAgc2V0KGlubmVyKSB7CiAgICAgICAgcmV0dXJuIG5ldyBPayhpbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybiBhIG5ldyBgRXJyYCBidXQgd2l0aCB0aGUgZ2l2ZW4gYGlubmVyYAogICAgICogQHBhcmFtIGlubmVyCiAgICAgKiBAcmV0dXJucyBgRXJyKGlubmVyKWAgaWYgYEVycmAsIGB0aGlzYCBpZiBgT2tgCiAgICAgKi8KICAgIHNldEVycihpbm5lcikgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBNYXAgdGhlIGlubmVyIHZhbHVlIGludG8gYW5vdGhlcgogICAgICogQHBhcmFtIG9rTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgT2soYXdhaXQgb2tNYXBwZXIodGhpcy5pbm5lcikpYCBpZiBgT2tgLCBgdGhpc2AgaWYgYEVycmAKICAgICAqIEB0aHJvd3MgaWYgYGF3YWl0IG9rTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgYXN5bmMgbWFwKG9rTWFwcGVyKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gbmV3IE9rKGF3YWl0IG9rTWFwcGVyKHRoaXMuaW5uZXIpKTsKICAgIH0KICAgIC8qKgogICAgICogTWFwIHRoZSBpbm5lciB2YWx1ZSBpbnRvIGFub3RoZXIKICAgICAqIEBwYXJhbSBva01hcHBlcgogICAgICogQHJldHVybnMgYE9rKG9rTWFwcGVyKHRoaXMuaW5uZXIpKWAgaWYgYE9rYCwgYHRoaXNgIGlmIGBFcnJgCiAgICAgKiBAdGhyb3dzIGlmIGBva01hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIG1hcFN5bmMob2tNYXBwZXIpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiBuZXcgT2sob2tNYXBwZXIodGhpcy5pbm5lcikpOwogICAgfQogICAgLyoqCiAgICAgKiBNYXAgdGhlIGlubmVyIGVycm9yIGludG8gYW5vdGhlcgogICAgICogQHBhcmFtIGVyck1hcHBlcgogICAgICogQHJldHVybnMgYEVycihhd2FpdCBlcnJNYXBwZXIodGhpcy5pbm5lcikpYCBpZiBgRXJyYCwgYHRoaXNgIGlmIGBPa2AKICAgICAqIEB0aHJvd3MgaWYgYGF3YWl0IGVyck1hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIGFzeW5jIG1hcEVycihlcnJNYXBwZXIpIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogTWFwIHRoZSBpbm5lciBlcnJvciBpbnRvIGFub3RoZXIKICAgICAqIEBwYXJhbSBlcnJNYXBwZXIKICAgICAqIEByZXR1cm5zIGBFcnIoZXJyTWFwcGVyKHRoaXMuaW5uZXIpKWAgaWYgYEVycmAsIGB0aGlzYCBpZiBgT2tgCiAgICAgKiBAdGhyb3dzIGlmIGBlcnJNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICBtYXBFcnJTeW5jKGVyck1hcHBlcikgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBNYXAgdGhlIGlubmVyIHZhbHVlIGludG8gYW5vdGhlciwgb3IgYSBkZWZhdWx0IG9uZQogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcGFyYW0gb2tNYXBwZXIKICAgICAqIEByZXR1cm5zIGBhd2FpdCBva01hcHBlcih0aGlzLmlubmVyKWAgaWYgYE9rYCwgYHZhbHVlYCBpZiBgRXJyYAogICAgICogQHRocm93cyBpZiBgYXdhaXQgb2tNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICBhc3luYyBtYXBPcih2YWx1ZSwgb2tNYXBwZXIpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiBhd2FpdCBva01hcHBlcih0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogTWFwIHRoZSBpbm5lciB2YWx1ZSBpbnRvIGFub3RoZXIsIG9yIGEgZGVmYXVsdCBvbmUKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHBhcmFtIG9rTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgb2tNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBPa2AsIGB2YWx1ZWAgaWYgYEVycmAKICAgICAqIEB0aHJvd3MgaWYgYG9rTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgbWFwT3JTeW5jKHZhbHVlLCBva01hcHBlcikgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIG9rTWFwcGVyKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBNYXAgdGhlIGlubmVyIHZhbHVlIGludG8gYW5vdGhlciwgb3IgYSBkZWZhdWx0IG9uZQogICAgICogQHBhcmFtIGVyck1hcHBlcgogICAgICogQHBhcmFtIG9rTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgYXdhaXQgb2tNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBPa2AsIGBhd2FpdCBlcnJNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBFcnJgCiAgICAgKiBAdGhyb3dzIGlmIGBhd2FpdCBva01hcHBlcih0aGlzLmlubmVyKWAgb3IgYGF3YWl0IGVyck1hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIGFzeW5jIG1hcE9yRWxzZShlcnJNYXBwZXIsIG9rTWFwcGVyKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gYXdhaXQgb2tNYXBwZXIodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIE1hcCB0aGUgaW5uZXIgdmFsdWUgaW50byBhbm90aGVyLCBvciBhIGRlZmF1bHQgb25lCiAgICAgKiBAcGFyYW0gZXJyTWFwcGVyCiAgICAgKiBAcGFyYW0gb2tNYXBwZXIKICAgICAqIEByZXR1cm5zIGBva01hcHBlcih0aGlzLmlubmVyKWAgaWYgYE9rYCwgYGVyck1hcHBlcih0aGlzLmlubmVyKWAgaWYgYEVycmAKICAgICAqIEB0aHJvd3MgaWYgYG9rTWFwcGVyKHRoaXMuaW5uZXIpYCBvciBgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgbWFwT3JFbHNlU3luYyhlcnJNYXBwZXIsIG9rTWFwcGVyKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gb2tNYXBwZXIodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybiBgdmFsdWVgIGlmIGBPa2AsIHJldHVybiBgdGhpc2AgaWYgYEVycmAKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHJldHVybnMgYHZhbHVlYCBpZiBgT2tgLCBgdGhpc2AgaWYgYEVycmAKICAgICAqLwogICAgYW5kKHZhbHVlKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gdmFsdWU7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybiBgYXdhaXQgb2tNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBPa2AsIHJldHVybiBgdGhpc2AgaWYgYEVycmAKICAgICAqIEBwYXJhbSBva01hcHBlcgogICAgICogQHJldHVybnMgYGF3YWl0IG9rTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgT2tgLCBgdGhpc2AgaWYgYEVycmAKICAgICAqIEB0aHJvd3MgaWYgYGF3YWl0IG9rTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgYXN5bmMgYW5kVGhlbihva01hcHBlcikgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIGF3YWl0IG9rTWFwcGVyKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm4gYG9rTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgT2tgLCByZXR1cm4gYHRoaXNgIGlmIGBFcnJgCiAgICAgKiBAcGFyYW0gb2tNYXBwZXIKICAgICAqIEByZXR1cm5zIGBva01hcHBlcih0aGlzLmlubmVyKWAgaWYgYE9rYCwgYHRoaXNgIGlmIGBFcnJgCiAgICAgKiBAdGhyb3dzIGlmIGBva01hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIGFuZFRoZW5TeW5jKG9rTWFwcGVyKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gb2tNYXBwZXIodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybiBgdmFsdWVgIGlmIGBFcnJgLCByZXR1cm4gYHRoaXNgIGlmIGBPa2AKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHJldHVybnMgYHZhbHVlYCBpZiBgRXJyYCwgYHRoaXNgIGlmIGBPa2AKICAgICAqLwogICAgb3IodmFsdWUpIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJuIGBhd2FpdCBlcnJNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBFcnJgLCByZXR1cm4gYHRoaXNgIGlmIGBPa2AKICAgICAqIEBwYXJhbSBlcnJNYXBwZXIKICAgICAqIEByZXR1cm5zIGBhd2FpdCBlcnJNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBFcnJgLCBgdGhpc2AgaWYgYE9rYAogICAgICogQHRocm93cyBpZiBgYXdhaXQgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgYXN5bmMgb3JFbHNlKGVyck1hcHBlcikgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm4gYGVyck1hcHBlcih0aGlzLmlubmVyKWAgaWYgYEVycmAsIHJldHVybiBgdGhpc2AgaWYgYE9rYAogICAgICogQHBhcmFtIGVyck1hcHBlcgogICAgICogQHJldHVybnMgYGVyck1hcHBlcih0aGlzLmlubmVyKWAgaWYgYEVycmAsIGB0aGlzYCBpZiBgT2tgCiAgICAgKiBAdGhyb3dzIGlmIGBlcnJNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICBvckVsc2VTeW5jKGVyck1hcHBlcikgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQp9CgoKLy8jIHNvdXJjZU1hcHBpbmdVUkw9b2subWpzLm1hcAoKOy8vIENPTkNBVEVOQVRFRCBNT0RVTEU6IC4vc3JjL2xpYnMvcnBjL29rLnRzCgp2YXIgUnBjT2tJbml0OwooZnVuY3Rpb24oUnBjT2tJbml0KSB7CiAgICBmdW5jdGlvbiBjbG9uZShpbml0KSB7CiAgICAgICAgY29uc3QgeyBqc29ucnBjLCBpZCwgcmVzdWx0IH0gPSBpbml0OwogICAgICAgIHJldHVybiB7CiAgICAgICAgICAgIGpzb25ycGMsCiAgICAgICAgICAgIGlkLAogICAgICAgICAgICByZXN1bHQKICAgICAgICB9OwogICAgfQogICAgUnBjT2tJbml0LmNsb25lID0gY2xvbmU7Cn0pKFJwY09rSW5pdCB8fCAoUnBjT2tJbml0ID0ge30pKTsKKGZ1bmN0aW9uKFJwY09rSW5pdCkgewogICAgZnVuY3Rpb24gZnJvbShyZXNwb25zZSkgewogICAgICAgIGNvbnN0IHsganNvbnJwYywgaWQsIHJlc3VsdCB9ID0gcmVzcG9uc2U7CiAgICAgICAgcmV0dXJuIHsKICAgICAgICAgICAganNvbnJwYywKICAgICAgICAgICAgaWQsCiAgICAgICAgICAgIHJlc3VsdAogICAgICAgIH07CiAgICB9CiAgICBScGNPa0luaXQuZnJvbSA9IGZyb207Cn0pKFJwY09rSW5pdCB8fCAoUnBjT2tJbml0ID0ge30pKTsKY2xhc3MgUnBjT2sgZXh0ZW5kcyBPayB7CiAgICBzdGF0aWMgZnJvbShpbml0KSB7CiAgICAgICAgcmV0dXJuIG5ldyBScGNPayhpbml0LmlkLCBpbml0LnJlc3VsdCk7CiAgICB9CiAgICBjb25zdHJ1Y3RvcihpZCwgcmVzdWx0KXsKICAgICAgICBzdXBlcihyZXN1bHQpOwogICAgICAgIHRoaXMuaWQgPSBpZDsKICAgICAgICB0aGlzLnJlc3VsdCA9IHJlc3VsdDsKICAgICAgICB0aGlzLmpzb25ycGMgPSAiMi4wIjsKICAgIH0KfQoKOy8vIENPTkNBVEVOQVRFRCBNT0RVTEU6IC4vc3JjL2xpYnMvcnBjL3JlcXVlc3QudHMKdmFyIFJwY1JlcXVlc3RJbml0OwooZnVuY3Rpb24oUnBjUmVxdWVzdEluaXQpIHsKICAgIGZ1bmN0aW9uIGNsb25lKGluaXQpIHsKICAgICAgICBjb25zdCB7IGlkLCBtZXRob2QsIHBhcmFtcyB9ID0gaW5pdDsKICAgICAgICByZXR1cm4gewogICAgICAgICAgICBpZCwKICAgICAgICAgICAgbWV0aG9kLAogICAgICAgICAgICBwYXJhbXMKICAgICAgICB9OwogICAgfQogICAgUnBjUmVxdWVzdEluaXQuY2xvbmUgPSBjbG9uZTsKfSkoUnBjUmVxdWVzdEluaXQgfHwgKFJwY1JlcXVlc3RJbml0ID0ge30pKTsKY2xhc3MgUnBjUmVxdWVzdCB7CiAgICBzdGF0aWMgZnJvbShpbml0KSB7CiAgICAgICAgY29uc3QgeyBpZCwgbWV0aG9kLCBwYXJhbXMgfSA9IGluaXQ7CiAgICAgICAgcmV0dXJuIG5ldyBScGNSZXF1ZXN0KGlkLCBtZXRob2QsIHBhcmFtcyk7CiAgICB9CiAgICBjb25zdHJ1Y3RvcihpZCwgbWV0aG9kLCBwYXJhbXMpewogICAgICAgIHRoaXMuaWQgPSBpZDsKICAgICAgICB0aGlzLm1ldGhvZCA9IG1ldGhvZDsKICAgICAgICB0aGlzLnBhcmFtcyA9IHBhcmFtczsKICAgICAgICB0aGlzLmpzb25ycGMgPSAiMi4wIjsKICAgIH0KfQoKOy8vIENPTkNBVEVOQVRFRCBNT0RVTEU6IC4vc3JjL2xpYnMvcnBjL2Vyci50cwoKY2xhc3MgUnBjRXJyb3IgZXh0ZW5kcyBFcnJvciB7CiAgICBzdGF0aWMgZnJvbShlcnJvcikgewogICAgICAgIHJldHVybiBuZXcgUnBjRXJyb3IoZXJyb3IubWVzc2FnZSk7CiAgICB9CiAgICB0b0pTT04oKSB7CiAgICAgICAgY29uc3QgeyBtZXNzYWdlIH0gPSB0aGlzOwogICAgICAgIHJldHVybiB7CiAgICAgICAgICAgIG1lc3NhZ2UKICAgICAgICB9OwogICAgfQp9CmNsYXNzIFJwY0VyciBleHRlbmRzIEVyciB7CiAgICBzdGF0aWMgZnJvbShpbml0KSB7CiAgICAgICAgcmV0dXJuIG5ldyBScGNFcnIoaW5pdC5pZCwgbmV3IFJwY0Vycm9yKGluaXQuZXJyb3IubWVzc2FnZSkpOwogICAgfQogICAgY29uc3RydWN0b3IoaWQsIGVycm9yKXsKICAgICAgICBzdXBlcihlcnJvcik7CiAgICAgICAgdGhpcy5pZCA9IGlkOwogICAgICAgIHRoaXMuZXJyb3IgPSBlcnJvcjsKICAgICAgICB0aGlzLmpzb25ycGMgPSAiMi4wIjsKICAgIH0KfQoKOy8vIENPTkNBVEVOQVRFRCBNT0RVTEU6IC4vc3JjL2xpYnMvcnBjL3Jlc3BvbnNlLnRzCgoKdmFyIFJwY1Jlc3BvbnNlOwooZnVuY3Rpb24oUnBjUmVzcG9uc2UpIHsKICAgIGZ1bmN0aW9uIGZyb20oaW5pdCkgewogICAgICAgIGlmICgiZXJyb3IiIGluIGluaXQpIHJldHVybiBScGNFcnIuZnJvbShpbml0KTsKICAgICAgICByZXR1cm4gUnBjT2suZnJvbShpbml0KTsKICAgIH0KICAgIFJwY1Jlc3BvbnNlLmZyb20gPSBmcm9tOwogICAgZnVuY3Rpb24gcmV3cmFwKGlkLCByZXN1bHQpIHsKICAgICAgICByZXN1bHQuaWdub3JlKCk7CiAgICAgICAgaWYgKHJlc3VsdC5pc09rKCkpIHJldHVybiBuZXcgUnBjT2soaWQsIHJlc3VsdC5pbm5lcik7CiAgICAgICAgaWYgKHJlc3VsdC5pbm5lciBpbnN0YW5jZW9mIEVycm9yKSByZXR1cm4gbmV3IFJwY0VycihpZCwgUnBjRXJyb3IuZnJvbShyZXN1bHQuaW5uZXIpKTsKICAgICAgICByZXR1cm4gbmV3IFJwY0VycihpZCwgbmV3IFJwY0Vycm9yKCkpOwogICAgfQogICAgUnBjUmVzcG9uc2UucmV3cmFwID0gcmV3cmFwOwp9KShScGNSZXNwb25zZSB8fCAoUnBjUmVzcG9uc2UgPSB7fSkpOwoKOy8vIENPTkNBVEVOQVRFRCBNT0RVTEU6IC4vbm9kZV9tb2R1bGVzL0BoYXphZTQxL2Z1dHVyZS9kaXN0L2VzbS9tb2RzL2Z1dHVyZS9mdXR1cmUubWpzCmNsYXNzIEZ1dHVyZSB7CiAgICAjcmVzb2x2ZTsKICAgICNyZWplY3Q7CiAgICBwcm9taXNlOwogICAgLyoqCiAgICAgKiBKdXN0IGxpa2UgYSBQcm9taXNlIGJ1dCB5b3UgY2FuIG1hbnVhbGx5IHJlc29sdmUgb3IgcmVqZWN0IGl0CiAgICAgKi8KICAgIGNvbnN0cnVjdG9yKCkgewogICAgICAgIHRoaXMucHJvbWlzZSA9IG5ldyBQcm9taXNlKChzdWJyZXNvbHZlLCBzdWJyZWplY3QpID0+IHsKICAgICAgICAgICAgdGhpcy4jcmVzb2x2ZSA9IHN1YnJlc29sdmU7CiAgICAgICAgICAgIHRoaXMuI3JlamVjdCA9IHN1YnJlamVjdDsKICAgICAgICB9KTsKICAgIH0KICAgIGdldCByZXNvbHZlKCkgewogICAgICAgIHJldHVybiB0aGlzLiNyZXNvbHZlOwogICAgfQogICAgZ2V0IHJlamVjdCgpIHsKICAgICAgICByZXR1cm4gdGhpcy4jcmVqZWN0OwogICAgfQp9CgoKLy8jIHNvdXJjZU1hcHBpbmdVUkw9ZnV0dXJlLm1qcy5tYXAKCjsvLyBDT05DQVRFTkFURUQgTU9EVUxFOiAuL25vZGVfbW9kdWxlcy9AaGF6YWU0MS9jbGVhbmVyL2Rpc3QvZXNtL21vZHMvY2xlYW5lci9jbGVhbmVyLm1qcwp2YXIgQ2xlYW5hYmxlOwooZnVuY3Rpb24gKENsZWFuYWJsZSkgewogICAgYXN5bmMgZnVuY3Rpb24gcnVuV2l0aChjbGVhbmFibGUsIGNhbGxiYWNrKSB7CiAgICAgICAgdHJ5IHsKICAgICAgICAgICAgcmV0dXJuIGF3YWl0IGNhbGxiYWNrKGNsZWFuYWJsZSk7CiAgICAgICAgfQogICAgICAgIGZpbmFsbHkgewogICAgICAgICAgICBjbGVhbmFibGU/LmNsZWFuKCk7CiAgICAgICAgfQogICAgfQogICAgQ2xlYW5hYmxlLnJ1bldpdGggPSBydW5XaXRoOwogICAgZnVuY3Rpb24gcnVuV2l0aFN5bmMoY2xlYW5hYmxlLCBjYWxsYmFjaykgewogICAgICAgIHRyeSB7CiAgICAgICAgICAgIHJldHVybiBjYWxsYmFjayhjbGVhbmFibGUpOwogICAgICAgIH0KICAgICAgICBmaW5hbGx5IHsKICAgICAgICAgICAgY2xlYW5hYmxlPy5jbGVhbigpOwogICAgICAgIH0KICAgIH0KICAgIENsZWFuYWJsZS5ydW5XaXRoU3luYyA9IHJ1bldpdGhTeW5jOwp9KShDbGVhbmFibGUgPSBDbGVhbmFibGUgfHwgKENsZWFuYWJsZSA9IHt9KSk7CmNsYXNzIENsZWFuZXIgewogICAgaW5uZXI7CiAgICBjbGVhbjsKICAgIGNvbnN0cnVjdG9yKGlubmVyLCBjbGVhbikgewogICAgICAgIHRoaXMuaW5uZXIgPSBpbm5lcjsKICAgICAgICB0aGlzLmNsZWFuID0gY2xlYW47CiAgICB9Cn0KKGZ1bmN0aW9uIChDbGVhbmVyKSB7CiAgICBhc3luYyBmdW5jdGlvbiB3YWl0KGNsZWFuZXIpIHsKICAgICAgICB0cnkgewogICAgICAgICAgICByZXR1cm4gYXdhaXQgY2xlYW5lci5pbm5lcjsKICAgICAgICB9CiAgICAgICAgZmluYWxseSB7CiAgICAgICAgICAgIGNsZWFuZXIuY2xlYW4oKTsKICAgICAgICB9CiAgICB9CiAgICBDbGVhbmVyLndhaXQgPSB3YWl0OwogICAgYXN5bmMgZnVuY3Rpb24gcmFjZShjbGVhbmVycykgewogICAgICAgIGNvbnN0IHByb21pc2VzID0gbmV3IEFycmF5KGNsZWFuZXJzLmxlbmd0aCk7CiAgICAgICAgY29uc3QgY2xlYW51cHMgPSBuZXcgQXJyYXkoY2xlYW5lcnMubGVuZ3RoKTsKICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGNsZWFuZXJzLmxlbmd0aDsgaSsrKSB7CiAgICAgICAgICAgIHByb21pc2VzW2ldID0gY2xlYW5lcnNbaV0uaW5uZXI7CiAgICAgICAgICAgIGNsZWFudXBzW2ldID0gY2xlYW5lcnNbaV0uY2xlYW47CiAgICAgICAgfQogICAgICAgIHRyeSB7CiAgICAgICAgICAgIHJldHVybiBhd2FpdCBQcm9taXNlLnJhY2UocHJvbWlzZXMpOwogICAgICAgIH0KICAgICAgICBmaW5hbGx5IHsKICAgICAgICAgICAgY2xlYW51cHMuZm9yRWFjaChjbGVhbnVwID0+IGNsZWFudXAoKSk7CiAgICAgICAgfQogICAgfQogICAgQ2xlYW5lci5yYWNlID0gcmFjZTsKfSkoQ2xlYW5lciA9IENsZWFuZXIgfHwgKENsZWFuZXIgPSB7fSkpOwoKCi8vIyBzb3VyY2VNYXBwaW5nVVJMPWNsZWFuZXIubWpzLm1hcAoKOy8vIENPTkNBVEVOQVRFRCBNT0RVTEU6IC4vbm9kZV9tb2R1bGVzL0BoYXphZTQxL3BsdW1lL2Rpc3QvZXNtL21vZHMvZXJyb3JzLm1qcwoKCgoKCmNsYXNzIEFib3J0ZWRFcnJvciBleHRlbmRzIEVycm9yIHsKICAgICNjbGFzcyA9IEFib3J0ZWRFcnJvcjsKICAgIG5hbWUgPSB0aGlzLiNjbGFzcy5uYW1lOwogICAgc3RhdGljIGZyb20oY2F1c2UpIHsKICAgICAgICByZXR1cm4gbmV3IEFib3J0ZWRFcnJvcihgQWJvcnRlZGAsIHsgY2F1c2UgfSk7CiAgICB9CiAgICBzdGF0aWMgd2FpdChzaWduYWwpIHsKICAgICAgICBjb25zdCBmdXR1cmUgPSBuZXcgRnV0dXJlKCk7CiAgICAgICAgY29uc3Qgb25BYm9ydCA9IChldmVudCkgPT4gewogICAgICAgICAgICBmdXR1cmUucmVzb2x2ZShuZXcgRXJyKEFib3J0ZWRFcnJvci5mcm9tKGV2ZW50KSkpOwogICAgICAgIH07CiAgICAgICAgc2lnbmFsLmFkZEV2ZW50TGlzdGVuZXIoImFib3J0Iiwgb25BYm9ydCwgeyBwYXNzaXZlOiB0cnVlIH0pOwogICAgICAgIGNvbnN0IG9mZiA9ICgpID0+IHNpZ25hbC5yZW1vdmVFdmVudExpc3RlbmVyKCJhYm9ydCIsIG9uQWJvcnQpOwogICAgICAgIHJldHVybiBuZXcgQ2xlYW5lcihmdXR1cmUucHJvbWlzZSwgb2ZmKTsKICAgIH0KfQpjbGFzcyBFcnJvcmVkRXJyb3IgZXh0ZW5kcyBFcnJvciB7CiAgICAjY2xhc3MgPSBFcnJvcmVkRXJyb3I7CiAgICBuYW1lID0gdGhpcy4jY2xhc3MubmFtZTsKICAgIHN0YXRpYyBmcm9tKGNhdXNlKSB7CiAgICAgICAgcmV0dXJuIG5ldyBFcnJvcmVkRXJyb3IoYEVycm9yZWRgLCB7IGNhdXNlIH0pOwogICAgfQogICAgc3RhdGljIHdhaXQodGFyZ2V0KSB7CiAgICAgICAgcmV0dXJuIHRhcmdldC53YWl0KCJlcnJvciIsIChmdXR1cmUsIGV2ZW50KSA9PiB7CiAgICAgICAgICAgIGNvbnN0IGVycm9yID0gRXJyb3JlZEVycm9yLmZyb20oZXZlbnQpOwogICAgICAgICAgICBmdXR1cmUucmVzb2x2ZShuZXcgRXJyKGVycm9yKSk7CiAgICAgICAgICAgIHJldHVybiBuZXcgTm9uZSgpOwogICAgICAgIH0pOwogICAgfQp9CmNsYXNzIENsb3NlZEVycm9yIGV4dGVuZHMgRXJyb3IgewogICAgI2NsYXNzID0gQ2xvc2VkRXJyb3I7CiAgICBuYW1lID0gdGhpcy4jY2xhc3MubmFtZTsKICAgIHN0YXRpYyBmcm9tKGNhdXNlKSB7CiAgICAgICAgcmV0dXJuIG5ldyBDbG9zZWRFcnJvcihgQ2xvc2VkYCwgeyBjYXVzZSB9KTsKICAgIH0KICAgIHN0YXRpYyB3YWl0KHRhcmdldCkgewogICAgICAgIHJldHVybiB0YXJnZXQud2FpdCgiY2xvc2UiLCAoZnV0dXJlLCBldmVudCkgPT4gewogICAgICAgICAgICBjb25zdCBlcnJvciA9IENsb3NlZEVycm9yLmZyb20oZXZlbnQpOwogICAgICAgICAgICBmdXR1cmUucmVzb2x2ZShuZXcgRXJyKGVycm9yKSk7CiAgICAgICAgICAgIHJldHVybiBuZXcgTm9uZSgpOwogICAgICAgIH0pOwogICAgfQp9CgoKLy8jIHNvdXJjZU1hcHBpbmdVUkw9ZXJyb3JzLm1qcy5tYXAKCjsvLyBDT05DQVRFTkFURUQgTU9EVUxFOiAuL3NyYy9saWJzL3JwYy9ycGMudHMKCgoKCgpjbGFzcyBScGNDbGllbnQgewogICAgY3JlYXRlKGluaXQpIHsKICAgICAgICBjb25zdCB7IG1ldGhvZCwgcGFyYW1zIH0gPSBpbml0OwogICAgICAgIGNvbnN0IGlkID0gdGhpcy5pZCsrOwogICAgICAgIHJldHVybiB7CiAgICAgICAgICAgIGpzb25ycGM6ICIyLjAiLAogICAgICAgICAgICBpZCwKICAgICAgICAgICAgbWV0aG9kLAogICAgICAgICAgICBwYXJhbXMKICAgICAgICB9OwogICAgfQogICAgYXN5bmMgdHJ5RmV0Y2hXaXRoQ2lyY3VpdChpbnB1dCwgaW5pdCkgewogICAgICAgIGNvbnN0IHsgbWV0aG9kLCBwYXJhbXMsIC4uLnJlc3QgfSA9IGluaXQ7CiAgICAgICAgY29uc3QgcmVxdWVzdCA9IHRoaXMuY3JlYXRlKHsKICAgICAgICAgICAgbWV0aG9kLAogICAgICAgICAgICBwYXJhbXMKICAgICAgICB9KTsKICAgICAgICByZXR1cm4gUnBjLnRyeUZldGNoV2l0aENpcmN1aXQoaW5wdXQsIHsKICAgICAgICAgICAgLi4ucmVzdCwKICAgICAgICAgICAgLi4ucmVxdWVzdAogICAgICAgIH0pOwogICAgfQogICAgYXN5bmMgdHJ5RmV0Y2hXaXRoU29ja2V0KHNvY2tldCwgcmVxdWVzdCwgc2lnbmFsKSB7CiAgICAgICAgcmV0dXJuIGF3YWl0IFJwYy50cnlGZXRjaFdpdGhTb2NrZXQoc29ja2V0LCB0aGlzLmNyZWF0ZShyZXF1ZXN0KSwgc2lnbmFsKTsKICAgIH0KICAgIGNvbnN0cnVjdG9yKCl7CiAgICAgICAgdGhpcy5pZCA9IDA7CiAgICB9Cn0KdmFyIFJwYzsKKGZ1bmN0aW9uKFJwYykgewogICAgYXN5bmMgZnVuY3Rpb24gdHJ5RmV0Y2hXaXRoQ2lyY3VpdChpbnB1dCwgaW5pdCkgewogICAgICAgIGNvbnN0IHsgaWQsIG1ldGhvZCwgcGFyYW1zLCBjaXJjdWl0LCAuLi5yZXN0IH0gPSBpbml0OwogICAgICAgIGNvbnN0IGhlYWRlcnMgPSBuZXcgSGVhZGVycyhyZXN0LmhlYWRlcnMpOwogICAgICAgIGhlYWRlcnMuc2V0KCJDb250ZW50LVR5cGUiLCAiYXBwbGljYXRpb24vanNvbiIpOwogICAgICAgIGNvbnN0IHJlcXVlc3QgPSBuZXcgUnBjUmVxdWVzdChpZCwgbWV0aG9kLCBwYXJhbXMpOwogICAgICAgIGNvbnN0IGJvZHkgPSBKU09OLnN0cmluZ2lmeShyZXF1ZXN0KTsKICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBjaXJjdWl0LnRyeUZldGNoKGlucHV0LCB7CiAgICAgICAgICAgIC4uLnJlc3QsCiAgICAgICAgICAgIG1ldGhvZDogIlBPU1QiLAogICAgICAgICAgICBoZWFkZXJzLAogICAgICAgICAgICBib2R5CiAgICAgICAgfSk7CiAgICAgICAgaWYgKCFyZXMuaXNPaygpKSByZXR1cm4gcmVzOwogICAgICAgIGlmICghcmVzLmlubmVyLm9rKSByZXR1cm4gbmV3IEVycihuZXcgRXJyb3IoYXdhaXQgcmVzLmlubmVyLnRleHQoKSkpOwogICAgICAgIGNvbnN0IHJlc3BvbnNlID0gUnBjUmVzcG9uc2UuZnJvbShhd2FpdCByZXMuaW5uZXIuanNvbigpKTsKICAgICAgICBpZiAocmVzcG9uc2UuaWQgIT09IHJlcXVlc3QuaWQpIGNvbnNvbGUud2FybigiSW52YWxpZCByZXNwb25zZSBJRCIsIHJlc3BvbnNlLmlkLCAiZXhwZWN0ZWQiLCByZXF1ZXN0LmlkKTsKICAgICAgICByZXR1cm4gbmV3IE9rKHJlc3BvbnNlKTsKICAgIH0KICAgIFJwYy50cnlGZXRjaFdpdGhDaXJjdWl0ID0gdHJ5RmV0Y2hXaXRoQ2lyY3VpdDsKICAgIGFzeW5jIGZ1bmN0aW9uIHRyeUZldGNoV2l0aFNvY2tldChzb2NrZXQsIHJlcXVlc3QsIHNpZ25hbCkgewogICAgICAgIGNvbnN0IHsgaWQsIG1ldGhvZCwgcGFyYW1zID0gW10gfSA9IHJlcXVlc3Q7CiAgICAgICAgc29ja2V0LnNlbmQoSlNPTi5zdHJpbmdpZnkobmV3IFJwY1JlcXVlc3QoaWQsIG1ldGhvZCwgcGFyYW1zKSkpOwogICAgICAgIGNvbnN0IGZ1dHVyZSA9IG5ldyBGdXR1cmUoKTsKICAgICAgICBjb25zdCBvbk1lc3NhZ2UgPSBhc3luYyAoZXZlbnQpPT57CiAgICAgICAgICAgIGNvbnN0IG1zZ0V2ZW50ID0gZXZlbnQ7CiAgICAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gUnBjUmVzcG9uc2UuZnJvbShKU09OLnBhcnNlKG1zZ0V2ZW50LmRhdGEpKTsKICAgICAgICAgICAgaWYgKHJlc3BvbnNlLmlkICE9PSByZXF1ZXN0LmlkKSByZXR1cm47CiAgICAgICAgICAgIGZ1dHVyZS5yZXNvbHZlKG5ldyBPayhyZXNwb25zZSkpOwogICAgICAgIH07CiAgICAgICAgY29uc3Qgb25FcnJvciA9IChlKT0+ewogICAgICAgICAgICBjb25zdCByZXN1bHQgPSBuZXcgRXJyKEVycm9yZWRFcnJvci5mcm9tKGUpKTsKICAgICAgICAgICAgZnV0dXJlLnJlc29sdmUocmVzdWx0KTsKICAgICAgICB9OwogICAgICAgIGNvbnN0IG9uQ2xvc2UgPSAoZSk9PnsKICAgICAgICAgICAgY29uc3QgcmVzdWx0ID0gbmV3IEVycihDbG9zZWRFcnJvci5mcm9tKGUpKTsKICAgICAgICAgICAgZnV0dXJlLnJlc29sdmUocmVzdWx0KTsKICAgICAgICB9OwogICAgICAgIGNvbnN0IG9uQWJvcnQgPSAoKT0+ewogICAgICAgICAgICBzb2NrZXQuY2xvc2UoKTsKICAgICAgICAgICAgY29uc3QgcmVzdWx0ID0gbmV3IEVycihBYm9ydGVkRXJyb3IuZnJvbShzaWduYWwucmVhc29uKSk7CiAgICAgICAgICAgIGZ1dHVyZS5yZXNvbHZlKHJlc3VsdCk7CiAgICAgICAgfTsKICAgICAgICB0cnkgewogICAgICAgICAgICBzb2NrZXQuYWRkRXZlbnRMaXN0ZW5lcigibWVzc2FnZSIsIG9uTWVzc2FnZSwgewogICAgICAgICAgICAgICAgcGFzc2l2ZTogdHJ1ZQogICAgICAgICAgICB9KTsKICAgICAgICAgICAgc29ja2V0LmFkZEV2ZW50TGlzdGVuZXIoImNsb3NlIiwgb25DbG9zZSwgewogICAgICAgICAgICAgICAgcGFzc2l2ZTogdHJ1ZQogICAgICAgICAgICB9KTsKICAgICAgICAgICAgc29ja2V0LmFkZEV2ZW50TGlzdGVuZXIoImVycm9yIiwgb25FcnJvciwgewogICAgICAgICAgICAgICAgcGFzc2l2ZTogdHJ1ZQogICAgICAgICAgICB9KTsKICAgICAgICAgICAgc2lnbmFsLmFkZEV2ZW50TGlzdGVuZXIoImFib3J0Iiwgb25BYm9ydCwgewogICAgICAgICAgICAgICAgcGFzc2l2ZTogdHJ1ZQogICAgICAgICAgICB9KTsKICAgICAgICAgICAgcmV0dXJuIGF3YWl0IGZ1dHVyZS5wcm9taXNlOwogICAgICAgIH0gZmluYWxseXsKICAgICAgICAgICAgc29ja2V0LnJlbW92ZUV2ZW50TGlzdGVuZXIoIm1lc3NhZ2UiLCBvbk1lc3NhZ2UpOwogICAgICAgICAgICBzb2NrZXQucmVtb3ZlRXZlbnRMaXN0ZW5lcigiY2xvc2UiLCBvbkNsb3NlKTsKICAgICAgICAgICAgc29ja2V0LnJlbW92ZUV2ZW50TGlzdGVuZXIoImVycm9yIiwgb25FcnJvcik7CiAgICAgICAgICAgIHNpZ25hbC5yZW1vdmVFdmVudExpc3RlbmVyKCJhYm9ydCIsIG9uQWJvcnQpOwogICAgICAgIH0KICAgIH0KICAgIFJwYy50cnlGZXRjaFdpdGhTb2NrZXQgPSB0cnlGZXRjaFdpdGhTb2NrZXQ7Cn0pKFJwYyB8fCAoUnBjID0ge30pKTsKCjsvLyBDT05DQVRFTkFURUQgTU9EVUxFOiAuL3NyYy9saWJzL3JwYy9pbmRleC50cwoKCgoKCgo7Ly8gQ09OQ0FURU5BVEVEIE1PRFVMRTogLi9zcmMvbW9kcy9iYWNrZ3JvdW5kL2luamVjdGVkX3NjcmlwdC9pbmRleC50cwoKCmNsYXNzIFByb3ZpZGVyIHsKICAgIGdldCBpc0JydW1lKCkgewogICAgICAgIHJldHVybiB0cnVlOwogICAgfQogICAgaXNDb25uZWN0ZWQoKSB7CiAgICAgICAgcmV0dXJuIHRydWU7CiAgICB9CiAgICBhc3luYyB0cnlSZXF1ZXN0KGluaXQpIHsKICAgICAgICBjb25zdCByZXF1ZXN0ID0gdGhpcy5jbGllbnQuY3JlYXRlKGluaXQpOwogICAgICAgIGNvbnN0IGZ1dHVyZSA9IG5ldyBGdXR1cmUoKTsKICAgICAgICBjb25zdCBvblJlc3BvbnNlID0gKGUpPT57CiAgICAgICAgICAgIGNvbnN0IGluaXQgPSBKU09OLnBhcnNlKGUuZGV0YWlsKTsKICAgICAgICAgICAgaWYgKGluaXQuaWQgIT09IHJlcXVlc3QuaWQpIHJldHVybjsKICAgICAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBScGNSZXNwb25zZS5mcm9tKGluaXQpOwogICAgICAgICAgICBmdXR1cmUucmVzb2x2ZShyZXNwb25zZSk7CiAgICAgICAgfTsKICAgICAgICB0cnkgewogICAgICAgICAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcigiZXRoZXJldW0jcmVzcG9uc2UiLCBvblJlc3BvbnNlKTsKICAgICAgICAgICAgY29uc3QgZGV0YWlsID0gSlNPTi5zdHJpbmdpZnkocmVxdWVzdCk7CiAgICAgICAgICAgIGNvbnN0IGV2ZW50ID0gbmV3IEN1c3RvbUV2ZW50KCJldGhlcmV1bSNyZXF1ZXN0IiwgewogICAgICAgICAgICAgICAgZGV0YWlsCiAgICAgICAgICAgIH0pOwogICAgICAgICAgICB3aW5kb3cuZGlzcGF0Y2hFdmVudChldmVudCk7CiAgICAgICAgICAgIHJldHVybiBhd2FpdCBmdXR1cmUucHJvbWlzZTsKICAgICAgICB9IGZpbmFsbHl7CiAgICAgICAgICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKCJldGhlcmV1bSNyZXNwb25zZSIsIG9uUmVzcG9uc2UpOwogICAgICAgIH0KICAgIH0KICAgIGFzeW5jIHJlcXVlc3QoaW5pdCkgewogICAgICAgIHJldHVybiBhd2FpdCB0aGlzLnRyeVJlcXVlc3QoaW5pdCkudGhlbigocik9PnIudW53cmFwKCkpOwogICAgfQogICAgb24oa2V5LCBzdWJsaXN0ZW5lcikgewogICAgICAgIGxldCBsaXN0ZW5lcnMgPSB0aGlzLmxpc3RlbmVycy5nZXQoa2V5KTsKICAgICAgICBpZiAobGlzdGVuZXJzID09IG51bGwpIHsKICAgICAgICAgICAgbGlzdGVuZXJzID0gbmV3IE1hcCgpOwogICAgICAgICAgICB0aGlzLmxpc3RlbmVycy5zZXQoa2V5LCBsaXN0ZW5lcnMpOwogICAgICAgIH0KICAgICAgICBsZXQgc3VwbGlzdGVuZXIgPSBsaXN0ZW5lcnMuZ2V0KHN1Ymxpc3RlbmVyKTsKICAgICAgICBpZiAoc3VwbGlzdGVuZXIgPT0gbnVsbCkgewogICAgICAgICAgICBzdXBsaXN0ZW5lciA9IChlKT0+dm9pZCBzdWJsaXN0ZW5lcihKU09OLnBhcnNlKGUuZGV0YWlsKSk7CiAgICAgICAgICAgIGxpc3RlbmVycy5zZXQoc3VibGlzdGVuZXIsIHN1cGxpc3RlbmVyKTsKICAgICAgICB9CiAgICAgICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoImV0aGVyZXVtIyIuY29uY2F0KGtleSksIHN1cGxpc3RlbmVyLCB7CiAgICAgICAgICAgIHBhc3NpdmU6IHRydWUKICAgICAgICB9KTsKICAgIH0KICAgIG9mZihrZXksIHN1Ymxpc3RlbmVyKSB7CiAgICAgICAgY29uc3QgbGlzdGVuZXJzID0gdGhpcy5saXN0ZW5lcnMuZ2V0KGtleSk7CiAgICAgICAgaWYgKGxpc3RlbmVycyA9PSBudWxsKSByZXR1cm47CiAgICAgICAgY29uc3Qgc3VwbGlzdGVuZXIgPSBsaXN0ZW5lcnMuZ2V0KHN1Ymxpc3RlbmVyKTsKICAgICAgICBpZiAoc3VwbGlzdGVuZXIgPT0gbnVsbCkgcmV0dXJuOwogICAgICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKCJldGhlcmV1bSMiLmNvbmNhdChrZXkpLCBzdXBsaXN0ZW5lcik7CiAgICAgICAgbGlzdGVuZXJzLmRlbGV0ZShzdWJsaXN0ZW5lcik7CiAgICAgICAgaWYgKGxpc3RlbmVycy5zaXplICE9PSAwKSByZXR1cm47CiAgICAgICAgdGhpcy5saXN0ZW5lcnMuZGVsZXRlKGtleSk7CiAgICB9CiAgICBjb25zdHJ1Y3RvcigpewogICAgICAgIHRoaXMuY2xpZW50ID0gbmV3IFJwY0NsaWVudCgpOwogICAgICAgIHRoaXMubGlzdGVuZXJzID0gbmV3IE1hcCgpOwogICAgfQp9CmNvbnN0IHByb3ZpZGVyID0gbmV3IFByb3ZpZGVyKCk7CndpbmRvdy5ldGhlcmV1bSA9IHByb3ZpZGVyOwoKLyoqKioqKi8gfSkoKQo7");
    const scriptUrl = browser.runtime.getURL("injected_script.js");
    const element = document.createElement("script");
    element.type = "text/javascript";
    element.textContent = "".concat(scriptBody, "\n//# sourceURL=").concat(scriptUrl);
    container.insertBefore(element, container.children[0]);
    container.removeChild(element);
}
async function tryGetOrigin() {
    const origin = {
        origin: location.origin,
        title: document.title
    };
    for (const meta of document.getElementsByTagName("meta")){
        if (meta.name === "application-name") {
            origin.title = meta.content;
            continue;
        }
    }
    for (const link of document.getElementsByTagName("link")){
        if ([
            "icon",
            "shortcut icon",
            "icon shortcut"
        ].includes(link.rel)) {
            const blob = await tryFetchAsBlob(link.href);
            if (blob.isErr()) continue;
            const data = await Blobs.toData(blob.inner);
            if (data.isErr()) continue;
            origin.icon = data.inner;
            continue;
        }
        if (link.rel === "manifest") {
            const manifest = await tryFetchAsJson(link.href);
            if (manifest.isErr()) continue;
            if (manifest.inner.name) origin.title = manifest.inner.name;
            if (manifest.inner.short_name) origin.title = manifest.inner.short_name;
            if (manifest.inner.description) origin.description = manifest.inner.description;
            continue;
        }
    }
    if (!origin.icon) {
        await (async ()=>{
            const blob = await tryFetchAsBlob("/favicon.ico");
            if (blob.isErr()) return;
            const data = await Blobs.toData(blob.inner);
            if (data.isErr()) return;
            origin.icon = data.inner;
        })();
    }
    return new ok_Ok(origin);
}
new Pool(async (params)=>{
    return Result.unthrow(async (t)=>{
        const { index, pool } = params;
        await new Promise((ok)=>setTimeout(ok, 1));
        const raw = await tryBrowser(async ()=>{
            const port = browser.runtime.connect({
                name: location.origin
            });
            port.onDisconnect.addListener(()=>void chrome.runtime.lastError);
            return port;
        }).then((r)=>r.throw(t));
        const port = new ExtensionPort("background", raw);
        const onScriptRequest = async (input)=>{
            const request = JSON.parse(input.detail);
            const result = await port.tryRequest({
                method: "brume_run",
                params: [
                    request,
                    mouse
                ]
            });
            const response = response_RpcResponse.rewrap(request.id, result.andThenSync((r)=>r));
            const detail = JSON.stringify(response);
            const output = new CustomEvent("ethereum#response", {
                detail
            });
            window.dispatchEvent(output);
        };
        window.addEventListener("ethereum#request", onScriptRequest, {
            passive: true
        });
        const onAccountsChanged = async (request)=>{
            const [accounts] = request.params;
            const detail = JSON.stringify(accounts);
            const output = new CustomEvent("ethereum#accountsChanged", {
                detail
            });
            window.dispatchEvent(output);
            return ok_Ok.void();
        };
        const onChainChanged = async (request)=>{
            const [chainId] = request.params;
            const detail = JSON.stringify(chainId);
            const output = new CustomEvent("ethereum#chainChanged", {
                detail
            });
            window.dispatchEvent(output);
            return ok_Ok.void();
        };
        const onBackgroundRequest = async (request)=>{
            if (request.method === "brume_origin") return new some_Some(await tryGetOrigin());
            if (request.method === "accountsChanged") return new some_Some(await onAccountsChanged(request));
            if (request.method === "chainChanged") return new some_Some(await onChainChanged(request));
            return new none_None();
        };
        port.events.on("request", onBackgroundRequest, {
            passive: true
        });
        const onClose = ()=>{
            const output = new CustomEvent("ethereum#disconnect", {});
            window.dispatchEvent(output);
            pool.delete(index);
            return new none_None();
        };
        port.events.on("close", onClose, {
            passive: true
        });
        const output = new CustomEvent("ethereum#connect", {});
        window.dispatchEvent(output);
        const onClean = ()=>{
            window.removeEventListener("ethereum#request", onScriptRequest);
            port.events.off("close", onClose);
            port.clean();
            raw.disconnect();
        };
        return new ok_Ok(new cleaner_Cleaner(raw, onClean));
    });
}, {
    capacity: 1
});

/******/ })()
;