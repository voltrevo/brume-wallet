(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[702],{

/***/ 9:
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


    (window.__NEXT_P = window.__NEXT_P || []).push([
      "/test/ui/portal/portal",
      function () {
        return __webpack_require__(2493);
      }
    ]);
    if(false) {}
  

/***/ }),

/***/ 2493:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": function() { return /* binding */ Page; }
});

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
// EXTERNAL MODULE: ./src/libs/react/memo.ts + 1 modules
var memo = __webpack_require__(7664);
// EXTERNAL MODULE: ./node_modules/react/index.js
var react = __webpack_require__(7294);
// EXTERNAL MODULE: ./node_modules/react-dom/index.js
var react_dom = __webpack_require__(3935);
;// CONCATENATED MODULE: ./src/libs/ui/portal/portal.tsx




function Portal(props) {
    const { children, type, container = document.getElementById("__next") } = props;
    const element = (0,memo/* useLazyMemo */.Gj)(()=>{
        return document.createElement(type);
    }, [
        type
    ]);
    (0,react.useEffect)(()=>{
        if (element == null) return;
        if (container == null) return;
        container.appendChild(element);
        return ()=>void container.removeChild(element);
    }, [
        element,
        container
    ]);
    if (element == null) return null;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(jsx_runtime.Fragment, {
        children: /*#__PURE__*/ (0,react_dom.createPortal)(children, element)
    });
}
(function(Portal) {
    function Test() {
        return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "p-1",
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsx)(Portal, {
                    type: "div",
                    container: document.getElementById("__next"),
                    children: "Hello world"
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "",
                    children: "Hello world"
                })
            ]
        });
    }
    Portal.Test = Test;
})(Portal || (Portal = {}));

;// CONCATENATED MODULE: ./pages/test/ui/portal/portal.tsx


function Page() {
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(Portal.Test, {});
}


/***/ })

},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
/******/ __webpack_require__.O(0, [774,888,179], function() { return __webpack_exec__(9); });
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ _N_E = __webpack_exports__;
/******/ }
]);