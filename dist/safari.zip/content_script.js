/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
var __webpack_exports__ = {};

;// CONCATENATED MODULE: ./node_modules/@hazae41/symbol-dispose-polyfill/dist/esm/mods/symbol-dispose-polyfill/polyfill.mjs
if (typeof Symbol.dispose !== "symbol")
    Object.defineProperty(Symbol, "dispose", {
        configurable: false,
        enumerable: false,
        writable: false,
        value: Symbol.for("dispose")
    });
if (typeof Symbol.asyncDispose !== "symbol")
    Object.defineProperty(Symbol, "asyncDispose", {
        configurable: false,
        enumerable: false,
        writable: false,
        value: Symbol.for("asyncDispose")
    });
//# sourceMappingURL=polyfill.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/symbol-dispose-polyfill/dist/esm/index.mjs

//# sourceMappingURL=index.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/future/dist/esm/mods/future/future.mjs
class Future {
    #resolve;
    #reject;
    promise;
    /**
     * Just like a Promise but you can manually resolve or reject it
     */
    constructor() {
        this.promise = new Promise((subresolve, subreject) => {
            this.#resolve = subresolve;
            this.#reject = subreject;
        });
    }
    get resolve() {
        return this.#resolve;
    }
    get reject() {
        return this.#reject;
    }
}


//# sourceMappingURL=future.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/option/dist/esm/mods/option/option.mjs



var Option;
(function (Option) {
    function from(init) {
        if ("inner" in init)
            return new Some(init.inner);
        return new None();
    }
    Option.from = from;
    /**
     * Create an Option from a nullable value
     * @param inner
     * @returns `Some<T>` if `T`, `None` if `undefined`
     */
    function wrap(inner) {
        if (inner == null)
            return new None();
        return new Some(inner);
    }
    Option.wrap = wrap;
    async function map(inner, mapper) {
        return Option.wrap(inner).map(mapper).then(o => o.get());
    }
    Option.map = map;
    function mapSync(inner, mapper) {
        return Option.wrap(inner).mapSync(mapper).get();
    }
    Option.mapSync = mapSync;
    function unwrap(inner) {
        return Option.wrap(inner).unwrap();
    }
    Option.unwrap = unwrap;
})(Option || (Option = {}));


//# sourceMappingURL=option.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/result.mjs





var Result;
(function (Result) {
    Result.debug = false;
    /**
     * Create a Result from a maybe Error value
     * @param inner
     * @returns `Ok<T>` if `T`, `Err<Error>` if `Error`
     */
    function from(inner) {
        if (inner instanceof Error)
            return new err_Err(inner);
        else
            return new ok_Ok(inner);
    }
    Result.from = from;
    /**
     * Create a Result from a boolean
     * @param value
     * @returns
     */
    function assert(value) {
        return value ? ok_Ok.void() : new err_Err(new AssertError());
    }
    Result.assert = assert;
    function rewrap(wrapper) {
        try {
            return new ok_Ok(wrapper.unwrap());
        }
        catch (error) {
            return new err_Err(error);
        }
    }
    Result.rewrap = rewrap;
    /**
     * Catch an Err thrown from Err.throw
     * @param callback
     * @param type
     * @returns `Ok<T>` if no `Err` was thrown, `Err<E>` otherwise
     * @see Err.throw
     */
    async function unthrow(callback) {
        let ref;
        try {
            return await callback((e) => ref = e);
        }
        catch (e) {
            if (ref !== undefined)
                return ref;
            throw e;
        }
    }
    Result.unthrow = unthrow;
    /**
     * Catch an Err thrown from Err.throw
     * @param callback
     * @param type
     * @returns `Ok<T>` if no `Err` was thrown, `Err<E>` otherwise
     * @see Err.throw
     */
    function unthrowSync(callback) {
        let ref;
        try {
            return callback((e) => ref = e);
        }
        catch (e) {
            if (ref !== undefined)
                return ref;
            throw e;
        }
    }
    Result.unthrowSync = unthrowSync;
    /**
     * Convert try-catch to Result<T, unknown>
     * @param callback
     * @returns
     */
    async function runAndWrap(callback) {
        try {
            return new ok_Ok(await callback());
        }
        catch (e) {
            return new err_Err(e);
        }
    }
    Result.runAndWrap = runAndWrap;
    /**
     * Convert try-catch to Result<T, unknown>
     * @param callback
     * @returns
     */
    function runAndWrapSync(callback) {
        try {
            return new ok_Ok(callback());
        }
        catch (e) {
            return new err_Err(e);
        }
    }
    Result.runAndWrapSync = runAndWrapSync;
    /**
     * Convert try-catch to Result<T, Catched>
     * @param callback
     * @returns
     */
    async function runAndDoubleWrap(callback) {
        return runAndWrap(callback).then(r => r.mapErrSync(errors_Catched.from));
    }
    Result.runAndDoubleWrap = runAndDoubleWrap;
    /**
     * Convert try-catch to Result<T, Catched>
     * @param callback
     * @returns
     */
    function runAndDoubleWrapSync(callback) {
        return runAndWrapSync(callback).mapErrSync(errors_Catched.from);
    }
    Result.runAndDoubleWrapSync = runAndDoubleWrapSync;
    /**
     * Transform Result<Result<T, E1>, E2> into Result<T, E1 | E2>
     * @param result
     * @returns `this` if `Err`, `this.inner` if `Ok`
     */
    function flatten(result) {
        if (result.isErr())
            return result;
        return result.get();
    }
    Result.flatten = flatten;
    /**
     * Transform `Iterable<Result<T,E>` into `Result<Array<T>, E>`
     * @param iterable
     * @returns `Result<Array<T>, E>`
     */
    function all(iterable) {
        return collect(iterate(iterable));
    }
    Result.all = all;
    function maybeAll(iterable) {
        return maybeCollect(maybeIterate(iterable));
    }
    Result.maybeAll = maybeAll;
    /**
     * Transform `Iterable<Result<T,E>` into `Iterator<T, Result<void, E>>`
     * @param iterable
     * @returns `Iterator<T, Result<void, E>>`
     */
    function* iterate(iterable) {
        for (const result of iterable) {
            if (result.isOk())
                yield result.get();
            else
                return result;
        }
        return ok_Ok.void();
    }
    Result.iterate = iterate;
    function* maybeIterate(iterable) {
        for (const result of iterable) {
            if (result == null)
                return result;
            else if (result.isOk())
                yield result.get();
            else
                return result;
        }
        return ok_Ok.void();
    }
    Result.maybeIterate = maybeIterate;
    /**
     * Transform `Iterator<T, Result<void, E>>` into `Result<Array<T>, E>`
     * @param iterator `Result<Array<T>, E>`
     */
    function collect(iterator) {
        const array = new Array();
        let result = iterator.next();
        for (; !result.done; result = iterator.next())
            array.push(result.value);
        return result.value.set(array);
    }
    Result.collect = collect;
    function maybeCollect(iterator) {
        const array = new Array();
        let result = iterator.next();
        for (; !result.done; result = iterator.next())
            array.push(result.value);
        return Option.mapSync(result.value, result => result.set(array));
    }
    Result.maybeCollect = maybeCollect;
    /**
     * Unwrap the callback but wrap thrown errors in Catched
     * @param callback
     * @returns `T` if `Ok`
     * @throws `Catched` if `callback()` throws, `E` if `Err`
     */
    async function runAndUnwrap(callback) {
        let result;
        try {
            result = await callback();
        }
        catch (e) {
            throw errors_Catched.from(e);
        }
        return result.unwrap();
    }
    Result.runAndUnwrap = runAndUnwrap;
    /**
     * Unwrap the callback but wrap thrown errors in Catched
     * @param callback
     * @returns `T` if `Ok`
     * @throws `Catched` if `callback()` throws, `E` if `Err`
     */
    function runAndUnwrapSync(callback) {
        let result;
        try {
            result = callback();
        }
        catch (e) {
            throw errors_Catched.from(e);
        }
        return result.unwrap();
    }
    Result.runAndUnwrapSync = runAndUnwrapSync;
})(Result || (Result = {}));


//# sourceMappingURL=result.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/err.mjs




class err_Err {
    #inner;
    #timeout;
    /**
     * A failure
     * @param inner
     */
    constructor(inner) {
        this.#inner = inner;
        if (!Result.debug)
            return;
        const error = Panic.from(new Error(`An Err has not been handled properly`, { cause: this }));
        this.#timeout = setTimeout(() => { throw error; }, 1000);
    }
    /**
     * Create an empty `Err`
     * @returns `Err(void)`
     */
    static void() {
        return new err_Err(undefined);
    }
    /**
     * Create an `Err`
     * @param inner
     * @returns `Err(inner)`
     */
    static new(inner) {
        return new err_Err(inner);
    }
    /**
     * Create an `Err` with an `Error` inside
     * @param message
     * @param options
     * @returns `Err<Error>`
     */
    static error(message, options) {
        return new err_Err(new Error(message, options));
    }
    get inner() {
        return this.#inner;
    }
    /**
     * Set this result as handled
     */
    ignore() {
        if (!this.#timeout)
            return this;
        clearTimeout(this.#timeout);
        this.#timeout = undefined;
        return this;
    }
    /**
     * Type guard for `Ok`
     * @returns `true` if `Ok`, `false` if `Err`
     */
    isOk() {
        return false;
    }
    /**
     * Returns true if the result is `Ok` and the value inside of it matches a predicate
     * @param okPredicate
     * @returns `true` if `Ok` and `await okPredicate(this.inner)`, `false` otherwise
     */
    async isOkAnd(okPredicate) {
        return false;
    }
    /**
     * Returns true if the result is `Ok` and the value inside of it matches a predicate
     * @param okPredicate
     * @returns `true` if `Ok` and `await okPredicate(this.inner)`, `false` otherwise
     */
    isOkAndSync(okPredicate) {
        return false;
    }
    /**
     * Type guard for `Err`
     * @returns `true` if `Err`, `false` if `Ok`
     */
    isErr() {
        return true;
    }
    /**
     * Returns true if the result is `Err` and the value inside of it matches a predicate
     * @param errPredicate
     * @returns `true` if `Err` and `await errPredicate(this.inner)`, `false` otherwise
     */
    async isErrAnd(errPredicate) {
        return await errPredicate(this.inner);
    }
    /**
     * Returns true if the result is `Err` and the value inside of it matches a predicate
     * @param errPredicate
     * @returns `true` if `Err` and `await errPredicate(this.inner)`, `false` otherwise
     */
    isErrAndSync(errPredicate) {
        return errPredicate(this.inner);
    }
    /**
     * Compile-time safely get `this.inner`
     * @returns `this.inner`
     */
    get() {
        this.ignore();
        return this.inner;
    }
    /**
     * Transform `Result<T, E>` into `Option<T>`
     * @returns `Some(this.inner)` if `Ok`, `None` if `Err`
     */
    ok() {
        this.ignore();
        return new None();
    }
    /**
     * Transform `Result<T, E>` into `Option<E>`
     * @returns `Some(this.inner)` if `Err`, `None` if `Ok`
     */
    err() {
        this.ignore();
        return new Some(this.inner);
    }
    /**
     * Returns an iterator over the possibly contained value
     * @yields `this.inner` if `Ok`
     */
    *[Symbol.iterator]() {
        this.ignore();
        return;
    }
    /**
     * Transform `Result<T,E>` into `[T,E]`
     * @returns `[this.inner, undefined]` if `Ok`, `[undefined, this.inner]` if `Err`
     */
    split() {
        this.ignore();
        return [undefined, this.inner];
    }
    /**
     * Returns true if the result is an `Ok` value containing the given value
     * @param value
     * @returns `true` if `Ok` and `this.inner === value`, `false` otherwise
     */
    contains(value) {
        return false;
    }
    /**
     * Returns true if the result is an `Err` value containing the given value
     * @param value
     * @returns `true` if `Err` and `this.inner === value`, `false` otherwise
     */
    containsErr(value) {
        return this.inner === value;
    }
    /**
     * Get the inner value or throw to the closest `Result.unthrow`
     * @param thrower The thrower from `Result.unthrow`
     * @returns `this.inner` if `Ok`
     * @throws `undefined` if `Err`
     * @see Result.unthrow
     * @see Result.unthrowSync
     */
    throw(thrower) {
        thrower(this);
        throw Panic.from(new Error(`An Err has been thrown but not catched`, { cause: this }));
    }
    /**
     * Get the inner value or throw the inner error wrapped inside another Error
     * @param message
     * @returns `this.inner` if `Ok`, `Error(message, { cause: this.inner })` if `Err`
     */
    expect(message) {
        this.ignore();
        throw Panic.from(new Error(message, { cause: this }));
    }
    /**
     * Get the inner error or throw the inner value wrapped inside another Error
     * @param message
     * @returns `this.inner` if `Err`, `Error(message, { cause: this.inner })` if `Ok`
     */
    expectErr(message) {
        this.ignore();
        return this.inner;
    }
    /**
     * Get the inner value or panic
     * @returns `this.inner` if `Ok`
     * @throws `this.inner` if `Err`
     */
    unwrap() {
        this.ignore();
        throw new Panic(new Error(`An Err has been unwrapped`, { cause: this }));
    }
    /**
     * Get the inner error or panic
     * @returns `this.inner` if `Err`
     * @throws `this.inner` if `Ok`
     */
    unwrapErr() {
        this.ignore();
        return this.inner;
    }
    /**
     * Get the inner value or a default one
     * @param value
     * @returns `this.inner` if `Ok`, `value` if `Err`
     */
    unwrapOr(value) {
        this.ignore();
        return value;
    }
    /**
     * Get the inner value or compute a default one from the inner error
     * @param errMapper
     * @returns `this.inner` if `Ok`, `await errMapper(this.inner)` if `Err`
     * @throws if `await errMapper(this.inner)` throws
     */
    async unwrapOrElse(errMapper) {
        this.ignore();
        return await errMapper(this.inner);
    }
    /**
     * Get the inner value or compute a default one from the inner error
     * @param errMapper
     * @returns `this.inner` if `Ok`, `errMapper(this.inner)` if `Err`
     * @throws if `errMapper(this.inner)` throws
     */
    unwrapOrElseSync(errMapper) {
        this.ignore();
        return errMapper(this.inner);
    }
    /**
     * Transform Result<Promise<T>, E> into Promise<Result<T, E>>
     * @returns `await this.inner` if `Ok`, `this` if `Err`
     */
    async await() {
        return this;
    }
    /**
     * Transform Result<T, Promise<E>> into Promise<Result<T, E>>
     * @returns `await this.inner` if `Err`, `this` if `Ok`
     */
    async awaitErr() {
        return new err_Err(await this.inner);
    }
    /**
     * Transform Result<Promise<T>, Promise<E>> into Promise<Result<T, E>>
     * @returns `await this.inner`
     */
    async awaitAll() {
        return await this.awaitErr();
    }
    /**
     * Transform `Result<T, E>` into `Result<void, E>`
     * @returns `Ok<void>` if `Ok<T>`, `Err<E>` if `E<E>`
     */
    clear() {
        return this;
    }
    /**
     * Transform `Result<T, E>` into `Result<T, void>`
     * @returns `Ok<T>` if `Ok<T>`, `Err<void>` if `E<E>`
     */
    clearErr() {
        this.ignore();
        return err_Err.void();
    }
    /**
     * Calls the given callback with the inner value if `Ok`
     * @param okCallback
     * @returns `this`
     */
    async inspect(okCallback) {
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Ok`
     * @param okCallback
     * @returns `this`
     */
    inspectSync(okCallback) {
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Err`
     * @param errCallback
     * @returns `this`
     */
    async inspectErr(errCallback) {
        await errCallback(this.inner);
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Err`
     * @param errCallback
     * @returns `this`
     */
    inspectErrSync(errCallback) {
        errCallback(this.inner);
        return this;
    }
    /**
     * Return a new `Ok` but with the given `inner`
     * @param inner
     * @returns `Ok(inner)` if `Ok`, `this` if `Err`
     */
    set(inner) {
        return this;
    }
    /**
     * Return a new `Err` but with the given `inner`
     * @param inner
     * @returns `Err(inner)` if `Err`, `this` if `Ok`
     */
    setErr(inner) {
        return new err_Err(inner);
    }
    /**
     * Map the inner value into another
     * @param okMapper
     * @returns `Ok(await okMapper(this.inner))` if `Ok`, `this` if `Err`
     * @throws if `await okMapper(this.inner)` throws
     */
    async map(okMapper) {
        return this;
    }
    /**
     * Map the inner value into another
     * @param okMapper
     * @returns `Ok(okMapper(this.inner))` if `Ok`, `this` if `Err`
     * @throws if `okMapper(this.inner)` throws
     */
    mapSync(okMapper) {
        return this;
    }
    /**
     * Map the inner error into another
     * @param errMapper
     * @returns `Err(await errMapper(this.inner))` if `Err`, `this` if `Ok`
     * @throws if `await errMapper(this.inner)` throws
     */
    async mapErr(errMapper) {
        this.ignore();
        return new err_Err(await errMapper(this.inner));
    }
    /**
     * Map the inner error into another
     * @param errMapper
     * @returns `Err(errMapper(this.inner))` if `Err`, `this` if `Ok`
     * @throws if `errMapper(this.inner)` throws
     */
    mapErrSync(errMapper) {
        this.ignore();
        return new err_Err(errMapper(this.inner));
    }
    /**
     * Map the inner value into another, or a default one
     * @param value
     * @param okMapper
     * @returns `await okMapper(this.inner)` if `Ok`, `value` if `Err`
     * @throws if `await okMapper(this.inner)` throws
     */
    async mapOr(value, okMapper) {
        this.ignore();
        return value;
    }
    /**
     * Map the inner value into another, or a default one
     * @param value
     * @param okMapper
     * @returns `okMapper(this.inner)` if `Ok`, `value` if `Err`
     * @throws if `okMapper(this.inner)` throws
     */
    mapOrSync(value, okMapper) {
        this.ignore();
        return value;
    }
    /**
     * Map the inner value into another, or a default one
     * @param errMapper
     * @param okMapper
     * @returns `await okMapper(this.inner)` if `Ok`, `await errMapper(this.inner)` if `Err`
     * @throws if `await okMapper(this.inner)` or `await errMapper(this.inner)` throws
     */
    async mapOrElse(errMapper, okMapper) {
        this.ignore();
        return await errMapper(this.inner);
    }
    /**
     * Map the inner value into another, or a default one
     * @param errMapper
     * @param okMapper
     * @returns `okMapper(this.inner)` if `Ok`, `errMapper(this.inner)` if `Err`
     * @throws if `okMapper(this.inner)` or `errMapper(this.inner)` throws
     */
    mapOrElseSync(errMapper, okMapper) {
        this.ignore();
        return errMapper(this.inner);
    }
    /**
     * Return `value` if `Ok`, return `this` if `Err`
     * @param value
     * @returns `value` if `Ok`, `this` if `Err`
     */
    and(value) {
        return this;
    }
    /**
     * Return `await okMapper(this.inner)` if `Ok`, return `this` if `Err`
     * @param okMapper
     * @returns `await okMapper(this.inner)` if `Ok`, `this` if `Err`
     * @throws if `await okMapper(this.inner)` throws
     */
    async andThen(okMapper) {
        return this;
    }
    /**
     * Return `okMapper(this.inner)` if `Ok`, return `this` if `Err`
     * @param okMapper
     * @returns `okMapper(this.inner)` if `Ok`, `this` if `Err`
     * @throws if `okMapper(this.inner)` throws
     */
    andThenSync(okMapper) {
        return this;
    }
    /**
     * Return `value` if `Err`, return `this` if `Ok`
     * @param value
     * @returns `value` if `Err`, `this` if `Ok`
     */
    or(value) {
        this.ignore();
        return value;
    }
    /**
     * Return `await errMapper(this.inner)` if `Err`, return `this` if `Ok`
     * @param errMapper
     * @returns `await errMapper(this.inner)` if `Err`, `this` if `Ok`
     * @throws if `await errMapper(this.inner)` throws
     */
    async orElse(errMapper) {
        this.ignore();
        return await errMapper(this.inner);
    }
    /**
     * Return `errMapper(this.inner)` if `Err`, return `this` if `Ok`
     * @param errMapper
     * @returns `errMapper(this.inner)` if `Err`, `this` if `Ok`
     * @throws if `errMapper(this.inner)` throws
     */
    orElseSync(errMapper) {
        this.ignore();
        return errMapper(this.inner);
    }
    /**
     * Transform Result<Result<T, E1>, E2> into Result<T, E1 | E2>
     * @param result
     * @returns `this` if `Err`, `this.inner` if `Ok`
     */
    flatten() {
        return this;
    }
}


//# sourceMappingURL=err.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/errors.mjs


class Unimplemented extends (/* unused pure expression or super */ null && (Error)) {
    #class = Unimplemented;
    name = this.#class.name;
    constructor(options) {
        super(`Something is not implemented`, options);
    }
}
class AssertError extends Error {
    #class = AssertError;
    name = this.#class.name;
    constructor(options) {
        super(`Some assertion failed`, options);
    }
}
class Panic extends Error {
    #class = Panic;
    name = this.#class.name;
    constructor(options) {
        super(`Something was not expected`, options);
    }
    static from(cause) {
        return new Panic({ cause });
    }
    static fromAndThrow(cause) {
        throw new Panic({ cause });
    }
}
class errors_Catched extends Error {
    #class = errors_Catched;
    name = this.#class.name;
    constructor(options) {
        super(`Something has been catched`, options);
    }
    static from(cause) {
        return new errors_Catched({ cause });
    }
    static fromAndThrow(cause) {
        throw new errors_Catched({ cause });
    }
    /**
     * Throw if `Catched`, wrap in `Err` otherwise
     * @param error
     * @returns `Err(error)` if not `Catched`
     * @throws `error.cause` if `Catched`
     */
    static throwOrErr(error) {
        if (error instanceof errors_Catched)
            throw error.cause;
        return new err_Err(error);
    }
}


//# sourceMappingURL=errors.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/option/dist/esm/mods/option/none.mjs


class NoneError extends Error {
    constructor() {
        super(`Option is a None`);
    }
}
class None {
    inner;
    /**
     * An empty value
     */
    constructor(inner = undefined) {
        this.inner = inner;
    }
    /**
     * Create a `None`
     * @returns `None`
     */
    static new() {
        return new None();
    }
    static from(init) {
        return new None();
    }
    /**
     * Type guard for `Some`
     * @returns `true` if `Some`, `false` if `None`
     */
    isSome() {
        return false;
    }
    /**
     * Returns `true` if the option is a `Some` and the value inside of it matches a predicate
     * @param somePredicate
     * @returns `true` if `Some` and `await somePredicate(this.inner)`, `None` otherwise
     */
    async isSomeAnd(somePredicate) {
        return false;
    }
    /**
     * Returns `true` if the option is a `Some` and the value inside of it matches a predicate
     * @param somePredicate
     * @returns `true` if `Some` and `somePredicate(this.inner)`, `None` otherwise
     */
    isSomeAndSync(somePredicate) {
        return false;
    }
    /**
     * Type guard for `None`
     * @returns `true` if `None`, `false` if `Some`
     */
    isNone() {
        return true;
    }
    /**
     * Compile-time safely get `this.inner`
     * @returns `this.inner`
     */
    get() {
        return this.inner;
    }
    /**
     * Returns an iterator over the possibly contained value
     * @yields `this.inner` if `Some`
     */
    *[Symbol.iterator]() {
        return;
    }
    /**
     * Get the inner value if `Some`, throw `Error(message)` otherwise
     * @param message
     * @returns `this.inner` if `Some`
     * @throws `Error(message)` if `None`
     */
    expect(message) {
        throw Panic.from(new Error(message, { cause: this }));
    }
    /**
     * Get the inner value or throw a NoneError
     * @returns `this.inner` if `Some`
     * @throws `NoneError` if `None`
     */
    unwrap() {
        throw Panic.from(new Error(`A None has been unwrapped`, { cause: this }));
    }
    /**
     * Get the inner value or a default one
     * @param value
     * @returns `this.inner` if `Some`, `value` if `None`
     */
    unwrapOr(value) {
        return value;
    }
    /**
     * Returns the contained `Some` value or computes it from a closure
     * @param noneCallback
     * @returns `this.inner` if `Some`, `await noneCallback()` if `None`
     */
    async unwrapOrElse(noneCallback) {
        return await noneCallback();
    }
    /**
     * Returns the contained `Some` value or computes it from a closure
     * @param noneCallback
     * @returns `this.inner` if `Some`, `noneCallback()` if `None`
     */
    unwrapOrElseSync(noneCallback) {
        return noneCallback();
    }
    /**
     * Transform `Option<T>` into `Result<T, NoneError>`
     * @returns `Ok(this.inner)` if `Some`, `Err(NoneError)` if `None`
     */
    ok() {
        return new err_Err(new NoneError());
    }
    /**
     * Transform `Option<T>` into `Result<T, E>`
     * @param error
     * @returns `Ok(this.inner)` if `Some`, `Err(error)` if `None`
     */
    okOr(error) {
        return new err_Err(error);
    }
    /**
     * Transforms the `Option<T>` into a `Result<T, E>`, mapping `Some(v)` to `Ok(v)` and `None` to `Err(err())`
     * @param noneCallback
     * @returns `Ok(this.inner)` if `Some`, `Err(await noneCallback())` is `None`
     */
    async okOrElse(noneCallback) {
        return new err_Err(await noneCallback());
    }
    /**
     * Transforms the `Option<T>` into a `Result<T, E>`, mapping `Some(v)` to `Ok(v)` and `None` to `Err(err())`
     * @param noneCallback
     * @returns `Ok(this.inner)` if `Some`, `Err(noneCallback())` is `None`
     */
    okOrElseSync(noneCallback) {
        return new err_Err(noneCallback());
    }
    /**
     * Returns `None` if the option is `None`, otherwise calls `somePredicate` with the wrapped value
     * @param somePredicate
     * @returns `Some` if `Some` and `await somePredicate(this.inner)`, `None` otherwise
     */
    async filter(somePredicate) {
        return this;
    }
    /**
     * Returns `None` if the option is `None`, otherwise calls `somePredicate` with the wrapped value
     * @param somePredicate
     * @returns `Some` if `Some` and `somePredicate(this.inner)`, `None` otherwise
     */
    filterSync(somePredicate) {
        return this;
    }
    /**
     * Transform `Option<Promise<T>>` into `Promise<Option<T>>`
     * @returns `Promise<Option<T>>`
     */
    async await() {
        return this;
    }
    /**
     * Returns `true` if the option is a `Some` value containing the given value
     * @param value
     * @returns `true` if `Some` and `this.inner === value`, `None` otherwise
     */
    contains(value) {
        return false;
    }
    /**
     * Calls the given callback with the inner value if `Ok`
     * @param someCallback
     * @returns `this`
     */
    async inspect(someCallback) {
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Ok`
     * @param someCallback
     * @returns `this`
     */
    inspectSync(someCallback) {
        return this;
    }
    /**
     * Maps an `Option<T>` to `Option<U>` by applying a function to a contained value (if `Some`) or returns `None` (if `None`)
     * @param someMapper
     * @returns `Some(await someMapper(this.inner))` if `Some`, `this` if `None`
     */
    async map(someMapper) {
        return this;
    }
    /**
     * Maps an `Option<T>` to `Option<U>` by applying a function to a contained value (if `Some`) or returns `None` (if `None`)
     * @param someMapper
     * @returns `Some(someMapper(this.inner))` if `Some`, `this` if `None`
     */
    mapSync(someMapper) {
        return this;
    }
    /**
     * Returns the provided default result (if none), or applies a function to the contained value (if any)
     * @param value
     * @param someMapper
     * @returns `value` if `None`, `await someMapper(this.inner)` if `Some`
     */
    async mapOr(value, someMapper) {
        return value;
    }
    /**
     * Returns the provided default result (if none), or applies a function to the contained value (if any)
     * @param value
     * @param someMapper
     * @returns `value` if `None`, `someMapper(this.inner)` if `Some`
     */
    mapOrSync(value, someMapper) {
        return value;
    }
    /**
     * Computes a default function result (if none), or applies a different function to the contained value (if any)
     * @param noneCallback
     * @param someMapper
     * @returns `await someMapper(this.inner)` if `Some`, `await noneCallback()` if `None`
     */
    async mapOrElse(noneCallback, someMapper) {
        return await noneCallback();
    }
    /**
     * Computes a default function result (if none), or applies a different function to the contained value (if any)
     * @param noneCallback
     * @param someMapper
     * @returns `someMapper(this.inner)` if `Some`, `noneCallback()` if `None`
     */
    mapOrElseSync(noneCallback, someMapper) {
        return noneCallback();
    }
    /**
     * Returns `None` if the option is `None`, otherwise returns `value`
     * @param value
     * @returns `None` if `None`, `value` if `Some`
     */
    and(value) {
        return this;
    }
    /**
     * Returns `None` if the option is `None`, otherwise calls `someMapper` with the wrapped value and returns the result
     * @param someMapper
     * @returns `None` if `None`, `await someMapper(this.inner)` if `Some`
     */
    async andThen(someMapper) {
        return this;
    }
    /**
     * Returns `None` if the option is `None`, otherwise calls `someMapper` with the wrapped value and returns the result
     * @param someMapper
     * @returns `None` if `None`, `someMapper(this.inner)` if `Some`
     */
    andThenSync(someMapper) {
        return this;
    }
    /**
     * Returns `this` if `Some`, otherwise returns `value`
     * @param value
     * @returns `this` if `Some`, `value` if `None`
     */
    or(value) {
        return value;
    }
    /**
     * Returns `this` if `Some`, otherwise calls `noneCallback` and returns the result
     * @param noneCallback
     * @returns `this` if `Some`, `await noneCallback()` if `None`
     */
    async orElse(noneCallback) {
        return await noneCallback();
    }
    /**
     * Returns `this` if `Some`, otherwise calls `noneCallback` and returns the result
     * @param noneCallback
     * @returns `this` if `Some`, `noneCallback()` if `None`
     */
    orElseSync(noneCallback) {
        return noneCallback();
    }
    /**
     * Returns `Some` if exactly one of the options is `Some`, otherwise returns `None`
     * @param value
     * @returns `None` if both are `Some` or both are `None`, the only `Some` otherwise
     */
    xor(value) {
        return value;
    }
    /**
     * Zips `this` with another `Option`
     * @param other
     * @returns `Some([this.inner, other.inner])` if both are `Some`, `None` if one of them is `None`
     */
    zip(other) {
        return this;
    }
}


//# sourceMappingURL=none.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/option/dist/esm/mods/option/some.mjs



class Some {
    inner;
    /**
     * An existing value
     * @param inner
     */
    constructor(inner) {
        this.inner = inner;
    }
    /**
     * Create a `Some`
     * @param inner
     * @returns `Some(inner)`
     */
    static new(inner) {
        return new Some(inner);
    }
    static from(init) {
        return new Some(init.inner);
    }
    /**
     * Type guard for `Some`
     * @returns `true` if `Some`, `false` if `None`
     */
    isSome() {
        return true;
    }
    /**
     * Returns `true` if the option is a `Some` and the value inside of it matches a predicate
     * @param somePredicate
     * @returns `true` if `Some` and `await somePredicate(this.inner)`, `None` otherwise
     */
    async isSomeAnd(somePredicate) {
        return await somePredicate(this.inner);
    }
    /**
     * Returns `true` if the option is a `Some` and the value inside of it matches a predicate
     * @param somePredicate
     * @returns `true` if `Some` and `somePredicate(this.inner)`, `None` otherwise
     */
    isSomeAndSync(somePredicate) {
        return somePredicate(this.inner);
    }
    /**
     * Type guard for `None`
     * @returns `true` if `None`, `false` if `Some`
     */
    isNone() {
        return false;
    }
    /**
     * Compile-time safely get `this.inner`
     * @returns `this.inner`
     */
    get() {
        return this.inner;
    }
    /**
     * Returns an iterator over the possibly contained value
     * @yields `this.inner` if `Some`
     */
    *[Symbol.iterator]() {
        yield this.inner;
    }
    /**
     * Get the inner value if `Some`, throw `Error(message)` otherwise
     * @param message
     * @returns `this.inner` if `Some`
     * @throws `Error(message)` if `None`
     */
    expect(message) {
        return this.inner;
    }
    /**
     * Get the inner value or throw a NoneError
     * @returns `this.inner` if `Some`
     * @throws `NoneError` if `None`
     */
    unwrap() {
        return this.inner;
    }
    /**
     * Get the inner value or a default one
     * @param value
     * @returns `this.inner` if `Some`, `value` if `None`
     */
    unwrapOr(value) {
        return this.inner;
    }
    /**
     * Returns the contained `Some` value or computes it from a closure
     * @param noneCallback
     * @returns `this.inner` if `Some`, `await noneCallback()` if `None`
     */
    async unwrapOrElse(noneCallback) {
        return this.inner;
    }
    /**
     * Returns the contained `Some` value or computes it from a closure
     * @param noneCallback
     * @returns `this.inner` if `Some`, `noneCallback()` if `None`
     */
    unwrapOrElseSync(noneCallback) {
        return this.inner;
    }
    /**
     * Transform `Option<T>` into `Result<T, NoneError>`
     * @returns `Ok(this.inner)` if `Some`, `Err(NoneError)` if `None`
     */
    ok() {
        return new ok_Ok(this.inner);
    }
    /**
     * Transform `Option<T>` into `Result<T, E>`
     * @param error
     * @returns `Ok(this.inner)` if `Some`, `Err(error)` if `None`
     */
    okOr(error) {
        return new ok_Ok(this.inner);
    }
    /**
     * Transforms the `Option<T>` into a `Result<T, E>`, mapping `Some(v)` to `Ok(v)` and `None` to `Err(err())`
     * @param noneCallback
     * @returns `Ok(this.inner)` if `Some`, `Err(await noneCallback())` is `None`
     */
    async okOrElse(noneCallback) {
        return new ok_Ok(this.inner);
    }
    /**
     * Transforms the `Option<T>` into a `Result<T, E>`, mapping `Some(v)` to `Ok(v)` and `None` to `Err(err())`
     * @param noneCallback
     * @returns `Ok(this.inner)` if `Some`, `Err(noneCallback())` is `None`
     */
    okOrElseSync(noneCallback) {
        return new ok_Ok(this.inner);
    }
    /**
     * Returns `None` if the option is `None`, otherwise calls `somePredicate` with the wrapped value
     * @param somePredicate
     * @returns `Some` if `Some` and `await somePredicate(this.inner)`, `None` otherwise
     */
    async filter(somePredicate) {
        if (await somePredicate(this.inner))
            return this;
        else
            return new None();
    }
    /**
     * Returns `None` if the option is `None`, otherwise calls `somePredicate` with the wrapped value
     * @param somePredicate
     * @returns `Some` if `Some` and `somePredicate(this.inner)`, `None` otherwise
     */
    filterSync(somePredicate) {
        if (somePredicate(this.inner))
            return this;
        else
            return new None();
    }
    /**
     * Transform `Option<Promise<T>>` into `Promise<Option<T>>`
     * @returns `Promise<Option<T>>`
     */
    async await() {
        return new Some(await this.inner);
    }
    /**
     * Returns `true` if the option is a `Some` value containing the given value
     * @param value
     * @returns `true` if `Some` and `this.inner === value`, `None` otherwise
     */
    contains(value) {
        return this.inner === value;
    }
    /**
     * Calls the given callback with the inner value if `Ok`
     * @param someCallback
     * @returns `this`
     */
    async inspect(someCallback) {
        await someCallback(this.inner);
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Ok`
     * @param someCallback
     * @returns `this`
     */
    inspectSync(someCallback) {
        someCallback(this.inner);
        return this;
    }
    /**
     * Maps an `Option<T>` to `Option<U>` by applying a function to a contained value (if `Some`) or returns `None` (if `None`)
     * @param someMapper
     * @returns `Some(await someMapper(this.inner))` if `Some`, `this` if `None`
     */
    async map(someMapper) {
        return new Some(await someMapper(this.inner));
    }
    /**
     * Maps an `Option<T>` to `Option<U>` by applying a function to a contained value (if `Some`) or returns `None` (if `None`)
     * @param someMapper
     * @returns `Some(someMapper(this.inner))` if `Some`, `this` if `None`
     */
    mapSync(someMapper) {
        return new Some(someMapper(this.inner));
    }
    /**
     * Returns the provided default result (if none), or applies a function to the contained value (if any)
     * @param value
     * @param someMapper
     * @returns `value` if `None`, `await someMapper(this.inner)` if `Some`
     */
    async mapOr(value, someMapper) {
        return await someMapper(this.inner);
    }
    /**
     * Returns the provided default result (if none), or applies a function to the contained value (if any)
     * @param value
     * @param someMapper
     * @returns `value` if `None`, `someMapper(this.inner)` if `Some`
     */
    mapOrSync(value, someMapper) {
        return someMapper(this.inner);
    }
    /**
     * Computes a default function result (if none), or applies a different function to the contained value (if any)
     * @param noneCallback
     * @param someMapper
     * @returns `await someMapper(this.inner)` if `Some`, `await noneCallback()` if `None`
     */
    async mapOrElse(noneCallback, someMapper) {
        return await someMapper(this.inner);
    }
    /**
     * Computes a default function result (if none), or applies a different function to the contained value (if any)
     * @param noneCallback
     * @param someMapper
     * @returns `someMapper(this.inner)` if `Some`, `noneCallback()` if `None`
     */
    mapOrElseSync(noneCallback, someMapper) {
        return someMapper(this.inner);
    }
    /**
     * Returns `None` if the option is `None`, otherwise returns `value`
     * @param value
     * @returns `None` if `None`, `value` if `Some`
     */
    and(value) {
        return value;
    }
    /**
     * Returns `None` if the option is `None`, otherwise calls `someMapper` with the wrapped value and returns the result
     * @param someMapper
     * @returns `None` if `None`, `await someMapper(this.inner)` if `Some`
     */
    async andThen(someMapper) {
        return await someMapper(this.inner);
    }
    /**
     * Returns `None` if the option is `None`, otherwise calls `someMapper` with the wrapped value and returns the result
     * @param someMapper
     * @returns `None` if `None`, `someMapper(this.inner)` if `Some`
     */
    andThenSync(someMapper) {
        return someMapper(this.inner);
    }
    /**
     * Returns `this` if `Some`, otherwise returns `value`
     * @param value
     * @returns `this` if `Some`, `value` if `None`
     */
    or(value) {
        return this;
    }
    /**
     * Returns `this` if `Some`, otherwise calls `noneCallback` and returns the result
     * @param noneCallback
     * @returns `this` if `Some`, `await noneCallback()` if `None`
     */
    async orElse(noneCallback) {
        return this;
    }
    /**
     * Returns `this` if `Some`, otherwise calls `noneCallback` and returns the result
     * @param noneCallback
     * @returns `this` if `Some`, `noneCallback()` if `None`
     */
    orElseSync(noneCallback) {
        return this;
    }
    /**
     * Returns `Some` if exactly one of the options is `Some`, otherwise returns `None`
     * @param value
     * @returns `None` if both are `Some` or both are `None`, the only `Some` otherwise
     */
    xor(value) {
        if (value.isSome())
            return new None();
        else
            return this;
    }
    /**
     * Zips `this` with another `Option`
     * @param other
     * @returns `Some([this.inner, other.inner])` if both are `Some`, `None` if one of them is `None`
     */
    zip(other) {
        if (other.isSome())
            return new Some([this.inner, other.inner]);
        else
            return other;
    }
}


//# sourceMappingURL=some.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/ok.mjs




class ok_Ok {
    #inner;
    #timeout;
    /**
     * A success
     * @param inner
     */
    constructor(inner) {
        this.#inner = inner;
        if (!Result.debug)
            return;
        const error = Panic.from(new Error(`An Ok has not been handled properly`, { cause: this }));
        this.#timeout = setTimeout(() => { throw error; }, 1000);
    }
    /**
     * Create an empty `Ok`
     * @returns `Ok(void)`
     */
    static void() {
        return new ok_Ok(undefined);
    }
    /**
     * Create an `Ok`
     * @param inner
     * @returns `Ok(inner)`
     */
    static new(inner) {
        return new ok_Ok(inner);
    }
    get inner() {
        return this.#inner;
    }
    /**
     * Set this result as handled
     */
    ignore() {
        if (!this.#timeout)
            return this;
        clearTimeout(this.#timeout);
        this.#timeout = undefined;
        return this;
    }
    /**
     * Type guard for `Ok`
     * @returns `true` if `Ok`, `false` if `Err`
     */
    isOk() {
        return true;
    }
    /**
     * Returns true if the result is `Ok` and the value inside of it matches a predicate
     * @param okPredicate
     * @returns `true` if `Ok` and `await okPredicate(this.inner)`, `false` otherwise
     */
    async isOkAnd(okPredicate) {
        return await okPredicate(this.inner);
    }
    /**
     * Returns true if the result is `Ok` and the value inside of it matches a predicate
     * @param okPredicate
     * @returns `true` if `Ok` and `await okPredicate(this.inner)`, `false` otherwise
     */
    isOkAndSync(okPredicate) {
        return okPredicate(this.inner);
    }
    /**
     * Type guard for `Err`
     * @returns `true` if `Err`, `false` if `Ok`
     */
    isErr() {
        return false;
    }
    /**
     * Returns true if the result is `Err` and the value inside of it matches a predicate
     * @param errPredicate
     * @returns `true` if `Err` and `await errPredicate(this.inner)`, `false` otherwise
     */
    async isErrAnd(errPredicate) {
        return false;
    }
    /**
     * Returns true if the result is `Err` and the value inside of it matches a predicate
     * @param errPredicate
     * @returns `true` if `Err` and `await errPredicate(this.inner)`, `false` otherwise
     */
    isErrAndSync(errPredicate) {
        return false;
    }
    /**
     * Compile-time safely get `this.inner`
     * @returns `this.inner`
     */
    get() {
        this.ignore();
        return this.inner;
    }
    /**
     * Transform `Result<T, E>` into `Option<T>`
     * @returns `Some(this.inner)` if `Ok`, `None` if `Err`
     */
    ok() {
        this.ignore();
        return new Some(this.inner);
    }
    /**
     * Transform `Result<T, E>` into `Option<E>`
     * @returns `Some(this.inner)` if `Err`, `None` if `Ok`
     */
    err() {
        this.ignore();
        return new None();
    }
    /**
     * Returns an iterator over the possibly contained value
     * @yields `this.inner` if `Ok`
     */
    *[Symbol.iterator]() {
        this.ignore();
        yield this.inner;
    }
    /**
     * Transform `Result<T,E>` into `[T,E]`
     * @returns `[this.inner, undefined]` if `Ok`, `[undefined, this.inner]` if `Err`
     */
    split() {
        this.ignore();
        return [this.inner, undefined];
    }
    /**
     * Returns true if the result is an `Ok` value containing the given value
     * @param value
     * @returns `true` if `Ok` and `this.inner === value`, `false` otherwise
     */
    contains(value) {
        return this.inner === value;
    }
    /**
     * Returns true if the result is an `Err` value containing the given value
     * @param value
     * @returns `true` if `Err` and `this.inner === value`, `false` otherwise
     */
    containsErr(value) {
        return false;
    }
    /**
     * Just like `unwrap` but it throws to the closest `Result.unthrow`
     * @returns `this.inner` if `Ok`
     * @throws `this` if `Err`
     * @see Result.unthrow
     * @see Result.unthrowSync
     */
    throw(thrower) {
        this.ignore();
        return this.inner;
    }
    /**
     * Get the inner value or throw the inner error wrapped inside another Error
     * @param message
     * @returns `this.inner` if `Ok`, `Error(message, { cause: this.inner })` if `Err`
     */
    expect(message) {
        this.ignore();
        return this.inner;
    }
    /**
     * Get the inner error or throw the inner value wrapped inside another Error
     * @param message
     * @returns `this.inner` if `Err`, `Error(message, { cause: this.inner })` if `Ok`
     */
    expectErr(message) {
        this.ignore();
        throw Panic.from(new Error(message, { cause: this }));
    }
    /**
     * Get the inner value or panic
     * @returns `this.inner` if `Ok`
     * @throws `this.inner` if `Err`
     */
    unwrap() {
        this.ignore();
        return this.inner;
    }
    /**
     * Get the inner error or panic
     * @returns `this.inner` if `Err`
     * @throws `this.inner` if `Ok`
     */
    unwrapErr() {
        this.ignore();
        throw Panic.from(new Error(`An Ok has been unwrapped`, { cause: this }));
    }
    /**
     * Get the inner value or a default one
     * @param value
     * @returns `this.inner` if `Ok`, `value` if `Err`
     */
    unwrapOr(value) {
        this.ignore();
        return this.inner;
    }
    /**
     * Get the inner value or compute a default one from the inner error
     * @param errMapper
     * @returns `this.inner` if `Ok`, `await errMapper(this.inner)` if `Err`
     * @throws if `await errMapper(this.inner)` throws
     */
    async unwrapOrElse(errMapper) {
        this.ignore();
        return this.inner;
    }
    /**
     * Get the inner value or compute a default one from the inner error
     * @param errMapper
     * @returns `this.inner` if `Ok`, `errMapper(this.inner)` if `Err`
     * @throws if `errMapper(this.inner)` throws
     */
    unwrapOrElseSync(errMapper) {
        this.ignore();
        return this.inner;
    }
    /**
     * Transform Result<Promise<T>, E> into Promise<Result<T, E>>
     * @returns `await this.inner` if `Ok`, `this` if `Err`
     */
    async await() {
        return new ok_Ok(await this.inner);
    }
    /**
     * Transform Result<T, Promise<E>> into Promise<Result<T, E>>
     * @returns `await this.inner` if `Err`, `this` if `Ok`
     */
    async awaitErr() {
        return this;
    }
    /**
     * Transform Result<Promise<T>, Promise<E>> into Promise<Result<T, E>>
     * @returns `await this.inner`
     */
    async awaitAll() {
        return await this.await();
    }
    /**
     * Transform `Result<T, E>` into `Result<void, E>`
     * @returns `Ok<void>` if `Ok<T>`, `Err<E>` if `E<E>`
     */
    clear() {
        this.ignore();
        return ok_Ok.void();
    }
    /**
     * Transform `Result<T, E>` into `Result<T, void>`
     * @returns `Ok<T>` if `Ok<T>`, `Err<void>` if `E<E>`
     */
    clearErr() {
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Ok`
     * @param okCallback
     * @returns `this`
     */
    async inspect(okCallback) {
        await okCallback(this.inner);
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Ok`
     * @param okCallback
     * @returns `this`
     */
    inspectSync(okCallback) {
        okCallback(this.inner);
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Err`
     * @param errCallback
     * @returns `this`
     */
    async inspectErr(errCallback) {
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Err`
     * @param errCallback
     * @returns `this`
     */
    inspectErrSync(errCallback) {
        return this;
    }
    /**
     * Return a new `Ok` but with the given `inner`
     * @param inner
     * @returns `Ok(inner)` if `Ok`, `this` if `Err`
     */
    set(inner) {
        return new ok_Ok(inner);
    }
    /**
     * Return a new `Err` but with the given `inner`
     * @param inner
     * @returns `Err(inner)` if `Err`, `this` if `Ok`
     */
    setErr(inner) {
        return this;
    }
    /**
     * Map the inner value into another
     * @param okMapper
     * @returns `Ok(await okMapper(this.inner))` if `Ok`, `this` if `Err`
     * @throws if `await okMapper(this.inner)` throws
     */
    async map(okMapper) {
        this.ignore();
        return new ok_Ok(await okMapper(this.inner));
    }
    /**
     * Map the inner value into another
     * @param okMapper
     * @returns `Ok(okMapper(this.inner))` if `Ok`, `this` if `Err`
     * @throws if `okMapper(this.inner)` throws
     */
    mapSync(okMapper) {
        this.ignore();
        return new ok_Ok(okMapper(this.inner));
    }
    /**
     * Map the inner error into another
     * @param errMapper
     * @returns `Err(await errMapper(this.inner))` if `Err`, `this` if `Ok`
     * @throws if `await errMapper(this.inner)` throws
     */
    async mapErr(errMapper) {
        return this;
    }
    /**
     * Map the inner error into another
     * @param errMapper
     * @returns `Err(errMapper(this.inner))` if `Err`, `this` if `Ok`
     * @throws if `errMapper(this.inner)` throws
     */
    mapErrSync(errMapper) {
        return this;
    }
    /**
     * Map the inner value into another, or a default one
     * @param value
     * @param okMapper
     * @returns `await okMapper(this.inner)` if `Ok`, `value` if `Err`
     * @throws if `await okMapper(this.inner)` throws
     */
    async mapOr(value, okMapper) {
        this.ignore();
        return await okMapper(this.inner);
    }
    /**
     * Map the inner value into another, or a default one
     * @param value
     * @param okMapper
     * @returns `okMapper(this.inner)` if `Ok`, `value` if `Err`
     * @throws if `okMapper(this.inner)` throws
     */
    mapOrSync(value, okMapper) {
        this.ignore();
        return okMapper(this.inner);
    }
    /**
     * Map the inner value into another, or a default one
     * @param errMapper
     * @param okMapper
     * @returns `await okMapper(this.inner)` if `Ok`, `await errMapper(this.inner)` if `Err`
     * @throws if `await okMapper(this.inner)` or `await errMapper(this.inner)` throws
     */
    async mapOrElse(errMapper, okMapper) {
        this.ignore();
        return await okMapper(this.inner);
    }
    /**
     * Map the inner value into another, or a default one
     * @param errMapper
     * @param okMapper
     * @returns `okMapper(this.inner)` if `Ok`, `errMapper(this.inner)` if `Err`
     * @throws if `okMapper(this.inner)` or `errMapper(this.inner)` throws
     */
    mapOrElseSync(errMapper, okMapper) {
        this.ignore();
        return okMapper(this.inner);
    }
    /**
     * Return `value` if `Ok`, return `this` if `Err`
     * @param value
     * @returns `value` if `Ok`, `this` if `Err`
     */
    and(value) {
        this.ignore();
        return value;
    }
    /**
     * Return `await okMapper(this.inner)` if `Ok`, return `this` if `Err`
     * @param okMapper
     * @returns `await okMapper(this.inner)` if `Ok`, `this` if `Err`
     * @throws if `await okMapper(this.inner)` throws
     */
    async andThen(okMapper) {
        this.ignore();
        return await okMapper(this.inner);
    }
    /**
     * Return `okMapper(this.inner)` if `Ok`, return `this` if `Err`
     * @param okMapper
     * @returns `okMapper(this.inner)` if `Ok`, `this` if `Err`
     * @throws if `okMapper(this.inner)` throws
     */
    andThenSync(okMapper) {
        this.ignore();
        return okMapper(this.inner);
    }
    /**
     * Return `value` if `Err`, return `this` if `Ok`
     * @param value
     * @returns `value` if `Err`, `this` if `Ok`
     */
    or(value) {
        return this;
    }
    /**
     * Return `await errMapper(this.inner)` if `Err`, return `this` if `Ok`
     * @param errMapper
     * @returns `await errMapper(this.inner)` if `Err`, `this` if `Ok`
     * @throws if `await errMapper(this.inner)` throws
     */
    async orElse(errMapper) {
        return this;
    }
    /**
     * Return `errMapper(this.inner)` if `Err`, return `this` if `Ok`
     * @param errMapper
     * @returns `errMapper(this.inner)` if `Err`, `this` if `Ok`
     * @throws if `errMapper(this.inner)` throws
     */
    orElseSync(errMapper) {
        return this;
    }
    /**
     * Transform Result<Result<T, E1>, E2> into Result<T, E1 | E2>
     * @param result
     * @returns `this` if `Err`, `this.inner` if `Ok`
     */
    flatten() {
        return this.inner;
    }
}


//# sourceMappingURL=ok.mjs.map

;// CONCATENATED MODULE: ./src/libs/blobs/blobs.ts


var Blobs;
(function(Blobs) {
    async function readAsDataURL(blob) {
        const future = new Future();
        const reader = new FileReader();
        const onLoad = ()=>{
            future.resolve(reader.result);
        };
        const onError = ()=>{
            future.reject(reader.error);
        };
        try {
            reader.addEventListener("load", onLoad, {
                passive: true
            });
            reader.addEventListener("error", onError, {
                passive: true
            });
            reader.readAsDataURL(blob);
            return await future.promise;
        } finally{
            reader.removeEventListener("load", onLoad);
            reader.removeEventListener("error", onError);
        }
    }
    Blobs.readAsDataURL = readAsDataURL;
    async function tryReadAsDataURL(blob) {
        const future = new Future();
        const reader = new FileReader();
        const onLoad = ()=>{
            future.resolve(new ok_Ok(reader.result));
        };
        const onError = ()=>{
            future.resolve(new err_Err(reader.error));
        };
        try {
            reader.addEventListener("load", onLoad, {
                passive: true
            });
            reader.addEventListener("error", onError, {
                passive: true
            });
            reader.readAsDataURL(blob);
            return await future.promise;
        } finally{
            reader.removeEventListener("load", onLoad);
            reader.removeEventListener("error", onError);
        }
    }
    Blobs.tryReadAsDataURL = tryReadAsDataURL;
})(Blobs || (Blobs = {}));

;// CONCATENATED MODULE: ./node_modules/@swc/helpers/esm/_class_apply_descriptor_get.js
function _class_apply_descriptor_get(receiver, descriptor) {
    if (descriptor.get) return descriptor.get.call(receiver);

    return descriptor.value;
}


;// CONCATENATED MODULE: ./node_modules/@swc/helpers/esm/_class_extract_field_descriptor.js
function _class_extract_field_descriptor(receiver, privateMap, action) {
    if (!privateMap.has(receiver)) throw new TypeError("attempted to " + action + " private field on non-instance");

    return privateMap.get(receiver);
}


;// CONCATENATED MODULE: ./node_modules/@swc/helpers/esm/_class_private_field_get.js



function _class_private_field_get(receiver, privateMap) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "get");
    return _class_apply_descriptor_get(receiver, descriptor);
}


;// CONCATENATED MODULE: ./node_modules/@swc/helpers/esm/_check_private_redeclaration.js
function _check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}


;// CONCATENATED MODULE: ./node_modules/@swc/helpers/esm/_class_private_field_init.js


function _class_private_field_init(obj, privateMap, value) {
    _check_private_redeclaration(obj, privateMap);
    privateMap.set(obj, value);
}


;// CONCATENATED MODULE: ./node_modules/@swc/helpers/esm/_class_apply_descriptor_set.js
function _class_apply_descriptor_set(receiver, descriptor, value) {
    if (descriptor.set) descriptor.set.call(receiver, value);
    else {
        if (!descriptor.writable) {
            // This should only throw in strict mode, but class bodies are
            // always strict and private fields can only be used inside
            // class bodies.
            throw new TypeError("attempted to set read only private field");
        }
        descriptor.value = value;
    }
}


;// CONCATENATED MODULE: ./node_modules/@swc/helpers/esm/_class_private_field_set.js



function _class_private_field_set(receiver, privateMap, value) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "set");
    _class_apply_descriptor_set(receiver, descriptor, value);
    return value;
}


;// CONCATENATED MODULE: ./src/libs/browser/browser.ts



var _a;

var _globalThis_browser;
const browser = (_globalThis_browser = globalThis.browser) !== null && _globalThis_browser !== void 0 ? _globalThis_browser : globalThis.chrome;
var _class = /*#__PURE__*/ new WeakMap();
class BrowserError extends Error {
    static from(cause) {
        return new _a(undefined, {
            cause
        });
    }
    constructor(...args){
        super(...args);
        _class_private_field_init(this, _class, {
            writable: true,
            value: void 0
        });
        _class_private_field_set(this, _class, _a);
        this.name = _class_private_field_get(this, _class).name;
    }
}
_a = BrowserError;
async function tryBrowser(callback) {
    try {
        const result = await callback();
        if (browser.runtime.lastError) return new err_Err(new BrowserError());
        return new ok_Ok(result);
    } catch (e) {
        return new err_Err(new BrowserError());
    }
}
function tryBrowserSync(callback) {
    try {
        const result = callback();
        const error = browser.runtime.lastError;
        if (error) return new err_Err(BrowserError.from(error));
        return new ok_Ok(result);
    } catch (e) {
        return new err_Err(BrowserError.from(e));
    }
}

;// CONCATENATED MODULE: ./node_modules/@hazae41/jsonrpc/dist/esm/mods/rpc/err.mjs


class RpcError extends Error {
    code;
    message;
    data;
    #class = RpcError;
    name = this.#class.name;
    static codes = {
        ParseError: -32700,
        InvalidRequest: -32600,
        MethodNotFound: -32601,
        InvalidParams: -32602,
        InternalError: -32603
    };
    static messages = {
        ParseError: "Parse error",
        InvalidRequest: "Invalid Request",
        MethodNotFound: "Method not found",
        InvalidParams: "Invalid params",
        InternalError: "Internal error",
        ServerError: "Server error"
    };
    constructor(code, message, data = undefined) {
        super(message);
        this.code = code;
        this.message = message;
        this.data = data;
    }
    static from(init) {
        const { code, message, data } = init;
        return new RpcError(code, message, data);
    }
    static rewrap(error) {
        if (error instanceof RpcError)
            return error;
        if (error instanceof Error)
            return new RpcError(-32603, error.message);
        return new RpcError(-32603, "An unknown error occured");
    }
    /**
     * Used by JSON.stringify
     */
    toJSON() {
        const { code, message, data } = this;
        return { code, message, data };
    }
}
class RpcParseError extends RpcError {
    #class = RpcParseError;
    name = this.#class.name;
    static code = RpcError.codes.ParseError;
    static message = RpcError.messages.ParseError;
    constructor() {
        super(RpcError.codes.ParseError, RpcError.messages.ParseError);
    }
}
class RpcInvalidRequestError extends RpcError {
    #class = RpcInvalidRequestError;
    name = this.#class.name;
    static code = RpcError.codes.InvalidRequest;
    static message = RpcError.messages.InvalidRequest;
    constructor() {
        super(RpcError.codes.InvalidRequest, RpcError.messages.InvalidRequest);
    }
}
class RpcMethodNotFoundError extends RpcError {
    #class = RpcMethodNotFoundError;
    name = this.#class.name;
    static code = RpcError.codes.MethodNotFound;
    static message = RpcError.messages.MethodNotFound;
    constructor() {
        super(RpcError.codes.MethodNotFound, RpcError.messages.MethodNotFound);
    }
}
class RpcInvalidParamsError extends RpcError {
    #class = RpcInvalidParamsError;
    name = this.#class.name;
    static code = RpcError.codes.InvalidParams;
    static message = RpcError.messages.InvalidParams;
    constructor() {
        super(RpcError.codes.InvalidParams, RpcError.messages.InvalidParams);
    }
}
class RpcInternalError extends RpcError {
    #class = RpcInternalError;
    name = this.#class.name;
    static code = RpcError.codes.InternalError;
    static message = RpcError.messages.InternalError;
    constructor() {
        super(RpcError.codes.InternalError, RpcError.messages.InternalError);
    }
}
class RpcErr extends err_Err {
    id;
    error;
    jsonrpc = "2.0";
    constructor(id, error) {
        super(error);
        this.id = id;
        this.error = error;
    }
    static from(init) {
        return new RpcErr(init.id, RpcError.from(init.error));
    }
    static rewrap(id, result) {
        return new RpcErr(id, RpcError.rewrap(result.inner));
    }
}


//# sourceMappingURL=err.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/jsonrpc/dist/esm/mods/rpc/ok.mjs


var RpcOkInit;
(function (RpcOkInit) {
    function from(response) {
        const { jsonrpc, id, result } = response;
        return { jsonrpc, id, result };
    }
    RpcOkInit.from = from;
})(RpcOkInit || (RpcOkInit = {}));
class RpcOk extends ok_Ok {
    id;
    result;
    jsonrpc = "2.0";
    constructor(id, result) {
        super(result);
        this.id = id;
        this.result = result;
    }
    static from(init) {
        return new RpcOk(init.id, init.result);
    }
    static rewrap(id, result) {
        return new RpcOk(id, result.inner);
    }
}


//# sourceMappingURL=ok.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/jsonrpc/dist/esm/mods/rpc/response.mjs



var RpcResponse;
(function (RpcResponse) {
    function from(init) {
        if ("error" in init)
            return RpcErr.from(init);
        return RpcOk.from(init);
    }
    RpcResponse.from = from;
    function rewrap(id, result) {
        if (result.isErr())
            return RpcErr.rewrap(id, result);
        return RpcOk.rewrap(id, result);
    }
    RpcResponse.rewrap = rewrap;
})(RpcResponse || (RpcResponse = {}));


//# sourceMappingURL=response.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/jsonrpc/dist/esm/mods/rpc/request.mjs
class RpcRequest {
    id;
    method;
    params;
    jsonrpc = "2.0";
    constructor(id, method, params) {
        this.id = id;
        this.method = method;
        this.params = params;
    }
    static from(init) {
        const { id, method, params } = init;
        return new RpcRequest(id, method, params);
    }
    toJSON() {
        const { jsonrpc, id, method, params } = this;
        return { jsonrpc, id, method, params };
    }
}


//# sourceMappingURL=request.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/jsonrpc/dist/esm/mods/rpc/rpc.mjs


class RpcCounter {
    id = 0;
    prepare(init) {
        return new RpcRequest(this.id++, init.method, init.params);
    }
}


//# sourceMappingURL=rpc.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/cleaner/dist/esm/libs/unpromise/unpromise.mjs
var Unpromise;
(function (Unpromise) {
    /**
     * Like Promise.all but sync
     * @param callbacks
     * @returns
     */
    function all(callbacks) {
        const results = new Array();
        let error = undefined;
        for (const callback of callbacks) {
            try {
                results.push(callback());
            }
            catch (e) {
                error = { e };
            }
        }
        if (error)
            throw error.e;
        return results;
    }
    Unpromise.all = all;
})(Unpromise || (Unpromise = {}));


//# sourceMappingURL=unpromise.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/cleaner/dist/esm/mods/dispose/dispose.mjs


class Disposer {
    inner;
    dispose;
    constructor(inner, dispose) {
        this.inner = inner;
        this.dispose = dispose;
    }
    static from(disposable) {
        return new Disposer(disposable, () => disposable[Symbol.dispose]());
    }
    [Symbol.dispose]() {
        this.dispose();
    }
}
class AsyncDisposer {
    inner;
    asyncDispose;
    constructor(inner, asyncDispose) {
        this.inner = inner;
        this.asyncDispose = asyncDispose;
    }
    static from(disposable) {
        return new AsyncDisposer(disposable, () => disposable[Symbol.asyncDispose]());
    }
    async [Symbol.asyncDispose]() {
        await this.asyncDispose();
    }
}
class PromiseDisposer {
    inner;
    dispose;
    constructor(inner, dispose) {
        this.inner = inner;
        this.dispose = dispose;
    }
    static from(disposable) {
        return new PromiseDisposer(disposable, () => disposable[Symbol.dispose]());
    }
    then(onfulfilled, onrejected) {
        return this.inner.then(onfulfilled, onrejected);
    }
    [Symbol.dispose]() {
        this.dispose();
    }
}
class AsyncPromiseDisposer {
    inner;
    asyncDispose;
    constructor(inner, asyncDispose) {
        this.inner = inner;
        this.asyncDispose = asyncDispose;
    }
    static from(disposable) {
        return new PromiseDisposer(disposable, () => disposable[Symbol.asyncDispose]());
    }
    then(onfulfilled, onrejected) {
        return this.inner.then(onfulfilled, onrejected);
    }
    async [Symbol.asyncDispose]() {
        await this.asyncDispose();
    }
}
var Disposable;
(function (Disposable) {
    async function dispose(disposable) {
        if (Symbol.dispose in disposable)
            disposable[Symbol.dispose]();
        else if (Symbol.asyncDispose)
            await disposable[Symbol.asyncDispose]();
    }
    Disposable.dispose = dispose;
    function disposeSync(disposable) {
        disposable[Symbol.dispose]();
    }
    Disposable.disposeSync = disposeSync;
    async function race(promises) {
        try {
            return await Promise.race(promises);
        }
        finally {
            await Promise.all(promises.map(dispose));
        }
    }
    Disposable.race = race;
    async function raceSync(promises) {
        try {
            return await Promise.race(promises);
        }
        finally {
            Unpromise.all(promises.map(it => () => disposeSync(it)));
        }
    }
    Disposable.raceSync = raceSync;
})(Disposable || (Disposable = {}));


//# sourceMappingURL=dispose.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/plume/dist/esm/mods/errors.mjs





class AbortedError extends Error {
    #class = AbortedError;
    name = this.#class.name;
    static from(cause) {
        return new AbortedError(`Aborted`, { cause });
    }
    static wait(signal) {
        const future = new Future();
        const onAbort = (event) => {
            future.resolve(new err_Err(AbortedError.from(event)));
        };
        signal.addEventListener("abort", onAbort, { passive: true });
        const off = () => signal.removeEventListener("abort", onAbort);
        return new PromiseDisposer(future.promise, off);
    }
}
class ErroredError extends Error {
    #class = ErroredError;
    name = this.#class.name;
    static from(cause) {
        return new ErroredError(`Errored`, { cause });
    }
    static wait(target) {
        return target.wait("error", (future, event) => {
            const error = ErroredError.from(event);
            future.resolve(new err_Err(error));
            return new None();
        });
    }
}
class ClosedError extends Error {
    #class = ClosedError;
    name = this.#class.name;
    static from(cause) {
        return new ClosedError(`Closed`, { cause });
    }
    static wait(target) {
        return target.wait("close", (future, event) => {
            const error = ClosedError.from(event);
            future.resolve(new err_Err(error));
            return new None();
        });
    }
}


//# sourceMappingURL=errors.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/plume/dist/esm/mods/waiters.mjs



async function tryWaitOrSignal(target, type, callback, signal) {
    const abort = AbortedError.wait(signal);
    const event = target.wait(type, callback);
    return await Disposable.raceSync([abort, event]);
}
async function tryWaitOrCloseOrError(target, type, callback) {
    const error = ErroredError.wait(target);
    const close = ClosedError.wait(target);
    const event = target.wait(type, callback);
    return await Disposable.raceSync([error, close, event]);
}
async function tryWaitOrCloseOrErrorOrSignal(target, type, callback, signal) {
    const abort = AbortedError.wait(signal);
    const error = ErroredError.wait(target);
    const close = ClosedError.wait(target);
    const event = target.wait(type, callback);
    return await Disposable.raceSync([abort, error, close, event]);
}


//# sourceMappingURL=waiters.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/plume/dist/esm/mods/target.mjs




class EventError extends (/* unused pure expression or super */ null && (Error)) {
    #class = EventError;
    name = this.#class.name;
    constructor(cause) {
        super(`Event failed`, { cause });
    }
    static new(cause) {
        return new EventError(cause);
    }
}
class SuperEventTarget {
    #listeners = new Map();
    get listeners() {
        return this.#listeners;
    }
    /**
     * Add a listener to an event
     * @param type Event type //  "abort", "error", "message", "close"
     * @param listener Event listener // (e) => new Some(123)
     * @param options Options // { passive: true }
     * @returns
     */
    on(type, listener, options = {}) {
        let listeners = this.#listeners.get(type);
        if (listeners === undefined) {
            listeners = new Map();
            this.#listeners.set(type, listeners);
        }
        const off = () => this.off(type, listener);
        const internalOptions = { ...options, off };
        internalOptions.signal?.addEventListener("abort", off, { passive: true });
        listeners.set(listener, internalOptions);
        return off;
    }
    /**
     * Remove a listener from an event
     * @param type Event type //  "abort", "error", "message", "close"
     * @param listener Event listener // (e) => console.log("hello")
     * @param options Just to look like DOM's EventTarget
     * @returns
     */
    off(type, listener) {
        const listeners = this.#listeners.get(type);
        if (!listeners)
            return;
        const options = listeners.get(listener);
        if (!options)
            return;
        options.signal?.removeEventListener("abort", options.off);
        listeners.delete(listener);
        if (listeners.size > 0)
            return;
        this.#listeners.delete(type);
    }
    /**
     * Dispatch an event to its listeners
     *
     * - Dispatch to active listeners sequencially
     * - Return if one of the listeners returned something
     * - Dispatch to passive listeners concurrently
     * - Return if one of the listeners returned something
     * - Return nothing
     * @param value The object to emit
     * @returns `Some` if the event
     */
    async emit(type, value) {
        const listeners = this.#listeners.get(type);
        if (!listeners)
            return new None();
        const promises = new Array();
        for (const [listener, options] of listeners) {
            if (options.passive)
                continue;
            if (options.once)
                this.off(type, listener);
            const returned = await listener(...value);
            if (returned.isNone())
                continue;
            return returned;
        }
        for (const [listener, options] of listeners) {
            if (!options.passive)
                continue;
            if (options.once)
                this.off(type, listener);
            const returned = listener(...value);
            if (returned instanceof Promise) {
                promises.push(returned);
                continue;
            }
            if (returned.isNone())
                continue;
            return returned;
        }
        const returneds = await Promise.all(promises);
        for (const returned of returneds)
            if (returned.isSome())
                return returned;
        return new None();
    }
    /**
     * Like `.on`, but instead of returning to the target, capture the returned value in a future, and return nothing to the target
     * @param type
     * @param callback
     * @returns
     */
    wait(type, callback) {
        const future = new Future();
        const onEvent = async (...params) => {
            try {
                return await callback(future, ...params);
            }
            catch (e) {
                future.reject(e);
                throw e;
            }
        };
        const off = this.on(type, onEvent, { passive: true });
        return new PromiseDisposer(future.promise, off);
    }
}


//# sourceMappingURL=target.mjs.map

;// CONCATENATED MODULE: ./src/libs/channel/channel.ts





class WebsitePort {
    [Symbol.dispose]() {
        this.clean();
    }
    async runPingLoop() {
        let count = 0;
        while(true){
            await new Promise((ok)=>setTimeout(ok, 1000));
            const result = await this.tryPingOrSignal(AbortSignal.timeout(1000)).then((r)=>r.flatten());
            if (result.isErr()) count++;
            else count = 0;
            if (count === 2) {
                await this.events.emit("close", [
                    undefined
                ]);
                return;
            }
        }
    }
    async tryRouteRequest(request) {
        if (request.method === "brume_ping") return ok_Ok.void();
        const returned = await this.events.emit("request", [
            request
        ]);
        if (returned.isSome()) return returned.inner;
        return new err_Err(new Error("Unhandled JSON-RPC request ".concat(JSON.stringify(request))));
    }
    async onRequest(request) {
        // if (request.id !== "ping")
        //   console.debug(this.name, "->", request)
        const result = await this.tryRouteRequest(request);
        const response = RpcResponse.rewrap(request.id, result);
        // if (request.id !== "ping")
        //   console.debug(this.name, "<-", response)
        this.port.postMessage(JSON.stringify(response));
    }
    async onResponse(response) {
        // if (response.id !== "ping")
        //   console.debug(this.name, "->", response)
        const returned = await this.events.emit("response", [
            response
        ]);
        if (returned.isSome()) return returned.inner;
        return new err_Err(new Error("Unhandled JSON-RPC response ".concat(JSON.stringify(response))));
    }
    async onMessage(message) {
        const data = JSON.parse(message.data);
        if ("method" in data) return await this.onRequest(data);
        return await this.onResponse(data);
    }
    async tryRequest(init) {
        const request = this.counter.prepare(init);
        // if (request.id !== "ping")
        //   console.debug(this.name, "<-", request)
        this.port.postMessage(JSON.stringify(request));
        return tryWaitOrCloseOrError(this.events, "response", (future, init)=>{
            if (init.id !== request.id) return new None();
            const response = RpcResponse.from(init);
            future.resolve(new ok_Ok(response));
            return new Some(undefined);
        });
    }
    async tryPingOrSignal(signal) {
        const request = {
            id: "ping",
            method: "brume_ping"
        };
        this.port.postMessage(JSON.stringify(request));
        return tryWaitOrCloseOrErrorOrSignal(this.events, "response", (future, init)=>{
            if (init.id !== request.id) return new None();
            const response = RpcResponse.from(init);
            future.resolve(new ok_Ok(response));
            return new Some(undefined);
        }, signal);
    }
    constructor(name, port){
        this.counter = new RpcCounter();
        this.uuid = crypto.randomUUID();
        this.events = new SuperEventTarget();
        this.name = name;
        this.port = port;
        const onMessage = this.onMessage.bind(this);
        this.port.addEventListener("message", onMessage, {
            passive: true
        });
        this.clean = ()=>{
            this.port.removeEventListener("message", onMessage);
        };
    }
}
class ExtensionPort {
    [Symbol.dispose]() {
        this.clean();
    }
    async tryRouteRequest(request) {
        if (request.method === "brume_ping") return ok_Ok.void();
        const returned = await this.events.emit("request", [
            request
        ]);
        if (returned.isSome()) return returned.inner;
        return new err_Err(new Error("Unhandled JSON-RPC request ".concat(JSON.stringify(request))));
    }
    async onRequest(request) {
        if (request.id !== "ping") console.debug(this.name, "->", request);
        const result = await this.tryRouteRequest(request);
        const response = RpcResponse.rewrap(request.id, result);
        if (request.id !== "ping") console.debug(this.name, "<-", response);
        tryBrowserSync(()=>{
            this.port.postMessage(JSON.stringify(response));
        }).ignore();
    }
    async onResponse(response) {
        if (response.id !== "ping") console.debug(this.name, "->", response);
        const returned = await this.events.emit("response", [
            response
        ]);
        if (returned.isSome()) return returned.inner;
        return new err_Err(new Error("Unhandled JSON-RPC response ".concat(JSON.stringify(response))));
    }
    async onMessage(message) {
        const data = JSON.parse(message);
        if ("method" in data) return await this.onRequest(data);
        return await this.onResponse(data);
    }
    async onDisconnect() {
        await this.events.emit("close", [
            undefined
        ]);
    }
    async tryRequest(init) {
        return await Result.unthrow(async (t)=>{
            const request = this.counter.prepare(init);
            if (request.id !== "ping") console.debug(this.name, "<-", request);
            tryBrowserSync(()=>{
                this.port.postMessage(JSON.stringify(request));
            }).throw(t);
            return tryWaitOrCloseOrError(this.events, "response", (future, init)=>{
                if (init.id !== request.id) return new None();
                const response = RpcResponse.from(init);
                future.resolve(new ok_Ok(response));
                return new Some(undefined);
            });
        });
    }
    constructor(name, port){
        this.counter = new RpcCounter();
        this.uuid = crypto.randomUUID();
        this.events = new SuperEventTarget();
        this.name = name;
        this.port = port;
        const onMessage = this.onMessage.bind(this);
        const onDisconnect = this.onDisconnect.bind(this);
        this.port.onMessage.addListener(onMessage);
        this.port.onDisconnect.addListener(onDisconnect);
        this.clean = ()=>{
            this.port.onMessage.removeListener(onMessage);
            this.port.onDisconnect.removeListener(onDisconnect);
        };
    }
}

;// CONCATENATED MODULE: ./src/libs/fetch/fetch.ts

async function tryFetch(input, init) {
    try {
        const res = await fetch(input, init);
        if (!res.ok) return new Err(new Error(await res.text()));
        return new Ok(res);
    } catch (e) {
        return new Err(Catched.from(e));
    }
}
async function tryFetchAsJson(input, init) {
    try {
        const res = await fetch(input, init);
        if (!res.ok) return new err_Err(new Error(await res.text()));
        return new ok_Ok(await res.json());
    } catch (e) {
        return new err_Err(errors_Catched.from(e));
    }
}
async function tryFetchAsBlob(input, init) {
    try {
        const res = await fetch(input, init);
        if (!res.ok) return new err_Err(new Error(await res.text()));
        return new ok_Ok(await res.blob());
    } catch (e) {
        return new err_Err(errors_Catched.from(e));
    }
}

;// CONCATENATED MODULE: ./node_modules/@hazae41/arrays/dist/esm/mods/arrays/arrays.mjs
/**
 * Get the last value
 * @param array
 * @returns
 */
function last(array) {
    if (array.length === 0)
        return undefined;
    return array[lastIndex(array)];
}
/**
 * Get the last index
 * @param array
 * @returns
 */
function lastIndex(array) {
    return array.length - 1;
}
/**
 * Get a random value using Math's PRNG
 * @param array
 * @returns
 */
function random(array) {
    if (array.length === 0)
        return undefined;
    return array[randomIndex(array)];
}
/**
 * Get a random index using Math's PRNG
 * @param array
 * @returns
 */
function randomIndex(array) {
    return Math.floor(Math.random() * array.length);
}
/**
 * Get a random value using WebCrypto's CSPRNG
 * @param array
 * @returns
 */
function cryptoRandom(array) {
    if (array.length === 0)
        return undefined;
    return array[cryptoRandomIndex(array)];
}
/**
 * Get a random value using WebCrypto's CSPRNG
 * @param array
 * @returns
 */
function cryptoRandomIndex(array) {
    const values = new Uint32Array(1);
    crypto.getRandomValues(values);
    return values[0] % array.length;
}
/**
 * Get a random value using Math's PRNG and delete it from the array
 * @param array
 * @returns
 */
function takeRandom(array) {
    if (array.length === 0)
        return undefined;
    const index = randomIndex(array);
    const element = array[index];
    array.splice(index, 1);
    return element;
}
/**
 * Get a random value using WebCrypto's CSPRNG and delete it from the array
 * @param array
 * @returns
 */
function takeCryptoRandom(array) {
    if (array.length === 0)
        return undefined;
    const index = cryptoRandomIndex(array);
    const element = array[index];
    array.splice(index, 1);
    return element;
}


//# sourceMappingURL=arrays.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/mutex/dist/esm/mods/mutex/mutex.mjs



class MutexLockError extends Error {
    #class = MutexLockError;
    name = this.#class.name;
    constructor() {
        super(`Could not lock mutex`);
    }
}
class Mutex {
    inner;
    promise;
    /**
     * Just a mutex
     */
    constructor(inner) {
        this.inner = inner;
    }
    get locked() {
        return this.promise != null;
    }
    acquire() {
        const future = new Future();
        const promise = this.promise;
        this.lock(() => future.promise);
        const release = () => future.resolve();
        const access = new Lock(this.inner, release);
        return promise
            ? promise.then(() => access)
            : access;
    }
    /**
     * Lock this mutex
     * @param callback
     * @returns
     */
    lock(callback) {
        const promise = this.promise
            ? this.promise.then(() => callback(this.inner))
            : callback(this.inner);
        const pure = promise
            .then(() => { })
            .catch(() => { });
        this.promise = pure;
        pure.finally(() => {
            if (this.promise !== pure)
                return;
            this.promise = undefined;
        });
        return promise;
    }
    /**
     * Try to lock this mutex
     * @param callback
     * @returns
     */
    tryLock(callback) {
        if (this.promise != null)
            return new err_Err(new MutexLockError());
        const promise = callback(this.inner);
        const pure = promise
            .then(() => { })
            .catch(() => { });
        this.promise = pure;
        pure.finally(() => {
            if (this.promise !== pure)
                return;
            this.promise = undefined;
        });
        return new ok_Ok(promise);
    }
}
class Lock {
    inner;
    release;
    constructor(inner, release) {
        this.inner = inner;
        this.release = release;
    }
    [Symbol.dispose]() {
        this.release();
    }
}


//# sourceMappingURL=mutex.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/piscine/dist/esm/libs/signals/signals.mjs
var AbortSignals;
(function (AbortSignals) {
    function never() {
        return new AbortController().signal;
    }
    AbortSignals.never = never;
    function timeout(delay, parent) {
        return merge(AbortSignal.timeout(delay), parent);
    }
    AbortSignals.timeout = timeout;
    function merge(a, b) {
        if (b === undefined)
            return a;
        const c = new AbortController();
        const onAbort = (reason) => {
            c.abort(reason);
            a.removeEventListener("abort", onAbort);
            b.removeEventListener("abort", onAbort);
        };
        a.addEventListener("abort", onAbort, { passive: true });
        b.addEventListener("abort", onAbort, { passive: true });
        return c.signal;
    }
    AbortSignals.merge = merge;
})(AbortSignals || (AbortSignals = {}));


//# sourceMappingURL=signals.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/piscine/dist/esm/mods/pool/pool.mjs








var PoolOkEntry;
(function (PoolOkEntry) {
    function is(x) {
        return x.result.isOk();
    }
    PoolOkEntry.is = is;
})(PoolOkEntry || (PoolOkEntry = {}));
class EmptyPoolError extends Error {
    #class = EmptyPoolError;
    name = this.#class.name;
    constructor() {
        super(`Empty pool`);
    }
}
class EmptySlotError extends Error {
    #class = EmptySlotError;
    name = this.#class.name;
    constructor() {
        super(`Empty pool slot`);
    }
}
class Pool {
    creator;
    params;
    #capacity;
    events = new SuperEventTarget();
    signal;
    #controller;
    mutex = new Mutex(undefined);
    /**
     * Entry by index, can be sparse
     */
    #allEntries;
    /**
     * Promise by index, can be sparse
     */
    #allPromises;
    /**
     * Entries that are ok
     */
    #okEntries = new Set();
    /**
     * Promises that are started (running or settled)
     */
    #okPromises = new Set();
    /**
     * A pool of circuits
     * @param tor
     * @param params
     */
    constructor(creator, params = {}) {
        this.creator = creator;
        this.params = params;
        const { capacity = 3 } = params;
        this.#capacity = capacity;
        this.#controller = new AbortController();
        this.signal = AbortSignals.merge(this.#controller.signal, params.signal);
        this.#allEntries = new Array(capacity);
        this.#allPromises = new Array(capacity);
        for (let index = 0; index < capacity; index++)
            this.#start(index).catch(console.warn);
    }
    /**
     * Whether all entries are errored
     */
    get stagnant() {
        return this.#allEntries.every(entry => entry.result.isErr());
    }
    abort(reason) {
        this.#controller.abort(reason);
    }
    async #start(index) {
        const promise = this.#createAndUnwrap(index);
        this.#allPromises[index] = promise;
        this.#okPromises.add(promise);
        /**
         * Set promise as handled
         */
        promise.catch(() => { });
        await this.events.emit("started", [index]);
    }
    async #tryCreate(index) {
        const { signal } = this;
        if (signal.aborted)
            return new err_Err(AbortedError.from(signal.reason));
        return await this.creator({ pool: this, index, signal });
    }
    async #createAndUnwrap(index) {
        const result = await Result.runAndDoubleWrap(() => {
            return this.#tryCreate(index);
        }).then(Result.flatten);
        if (result.isOk()) {
            const entry = { index, result };
            this.#allEntries[index] = entry;
            this.#okEntries.add(entry);
            await this.events.emit("created", [entry]);
            return entry;
        }
        else {
            const entry = { index, result };
            this.#allEntries[index] = entry;
            await this.events.emit("created", [entry]);
            throw result.inner;
        }
    }
    async #delete(index) {
        const entry = this.#allEntries.at(index);
        if (entry == null)
            return undefined;
        const promise = this.#allPromises.at(index);
        if (promise == null)
            throw Panic.from(new Error(`Promise is null`));
        this.#okPromises.delete(promise);
        delete this.#allPromises[index];
        if (PoolOkEntry.is(entry)) {
            await Disposable.dispose(entry.result.inner);
            this.#okEntries.delete(entry);
        }
        delete this.#allEntries[index];
        await this.events.emit("deleted", [entry]);
        return entry;
    }
    /**
     * Restart the index and return the previous entry
     * @param element
     * @returns
     */
    async restart(index) {
        return await this.mutex.lock(async () => {
            const entry = await this.#delete(index);
            await this.#start(index);
            return entry;
        });
    }
    /**
     * Modify capacity
     * @param capacity
     * @returns
     */
    async growOrShrink(capacity) {
        return await this.mutex.lock(async () => {
            if (capacity > this.#capacity) {
                const previous = this.#capacity;
                this.#capacity = capacity;
                for (let i = previous; i < capacity; i++)
                    await this.#start(i);
                return previous;
            }
            else if (capacity < this.#capacity) {
                const previous = this.#capacity;
                this.#capacity = capacity;
                for (let i = capacity; i < previous; i++)
                    await this.#delete(i);
                return previous;
            }
            return this.#capacity;
        });
    }
    /**
     * Number of open elements
     */
    get size() {
        return this.#okEntries.size;
    }
    /**
     * Number of slots
     */
    get capacity() {
        return this.#capacity;
    }
    /**
     * Iterator on open elements
     * @returns
     */
    [Symbol.iterator]() {
        return this.#okEntries.values();
    }
    /**
     * Get the element at index, if still loading, wait for it, if not started, wait for started until signal, and wait for it
     * @param index
     * @param signal
     * @returns
     */
    async tryGetOrWait(index, signal = AbortSignals.never()) {
        const current = await this.tryGet(index);
        if (current.isOk())
            return current.inner;
        const aborted = await tryWaitOrSignal(this.events, "started", (future, i) => {
            if (i !== index)
                return new None();
            future.resolve(ok_Ok.void());
            return new None();
        }, signal);
        if (aborted.isErr())
            return aborted;
        return await this.tryGet(index).then(r => r.unwrap());
    }
    /**
     * Get the element at index, if still loading, wait for it, err if not started
     * @param index
     * @returns
     */
    async tryGet(index) {
        await this.mutex.promise;
        const slot = this.#allPromises.at(index);
        if (slot === undefined)
            return new err_Err(new EmptySlotError());
        try {
            return new ok_Ok(await slot.then(r => r.result));
        }
        catch (e) {
            return new ok_Ok(new err_Err(e));
        }
    }
    /**
     * Get the element at index, err if empty
     * @param index
     * @returns
     */
    async tryGetSync(index) {
        await this.mutex.promise;
        const slot = this.#allEntries.at(index);
        if (slot === undefined)
            return new err_Err(new EmptySlotError());
        return new ok_Ok(slot.result);
    }
    /**
     * Wait for any element to be created, then get a random one using Math's PRNG
     * @returns
     */
    async tryGetRandom() {
        await this.mutex.promise;
        const first = await Result
            .runAndWrap(() => Promise.any(this.#okPromises))
            .then(r => r.mapErrSync(e => e));
        if (first.isErr())
            return first;
        const random = await this.tryGetRandomSync();
        if (random.isOk())
            return random;
        /**
         * The element has been deleted already?
         */
        console.error(`Could not get random element`, { first });
        throw Panic.from(new Error(`Could not get random element`));
    }
    /**
     * Get a random element from the pool using Math's PRNG, throws if none available
     * @returns
     */
    async tryGetRandomSync() {
        await this.mutex.promise;
        if (this.#okEntries.size === 0)
            return new err_Err(new EmptyPoolError());
        const entries = [...this.#okEntries];
        const entry = random(entries);
        return new ok_Ok(entry);
    }
    /**
     * Wait for any element to be created, then get a random one using WebCrypto's CSPRNG
     * @returns
     */
    async tryGetCryptoRandom() {
        await this.mutex.promise;
        const first = await Result
            .runAndWrap(() => Promise.any(this.#okPromises))
            .then(r => r.mapErrSync(e => e));
        if (first.isErr())
            return first;
        const random = await this.tryGetCryptoRandomSync();
        if (random.isOk())
            return random;
        /**
         * The element has been deleted already?
         */
        console.error(`Could not get random element`, { first });
        throw Panic.from(new Error(`Could not get random element`));
    }
    /**
     * Get a random element from the pool using WebCrypto's CSPRNG, throws if none available
     * @returns
     */
    async tryGetCryptoRandomSync() {
        await this.mutex.promise;
        if (this.#okEntries.size === 0)
            return new err_Err(new EmptyPoolError());
        const entries = [...this.#okEntries];
        const entry = cryptoRandom(entries);
        return new ok_Ok(entry);
    }
    static async takeRandom(pool) {
        return await pool.lock(async (pool) => {
            const result = await pool.tryGetRandom();
            if (result.isOk())
                pool.restart(result.inner.index);
            return result;
        });
    }
    static async takeCryptoRandom(pool) {
        return await pool.lock(async (pool) => {
            const result = await pool.tryGetCryptoRandom();
            if (result.isOk())
                pool.restart(result.inner.index);
            return result;
        });
    }
}


//# sourceMappingURL=pool.mjs.map

;// CONCATENATED MODULE: ./src/mods/background/content_script/index.ts










const mouse = {
    x: window.screen.width / 2,
    y: window.screen.height / 2
};
addEventListener("mousemove", (e)=>{
    mouse.x = e.screenX;
    mouse.y = e.screenY;
}, {
    passive: true
});
if (false || true) {
    const container = document.documentElement;
    const scriptBody = atob("LyoqKioqKi8gKCgpID0+IHsgLy8gd2VicGFja0Jvb3RzdHJhcAovKioqKioqLyAJInVzZSBzdHJpY3QiOwp2YXIgX193ZWJwYWNrX2V4cG9ydHNfXyA9IHt9OwoKOy8vIENPTkNBVEVOQVRFRCBNT0RVTEU6IC4vbm9kZV9tb2R1bGVzL0Bzd2MvaGVscGVycy9lc20vX2NsYXNzX2FwcGx5X2Rlc2NyaXB0b3JfZ2V0LmpzCmZ1bmN0aW9uIF9jbGFzc19hcHBseV9kZXNjcmlwdG9yX2dldChyZWNlaXZlciwgZGVzY3JpcHRvcikgewogICAgaWYgKGRlc2NyaXB0b3IuZ2V0KSByZXR1cm4gZGVzY3JpcHRvci5nZXQuY2FsbChyZWNlaXZlcik7CgogICAgcmV0dXJuIGRlc2NyaXB0b3IudmFsdWU7Cn0KCgo7Ly8gQ09OQ0FURU5BVEVEIE1PRFVMRTogLi9ub2RlX21vZHVsZXMvQHN3Yy9oZWxwZXJzL2VzbS9fY2xhc3NfZXh0cmFjdF9maWVsZF9kZXNjcmlwdG9yLmpzCmZ1bmN0aW9uIF9jbGFzc19leHRyYWN0X2ZpZWxkX2Rlc2NyaXB0b3IocmVjZWl2ZXIsIHByaXZhdGVNYXAsIGFjdGlvbikgewogICAgaWYgKCFwcml2YXRlTWFwLmhhcyhyZWNlaXZlcikpIHRocm93IG5ldyBUeXBlRXJyb3IoImF0dGVtcHRlZCB0byAiICsgYWN0aW9uICsgIiBwcml2YXRlIGZpZWxkIG9uIG5vbi1pbnN0YW5jZSIpOwoKICAgIHJldHVybiBwcml2YXRlTWFwLmdldChyZWNlaXZlcik7Cn0KCgo7Ly8gQ09OQ0FURU5BVEVEIE1PRFVMRTogLi9ub2RlX21vZHVsZXMvQHN3Yy9oZWxwZXJzL2VzbS9fY2xhc3NfcHJpdmF0ZV9maWVsZF9nZXQuanMKCgoKZnVuY3Rpb24gX2NsYXNzX3ByaXZhdGVfZmllbGRfZ2V0KHJlY2VpdmVyLCBwcml2YXRlTWFwKSB7CiAgICB2YXIgZGVzY3JpcHRvciA9IF9jbGFzc19leHRyYWN0X2ZpZWxkX2Rlc2NyaXB0b3IocmVjZWl2ZXIsIHByaXZhdGVNYXAsICJnZXQiKTsKICAgIHJldHVybiBfY2xhc3NfYXBwbHlfZGVzY3JpcHRvcl9nZXQocmVjZWl2ZXIsIGRlc2NyaXB0b3IpOwp9CgoKOy8vIENPTkNBVEVOQVRFRCBNT0RVTEU6IC4vbm9kZV9tb2R1bGVzL0Bzd2MvaGVscGVycy9lc20vX2NoZWNrX3ByaXZhdGVfcmVkZWNsYXJhdGlvbi5qcwpmdW5jdGlvbiBfY2hlY2tfcHJpdmF0ZV9yZWRlY2xhcmF0aW9uKG9iaiwgcHJpdmF0ZUNvbGxlY3Rpb24pIHsKICAgIGlmIChwcml2YXRlQ29sbGVjdGlvbi5oYXMob2JqKSkgewogICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoIkNhbm5vdCBpbml0aWFsaXplIHRoZSBzYW1lIHByaXZhdGUgZWxlbWVudHMgdHdpY2Ugb24gYW4gb2JqZWN0Iik7CiAgICB9Cn0KCgo7Ly8gQ09OQ0FURU5BVEVEIE1PRFVMRTogLi9ub2RlX21vZHVsZXMvQHN3Yy9oZWxwZXJzL2VzbS9fY2xhc3NfcHJpdmF0ZV9maWVsZF9pbml0LmpzCgoKZnVuY3Rpb24gX2NsYXNzX3ByaXZhdGVfZmllbGRfaW5pdChvYmosIHByaXZhdGVNYXAsIHZhbHVlKSB7CiAgICBfY2hlY2tfcHJpdmF0ZV9yZWRlY2xhcmF0aW9uKG9iaiwgcHJpdmF0ZU1hcCk7CiAgICBwcml2YXRlTWFwLnNldChvYmosIHZhbHVlKTsKfQoKCjsvLyBDT05DQVRFTkFURUQgTU9EVUxFOiAuL25vZGVfbW9kdWxlcy9Ac3djL2hlbHBlcnMvZXNtL19jbGFzc19hcHBseV9kZXNjcmlwdG9yX3NldC5qcwpmdW5jdGlvbiBfY2xhc3NfYXBwbHlfZGVzY3JpcHRvcl9zZXQocmVjZWl2ZXIsIGRlc2NyaXB0b3IsIHZhbHVlKSB7CiAgICBpZiAoZGVzY3JpcHRvci5zZXQpIGRlc2NyaXB0b3Iuc2V0LmNhbGwocmVjZWl2ZXIsIHZhbHVlKTsKICAgIGVsc2UgewogICAgICAgIGlmICghZGVzY3JpcHRvci53cml0YWJsZSkgewogICAgICAgICAgICAvLyBUaGlzIHNob3VsZCBvbmx5IHRocm93IGluIHN0cmljdCBtb2RlLCBidXQgY2xhc3MgYm9kaWVzIGFyZQogICAgICAgICAgICAvLyBhbHdheXMgc3RyaWN0IGFuZCBwcml2YXRlIGZpZWxkcyBjYW4gb25seSBiZSB1c2VkIGluc2lkZQogICAgICAgICAgICAvLyBjbGFzcyBib2RpZXMuCiAgICAgICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoImF0dGVtcHRlZCB0byBzZXQgcmVhZCBvbmx5IHByaXZhdGUgZmllbGQiKTsKICAgICAgICB9CiAgICAgICAgZGVzY3JpcHRvci52YWx1ZSA9IHZhbHVlOwogICAgfQp9CgoKOy8vIENPTkNBVEVOQVRFRCBNT0RVTEU6IC4vbm9kZV9tb2R1bGVzL0Bzd2MvaGVscGVycy9lc20vX2NsYXNzX3ByaXZhdGVfZmllbGRfc2V0LmpzCgoKCmZ1bmN0aW9uIF9jbGFzc19wcml2YXRlX2ZpZWxkX3NldChyZWNlaXZlciwgcHJpdmF0ZU1hcCwgdmFsdWUpIHsKICAgIHZhciBkZXNjcmlwdG9yID0gX2NsYXNzX2V4dHJhY3RfZmllbGRfZGVzY3JpcHRvcihyZWNlaXZlciwgcHJpdmF0ZU1hcCwgInNldCIpOwogICAgX2NsYXNzX2FwcGx5X2Rlc2NyaXB0b3Jfc2V0KHJlY2VpdmVyLCBkZXNjcmlwdG9yLCB2YWx1ZSk7CiAgICByZXR1cm4gdmFsdWU7Cn0KCgo7Ly8gQ09OQ0FURU5BVEVEIE1PRFVMRTogLi9ub2RlX21vZHVsZXMvQGhhemFlNDEvc3ltYm9sLWRpc3Bvc2UtcG9seWZpbGwvZGlzdC9lc20vbW9kcy9zeW1ib2wtZGlzcG9zZS1wb2x5ZmlsbC9wb2x5ZmlsbC5tanMKaWYgKHR5cGVvZiBTeW1ib2wuZGlzcG9zZSAhPT0gInN5bWJvbCIpCiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoU3ltYm9sLCAiZGlzcG9zZSIsIHsKICAgICAgICBjb25maWd1cmFibGU6IGZhbHNlLAogICAgICAgIGVudW1lcmFibGU6IGZhbHNlLAogICAgICAgIHdyaXRhYmxlOiBmYWxzZSwKICAgICAgICB2YWx1ZTogU3ltYm9sLmZvcigiZGlzcG9zZSIpCiAgICB9KTsKaWYgKHR5cGVvZiBTeW1ib2wuYXN5bmNEaXNwb3NlICE9PSAic3ltYm9sIikKICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShTeW1ib2wsICJhc3luY0Rpc3Bvc2UiLCB7CiAgICAgICAgY29uZmlndXJhYmxlOiBmYWxzZSwKICAgICAgICBlbnVtZXJhYmxlOiBmYWxzZSwKICAgICAgICB3cml0YWJsZTogZmFsc2UsCiAgICAgICAgdmFsdWU6IFN5bWJvbC5mb3IoImFzeW5jRGlzcG9zZSIpCiAgICB9KTsKLy8jIHNvdXJjZU1hcHBpbmdVUkw9cG9seWZpbGwubWpzLm1hcAoKOy8vIENPTkNBVEVOQVRFRCBNT0RVTEU6IC4vbm9kZV9tb2R1bGVzL0BoYXphZTQxL3N5bWJvbC1kaXNwb3NlLXBvbHlmaWxsL2Rpc3QvZXNtL2luZGV4Lm1qcwoKLy8jIHNvdXJjZU1hcHBpbmdVUkw9aW5kZXgubWpzLm1hcAoKOy8vIENPTkNBVEVOQVRFRCBNT0RVTEU6IC4vbm9kZV9tb2R1bGVzL0BoYXphZTQxL2Z1dHVyZS9kaXN0L2VzbS9tb2RzL2Z1dHVyZS9mdXR1cmUubWpzCmNsYXNzIEZ1dHVyZSB7CiAgICAjcmVzb2x2ZTsKICAgICNyZWplY3Q7CiAgICBwcm9taXNlOwogICAgLyoqCiAgICAgKiBKdXN0IGxpa2UgYSBQcm9taXNlIGJ1dCB5b3UgY2FuIG1hbnVhbGx5IHJlc29sdmUgb3IgcmVqZWN0IGl0CiAgICAgKi8KICAgIGNvbnN0cnVjdG9yKCkgewogICAgICAgIHRoaXMucHJvbWlzZSA9IG5ldyBQcm9taXNlKChzdWJyZXNvbHZlLCBzdWJyZWplY3QpID0+IHsKICAgICAgICAgICAgdGhpcy4jcmVzb2x2ZSA9IHN1YnJlc29sdmU7CiAgICAgICAgICAgIHRoaXMuI3JlamVjdCA9IHN1YnJlamVjdDsKICAgICAgICB9KTsKICAgIH0KICAgIGdldCByZXNvbHZlKCkgewogICAgICAgIHJldHVybiB0aGlzLiNyZXNvbHZlOwogICAgfQogICAgZ2V0IHJlamVjdCgpIHsKICAgICAgICByZXR1cm4gdGhpcy4jcmVqZWN0OwogICAgfQp9CgoKLy8jIHNvdXJjZU1hcHBpbmdVUkw9ZnV0dXJlLm1qcy5tYXAKCjsvLyBDT05DQVRFTkFURUQgTU9EVUxFOiAuL25vZGVfbW9kdWxlcy9AaGF6YWU0MS9yZXN1bHQvZGlzdC9lc20vbW9kcy9yZXN1bHQvZXJyb3JzLm1qcwoKCmNsYXNzIFVuaW1wbGVtZW50ZWQgZXh0ZW5kcyAoLyogdW51c2VkIHB1cmUgZXhwcmVzc2lvbiBvciBzdXBlciAqLyBudWxsICYmIChFcnJvcikpIHsKICAgICNjbGFzcyA9IFVuaW1wbGVtZW50ZWQ7CiAgICBuYW1lID0gdGhpcy4jY2xhc3MubmFtZTsKICAgIGNvbnN0cnVjdG9yKG9wdGlvbnMpIHsKICAgICAgICBzdXBlcihgU29tZXRoaW5nIGlzIG5vdCBpbXBsZW1lbnRlZGAsIG9wdGlvbnMpOwogICAgfQp9CmNsYXNzIEFzc2VydEVycm9yIGV4dGVuZHMgRXJyb3IgewogICAgI2NsYXNzID0gQXNzZXJ0RXJyb3I7CiAgICBuYW1lID0gdGhpcy4jY2xhc3MubmFtZTsKICAgIGNvbnN0cnVjdG9yKG9wdGlvbnMpIHsKICAgICAgICBzdXBlcihgU29tZSBhc3NlcnRpb24gZmFpbGVkYCwgb3B0aW9ucyk7CiAgICB9Cn0KY2xhc3MgUGFuaWMgZXh0ZW5kcyBFcnJvciB7CiAgICAjY2xhc3MgPSBQYW5pYzsKICAgIG5hbWUgPSB0aGlzLiNjbGFzcy5uYW1lOwogICAgY29uc3RydWN0b3Iob3B0aW9ucykgewogICAgICAgIHN1cGVyKGBTb21ldGhpbmcgd2FzIG5vdCBleHBlY3RlZGAsIG9wdGlvbnMpOwogICAgfQogICAgc3RhdGljIGZyb20oY2F1c2UpIHsKICAgICAgICByZXR1cm4gbmV3IFBhbmljKHsgY2F1c2UgfSk7CiAgICB9CiAgICBzdGF0aWMgZnJvbUFuZFRocm93KGNhdXNlKSB7CiAgICAgICAgdGhyb3cgbmV3IFBhbmljKHsgY2F1c2UgfSk7CiAgICB9Cn0KY2xhc3MgQ2F0Y2hlZCBleHRlbmRzIEVycm9yIHsKICAgICNjbGFzcyA9IENhdGNoZWQ7CiAgICBuYW1lID0gdGhpcy4jY2xhc3MubmFtZTsKICAgIGNvbnN0cnVjdG9yKG9wdGlvbnMpIHsKICAgICAgICBzdXBlcihgU29tZXRoaW5nIGhhcyBiZWVuIGNhdGNoZWRgLCBvcHRpb25zKTsKICAgIH0KICAgIHN0YXRpYyBmcm9tKGNhdXNlKSB7CiAgICAgICAgcmV0dXJuIG5ldyBDYXRjaGVkKHsgY2F1c2UgfSk7CiAgICB9CiAgICBzdGF0aWMgZnJvbUFuZFRocm93KGNhdXNlKSB7CiAgICAgICAgdGhyb3cgbmV3IENhdGNoZWQoeyBjYXVzZSB9KTsKICAgIH0KICAgIC8qKgogICAgICogVGhyb3cgaWYgYENhdGNoZWRgLCB3cmFwIGluIGBFcnJgIG90aGVyd2lzZQogICAgICogQHBhcmFtIGVycm9yCiAgICAgKiBAcmV0dXJucyBgRXJyKGVycm9yKWAgaWYgbm90IGBDYXRjaGVkYAogICAgICogQHRocm93cyBgZXJyb3IuY2F1c2VgIGlmIGBDYXRjaGVkYAogICAgICovCiAgICBzdGF0aWMgdGhyb3dPckVycihlcnJvcikgewogICAgICAgIGlmIChlcnJvciBpbnN0YW5jZW9mIENhdGNoZWQpCiAgICAgICAgICAgIHRocm93IGVycm9yLmNhdXNlOwogICAgICAgIHJldHVybiBuZXcgRXJyKGVycm9yKTsKICAgIH0KfQoKCi8vIyBzb3VyY2VNYXBwaW5nVVJMPWVycm9ycy5tanMubWFwCgo7Ly8gQ09OQ0FURU5BVEVEIE1PRFVMRTogLi9ub2RlX21vZHVsZXMvQGhhemFlNDEvb3B0aW9uL2Rpc3QvZXNtL21vZHMvb3B0aW9uL25vbmUubWpzCgoKY2xhc3MgTm9uZUVycm9yIGV4dGVuZHMgRXJyb3IgewogICAgY29uc3RydWN0b3IoKSB7CiAgICAgICAgc3VwZXIoYE9wdGlvbiBpcyBhIE5vbmVgKTsKICAgIH0KfQpjbGFzcyBOb25lIHsKICAgIGlubmVyOwogICAgLyoqCiAgICAgKiBBbiBlbXB0eSB2YWx1ZQogICAgICovCiAgICBjb25zdHJ1Y3Rvcihpbm5lciA9IHVuZGVmaW5lZCkgewogICAgICAgIHRoaXMuaW5uZXIgPSBpbm5lcjsKICAgIH0KICAgIC8qKgogICAgICogQ3JlYXRlIGEgYE5vbmVgCiAgICAgKiBAcmV0dXJucyBgTm9uZWAKICAgICAqLwogICAgc3RhdGljIG5ldygpIHsKICAgICAgICByZXR1cm4gbmV3IE5vbmUoKTsKICAgIH0KICAgIHN0YXRpYyBmcm9tKGluaXQpIHsKICAgICAgICByZXR1cm4gbmV3IE5vbmUoKTsKICAgIH0KICAgIC8qKgogICAgICogVHlwZSBndWFyZCBmb3IgYFNvbWVgCiAgICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYFNvbWVgLCBgZmFsc2VgIGlmIGBOb25lYAogICAgICovCiAgICBpc1NvbWUoKSB7CiAgICAgICAgcmV0dXJuIGZhbHNlOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGB0cnVlYCBpZiB0aGUgb3B0aW9uIGlzIGEgYFNvbWVgIGFuZCB0aGUgdmFsdWUgaW5zaWRlIG9mIGl0IG1hdGNoZXMgYSBwcmVkaWNhdGUKICAgICAqIEBwYXJhbSBzb21lUHJlZGljYXRlCiAgICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYFNvbWVgIGFuZCBgYXdhaXQgc29tZVByZWRpY2F0ZSh0aGlzLmlubmVyKWAsIGBOb25lYCBvdGhlcndpc2UKICAgICAqLwogICAgYXN5bmMgaXNTb21lQW5kKHNvbWVQcmVkaWNhdGUpIHsKICAgICAgICByZXR1cm4gZmFsc2U7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYHRydWVgIGlmIHRoZSBvcHRpb24gaXMgYSBgU29tZWAgYW5kIHRoZSB2YWx1ZSBpbnNpZGUgb2YgaXQgbWF0Y2hlcyBhIHByZWRpY2F0ZQogICAgICogQHBhcmFtIHNvbWVQcmVkaWNhdGUKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgU29tZWAgYW5kIGBzb21lUHJlZGljYXRlKHRoaXMuaW5uZXIpYCwgYE5vbmVgIG90aGVyd2lzZQogICAgICovCiAgICBpc1NvbWVBbmRTeW5jKHNvbWVQcmVkaWNhdGUpIHsKICAgICAgICByZXR1cm4gZmFsc2U7CiAgICB9CiAgICAvKioKICAgICAqIFR5cGUgZ3VhcmQgZm9yIGBOb25lYAogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBOb25lYCwgYGZhbHNlYCBpZiBgU29tZWAKICAgICAqLwogICAgaXNOb25lKCkgewogICAgICAgIHJldHVybiB0cnVlOwogICAgfQogICAgLyoqCiAgICAgKiBDb21waWxlLXRpbWUgc2FmZWx5IGdldCBgdGhpcy5pbm5lcmAKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYAogICAgICovCiAgICBnZXQoKSB7CiAgICAgICAgcmV0dXJuIHRoaXMuaW5uZXI7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYW4gaXRlcmF0b3Igb3ZlciB0aGUgcG9zc2libHkgY29udGFpbmVkIHZhbHVlCiAgICAgKiBAeWllbGRzIGB0aGlzLmlubmVyYCBpZiBgU29tZWAKICAgICAqLwogICAgKltTeW1ib2wuaXRlcmF0b3JdKCkgewogICAgICAgIHJldHVybjsKICAgIH0KICAgIC8qKgogICAgICogR2V0IHRoZSBpbm5lciB2YWx1ZSBpZiBgU29tZWAsIHRocm93IGBFcnJvcihtZXNzYWdlKWAgb3RoZXJ3aXNlCiAgICAgKiBAcGFyYW0gbWVzc2FnZQogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBTb21lYAogICAgICogQHRocm93cyBgRXJyb3IobWVzc2FnZSlgIGlmIGBOb25lYAogICAgICovCiAgICBleHBlY3QobWVzc2FnZSkgewogICAgICAgIHRocm93IFBhbmljLmZyb20obmV3IEVycm9yKG1lc3NhZ2UsIHsgY2F1c2U6IHRoaXMgfSkpOwogICAgfQogICAgLyoqCiAgICAgKiBHZXQgdGhlIGlubmVyIHZhbHVlIG9yIHRocm93IGEgTm9uZUVycm9yCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAgaWYgYFNvbWVgCiAgICAgKiBAdGhyb3dzIGBOb25lRXJyb3JgIGlmIGBOb25lYAogICAgICovCiAgICB1bndyYXAoKSB7CiAgICAgICAgdGhyb3cgUGFuaWMuZnJvbShuZXcgRXJyb3IoYEEgTm9uZSBoYXMgYmVlbiB1bndyYXBwZWRgLCB7IGNhdXNlOiB0aGlzIH0pKTsKICAgIH0KICAgIC8qKgogICAgICogR2V0IHRoZSBpbm5lciB2YWx1ZSBvciBhIGRlZmF1bHQgb25lCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgU29tZWAsIGB2YWx1ZWAgaWYgYE5vbmVgCiAgICAgKi8KICAgIHVud3JhcE9yKHZhbHVlKSB7CiAgICAgICAgcmV0dXJuIHZhbHVlOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIHRoZSBjb250YWluZWQgYFNvbWVgIHZhbHVlIG9yIGNvbXB1dGVzIGl0IGZyb20gYSBjbG9zdXJlCiAgICAgKiBAcGFyYW0gbm9uZUNhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAgaWYgYFNvbWVgLCBgYXdhaXQgbm9uZUNhbGxiYWNrKClgIGlmIGBOb25lYAogICAgICovCiAgICBhc3luYyB1bndyYXBPckVsc2Uobm9uZUNhbGxiYWNrKSB7CiAgICAgICAgcmV0dXJuIGF3YWl0IG5vbmVDYWxsYmFjaygpOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIHRoZSBjb250YWluZWQgYFNvbWVgIHZhbHVlIG9yIGNvbXB1dGVzIGl0IGZyb20gYSBjbG9zdXJlCiAgICAgKiBAcGFyYW0gbm9uZUNhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAgaWYgYFNvbWVgLCBgbm9uZUNhbGxiYWNrKClgIGlmIGBOb25lYAogICAgICovCiAgICB1bndyYXBPckVsc2VTeW5jKG5vbmVDYWxsYmFjaykgewogICAgICAgIHJldHVybiBub25lQ2FsbGJhY2soKTsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtIGBPcHRpb248VD5gIGludG8gYFJlc3VsdDxULCBOb25lRXJyb3I+YAogICAgICogQHJldHVybnMgYE9rKHRoaXMuaW5uZXIpYCBpZiBgU29tZWAsIGBFcnIoTm9uZUVycm9yKWAgaWYgYE5vbmVgCiAgICAgKi8KICAgIG9rKCkgewogICAgICAgIHJldHVybiBuZXcgRXJyKG5ldyBOb25lRXJyb3IoKSk7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBgT3B0aW9uPFQ+YCBpbnRvIGBSZXN1bHQ8VCwgRT5gCiAgICAgKiBAcGFyYW0gZXJyb3IKICAgICAqIEByZXR1cm5zIGBPayh0aGlzLmlubmVyKWAgaWYgYFNvbWVgLCBgRXJyKGVycm9yKWAgaWYgYE5vbmVgCiAgICAgKi8KICAgIG9rT3IoZXJyb3IpIHsKICAgICAgICByZXR1cm4gbmV3IEVycihlcnJvcik7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybXMgdGhlIGBPcHRpb248VD5gIGludG8gYSBgUmVzdWx0PFQsIEU+YCwgbWFwcGluZyBgU29tZSh2KWAgdG8gYE9rKHYpYCBhbmQgYE5vbmVgIHRvIGBFcnIoZXJyKCkpYAogICAgICogQHBhcmFtIG5vbmVDYWxsYmFjawogICAgICogQHJldHVybnMgYE9rKHRoaXMuaW5uZXIpYCBpZiBgU29tZWAsIGBFcnIoYXdhaXQgbm9uZUNhbGxiYWNrKCkpYCBpcyBgTm9uZWAKICAgICAqLwogICAgYXN5bmMgb2tPckVsc2Uobm9uZUNhbGxiYWNrKSB7CiAgICAgICAgcmV0dXJuIG5ldyBFcnIoYXdhaXQgbm9uZUNhbGxiYWNrKCkpOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm1zIHRoZSBgT3B0aW9uPFQ+YCBpbnRvIGEgYFJlc3VsdDxULCBFPmAsIG1hcHBpbmcgYFNvbWUodilgIHRvIGBPayh2KWAgYW5kIGBOb25lYCB0byBgRXJyKGVycigpKWAKICAgICAqIEBwYXJhbSBub25lQ2FsbGJhY2sKICAgICAqIEByZXR1cm5zIGBPayh0aGlzLmlubmVyKWAgaWYgYFNvbWVgLCBgRXJyKG5vbmVDYWxsYmFjaygpKWAgaXMgYE5vbmVgCiAgICAgKi8KICAgIG9rT3JFbHNlU3luYyhub25lQ2FsbGJhY2spIHsKICAgICAgICByZXR1cm4gbmV3IEVycihub25lQ2FsbGJhY2soKSk7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYE5vbmVgIGlmIHRoZSBvcHRpb24gaXMgYE5vbmVgLCBvdGhlcndpc2UgY2FsbHMgYHNvbWVQcmVkaWNhdGVgIHdpdGggdGhlIHdyYXBwZWQgdmFsdWUKICAgICAqIEBwYXJhbSBzb21lUHJlZGljYXRlCiAgICAgKiBAcmV0dXJucyBgU29tZWAgaWYgYFNvbWVgIGFuZCBgYXdhaXQgc29tZVByZWRpY2F0ZSh0aGlzLmlubmVyKWAsIGBOb25lYCBvdGhlcndpc2UKICAgICAqLwogICAgYXN5bmMgZmlsdGVyKHNvbWVQcmVkaWNhdGUpIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBgTm9uZWAgaWYgdGhlIG9wdGlvbiBpcyBgTm9uZWAsIG90aGVyd2lzZSBjYWxscyBgc29tZVByZWRpY2F0ZWAgd2l0aCB0aGUgd3JhcHBlZCB2YWx1ZQogICAgICogQHBhcmFtIHNvbWVQcmVkaWNhdGUKICAgICAqIEByZXR1cm5zIGBTb21lYCBpZiBgU29tZWAgYW5kIGBzb21lUHJlZGljYXRlKHRoaXMuaW5uZXIpYCwgYE5vbmVgIG90aGVyd2lzZQogICAgICovCiAgICBmaWx0ZXJTeW5jKHNvbWVQcmVkaWNhdGUpIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtIGBPcHRpb248UHJvbWlzZTxUPj5gIGludG8gYFByb21pc2U8T3B0aW9uPFQ+PmAKICAgICAqIEByZXR1cm5zIGBQcm9taXNlPE9wdGlvbjxUPj5gCiAgICAgKi8KICAgIGFzeW5jIGF3YWl0KCkgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGB0cnVlYCBpZiB0aGUgb3B0aW9uIGlzIGEgYFNvbWVgIHZhbHVlIGNvbnRhaW5pbmcgdGhlIGdpdmVuIHZhbHVlCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgU29tZWAgYW5kIGB0aGlzLmlubmVyID09PSB2YWx1ZWAsIGBOb25lYCBvdGhlcndpc2UKICAgICAqLwogICAgY29udGFpbnModmFsdWUpIHsKICAgICAgICByZXR1cm4gZmFsc2U7CiAgICB9CiAgICAvKioKICAgICAqIENhbGxzIHRoZSBnaXZlbiBjYWxsYmFjayB3aXRoIHRoZSBpbm5lciB2YWx1ZSBpZiBgT2tgCiAgICAgKiBAcGFyYW0gc29tZUNhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgdGhpc2AKICAgICAqLwogICAgYXN5bmMgaW5zcGVjdChzb21lQ2FsbGJhY2spIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogQ2FsbHMgdGhlIGdpdmVuIGNhbGxiYWNrIHdpdGggdGhlIGlubmVyIHZhbHVlIGlmIGBPa2AKICAgICAqIEBwYXJhbSBzb21lQ2FsbGJhY2sKICAgICAqIEByZXR1cm5zIGB0aGlzYAogICAgICovCiAgICBpbnNwZWN0U3luYyhzb21lQ2FsbGJhY2spIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogTWFwcyBhbiBgT3B0aW9uPFQ+YCB0byBgT3B0aW9uPFU+YCBieSBhcHBseWluZyBhIGZ1bmN0aW9uIHRvIGEgY29udGFpbmVkIHZhbHVlIChpZiBgU29tZWApIG9yIHJldHVybnMgYE5vbmVgIChpZiBgTm9uZWApCiAgICAgKiBAcGFyYW0gc29tZU1hcHBlcgogICAgICogQHJldHVybnMgYFNvbWUoYXdhaXQgc29tZU1hcHBlcih0aGlzLmlubmVyKSlgIGlmIGBTb21lYCwgYHRoaXNgIGlmIGBOb25lYAogICAgICovCiAgICBhc3luYyBtYXAoc29tZU1hcHBlcikgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBNYXBzIGFuIGBPcHRpb248VD5gIHRvIGBPcHRpb248VT5gIGJ5IGFwcGx5aW5nIGEgZnVuY3Rpb24gdG8gYSBjb250YWluZWQgdmFsdWUgKGlmIGBTb21lYCkgb3IgcmV0dXJucyBgTm9uZWAgKGlmIGBOb25lYCkKICAgICAqIEBwYXJhbSBzb21lTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgU29tZShzb21lTWFwcGVyKHRoaXMuaW5uZXIpKWAgaWYgYFNvbWVgLCBgdGhpc2AgaWYgYE5vbmVgCiAgICAgKi8KICAgIG1hcFN5bmMoc29tZU1hcHBlcikgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIHRoZSBwcm92aWRlZCBkZWZhdWx0IHJlc3VsdCAoaWYgbm9uZSksIG9yIGFwcGxpZXMgYSBmdW5jdGlvbiB0byB0aGUgY29udGFpbmVkIHZhbHVlIChpZiBhbnkpCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEBwYXJhbSBzb21lTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgdmFsdWVgIGlmIGBOb25lYCwgYGF3YWl0IHNvbWVNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBTb21lYAogICAgICovCiAgICBhc3luYyBtYXBPcih2YWx1ZSwgc29tZU1hcHBlcikgewogICAgICAgIHJldHVybiB2YWx1ZTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyB0aGUgcHJvdmlkZWQgZGVmYXVsdCByZXN1bHQgKGlmIG5vbmUpLCBvciBhcHBsaWVzIGEgZnVuY3Rpb24gdG8gdGhlIGNvbnRhaW5lZCB2YWx1ZSAoaWYgYW55KQogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcGFyYW0gc29tZU1hcHBlcgogICAgICogQHJldHVybnMgYHZhbHVlYCBpZiBgTm9uZWAsIGBzb21lTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgU29tZWAKICAgICAqLwogICAgbWFwT3JTeW5jKHZhbHVlLCBzb21lTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIHZhbHVlOwogICAgfQogICAgLyoqCiAgICAgKiBDb21wdXRlcyBhIGRlZmF1bHQgZnVuY3Rpb24gcmVzdWx0IChpZiBub25lKSwgb3IgYXBwbGllcyBhIGRpZmZlcmVudCBmdW5jdGlvbiB0byB0aGUgY29udGFpbmVkIHZhbHVlIChpZiBhbnkpCiAgICAgKiBAcGFyYW0gbm9uZUNhbGxiYWNrCiAgICAgKiBAcGFyYW0gc29tZU1hcHBlcgogICAgICogQHJldHVybnMgYGF3YWl0IHNvbWVNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBTb21lYCwgYGF3YWl0IG5vbmVDYWxsYmFjaygpYCBpZiBgTm9uZWAKICAgICAqLwogICAgYXN5bmMgbWFwT3JFbHNlKG5vbmVDYWxsYmFjaywgc29tZU1hcHBlcikgewogICAgICAgIHJldHVybiBhd2FpdCBub25lQ2FsbGJhY2soKTsKICAgIH0KICAgIC8qKgogICAgICogQ29tcHV0ZXMgYSBkZWZhdWx0IGZ1bmN0aW9uIHJlc3VsdCAoaWYgbm9uZSksIG9yIGFwcGxpZXMgYSBkaWZmZXJlbnQgZnVuY3Rpb24gdG8gdGhlIGNvbnRhaW5lZCB2YWx1ZSAoaWYgYW55KQogICAgICogQHBhcmFtIG5vbmVDYWxsYmFjawogICAgICogQHBhcmFtIHNvbWVNYXBwZXIKICAgICAqIEByZXR1cm5zIGBzb21lTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgU29tZWAsIGBub25lQ2FsbGJhY2soKWAgaWYgYE5vbmVgCiAgICAgKi8KICAgIG1hcE9yRWxzZVN5bmMobm9uZUNhbGxiYWNrLCBzb21lTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIG5vbmVDYWxsYmFjaygpOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGBOb25lYCBpZiB0aGUgb3B0aW9uIGlzIGBOb25lYCwgb3RoZXJ3aXNlIHJldHVybnMgYHZhbHVlYAogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcmV0dXJucyBgTm9uZWAgaWYgYE5vbmVgLCBgdmFsdWVgIGlmIGBTb21lYAogICAgICovCiAgICBhbmQodmFsdWUpIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBgTm9uZWAgaWYgdGhlIG9wdGlvbiBpcyBgTm9uZWAsIG90aGVyd2lzZSBjYWxscyBgc29tZU1hcHBlcmAgd2l0aCB0aGUgd3JhcHBlZCB2YWx1ZSBhbmQgcmV0dXJucyB0aGUgcmVzdWx0CiAgICAgKiBAcGFyYW0gc29tZU1hcHBlcgogICAgICogQHJldHVybnMgYE5vbmVgIGlmIGBOb25lYCwgYGF3YWl0IHNvbWVNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBTb21lYAogICAgICovCiAgICBhc3luYyBhbmRUaGVuKHNvbWVNYXBwZXIpIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBgTm9uZWAgaWYgdGhlIG9wdGlvbiBpcyBgTm9uZWAsIG90aGVyd2lzZSBjYWxscyBgc29tZU1hcHBlcmAgd2l0aCB0aGUgd3JhcHBlZCB2YWx1ZSBhbmQgcmV0dXJucyB0aGUgcmVzdWx0CiAgICAgKiBAcGFyYW0gc29tZU1hcHBlcgogICAgICogQHJldHVybnMgYE5vbmVgIGlmIGBOb25lYCwgYHNvbWVNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBTb21lYAogICAgICovCiAgICBhbmRUaGVuU3luYyhzb21lTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYHRoaXNgIGlmIGBTb21lYCwgb3RoZXJ3aXNlIHJldHVybnMgYHZhbHVlYAogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcmV0dXJucyBgdGhpc2AgaWYgYFNvbWVgLCBgdmFsdWVgIGlmIGBOb25lYAogICAgICovCiAgICBvcih2YWx1ZSkgewogICAgICAgIHJldHVybiB2YWx1ZTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBgdGhpc2AgaWYgYFNvbWVgLCBvdGhlcndpc2UgY2FsbHMgYG5vbmVDYWxsYmFja2AgYW5kIHJldHVybnMgdGhlIHJlc3VsdAogICAgICogQHBhcmFtIG5vbmVDYWxsYmFjawogICAgICogQHJldHVybnMgYHRoaXNgIGlmIGBTb21lYCwgYGF3YWl0IG5vbmVDYWxsYmFjaygpYCBpZiBgTm9uZWAKICAgICAqLwogICAgYXN5bmMgb3JFbHNlKG5vbmVDYWxsYmFjaykgewogICAgICAgIHJldHVybiBhd2FpdCBub25lQ2FsbGJhY2soKTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBgdGhpc2AgaWYgYFNvbWVgLCBvdGhlcndpc2UgY2FsbHMgYG5vbmVDYWxsYmFja2AgYW5kIHJldHVybnMgdGhlIHJlc3VsdAogICAgICogQHBhcmFtIG5vbmVDYWxsYmFjawogICAgICogQHJldHVybnMgYHRoaXNgIGlmIGBTb21lYCwgYG5vbmVDYWxsYmFjaygpYCBpZiBgTm9uZWAKICAgICAqLwogICAgb3JFbHNlU3luYyhub25lQ2FsbGJhY2spIHsKICAgICAgICByZXR1cm4gbm9uZUNhbGxiYWNrKCk7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYFNvbWVgIGlmIGV4YWN0bHkgb25lIG9mIHRoZSBvcHRpb25zIGlzIGBTb21lYCwgb3RoZXJ3aXNlIHJldHVybnMgYE5vbmVgCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEByZXR1cm5zIGBOb25lYCBpZiBib3RoIGFyZSBgU29tZWAgb3IgYm90aCBhcmUgYE5vbmVgLCB0aGUgb25seSBgU29tZWAgb3RoZXJ3aXNlCiAgICAgKi8KICAgIHhvcih2YWx1ZSkgewogICAgICAgIHJldHVybiB2YWx1ZTsKICAgIH0KICAgIC8qKgogICAgICogWmlwcyBgdGhpc2Agd2l0aCBhbm90aGVyIGBPcHRpb25gCiAgICAgKiBAcGFyYW0gb3RoZXIKICAgICAqIEByZXR1cm5zIGBTb21lKFt0aGlzLmlubmVyLCBvdGhlci5pbm5lcl0pYCBpZiBib3RoIGFyZSBgU29tZWAsIGBOb25lYCBpZiBvbmUgb2YgdGhlbSBpcyBgTm9uZWAKICAgICAqLwogICAgemlwKG90aGVyKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9Cn0KCgovLyMgc291cmNlTWFwcGluZ1VSTD1ub25lLm1qcy5tYXAKCjsvLyBDT05DQVRFTkFURUQgTU9EVUxFOiAuL25vZGVfbW9kdWxlcy9AaGF6YWU0MS9vcHRpb24vZGlzdC9lc20vbW9kcy9vcHRpb24vb3B0aW9uLm1qcwoKCgp2YXIgT3B0aW9uOwooZnVuY3Rpb24gKE9wdGlvbikgewogICAgZnVuY3Rpb24gZnJvbShpbml0KSB7CiAgICAgICAgaWYgKCJpbm5lciIgaW4gaW5pdCkKICAgICAgICAgICAgcmV0dXJuIG5ldyBTb21lKGluaXQuaW5uZXIpOwogICAgICAgIHJldHVybiBuZXcgTm9uZSgpOwogICAgfQogICAgT3B0aW9uLmZyb20gPSBmcm9tOwogICAgLyoqCiAgICAgKiBDcmVhdGUgYW4gT3B0aW9uIGZyb20gYSBudWxsYWJsZSB2YWx1ZQogICAgICogQHBhcmFtIGlubmVyCiAgICAgKiBAcmV0dXJucyBgU29tZTxUPmAgaWYgYFRgLCBgTm9uZWAgaWYgYHVuZGVmaW5lZGAKICAgICAqLwogICAgZnVuY3Rpb24gd3JhcChpbm5lcikgewogICAgICAgIGlmIChpbm5lciA9PSBudWxsKQogICAgICAgICAgICByZXR1cm4gbmV3IE5vbmUoKTsKICAgICAgICByZXR1cm4gbmV3IFNvbWUoaW5uZXIpOwogICAgfQogICAgT3B0aW9uLndyYXAgPSB3cmFwOwogICAgYXN5bmMgZnVuY3Rpb24gbWFwKGlubmVyLCBtYXBwZXIpIHsKICAgICAgICByZXR1cm4gT3B0aW9uLndyYXAoaW5uZXIpLm1hcChtYXBwZXIpLnRoZW4obyA9PiBvLmdldCgpKTsKICAgIH0KICAgIE9wdGlvbi5tYXAgPSBtYXA7CiAgICBmdW5jdGlvbiBtYXBTeW5jKGlubmVyLCBtYXBwZXIpIHsKICAgICAgICByZXR1cm4gT3B0aW9uLndyYXAoaW5uZXIpLm1hcFN5bmMobWFwcGVyKS5nZXQoKTsKICAgIH0KICAgIE9wdGlvbi5tYXBTeW5jID0gbWFwU3luYzsKICAgIGZ1bmN0aW9uIHVud3JhcChpbm5lcikgewogICAgICAgIHJldHVybiBPcHRpb24ud3JhcChpbm5lcikudW53cmFwKCk7CiAgICB9CiAgICBPcHRpb24udW53cmFwID0gdW53cmFwOwp9KShPcHRpb24gfHwgKE9wdGlvbiA9IHt9KSk7CgoKLy8jIHNvdXJjZU1hcHBpbmdVUkw9b3B0aW9uLm1qcy5tYXAKCjsvLyBDT05DQVRFTkFURUQgTU9EVUxFOiAuL25vZGVfbW9kdWxlcy9AaGF6YWU0MS9yZXN1bHQvZGlzdC9lc20vbW9kcy9yZXN1bHQvcmVzdWx0Lm1qcwoKCgoKCnZhciBSZXN1bHQ7CihmdW5jdGlvbiAoUmVzdWx0KSB7CiAgICBSZXN1bHQuZGVidWcgPSBmYWxzZTsKICAgIC8qKgogICAgICogQ3JlYXRlIGEgUmVzdWx0IGZyb20gYSBtYXliZSBFcnJvciB2YWx1ZQogICAgICogQHBhcmFtIGlubmVyCiAgICAgKiBAcmV0dXJucyBgT2s8VD5gIGlmIGBUYCwgYEVycjxFcnJvcj5gIGlmIGBFcnJvcmAKICAgICAqLwogICAgZnVuY3Rpb24gZnJvbShpbm5lcikgewogICAgICAgIGlmIChpbm5lciBpbnN0YW5jZW9mIEVycm9yKQogICAgICAgICAgICByZXR1cm4gbmV3IEVycihpbm5lcik7CiAgICAgICAgZWxzZQogICAgICAgICAgICByZXR1cm4gbmV3IE9rKGlubmVyKTsKICAgIH0KICAgIFJlc3VsdC5mcm9tID0gZnJvbTsKICAgIC8qKgogICAgICogQ3JlYXRlIGEgUmVzdWx0IGZyb20gYSBib29sZWFuCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEByZXR1cm5zCiAgICAgKi8KICAgIGZ1bmN0aW9uIGFzc2VydCh2YWx1ZSkgewogICAgICAgIHJldHVybiB2YWx1ZSA/IE9rLnZvaWQoKSA6IG5ldyBFcnIobmV3IEFzc2VydEVycm9yKCkpOwogICAgfQogICAgUmVzdWx0LmFzc2VydCA9IGFzc2VydDsKICAgIGZ1bmN0aW9uIHJld3JhcCh3cmFwcGVyKSB7CiAgICAgICAgdHJ5IHsKICAgICAgICAgICAgcmV0dXJuIG5ldyBPayh3cmFwcGVyLnVud3JhcCgpKTsKICAgICAgICB9CiAgICAgICAgY2F0Y2ggKGVycm9yKSB7CiAgICAgICAgICAgIHJldHVybiBuZXcgRXJyKGVycm9yKTsKICAgICAgICB9CiAgICB9CiAgICBSZXN1bHQucmV3cmFwID0gcmV3cmFwOwogICAgLyoqCiAgICAgKiBDYXRjaCBhbiBFcnIgdGhyb3duIGZyb20gRXJyLnRocm93CiAgICAgKiBAcGFyYW0gY2FsbGJhY2sKICAgICAqIEBwYXJhbSB0eXBlCiAgICAgKiBAcmV0dXJucyBgT2s8VD5gIGlmIG5vIGBFcnJgIHdhcyB0aHJvd24sIGBFcnI8RT5gIG90aGVyd2lzZQogICAgICogQHNlZSBFcnIudGhyb3cKICAgICAqLwogICAgYXN5bmMgZnVuY3Rpb24gdW50aHJvdyhjYWxsYmFjaykgewogICAgICAgIGxldCByZWY7CiAgICAgICAgdHJ5IHsKICAgICAgICAgICAgcmV0dXJuIGF3YWl0IGNhbGxiYWNrKChlKSA9PiByZWYgPSBlKTsKICAgICAgICB9CiAgICAgICAgY2F0Y2ggKGUpIHsKICAgICAgICAgICAgaWYgKHJlZiAhPT0gdW5kZWZpbmVkKQogICAgICAgICAgICAgICAgcmV0dXJuIHJlZjsKICAgICAgICAgICAgdGhyb3cgZTsKICAgICAgICB9CiAgICB9CiAgICBSZXN1bHQudW50aHJvdyA9IHVudGhyb3c7CiAgICAvKioKICAgICAqIENhdGNoIGFuIEVyciB0aHJvd24gZnJvbSBFcnIudGhyb3cKICAgICAqIEBwYXJhbSBjYWxsYmFjawogICAgICogQHBhcmFtIHR5cGUKICAgICAqIEByZXR1cm5zIGBPazxUPmAgaWYgbm8gYEVycmAgd2FzIHRocm93biwgYEVycjxFPmAgb3RoZXJ3aXNlCiAgICAgKiBAc2VlIEVyci50aHJvdwogICAgICovCiAgICBmdW5jdGlvbiB1bnRocm93U3luYyhjYWxsYmFjaykgewogICAgICAgIGxldCByZWY7CiAgICAgICAgdHJ5IHsKICAgICAgICAgICAgcmV0dXJuIGNhbGxiYWNrKChlKSA9PiByZWYgPSBlKTsKICAgICAgICB9CiAgICAgICAgY2F0Y2ggKGUpIHsKICAgICAgICAgICAgaWYgKHJlZiAhPT0gdW5kZWZpbmVkKQogICAgICAgICAgICAgICAgcmV0dXJuIHJlZjsKICAgICAgICAgICAgdGhyb3cgZTsKICAgICAgICB9CiAgICB9CiAgICBSZXN1bHQudW50aHJvd1N5bmMgPSB1bnRocm93U3luYzsKICAgIC8qKgogICAgICogQ29udmVydCB0cnktY2F0Y2ggdG8gUmVzdWx0PFQsIHVua25vd24+CiAgICAgKiBAcGFyYW0gY2FsbGJhY2sKICAgICAqIEByZXR1cm5zCiAgICAgKi8KICAgIGFzeW5jIGZ1bmN0aW9uIHJ1bkFuZFdyYXAoY2FsbGJhY2spIHsKICAgICAgICB0cnkgewogICAgICAgICAgICByZXR1cm4gbmV3IE9rKGF3YWl0IGNhbGxiYWNrKCkpOwogICAgICAgIH0KICAgICAgICBjYXRjaCAoZSkgewogICAgICAgICAgICByZXR1cm4gbmV3IEVycihlKTsKICAgICAgICB9CiAgICB9CiAgICBSZXN1bHQucnVuQW5kV3JhcCA9IHJ1bkFuZFdyYXA7CiAgICAvKioKICAgICAqIENvbnZlcnQgdHJ5LWNhdGNoIHRvIFJlc3VsdDxULCB1bmtub3duPgogICAgICogQHBhcmFtIGNhbGxiYWNrCiAgICAgKiBAcmV0dXJucwogICAgICovCiAgICBmdW5jdGlvbiBydW5BbmRXcmFwU3luYyhjYWxsYmFjaykgewogICAgICAgIHRyeSB7CiAgICAgICAgICAgIHJldHVybiBuZXcgT2soY2FsbGJhY2soKSk7CiAgICAgICAgfQogICAgICAgIGNhdGNoIChlKSB7CiAgICAgICAgICAgIHJldHVybiBuZXcgRXJyKGUpOwogICAgICAgIH0KICAgIH0KICAgIFJlc3VsdC5ydW5BbmRXcmFwU3luYyA9IHJ1bkFuZFdyYXBTeW5jOwogICAgLyoqCiAgICAgKiBDb252ZXJ0IHRyeS1jYXRjaCB0byBSZXN1bHQ8VCwgQ2F0Y2hlZD4KICAgICAqIEBwYXJhbSBjYWxsYmFjawogICAgICogQHJldHVybnMKICAgICAqLwogICAgYXN5bmMgZnVuY3Rpb24gcnVuQW5kRG91YmxlV3JhcChjYWxsYmFjaykgewogICAgICAgIHJldHVybiBydW5BbmRXcmFwKGNhbGxiYWNrKS50aGVuKHIgPT4gci5tYXBFcnJTeW5jKENhdGNoZWQuZnJvbSkpOwogICAgfQogICAgUmVzdWx0LnJ1bkFuZERvdWJsZVdyYXAgPSBydW5BbmREb3VibGVXcmFwOwogICAgLyoqCiAgICAgKiBDb252ZXJ0IHRyeS1jYXRjaCB0byBSZXN1bHQ8VCwgQ2F0Y2hlZD4KICAgICAqIEBwYXJhbSBjYWxsYmFjawogICAgICogQHJldHVybnMKICAgICAqLwogICAgZnVuY3Rpb24gcnVuQW5kRG91YmxlV3JhcFN5bmMoY2FsbGJhY2spIHsKICAgICAgICByZXR1cm4gcnVuQW5kV3JhcFN5bmMoY2FsbGJhY2spLm1hcEVyclN5bmMoQ2F0Y2hlZC5mcm9tKTsKICAgIH0KICAgIFJlc3VsdC5ydW5BbmREb3VibGVXcmFwU3luYyA9IHJ1bkFuZERvdWJsZVdyYXBTeW5jOwogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm0gUmVzdWx0PFJlc3VsdDxULCBFMT4sIEUyPiBpbnRvIFJlc3VsdDxULCBFMSB8IEUyPgogICAgICogQHBhcmFtIHJlc3VsdAogICAgICogQHJldHVybnMgYHRoaXNgIGlmIGBFcnJgLCBgdGhpcy5pbm5lcmAgaWYgYE9rYAogICAgICovCiAgICBmdW5jdGlvbiBmbGF0dGVuKHJlc3VsdCkgewogICAgICAgIGlmIChyZXN1bHQuaXNFcnIoKSkKICAgICAgICAgICAgcmV0dXJuIHJlc3VsdDsKICAgICAgICByZXR1cm4gcmVzdWx0LmdldCgpOwogICAgfQogICAgUmVzdWx0LmZsYXR0ZW4gPSBmbGF0dGVuOwogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm0gYEl0ZXJhYmxlPFJlc3VsdDxULEU+YCBpbnRvIGBSZXN1bHQ8QXJyYXk8VD4sIEU+YAogICAgICogQHBhcmFtIGl0ZXJhYmxlCiAgICAgKiBAcmV0dXJucyBgUmVzdWx0PEFycmF5PFQ+LCBFPmAKICAgICAqLwogICAgZnVuY3Rpb24gYWxsKGl0ZXJhYmxlKSB7CiAgICAgICAgcmV0dXJuIGNvbGxlY3QoaXRlcmF0ZShpdGVyYWJsZSkpOwogICAgfQogICAgUmVzdWx0LmFsbCA9IGFsbDsKICAgIGZ1bmN0aW9uIG1heWJlQWxsKGl0ZXJhYmxlKSB7CiAgICAgICAgcmV0dXJuIG1heWJlQ29sbGVjdChtYXliZUl0ZXJhdGUoaXRlcmFibGUpKTsKICAgIH0KICAgIFJlc3VsdC5tYXliZUFsbCA9IG1heWJlQWxsOwogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm0gYEl0ZXJhYmxlPFJlc3VsdDxULEU+YCBpbnRvIGBJdGVyYXRvcjxULCBSZXN1bHQ8dm9pZCwgRT4+YAogICAgICogQHBhcmFtIGl0ZXJhYmxlCiAgICAgKiBAcmV0dXJucyBgSXRlcmF0b3I8VCwgUmVzdWx0PHZvaWQsIEU+PmAKICAgICAqLwogICAgZnVuY3Rpb24qIGl0ZXJhdGUoaXRlcmFibGUpIHsKICAgICAgICBmb3IgKGNvbnN0IHJlc3VsdCBvZiBpdGVyYWJsZSkgewogICAgICAgICAgICBpZiAocmVzdWx0LmlzT2soKSkKICAgICAgICAgICAgICAgIHlpZWxkIHJlc3VsdC5nZXQoKTsKICAgICAgICAgICAgZWxzZQogICAgICAgICAgICAgICAgcmV0dXJuIHJlc3VsdDsKICAgICAgICB9CiAgICAgICAgcmV0dXJuIE9rLnZvaWQoKTsKICAgIH0KICAgIFJlc3VsdC5pdGVyYXRlID0gaXRlcmF0ZTsKICAgIGZ1bmN0aW9uKiBtYXliZUl0ZXJhdGUoaXRlcmFibGUpIHsKICAgICAgICBmb3IgKGNvbnN0IHJlc3VsdCBvZiBpdGVyYWJsZSkgewogICAgICAgICAgICBpZiAocmVzdWx0ID09IG51bGwpCiAgICAgICAgICAgICAgICByZXR1cm4gcmVzdWx0OwogICAgICAgICAgICBlbHNlIGlmIChyZXN1bHQuaXNPaygpKQogICAgICAgICAgICAgICAgeWllbGQgcmVzdWx0LmdldCgpOwogICAgICAgICAgICBlbHNlCiAgICAgICAgICAgICAgICByZXR1cm4gcmVzdWx0OwogICAgICAgIH0KICAgICAgICByZXR1cm4gT2sudm9pZCgpOwogICAgfQogICAgUmVzdWx0Lm1heWJlSXRlcmF0ZSA9IG1heWJlSXRlcmF0ZTsKICAgIC8qKgogICAgICogVHJhbnNmb3JtIGBJdGVyYXRvcjxULCBSZXN1bHQ8dm9pZCwgRT4+YCBpbnRvIGBSZXN1bHQ8QXJyYXk8VD4sIEU+YAogICAgICogQHBhcmFtIGl0ZXJhdG9yIGBSZXN1bHQ8QXJyYXk8VD4sIEU+YAogICAgICovCiAgICBmdW5jdGlvbiBjb2xsZWN0KGl0ZXJhdG9yKSB7CiAgICAgICAgY29uc3QgYXJyYXkgPSBuZXcgQXJyYXkoKTsKICAgICAgICBsZXQgcmVzdWx0ID0gaXRlcmF0b3IubmV4dCgpOwogICAgICAgIGZvciAoOyAhcmVzdWx0LmRvbmU7IHJlc3VsdCA9IGl0ZXJhdG9yLm5leHQoKSkKICAgICAgICAgICAgYXJyYXkucHVzaChyZXN1bHQudmFsdWUpOwogICAgICAgIHJldHVybiByZXN1bHQudmFsdWUuc2V0KGFycmF5KTsKICAgIH0KICAgIFJlc3VsdC5jb2xsZWN0ID0gY29sbGVjdDsKICAgIGZ1bmN0aW9uIG1heWJlQ29sbGVjdChpdGVyYXRvcikgewogICAgICAgIGNvbnN0IGFycmF5ID0gbmV3IEFycmF5KCk7CiAgICAgICAgbGV0IHJlc3VsdCA9IGl0ZXJhdG9yLm5leHQoKTsKICAgICAgICBmb3IgKDsgIXJlc3VsdC5kb25lOyByZXN1bHQgPSBpdGVyYXRvci5uZXh0KCkpCiAgICAgICAgICAgIGFycmF5LnB1c2gocmVzdWx0LnZhbHVlKTsKICAgICAgICByZXR1cm4gT3B0aW9uLm1hcFN5bmMocmVzdWx0LnZhbHVlLCByZXN1bHQgPT4gcmVzdWx0LnNldChhcnJheSkpOwogICAgfQogICAgUmVzdWx0Lm1heWJlQ29sbGVjdCA9IG1heWJlQ29sbGVjdDsKICAgIC8qKgogICAgICogVW53cmFwIHRoZSBjYWxsYmFjayBidXQgd3JhcCB0aHJvd24gZXJyb3JzIGluIENhdGNoZWQKICAgICAqIEBwYXJhbSBjYWxsYmFjawogICAgICogQHJldHVybnMgYFRgIGlmIGBPa2AKICAgICAqIEB0aHJvd3MgYENhdGNoZWRgIGlmIGBjYWxsYmFjaygpYCB0aHJvd3MsIGBFYCBpZiBgRXJyYAogICAgICovCiAgICBhc3luYyBmdW5jdGlvbiBydW5BbmRVbndyYXAoY2FsbGJhY2spIHsKICAgICAgICBsZXQgcmVzdWx0OwogICAgICAgIHRyeSB7CiAgICAgICAgICAgIHJlc3VsdCA9IGF3YWl0IGNhbGxiYWNrKCk7CiAgICAgICAgfQogICAgICAgIGNhdGNoIChlKSB7CiAgICAgICAgICAgIHRocm93IENhdGNoZWQuZnJvbShlKTsKICAgICAgICB9CiAgICAgICAgcmV0dXJuIHJlc3VsdC51bndyYXAoKTsKICAgIH0KICAgIFJlc3VsdC5ydW5BbmRVbndyYXAgPSBydW5BbmRVbndyYXA7CiAgICAvKioKICAgICAqIFVud3JhcCB0aGUgY2FsbGJhY2sgYnV0IHdyYXAgdGhyb3duIGVycm9ycyBpbiBDYXRjaGVkCiAgICAgKiBAcGFyYW0gY2FsbGJhY2sKICAgICAqIEByZXR1cm5zIGBUYCBpZiBgT2tgCiAgICAgKiBAdGhyb3dzIGBDYXRjaGVkYCBpZiBgY2FsbGJhY2soKWAgdGhyb3dzLCBgRWAgaWYgYEVycmAKICAgICAqLwogICAgZnVuY3Rpb24gcnVuQW5kVW53cmFwU3luYyhjYWxsYmFjaykgewogICAgICAgIGxldCByZXN1bHQ7CiAgICAgICAgdHJ5IHsKICAgICAgICAgICAgcmVzdWx0ID0gY2FsbGJhY2soKTsKICAgICAgICB9CiAgICAgICAgY2F0Y2ggKGUpIHsKICAgICAgICAgICAgdGhyb3cgQ2F0Y2hlZC5mcm9tKGUpOwogICAgICAgIH0KICAgICAgICByZXR1cm4gcmVzdWx0LnVud3JhcCgpOwogICAgfQogICAgUmVzdWx0LnJ1bkFuZFVud3JhcFN5bmMgPSBydW5BbmRVbndyYXBTeW5jOwp9KShSZXN1bHQgfHwgKFJlc3VsdCA9IHt9KSk7CgoKLy8jIHNvdXJjZU1hcHBpbmdVUkw9cmVzdWx0Lm1qcy5tYXAKCjsvLyBDT05DQVRFTkFURUQgTU9EVUxFOiAuL25vZGVfbW9kdWxlcy9AaGF6YWU0MS9yZXN1bHQvZGlzdC9lc20vbW9kcy9yZXN1bHQvb2subWpzCgoKCgpjbGFzcyBPayB7CiAgICAjaW5uZXI7CiAgICAjdGltZW91dDsKICAgIC8qKgogICAgICogQSBzdWNjZXNzCiAgICAgKiBAcGFyYW0gaW5uZXIKICAgICAqLwogICAgY29uc3RydWN0b3IoaW5uZXIpIHsKICAgICAgICB0aGlzLiNpbm5lciA9IGlubmVyOwogICAgICAgIGlmICghUmVzdWx0LmRlYnVnKQogICAgICAgICAgICByZXR1cm47CiAgICAgICAgY29uc3QgZXJyb3IgPSBQYW5pYy5mcm9tKG5ldyBFcnJvcihgQW4gT2sgaGFzIG5vdCBiZWVuIGhhbmRsZWQgcHJvcGVybHlgLCB7IGNhdXNlOiB0aGlzIH0pKTsKICAgICAgICB0aGlzLiN0aW1lb3V0ID0gc2V0VGltZW91dCgoKSA9PiB7IHRocm93IGVycm9yOyB9LCAxMDAwKTsKICAgIH0KICAgIC8qKgogICAgICogQ3JlYXRlIGFuIGVtcHR5IGBPa2AKICAgICAqIEByZXR1cm5zIGBPayh2b2lkKWAKICAgICAqLwogICAgc3RhdGljIHZvaWQoKSB7CiAgICAgICAgcmV0dXJuIG5ldyBPayh1bmRlZmluZWQpOwogICAgfQogICAgLyoqCiAgICAgKiBDcmVhdGUgYW4gYE9rYAogICAgICogQHBhcmFtIGlubmVyCiAgICAgKiBAcmV0dXJucyBgT2soaW5uZXIpYAogICAgICovCiAgICBzdGF0aWMgbmV3KGlubmVyKSB7CiAgICAgICAgcmV0dXJuIG5ldyBPayhpbm5lcik7CiAgICB9CiAgICBnZXQgaW5uZXIoKSB7CiAgICAgICAgcmV0dXJuIHRoaXMuI2lubmVyOwogICAgfQogICAgLyoqCiAgICAgKiBTZXQgdGhpcyByZXN1bHQgYXMgaGFuZGxlZAogICAgICovCiAgICBpZ25vcmUoKSB7CiAgICAgICAgaWYgKCF0aGlzLiN0aW1lb3V0KQogICAgICAgICAgICByZXR1cm4gdGhpczsKICAgICAgICBjbGVhclRpbWVvdXQodGhpcy4jdGltZW91dCk7CiAgICAgICAgdGhpcy4jdGltZW91dCA9IHVuZGVmaW5lZDsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogVHlwZSBndWFyZCBmb3IgYE9rYAogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBPa2AsIGBmYWxzZWAgaWYgYEVycmAKICAgICAqLwogICAgaXNPaygpIHsKICAgICAgICByZXR1cm4gdHJ1ZTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyB0cnVlIGlmIHRoZSByZXN1bHQgaXMgYE9rYCBhbmQgdGhlIHZhbHVlIGluc2lkZSBvZiBpdCBtYXRjaGVzIGEgcHJlZGljYXRlCiAgICAgKiBAcGFyYW0gb2tQcmVkaWNhdGUKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgT2tgIGFuZCBgYXdhaXQgb2tQcmVkaWNhdGUodGhpcy5pbm5lcilgLCBgZmFsc2VgIG90aGVyd2lzZQogICAgICovCiAgICBhc3luYyBpc09rQW5kKG9rUHJlZGljYXRlKSB7CiAgICAgICAgcmV0dXJuIGF3YWl0IG9rUHJlZGljYXRlKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIHRydWUgaWYgdGhlIHJlc3VsdCBpcyBgT2tgIGFuZCB0aGUgdmFsdWUgaW5zaWRlIG9mIGl0IG1hdGNoZXMgYSBwcmVkaWNhdGUKICAgICAqIEBwYXJhbSBva1ByZWRpY2F0ZQogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBPa2AgYW5kIGBhd2FpdCBva1ByZWRpY2F0ZSh0aGlzLmlubmVyKWAsIGBmYWxzZWAgb3RoZXJ3aXNlCiAgICAgKi8KICAgIGlzT2tBbmRTeW5jKG9rUHJlZGljYXRlKSB7CiAgICAgICAgcmV0dXJuIG9rUHJlZGljYXRlKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBUeXBlIGd1YXJkIGZvciBgRXJyYAogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBFcnJgLCBgZmFsc2VgIGlmIGBPa2AKICAgICAqLwogICAgaXNFcnIoKSB7CiAgICAgICAgcmV0dXJuIGZhbHNlOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIHRydWUgaWYgdGhlIHJlc3VsdCBpcyBgRXJyYCBhbmQgdGhlIHZhbHVlIGluc2lkZSBvZiBpdCBtYXRjaGVzIGEgcHJlZGljYXRlCiAgICAgKiBAcGFyYW0gZXJyUHJlZGljYXRlCiAgICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYEVycmAgYW5kIGBhd2FpdCBlcnJQcmVkaWNhdGUodGhpcy5pbm5lcilgLCBgZmFsc2VgIG90aGVyd2lzZQogICAgICovCiAgICBhc3luYyBpc0VyckFuZChlcnJQcmVkaWNhdGUpIHsKICAgICAgICByZXR1cm4gZmFsc2U7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgdHJ1ZSBpZiB0aGUgcmVzdWx0IGlzIGBFcnJgIGFuZCB0aGUgdmFsdWUgaW5zaWRlIG9mIGl0IG1hdGNoZXMgYSBwcmVkaWNhdGUKICAgICAqIEBwYXJhbSBlcnJQcmVkaWNhdGUKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgRXJyYCBhbmQgYGF3YWl0IGVyclByZWRpY2F0ZSh0aGlzLmlubmVyKWAsIGBmYWxzZWAgb3RoZXJ3aXNlCiAgICAgKi8KICAgIGlzRXJyQW5kU3luYyhlcnJQcmVkaWNhdGUpIHsKICAgICAgICByZXR1cm4gZmFsc2U7CiAgICB9CiAgICAvKioKICAgICAqIENvbXBpbGUtdGltZSBzYWZlbHkgZ2V0IGB0aGlzLmlubmVyYAogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgCiAgICAgKi8KICAgIGdldCgpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiB0aGlzLmlubmVyOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm0gYFJlc3VsdDxULCBFPmAgaW50byBgT3B0aW9uPFQ+YAogICAgICogQHJldHVybnMgYFNvbWUodGhpcy5pbm5lcilgIGlmIGBPa2AsIGBOb25lYCBpZiBgRXJyYAogICAgICovCiAgICBvaygpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiBuZXcgU29tZSh0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtIGBSZXN1bHQ8VCwgRT5gIGludG8gYE9wdGlvbjxFPmAKICAgICAqIEByZXR1cm5zIGBTb21lKHRoaXMuaW5uZXIpYCBpZiBgRXJyYCwgYE5vbmVgIGlmIGBPa2AKICAgICAqLwogICAgZXJyKCkgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIG5ldyBOb25lKCk7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYW4gaXRlcmF0b3Igb3ZlciB0aGUgcG9zc2libHkgY29udGFpbmVkIHZhbHVlCiAgICAgKiBAeWllbGRzIGB0aGlzLmlubmVyYCBpZiBgT2tgCiAgICAgKi8KICAgICpbU3ltYm9sLml0ZXJhdG9yXSgpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHlpZWxkIHRoaXMuaW5uZXI7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBgUmVzdWx0PFQsRT5gIGludG8gYFtULEVdYAogICAgICogQHJldHVybnMgYFt0aGlzLmlubmVyLCB1bmRlZmluZWRdYCBpZiBgT2tgLCBgW3VuZGVmaW5lZCwgdGhpcy5pbm5lcl1gIGlmIGBFcnJgCiAgICAgKi8KICAgIHNwbGl0KCkgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIFt0aGlzLmlubmVyLCB1bmRlZmluZWRdOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIHRydWUgaWYgdGhlIHJlc3VsdCBpcyBhbiBgT2tgIHZhbHVlIGNvbnRhaW5pbmcgdGhlIGdpdmVuIHZhbHVlCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgT2tgIGFuZCBgdGhpcy5pbm5lciA9PT0gdmFsdWVgLCBgZmFsc2VgIG90aGVyd2lzZQogICAgICovCiAgICBjb250YWlucyh2YWx1ZSkgewogICAgICAgIHJldHVybiB0aGlzLmlubmVyID09PSB2YWx1ZTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyB0cnVlIGlmIHRoZSByZXN1bHQgaXMgYW4gYEVycmAgdmFsdWUgY29udGFpbmluZyB0aGUgZ2l2ZW4gdmFsdWUKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBFcnJgIGFuZCBgdGhpcy5pbm5lciA9PT0gdmFsdWVgLCBgZmFsc2VgIG90aGVyd2lzZQogICAgICovCiAgICBjb250YWluc0Vycih2YWx1ZSkgewogICAgICAgIHJldHVybiBmYWxzZTsKICAgIH0KICAgIC8qKgogICAgICogSnVzdCBsaWtlIGB1bndyYXBgIGJ1dCBpdCB0aHJvd3MgdG8gdGhlIGNsb3Nlc3QgYFJlc3VsdC51bnRocm93YAogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBPa2AKICAgICAqIEB0aHJvd3MgYHRoaXNgIGlmIGBFcnJgCiAgICAgKiBAc2VlIFJlc3VsdC51bnRocm93CiAgICAgKiBAc2VlIFJlc3VsdC51bnRocm93U3luYwogICAgICovCiAgICB0aHJvdyh0aHJvd2VyKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gdGhpcy5pbm5lcjsKICAgIH0KICAgIC8qKgogICAgICogR2V0IHRoZSBpbm5lciB2YWx1ZSBvciB0aHJvdyB0aGUgaW5uZXIgZXJyb3Igd3JhcHBlZCBpbnNpZGUgYW5vdGhlciBFcnJvcgogICAgICogQHBhcmFtIG1lc3NhZ2UKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgT2tgLCBgRXJyb3IobWVzc2FnZSwgeyBjYXVzZTogdGhpcy5pbm5lciB9KWAgaWYgYEVycmAKICAgICAqLwogICAgZXhwZWN0KG1lc3NhZ2UpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiB0aGlzLmlubmVyOwogICAgfQogICAgLyoqCiAgICAgKiBHZXQgdGhlIGlubmVyIGVycm9yIG9yIHRocm93IHRoZSBpbm5lciB2YWx1ZSB3cmFwcGVkIGluc2lkZSBhbm90aGVyIEVycm9yCiAgICAgKiBAcGFyYW0gbWVzc2FnZQogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBFcnJgLCBgRXJyb3IobWVzc2FnZSwgeyBjYXVzZTogdGhpcy5pbm5lciB9KWAgaWYgYE9rYAogICAgICovCiAgICBleHBlY3RFcnIobWVzc2FnZSkgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgdGhyb3cgUGFuaWMuZnJvbShuZXcgRXJyb3IobWVzc2FnZSwgeyBjYXVzZTogdGhpcyB9KSk7CiAgICB9CiAgICAvKioKICAgICAqIEdldCB0aGUgaW5uZXIgdmFsdWUgb3IgcGFuaWMKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgT2tgCiAgICAgKiBAdGhyb3dzIGB0aGlzLmlubmVyYCBpZiBgRXJyYAogICAgICovCiAgICB1bndyYXAoKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gdGhpcy5pbm5lcjsKICAgIH0KICAgIC8qKgogICAgICogR2V0IHRoZSBpbm5lciBlcnJvciBvciBwYW5pYwogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBFcnJgCiAgICAgKiBAdGhyb3dzIGB0aGlzLmlubmVyYCBpZiBgT2tgCiAgICAgKi8KICAgIHVud3JhcEVycigpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHRocm93IFBhbmljLmZyb20obmV3IEVycm9yKGBBbiBPayBoYXMgYmVlbiB1bndyYXBwZWRgLCB7IGNhdXNlOiB0aGlzIH0pKTsKICAgIH0KICAgIC8qKgogICAgICogR2V0IHRoZSBpbm5lciB2YWx1ZSBvciBhIGRlZmF1bHQgb25lCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgT2tgLCBgdmFsdWVgIGlmIGBFcnJgCiAgICAgKi8KICAgIHVud3JhcE9yKHZhbHVlKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gdGhpcy5pbm5lcjsKICAgIH0KICAgIC8qKgogICAgICogR2V0IHRoZSBpbm5lciB2YWx1ZSBvciBjb21wdXRlIGEgZGVmYXVsdCBvbmUgZnJvbSB0aGUgaW5uZXIgZXJyb3IKICAgICAqIEBwYXJhbSBlcnJNYXBwZXIKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgT2tgLCBgYXdhaXQgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgRXJyYAogICAgICogQHRocm93cyBpZiBgYXdhaXQgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgYXN5bmMgdW53cmFwT3JFbHNlKGVyck1hcHBlcikgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIHRoaXMuaW5uZXI7CiAgICB9CiAgICAvKioKICAgICAqIEdldCB0aGUgaW5uZXIgdmFsdWUgb3IgY29tcHV0ZSBhIGRlZmF1bHQgb25lIGZyb20gdGhlIGlubmVyIGVycm9yCiAgICAgKiBAcGFyYW0gZXJyTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAgaWYgYE9rYCwgYGVyck1hcHBlcih0aGlzLmlubmVyKWAgaWYgYEVycmAKICAgICAqIEB0aHJvd3MgaWYgYGVyck1hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIHVud3JhcE9yRWxzZVN5bmMoZXJyTWFwcGVyKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gdGhpcy5pbm5lcjsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtIFJlc3VsdDxQcm9taXNlPFQ+LCBFPiBpbnRvIFByb21pc2U8UmVzdWx0PFQsIEU+PgogICAgICogQHJldHVybnMgYGF3YWl0IHRoaXMuaW5uZXJgIGlmIGBPa2AsIGB0aGlzYCBpZiBgRXJyYAogICAgICovCiAgICBhc3luYyBhd2FpdCgpIHsKICAgICAgICByZXR1cm4gbmV3IE9rKGF3YWl0IHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm0gUmVzdWx0PFQsIFByb21pc2U8RT4+IGludG8gUHJvbWlzZTxSZXN1bHQ8VCwgRT4+CiAgICAgKiBAcmV0dXJucyBgYXdhaXQgdGhpcy5pbm5lcmAgaWYgYEVycmAsIGB0aGlzYCBpZiBgT2tgCiAgICAgKi8KICAgIGFzeW5jIGF3YWl0RXJyKCkgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm0gUmVzdWx0PFByb21pc2U8VD4sIFByb21pc2U8RT4+IGludG8gUHJvbWlzZTxSZXN1bHQ8VCwgRT4+CiAgICAgKiBAcmV0dXJucyBgYXdhaXQgdGhpcy5pbm5lcmAKICAgICAqLwogICAgYXN5bmMgYXdhaXRBbGwoKSB7CiAgICAgICAgcmV0dXJuIGF3YWl0IHRoaXMuYXdhaXQoKTsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtIGBSZXN1bHQ8VCwgRT5gIGludG8gYFJlc3VsdDx2b2lkLCBFPmAKICAgICAqIEByZXR1cm5zIGBPazx2b2lkPmAgaWYgYE9rPFQ+YCwgYEVycjxFPmAgaWYgYEU8RT5gCiAgICAgKi8KICAgIGNsZWFyKCkgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIE9rLnZvaWQoKTsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtIGBSZXN1bHQ8VCwgRT5gIGludG8gYFJlc3VsdDxULCB2b2lkPmAKICAgICAqIEByZXR1cm5zIGBPazxUPmAgaWYgYE9rPFQ+YCwgYEVycjx2b2lkPmAgaWYgYEU8RT5gCiAgICAgKi8KICAgIGNsZWFyRXJyKCkgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBDYWxscyB0aGUgZ2l2ZW4gY2FsbGJhY2sgd2l0aCB0aGUgaW5uZXIgdmFsdWUgaWYgYE9rYAogICAgICogQHBhcmFtIG9rQ2FsbGJhY2sKICAgICAqIEByZXR1cm5zIGB0aGlzYAogICAgICovCiAgICBhc3luYyBpbnNwZWN0KG9rQ2FsbGJhY2spIHsKICAgICAgICBhd2FpdCBva0NhbGxiYWNrKHRoaXMuaW5uZXIpOwogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBDYWxscyB0aGUgZ2l2ZW4gY2FsbGJhY2sgd2l0aCB0aGUgaW5uZXIgdmFsdWUgaWYgYE9rYAogICAgICogQHBhcmFtIG9rQ2FsbGJhY2sKICAgICAqIEByZXR1cm5zIGB0aGlzYAogICAgICovCiAgICBpbnNwZWN0U3luYyhva0NhbGxiYWNrKSB7CiAgICAgICAgb2tDYWxsYmFjayh0aGlzLmlubmVyKTsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogQ2FsbHMgdGhlIGdpdmVuIGNhbGxiYWNrIHdpdGggdGhlIGlubmVyIHZhbHVlIGlmIGBFcnJgCiAgICAgKiBAcGFyYW0gZXJyQ2FsbGJhY2sKICAgICAqIEByZXR1cm5zIGB0aGlzYAogICAgICovCiAgICBhc3luYyBpbnNwZWN0RXJyKGVyckNhbGxiYWNrKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIENhbGxzIHRoZSBnaXZlbiBjYWxsYmFjayB3aXRoIHRoZSBpbm5lciB2YWx1ZSBpZiBgRXJyYAogICAgICogQHBhcmFtIGVyckNhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgdGhpc2AKICAgICAqLwogICAgaW5zcGVjdEVyclN5bmMoZXJyQ2FsbGJhY2spIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJuIGEgbmV3IGBPa2AgYnV0IHdpdGggdGhlIGdpdmVuIGBpbm5lcmAKICAgICAqIEBwYXJhbSBpbm5lcgogICAgICogQHJldHVybnMgYE9rKGlubmVyKWAgaWYgYE9rYCwgYHRoaXNgIGlmIGBFcnJgCiAgICAgKi8KICAgIHNldChpbm5lcikgewogICAgICAgIHJldHVybiBuZXcgT2soaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm4gYSBuZXcgYEVycmAgYnV0IHdpdGggdGhlIGdpdmVuIGBpbm5lcmAKICAgICAqIEBwYXJhbSBpbm5lcgogICAgICogQHJldHVybnMgYEVycihpbm5lcilgIGlmIGBFcnJgLCBgdGhpc2AgaWYgYE9rYAogICAgICovCiAgICBzZXRFcnIoaW5uZXIpIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogTWFwIHRoZSBpbm5lciB2YWx1ZSBpbnRvIGFub3RoZXIKICAgICAqIEBwYXJhbSBva01hcHBlcgogICAgICogQHJldHVybnMgYE9rKGF3YWl0IG9rTWFwcGVyKHRoaXMuaW5uZXIpKWAgaWYgYE9rYCwgYHRoaXNgIGlmIGBFcnJgCiAgICAgKiBAdGhyb3dzIGlmIGBhd2FpdCBva01hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIGFzeW5jIG1hcChva01hcHBlcikgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIG5ldyBPayhhd2FpdCBva01hcHBlcih0aGlzLmlubmVyKSk7CiAgICB9CiAgICAvKioKICAgICAqIE1hcCB0aGUgaW5uZXIgdmFsdWUgaW50byBhbm90aGVyCiAgICAgKiBAcGFyYW0gb2tNYXBwZXIKICAgICAqIEByZXR1cm5zIGBPayhva01hcHBlcih0aGlzLmlubmVyKSlgIGlmIGBPa2AsIGB0aGlzYCBpZiBgRXJyYAogICAgICogQHRocm93cyBpZiBgb2tNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICBtYXBTeW5jKG9rTWFwcGVyKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gbmV3IE9rKG9rTWFwcGVyKHRoaXMuaW5uZXIpKTsKICAgIH0KICAgIC8qKgogICAgICogTWFwIHRoZSBpbm5lciBlcnJvciBpbnRvIGFub3RoZXIKICAgICAqIEBwYXJhbSBlcnJNYXBwZXIKICAgICAqIEByZXR1cm5zIGBFcnIoYXdhaXQgZXJyTWFwcGVyKHRoaXMuaW5uZXIpKWAgaWYgYEVycmAsIGB0aGlzYCBpZiBgT2tgCiAgICAgKiBAdGhyb3dzIGlmIGBhd2FpdCBlcnJNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICBhc3luYyBtYXBFcnIoZXJyTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIE1hcCB0aGUgaW5uZXIgZXJyb3IgaW50byBhbm90aGVyCiAgICAgKiBAcGFyYW0gZXJyTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgRXJyKGVyck1hcHBlcih0aGlzLmlubmVyKSlgIGlmIGBFcnJgLCBgdGhpc2AgaWYgYE9rYAogICAgICogQHRocm93cyBpZiBgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgbWFwRXJyU3luYyhlcnJNYXBwZXIpIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogTWFwIHRoZSBpbm5lciB2YWx1ZSBpbnRvIGFub3RoZXIsIG9yIGEgZGVmYXVsdCBvbmUKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHBhcmFtIG9rTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgYXdhaXQgb2tNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBPa2AsIGB2YWx1ZWAgaWYgYEVycmAKICAgICAqIEB0aHJvd3MgaWYgYGF3YWl0IG9rTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgYXN5bmMgbWFwT3IodmFsdWUsIG9rTWFwcGVyKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gYXdhaXQgb2tNYXBwZXIodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIE1hcCB0aGUgaW5uZXIgdmFsdWUgaW50byBhbm90aGVyLCBvciBhIGRlZmF1bHQgb25lCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEBwYXJhbSBva01hcHBlcgogICAgICogQHJldHVybnMgYG9rTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgT2tgLCBgdmFsdWVgIGlmIGBFcnJgCiAgICAgKiBAdGhyb3dzIGlmIGBva01hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIG1hcE9yU3luYyh2YWx1ZSwgb2tNYXBwZXIpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiBva01hcHBlcih0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogTWFwIHRoZSBpbm5lciB2YWx1ZSBpbnRvIGFub3RoZXIsIG9yIGEgZGVmYXVsdCBvbmUKICAgICAqIEBwYXJhbSBlcnJNYXBwZXIKICAgICAqIEBwYXJhbSBva01hcHBlcgogICAgICogQHJldHVybnMgYGF3YWl0IG9rTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgT2tgLCBgYXdhaXQgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgRXJyYAogICAgICogQHRocm93cyBpZiBgYXdhaXQgb2tNYXBwZXIodGhpcy5pbm5lcilgIG9yIGBhd2FpdCBlcnJNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICBhc3luYyBtYXBPckVsc2UoZXJyTWFwcGVyLCBva01hcHBlcikgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIGF3YWl0IG9rTWFwcGVyKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBNYXAgdGhlIGlubmVyIHZhbHVlIGludG8gYW5vdGhlciwgb3IgYSBkZWZhdWx0IG9uZQogICAgICogQHBhcmFtIGVyck1hcHBlcgogICAgICogQHBhcmFtIG9rTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgb2tNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBPa2AsIGBlcnJNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBFcnJgCiAgICAgKiBAdGhyb3dzIGlmIGBva01hcHBlcih0aGlzLmlubmVyKWAgb3IgYGVyck1hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIG1hcE9yRWxzZVN5bmMoZXJyTWFwcGVyLCBva01hcHBlcikgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIG9rTWFwcGVyKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm4gYHZhbHVlYCBpZiBgT2tgLCByZXR1cm4gYHRoaXNgIGlmIGBFcnJgCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEByZXR1cm5zIGB2YWx1ZWAgaWYgYE9rYCwgYHRoaXNgIGlmIGBFcnJgCiAgICAgKi8KICAgIGFuZCh2YWx1ZSkgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIHZhbHVlOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm4gYGF3YWl0IG9rTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgT2tgLCByZXR1cm4gYHRoaXNgIGlmIGBFcnJgCiAgICAgKiBAcGFyYW0gb2tNYXBwZXIKICAgICAqIEByZXR1cm5zIGBhd2FpdCBva01hcHBlcih0aGlzLmlubmVyKWAgaWYgYE9rYCwgYHRoaXNgIGlmIGBFcnJgCiAgICAgKiBAdGhyb3dzIGlmIGBhd2FpdCBva01hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIGFzeW5jIGFuZFRoZW4ob2tNYXBwZXIpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiBhd2FpdCBva01hcHBlcih0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJuIGBva01hcHBlcih0aGlzLmlubmVyKWAgaWYgYE9rYCwgcmV0dXJuIGB0aGlzYCBpZiBgRXJyYAogICAgICogQHBhcmFtIG9rTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgb2tNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBPa2AsIGB0aGlzYCBpZiBgRXJyYAogICAgICogQHRocm93cyBpZiBgb2tNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICBhbmRUaGVuU3luYyhva01hcHBlcikgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIG9rTWFwcGVyKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm4gYHZhbHVlYCBpZiBgRXJyYCwgcmV0dXJuIGB0aGlzYCBpZiBgT2tgCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEByZXR1cm5zIGB2YWx1ZWAgaWYgYEVycmAsIGB0aGlzYCBpZiBgT2tgCiAgICAgKi8KICAgIG9yKHZhbHVlKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybiBgYXdhaXQgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgRXJyYCwgcmV0dXJuIGB0aGlzYCBpZiBgT2tgCiAgICAgKiBAcGFyYW0gZXJyTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgYXdhaXQgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgRXJyYCwgYHRoaXNgIGlmIGBPa2AKICAgICAqIEB0aHJvd3MgaWYgYGF3YWl0IGVyck1hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIGFzeW5jIG9yRWxzZShlcnJNYXBwZXIpIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJuIGBlcnJNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBFcnJgLCByZXR1cm4gYHRoaXNgIGlmIGBPa2AKICAgICAqIEBwYXJhbSBlcnJNYXBwZXIKICAgICAqIEByZXR1cm5zIGBlcnJNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBFcnJgLCBgdGhpc2AgaWYgYE9rYAogICAgICogQHRocm93cyBpZiBgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgb3JFbHNlU3luYyhlcnJNYXBwZXIpIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtIFJlc3VsdDxSZXN1bHQ8VCwgRTE+LCBFMj4gaW50byBSZXN1bHQ8VCwgRTEgfCBFMj4KICAgICAqIEBwYXJhbSByZXN1bHQKICAgICAqIEByZXR1cm5zIGB0aGlzYCBpZiBgRXJyYCwgYHRoaXMuaW5uZXJgIGlmIGBPa2AKICAgICAqLwogICAgZmxhdHRlbigpIHsKICAgICAgICByZXR1cm4gdGhpcy5pbm5lcjsKICAgIH0KfQoKCi8vIyBzb3VyY2VNYXBwaW5nVVJMPW9rLm1qcy5tYXAKCjsvLyBDT05DQVRFTkFURUQgTU9EVUxFOiAuL25vZGVfbW9kdWxlcy9AaGF6YWU0MS9vcHRpb24vZGlzdC9lc20vbW9kcy9vcHRpb24vc29tZS5tanMKCgoKY2xhc3MgU29tZSB7CiAgICBpbm5lcjsKICAgIC8qKgogICAgICogQW4gZXhpc3RpbmcgdmFsdWUKICAgICAqIEBwYXJhbSBpbm5lcgogICAgICovCiAgICBjb25zdHJ1Y3Rvcihpbm5lcikgewogICAgICAgIHRoaXMuaW5uZXIgPSBpbm5lcjsKICAgIH0KICAgIC8qKgogICAgICogQ3JlYXRlIGEgYFNvbWVgCiAgICAgKiBAcGFyYW0gaW5uZXIKICAgICAqIEByZXR1cm5zIGBTb21lKGlubmVyKWAKICAgICAqLwogICAgc3RhdGljIG5ldyhpbm5lcikgewogICAgICAgIHJldHVybiBuZXcgU29tZShpbm5lcik7CiAgICB9CiAgICBzdGF0aWMgZnJvbShpbml0KSB7CiAgICAgICAgcmV0dXJuIG5ldyBTb21lKGluaXQuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBUeXBlIGd1YXJkIGZvciBgU29tZWAKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgU29tZWAsIGBmYWxzZWAgaWYgYE5vbmVgCiAgICAgKi8KICAgIGlzU29tZSgpIHsKICAgICAgICByZXR1cm4gdHJ1ZTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBgdHJ1ZWAgaWYgdGhlIG9wdGlvbiBpcyBhIGBTb21lYCBhbmQgdGhlIHZhbHVlIGluc2lkZSBvZiBpdCBtYXRjaGVzIGEgcHJlZGljYXRlCiAgICAgKiBAcGFyYW0gc29tZVByZWRpY2F0ZQogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBTb21lYCBhbmQgYGF3YWl0IHNvbWVQcmVkaWNhdGUodGhpcy5pbm5lcilgLCBgTm9uZWAgb3RoZXJ3aXNlCiAgICAgKi8KICAgIGFzeW5jIGlzU29tZUFuZChzb21lUHJlZGljYXRlKSB7CiAgICAgICAgcmV0dXJuIGF3YWl0IHNvbWVQcmVkaWNhdGUodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYHRydWVgIGlmIHRoZSBvcHRpb24gaXMgYSBgU29tZWAgYW5kIHRoZSB2YWx1ZSBpbnNpZGUgb2YgaXQgbWF0Y2hlcyBhIHByZWRpY2F0ZQogICAgICogQHBhcmFtIHNvbWVQcmVkaWNhdGUKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgU29tZWAgYW5kIGBzb21lUHJlZGljYXRlKHRoaXMuaW5uZXIpYCwgYE5vbmVgIG90aGVyd2lzZQogICAgICovCiAgICBpc1NvbWVBbmRTeW5jKHNvbWVQcmVkaWNhdGUpIHsKICAgICAgICByZXR1cm4gc29tZVByZWRpY2F0ZSh0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogVHlwZSBndWFyZCBmb3IgYE5vbmVgCiAgICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYE5vbmVgLCBgZmFsc2VgIGlmIGBTb21lYAogICAgICovCiAgICBpc05vbmUoKSB7CiAgICAgICAgcmV0dXJuIGZhbHNlOwogICAgfQogICAgLyoqCiAgICAgKiBDb21waWxlLXRpbWUgc2FmZWx5IGdldCBgdGhpcy5pbm5lcmAKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYAogICAgICovCiAgICBnZXQoKSB7CiAgICAgICAgcmV0dXJuIHRoaXMuaW5uZXI7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYW4gaXRlcmF0b3Igb3ZlciB0aGUgcG9zc2libHkgY29udGFpbmVkIHZhbHVlCiAgICAgKiBAeWllbGRzIGB0aGlzLmlubmVyYCBpZiBgU29tZWAKICAgICAqLwogICAgKltTeW1ib2wuaXRlcmF0b3JdKCkgewogICAgICAgIHlpZWxkIHRoaXMuaW5uZXI7CiAgICB9CiAgICAvKioKICAgICAqIEdldCB0aGUgaW5uZXIgdmFsdWUgaWYgYFNvbWVgLCB0aHJvdyBgRXJyb3IobWVzc2FnZSlgIG90aGVyd2lzZQogICAgICogQHBhcmFtIG1lc3NhZ2UKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgU29tZWAKICAgICAqIEB0aHJvd3MgYEVycm9yKG1lc3NhZ2UpYCBpZiBgTm9uZWAKICAgICAqLwogICAgZXhwZWN0KG1lc3NhZ2UpIHsKICAgICAgICByZXR1cm4gdGhpcy5pbm5lcjsKICAgIH0KICAgIC8qKgogICAgICogR2V0IHRoZSBpbm5lciB2YWx1ZSBvciB0aHJvdyBhIE5vbmVFcnJvcgogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBTb21lYAogICAgICogQHRocm93cyBgTm9uZUVycm9yYCBpZiBgTm9uZWAKICAgICAqLwogICAgdW53cmFwKCkgewogICAgICAgIHJldHVybiB0aGlzLmlubmVyOwogICAgfQogICAgLyoqCiAgICAgKiBHZXQgdGhlIGlubmVyIHZhbHVlIG9yIGEgZGVmYXVsdCBvbmUKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBTb21lYCwgYHZhbHVlYCBpZiBgTm9uZWAKICAgICAqLwogICAgdW53cmFwT3IodmFsdWUpIHsKICAgICAgICByZXR1cm4gdGhpcy5pbm5lcjsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyB0aGUgY29udGFpbmVkIGBTb21lYCB2YWx1ZSBvciBjb21wdXRlcyBpdCBmcm9tIGEgY2xvc3VyZQogICAgICogQHBhcmFtIG5vbmVDYWxsYmFjawogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBTb21lYCwgYGF3YWl0IG5vbmVDYWxsYmFjaygpYCBpZiBgTm9uZWAKICAgICAqLwogICAgYXN5bmMgdW53cmFwT3JFbHNlKG5vbmVDYWxsYmFjaykgewogICAgICAgIHJldHVybiB0aGlzLmlubmVyOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIHRoZSBjb250YWluZWQgYFNvbWVgIHZhbHVlIG9yIGNvbXB1dGVzIGl0IGZyb20gYSBjbG9zdXJlCiAgICAgKiBAcGFyYW0gbm9uZUNhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAgaWYgYFNvbWVgLCBgbm9uZUNhbGxiYWNrKClgIGlmIGBOb25lYAogICAgICovCiAgICB1bndyYXBPckVsc2VTeW5jKG5vbmVDYWxsYmFjaykgewogICAgICAgIHJldHVybiB0aGlzLmlubmVyOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm0gYE9wdGlvbjxUPmAgaW50byBgUmVzdWx0PFQsIE5vbmVFcnJvcj5gCiAgICAgKiBAcmV0dXJucyBgT2sodGhpcy5pbm5lcilgIGlmIGBTb21lYCwgYEVycihOb25lRXJyb3IpYCBpZiBgTm9uZWAKICAgICAqLwogICAgb2soKSB7CiAgICAgICAgcmV0dXJuIG5ldyBPayh0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtIGBPcHRpb248VD5gIGludG8gYFJlc3VsdDxULCBFPmAKICAgICAqIEBwYXJhbSBlcnJvcgogICAgICogQHJldHVybnMgYE9rKHRoaXMuaW5uZXIpYCBpZiBgU29tZWAsIGBFcnIoZXJyb3IpYCBpZiBgTm9uZWAKICAgICAqLwogICAgb2tPcihlcnJvcikgewogICAgICAgIHJldHVybiBuZXcgT2sodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybXMgdGhlIGBPcHRpb248VD5gIGludG8gYSBgUmVzdWx0PFQsIEU+YCwgbWFwcGluZyBgU29tZSh2KWAgdG8gYE9rKHYpYCBhbmQgYE5vbmVgIHRvIGBFcnIoZXJyKCkpYAogICAgICogQHBhcmFtIG5vbmVDYWxsYmFjawogICAgICogQHJldHVybnMgYE9rKHRoaXMuaW5uZXIpYCBpZiBgU29tZWAsIGBFcnIoYXdhaXQgbm9uZUNhbGxiYWNrKCkpYCBpcyBgTm9uZWAKICAgICAqLwogICAgYXN5bmMgb2tPckVsc2Uobm9uZUNhbGxiYWNrKSB7CiAgICAgICAgcmV0dXJuIG5ldyBPayh0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtcyB0aGUgYE9wdGlvbjxUPmAgaW50byBhIGBSZXN1bHQ8VCwgRT5gLCBtYXBwaW5nIGBTb21lKHYpYCB0byBgT2sodilgIGFuZCBgTm9uZWAgdG8gYEVycihlcnIoKSlgCiAgICAgKiBAcGFyYW0gbm9uZUNhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgT2sodGhpcy5pbm5lcilgIGlmIGBTb21lYCwgYEVycihub25lQ2FsbGJhY2soKSlgIGlzIGBOb25lYAogICAgICovCiAgICBva09yRWxzZVN5bmMobm9uZUNhbGxiYWNrKSB7CiAgICAgICAgcmV0dXJuIG5ldyBPayh0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBgTm9uZWAgaWYgdGhlIG9wdGlvbiBpcyBgTm9uZWAsIG90aGVyd2lzZSBjYWxscyBgc29tZVByZWRpY2F0ZWAgd2l0aCB0aGUgd3JhcHBlZCB2YWx1ZQogICAgICogQHBhcmFtIHNvbWVQcmVkaWNhdGUKICAgICAqIEByZXR1cm5zIGBTb21lYCBpZiBgU29tZWAgYW5kIGBhd2FpdCBzb21lUHJlZGljYXRlKHRoaXMuaW5uZXIpYCwgYE5vbmVgIG90aGVyd2lzZQogICAgICovCiAgICBhc3luYyBmaWx0ZXIoc29tZVByZWRpY2F0ZSkgewogICAgICAgIGlmIChhd2FpdCBzb21lUHJlZGljYXRlKHRoaXMuaW5uZXIpKQogICAgICAgICAgICByZXR1cm4gdGhpczsKICAgICAgICBlbHNlCiAgICAgICAgICAgIHJldHVybiBuZXcgTm9uZSgpOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGBOb25lYCBpZiB0aGUgb3B0aW9uIGlzIGBOb25lYCwgb3RoZXJ3aXNlIGNhbGxzIGBzb21lUHJlZGljYXRlYCB3aXRoIHRoZSB3cmFwcGVkIHZhbHVlCiAgICAgKiBAcGFyYW0gc29tZVByZWRpY2F0ZQogICAgICogQHJldHVybnMgYFNvbWVgIGlmIGBTb21lYCBhbmQgYHNvbWVQcmVkaWNhdGUodGhpcy5pbm5lcilgLCBgTm9uZWAgb3RoZXJ3aXNlCiAgICAgKi8KICAgIGZpbHRlclN5bmMoc29tZVByZWRpY2F0ZSkgewogICAgICAgIGlmIChzb21lUHJlZGljYXRlKHRoaXMuaW5uZXIpKQogICAgICAgICAgICByZXR1cm4gdGhpczsKICAgICAgICBlbHNlCiAgICAgICAgICAgIHJldHVybiBuZXcgTm9uZSgpOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm0gYE9wdGlvbjxQcm9taXNlPFQ+PmAgaW50byBgUHJvbWlzZTxPcHRpb248VD4+YAogICAgICogQHJldHVybnMgYFByb21pc2U8T3B0aW9uPFQ+PmAKICAgICAqLwogICAgYXN5bmMgYXdhaXQoKSB7CiAgICAgICAgcmV0dXJuIG5ldyBTb21lKGF3YWl0IHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGB0cnVlYCBpZiB0aGUgb3B0aW9uIGlzIGEgYFNvbWVgIHZhbHVlIGNvbnRhaW5pbmcgdGhlIGdpdmVuIHZhbHVlCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgU29tZWAgYW5kIGB0aGlzLmlubmVyID09PSB2YWx1ZWAsIGBOb25lYCBvdGhlcndpc2UKICAgICAqLwogICAgY29udGFpbnModmFsdWUpIHsKICAgICAgICByZXR1cm4gdGhpcy5pbm5lciA9PT0gdmFsdWU7CiAgICB9CiAgICAvKioKICAgICAqIENhbGxzIHRoZSBnaXZlbiBjYWxsYmFjayB3aXRoIHRoZSBpbm5lciB2YWx1ZSBpZiBgT2tgCiAgICAgKiBAcGFyYW0gc29tZUNhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgdGhpc2AKICAgICAqLwogICAgYXN5bmMgaW5zcGVjdChzb21lQ2FsbGJhY2spIHsKICAgICAgICBhd2FpdCBzb21lQ2FsbGJhY2sodGhpcy5pbm5lcik7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIENhbGxzIHRoZSBnaXZlbiBjYWxsYmFjayB3aXRoIHRoZSBpbm5lciB2YWx1ZSBpZiBgT2tgCiAgICAgKiBAcGFyYW0gc29tZUNhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgdGhpc2AKICAgICAqLwogICAgaW5zcGVjdFN5bmMoc29tZUNhbGxiYWNrKSB7CiAgICAgICAgc29tZUNhbGxiYWNrKHRoaXMuaW5uZXIpOwogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBNYXBzIGFuIGBPcHRpb248VD5gIHRvIGBPcHRpb248VT5gIGJ5IGFwcGx5aW5nIGEgZnVuY3Rpb24gdG8gYSBjb250YWluZWQgdmFsdWUgKGlmIGBTb21lYCkgb3IgcmV0dXJucyBgTm9uZWAgKGlmIGBOb25lYCkKICAgICAqIEBwYXJhbSBzb21lTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgU29tZShhd2FpdCBzb21lTWFwcGVyKHRoaXMuaW5uZXIpKWAgaWYgYFNvbWVgLCBgdGhpc2AgaWYgYE5vbmVgCiAgICAgKi8KICAgIGFzeW5jIG1hcChzb21lTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIG5ldyBTb21lKGF3YWl0IHNvbWVNYXBwZXIodGhpcy5pbm5lcikpOwogICAgfQogICAgLyoqCiAgICAgKiBNYXBzIGFuIGBPcHRpb248VD5gIHRvIGBPcHRpb248VT5gIGJ5IGFwcGx5aW5nIGEgZnVuY3Rpb24gdG8gYSBjb250YWluZWQgdmFsdWUgKGlmIGBTb21lYCkgb3IgcmV0dXJucyBgTm9uZWAgKGlmIGBOb25lYCkKICAgICAqIEBwYXJhbSBzb21lTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgU29tZShzb21lTWFwcGVyKHRoaXMuaW5uZXIpKWAgaWYgYFNvbWVgLCBgdGhpc2AgaWYgYE5vbmVgCiAgICAgKi8KICAgIG1hcFN5bmMoc29tZU1hcHBlcikgewogICAgICAgIHJldHVybiBuZXcgU29tZShzb21lTWFwcGVyKHRoaXMuaW5uZXIpKTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyB0aGUgcHJvdmlkZWQgZGVmYXVsdCByZXN1bHQgKGlmIG5vbmUpLCBvciBhcHBsaWVzIGEgZnVuY3Rpb24gdG8gdGhlIGNvbnRhaW5lZCB2YWx1ZSAoaWYgYW55KQogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcGFyYW0gc29tZU1hcHBlcgogICAgICogQHJldHVybnMgYHZhbHVlYCBpZiBgTm9uZWAsIGBhd2FpdCBzb21lTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgU29tZWAKICAgICAqLwogICAgYXN5bmMgbWFwT3IodmFsdWUsIHNvbWVNYXBwZXIpIHsKICAgICAgICByZXR1cm4gYXdhaXQgc29tZU1hcHBlcih0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyB0aGUgcHJvdmlkZWQgZGVmYXVsdCByZXN1bHQgKGlmIG5vbmUpLCBvciBhcHBsaWVzIGEgZnVuY3Rpb24gdG8gdGhlIGNvbnRhaW5lZCB2YWx1ZSAoaWYgYW55KQogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcGFyYW0gc29tZU1hcHBlcgogICAgICogQHJldHVybnMgYHZhbHVlYCBpZiBgTm9uZWAsIGBzb21lTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgU29tZWAKICAgICAqLwogICAgbWFwT3JTeW5jKHZhbHVlLCBzb21lTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIHNvbWVNYXBwZXIodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIENvbXB1dGVzIGEgZGVmYXVsdCBmdW5jdGlvbiByZXN1bHQgKGlmIG5vbmUpLCBvciBhcHBsaWVzIGEgZGlmZmVyZW50IGZ1bmN0aW9uIHRvIHRoZSBjb250YWluZWQgdmFsdWUgKGlmIGFueSkKICAgICAqIEBwYXJhbSBub25lQ2FsbGJhY2sKICAgICAqIEBwYXJhbSBzb21lTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgYXdhaXQgc29tZU1hcHBlcih0aGlzLmlubmVyKWAgaWYgYFNvbWVgLCBgYXdhaXQgbm9uZUNhbGxiYWNrKClgIGlmIGBOb25lYAogICAgICovCiAgICBhc3luYyBtYXBPckVsc2Uobm9uZUNhbGxiYWNrLCBzb21lTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIGF3YWl0IHNvbWVNYXBwZXIodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIENvbXB1dGVzIGEgZGVmYXVsdCBmdW5jdGlvbiByZXN1bHQgKGlmIG5vbmUpLCBvciBhcHBsaWVzIGEgZGlmZmVyZW50IGZ1bmN0aW9uIHRvIHRoZSBjb250YWluZWQgdmFsdWUgKGlmIGFueSkKICAgICAqIEBwYXJhbSBub25lQ2FsbGJhY2sKICAgICAqIEBwYXJhbSBzb21lTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgc29tZU1hcHBlcih0aGlzLmlubmVyKWAgaWYgYFNvbWVgLCBgbm9uZUNhbGxiYWNrKClgIGlmIGBOb25lYAogICAgICovCiAgICBtYXBPckVsc2VTeW5jKG5vbmVDYWxsYmFjaywgc29tZU1hcHBlcikgewogICAgICAgIHJldHVybiBzb21lTWFwcGVyKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGBOb25lYCBpZiB0aGUgb3B0aW9uIGlzIGBOb25lYCwgb3RoZXJ3aXNlIHJldHVybnMgYHZhbHVlYAogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcmV0dXJucyBgTm9uZWAgaWYgYE5vbmVgLCBgdmFsdWVgIGlmIGBTb21lYAogICAgICovCiAgICBhbmQodmFsdWUpIHsKICAgICAgICByZXR1cm4gdmFsdWU7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYE5vbmVgIGlmIHRoZSBvcHRpb24gaXMgYE5vbmVgLCBvdGhlcndpc2UgY2FsbHMgYHNvbWVNYXBwZXJgIHdpdGggdGhlIHdyYXBwZWQgdmFsdWUgYW5kIHJldHVybnMgdGhlIHJlc3VsdAogICAgICogQHBhcmFtIHNvbWVNYXBwZXIKICAgICAqIEByZXR1cm5zIGBOb25lYCBpZiBgTm9uZWAsIGBhd2FpdCBzb21lTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgU29tZWAKICAgICAqLwogICAgYXN5bmMgYW5kVGhlbihzb21lTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIGF3YWl0IHNvbWVNYXBwZXIodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYE5vbmVgIGlmIHRoZSBvcHRpb24gaXMgYE5vbmVgLCBvdGhlcndpc2UgY2FsbHMgYHNvbWVNYXBwZXJgIHdpdGggdGhlIHdyYXBwZWQgdmFsdWUgYW5kIHJldHVybnMgdGhlIHJlc3VsdAogICAgICogQHBhcmFtIHNvbWVNYXBwZXIKICAgICAqIEByZXR1cm5zIGBOb25lYCBpZiBgTm9uZWAsIGBzb21lTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgU29tZWAKICAgICAqLwogICAgYW5kVGhlblN5bmMoc29tZU1hcHBlcikgewogICAgICAgIHJldHVybiBzb21lTWFwcGVyKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGB0aGlzYCBpZiBgU29tZWAsIG90aGVyd2lzZSByZXR1cm5zIGB2YWx1ZWAKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHJldHVybnMgYHRoaXNgIGlmIGBTb21lYCwgYHZhbHVlYCBpZiBgTm9uZWAKICAgICAqLwogICAgb3IodmFsdWUpIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBgdGhpc2AgaWYgYFNvbWVgLCBvdGhlcndpc2UgY2FsbHMgYG5vbmVDYWxsYmFja2AgYW5kIHJldHVybnMgdGhlIHJlc3VsdAogICAgICogQHBhcmFtIG5vbmVDYWxsYmFjawogICAgICogQHJldHVybnMgYHRoaXNgIGlmIGBTb21lYCwgYGF3YWl0IG5vbmVDYWxsYmFjaygpYCBpZiBgTm9uZWAKICAgICAqLwogICAgYXN5bmMgb3JFbHNlKG5vbmVDYWxsYmFjaykgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGB0aGlzYCBpZiBgU29tZWAsIG90aGVyd2lzZSBjYWxscyBgbm9uZUNhbGxiYWNrYCBhbmQgcmV0dXJucyB0aGUgcmVzdWx0CiAgICAgKiBAcGFyYW0gbm9uZUNhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgdGhpc2AgaWYgYFNvbWVgLCBgbm9uZUNhbGxiYWNrKClgIGlmIGBOb25lYAogICAgICovCiAgICBvckVsc2VTeW5jKG5vbmVDYWxsYmFjaykgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGBTb21lYCBpZiBleGFjdGx5IG9uZSBvZiB0aGUgb3B0aW9ucyBpcyBgU29tZWAsIG90aGVyd2lzZSByZXR1cm5zIGBOb25lYAogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcmV0dXJucyBgTm9uZWAgaWYgYm90aCBhcmUgYFNvbWVgIG9yIGJvdGggYXJlIGBOb25lYCwgdGhlIG9ubHkgYFNvbWVgIG90aGVyd2lzZQogICAgICovCiAgICB4b3IodmFsdWUpIHsKICAgICAgICBpZiAodmFsdWUuaXNTb21lKCkpCiAgICAgICAgICAgIHJldHVybiBuZXcgTm9uZSgpOwogICAgICAgIGVsc2UKICAgICAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIFppcHMgYHRoaXNgIHdpdGggYW5vdGhlciBgT3B0aW9uYAogICAgICogQHBhcmFtIG90aGVyCiAgICAgKiBAcmV0dXJucyBgU29tZShbdGhpcy5pbm5lciwgb3RoZXIuaW5uZXJdKWAgaWYgYm90aCBhcmUgYFNvbWVgLCBgTm9uZWAgaWYgb25lIG9mIHRoZW0gaXMgYE5vbmVgCiAgICAgKi8KICAgIHppcChvdGhlcikgewogICAgICAgIGlmIChvdGhlci5pc1NvbWUoKSkKICAgICAgICAgICAgcmV0dXJuIG5ldyBTb21lKFt0aGlzLmlubmVyLCBvdGhlci5pbm5lcl0pOwogICAgICAgIGVsc2UKICAgICAgICAgICAgcmV0dXJuIG90aGVyOwogICAgfQp9CgoKLy8jIHNvdXJjZU1hcHBpbmdVUkw9c29tZS5tanMubWFwCgo7Ly8gQ09OQ0FURU5BVEVEIE1PRFVMRTogLi9ub2RlX21vZHVsZXMvQGhhemFlNDEvcmVzdWx0L2Rpc3QvZXNtL21vZHMvcmVzdWx0L2Vyci5tanMKCgoKCmNsYXNzIEVyciB7CiAgICAjaW5uZXI7CiAgICAjdGltZW91dDsKICAgIC8qKgogICAgICogQSBmYWlsdXJlCiAgICAgKiBAcGFyYW0gaW5uZXIKICAgICAqLwogICAgY29uc3RydWN0b3IoaW5uZXIpIHsKICAgICAgICB0aGlzLiNpbm5lciA9IGlubmVyOwogICAgICAgIGlmICghUmVzdWx0LmRlYnVnKQogICAgICAgICAgICByZXR1cm47CiAgICAgICAgY29uc3QgZXJyb3IgPSBQYW5pYy5mcm9tKG5ldyBFcnJvcihgQW4gRXJyIGhhcyBub3QgYmVlbiBoYW5kbGVkIHByb3Blcmx5YCwgeyBjYXVzZTogdGhpcyB9KSk7CiAgICAgICAgdGhpcy4jdGltZW91dCA9IHNldFRpbWVvdXQoKCkgPT4geyB0aHJvdyBlcnJvcjsgfSwgMTAwMCk7CiAgICB9CiAgICAvKioKICAgICAqIENyZWF0ZSBhbiBlbXB0eSBgRXJyYAogICAgICogQHJldHVybnMgYEVycih2b2lkKWAKICAgICAqLwogICAgc3RhdGljIHZvaWQoKSB7CiAgICAgICAgcmV0dXJuIG5ldyBFcnIodW5kZWZpbmVkKTsKICAgIH0KICAgIC8qKgogICAgICogQ3JlYXRlIGFuIGBFcnJgCiAgICAgKiBAcGFyYW0gaW5uZXIKICAgICAqIEByZXR1cm5zIGBFcnIoaW5uZXIpYAogICAgICovCiAgICBzdGF0aWMgbmV3KGlubmVyKSB7CiAgICAgICAgcmV0dXJuIG5ldyBFcnIoaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBDcmVhdGUgYW4gYEVycmAgd2l0aCBhbiBgRXJyb3JgIGluc2lkZQogICAgICogQHBhcmFtIG1lc3NhZ2UKICAgICAqIEBwYXJhbSBvcHRpb25zCiAgICAgKiBAcmV0dXJucyBgRXJyPEVycm9yPmAKICAgICAqLwogICAgc3RhdGljIGVycm9yKG1lc3NhZ2UsIG9wdGlvbnMpIHsKICAgICAgICByZXR1cm4gbmV3IEVycihuZXcgRXJyb3IobWVzc2FnZSwgb3B0aW9ucykpOwogICAgfQogICAgZ2V0IGlubmVyKCkgewogICAgICAgIHJldHVybiB0aGlzLiNpbm5lcjsKICAgIH0KICAgIC8qKgogICAgICogU2V0IHRoaXMgcmVzdWx0IGFzIGhhbmRsZWQKICAgICAqLwogICAgaWdub3JlKCkgewogICAgICAgIGlmICghdGhpcy4jdGltZW91dCkKICAgICAgICAgICAgcmV0dXJuIHRoaXM7CiAgICAgICAgY2xlYXJUaW1lb3V0KHRoaXMuI3RpbWVvdXQpOwogICAgICAgIHRoaXMuI3RpbWVvdXQgPSB1bmRlZmluZWQ7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIFR5cGUgZ3VhcmQgZm9yIGBPa2AKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgT2tgLCBgZmFsc2VgIGlmIGBFcnJgCiAgICAgKi8KICAgIGlzT2soKSB7CiAgICAgICAgcmV0dXJuIGZhbHNlOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIHRydWUgaWYgdGhlIHJlc3VsdCBpcyBgT2tgIGFuZCB0aGUgdmFsdWUgaW5zaWRlIG9mIGl0IG1hdGNoZXMgYSBwcmVkaWNhdGUKICAgICAqIEBwYXJhbSBva1ByZWRpY2F0ZQogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBPa2AgYW5kIGBhd2FpdCBva1ByZWRpY2F0ZSh0aGlzLmlubmVyKWAsIGBmYWxzZWAgb3RoZXJ3aXNlCiAgICAgKi8KICAgIGFzeW5jIGlzT2tBbmQob2tQcmVkaWNhdGUpIHsKICAgICAgICByZXR1cm4gZmFsc2U7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgdHJ1ZSBpZiB0aGUgcmVzdWx0IGlzIGBPa2AgYW5kIHRoZSB2YWx1ZSBpbnNpZGUgb2YgaXQgbWF0Y2hlcyBhIHByZWRpY2F0ZQogICAgICogQHBhcmFtIG9rUHJlZGljYXRlCiAgICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYE9rYCBhbmQgYGF3YWl0IG9rUHJlZGljYXRlKHRoaXMuaW5uZXIpYCwgYGZhbHNlYCBvdGhlcndpc2UKICAgICAqLwogICAgaXNPa0FuZFN5bmMob2tQcmVkaWNhdGUpIHsKICAgICAgICByZXR1cm4gZmFsc2U7CiAgICB9CiAgICAvKioKICAgICAqIFR5cGUgZ3VhcmQgZm9yIGBFcnJgCiAgICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYEVycmAsIGBmYWxzZWAgaWYgYE9rYAogICAgICovCiAgICBpc0VycigpIHsKICAgICAgICByZXR1cm4gdHJ1ZTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyB0cnVlIGlmIHRoZSByZXN1bHQgaXMgYEVycmAgYW5kIHRoZSB2YWx1ZSBpbnNpZGUgb2YgaXQgbWF0Y2hlcyBhIHByZWRpY2F0ZQogICAgICogQHBhcmFtIGVyclByZWRpY2F0ZQogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBFcnJgIGFuZCBgYXdhaXQgZXJyUHJlZGljYXRlKHRoaXMuaW5uZXIpYCwgYGZhbHNlYCBvdGhlcndpc2UKICAgICAqLwogICAgYXN5bmMgaXNFcnJBbmQoZXJyUHJlZGljYXRlKSB7CiAgICAgICAgcmV0dXJuIGF3YWl0IGVyclByZWRpY2F0ZSh0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyB0cnVlIGlmIHRoZSByZXN1bHQgaXMgYEVycmAgYW5kIHRoZSB2YWx1ZSBpbnNpZGUgb2YgaXQgbWF0Y2hlcyBhIHByZWRpY2F0ZQogICAgICogQHBhcmFtIGVyclByZWRpY2F0ZQogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBFcnJgIGFuZCBgYXdhaXQgZXJyUHJlZGljYXRlKHRoaXMuaW5uZXIpYCwgYGZhbHNlYCBvdGhlcndpc2UKICAgICAqLwogICAgaXNFcnJBbmRTeW5jKGVyclByZWRpY2F0ZSkgewogICAgICAgIHJldHVybiBlcnJQcmVkaWNhdGUodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIENvbXBpbGUtdGltZSBzYWZlbHkgZ2V0IGB0aGlzLmlubmVyYAogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgCiAgICAgKi8KICAgIGdldCgpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiB0aGlzLmlubmVyOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm0gYFJlc3VsdDxULCBFPmAgaW50byBgT3B0aW9uPFQ+YAogICAgICogQHJldHVybnMgYFNvbWUodGhpcy5pbm5lcilgIGlmIGBPa2AsIGBOb25lYCBpZiBgRXJyYAogICAgICovCiAgICBvaygpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiBuZXcgTm9uZSgpOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm0gYFJlc3VsdDxULCBFPmAgaW50byBgT3B0aW9uPEU+YAogICAgICogQHJldHVybnMgYFNvbWUodGhpcy5pbm5lcilgIGlmIGBFcnJgLCBgTm9uZWAgaWYgYE9rYAogICAgICovCiAgICBlcnIoKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gbmV3IFNvbWUodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYW4gaXRlcmF0b3Igb3ZlciB0aGUgcG9zc2libHkgY29udGFpbmVkIHZhbHVlCiAgICAgKiBAeWllbGRzIGB0aGlzLmlubmVyYCBpZiBgT2tgCiAgICAgKi8KICAgICpbU3ltYm9sLml0ZXJhdG9yXSgpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybjsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtIGBSZXN1bHQ8VCxFPmAgaW50byBgW1QsRV1gCiAgICAgKiBAcmV0dXJucyBgW3RoaXMuaW5uZXIsIHVuZGVmaW5lZF1gIGlmIGBPa2AsIGBbdW5kZWZpbmVkLCB0aGlzLmlubmVyXWAgaWYgYEVycmAKICAgICAqLwogICAgc3BsaXQoKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gW3VuZGVmaW5lZCwgdGhpcy5pbm5lcl07CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgdHJ1ZSBpZiB0aGUgcmVzdWx0IGlzIGFuIGBPa2AgdmFsdWUgY29udGFpbmluZyB0aGUgZ2l2ZW4gdmFsdWUKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBPa2AgYW5kIGB0aGlzLmlubmVyID09PSB2YWx1ZWAsIGBmYWxzZWAgb3RoZXJ3aXNlCiAgICAgKi8KICAgIGNvbnRhaW5zKHZhbHVlKSB7CiAgICAgICAgcmV0dXJuIGZhbHNlOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIHRydWUgaWYgdGhlIHJlc3VsdCBpcyBhbiBgRXJyYCB2YWx1ZSBjb250YWluaW5nIHRoZSBnaXZlbiB2YWx1ZQogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYEVycmAgYW5kIGB0aGlzLmlubmVyID09PSB2YWx1ZWAsIGBmYWxzZWAgb3RoZXJ3aXNlCiAgICAgKi8KICAgIGNvbnRhaW5zRXJyKHZhbHVlKSB7CiAgICAgICAgcmV0dXJuIHRoaXMuaW5uZXIgPT09IHZhbHVlOwogICAgfQogICAgLyoqCiAgICAgKiBHZXQgdGhlIGlubmVyIHZhbHVlIG9yIHRocm93IHRvIHRoZSBjbG9zZXN0IGBSZXN1bHQudW50aHJvd2AKICAgICAqIEBwYXJhbSB0aHJvd2VyIFRoZSB0aHJvd2VyIGZyb20gYFJlc3VsdC51bnRocm93YAogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBPa2AKICAgICAqIEB0aHJvd3MgYHVuZGVmaW5lZGAgaWYgYEVycmAKICAgICAqIEBzZWUgUmVzdWx0LnVudGhyb3cKICAgICAqIEBzZWUgUmVzdWx0LnVudGhyb3dTeW5jCiAgICAgKi8KICAgIHRocm93KHRocm93ZXIpIHsKICAgICAgICB0aHJvd2VyKHRoaXMpOwogICAgICAgIHRocm93IFBhbmljLmZyb20obmV3IEVycm9yKGBBbiBFcnIgaGFzIGJlZW4gdGhyb3duIGJ1dCBub3QgY2F0Y2hlZGAsIHsgY2F1c2U6IHRoaXMgfSkpOwogICAgfQogICAgLyoqCiAgICAgKiBHZXQgdGhlIGlubmVyIHZhbHVlIG9yIHRocm93IHRoZSBpbm5lciBlcnJvciB3cmFwcGVkIGluc2lkZSBhbm90aGVyIEVycm9yCiAgICAgKiBAcGFyYW0gbWVzc2FnZQogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBPa2AsIGBFcnJvcihtZXNzYWdlLCB7IGNhdXNlOiB0aGlzLmlubmVyIH0pYCBpZiBgRXJyYAogICAgICovCiAgICBleHBlY3QobWVzc2FnZSkgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgdGhyb3cgUGFuaWMuZnJvbShuZXcgRXJyb3IobWVzc2FnZSwgeyBjYXVzZTogdGhpcyB9KSk7CiAgICB9CiAgICAvKioKICAgICAqIEdldCB0aGUgaW5uZXIgZXJyb3Igb3IgdGhyb3cgdGhlIGlubmVyIHZhbHVlIHdyYXBwZWQgaW5zaWRlIGFub3RoZXIgRXJyb3IKICAgICAqIEBwYXJhbSBtZXNzYWdlCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAgaWYgYEVycmAsIGBFcnJvcihtZXNzYWdlLCB7IGNhdXNlOiB0aGlzLmlubmVyIH0pYCBpZiBgT2tgCiAgICAgKi8KICAgIGV4cGVjdEVycihtZXNzYWdlKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gdGhpcy5pbm5lcjsKICAgIH0KICAgIC8qKgogICAgICogR2V0IHRoZSBpbm5lciB2YWx1ZSBvciBwYW5pYwogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBPa2AKICAgICAqIEB0aHJvd3MgYHRoaXMuaW5uZXJgIGlmIGBFcnJgCiAgICAgKi8KICAgIHVud3JhcCgpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHRocm93IG5ldyBQYW5pYyhuZXcgRXJyb3IoYEFuIEVyciBoYXMgYmVlbiB1bndyYXBwZWRgLCB7IGNhdXNlOiB0aGlzIH0pKTsKICAgIH0KICAgIC8qKgogICAgICogR2V0IHRoZSBpbm5lciBlcnJvciBvciBwYW5pYwogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBFcnJgCiAgICAgKiBAdGhyb3dzIGB0aGlzLmlubmVyYCBpZiBgT2tgCiAgICAgKi8KICAgIHVud3JhcEVycigpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiB0aGlzLmlubmVyOwogICAgfQogICAgLyoqCiAgICAgKiBHZXQgdGhlIGlubmVyIHZhbHVlIG9yIGEgZGVmYXVsdCBvbmUKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBPa2AsIGB2YWx1ZWAgaWYgYEVycmAKICAgICAqLwogICAgdW53cmFwT3IodmFsdWUpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiB2YWx1ZTsKICAgIH0KICAgIC8qKgogICAgICogR2V0IHRoZSBpbm5lciB2YWx1ZSBvciBjb21wdXRlIGEgZGVmYXVsdCBvbmUgZnJvbSB0aGUgaW5uZXIgZXJyb3IKICAgICAqIEBwYXJhbSBlcnJNYXBwZXIKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgT2tgLCBgYXdhaXQgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgRXJyYAogICAgICogQHRocm93cyBpZiBgYXdhaXQgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgYXN5bmMgdW53cmFwT3JFbHNlKGVyck1hcHBlcikgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIGF3YWl0IGVyck1hcHBlcih0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogR2V0IHRoZSBpbm5lciB2YWx1ZSBvciBjb21wdXRlIGEgZGVmYXVsdCBvbmUgZnJvbSB0aGUgaW5uZXIgZXJyb3IKICAgICAqIEBwYXJhbSBlcnJNYXBwZXIKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgT2tgLCBgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgRXJyYAogICAgICogQHRocm93cyBpZiBgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgdW53cmFwT3JFbHNlU3luYyhlcnJNYXBwZXIpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiBlcnJNYXBwZXIodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBSZXN1bHQ8UHJvbWlzZTxUPiwgRT4gaW50byBQcm9taXNlPFJlc3VsdDxULCBFPj4KICAgICAqIEByZXR1cm5zIGBhd2FpdCB0aGlzLmlubmVyYCBpZiBgT2tgLCBgdGhpc2AgaWYgYEVycmAKICAgICAqLwogICAgYXN5bmMgYXdhaXQoKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBSZXN1bHQ8VCwgUHJvbWlzZTxFPj4gaW50byBQcm9taXNlPFJlc3VsdDxULCBFPj4KICAgICAqIEByZXR1cm5zIGBhd2FpdCB0aGlzLmlubmVyYCBpZiBgRXJyYCwgYHRoaXNgIGlmIGBPa2AKICAgICAqLwogICAgYXN5bmMgYXdhaXRFcnIoKSB7CiAgICAgICAgcmV0dXJuIG5ldyBFcnIoYXdhaXQgdGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBSZXN1bHQ8UHJvbWlzZTxUPiwgUHJvbWlzZTxFPj4gaW50byBQcm9taXNlPFJlc3VsdDxULCBFPj4KICAgICAqIEByZXR1cm5zIGBhd2FpdCB0aGlzLmlubmVyYAogICAgICovCiAgICBhc3luYyBhd2FpdEFsbCgpIHsKICAgICAgICByZXR1cm4gYXdhaXQgdGhpcy5hd2FpdEVycigpOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm0gYFJlc3VsdDxULCBFPmAgaW50byBgUmVzdWx0PHZvaWQsIEU+YAogICAgICogQHJldHVybnMgYE9rPHZvaWQ+YCBpZiBgT2s8VD5gLCBgRXJyPEU+YCBpZiBgRTxFPmAKICAgICAqLwogICAgY2xlYXIoKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBgUmVzdWx0PFQsIEU+YCBpbnRvIGBSZXN1bHQ8VCwgdm9pZD5gCiAgICAgKiBAcmV0dXJucyBgT2s8VD5gIGlmIGBPazxUPmAsIGBFcnI8dm9pZD5gIGlmIGBFPEU+YAogICAgICovCiAgICBjbGVhckVycigpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiBFcnIudm9pZCgpOwogICAgfQogICAgLyoqCiAgICAgKiBDYWxscyB0aGUgZ2l2ZW4gY2FsbGJhY2sgd2l0aCB0aGUgaW5uZXIgdmFsdWUgaWYgYE9rYAogICAgICogQHBhcmFtIG9rQ2FsbGJhY2sKICAgICAqIEByZXR1cm5zIGB0aGlzYAogICAgICovCiAgICBhc3luYyBpbnNwZWN0KG9rQ2FsbGJhY2spIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogQ2FsbHMgdGhlIGdpdmVuIGNhbGxiYWNrIHdpdGggdGhlIGlubmVyIHZhbHVlIGlmIGBPa2AKICAgICAqIEBwYXJhbSBva0NhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgdGhpc2AKICAgICAqLwogICAgaW5zcGVjdFN5bmMob2tDYWxsYmFjaykgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBDYWxscyB0aGUgZ2l2ZW4gY2FsbGJhY2sgd2l0aCB0aGUgaW5uZXIgdmFsdWUgaWYgYEVycmAKICAgICAqIEBwYXJhbSBlcnJDYWxsYmFjawogICAgICogQHJldHVybnMgYHRoaXNgCiAgICAgKi8KICAgIGFzeW5jIGluc3BlY3RFcnIoZXJyQ2FsbGJhY2spIHsKICAgICAgICBhd2FpdCBlcnJDYWxsYmFjayh0aGlzLmlubmVyKTsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogQ2FsbHMgdGhlIGdpdmVuIGNhbGxiYWNrIHdpdGggdGhlIGlubmVyIHZhbHVlIGlmIGBFcnJgCiAgICAgKiBAcGFyYW0gZXJyQ2FsbGJhY2sKICAgICAqIEByZXR1cm5zIGB0aGlzYAogICAgICovCiAgICBpbnNwZWN0RXJyU3luYyhlcnJDYWxsYmFjaykgewogICAgICAgIGVyckNhbGxiYWNrKHRoaXMuaW5uZXIpOwogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm4gYSBuZXcgYE9rYCBidXQgd2l0aCB0aGUgZ2l2ZW4gYGlubmVyYAogICAgICogQHBhcmFtIGlubmVyCiAgICAgKiBAcmV0dXJucyBgT2soaW5uZXIpYCBpZiBgT2tgLCBgdGhpc2AgaWYgYEVycmAKICAgICAqLwogICAgc2V0KGlubmVyKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybiBhIG5ldyBgRXJyYCBidXQgd2l0aCB0aGUgZ2l2ZW4gYGlubmVyYAogICAgICogQHBhcmFtIGlubmVyCiAgICAgKiBAcmV0dXJucyBgRXJyKGlubmVyKWAgaWYgYEVycmAsIGB0aGlzYCBpZiBgT2tgCiAgICAgKi8KICAgIHNldEVycihpbm5lcikgewogICAgICAgIHJldHVybiBuZXcgRXJyKGlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogTWFwIHRoZSBpbm5lciB2YWx1ZSBpbnRvIGFub3RoZXIKICAgICAqIEBwYXJhbSBva01hcHBlcgogICAgICogQHJldHVybnMgYE9rKGF3YWl0IG9rTWFwcGVyKHRoaXMuaW5uZXIpKWAgaWYgYE9rYCwgYHRoaXNgIGlmIGBFcnJgCiAgICAgKiBAdGhyb3dzIGlmIGBhd2FpdCBva01hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIGFzeW5jIG1hcChva01hcHBlcikgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBNYXAgdGhlIGlubmVyIHZhbHVlIGludG8gYW5vdGhlcgogICAgICogQHBhcmFtIG9rTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgT2sob2tNYXBwZXIodGhpcy5pbm5lcikpYCBpZiBgT2tgLCBgdGhpc2AgaWYgYEVycmAKICAgICAqIEB0aHJvd3MgaWYgYG9rTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgbWFwU3luYyhva01hcHBlcikgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBNYXAgdGhlIGlubmVyIGVycm9yIGludG8gYW5vdGhlcgogICAgICogQHBhcmFtIGVyck1hcHBlcgogICAgICogQHJldHVybnMgYEVycihhd2FpdCBlcnJNYXBwZXIodGhpcy5pbm5lcikpYCBpZiBgRXJyYCwgYHRoaXNgIGlmIGBPa2AKICAgICAqIEB0aHJvd3MgaWYgYGF3YWl0IGVyck1hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIGFzeW5jIG1hcEVycihlcnJNYXBwZXIpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiBuZXcgRXJyKGF3YWl0IGVyck1hcHBlcih0aGlzLmlubmVyKSk7CiAgICB9CiAgICAvKioKICAgICAqIE1hcCB0aGUgaW5uZXIgZXJyb3IgaW50byBhbm90aGVyCiAgICAgKiBAcGFyYW0gZXJyTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgRXJyKGVyck1hcHBlcih0aGlzLmlubmVyKSlgIGlmIGBFcnJgLCBgdGhpc2AgaWYgYE9rYAogICAgICogQHRocm93cyBpZiBgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgbWFwRXJyU3luYyhlcnJNYXBwZXIpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiBuZXcgRXJyKGVyck1hcHBlcih0aGlzLmlubmVyKSk7CiAgICB9CiAgICAvKioKICAgICAqIE1hcCB0aGUgaW5uZXIgdmFsdWUgaW50byBhbm90aGVyLCBvciBhIGRlZmF1bHQgb25lCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEBwYXJhbSBva01hcHBlcgogICAgICogQHJldHVybnMgYGF3YWl0IG9rTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgT2tgLCBgdmFsdWVgIGlmIGBFcnJgCiAgICAgKiBAdGhyb3dzIGlmIGBhd2FpdCBva01hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIGFzeW5jIG1hcE9yKHZhbHVlLCBva01hcHBlcikgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIHZhbHVlOwogICAgfQogICAgLyoqCiAgICAgKiBNYXAgdGhlIGlubmVyIHZhbHVlIGludG8gYW5vdGhlciwgb3IgYSBkZWZhdWx0IG9uZQogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcGFyYW0gb2tNYXBwZXIKICAgICAqIEByZXR1cm5zIGBva01hcHBlcih0aGlzLmlubmVyKWAgaWYgYE9rYCwgYHZhbHVlYCBpZiBgRXJyYAogICAgICogQHRocm93cyBpZiBgb2tNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICBtYXBPclN5bmModmFsdWUsIG9rTWFwcGVyKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gdmFsdWU7CiAgICB9CiAgICAvKioKICAgICAqIE1hcCB0aGUgaW5uZXIgdmFsdWUgaW50byBhbm90aGVyLCBvciBhIGRlZmF1bHQgb25lCiAgICAgKiBAcGFyYW0gZXJyTWFwcGVyCiAgICAgKiBAcGFyYW0gb2tNYXBwZXIKICAgICAqIEByZXR1cm5zIGBhd2FpdCBva01hcHBlcih0aGlzLmlubmVyKWAgaWYgYE9rYCwgYGF3YWl0IGVyck1hcHBlcih0aGlzLmlubmVyKWAgaWYgYEVycmAKICAgICAqIEB0aHJvd3MgaWYgYGF3YWl0IG9rTWFwcGVyKHRoaXMuaW5uZXIpYCBvciBgYXdhaXQgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgYXN5bmMgbWFwT3JFbHNlKGVyck1hcHBlciwgb2tNYXBwZXIpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiBhd2FpdCBlcnJNYXBwZXIodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIE1hcCB0aGUgaW5uZXIgdmFsdWUgaW50byBhbm90aGVyLCBvciBhIGRlZmF1bHQgb25lCiAgICAgKiBAcGFyYW0gZXJyTWFwcGVyCiAgICAgKiBAcGFyYW0gb2tNYXBwZXIKICAgICAqIEByZXR1cm5zIGBva01hcHBlcih0aGlzLmlubmVyKWAgaWYgYE9rYCwgYGVyck1hcHBlcih0aGlzLmlubmVyKWAgaWYgYEVycmAKICAgICAqIEB0aHJvd3MgaWYgYG9rTWFwcGVyKHRoaXMuaW5uZXIpYCBvciBgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgbWFwT3JFbHNlU3luYyhlcnJNYXBwZXIsIG9rTWFwcGVyKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gZXJyTWFwcGVyKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm4gYHZhbHVlYCBpZiBgT2tgLCByZXR1cm4gYHRoaXNgIGlmIGBFcnJgCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEByZXR1cm5zIGB2YWx1ZWAgaWYgYE9rYCwgYHRoaXNgIGlmIGBFcnJgCiAgICAgKi8KICAgIGFuZCh2YWx1ZSkgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm4gYGF3YWl0IG9rTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgT2tgLCByZXR1cm4gYHRoaXNgIGlmIGBFcnJgCiAgICAgKiBAcGFyYW0gb2tNYXBwZXIKICAgICAqIEByZXR1cm5zIGBhd2FpdCBva01hcHBlcih0aGlzLmlubmVyKWAgaWYgYE9rYCwgYHRoaXNgIGlmIGBFcnJgCiAgICAgKiBAdGhyb3dzIGlmIGBhd2FpdCBva01hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIGFzeW5jIGFuZFRoZW4ob2tNYXBwZXIpIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJuIGBva01hcHBlcih0aGlzLmlubmVyKWAgaWYgYE9rYCwgcmV0dXJuIGB0aGlzYCBpZiBgRXJyYAogICAgICogQHBhcmFtIG9rTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgb2tNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBPa2AsIGB0aGlzYCBpZiBgRXJyYAogICAgICogQHRocm93cyBpZiBgb2tNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICBhbmRUaGVuU3luYyhva01hcHBlcikgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm4gYHZhbHVlYCBpZiBgRXJyYCwgcmV0dXJuIGB0aGlzYCBpZiBgT2tgCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEByZXR1cm5zIGB2YWx1ZWAgaWYgYEVycmAsIGB0aGlzYCBpZiBgT2tgCiAgICAgKi8KICAgIG9yKHZhbHVlKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gdmFsdWU7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybiBgYXdhaXQgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgRXJyYCwgcmV0dXJuIGB0aGlzYCBpZiBgT2tgCiAgICAgKiBAcGFyYW0gZXJyTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgYXdhaXQgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgRXJyYCwgYHRoaXNgIGlmIGBPa2AKICAgICAqIEB0aHJvd3MgaWYgYGF3YWl0IGVyck1hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIGFzeW5jIG9yRWxzZShlcnJNYXBwZXIpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiBhd2FpdCBlcnJNYXBwZXIodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybiBgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgRXJyYCwgcmV0dXJuIGB0aGlzYCBpZiBgT2tgCiAgICAgKiBAcGFyYW0gZXJyTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgRXJyYCwgYHRoaXNgIGlmIGBPa2AKICAgICAqIEB0aHJvd3MgaWYgYGVyck1hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIG9yRWxzZVN5bmMoZXJyTWFwcGVyKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gZXJyTWFwcGVyKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm0gUmVzdWx0PFJlc3VsdDxULCBFMT4sIEUyPiBpbnRvIFJlc3VsdDxULCBFMSB8IEUyPgogICAgICogQHBhcmFtIHJlc3VsdAogICAgICogQHJldHVybnMgYHRoaXNgIGlmIGBFcnJgLCBgdGhpcy5pbm5lcmAgaWYgYE9rYAogICAgICovCiAgICBmbGF0dGVuKCkgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQp9CgoKLy8jIHNvdXJjZU1hcHBpbmdVUkw9ZXJyLm1qcy5tYXAKCjsvLyBDT05DQVRFTkFURUQgTU9EVUxFOiAuL25vZGVfbW9kdWxlcy9AaGF6YWU0MS9qc29ucnBjL2Rpc3QvZXNtL21vZHMvcnBjL2Vyci5tanMKCgpjbGFzcyBScGNFcnJvciBleHRlbmRzIEVycm9yIHsKICAgIGNvZGU7CiAgICBtZXNzYWdlOwogICAgZGF0YTsKICAgICNjbGFzcyA9IFJwY0Vycm9yOwogICAgbmFtZSA9IHRoaXMuI2NsYXNzLm5hbWU7CiAgICBzdGF0aWMgY29kZXMgPSB7CiAgICAgICAgUGFyc2VFcnJvcjogLTMyNzAwLAogICAgICAgIEludmFsaWRSZXF1ZXN0OiAtMzI2MDAsCiAgICAgICAgTWV0aG9kTm90Rm91bmQ6IC0zMjYwMSwKICAgICAgICBJbnZhbGlkUGFyYW1zOiAtMzI2MDIsCiAgICAgICAgSW50ZXJuYWxFcnJvcjogLTMyNjAzCiAgICB9OwogICAgc3RhdGljIG1lc3NhZ2VzID0gewogICAgICAgIFBhcnNlRXJyb3I6ICJQYXJzZSBlcnJvciIsCiAgICAgICAgSW52YWxpZFJlcXVlc3Q6ICJJbnZhbGlkIFJlcXVlc3QiLAogICAgICAgIE1ldGhvZE5vdEZvdW5kOiAiTWV0aG9kIG5vdCBmb3VuZCIsCiAgICAgICAgSW52YWxpZFBhcmFtczogIkludmFsaWQgcGFyYW1zIiwKICAgICAgICBJbnRlcm5hbEVycm9yOiAiSW50ZXJuYWwgZXJyb3IiLAogICAgICAgIFNlcnZlckVycm9yOiAiU2VydmVyIGVycm9yIgogICAgfTsKICAgIGNvbnN0cnVjdG9yKGNvZGUsIG1lc3NhZ2UsIGRhdGEgPSB1bmRlZmluZWQpIHsKICAgICAgICBzdXBlcihtZXNzYWdlKTsKICAgICAgICB0aGlzLmNvZGUgPSBjb2RlOwogICAgICAgIHRoaXMubWVzc2FnZSA9IG1lc3NhZ2U7CiAgICAgICAgdGhpcy5kYXRhID0gZGF0YTsKICAgIH0KICAgIHN0YXRpYyBmcm9tKGluaXQpIHsKICAgICAgICBjb25zdCB7IGNvZGUsIG1lc3NhZ2UsIGRhdGEgfSA9IGluaXQ7CiAgICAgICAgcmV0dXJuIG5ldyBScGNFcnJvcihjb2RlLCBtZXNzYWdlLCBkYXRhKTsKICAgIH0KICAgIHN0YXRpYyByZXdyYXAoZXJyb3IpIHsKICAgICAgICBpZiAoZXJyb3IgaW5zdGFuY2VvZiBScGNFcnJvcikKICAgICAgICAgICAgcmV0dXJuIGVycm9yOwogICAgICAgIGlmIChlcnJvciBpbnN0YW5jZW9mIEVycm9yKQogICAgICAgICAgICByZXR1cm4gbmV3IFJwY0Vycm9yKC0zMjYwMywgZXJyb3IubWVzc2FnZSk7CiAgICAgICAgcmV0dXJuIG5ldyBScGNFcnJvcigtMzI2MDMsICJBbiB1bmtub3duIGVycm9yIG9jY3VyZWQiKTsKICAgIH0KICAgIC8qKgogICAgICogVXNlZCBieSBKU09OLnN0cmluZ2lmeQogICAgICovCiAgICB0b0pTT04oKSB7CiAgICAgICAgY29uc3QgeyBjb2RlLCBtZXNzYWdlLCBkYXRhIH0gPSB0aGlzOwogICAgICAgIHJldHVybiB7IGNvZGUsIG1lc3NhZ2UsIGRhdGEgfTsKICAgIH0KfQpjbGFzcyBScGNQYXJzZUVycm9yIGV4dGVuZHMgUnBjRXJyb3IgewogICAgI2NsYXNzID0gUnBjUGFyc2VFcnJvcjsKICAgIG5hbWUgPSB0aGlzLiNjbGFzcy5uYW1lOwogICAgc3RhdGljIGNvZGUgPSBScGNFcnJvci5jb2Rlcy5QYXJzZUVycm9yOwogICAgc3RhdGljIG1lc3NhZ2UgPSBScGNFcnJvci5tZXNzYWdlcy5QYXJzZUVycm9yOwogICAgY29uc3RydWN0b3IoKSB7CiAgICAgICAgc3VwZXIoUnBjRXJyb3IuY29kZXMuUGFyc2VFcnJvciwgUnBjRXJyb3IubWVzc2FnZXMuUGFyc2VFcnJvcik7CiAgICB9Cn0KY2xhc3MgUnBjSW52YWxpZFJlcXVlc3RFcnJvciBleHRlbmRzIFJwY0Vycm9yIHsKICAgICNjbGFzcyA9IFJwY0ludmFsaWRSZXF1ZXN0RXJyb3I7CiAgICBuYW1lID0gdGhpcy4jY2xhc3MubmFtZTsKICAgIHN0YXRpYyBjb2RlID0gUnBjRXJyb3IuY29kZXMuSW52YWxpZFJlcXVlc3Q7CiAgICBzdGF0aWMgbWVzc2FnZSA9IFJwY0Vycm9yLm1lc3NhZ2VzLkludmFsaWRSZXF1ZXN0OwogICAgY29uc3RydWN0b3IoKSB7CiAgICAgICAgc3VwZXIoUnBjRXJyb3IuY29kZXMuSW52YWxpZFJlcXVlc3QsIFJwY0Vycm9yLm1lc3NhZ2VzLkludmFsaWRSZXF1ZXN0KTsKICAgIH0KfQpjbGFzcyBScGNNZXRob2ROb3RGb3VuZEVycm9yIGV4dGVuZHMgUnBjRXJyb3IgewogICAgI2NsYXNzID0gUnBjTWV0aG9kTm90Rm91bmRFcnJvcjsKICAgIG5hbWUgPSB0aGlzLiNjbGFzcy5uYW1lOwogICAgc3RhdGljIGNvZGUgPSBScGNFcnJvci5jb2Rlcy5NZXRob2ROb3RGb3VuZDsKICAgIHN0YXRpYyBtZXNzYWdlID0gUnBjRXJyb3IubWVzc2FnZXMuTWV0aG9kTm90Rm91bmQ7CiAgICBjb25zdHJ1Y3RvcigpIHsKICAgICAgICBzdXBlcihScGNFcnJvci5jb2Rlcy5NZXRob2ROb3RGb3VuZCwgUnBjRXJyb3IubWVzc2FnZXMuTWV0aG9kTm90Rm91bmQpOwogICAgfQp9CmNsYXNzIFJwY0ludmFsaWRQYXJhbXNFcnJvciBleHRlbmRzIFJwY0Vycm9yIHsKICAgICNjbGFzcyA9IFJwY0ludmFsaWRQYXJhbXNFcnJvcjsKICAgIG5hbWUgPSB0aGlzLiNjbGFzcy5uYW1lOwogICAgc3RhdGljIGNvZGUgPSBScGNFcnJvci5jb2Rlcy5JbnZhbGlkUGFyYW1zOwogICAgc3RhdGljIG1lc3NhZ2UgPSBScGNFcnJvci5tZXNzYWdlcy5JbnZhbGlkUGFyYW1zOwogICAgY29uc3RydWN0b3IoKSB7CiAgICAgICAgc3VwZXIoUnBjRXJyb3IuY29kZXMuSW52YWxpZFBhcmFtcywgUnBjRXJyb3IubWVzc2FnZXMuSW52YWxpZFBhcmFtcyk7CiAgICB9Cn0KY2xhc3MgUnBjSW50ZXJuYWxFcnJvciBleHRlbmRzIFJwY0Vycm9yIHsKICAgICNjbGFzcyA9IFJwY0ludGVybmFsRXJyb3I7CiAgICBuYW1lID0gdGhpcy4jY2xhc3MubmFtZTsKICAgIHN0YXRpYyBjb2RlID0gUnBjRXJyb3IuY29kZXMuSW50ZXJuYWxFcnJvcjsKICAgIHN0YXRpYyBtZXNzYWdlID0gUnBjRXJyb3IubWVzc2FnZXMuSW50ZXJuYWxFcnJvcjsKICAgIGNvbnN0cnVjdG9yKCkgewogICAgICAgIHN1cGVyKFJwY0Vycm9yLmNvZGVzLkludGVybmFsRXJyb3IsIFJwY0Vycm9yLm1lc3NhZ2VzLkludGVybmFsRXJyb3IpOwogICAgfQp9CmNsYXNzIFJwY0VyciBleHRlbmRzIEVyciB7CiAgICBpZDsKICAgIGVycm9yOwogICAganNvbnJwYyA9ICIyLjAiOwogICAgY29uc3RydWN0b3IoaWQsIGVycm9yKSB7CiAgICAgICAgc3VwZXIoZXJyb3IpOwogICAgICAgIHRoaXMuaWQgPSBpZDsKICAgICAgICB0aGlzLmVycm9yID0gZXJyb3I7CiAgICB9CiAgICBzdGF0aWMgZnJvbShpbml0KSB7CiAgICAgICAgcmV0dXJuIG5ldyBScGNFcnIoaW5pdC5pZCwgUnBjRXJyb3IuZnJvbShpbml0LmVycm9yKSk7CiAgICB9CiAgICBzdGF0aWMgcmV3cmFwKGlkLCByZXN1bHQpIHsKICAgICAgICByZXR1cm4gbmV3IFJwY0VycihpZCwgUnBjRXJyb3IucmV3cmFwKHJlc3VsdC5pbm5lcikpOwogICAgfQp9CgoKLy8jIHNvdXJjZU1hcHBpbmdVUkw9ZXJyLm1qcy5tYXAKCjsvLyBDT05DQVRFTkFURUQgTU9EVUxFOiAuL25vZGVfbW9kdWxlcy9AaGF6YWU0MS9qc29ucnBjL2Rpc3QvZXNtL21vZHMvcnBjL29rLm1qcwoKCnZhciBScGNPa0luaXQ7CihmdW5jdGlvbiAoUnBjT2tJbml0KSB7CiAgICBmdW5jdGlvbiBmcm9tKHJlc3BvbnNlKSB7CiAgICAgICAgY29uc3QgeyBqc29ucnBjLCBpZCwgcmVzdWx0IH0gPSByZXNwb25zZTsKICAgICAgICByZXR1cm4geyBqc29ucnBjLCBpZCwgcmVzdWx0IH07CiAgICB9CiAgICBScGNPa0luaXQuZnJvbSA9IGZyb207Cn0pKFJwY09rSW5pdCB8fCAoUnBjT2tJbml0ID0ge30pKTsKY2xhc3MgUnBjT2sgZXh0ZW5kcyBPayB7CiAgICBpZDsKICAgIHJlc3VsdDsKICAgIGpzb25ycGMgPSAiMi4wIjsKICAgIGNvbnN0cnVjdG9yKGlkLCByZXN1bHQpIHsKICAgICAgICBzdXBlcihyZXN1bHQpOwogICAgICAgIHRoaXMuaWQgPSBpZDsKICAgICAgICB0aGlzLnJlc3VsdCA9IHJlc3VsdDsKICAgIH0KICAgIHN0YXRpYyBmcm9tKGluaXQpIHsKICAgICAgICByZXR1cm4gbmV3IFJwY09rKGluaXQuaWQsIGluaXQucmVzdWx0KTsKICAgIH0KICAgIHN0YXRpYyByZXdyYXAoaWQsIHJlc3VsdCkgewogICAgICAgIHJldHVybiBuZXcgUnBjT2soaWQsIHJlc3VsdC5pbm5lcik7CiAgICB9Cn0KCgovLyMgc291cmNlTWFwcGluZ1VSTD1vay5tanMubWFwCgo7Ly8gQ09OQ0FURU5BVEVEIE1PRFVMRTogLi9ub2RlX21vZHVsZXMvQGhhemFlNDEvanNvbnJwYy9kaXN0L2VzbS9tb2RzL3JwYy9yZXNwb25zZS5tanMKCgoKdmFyIFJwY1Jlc3BvbnNlOwooZnVuY3Rpb24gKFJwY1Jlc3BvbnNlKSB7CiAgICBmdW5jdGlvbiBmcm9tKGluaXQpIHsKICAgICAgICBpZiAoImVycm9yIiBpbiBpbml0KQogICAgICAgICAgICByZXR1cm4gUnBjRXJyLmZyb20oaW5pdCk7CiAgICAgICAgcmV0dXJuIFJwY09rLmZyb20oaW5pdCk7CiAgICB9CiAgICBScGNSZXNwb25zZS5mcm9tID0gZnJvbTsKICAgIGZ1bmN0aW9uIHJld3JhcChpZCwgcmVzdWx0KSB7CiAgICAgICAgaWYgKHJlc3VsdC5pc0VycigpKQogICAgICAgICAgICByZXR1cm4gUnBjRXJyLnJld3JhcChpZCwgcmVzdWx0KTsKICAgICAgICByZXR1cm4gUnBjT2sucmV3cmFwKGlkLCByZXN1bHQpOwogICAgfQogICAgUnBjUmVzcG9uc2UucmV3cmFwID0gcmV3cmFwOwp9KShScGNSZXNwb25zZSB8fCAoUnBjUmVzcG9uc2UgPSB7fSkpOwoKCi8vIyBzb3VyY2VNYXBwaW5nVVJMPXJlc3BvbnNlLm1qcy5tYXAKCjsvLyBDT05DQVRFTkFURUQgTU9EVUxFOiAuL25vZGVfbW9kdWxlcy9AaGF6YWU0MS9qc29ucnBjL2Rpc3QvZXNtL21vZHMvcnBjL3JlcXVlc3QubWpzCmNsYXNzIFJwY1JlcXVlc3QgewogICAgaWQ7CiAgICBtZXRob2Q7CiAgICBwYXJhbXM7CiAgICBqc29ucnBjID0gIjIuMCI7CiAgICBjb25zdHJ1Y3RvcihpZCwgbWV0aG9kLCBwYXJhbXMpIHsKICAgICAgICB0aGlzLmlkID0gaWQ7CiAgICAgICAgdGhpcy5tZXRob2QgPSBtZXRob2Q7CiAgICAgICAgdGhpcy5wYXJhbXMgPSBwYXJhbXM7CiAgICB9CiAgICBzdGF0aWMgZnJvbShpbml0KSB7CiAgICAgICAgY29uc3QgeyBpZCwgbWV0aG9kLCBwYXJhbXMgfSA9IGluaXQ7CiAgICAgICAgcmV0dXJuIG5ldyBScGNSZXF1ZXN0KGlkLCBtZXRob2QsIHBhcmFtcyk7CiAgICB9CiAgICB0b0pTT04oKSB7CiAgICAgICAgY29uc3QgeyBqc29ucnBjLCBpZCwgbWV0aG9kLCBwYXJhbXMgfSA9IHRoaXM7CiAgICAgICAgcmV0dXJuIHsganNvbnJwYywgaWQsIG1ldGhvZCwgcGFyYW1zIH07CiAgICB9Cn0KCgovLyMgc291cmNlTWFwcGluZ1VSTD1yZXF1ZXN0Lm1qcy5tYXAKCjsvLyBDT05DQVRFTkFURUQgTU9EVUxFOiAuL25vZGVfbW9kdWxlcy9AaGF6YWU0MS9qc29ucnBjL2Rpc3QvZXNtL21vZHMvcnBjL3JwYy5tanMKCgpjbGFzcyBScGNDb3VudGVyIHsKICAgIGlkID0gMDsKICAgIHByZXBhcmUoaW5pdCkgewogICAgICAgIHJldHVybiBuZXcgUnBjUmVxdWVzdCh0aGlzLmlkKyssIGluaXQubWV0aG9kLCBpbml0LnBhcmFtcyk7CiAgICB9Cn0KCgovLyMgc291cmNlTWFwcGluZ1VSTD1ycGMubWpzLm1hcAoKOy8vIENPTkNBVEVOQVRFRCBNT0RVTEU6IC4vc3JjL21vZHMvYmFja2dyb3VuZC9pbmplY3RlZF9zY3JpcHQvaW5kZXgudHMKCgoKCgoKY29uc3QgaWNvbiA9IG5ldyBGdXR1cmUoKTsKY29uc3Qgb25Mb2dvID0gKGV2ZW50KT0+ewogICAgaWNvbi5yZXNvbHZlKEpTT04ucGFyc2UoZXZlbnQuZGV0YWlsKSk7Cn07CndpbmRvdy5hZGRFdmVudExpc3RlbmVyKCJicnVtZSNpY29uIiwgb25Mb2dvLCB7CiAgICBwYXNzaXZlOiB0cnVlLAogICAgb25jZTogdHJ1ZQp9KTsKdmFyIF9jb3VudGVyID0gLyojX19QVVJFX18qLyBuZXcgV2Vha01hcCgpLCBfbGlzdGVuZXJzID0gLyojX19QVVJFX18qLyBuZXcgV2Vha01hcCgpOwpjbGFzcyBQcm92aWRlciB7CiAgICBnZXQgaXNCcnVtZSgpIHsKICAgICAgICByZXR1cm4gdHJ1ZTsKICAgIH0KICAgIGlzQ29ubmVjdGVkKCkgewogICAgICAgIHJldHVybiB0cnVlOwogICAgfQogICAgYXN5bmMgZW5hYmxlKCkgewogICAgICAgIC8qKgogICAgICAgICAqIENvbXBhdGliaWxpdHkgbW9kZQogICAgICAgICAqLyB0aGlzLmF1dG9SZWZyZXNoT25OZXR3b3JrQ2hhbmdlID0gdHJ1ZTsKICAgICAgICByZXR1cm4gYXdhaXQgdGhpcy5yZXF1ZXN0KHsKICAgICAgICAgICAgbWV0aG9kOiAiZXRoX3JlcXVlc3RBY2NvdW50cyIKICAgICAgICB9KTsKICAgIH0KICAgIGFzeW5jIHRyeVJlcXVlc3QoaW5pdCkgewogICAgICAgIGNvbnN0IHJlcXVlc3QgPSBfY2xhc3NfcHJpdmF0ZV9maWVsZF9nZXQodGhpcywgX2NvdW50ZXIpLnByZXBhcmUoaW5pdCk7CiAgICAgICAgY29uc3QgZnV0dXJlID0gbmV3IEZ1dHVyZSgpOwogICAgICAgIGNvbnN0IG9uUmVzcG9uc2UgPSAoZSk9PnsKICAgICAgICAgICAgY29uc3QgaW5pdCA9IEpTT04ucGFyc2UoZS5kZXRhaWwpOwogICAgICAgICAgICBpZiAoaW5pdC5pZCAhPT0gcmVxdWVzdC5pZCkgcmV0dXJuOwogICAgICAgICAgICBjb25zdCByZXNwb25zZSA9IFJwY1Jlc3BvbnNlLmZyb20oaW5pdCk7CiAgICAgICAgICAgIGZ1dHVyZS5yZXNvbHZlKHJlc3BvbnNlKTsKICAgICAgICB9OwogICAgICAgIHRyeSB7CiAgICAgICAgICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCJldGhlcmV1bSNyZXNwb25zZSIsIG9uUmVzcG9uc2UpOwogICAgICAgICAgICBjb25zdCBkZXRhaWwgPSBKU09OLnN0cmluZ2lmeShyZXF1ZXN0KTsKICAgICAgICAgICAgY29uc3QgZXZlbnQgPSBuZXcgQ3VzdG9tRXZlbnQoImV0aGVyZXVtI3JlcXVlc3QiLCB7CiAgICAgICAgICAgICAgICBkZXRhaWwKICAgICAgICAgICAgfSk7CiAgICAgICAgICAgIHdpbmRvdy5kaXNwYXRjaEV2ZW50KGV2ZW50KTsKICAgICAgICAgICAgcmV0dXJuIGF3YWl0IGZ1dHVyZS5wcm9taXNlOwogICAgICAgIH0gZmluYWxseXsKICAgICAgICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoImV0aGVyZXVtI3Jlc3BvbnNlIiwgb25SZXNwb25zZSk7CiAgICAgICAgfQogICAgfQogICAgYXN5bmMgcmVxdWVzdChpbml0KSB7CiAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgdGhpcy50cnlSZXF1ZXN0KGluaXQpOwogICAgICAgIGlmIChyZXN1bHQuaXNFcnIoKSkgdGhyb3cgcmVzdWx0LmlubmVyOwogICAgICAgIHJldHVybiByZXN1bHQuaW5uZXI7CiAgICB9CiAgICBvbihrZXksIHN1Ymxpc3RlbmVyKSB7CiAgICAgICAgbGV0IGxpc3RlbmVycyA9IF9jbGFzc19wcml2YXRlX2ZpZWxkX2dldCh0aGlzLCBfbGlzdGVuZXJzKS5nZXQoa2V5KTsKICAgICAgICBpZiAobGlzdGVuZXJzID09IG51bGwpIHsKICAgICAgICAgICAgbGlzdGVuZXJzID0gbmV3IE1hcCgpOwogICAgICAgICAgICBfY2xhc3NfcHJpdmF0ZV9maWVsZF9nZXQodGhpcywgX2xpc3RlbmVycykuc2V0KGtleSwgbGlzdGVuZXJzKTsKICAgICAgICB9CiAgICAgICAgbGV0IHN1cGxpc3RlbmVyID0gbGlzdGVuZXJzLmdldChzdWJsaXN0ZW5lcik7CiAgICAgICAgaWYgKHN1cGxpc3RlbmVyID09IG51bGwpIHsKICAgICAgICAgICAgc3VwbGlzdGVuZXIgPSAoZSk9PnsKICAgICAgICAgICAgICAgIHN1Ymxpc3RlbmVyKEpTT04ucGFyc2UoZS5kZXRhaWwpKTsKICAgICAgICAgICAgfTsKICAgICAgICAgICAgbGlzdGVuZXJzLnNldChzdWJsaXN0ZW5lciwgc3VwbGlzdGVuZXIpOwogICAgICAgIH0KICAgICAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcigiZXRoZXJldW0jIi5jb25jYXQoa2V5KSwgc3VwbGlzdGVuZXIsIHsKICAgICAgICAgICAgcGFzc2l2ZTogdHJ1ZQogICAgICAgIH0pOwogICAgfQogICAgb25jZShrZXksIHN1Ymxpc3RlbmVyKSB7CiAgICAgICAgdmFyIF90aGlzID0gdGhpczsKICAgICAgICBjb25zdCBzdWJsaXN0ZW5lcjIgPSBmdW5jdGlvbigpIHsKICAgICAgICAgICAgZm9yKHZhciBfbGVuID0gYXJndW1lbnRzLmxlbmd0aCwgcGFyYW1zID0gbmV3IEFycmF5KF9sZW4pLCBfa2V5ID0gMDsgX2tleSA8IF9sZW47IF9rZXkrKyl7CiAgICAgICAgICAgICAgICBwYXJhbXNbX2tleV0gPSBhcmd1bWVudHNbX2tleV07CiAgICAgICAgICAgIH0KICAgICAgICAgICAgc3VibGlzdGVuZXIoLi4ucGFyYW1zKTsKICAgICAgICAgICAgX3RoaXMub2ZmKGtleSwgc3VibGlzdGVuZXIpOwogICAgICAgIH07CiAgICAgICAgdGhpcy5vbihrZXksIHN1Ymxpc3RlbmVyMik7CiAgICB9CiAgICBvZmYoa2V5LCBzdWJsaXN0ZW5lcikgewogICAgICAgIGNvbnN0IGxpc3RlbmVycyA9IF9jbGFzc19wcml2YXRlX2ZpZWxkX2dldCh0aGlzLCBfbGlzdGVuZXJzKS5nZXQoa2V5KTsKICAgICAgICBpZiAobGlzdGVuZXJzID09IG51bGwpIHJldHVybjsKICAgICAgICBjb25zdCBzdXBsaXN0ZW5lciA9IGxpc3RlbmVycy5nZXQoc3VibGlzdGVuZXIpOwogICAgICAgIGlmIChzdXBsaXN0ZW5lciA9PSBudWxsKSByZXR1cm47CiAgICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoImV0aGVyZXVtIyIuY29uY2F0KGtleSksIHN1cGxpc3RlbmVyKTsKICAgICAgICBsaXN0ZW5lcnMuZGVsZXRlKHN1Ymxpc3RlbmVyKTsKICAgICAgICBpZiAobGlzdGVuZXJzLnNpemUgIT09IDApIHJldHVybjsKICAgICAgICBfY2xhc3NfcHJpdmF0ZV9maWVsZF9nZXQodGhpcywgX2xpc3RlbmVycykuZGVsZXRlKGtleSk7CiAgICB9CiAgICBjb25zdHJ1Y3RvcigpewogICAgICAgIF9jbGFzc19wcml2YXRlX2ZpZWxkX2luaXQodGhpcywgX2NvdW50ZXIsIHsKICAgICAgICAgICAgd3JpdGFibGU6IHRydWUsCiAgICAgICAgICAgIHZhbHVlOiB2b2lkIDAKICAgICAgICB9KTsKICAgICAgICBfY2xhc3NfcHJpdmF0ZV9maWVsZF9pbml0KHRoaXMsIF9saXN0ZW5lcnMsIHsKICAgICAgICAgICAgd3JpdGFibGU6IHRydWUsCiAgICAgICAgICAgIHZhbHVlOiB2b2lkIDAKICAgICAgICB9KTsKICAgICAgICBfY2xhc3NfcHJpdmF0ZV9maWVsZF9zZXQodGhpcywgX2NvdW50ZXIsIG5ldyBScGNDb3VudGVyKCkpOwogICAgICAgIF9jbGFzc19wcml2YXRlX2ZpZWxkX3NldCh0aGlzLCBfbGlzdGVuZXJzLCBuZXcgTWFwKCkpOwogICAgICAgIC8qKgogICAgICogQGRlcHJlY2F0ZWQKICAgICAqLyB0aGlzLmF1dG9SZWZyZXNoT25OZXR3b3JrQ2hhbmdlID0gZmFsc2U7CiAgICAgICAgLyoqCiAgICAgICAgICogRml4IGZvciB0aGF0IHBvb3JseS1jb2RlZCBhcHAgdGhhdCBkb2VzIGBjb25zdCB7IHJlcXVlc3QgfSA9IHByb3ZpZGVyYAogICAgICAgICAqLyB0aGlzLnJlcXVlc3QgPSB0aGlzLnJlcXVlc3QuYmluZCh0aGlzKTsKICAgICAgICB0aGlzLm9uID0gdGhpcy5vbi5iaW5kKHRoaXMpOwogICAgICAgIHRoaXMub2ZmID0gdGhpcy5vZmYuYmluZCh0aGlzKTsKICAgICAgICAvKioKICAgICAgICAgKiBGaXggZm9yIE1ldGFNYXNrLWxpa2UKICAgICAgICAgKi8gdGhpcy5vbigiY2hhaW5DaGFuZ2VkIiwgKCk9PnsKICAgICAgICAgICAgaWYgKCF0aGlzLmF1dG9SZWZyZXNoT25OZXR3b3JrQ2hhbmdlKSByZXR1cm47CiAgICAgICAgICAgIGxvY2F0aW9uLnJlbG9hZCgpOwogICAgICAgIH0pOwogICAgfQp9CmNvbnN0IHByb3ZpZGVyID0gbmV3IFByb3ZpZGVyKCk7Ci8qKgogKiBFSVAxMTkzCiAqLyB3aW5kb3cuZXRoZXJldW0gPSBwcm92aWRlcjsKLyoqCiAqIEVJUDY5NjMKICovIHsKICAgIGFzeW5jIGZ1bmN0aW9uIGFubm91bmNlKCkgewogICAgICAgIGNvbnN0IGluZm8gPSBPYmplY3QuZnJlZXplKHsKICAgICAgICAgICAgdXVpZDogImU3NTBhOThjLWZmMmQtNGZjNC1iNmUyLWZhZjRkMTNkMWFkZCIsCiAgICAgICAgICAgIG5hbWU6ICJCcnVtZSBXYWxsZXQiLAogICAgICAgICAgICBpY29uOiBhd2FpdCBpY29uLnByb21pc2UsCiAgICAgICAgICAgIHJkbnM6ICJtb25leS5icnVtZSIKICAgICAgICB9KTsKICAgICAgICBjb25zdCBkZXRhaWwgPSBPYmplY3QuZnJlZXplKHsKICAgICAgICAgICAgaW5mbywKICAgICAgICAgICAgcHJvdmlkZXIKICAgICAgICB9KTsKICAgICAgICBjb25zdCBldmVudCA9IG5ldyBDdXN0b21FdmVudCgiZWlwNjk2Mzphbm5vdW5jZVByb3ZpZGVyIiwgewogICAgICAgICAgICBkZXRhaWwKICAgICAgICB9KTsKICAgICAgICB3aW5kb3cuZGlzcGF0Y2hFdmVudChldmVudCk7CiAgICB9CiAgICBmdW5jdGlvbiBvbkFubm91bmNlUmVxdWVzdChldmVudCkgewogICAgICAgIGFubm91bmNlKCk7CiAgICB9CiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcigiZWlwNjk2MzpyZXF1ZXN0UHJvdmlkZXIiLCBvbkFubm91bmNlUmVxdWVzdCwgewogICAgICAgIHBhc3NpdmU6IHRydWUKICAgIH0pOwogICAgYW5ub3VuY2UoKTsKfQovKioqKioqLyB9KSgpCjs=");
    const scriptUrl = browser.runtime.getURL("injected_script.js");
    const element = document.createElement("script");
    element.type = "text/javascript";
    element.textContent = "".concat(scriptBody, "\n//# sourceURL=").concat(scriptUrl);
    container.insertBefore(element, container.children[0]);
    container.removeChild(element);
}
async function tryGetOrigin() {
    const origin = {
        origin: location.origin,
        title: document.title
    };
    for (const meta of document.getElementsByTagName("meta")){
        if (meta.name === "application-name") {
            origin.title = meta.content;
            continue;
        }
    }
    for (const link of document.getElementsByTagName("link")){
        if ([
            "icon",
            "shortcut icon",
            "icon shortcut"
        ].includes(link.rel)) {
            const blob = await tryFetchAsBlob(link.href);
            if (blob.isErr()) continue;
            const data = await Blobs.tryReadAsDataURL(blob.inner);
            if (data.isErr()) continue;
            origin.icon = data.inner;
            continue;
        }
        if (link.rel === "manifest") {
            const manifest = await tryFetchAsJson(link.href);
            if (manifest.isErr()) continue;
            if (manifest.inner.name) origin.title = manifest.inner.name;
            if (manifest.inner.short_name) origin.title = manifest.inner.short_name;
            if (manifest.inner.description) origin.description = manifest.inner.description;
            continue;
        }
    }
    if (!origin.icon) {
        await (async ()=>{
            const blob = await tryFetchAsBlob("/favicon.ico");
            if (blob.isErr()) return;
            const data = await Blobs.tryReadAsDataURL(blob.inner);
            if (data.isErr()) return;
            origin.icon = data.inner;
        })();
    }
    return new ok_Ok(origin);
}
new Pool(async (params)=>{
    return Result.unthrow(async (t)=>{
        const { index, pool } = params;
        await new Promise((ok)=>setTimeout(ok, 1));
        const raw = await tryBrowser(async ()=>{
            const port = browser.runtime.connect({
                name: location.origin
            });
            port.onDisconnect.addListener(()=>void chrome.runtime.lastError);
            return port;
        }).then((r)=>r.throw(t));
        const port = new ExtensionPort("background", raw);
        {
            const icon = await port.tryRequest({
                method: "brume_icon"
            }).then((r)=>r.throw(t).throw(t));
            const detail = JSON.stringify(icon);
            const event = new CustomEvent("brume#icon", {
                detail
            });
            window.dispatchEvent(event);
        }
        const onScriptRequest = async (input)=>{
            const request = JSON.parse(input.detail);
            const result = await port.tryRequest({
                method: "brume_run",
                params: [
                    request,
                    mouse
                ]
            });
            const response = RpcResponse.rewrap(request.id, result.andThenSync((r)=>r));
            const detail = JSON.stringify(response);
            const output = new CustomEvent("ethereum#response", {
                detail
            });
            window.dispatchEvent(output);
        };
        window.addEventListener("ethereum#request", onScriptRequest, {
            passive: true
        });
        const onAccountsChanged = async (request)=>{
            const [accounts] = request.params;
            const detail = JSON.stringify(accounts);
            const event = new CustomEvent("ethereum#accountsChanged", {
                detail
            });
            window.dispatchEvent(event);
            return ok_Ok.void();
        };
        const onConnect = async (request)=>{
            const [{ chainId }] = request.params;
            const detail = JSON.stringify({
                chainId
            });
            const event = new CustomEvent("ethereum#connect", {
                detail
            });
            window.dispatchEvent(event);
            return ok_Ok.void();
        };
        const onChainChanged = async (request)=>{
            const [chainId] = request.params;
            const detail = JSON.stringify(chainId);
            const event = new CustomEvent("ethereum#chainChanged", {
                detail
            });
            window.dispatchEvent(event);
            return ok_Ok.void();
        };
        const onBackgroundRequest = async (request)=>{
            if (request.method === "brume_origin") return new Some(await tryGetOrigin());
            if (request.method === "connect") return new Some(await onConnect(request));
            if (request.method === "accountsChanged") return new Some(await onAccountsChanged(request));
            if (request.method === "chainChanged") return new Some(await onChainChanged(request));
            return new None();
        };
        port.events.on("request", onBackgroundRequest, {
            passive: true
        });
        const onClose = async ()=>{
            const event = new CustomEvent("ethereum#disconnect", {});
            window.dispatchEvent(event);
            await pool.restart(index);
            return new None();
        };
        port.events.on("close", onClose, {
            passive: true
        });
        const onClean = ()=>{
            window.removeEventListener("ethereum#request", onScriptRequest);
            port.events.off("close", onClose);
            port.clean();
            raw.disconnect();
        };
        return new ok_Ok(new Disposer(raw, onClean));
    });
}, {
    capacity: 1
});

/******/ })()
;