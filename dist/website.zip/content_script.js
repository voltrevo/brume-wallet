/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
var __webpack_exports__ = {};

;// CONCATENATED MODULE: ./node_modules/@hazae41/symbol-dispose-polyfill/dist/esm/mods/symbol-dispose-polyfill/polyfill.mjs
if (typeof Symbol.dispose !== "symbol")
    Object.defineProperty(Symbol, "dispose", {
        configurable: false,
        enumerable: false,
        writable: false,
        value: Symbol.for("dispose")
    });
if (typeof Symbol.asyncDispose !== "symbol")
    Object.defineProperty(Symbol, "asyncDispose", {
        configurable: false,
        enumerable: false,
        writable: false,
        value: Symbol.for("asyncDispose")
    });
//# sourceMappingURL=polyfill.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/symbol-dispose-polyfill/dist/esm/index.mjs

//# sourceMappingURL=index.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/future/dist/esm/mods/future/future.mjs
class Future {
    #resolve;
    #reject;
    promise;
    /**
     * Just like a Promise but you can manually resolve or reject it
     */
    constructor() {
        this.promise = new Promise((subresolve, subreject) => {
            this.#resolve = subresolve;
            this.#reject = subreject;
        });
    }
    get resolve() {
        return this.#resolve;
    }
    get reject() {
        return this.#reject;
    }
}


//# sourceMappingURL=future.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/option/dist/esm/mods/option/option.mjs



var Option;
(function (Option) {
    function from(init) {
        if ("inner" in init)
            return new Some(init.inner);
        return new None();
    }
    Option.from = from;
    /**
     * Create an Option from a nullable value
     * @param inner
     * @returns `Some<T>` if `T`, `None` if `undefined`
     */
    function wrap(inner) {
        if (inner == null)
            return new None();
        return new Some(inner);
    }
    Option.wrap = wrap;
    async function map(inner, mapper) {
        return Option.wrap(inner).map(mapper).then(o => o.get());
    }
    Option.map = map;
    function mapSync(inner, mapper) {
        return Option.wrap(inner).mapSync(mapper).get();
    }
    Option.mapSync = mapSync;
    function unwrap(inner) {
        return Option.wrap(inner).unwrap();
    }
    Option.unwrap = unwrap;
})(Option || (Option = {}));


//# sourceMappingURL=option.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/result.mjs





var Result;
(function (Result) {
    Result.debug = false;
    /**
     * Create a Result from a maybe Error value
     * @param inner
     * @returns `Ok<T>` if `T`, `Err<Error>` if `Error`
     */
    function from(inner) {
        if (inner instanceof Error)
            return new err_Err(inner);
        else
            return new ok_Ok(inner);
    }
    Result.from = from;
    /**
     * Create a Result from a boolean
     * @param value
     * @returns
     */
    function assert(value) {
        return value ? ok_Ok.void() : new err_Err(new AssertError());
    }
    Result.assert = assert;
    function rewrap(wrapper) {
        try {
            return new ok_Ok(wrapper.unwrap());
        }
        catch (error) {
            return new err_Err(error);
        }
    }
    Result.rewrap = rewrap;
    /**
     * Catch an Err thrown from Err.throw
     * @param callback
     * @param type
     * @returns `Ok<T>` if no `Err` was thrown, `Err<E>` otherwise
     * @see Err.throw
     */
    async function unthrow(callback) {
        let ref;
        try {
            return await callback((e) => ref = e);
        }
        catch (e) {
            if (ref !== undefined)
                return ref;
            throw e;
        }
    }
    Result.unthrow = unthrow;
    /**
     * Catch an Err thrown from Err.throw
     * @param callback
     * @param type
     * @returns `Ok<T>` if no `Err` was thrown, `Err<E>` otherwise
     * @see Err.throw
     */
    function unthrowSync(callback) {
        let ref;
        try {
            return callback((e) => ref = e);
        }
        catch (e) {
            if (ref !== undefined)
                return ref;
            throw e;
        }
    }
    Result.unthrowSync = unthrowSync;
    /**
     * Convert try-catch to Result<T, unknown>
     * @param callback
     * @returns
     */
    async function runAndWrap(callback) {
        try {
            return new ok_Ok(await callback());
        }
        catch (e) {
            return new err_Err(e);
        }
    }
    Result.runAndWrap = runAndWrap;
    /**
     * Convert try-catch to Result<T, unknown>
     * @param callback
     * @returns
     */
    function runAndWrapSync(callback) {
        try {
            return new ok_Ok(callback());
        }
        catch (e) {
            return new err_Err(e);
        }
    }
    Result.runAndWrapSync = runAndWrapSync;
    /**
     * Convert try-catch to Result<T, Catched>
     * @param callback
     * @returns
     */
    async function runAndDoubleWrap(callback) {
        return runAndWrap(callback).then(r => r.mapErrSync(errors_Catched.from));
    }
    Result.runAndDoubleWrap = runAndDoubleWrap;
    /**
     * Convert try-catch to Result<T, Catched>
     * @param callback
     * @returns
     */
    function runAndDoubleWrapSync(callback) {
        return runAndWrapSync(callback).mapErrSync(errors_Catched.from);
    }
    Result.runAndDoubleWrapSync = runAndDoubleWrapSync;
    /**
     * Transform Result<Result<T, E1>, E2> into Result<T, E1 | E2>
     * @param result
     * @returns `this` if `Err`, `this.inner` if `Ok`
     */
    function flatten(result) {
        if (result.isErr())
            return result;
        return result.get();
    }
    Result.flatten = flatten;
    /**
     * Transform `Iterable<Result<T,E>` into `Result<Array<T>, E>`
     * @param iterable
     * @returns `Result<Array<T>, E>`
     */
    function all(iterable) {
        return collect(iterate(iterable));
    }
    Result.all = all;
    function maybeAll(iterable) {
        return maybeCollect(maybeIterate(iterable));
    }
    Result.maybeAll = maybeAll;
    /**
     * Transform `Iterable<Result<T,E>` into `Iterator<T, Result<void, E>>`
     * @param iterable
     * @returns `Iterator<T, Result<void, E>>`
     */
    function* iterate(iterable) {
        for (const result of iterable) {
            if (result.isOk())
                yield result.get();
            else
                return result;
        }
        return ok_Ok.void();
    }
    Result.iterate = iterate;
    function* maybeIterate(iterable) {
        for (const result of iterable) {
            if (result == null)
                return result;
            else if (result.isOk())
                yield result.get();
            else
                return result;
        }
        return ok_Ok.void();
    }
    Result.maybeIterate = maybeIterate;
    /**
     * Transform `Iterator<T, Result<void, E>>` into `Result<Array<T>, E>`
     * @param iterator `Result<Array<T>, E>`
     */
    function collect(iterator) {
        const array = new Array();
        let result = iterator.next();
        for (; !result.done; result = iterator.next())
            array.push(result.value);
        return result.value.set(array);
    }
    Result.collect = collect;
    function maybeCollect(iterator) {
        const array = new Array();
        let result = iterator.next();
        for (; !result.done; result = iterator.next())
            array.push(result.value);
        return Option.mapSync(result.value, result => result.set(array));
    }
    Result.maybeCollect = maybeCollect;
    /**
     * Unwrap the callback but wrap thrown errors in Catched
     * @param callback
     * @returns `T` if `Ok`
     * @throws `Catched` if `callback()` throws, `E` if `Err`
     */
    async function runAndUnwrap(callback) {
        let result;
        try {
            result = await callback();
        }
        catch (e) {
            throw errors_Catched.from(e);
        }
        return result.unwrap();
    }
    Result.runAndUnwrap = runAndUnwrap;
    /**
     * Unwrap the callback but wrap thrown errors in Catched
     * @param callback
     * @returns `T` if `Ok`
     * @throws `Catched` if `callback()` throws, `E` if `Err`
     */
    function runAndUnwrapSync(callback) {
        let result;
        try {
            result = callback();
        }
        catch (e) {
            throw errors_Catched.from(e);
        }
        return result.unwrap();
    }
    Result.runAndUnwrapSync = runAndUnwrapSync;
})(Result || (Result = {}));


//# sourceMappingURL=result.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/err.mjs




class err_Err {
    #inner;
    #timeout;
    /**
     * A failure
     * @param inner
     */
    constructor(inner) {
        this.#inner = inner;
        if (!Result.debug)
            return;
        const error = Panic.from(new Error(`An Err has not been handled properly`, { cause: this }));
        this.#timeout = setTimeout(() => { throw error; }, 1000);
    }
    /**
     * Create an empty `Err`
     * @returns `Err(void)`
     */
    static void() {
        return new err_Err(undefined);
    }
    /**
     * Create an `Err`
     * @param inner
     * @returns `Err(inner)`
     */
    static new(inner) {
        return new err_Err(inner);
    }
    /**
     * Create an `Err` with an `Error` inside
     * @param message
     * @param options
     * @returns `Err<Error>`
     */
    static error(message, options) {
        return new err_Err(new Error(message, options));
    }
    get inner() {
        return this.#inner;
    }
    /**
     * Set this result as handled
     */
    ignore() {
        if (!this.#timeout)
            return this;
        clearTimeout(this.#timeout);
        this.#timeout = undefined;
        return this;
    }
    /**
     * Type guard for `Ok`
     * @returns `true` if `Ok`, `false` if `Err`
     */
    isOk() {
        return false;
    }
    /**
     * Returns true if the result is `Ok` and the value inside of it matches a predicate
     * @param okPredicate
     * @returns `true` if `Ok` and `await okPredicate(this.inner)`, `false` otherwise
     */
    async isOkAnd(okPredicate) {
        return false;
    }
    /**
     * Returns true if the result is `Ok` and the value inside of it matches a predicate
     * @param okPredicate
     * @returns `true` if `Ok` and `await okPredicate(this.inner)`, `false` otherwise
     */
    isOkAndSync(okPredicate) {
        return false;
    }
    /**
     * Type guard for `Err`
     * @returns `true` if `Err`, `false` if `Ok`
     */
    isErr() {
        return true;
    }
    /**
     * Returns true if the result is `Err` and the value inside of it matches a predicate
     * @param errPredicate
     * @returns `true` if `Err` and `await errPredicate(this.inner)`, `false` otherwise
     */
    async isErrAnd(errPredicate) {
        return await errPredicate(this.inner);
    }
    /**
     * Returns true if the result is `Err` and the value inside of it matches a predicate
     * @param errPredicate
     * @returns `true` if `Err` and `await errPredicate(this.inner)`, `false` otherwise
     */
    isErrAndSync(errPredicate) {
        return errPredicate(this.inner);
    }
    /**
     * Compile-time safely get `this.inner`
     * @returns `this.inner`
     */
    get() {
        this.ignore();
        return this.inner;
    }
    /**
     * Transform `Result<T, E>` into `Option<T>`
     * @returns `Some(this.inner)` if `Ok`, `None` if `Err`
     */
    ok() {
        this.ignore();
        return new None();
    }
    /**
     * Transform `Result<T, E>` into `Option<E>`
     * @returns `Some(this.inner)` if `Err`, `None` if `Ok`
     */
    err() {
        this.ignore();
        return new Some(this.inner);
    }
    /**
     * Returns an iterator over the possibly contained value
     * @yields `this.inner` if `Ok`
     */
    *[Symbol.iterator]() {
        this.ignore();
        return;
    }
    /**
     * Transform `Result<T,E>` into `[T,E]`
     * @returns `[this.inner, undefined]` if `Ok`, `[undefined, this.inner]` if `Err`
     */
    split() {
        this.ignore();
        return [undefined, this.inner];
    }
    /**
     * Returns true if the result is an `Ok` value containing the given value
     * @param value
     * @returns `true` if `Ok` and `this.inner === value`, `false` otherwise
     */
    contains(value) {
        return false;
    }
    /**
     * Returns true if the result is an `Err` value containing the given value
     * @param value
     * @returns `true` if `Err` and `this.inner === value`, `false` otherwise
     */
    containsErr(value) {
        return this.inner === value;
    }
    /**
     * Get the inner value or throw to the closest `Result.unthrow`
     * @param thrower The thrower from `Result.unthrow`
     * @returns `this.inner` if `Ok`
     * @throws `undefined` if `Err`
     * @see Result.unthrow
     * @see Result.unthrowSync
     */
    throw(thrower) {
        thrower(this);
        throw Panic.from(new Error(`An Err has been thrown but not catched`, { cause: this }));
    }
    /**
     * Get the inner value or throw the inner error wrapped inside another Error
     * @param message
     * @returns `this.inner` if `Ok`, `Error(message, { cause: this.inner })` if `Err`
     */
    expect(message) {
        this.ignore();
        throw Panic.from(new Error(message, { cause: this }));
    }
    /**
     * Get the inner error or throw the inner value wrapped inside another Error
     * @param message
     * @returns `this.inner` if `Err`, `Error(message, { cause: this.inner })` if `Ok`
     */
    expectErr(message) {
        this.ignore();
        return this.inner;
    }
    /**
     * Get the inner value or panic
     * @returns `this.inner` if `Ok`
     * @throws `this.inner` if `Err`
     */
    unwrap() {
        this.ignore();
        throw new Panic(new Error(`An Err has been unwrapped`, { cause: this }));
    }
    /**
     * Get the inner error or panic
     * @returns `this.inner` if `Err`
     * @throws `this.inner` if `Ok`
     */
    unwrapErr() {
        this.ignore();
        return this.inner;
    }
    /**
     * Get the inner value or a default one
     * @param value
     * @returns `this.inner` if `Ok`, `value` if `Err`
     */
    unwrapOr(value) {
        this.ignore();
        return value;
    }
    /**
     * Get the inner value or compute a default one from the inner error
     * @param errMapper
     * @returns `this.inner` if `Ok`, `await errMapper(this.inner)` if `Err`
     * @throws if `await errMapper(this.inner)` throws
     */
    async unwrapOrElse(errMapper) {
        this.ignore();
        return await errMapper(this.inner);
    }
    /**
     * Get the inner value or compute a default one from the inner error
     * @param errMapper
     * @returns `this.inner` if `Ok`, `errMapper(this.inner)` if `Err`
     * @throws if `errMapper(this.inner)` throws
     */
    unwrapOrElseSync(errMapper) {
        this.ignore();
        return errMapper(this.inner);
    }
    /**
     * Transform Result<Promise<T>, E> into Promise<Result<T, E>>
     * @returns `await this.inner` if `Ok`, `this` if `Err`
     */
    async await() {
        return this;
    }
    /**
     * Transform Result<T, Promise<E>> into Promise<Result<T, E>>
     * @returns `await this.inner` if `Err`, `this` if `Ok`
     */
    async awaitErr() {
        return new err_Err(await this.inner);
    }
    /**
     * Transform Result<Promise<T>, Promise<E>> into Promise<Result<T, E>>
     * @returns `await this.inner`
     */
    async awaitAll() {
        return await this.awaitErr();
    }
    /**
     * Transform `Result<T, E>` into `Result<void, E>`
     * @returns `Ok<void>` if `Ok<T>`, `Err<E>` if `E<E>`
     */
    clear() {
        return this;
    }
    /**
     * Transform `Result<T, E>` into `Result<T, void>`
     * @returns `Ok<T>` if `Ok<T>`, `Err<void>` if `E<E>`
     */
    clearErr() {
        this.ignore();
        return err_Err.void();
    }
    /**
     * Calls the given callback with the inner value if `Ok`
     * @param okCallback
     * @returns `this`
     */
    async inspect(okCallback) {
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Ok`
     * @param okCallback
     * @returns `this`
     */
    inspectSync(okCallback) {
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Err`
     * @param errCallback
     * @returns `this`
     */
    async inspectErr(errCallback) {
        await errCallback(this.inner);
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Err`
     * @param errCallback
     * @returns `this`
     */
    inspectErrSync(errCallback) {
        errCallback(this.inner);
        return this;
    }
    /**
     * Return a new `Ok` but with the given `inner`
     * @param inner
     * @returns `Ok(inner)` if `Ok`, `this` if `Err`
     */
    set(inner) {
        return this;
    }
    /**
     * Return a new `Err` but with the given `inner`
     * @param inner
     * @returns `Err(inner)` if `Err`, `this` if `Ok`
     */
    setErr(inner) {
        return new err_Err(inner);
    }
    /**
     * Map the inner value into another
     * @param okMapper
     * @returns `Ok(await okMapper(this.inner))` if `Ok`, `this` if `Err`
     * @throws if `await okMapper(this.inner)` throws
     */
    async map(okMapper) {
        return this;
    }
    /**
     * Map the inner value into another
     * @param okMapper
     * @returns `Ok(okMapper(this.inner))` if `Ok`, `this` if `Err`
     * @throws if `okMapper(this.inner)` throws
     */
    mapSync(okMapper) {
        return this;
    }
    /**
     * Map the inner error into another
     * @param errMapper
     * @returns `Err(await errMapper(this.inner))` if `Err`, `this` if `Ok`
     * @throws if `await errMapper(this.inner)` throws
     */
    async mapErr(errMapper) {
        this.ignore();
        return new err_Err(await errMapper(this.inner));
    }
    /**
     * Map the inner error into another
     * @param errMapper
     * @returns `Err(errMapper(this.inner))` if `Err`, `this` if `Ok`
     * @throws if `errMapper(this.inner)` throws
     */
    mapErrSync(errMapper) {
        this.ignore();
        return new err_Err(errMapper(this.inner));
    }
    /**
     * Map the inner value into another, or a default one
     * @param value
     * @param okMapper
     * @returns `await okMapper(this.inner)` if `Ok`, `value` if `Err`
     * @throws if `await okMapper(this.inner)` throws
     */
    async mapOr(value, okMapper) {
        this.ignore();
        return value;
    }
    /**
     * Map the inner value into another, or a default one
     * @param value
     * @param okMapper
     * @returns `okMapper(this.inner)` if `Ok`, `value` if `Err`
     * @throws if `okMapper(this.inner)` throws
     */
    mapOrSync(value, okMapper) {
        this.ignore();
        return value;
    }
    /**
     * Map the inner value into another, or a default one
     * @param errMapper
     * @param okMapper
     * @returns `await okMapper(this.inner)` if `Ok`, `await errMapper(this.inner)` if `Err`
     * @throws if `await okMapper(this.inner)` or `await errMapper(this.inner)` throws
     */
    async mapOrElse(errMapper, okMapper) {
        this.ignore();
        return await errMapper(this.inner);
    }
    /**
     * Map the inner value into another, or a default one
     * @param errMapper
     * @param okMapper
     * @returns `okMapper(this.inner)` if `Ok`, `errMapper(this.inner)` if `Err`
     * @throws if `okMapper(this.inner)` or `errMapper(this.inner)` throws
     */
    mapOrElseSync(errMapper, okMapper) {
        this.ignore();
        return errMapper(this.inner);
    }
    /**
     * Return `value` if `Ok`, return `this` if `Err`
     * @param value
     * @returns `value` if `Ok`, `this` if `Err`
     */
    and(value) {
        return this;
    }
    /**
     * Return `await okMapper(this.inner)` if `Ok`, return `this` if `Err`
     * @param okMapper
     * @returns `await okMapper(this.inner)` if `Ok`, `this` if `Err`
     * @throws if `await okMapper(this.inner)` throws
     */
    async andThen(okMapper) {
        return this;
    }
    /**
     * Return `okMapper(this.inner)` if `Ok`, return `this` if `Err`
     * @param okMapper
     * @returns `okMapper(this.inner)` if `Ok`, `this` if `Err`
     * @throws if `okMapper(this.inner)` throws
     */
    andThenSync(okMapper) {
        return this;
    }
    /**
     * Return `value` if `Err`, return `this` if `Ok`
     * @param value
     * @returns `value` if `Err`, `this` if `Ok`
     */
    or(value) {
        this.ignore();
        return value;
    }
    /**
     * Return `await errMapper(this.inner)` if `Err`, return `this` if `Ok`
     * @param errMapper
     * @returns `await errMapper(this.inner)` if `Err`, `this` if `Ok`
     * @throws if `await errMapper(this.inner)` throws
     */
    async orElse(errMapper) {
        this.ignore();
        return await errMapper(this.inner);
    }
    /**
     * Return `errMapper(this.inner)` if `Err`, return `this` if `Ok`
     * @param errMapper
     * @returns `errMapper(this.inner)` if `Err`, `this` if `Ok`
     * @throws if `errMapper(this.inner)` throws
     */
    orElseSync(errMapper) {
        this.ignore();
        return errMapper(this.inner);
    }
    /**
     * Transform Result<Result<T, E1>, E2> into Result<T, E1 | E2>
     * @param result
     * @returns `this` if `Err`, `this.inner` if `Ok`
     */
    flatten() {
        return this;
    }
}


//# sourceMappingURL=err.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/errors.mjs


class Unimplemented extends (/* unused pure expression or super */ null && (Error)) {
    #class = Unimplemented;
    name = this.#class.name;
    constructor(options) {
        super(`Something is not implemented`, options);
    }
}
class AssertError extends Error {
    #class = AssertError;
    name = this.#class.name;
    constructor(options) {
        super(`Some assertion failed`, options);
    }
}
class Panic extends Error {
    #class = Panic;
    name = this.#class.name;
    constructor(options) {
        super(`Something was not expected`, options);
    }
    static from(cause) {
        return new Panic({ cause });
    }
    static fromAndThrow(cause) {
        throw new Panic({ cause });
    }
}
class errors_Catched extends Error {
    #class = errors_Catched;
    name = this.#class.name;
    constructor(options) {
        super(`Something has been catched`, options);
    }
    static from(cause) {
        return new errors_Catched({ cause });
    }
    static fromAndThrow(cause) {
        throw new errors_Catched({ cause });
    }
    /**
     * Throw if `Catched`, wrap in `Err` otherwise
     * @param error
     * @returns `Err(error)` if not `Catched`
     * @throws `error.cause` if `Catched`
     */
    static throwOrErr(error) {
        if (error instanceof errors_Catched)
            throw error.cause;
        return new err_Err(error);
    }
}


//# sourceMappingURL=errors.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/option/dist/esm/mods/option/none.mjs


class NoneError extends Error {
    constructor() {
        super(`Option is a None`);
    }
}
class None {
    inner;
    /**
     * An empty value
     */
    constructor(inner = undefined) {
        this.inner = inner;
    }
    /**
     * Create a `None`
     * @returns `None`
     */
    static new() {
        return new None();
    }
    static from(init) {
        return new None();
    }
    /**
     * Type guard for `Some`
     * @returns `true` if `Some`, `false` if `None`
     */
    isSome() {
        return false;
    }
    /**
     * Returns `true` if the option is a `Some` and the value inside of it matches a predicate
     * @param somePredicate
     * @returns `true` if `Some` and `await somePredicate(this.inner)`, `None` otherwise
     */
    async isSomeAnd(somePredicate) {
        return false;
    }
    /**
     * Returns `true` if the option is a `Some` and the value inside of it matches a predicate
     * @param somePredicate
     * @returns `true` if `Some` and `somePredicate(this.inner)`, `None` otherwise
     */
    isSomeAndSync(somePredicate) {
        return false;
    }
    /**
     * Type guard for `None`
     * @returns `true` if `None`, `false` if `Some`
     */
    isNone() {
        return true;
    }
    /**
     * Compile-time safely get `this.inner`
     * @returns `this.inner`
     */
    get() {
        return this.inner;
    }
    /**
     * Returns an iterator over the possibly contained value
     * @yields `this.inner` if `Some`
     */
    *[Symbol.iterator]() {
        return;
    }
    /**
     * Get the inner value if `Some`, throw `Error(message)` otherwise
     * @param message
     * @returns `this.inner` if `Some`
     * @throws `Error(message)` if `None`
     */
    expect(message) {
        throw Panic.from(new Error(message, { cause: this }));
    }
    /**
     * Get the inner value or throw a NoneError
     * @returns `this.inner` if `Some`
     * @throws `NoneError` if `None`
     */
    unwrap() {
        throw Panic.from(new Error(`A None has been unwrapped`, { cause: this }));
    }
    /**
     * Get the inner value or a default one
     * @param value
     * @returns `this.inner` if `Some`, `value` if `None`
     */
    unwrapOr(value) {
        return value;
    }
    /**
     * Returns the contained `Some` value or computes it from a closure
     * @param noneCallback
     * @returns `this.inner` if `Some`, `await noneCallback()` if `None`
     */
    async unwrapOrElse(noneCallback) {
        return await noneCallback();
    }
    /**
     * Returns the contained `Some` value or computes it from a closure
     * @param noneCallback
     * @returns `this.inner` if `Some`, `noneCallback()` if `None`
     */
    unwrapOrElseSync(noneCallback) {
        return noneCallback();
    }
    /**
     * Transform `Option<T>` into `Result<T, NoneError>`
     * @returns `Ok(this.inner)` if `Some`, `Err(NoneError)` if `None`
     */
    ok() {
        return new err_Err(new NoneError());
    }
    /**
     * Transform `Option<T>` into `Result<T, E>`
     * @param error
     * @returns `Ok(this.inner)` if `Some`, `Err(error)` if `None`
     */
    okOr(error) {
        return new err_Err(error);
    }
    /**
     * Transforms the `Option<T>` into a `Result<T, E>`, mapping `Some(v)` to `Ok(v)` and `None` to `Err(err())`
     * @param noneCallback
     * @returns `Ok(this.inner)` if `Some`, `Err(await noneCallback())` is `None`
     */
    async okOrElse(noneCallback) {
        return new err_Err(await noneCallback());
    }
    /**
     * Transforms the `Option<T>` into a `Result<T, E>`, mapping `Some(v)` to `Ok(v)` and `None` to `Err(err())`
     * @param noneCallback
     * @returns `Ok(this.inner)` if `Some`, `Err(noneCallback())` is `None`
     */
    okOrElseSync(noneCallback) {
        return new err_Err(noneCallback());
    }
    /**
     * Returns `None` if the option is `None`, otherwise calls `somePredicate` with the wrapped value
     * @param somePredicate
     * @returns `Some` if `Some` and `await somePredicate(this.inner)`, `None` otherwise
     */
    async filter(somePredicate) {
        return this;
    }
    /**
     * Returns `None` if the option is `None`, otherwise calls `somePredicate` with the wrapped value
     * @param somePredicate
     * @returns `Some` if `Some` and `somePredicate(this.inner)`, `None` otherwise
     */
    filterSync(somePredicate) {
        return this;
    }
    /**
     * Transform `Option<Promise<T>>` into `Promise<Option<T>>`
     * @returns `Promise<Option<T>>`
     */
    async await() {
        return this;
    }
    /**
     * Returns `true` if the option is a `Some` value containing the given value
     * @param value
     * @returns `true` if `Some` and `this.inner === value`, `None` otherwise
     */
    contains(value) {
        return false;
    }
    /**
     * Calls the given callback with the inner value if `Ok`
     * @param someCallback
     * @returns `this`
     */
    async inspect(someCallback) {
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Ok`
     * @param someCallback
     * @returns `this`
     */
    inspectSync(someCallback) {
        return this;
    }
    /**
     * Maps an `Option<T>` to `Option<U>` by applying a function to a contained value (if `Some`) or returns `None` (if `None`)
     * @param someMapper
     * @returns `Some(await someMapper(this.inner))` if `Some`, `this` if `None`
     */
    async map(someMapper) {
        return this;
    }
    /**
     * Maps an `Option<T>` to `Option<U>` by applying a function to a contained value (if `Some`) or returns `None` (if `None`)
     * @param someMapper
     * @returns `Some(someMapper(this.inner))` if `Some`, `this` if `None`
     */
    mapSync(someMapper) {
        return this;
    }
    /**
     * Returns the provided default result (if none), or applies a function to the contained value (if any)
     * @param value
     * @param someMapper
     * @returns `value` if `None`, `await someMapper(this.inner)` if `Some`
     */
    async mapOr(value, someMapper) {
        return value;
    }
    /**
     * Returns the provided default result (if none), or applies a function to the contained value (if any)
     * @param value
     * @param someMapper
     * @returns `value` if `None`, `someMapper(this.inner)` if `Some`
     */
    mapOrSync(value, someMapper) {
        return value;
    }
    /**
     * Computes a default function result (if none), or applies a different function to the contained value (if any)
     * @param noneCallback
     * @param someMapper
     * @returns `await someMapper(this.inner)` if `Some`, `await noneCallback()` if `None`
     */
    async mapOrElse(noneCallback, someMapper) {
        return await noneCallback();
    }
    /**
     * Computes a default function result (if none), or applies a different function to the contained value (if any)
     * @param noneCallback
     * @param someMapper
     * @returns `someMapper(this.inner)` if `Some`, `noneCallback()` if `None`
     */
    mapOrElseSync(noneCallback, someMapper) {
        return noneCallback();
    }
    /**
     * Returns `None` if the option is `None`, otherwise returns `value`
     * @param value
     * @returns `None` if `None`, `value` if `Some`
     */
    and(value) {
        return this;
    }
    /**
     * Returns `None` if the option is `None`, otherwise calls `someMapper` with the wrapped value and returns the result
     * @param someMapper
     * @returns `None` if `None`, `await someMapper(this.inner)` if `Some`
     */
    async andThen(someMapper) {
        return this;
    }
    /**
     * Returns `None` if the option is `None`, otherwise calls `someMapper` with the wrapped value and returns the result
     * @param someMapper
     * @returns `None` if `None`, `someMapper(this.inner)` if `Some`
     */
    andThenSync(someMapper) {
        return this;
    }
    /**
     * Returns `this` if `Some`, otherwise returns `value`
     * @param value
     * @returns `this` if `Some`, `value` if `None`
     */
    or(value) {
        return value;
    }
    /**
     * Returns `this` if `Some`, otherwise calls `noneCallback` and returns the result
     * @param noneCallback
     * @returns `this` if `Some`, `await noneCallback()` if `None`
     */
    async orElse(noneCallback) {
        return await noneCallback();
    }
    /**
     * Returns `this` if `Some`, otherwise calls `noneCallback` and returns the result
     * @param noneCallback
     * @returns `this` if `Some`, `noneCallback()` if `None`
     */
    orElseSync(noneCallback) {
        return noneCallback();
    }
    /**
     * Returns `Some` if exactly one of the options is `Some`, otherwise returns `None`
     * @param value
     * @returns `None` if both are `Some` or both are `None`, the only `Some` otherwise
     */
    xor(value) {
        return value;
    }
    /**
     * Zips `this` with another `Option`
     * @param other
     * @returns `Some([this.inner, other.inner])` if both are `Some`, `None` if one of them is `None`
     */
    zip(other) {
        return this;
    }
}


//# sourceMappingURL=none.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/option/dist/esm/mods/option/some.mjs



class Some {
    inner;
    /**
     * An existing value
     * @param inner
     */
    constructor(inner) {
        this.inner = inner;
    }
    /**
     * Create a `Some`
     * @param inner
     * @returns `Some(inner)`
     */
    static new(inner) {
        return new Some(inner);
    }
    static from(init) {
        return new Some(init.inner);
    }
    /**
     * Type guard for `Some`
     * @returns `true` if `Some`, `false` if `None`
     */
    isSome() {
        return true;
    }
    /**
     * Returns `true` if the option is a `Some` and the value inside of it matches a predicate
     * @param somePredicate
     * @returns `true` if `Some` and `await somePredicate(this.inner)`, `None` otherwise
     */
    async isSomeAnd(somePredicate) {
        return await somePredicate(this.inner);
    }
    /**
     * Returns `true` if the option is a `Some` and the value inside of it matches a predicate
     * @param somePredicate
     * @returns `true` if `Some` and `somePredicate(this.inner)`, `None` otherwise
     */
    isSomeAndSync(somePredicate) {
        return somePredicate(this.inner);
    }
    /**
     * Type guard for `None`
     * @returns `true` if `None`, `false` if `Some`
     */
    isNone() {
        return false;
    }
    /**
     * Compile-time safely get `this.inner`
     * @returns `this.inner`
     */
    get() {
        return this.inner;
    }
    /**
     * Returns an iterator over the possibly contained value
     * @yields `this.inner` if `Some`
     */
    *[Symbol.iterator]() {
        yield this.inner;
    }
    /**
     * Get the inner value if `Some`, throw `Error(message)` otherwise
     * @param message
     * @returns `this.inner` if `Some`
     * @throws `Error(message)` if `None`
     */
    expect(message) {
        return this.inner;
    }
    /**
     * Get the inner value or throw a NoneError
     * @returns `this.inner` if `Some`
     * @throws `NoneError` if `None`
     */
    unwrap() {
        return this.inner;
    }
    /**
     * Get the inner value or a default one
     * @param value
     * @returns `this.inner` if `Some`, `value` if `None`
     */
    unwrapOr(value) {
        return this.inner;
    }
    /**
     * Returns the contained `Some` value or computes it from a closure
     * @param noneCallback
     * @returns `this.inner` if `Some`, `await noneCallback()` if `None`
     */
    async unwrapOrElse(noneCallback) {
        return this.inner;
    }
    /**
     * Returns the contained `Some` value or computes it from a closure
     * @param noneCallback
     * @returns `this.inner` if `Some`, `noneCallback()` if `None`
     */
    unwrapOrElseSync(noneCallback) {
        return this.inner;
    }
    /**
     * Transform `Option<T>` into `Result<T, NoneError>`
     * @returns `Ok(this.inner)` if `Some`, `Err(NoneError)` if `None`
     */
    ok() {
        return new ok_Ok(this.inner);
    }
    /**
     * Transform `Option<T>` into `Result<T, E>`
     * @param error
     * @returns `Ok(this.inner)` if `Some`, `Err(error)` if `None`
     */
    okOr(error) {
        return new ok_Ok(this.inner);
    }
    /**
     * Transforms the `Option<T>` into a `Result<T, E>`, mapping `Some(v)` to `Ok(v)` and `None` to `Err(err())`
     * @param noneCallback
     * @returns `Ok(this.inner)` if `Some`, `Err(await noneCallback())` is `None`
     */
    async okOrElse(noneCallback) {
        return new ok_Ok(this.inner);
    }
    /**
     * Transforms the `Option<T>` into a `Result<T, E>`, mapping `Some(v)` to `Ok(v)` and `None` to `Err(err())`
     * @param noneCallback
     * @returns `Ok(this.inner)` if `Some`, `Err(noneCallback())` is `None`
     */
    okOrElseSync(noneCallback) {
        return new ok_Ok(this.inner);
    }
    /**
     * Returns `None` if the option is `None`, otherwise calls `somePredicate` with the wrapped value
     * @param somePredicate
     * @returns `Some` if `Some` and `await somePredicate(this.inner)`, `None` otherwise
     */
    async filter(somePredicate) {
        if (await somePredicate(this.inner))
            return this;
        else
            return new None();
    }
    /**
     * Returns `None` if the option is `None`, otherwise calls `somePredicate` with the wrapped value
     * @param somePredicate
     * @returns `Some` if `Some` and `somePredicate(this.inner)`, `None` otherwise
     */
    filterSync(somePredicate) {
        if (somePredicate(this.inner))
            return this;
        else
            return new None();
    }
    /**
     * Transform `Option<Promise<T>>` into `Promise<Option<T>>`
     * @returns `Promise<Option<T>>`
     */
    async await() {
        return new Some(await this.inner);
    }
    /**
     * Returns `true` if the option is a `Some` value containing the given value
     * @param value
     * @returns `true` if `Some` and `this.inner === value`, `None` otherwise
     */
    contains(value) {
        return this.inner === value;
    }
    /**
     * Calls the given callback with the inner value if `Ok`
     * @param someCallback
     * @returns `this`
     */
    async inspect(someCallback) {
        await someCallback(this.inner);
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Ok`
     * @param someCallback
     * @returns `this`
     */
    inspectSync(someCallback) {
        someCallback(this.inner);
        return this;
    }
    /**
     * Maps an `Option<T>` to `Option<U>` by applying a function to a contained value (if `Some`) or returns `None` (if `None`)
     * @param someMapper
     * @returns `Some(await someMapper(this.inner))` if `Some`, `this` if `None`
     */
    async map(someMapper) {
        return new Some(await someMapper(this.inner));
    }
    /**
     * Maps an `Option<T>` to `Option<U>` by applying a function to a contained value (if `Some`) or returns `None` (if `None`)
     * @param someMapper
     * @returns `Some(someMapper(this.inner))` if `Some`, `this` if `None`
     */
    mapSync(someMapper) {
        return new Some(someMapper(this.inner));
    }
    /**
     * Returns the provided default result (if none), or applies a function to the contained value (if any)
     * @param value
     * @param someMapper
     * @returns `value` if `None`, `await someMapper(this.inner)` if `Some`
     */
    async mapOr(value, someMapper) {
        return await someMapper(this.inner);
    }
    /**
     * Returns the provided default result (if none), or applies a function to the contained value (if any)
     * @param value
     * @param someMapper
     * @returns `value` if `None`, `someMapper(this.inner)` if `Some`
     */
    mapOrSync(value, someMapper) {
        return someMapper(this.inner);
    }
    /**
     * Computes a default function result (if none), or applies a different function to the contained value (if any)
     * @param noneCallback
     * @param someMapper
     * @returns `await someMapper(this.inner)` if `Some`, `await noneCallback()` if `None`
     */
    async mapOrElse(noneCallback, someMapper) {
        return await someMapper(this.inner);
    }
    /**
     * Computes a default function result (if none), or applies a different function to the contained value (if any)
     * @param noneCallback
     * @param someMapper
     * @returns `someMapper(this.inner)` if `Some`, `noneCallback()` if `None`
     */
    mapOrElseSync(noneCallback, someMapper) {
        return someMapper(this.inner);
    }
    /**
     * Returns `None` if the option is `None`, otherwise returns `value`
     * @param value
     * @returns `None` if `None`, `value` if `Some`
     */
    and(value) {
        return value;
    }
    /**
     * Returns `None` if the option is `None`, otherwise calls `someMapper` with the wrapped value and returns the result
     * @param someMapper
     * @returns `None` if `None`, `await someMapper(this.inner)` if `Some`
     */
    async andThen(someMapper) {
        return await someMapper(this.inner);
    }
    /**
     * Returns `None` if the option is `None`, otherwise calls `someMapper` with the wrapped value and returns the result
     * @param someMapper
     * @returns `None` if `None`, `someMapper(this.inner)` if `Some`
     */
    andThenSync(someMapper) {
        return someMapper(this.inner);
    }
    /**
     * Returns `this` if `Some`, otherwise returns `value`
     * @param value
     * @returns `this` if `Some`, `value` if `None`
     */
    or(value) {
        return this;
    }
    /**
     * Returns `this` if `Some`, otherwise calls `noneCallback` and returns the result
     * @param noneCallback
     * @returns `this` if `Some`, `await noneCallback()` if `None`
     */
    async orElse(noneCallback) {
        return this;
    }
    /**
     * Returns `this` if `Some`, otherwise calls `noneCallback` and returns the result
     * @param noneCallback
     * @returns `this` if `Some`, `noneCallback()` if `None`
     */
    orElseSync(noneCallback) {
        return this;
    }
    /**
     * Returns `Some` if exactly one of the options is `Some`, otherwise returns `None`
     * @param value
     * @returns `None` if both are `Some` or both are `None`, the only `Some` otherwise
     */
    xor(value) {
        if (value.isSome())
            return new None();
        else
            return this;
    }
    /**
     * Zips `this` with another `Option`
     * @param other
     * @returns `Some([this.inner, other.inner])` if both are `Some`, `None` if one of them is `None`
     */
    zip(other) {
        if (other.isSome())
            return new Some([this.inner, other.inner]);
        else
            return other;
    }
}


//# sourceMappingURL=some.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/ok.mjs




class ok_Ok {
    #inner;
    #timeout;
    /**
     * A success
     * @param inner
     */
    constructor(inner) {
        this.#inner = inner;
        if (!Result.debug)
            return;
        const error = Panic.from(new Error(`An Ok has not been handled properly`, { cause: this }));
        this.#timeout = setTimeout(() => { throw error; }, 1000);
    }
    /**
     * Create an empty `Ok`
     * @returns `Ok(void)`
     */
    static void() {
        return new ok_Ok(undefined);
    }
    /**
     * Create an `Ok`
     * @param inner
     * @returns `Ok(inner)`
     */
    static new(inner) {
        return new ok_Ok(inner);
    }
    get inner() {
        return this.#inner;
    }
    /**
     * Set this result as handled
     */
    ignore() {
        if (!this.#timeout)
            return this;
        clearTimeout(this.#timeout);
        this.#timeout = undefined;
        return this;
    }
    /**
     * Type guard for `Ok`
     * @returns `true` if `Ok`, `false` if `Err`
     */
    isOk() {
        return true;
    }
    /**
     * Returns true if the result is `Ok` and the value inside of it matches a predicate
     * @param okPredicate
     * @returns `true` if `Ok` and `await okPredicate(this.inner)`, `false` otherwise
     */
    async isOkAnd(okPredicate) {
        return await okPredicate(this.inner);
    }
    /**
     * Returns true if the result is `Ok` and the value inside of it matches a predicate
     * @param okPredicate
     * @returns `true` if `Ok` and `await okPredicate(this.inner)`, `false` otherwise
     */
    isOkAndSync(okPredicate) {
        return okPredicate(this.inner);
    }
    /**
     * Type guard for `Err`
     * @returns `true` if `Err`, `false` if `Ok`
     */
    isErr() {
        return false;
    }
    /**
     * Returns true if the result is `Err` and the value inside of it matches a predicate
     * @param errPredicate
     * @returns `true` if `Err` and `await errPredicate(this.inner)`, `false` otherwise
     */
    async isErrAnd(errPredicate) {
        return false;
    }
    /**
     * Returns true if the result is `Err` and the value inside of it matches a predicate
     * @param errPredicate
     * @returns `true` if `Err` and `await errPredicate(this.inner)`, `false` otherwise
     */
    isErrAndSync(errPredicate) {
        return false;
    }
    /**
     * Compile-time safely get `this.inner`
     * @returns `this.inner`
     */
    get() {
        this.ignore();
        return this.inner;
    }
    /**
     * Transform `Result<T, E>` into `Option<T>`
     * @returns `Some(this.inner)` if `Ok`, `None` if `Err`
     */
    ok() {
        this.ignore();
        return new Some(this.inner);
    }
    /**
     * Transform `Result<T, E>` into `Option<E>`
     * @returns `Some(this.inner)` if `Err`, `None` if `Ok`
     */
    err() {
        this.ignore();
        return new None();
    }
    /**
     * Returns an iterator over the possibly contained value
     * @yields `this.inner` if `Ok`
     */
    *[Symbol.iterator]() {
        this.ignore();
        yield this.inner;
    }
    /**
     * Transform `Result<T,E>` into `[T,E]`
     * @returns `[this.inner, undefined]` if `Ok`, `[undefined, this.inner]` if `Err`
     */
    split() {
        this.ignore();
        return [this.inner, undefined];
    }
    /**
     * Returns true if the result is an `Ok` value containing the given value
     * @param value
     * @returns `true` if `Ok` and `this.inner === value`, `false` otherwise
     */
    contains(value) {
        return this.inner === value;
    }
    /**
     * Returns true if the result is an `Err` value containing the given value
     * @param value
     * @returns `true` if `Err` and `this.inner === value`, `false` otherwise
     */
    containsErr(value) {
        return false;
    }
    /**
     * Just like `unwrap` but it throws to the closest `Result.unthrow`
     * @returns `this.inner` if `Ok`
     * @throws `this` if `Err`
     * @see Result.unthrow
     * @see Result.unthrowSync
     */
    throw(thrower) {
        this.ignore();
        return this.inner;
    }
    /**
     * Get the inner value or throw the inner error wrapped inside another Error
     * @param message
     * @returns `this.inner` if `Ok`, `Error(message, { cause: this.inner })` if `Err`
     */
    expect(message) {
        this.ignore();
        return this.inner;
    }
    /**
     * Get the inner error or throw the inner value wrapped inside another Error
     * @param message
     * @returns `this.inner` if `Err`, `Error(message, { cause: this.inner })` if `Ok`
     */
    expectErr(message) {
        this.ignore();
        throw Panic.from(new Error(message, { cause: this }));
    }
    /**
     * Get the inner value or panic
     * @returns `this.inner` if `Ok`
     * @throws `this.inner` if `Err`
     */
    unwrap() {
        this.ignore();
        return this.inner;
    }
    /**
     * Get the inner error or panic
     * @returns `this.inner` if `Err`
     * @throws `this.inner` if `Ok`
     */
    unwrapErr() {
        this.ignore();
        throw Panic.from(new Error(`An Ok has been unwrapped`, { cause: this }));
    }
    /**
     * Get the inner value or a default one
     * @param value
     * @returns `this.inner` if `Ok`, `value` if `Err`
     */
    unwrapOr(value) {
        this.ignore();
        return this.inner;
    }
    /**
     * Get the inner value or compute a default one from the inner error
     * @param errMapper
     * @returns `this.inner` if `Ok`, `await errMapper(this.inner)` if `Err`
     * @throws if `await errMapper(this.inner)` throws
     */
    async unwrapOrElse(errMapper) {
        this.ignore();
        return this.inner;
    }
    /**
     * Get the inner value or compute a default one from the inner error
     * @param errMapper
     * @returns `this.inner` if `Ok`, `errMapper(this.inner)` if `Err`
     * @throws if `errMapper(this.inner)` throws
     */
    unwrapOrElseSync(errMapper) {
        this.ignore();
        return this.inner;
    }
    /**
     * Transform Result<Promise<T>, E> into Promise<Result<T, E>>
     * @returns `await this.inner` if `Ok`, `this` if `Err`
     */
    async await() {
        return new ok_Ok(await this.inner);
    }
    /**
     * Transform Result<T, Promise<E>> into Promise<Result<T, E>>
     * @returns `await this.inner` if `Err`, `this` if `Ok`
     */
    async awaitErr() {
        return this;
    }
    /**
     * Transform Result<Promise<T>, Promise<E>> into Promise<Result<T, E>>
     * @returns `await this.inner`
     */
    async awaitAll() {
        return await this.await();
    }
    /**
     * Transform `Result<T, E>` into `Result<void, E>`
     * @returns `Ok<void>` if `Ok<T>`, `Err<E>` if `E<E>`
     */
    clear() {
        this.ignore();
        return ok_Ok.void();
    }
    /**
     * Transform `Result<T, E>` into `Result<T, void>`
     * @returns `Ok<T>` if `Ok<T>`, `Err<void>` if `E<E>`
     */
    clearErr() {
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Ok`
     * @param okCallback
     * @returns `this`
     */
    async inspect(okCallback) {
        await okCallback(this.inner);
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Ok`
     * @param okCallback
     * @returns `this`
     */
    inspectSync(okCallback) {
        okCallback(this.inner);
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Err`
     * @param errCallback
     * @returns `this`
     */
    async inspectErr(errCallback) {
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Err`
     * @param errCallback
     * @returns `this`
     */
    inspectErrSync(errCallback) {
        return this;
    }
    /**
     * Return a new `Ok` but with the given `inner`
     * @param inner
     * @returns `Ok(inner)` if `Ok`, `this` if `Err`
     */
    set(inner) {
        return new ok_Ok(inner);
    }
    /**
     * Return a new `Err` but with the given `inner`
     * @param inner
     * @returns `Err(inner)` if `Err`, `this` if `Ok`
     */
    setErr(inner) {
        return this;
    }
    /**
     * Map the inner value into another
     * @param okMapper
     * @returns `Ok(await okMapper(this.inner))` if `Ok`, `this` if `Err`
     * @throws if `await okMapper(this.inner)` throws
     */
    async map(okMapper) {
        this.ignore();
        return new ok_Ok(await okMapper(this.inner));
    }
    /**
     * Map the inner value into another
     * @param okMapper
     * @returns `Ok(okMapper(this.inner))` if `Ok`, `this` if `Err`
     * @throws if `okMapper(this.inner)` throws
     */
    mapSync(okMapper) {
        this.ignore();
        return new ok_Ok(okMapper(this.inner));
    }
    /**
     * Map the inner error into another
     * @param errMapper
     * @returns `Err(await errMapper(this.inner))` if `Err`, `this` if `Ok`
     * @throws if `await errMapper(this.inner)` throws
     */
    async mapErr(errMapper) {
        return this;
    }
    /**
     * Map the inner error into another
     * @param errMapper
     * @returns `Err(errMapper(this.inner))` if `Err`, `this` if `Ok`
     * @throws if `errMapper(this.inner)` throws
     */
    mapErrSync(errMapper) {
        return this;
    }
    /**
     * Map the inner value into another, or a default one
     * @param value
     * @param okMapper
     * @returns `await okMapper(this.inner)` if `Ok`, `value` if `Err`
     * @throws if `await okMapper(this.inner)` throws
     */
    async mapOr(value, okMapper) {
        this.ignore();
        return await okMapper(this.inner);
    }
    /**
     * Map the inner value into another, or a default one
     * @param value
     * @param okMapper
     * @returns `okMapper(this.inner)` if `Ok`, `value` if `Err`
     * @throws if `okMapper(this.inner)` throws
     */
    mapOrSync(value, okMapper) {
        this.ignore();
        return okMapper(this.inner);
    }
    /**
     * Map the inner value into another, or a default one
     * @param errMapper
     * @param okMapper
     * @returns `await okMapper(this.inner)` if `Ok`, `await errMapper(this.inner)` if `Err`
     * @throws if `await okMapper(this.inner)` or `await errMapper(this.inner)` throws
     */
    async mapOrElse(errMapper, okMapper) {
        this.ignore();
        return await okMapper(this.inner);
    }
    /**
     * Map the inner value into another, or a default one
     * @param errMapper
     * @param okMapper
     * @returns `okMapper(this.inner)` if `Ok`, `errMapper(this.inner)` if `Err`
     * @throws if `okMapper(this.inner)` or `errMapper(this.inner)` throws
     */
    mapOrElseSync(errMapper, okMapper) {
        this.ignore();
        return okMapper(this.inner);
    }
    /**
     * Return `value` if `Ok`, return `this` if `Err`
     * @param value
     * @returns `value` if `Ok`, `this` if `Err`
     */
    and(value) {
        this.ignore();
        return value;
    }
    /**
     * Return `await okMapper(this.inner)` if `Ok`, return `this` if `Err`
     * @param okMapper
     * @returns `await okMapper(this.inner)` if `Ok`, `this` if `Err`
     * @throws if `await okMapper(this.inner)` throws
     */
    async andThen(okMapper) {
        this.ignore();
        return await okMapper(this.inner);
    }
    /**
     * Return `okMapper(this.inner)` if `Ok`, return `this` if `Err`
     * @param okMapper
     * @returns `okMapper(this.inner)` if `Ok`, `this` if `Err`
     * @throws if `okMapper(this.inner)` throws
     */
    andThenSync(okMapper) {
        this.ignore();
        return okMapper(this.inner);
    }
    /**
     * Return `value` if `Err`, return `this` if `Ok`
     * @param value
     * @returns `value` if `Err`, `this` if `Ok`
     */
    or(value) {
        return this;
    }
    /**
     * Return `await errMapper(this.inner)` if `Err`, return `this` if `Ok`
     * @param errMapper
     * @returns `await errMapper(this.inner)` if `Err`, `this` if `Ok`
     * @throws if `await errMapper(this.inner)` throws
     */
    async orElse(errMapper) {
        return this;
    }
    /**
     * Return `errMapper(this.inner)` if `Err`, return `this` if `Ok`
     * @param errMapper
     * @returns `errMapper(this.inner)` if `Err`, `this` if `Ok`
     * @throws if `errMapper(this.inner)` throws
     */
    orElseSync(errMapper) {
        return this;
    }
    /**
     * Transform Result<Result<T, E1>, E2> into Result<T, E1 | E2>
     * @param result
     * @returns `this` if `Err`, `this.inner` if `Ok`
     */
    flatten() {
        return this.inner;
    }
}


//# sourceMappingURL=ok.mjs.map

;// CONCATENATED MODULE: ./src/libs/blobs/blobs.ts


var Blobs;
(function(Blobs) {
    async function readAsDataURL(blob) {
        const future = new Future();
        const reader = new FileReader();
        const onLoad = ()=>{
            future.resolve(reader.result);
        };
        const onError = ()=>{
            future.reject(reader.error);
        };
        try {
            reader.addEventListener("load", onLoad, {
                passive: true
            });
            reader.addEventListener("error", onError, {
                passive: true
            });
            reader.readAsDataURL(blob);
            return await future.promise;
        } finally{
            reader.removeEventListener("load", onLoad);
            reader.removeEventListener("error", onError);
        }
    }
    Blobs.readAsDataURL = readAsDataURL;
    async function tryReadAsDataURL(blob) {
        const future = new Future();
        const reader = new FileReader();
        const onLoad = ()=>{
            future.resolve(new ok_Ok(reader.result));
        };
        const onError = ()=>{
            future.resolve(new err_Err(reader.error));
        };
        try {
            reader.addEventListener("load", onLoad, {
                passive: true
            });
            reader.addEventListener("error", onError, {
                passive: true
            });
            reader.readAsDataURL(blob);
            return await future.promise;
        } finally{
            reader.removeEventListener("load", onLoad);
            reader.removeEventListener("error", onError);
        }
    }
    Blobs.tryReadAsDataURL = tryReadAsDataURL;
})(Blobs || (Blobs = {}));

;// CONCATENATED MODULE: ./node_modules/@swc/helpers/esm/_class_apply_descriptor_get.js
function _class_apply_descriptor_get(receiver, descriptor) {
    if (descriptor.get) return descriptor.get.call(receiver);

    return descriptor.value;
}


;// CONCATENATED MODULE: ./node_modules/@swc/helpers/esm/_class_extract_field_descriptor.js
function _class_extract_field_descriptor(receiver, privateMap, action) {
    if (!privateMap.has(receiver)) throw new TypeError("attempted to " + action + " private field on non-instance");

    return privateMap.get(receiver);
}


;// CONCATENATED MODULE: ./node_modules/@swc/helpers/esm/_class_private_field_get.js



function _class_private_field_get(receiver, privateMap) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "get");
    return _class_apply_descriptor_get(receiver, descriptor);
}


;// CONCATENATED MODULE: ./node_modules/@swc/helpers/esm/_check_private_redeclaration.js
function _check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}


;// CONCATENATED MODULE: ./node_modules/@swc/helpers/esm/_class_private_field_init.js


function _class_private_field_init(obj, privateMap, value) {
    _check_private_redeclaration(obj, privateMap);
    privateMap.set(obj, value);
}


;// CONCATENATED MODULE: ./node_modules/@swc/helpers/esm/_class_apply_descriptor_set.js
function _class_apply_descriptor_set(receiver, descriptor, value) {
    if (descriptor.set) descriptor.set.call(receiver, value);
    else {
        if (!descriptor.writable) {
            // This should only throw in strict mode, but class bodies are
            // always strict and private fields can only be used inside
            // class bodies.
            throw new TypeError("attempted to set read only private field");
        }
        descriptor.value = value;
    }
}


;// CONCATENATED MODULE: ./node_modules/@swc/helpers/esm/_class_private_field_set.js



function _class_private_field_set(receiver, privateMap, value) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "set");
    _class_apply_descriptor_set(receiver, descriptor, value);
    return value;
}


;// CONCATENATED MODULE: ./src/libs/browser/browser.ts



var _a;

var _globalThis_browser;
const browser = (_globalThis_browser = globalThis.browser) !== null && _globalThis_browser !== void 0 ? _globalThis_browser : globalThis.chrome;
var _class = /*#__PURE__*/ new WeakMap();
class BrowserError extends Error {
    static from(cause) {
        return new _a(undefined, {
            cause
        });
    }
    constructor(...args){
        super(...args);
        _class_private_field_init(this, _class, {
            writable: true,
            value: void 0
        });
        _class_private_field_set(this, _class, _a);
        this.name = _class_private_field_get(this, _class).name;
    }
}
_a = BrowserError;
async function tryBrowser(callback) {
    try {
        const result = await callback();
        if (browser.runtime.lastError) return new err_Err(new BrowserError());
        return new ok_Ok(result);
    } catch (e) {
        return new err_Err(new BrowserError());
    }
}
function tryBrowserSync(callback) {
    try {
        const result = callback();
        const error = browser.runtime.lastError;
        if (error) return new err_Err(BrowserError.from(error));
        return new ok_Ok(result);
    } catch (e) {
        return new err_Err(BrowserError.from(e));
    }
}

;// CONCATENATED MODULE: ./node_modules/@hazae41/jsonrpc/dist/esm/mods/rpc/err.mjs


class RpcError extends Error {
    code;
    message;
    data;
    #class = RpcError;
    name = this.#class.name;
    static codes = {
        ParseError: -32700,
        InvalidRequest: -32600,
        MethodNotFound: -32601,
        InvalidParams: -32602,
        InternalError: -32603
    };
    static messages = {
        ParseError: "Parse error",
        InvalidRequest: "Invalid Request",
        MethodNotFound: "Method not found",
        InvalidParams: "Invalid params",
        InternalError: "Internal error",
        ServerError: "Server error"
    };
    constructor(code, message, data = undefined) {
        super(message);
        this.code = code;
        this.message = message;
        this.data = data;
    }
    static from(init) {
        const { code, message, data } = init;
        return new RpcError(code, message, data);
    }
    static rewrap(error) {
        if (error instanceof RpcError)
            return error;
        if (error instanceof Error)
            return new RpcError(-32603, error.message);
        return new RpcError(-32603, "An unknown error occured");
    }
    /**
     * Used by JSON.stringify
     */
    toJSON() {
        const { code, message, data } = this;
        return { code, message, data };
    }
}
class RpcParseError extends RpcError {
    #class = RpcParseError;
    name = this.#class.name;
    static code = RpcError.codes.ParseError;
    static message = RpcError.messages.ParseError;
    constructor() {
        super(RpcError.codes.ParseError, RpcError.messages.ParseError);
    }
}
class RpcInvalidRequestError extends RpcError {
    #class = RpcInvalidRequestError;
    name = this.#class.name;
    static code = RpcError.codes.InvalidRequest;
    static message = RpcError.messages.InvalidRequest;
    constructor() {
        super(RpcError.codes.InvalidRequest, RpcError.messages.InvalidRequest);
    }
}
class RpcMethodNotFoundError extends RpcError {
    #class = RpcMethodNotFoundError;
    name = this.#class.name;
    static code = RpcError.codes.MethodNotFound;
    static message = RpcError.messages.MethodNotFound;
    constructor() {
        super(RpcError.codes.MethodNotFound, RpcError.messages.MethodNotFound);
    }
}
class RpcInvalidParamsError extends RpcError {
    #class = RpcInvalidParamsError;
    name = this.#class.name;
    static code = RpcError.codes.InvalidParams;
    static message = RpcError.messages.InvalidParams;
    constructor() {
        super(RpcError.codes.InvalidParams, RpcError.messages.InvalidParams);
    }
}
class RpcInternalError extends RpcError {
    #class = RpcInternalError;
    name = this.#class.name;
    static code = RpcError.codes.InternalError;
    static message = RpcError.messages.InternalError;
    constructor() {
        super(RpcError.codes.InternalError, RpcError.messages.InternalError);
    }
}
class RpcErr extends err_Err {
    id;
    error;
    jsonrpc = "2.0";
    constructor(id, error) {
        super(error);
        this.id = id;
        this.error = error;
    }
    static from(init) {
        return new RpcErr(init.id, RpcError.from(init.error));
    }
    static rewrap(id, result) {
        return new RpcErr(id, RpcError.rewrap(result.inner));
    }
}


//# sourceMappingURL=err.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/jsonrpc/dist/esm/mods/rpc/ok.mjs


var RpcOkInit;
(function (RpcOkInit) {
    function from(response) {
        const { jsonrpc, id, result } = response;
        return { jsonrpc, id, result };
    }
    RpcOkInit.from = from;
})(RpcOkInit || (RpcOkInit = {}));
class RpcOk extends ok_Ok {
    id;
    result;
    jsonrpc = "2.0";
    constructor(id, result) {
        super(result);
        this.id = id;
        this.result = result;
    }
    static from(init) {
        return new RpcOk(init.id, init.result);
    }
    static rewrap(id, result) {
        return new RpcOk(id, result.inner);
    }
}


//# sourceMappingURL=ok.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/jsonrpc/dist/esm/mods/rpc/response.mjs



var RpcResponse;
(function (RpcResponse) {
    function from(init) {
        if ("error" in init)
            return RpcErr.from(init);
        return RpcOk.from(init);
    }
    RpcResponse.from = from;
    function rewrap(id, result) {
        if (result.isErr())
            return RpcErr.rewrap(id, result);
        return RpcOk.rewrap(id, result);
    }
    RpcResponse.rewrap = rewrap;
})(RpcResponse || (RpcResponse = {}));


//# sourceMappingURL=response.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/jsonrpc/dist/esm/mods/rpc/request.mjs
class RpcRequest {
    id;
    method;
    params;
    jsonrpc = "2.0";
    constructor(id, method, params) {
        this.id = id;
        this.method = method;
        this.params = params;
    }
    static from(init) {
        const { id, method, params } = init;
        return new RpcRequest(id, method, params);
    }
    toJSON() {
        const { jsonrpc, id, method, params } = this;
        return { jsonrpc, id, method, params };
    }
}


//# sourceMappingURL=request.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/jsonrpc/dist/esm/mods/rpc/rpc.mjs


class RpcCounter {
    id = 0;
    prepare(init) {
        return new RpcRequest(this.id++, init.method, init.params);
    }
}


//# sourceMappingURL=rpc.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/cleaner/dist/esm/libs/unpromise/unpromise.mjs
var Unpromise;
(function (Unpromise) {
    /**
     * Like Promise.all but sync
     * @param callbacks
     * @returns
     */
    function all(callbacks) {
        const results = new Array();
        let error = undefined;
        for (const callback of callbacks) {
            try {
                results.push(callback());
            }
            catch (e) {
                error = { e };
            }
        }
        if (error)
            throw error.e;
        return results;
    }
    Unpromise.all = all;
})(Unpromise || (Unpromise = {}));


//# sourceMappingURL=unpromise.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/cleaner/dist/esm/mods/dispose/dispose.mjs


class Disposer {
    inner;
    dispose;
    constructor(inner, dispose) {
        this.inner = inner;
        this.dispose = dispose;
    }
    static from(disposable) {
        return new Disposer(disposable, () => disposable[Symbol.dispose]());
    }
    [Symbol.dispose]() {
        this.dispose();
    }
}
class AsyncDisposer {
    inner;
    asyncDispose;
    constructor(inner, asyncDispose) {
        this.inner = inner;
        this.asyncDispose = asyncDispose;
    }
    static from(disposable) {
        return new AsyncDisposer(disposable, () => disposable[Symbol.asyncDispose]());
    }
    async [Symbol.asyncDispose]() {
        await this.asyncDispose();
    }
}
class PromiseDisposer {
    inner;
    dispose;
    constructor(inner, dispose) {
        this.inner = inner;
        this.dispose = dispose;
    }
    static from(disposable) {
        return new PromiseDisposer(disposable, () => disposable[Symbol.dispose]());
    }
    then(onfulfilled, onrejected) {
        return this.inner.then(onfulfilled, onrejected);
    }
    [Symbol.dispose]() {
        this.dispose();
    }
}
class AsyncPromiseDisposer {
    inner;
    asyncDispose;
    constructor(inner, asyncDispose) {
        this.inner = inner;
        this.asyncDispose = asyncDispose;
    }
    static from(disposable) {
        return new PromiseDisposer(disposable, () => disposable[Symbol.asyncDispose]());
    }
    then(onfulfilled, onrejected) {
        return this.inner.then(onfulfilled, onrejected);
    }
    async [Symbol.asyncDispose]() {
        await this.asyncDispose();
    }
}
var Disposable;
(function (Disposable) {
    async function dispose(disposable) {
        if (Symbol.dispose in disposable)
            disposable[Symbol.dispose]();
        else if (Symbol.asyncDispose)
            await disposable[Symbol.asyncDispose]();
    }
    Disposable.dispose = dispose;
    function disposeSync(disposable) {
        disposable[Symbol.dispose]();
    }
    Disposable.disposeSync = disposeSync;
    async function race(promises) {
        try {
            return await Promise.race(promises);
        }
        finally {
            await Promise.all(promises.map(dispose));
        }
    }
    Disposable.race = race;
    async function raceSync(promises) {
        try {
            return await Promise.race(promises);
        }
        finally {
            Unpromise.all(promises.map(it => () => disposeSync(it)));
        }
    }
    Disposable.raceSync = raceSync;
})(Disposable || (Disposable = {}));


//# sourceMappingURL=dispose.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/plume/dist/esm/mods/errors.mjs





class AbortedError extends Error {
    #class = AbortedError;
    name = this.#class.name;
    static from(cause) {
        return new AbortedError(`Aborted`, { cause });
    }
    static wait(signal) {
        const future = new Future();
        const onAbort = (event) => {
            future.resolve(new err_Err(AbortedError.from(event)));
        };
        signal.addEventListener("abort", onAbort, { passive: true });
        const off = () => signal.removeEventListener("abort", onAbort);
        return new PromiseDisposer(future.promise, off);
    }
}
class ErroredError extends Error {
    #class = ErroredError;
    name = this.#class.name;
    static from(cause) {
        return new ErroredError(`Errored`, { cause });
    }
    static wait(target) {
        return target.wait("error", (future, event) => {
            const error = ErroredError.from(event);
            future.resolve(new err_Err(error));
            return new None();
        });
    }
}
class ClosedError extends Error {
    #class = ClosedError;
    name = this.#class.name;
    static from(cause) {
        return new ClosedError(`Closed`, { cause });
    }
    static wait(target) {
        return target.wait("close", (future, event) => {
            const error = ClosedError.from(event);
            future.resolve(new err_Err(error));
            return new None();
        });
    }
}


//# sourceMappingURL=errors.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/plume/dist/esm/mods/waiters.mjs



async function tryWaitOrSignal(target, type, callback, signal) {
    const abort = AbortedError.wait(signal);
    const event = target.wait(type, callback);
    return await Disposable.raceSync([abort, event]);
}
async function tryWaitOrCloseOrError(target, type, callback) {
    const error = ErroredError.wait(target);
    const close = ClosedError.wait(target);
    const event = target.wait(type, callback);
    return await Disposable.raceSync([error, close, event]);
}
async function tryWaitOrCloseOrErrorOrSignal(target, type, callback, signal) {
    const abort = AbortedError.wait(signal);
    const error = ErroredError.wait(target);
    const close = ClosedError.wait(target);
    const event = target.wait(type, callback);
    return await Disposable.raceSync([abort, error, close, event]);
}


//# sourceMappingURL=waiters.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/plume/dist/esm/mods/target.mjs




class EventError extends (/* unused pure expression or super */ null && (Error)) {
    #class = EventError;
    name = this.#class.name;
    constructor(cause) {
        super(`Event failed`, { cause });
    }
    static new(cause) {
        return new EventError(cause);
    }
}
class SuperEventTarget {
    #listeners = new Map();
    get listeners() {
        return this.#listeners;
    }
    /**
     * Add a listener to an event
     * @param type Event type //  "abort", "error", "message", "close"
     * @param listener Event listener // (e) => new Some(123)
     * @param options Options // { passive: true }
     * @returns
     */
    on(type, listener, options = {}) {
        let listeners = this.#listeners.get(type);
        if (listeners === undefined) {
            listeners = new Map();
            this.#listeners.set(type, listeners);
        }
        const off = () => this.off(type, listener);
        const internalOptions = { ...options, off };
        internalOptions.signal?.addEventListener("abort", off, { passive: true });
        listeners.set(listener, internalOptions);
        return off;
    }
    /**
     * Remove a listener from an event
     * @param type Event type //  "abort", "error", "message", "close"
     * @param listener Event listener // (e) => console.log("hello")
     * @param options Just to look like DOM's EventTarget
     * @returns
     */
    off(type, listener) {
        const listeners = this.#listeners.get(type);
        if (!listeners)
            return;
        const options = listeners.get(listener);
        if (!options)
            return;
        options.signal?.removeEventListener("abort", options.off);
        listeners.delete(listener);
        if (listeners.size > 0)
            return;
        this.#listeners.delete(type);
    }
    /**
     * Dispatch an event to its listeners
     *
     * - Dispatch to active listeners sequencially
     * - Return if one of the listeners returned something
     * - Dispatch to passive listeners concurrently
     * - Return if one of the listeners returned something
     * - Return nothing
     * @param value The object to emit
     * @returns `Some` if the event
     */
    async emit(type, value) {
        const listeners = this.#listeners.get(type);
        if (!listeners)
            return new None();
        const promises = new Array();
        for (const [listener, options] of listeners) {
            if (options.passive)
                continue;
            if (options.once)
                this.off(type, listener);
            const returned = await listener(...value);
            if (returned.isNone())
                continue;
            return returned;
        }
        for (const [listener, options] of listeners) {
            if (!options.passive)
                continue;
            if (options.once)
                this.off(type, listener);
            const returned = listener(...value);
            if (returned instanceof Promise) {
                promises.push(returned);
                continue;
            }
            if (returned.isNone())
                continue;
            return returned;
        }
        const returneds = await Promise.all(promises);
        for (const returned of returneds)
            if (returned.isSome())
                return returned;
        return new None();
    }
    /**
     * Like `.on`, but instead of returning to the target, capture the returned value in a future, and return nothing to the target
     * @param type
     * @param callback
     * @returns
     */
    wait(type, callback) {
        const future = new Future();
        const onEvent = async (...params) => {
            try {
                return await callback(future, ...params);
            }
            catch (e) {
                future.reject(e);
                throw e;
            }
        };
        const off = this.on(type, onEvent, { passive: true });
        return new PromiseDisposer(future.promise, off);
    }
}


//# sourceMappingURL=target.mjs.map

;// CONCATENATED MODULE: ./src/libs/channel/channel.ts





class WebsitePort {
    [Symbol.dispose]() {
        this.clean();
    }
    async runPingLoop() {
        let count = 0;
        while(true){
            await new Promise((ok)=>setTimeout(ok, 1000));
            const result = await this.tryPingOrSignal(AbortSignal.timeout(1000)).then((r)=>r.flatten());
            if (result.isErr()) count++;
            else count = 0;
            if (count === 2) {
                await this.events.emit("close", [
                    undefined
                ]);
                return;
            }
        }
    }
    async tryRouteRequest(request) {
        if (request.method === "brume_ping") return ok_Ok.void();
        const returned = await this.events.emit("request", [
            request
        ]);
        if (returned.isSome()) return returned.inner;
        return new err_Err(new Error("Unhandled JSON-RPC request ".concat(JSON.stringify(request))));
    }
    async onRequest(request) {
        // if (request.id !== "ping")
        //   console.debug(this.name, "->", request)
        const result = await this.tryRouteRequest(request);
        const response = RpcResponse.rewrap(request.id, result);
        // if (request.id !== "ping")
        //   console.debug(this.name, "<-", response)
        this.port.postMessage(JSON.stringify(response));
    }
    async onResponse(response) {
        // if (response.id !== "ping")
        //   console.debug(this.name, "->", response)
        const returned = await this.events.emit("response", [
            response
        ]);
        if (returned.isSome()) return returned.inner;
        return new err_Err(new Error("Unhandled JSON-RPC response ".concat(JSON.stringify(response))));
    }
    async onMessage(message) {
        const data = JSON.parse(message.data);
        if ("method" in data) return await this.onRequest(data);
        return await this.onResponse(data);
    }
    async tryRequest(init) {
        const request = this.counter.prepare(init);
        // if (request.id !== "ping")
        //   console.debug(this.name, "<-", request)
        this.port.postMessage(JSON.stringify(request));
        return tryWaitOrCloseOrError(this.events, "response", (future, init)=>{
            if (init.id !== request.id) return new None();
            const response = RpcResponse.from(init);
            future.resolve(new ok_Ok(response));
            return new Some(undefined);
        });
    }
    async tryPingOrSignal(signal) {
        const request = {
            id: "ping",
            method: "brume_ping"
        };
        this.port.postMessage(JSON.stringify(request));
        return tryWaitOrCloseOrErrorOrSignal(this.events, "response", (future, init)=>{
            if (init.id !== request.id) return new None();
            const response = RpcResponse.from(init);
            future.resolve(new ok_Ok(response));
            return new Some(undefined);
        }, signal);
    }
    constructor(name, port){
        this.counter = new RpcCounter();
        this.uuid = crypto.randomUUID();
        this.events = new SuperEventTarget();
        this.name = name;
        this.port = port;
        const onMessage = this.onMessage.bind(this);
        this.port.addEventListener("message", onMessage, {
            passive: true
        });
        this.clean = ()=>{
            this.port.removeEventListener("message", onMessage);
        };
    }
}
class ExtensionPort {
    [Symbol.dispose]() {
        this.clean();
    }
    async tryRouteRequest(request) {
        if (request.method === "brume_ping") return ok_Ok.void();
        const returned = await this.events.emit("request", [
            request
        ]);
        if (returned.isSome()) return returned.inner;
        return new err_Err(new Error("Unhandled JSON-RPC request ".concat(JSON.stringify(request))));
    }
    async onRequest(request) {
        if (request.id !== "ping") console.debug(this.name, "->", request);
        const result = await this.tryRouteRequest(request);
        const response = RpcResponse.rewrap(request.id, result);
        if (request.id !== "ping") console.debug(this.name, "<-", response);
        tryBrowserSync(()=>{
            this.port.postMessage(JSON.stringify(response));
        }).ignore();
    }
    async onResponse(response) {
        if (response.id !== "ping") console.debug(this.name, "->", response);
        const returned = await this.events.emit("response", [
            response
        ]);
        if (returned.isSome()) return returned.inner;
        return new err_Err(new Error("Unhandled JSON-RPC response ".concat(JSON.stringify(response))));
    }
    async onMessage(message) {
        const data = JSON.parse(message);
        if ("method" in data) return await this.onRequest(data);
        return await this.onResponse(data);
    }
    async onDisconnect() {
        await this.events.emit("close", [
            undefined
        ]);
    }
    async tryRequest(init) {
        return await Result.unthrow(async (t)=>{
            const request = this.counter.prepare(init);
            if (request.id !== "ping") console.debug(this.name, "<-", request);
            tryBrowserSync(()=>{
                this.port.postMessage(JSON.stringify(request));
            }).throw(t);
            return tryWaitOrCloseOrError(this.events, "response", (future, init)=>{
                if (init.id !== request.id) return new None();
                const response = RpcResponse.from(init);
                future.resolve(new ok_Ok(response));
                return new Some(undefined);
            });
        });
    }
    constructor(name, port){
        this.counter = new RpcCounter();
        this.uuid = crypto.randomUUID();
        this.events = new SuperEventTarget();
        this.name = name;
        this.port = port;
        const onMessage = this.onMessage.bind(this);
        const onDisconnect = this.onDisconnect.bind(this);
        this.port.onMessage.addListener(onMessage);
        this.port.onDisconnect.addListener(onDisconnect);
        this.clean = ()=>{
            this.port.onMessage.removeListener(onMessage);
            this.port.onDisconnect.removeListener(onDisconnect);
        };
    }
}

;// CONCATENATED MODULE: ./src/libs/fetch/fetch.ts

async function tryFetch(input, init) {
    try {
        const res = await fetch(input, init);
        if (!res.ok) return new Err(new Error(await res.text()));
        return new Ok(res);
    } catch (e) {
        return new Err(Catched.from(e));
    }
}
async function tryFetchAsJson(input, init) {
    try {
        const res = await fetch(input, init);
        if (!res.ok) return new err_Err(new Error(await res.text()));
        return new ok_Ok(await res.json());
    } catch (e) {
        return new err_Err(errors_Catched.from(e));
    }
}
async function tryFetchAsBlob(input, init) {
    try {
        const res = await fetch(input, init);
        if (!res.ok) return new err_Err(new Error(await res.text()));
        return new ok_Ok(await res.blob());
    } catch (e) {
        return new err_Err(errors_Catched.from(e));
    }
}

;// CONCATENATED MODULE: ./node_modules/@hazae41/arrays/dist/esm/mods/arrays/arrays.mjs
/**
 * Get the last value
 * @param array
 * @returns
 */
function last(array) {
    if (array.length === 0)
        return undefined;
    return array[lastIndex(array)];
}
/**
 * Get the last index
 * @param array
 * @returns
 */
function lastIndex(array) {
    return array.length - 1;
}
/**
 * Get a random value using Math's PRNG
 * @param array
 * @returns
 */
function random(array) {
    if (array.length === 0)
        return undefined;
    return array[randomIndex(array)];
}
/**
 * Get a random index using Math's PRNG
 * @param array
 * @returns
 */
function randomIndex(array) {
    return Math.floor(Math.random() * array.length);
}
/**
 * Get a random value using WebCrypto's CSPRNG
 * @param array
 * @returns
 */
function cryptoRandom(array) {
    if (array.length === 0)
        return undefined;
    return array[cryptoRandomIndex(array)];
}
/**
 * Get a random value using WebCrypto's CSPRNG
 * @param array
 * @returns
 */
function cryptoRandomIndex(array) {
    const values = new Uint32Array(1);
    crypto.getRandomValues(values);
    return values[0] % array.length;
}
/**
 * Get a random value using Math's PRNG and delete it from the array
 * @param array
 * @returns
 */
function takeRandom(array) {
    if (array.length === 0)
        return undefined;
    const index = randomIndex(array);
    const element = array[index];
    array.splice(index, 1);
    return element;
}
/**
 * Get a random value using WebCrypto's CSPRNG and delete it from the array
 * @param array
 * @returns
 */
function takeCryptoRandom(array) {
    if (array.length === 0)
        return undefined;
    const index = cryptoRandomIndex(array);
    const element = array[index];
    array.splice(index, 1);
    return element;
}


//# sourceMappingURL=arrays.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/mutex/dist/esm/mods/mutex/mutex.mjs



class MutexLockError extends Error {
    #class = MutexLockError;
    name = this.#class.name;
    constructor() {
        super(`Could not lock mutex`);
    }
}
class Mutex {
    inner;
    promise;
    /**
     * Just a mutex
     */
    constructor(inner) {
        this.inner = inner;
    }
    get locked() {
        return this.promise != null;
    }
    acquire() {
        const future = new Future();
        const promise = this.promise;
        this.lock(() => future.promise);
        const release = () => future.resolve();
        const access = new Lock(this.inner, release);
        return promise
            ? promise.then(() => access)
            : access;
    }
    /**
     * Lock this mutex
     * @param callback
     * @returns
     */
    lock(callback) {
        const promise = this.promise
            ? this.promise.then(() => callback(this.inner))
            : callback(this.inner);
        const pure = promise
            .then(() => { })
            .catch(() => { });
        this.promise = pure;
        pure.finally(() => {
            if (this.promise !== pure)
                return;
            this.promise = undefined;
        });
        return promise;
    }
    /**
     * Try to lock this mutex
     * @param callback
     * @returns
     */
    tryLock(callback) {
        if (this.promise != null)
            return new err_Err(new MutexLockError());
        const promise = callback(this.inner);
        const pure = promise
            .then(() => { })
            .catch(() => { });
        this.promise = pure;
        pure.finally(() => {
            if (this.promise !== pure)
                return;
            this.promise = undefined;
        });
        return new ok_Ok(promise);
    }
}
class Lock {
    inner;
    release;
    constructor(inner, release) {
        this.inner = inner;
        this.release = release;
    }
    [Symbol.dispose]() {
        this.release();
    }
}


//# sourceMappingURL=mutex.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/piscine/dist/esm/libs/signals/signals.mjs
var AbortSignals;
(function (AbortSignals) {
    function never() {
        return new AbortController().signal;
    }
    AbortSignals.never = never;
    function timeout(delay, parent) {
        return merge(AbortSignal.timeout(delay), parent);
    }
    AbortSignals.timeout = timeout;
    function merge(a, b) {
        if (b === undefined)
            return a;
        const c = new AbortController();
        const onAbort = (reason) => {
            c.abort(reason);
            a.removeEventListener("abort", onAbort);
            b.removeEventListener("abort", onAbort);
        };
        a.addEventListener("abort", onAbort, { passive: true });
        b.addEventListener("abort", onAbort, { passive: true });
        return c.signal;
    }
    AbortSignals.merge = merge;
})(AbortSignals || (AbortSignals = {}));


//# sourceMappingURL=signals.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/piscine/dist/esm/mods/pool/pool.mjs








var PoolOkEntry;
(function (PoolOkEntry) {
    function is(x) {
        return x.result.isOk();
    }
    PoolOkEntry.is = is;
})(PoolOkEntry || (PoolOkEntry = {}));
class EmptyPoolError extends Error {
    #class = EmptyPoolError;
    name = this.#class.name;
    constructor() {
        super(`Empty pool`);
    }
}
class EmptySlotError extends Error {
    #class = EmptySlotError;
    name = this.#class.name;
    constructor() {
        super(`Empty pool slot`);
    }
}
class Pool {
    creator;
    params;
    #capacity;
    events = new SuperEventTarget();
    signal;
    #controller;
    mutex = new Mutex(undefined);
    /**
     * Entry by index, can be sparse
     */
    #allEntries;
    /**
     * Promise by index, can be sparse
     */
    #allPromises;
    /**
     * Entries that are ok
     */
    #okEntries = new Set();
    /**
     * Promises that are started (running or settled)
     */
    #okPromises = new Set();
    /**
     * A pool of circuits
     * @param tor
     * @param params
     */
    constructor(creator, params = {}) {
        this.creator = creator;
        this.params = params;
        const { capacity = 3 } = params;
        this.#capacity = capacity;
        this.#controller = new AbortController();
        this.signal = AbortSignals.merge(this.#controller.signal, params.signal);
        this.#allEntries = new Array(capacity);
        this.#allPromises = new Array(capacity);
        for (let index = 0; index < capacity; index++)
            this.#start(index).catch(console.warn);
    }
    /**
     * Whether all entries are errored
     */
    get stagnant() {
        return this.#allEntries.every(entry => entry.result.isErr());
    }
    abort(reason) {
        this.#controller.abort(reason);
    }
    async #start(index) {
        const promise = this.#createAndUnwrap(index);
        this.#allPromises[index] = promise;
        this.#okPromises.add(promise);
        /**
         * Set promise as handled
         */
        promise.catch(() => { });
        await this.events.emit("started", [index]);
    }
    async #tryCreate(index) {
        const { signal } = this;
        if (signal.aborted)
            return new err_Err(AbortedError.from(signal.reason));
        return await this.creator({ pool: this, index, signal });
    }
    async #createAndUnwrap(index) {
        const result = await Result.runAndDoubleWrap(() => {
            return this.#tryCreate(index);
        }).then(Result.flatten);
        if (result.isOk()) {
            const entry = { index, result };
            this.#allEntries[index] = entry;
            this.#okEntries.add(entry);
            await this.events.emit("created", [entry]);
            return entry;
        }
        else {
            const entry = { index, result };
            this.#allEntries[index] = entry;
            await this.events.emit("created", [entry]);
            throw result.inner;
        }
    }
    async #delete(index) {
        const entry = this.#allEntries.at(index);
        if (entry == null)
            return undefined;
        const promise = this.#allPromises.at(index);
        if (promise == null)
            throw Panic.from(new Error(`Promise is null`));
        this.#okPromises.delete(promise);
        delete this.#allPromises[index];
        if (PoolOkEntry.is(entry)) {
            await Disposable.dispose(entry.result.inner);
            this.#okEntries.delete(entry);
        }
        delete this.#allEntries[index];
        await this.events.emit("deleted", [entry]);
        return entry;
    }
    /**
     * Restart the index and return the previous entry
     * @param element
     * @returns
     */
    async restart(index) {
        return await this.mutex.lock(async () => {
            const entry = await this.#delete(index);
            await this.#start(index);
            return entry;
        });
    }
    /**
     * Modify capacity
     * @param capacity
     * @returns
     */
    async growOrShrink(capacity) {
        return await this.mutex.lock(async () => {
            if (capacity > this.#capacity) {
                const previous = this.#capacity;
                this.#capacity = capacity;
                for (let i = previous; i < capacity; i++)
                    await this.#start(i);
                return previous;
            }
            else if (capacity < this.#capacity) {
                const previous = this.#capacity;
                this.#capacity = capacity;
                for (let i = capacity; i < previous; i++)
                    await this.#delete(i);
                return previous;
            }
            return this.#capacity;
        });
    }
    /**
     * Number of open elements
     */
    get size() {
        return this.#okEntries.size;
    }
    /**
     * Number of slots
     */
    get capacity() {
        return this.#capacity;
    }
    /**
     * Iterator on open elements
     * @returns
     */
    [Symbol.iterator]() {
        return this.#okEntries.values();
    }
    /**
     * Get the element at index, if still loading, wait for it, if not started, wait for started until signal, and wait for it
     * @param index
     * @param signal
     * @returns
     */
    async tryGetOrWait(index, signal = AbortSignals.never()) {
        const current = await this.tryGet(index);
        if (current.isOk())
            return current.inner;
        const aborted = await tryWaitOrSignal(this.events, "started", (future, i) => {
            if (i !== index)
                return new None();
            future.resolve(ok_Ok.void());
            return new None();
        }, signal);
        if (aborted.isErr())
            return aborted;
        return await this.tryGet(index).then(r => r.unwrap());
    }
    /**
     * Get the element at index, if still loading, wait for it, err if not started
     * @param index
     * @returns
     */
    async tryGet(index) {
        await this.mutex.promise;
        const slot = this.#allPromises.at(index);
        if (slot === undefined)
            return new err_Err(new EmptySlotError());
        try {
            return new ok_Ok(await slot.then(r => r.result));
        }
        catch (e) {
            return new ok_Ok(new err_Err(e));
        }
    }
    /**
     * Get the element at index, err if empty
     * @param index
     * @returns
     */
    async tryGetSync(index) {
        await this.mutex.promise;
        const slot = this.#allEntries.at(index);
        if (slot === undefined)
            return new err_Err(new EmptySlotError());
        return new ok_Ok(slot.result);
    }
    /**
     * Wait for any element to be created, then get a random one using Math's PRNG
     * @returns
     */
    async tryGetRandom() {
        await this.mutex.promise;
        const first = await Result
            .runAndWrap(() => Promise.any(this.#okPromises))
            .then(r => r.mapErrSync(e => e));
        if (first.isErr())
            return first;
        const random = await this.tryGetRandomSync();
        if (random.isOk())
            return random;
        /**
         * The element has been deleted already?
         */
        console.error(`Could not get random element`, { first });
        throw Panic.from(new Error(`Could not get random element`));
    }
    /**
     * Get a random element from the pool using Math's PRNG, throws if none available
     * @returns
     */
    async tryGetRandomSync() {
        await this.mutex.promise;
        if (this.#okEntries.size === 0)
            return new err_Err(new EmptyPoolError());
        const entries = [...this.#okEntries];
        const entry = random(entries);
        return new ok_Ok(entry);
    }
    /**
     * Wait for any element to be created, then get a random one using WebCrypto's CSPRNG
     * @returns
     */
    async tryGetCryptoRandom() {
        await this.mutex.promise;
        const first = await Result
            .runAndWrap(() => Promise.any(this.#okPromises))
            .then(r => r.mapErrSync(e => e));
        if (first.isErr())
            return first;
        const random = await this.tryGetCryptoRandomSync();
        if (random.isOk())
            return random;
        /**
         * The element has been deleted already?
         */
        console.error(`Could not get random element`, { first });
        throw Panic.from(new Error(`Could not get random element`));
    }
    /**
     * Get a random element from the pool using WebCrypto's CSPRNG, throws if none available
     * @returns
     */
    async tryGetCryptoRandomSync() {
        await this.mutex.promise;
        if (this.#okEntries.size === 0)
            return new err_Err(new EmptyPoolError());
        const entries = [...this.#okEntries];
        const entry = cryptoRandom(entries);
        return new ok_Ok(entry);
    }
    static async takeRandom(pool) {
        return await pool.lock(async (pool) => {
            const result = await pool.tryGetRandom();
            if (result.isOk())
                pool.restart(result.inner.index);
            return result;
        });
    }
    static async takeCryptoRandom(pool) {
        return await pool.lock(async (pool) => {
            const result = await pool.tryGetCryptoRandom();
            if (result.isOk())
                pool.restart(result.inner.index);
            return result;
        });
    }
}


//# sourceMappingURL=pool.mjs.map

;// CONCATENATED MODULE: ./src/mods/background/content_script/index.ts










const mouse = {
    x: window.screen.width / 2,
    y: window.screen.height / 2
};
addEventListener("mousemove", (e)=>{
    mouse.x = e.screenX;
    mouse.y = e.screenY;
}, {
    passive: true
});
if (IS_FIREFOX || IS_SAFARI) {
    const container = document.documentElement;
    const scriptBody = atob("LyoqKioqKi8gKCgpID0+IHsgLy8gd2VicGFja0Jvb3RzdHJhcAovKioqKioqLyAJInVzZSBzdHJpY3QiOwp2YXIgX193ZWJwYWNrX2V4cG9ydHNfXyA9IHt9OwoKOy8vIENPTkNBVEVOQVRFRCBNT0RVTEU6IC4vbm9kZV9tb2R1bGVzL0BoYXphZTQxL3N5bWJvbC1kaXNwb3NlLXBvbHlmaWxsL2Rpc3QvZXNtL21vZHMvc3ltYm9sLWRpc3Bvc2UtcG9seWZpbGwvcG9seWZpbGwubWpzCmlmICh0eXBlb2YgU3ltYm9sLmRpc3Bvc2UgIT09ICJzeW1ib2wiKQogICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KFN5bWJvbCwgImRpc3Bvc2UiLCB7CiAgICAgICAgY29uZmlndXJhYmxlOiBmYWxzZSwKICAgICAgICBlbnVtZXJhYmxlOiBmYWxzZSwKICAgICAgICB3cml0YWJsZTogZmFsc2UsCiAgICAgICAgdmFsdWU6IFN5bWJvbC5mb3IoImRpc3Bvc2UiKQogICAgfSk7CmlmICh0eXBlb2YgU3ltYm9sLmFzeW5jRGlzcG9zZSAhPT0gInN5bWJvbCIpCiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoU3ltYm9sLCAiYXN5bmNEaXNwb3NlIiwgewogICAgICAgIGNvbmZpZ3VyYWJsZTogZmFsc2UsCiAgICAgICAgZW51bWVyYWJsZTogZmFsc2UsCiAgICAgICAgd3JpdGFibGU6IGZhbHNlLAogICAgICAgIHZhbHVlOiBTeW1ib2wuZm9yKCJhc3luY0Rpc3Bvc2UiKQogICAgfSk7Ci8vIyBzb3VyY2VNYXBwaW5nVVJMPXBvbHlmaWxsLm1qcy5tYXAKCjsvLyBDT05DQVRFTkFURUQgTU9EVUxFOiAuL25vZGVfbW9kdWxlcy9AaGF6YWU0MS9zeW1ib2wtZGlzcG9zZS1wb2x5ZmlsbC9kaXN0L2VzbS9pbmRleC5tanMKCi8vIyBzb3VyY2VNYXBwaW5nVVJMPWluZGV4Lm1qcy5tYXAKCjsvLyBDT05DQVRFTkFURUQgTU9EVUxFOiAuL25vZGVfbW9kdWxlcy9AaGF6YWU0MS9mdXR1cmUvZGlzdC9lc20vbW9kcy9mdXR1cmUvZnV0dXJlLm1qcwpjbGFzcyBGdXR1cmUgewogICAgI3Jlc29sdmU7CiAgICAjcmVqZWN0OwogICAgcHJvbWlzZTsKICAgIC8qKgogICAgICogSnVzdCBsaWtlIGEgUHJvbWlzZSBidXQgeW91IGNhbiBtYW51YWxseSByZXNvbHZlIG9yIHJlamVjdCBpdAogICAgICovCiAgICBjb25zdHJ1Y3RvcigpIHsKICAgICAgICB0aGlzLnByb21pc2UgPSBuZXcgUHJvbWlzZSgoc3VicmVzb2x2ZSwgc3VicmVqZWN0KSA9PiB7CiAgICAgICAgICAgIHRoaXMuI3Jlc29sdmUgPSBzdWJyZXNvbHZlOwogICAgICAgICAgICB0aGlzLiNyZWplY3QgPSBzdWJyZWplY3Q7CiAgICAgICAgfSk7CiAgICB9CiAgICBnZXQgcmVzb2x2ZSgpIHsKICAgICAgICByZXR1cm4gdGhpcy4jcmVzb2x2ZTsKICAgIH0KICAgIGdldCByZWplY3QoKSB7CiAgICAgICAgcmV0dXJuIHRoaXMuI3JlamVjdDsKICAgIH0KfQoKCi8vIyBzb3VyY2VNYXBwaW5nVVJMPWZ1dHVyZS5tanMubWFwCgo7Ly8gQ09OQ0FURU5BVEVEIE1PRFVMRTogLi9ub2RlX21vZHVsZXMvQGhhemFlNDEvcmVzdWx0L2Rpc3QvZXNtL21vZHMvcmVzdWx0L2Vycm9ycy5tanMKCgpjbGFzcyBVbmltcGxlbWVudGVkIGV4dGVuZHMgKC8qIHVudXNlZCBwdXJlIGV4cHJlc3Npb24gb3Igc3VwZXIgKi8gbnVsbCAmJiAoRXJyb3IpKSB7CiAgICAjY2xhc3MgPSBVbmltcGxlbWVudGVkOwogICAgbmFtZSA9IHRoaXMuI2NsYXNzLm5hbWU7CiAgICBjb25zdHJ1Y3RvcihvcHRpb25zKSB7CiAgICAgICAgc3VwZXIoYFNvbWV0aGluZyBpcyBub3QgaW1wbGVtZW50ZWRgLCBvcHRpb25zKTsKICAgIH0KfQpjbGFzcyBBc3NlcnRFcnJvciBleHRlbmRzIEVycm9yIHsKICAgICNjbGFzcyA9IEFzc2VydEVycm9yOwogICAgbmFtZSA9IHRoaXMuI2NsYXNzLm5hbWU7CiAgICBjb25zdHJ1Y3RvcihvcHRpb25zKSB7CiAgICAgICAgc3VwZXIoYFNvbWUgYXNzZXJ0aW9uIGZhaWxlZGAsIG9wdGlvbnMpOwogICAgfQp9CmNsYXNzIFBhbmljIGV4dGVuZHMgRXJyb3IgewogICAgI2NsYXNzID0gUGFuaWM7CiAgICBuYW1lID0gdGhpcy4jY2xhc3MubmFtZTsKICAgIGNvbnN0cnVjdG9yKG9wdGlvbnMpIHsKICAgICAgICBzdXBlcihgU29tZXRoaW5nIHdhcyBub3QgZXhwZWN0ZWRgLCBvcHRpb25zKTsKICAgIH0KICAgIHN0YXRpYyBmcm9tKGNhdXNlKSB7CiAgICAgICAgcmV0dXJuIG5ldyBQYW5pYyh7IGNhdXNlIH0pOwogICAgfQogICAgc3RhdGljIGZyb21BbmRUaHJvdyhjYXVzZSkgewogICAgICAgIHRocm93IG5ldyBQYW5pYyh7IGNhdXNlIH0pOwogICAgfQp9CmNsYXNzIENhdGNoZWQgZXh0ZW5kcyBFcnJvciB7CiAgICAjY2xhc3MgPSBDYXRjaGVkOwogICAgbmFtZSA9IHRoaXMuI2NsYXNzLm5hbWU7CiAgICBjb25zdHJ1Y3RvcihvcHRpb25zKSB7CiAgICAgICAgc3VwZXIoYFNvbWV0aGluZyBoYXMgYmVlbiBjYXRjaGVkYCwgb3B0aW9ucyk7CiAgICB9CiAgICBzdGF0aWMgZnJvbShjYXVzZSkgewogICAgICAgIHJldHVybiBuZXcgQ2F0Y2hlZCh7IGNhdXNlIH0pOwogICAgfQogICAgc3RhdGljIGZyb21BbmRUaHJvdyhjYXVzZSkgewogICAgICAgIHRocm93IG5ldyBDYXRjaGVkKHsgY2F1c2UgfSk7CiAgICB9CiAgICAvKioKICAgICAqIFRocm93IGlmIGBDYXRjaGVkYCwgd3JhcCBpbiBgRXJyYCBvdGhlcndpc2UKICAgICAqIEBwYXJhbSBlcnJvcgogICAgICogQHJldHVybnMgYEVycihlcnJvcilgIGlmIG5vdCBgQ2F0Y2hlZGAKICAgICAqIEB0aHJvd3MgYGVycm9yLmNhdXNlYCBpZiBgQ2F0Y2hlZGAKICAgICAqLwogICAgc3RhdGljIHRocm93T3JFcnIoZXJyb3IpIHsKICAgICAgICBpZiAoZXJyb3IgaW5zdGFuY2VvZiBDYXRjaGVkKQogICAgICAgICAgICB0aHJvdyBlcnJvci5jYXVzZTsKICAgICAgICByZXR1cm4gbmV3IEVycihlcnJvcik7CiAgICB9Cn0KCgovLyMgc291cmNlTWFwcGluZ1VSTD1lcnJvcnMubWpzLm1hcAoKOy8vIENPTkNBVEVOQVRFRCBNT0RVTEU6IC4vbm9kZV9tb2R1bGVzL0BoYXphZTQxL29wdGlvbi9kaXN0L2VzbS9tb2RzL29wdGlvbi9ub25lLm1qcwoKCmNsYXNzIE5vbmVFcnJvciBleHRlbmRzIEVycm9yIHsKICAgIGNvbnN0cnVjdG9yKCkgewogICAgICAgIHN1cGVyKGBPcHRpb24gaXMgYSBOb25lYCk7CiAgICB9Cn0KY2xhc3MgTm9uZSB7CiAgICBpbm5lcjsKICAgIC8qKgogICAgICogQW4gZW1wdHkgdmFsdWUKICAgICAqLwogICAgY29uc3RydWN0b3IoaW5uZXIgPSB1bmRlZmluZWQpIHsKICAgICAgICB0aGlzLmlubmVyID0gaW5uZXI7CiAgICB9CiAgICAvKioKICAgICAqIENyZWF0ZSBhIGBOb25lYAogICAgICogQHJldHVybnMgYE5vbmVgCiAgICAgKi8KICAgIHN0YXRpYyBuZXcoKSB7CiAgICAgICAgcmV0dXJuIG5ldyBOb25lKCk7CiAgICB9CiAgICBzdGF0aWMgZnJvbShpbml0KSB7CiAgICAgICAgcmV0dXJuIG5ldyBOb25lKCk7CiAgICB9CiAgICAvKioKICAgICAqIFR5cGUgZ3VhcmQgZm9yIGBTb21lYAogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBTb21lYCwgYGZhbHNlYCBpZiBgTm9uZWAKICAgICAqLwogICAgaXNTb21lKCkgewogICAgICAgIHJldHVybiBmYWxzZTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBgdHJ1ZWAgaWYgdGhlIG9wdGlvbiBpcyBhIGBTb21lYCBhbmQgdGhlIHZhbHVlIGluc2lkZSBvZiBpdCBtYXRjaGVzIGEgcHJlZGljYXRlCiAgICAgKiBAcGFyYW0gc29tZVByZWRpY2F0ZQogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBTb21lYCBhbmQgYGF3YWl0IHNvbWVQcmVkaWNhdGUodGhpcy5pbm5lcilgLCBgTm9uZWAgb3RoZXJ3aXNlCiAgICAgKi8KICAgIGFzeW5jIGlzU29tZUFuZChzb21lUHJlZGljYXRlKSB7CiAgICAgICAgcmV0dXJuIGZhbHNlOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGB0cnVlYCBpZiB0aGUgb3B0aW9uIGlzIGEgYFNvbWVgIGFuZCB0aGUgdmFsdWUgaW5zaWRlIG9mIGl0IG1hdGNoZXMgYSBwcmVkaWNhdGUKICAgICAqIEBwYXJhbSBzb21lUHJlZGljYXRlCiAgICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYFNvbWVgIGFuZCBgc29tZVByZWRpY2F0ZSh0aGlzLmlubmVyKWAsIGBOb25lYCBvdGhlcndpc2UKICAgICAqLwogICAgaXNTb21lQW5kU3luYyhzb21lUHJlZGljYXRlKSB7CiAgICAgICAgcmV0dXJuIGZhbHNlOwogICAgfQogICAgLyoqCiAgICAgKiBUeXBlIGd1YXJkIGZvciBgTm9uZWAKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgTm9uZWAsIGBmYWxzZWAgaWYgYFNvbWVgCiAgICAgKi8KICAgIGlzTm9uZSgpIHsKICAgICAgICByZXR1cm4gdHJ1ZTsKICAgIH0KICAgIC8qKgogICAgICogQ29tcGlsZS10aW1lIHNhZmVseSBnZXQgYHRoaXMuaW5uZXJgCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAKICAgICAqLwogICAgZ2V0KCkgewogICAgICAgIHJldHVybiB0aGlzLmlubmVyOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGFuIGl0ZXJhdG9yIG92ZXIgdGhlIHBvc3NpYmx5IGNvbnRhaW5lZCB2YWx1ZQogICAgICogQHlpZWxkcyBgdGhpcy5pbm5lcmAgaWYgYFNvbWVgCiAgICAgKi8KICAgICpbU3ltYm9sLml0ZXJhdG9yXSgpIHsKICAgICAgICByZXR1cm47CiAgICB9CiAgICAvKioKICAgICAqIEdldCB0aGUgaW5uZXIgdmFsdWUgaWYgYFNvbWVgLCB0aHJvdyBgRXJyb3IobWVzc2FnZSlgIG90aGVyd2lzZQogICAgICogQHBhcmFtIG1lc3NhZ2UKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgU29tZWAKICAgICAqIEB0aHJvd3MgYEVycm9yKG1lc3NhZ2UpYCBpZiBgTm9uZWAKICAgICAqLwogICAgZXhwZWN0KG1lc3NhZ2UpIHsKICAgICAgICB0aHJvdyBQYW5pYy5mcm9tKG5ldyBFcnJvcihtZXNzYWdlLCB7IGNhdXNlOiB0aGlzIH0pKTsKICAgIH0KICAgIC8qKgogICAgICogR2V0IHRoZSBpbm5lciB2YWx1ZSBvciB0aHJvdyBhIE5vbmVFcnJvcgogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBTb21lYAogICAgICogQHRocm93cyBgTm9uZUVycm9yYCBpZiBgTm9uZWAKICAgICAqLwogICAgdW53cmFwKCkgewogICAgICAgIHRocm93IFBhbmljLmZyb20obmV3IEVycm9yKGBBIE5vbmUgaGFzIGJlZW4gdW53cmFwcGVkYCwgeyBjYXVzZTogdGhpcyB9KSk7CiAgICB9CiAgICAvKioKICAgICAqIEdldCB0aGUgaW5uZXIgdmFsdWUgb3IgYSBkZWZhdWx0IG9uZQogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAgaWYgYFNvbWVgLCBgdmFsdWVgIGlmIGBOb25lYAogICAgICovCiAgICB1bndyYXBPcih2YWx1ZSkgewogICAgICAgIHJldHVybiB2YWx1ZTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyB0aGUgY29udGFpbmVkIGBTb21lYCB2YWx1ZSBvciBjb21wdXRlcyBpdCBmcm9tIGEgY2xvc3VyZQogICAgICogQHBhcmFtIG5vbmVDYWxsYmFjawogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBTb21lYCwgYGF3YWl0IG5vbmVDYWxsYmFjaygpYCBpZiBgTm9uZWAKICAgICAqLwogICAgYXN5bmMgdW53cmFwT3JFbHNlKG5vbmVDYWxsYmFjaykgewogICAgICAgIHJldHVybiBhd2FpdCBub25lQ2FsbGJhY2soKTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyB0aGUgY29udGFpbmVkIGBTb21lYCB2YWx1ZSBvciBjb21wdXRlcyBpdCBmcm9tIGEgY2xvc3VyZQogICAgICogQHBhcmFtIG5vbmVDYWxsYmFjawogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBTb21lYCwgYG5vbmVDYWxsYmFjaygpYCBpZiBgTm9uZWAKICAgICAqLwogICAgdW53cmFwT3JFbHNlU3luYyhub25lQ2FsbGJhY2spIHsKICAgICAgICByZXR1cm4gbm9uZUNhbGxiYWNrKCk7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBgT3B0aW9uPFQ+YCBpbnRvIGBSZXN1bHQ8VCwgTm9uZUVycm9yPmAKICAgICAqIEByZXR1cm5zIGBPayh0aGlzLmlubmVyKWAgaWYgYFNvbWVgLCBgRXJyKE5vbmVFcnJvcilgIGlmIGBOb25lYAogICAgICovCiAgICBvaygpIHsKICAgICAgICByZXR1cm4gbmV3IEVycihuZXcgTm9uZUVycm9yKCkpOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm0gYE9wdGlvbjxUPmAgaW50byBgUmVzdWx0PFQsIEU+YAogICAgICogQHBhcmFtIGVycm9yCiAgICAgKiBAcmV0dXJucyBgT2sodGhpcy5pbm5lcilgIGlmIGBTb21lYCwgYEVycihlcnJvcilgIGlmIGBOb25lYAogICAgICovCiAgICBva09yKGVycm9yKSB7CiAgICAgICAgcmV0dXJuIG5ldyBFcnIoZXJyb3IpOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm1zIHRoZSBgT3B0aW9uPFQ+YCBpbnRvIGEgYFJlc3VsdDxULCBFPmAsIG1hcHBpbmcgYFNvbWUodilgIHRvIGBPayh2KWAgYW5kIGBOb25lYCB0byBgRXJyKGVycigpKWAKICAgICAqIEBwYXJhbSBub25lQ2FsbGJhY2sKICAgICAqIEByZXR1cm5zIGBPayh0aGlzLmlubmVyKWAgaWYgYFNvbWVgLCBgRXJyKGF3YWl0IG5vbmVDYWxsYmFjaygpKWAgaXMgYE5vbmVgCiAgICAgKi8KICAgIGFzeW5jIG9rT3JFbHNlKG5vbmVDYWxsYmFjaykgewogICAgICAgIHJldHVybiBuZXcgRXJyKGF3YWl0IG5vbmVDYWxsYmFjaygpKTsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtcyB0aGUgYE9wdGlvbjxUPmAgaW50byBhIGBSZXN1bHQ8VCwgRT5gLCBtYXBwaW5nIGBTb21lKHYpYCB0byBgT2sodilgIGFuZCBgTm9uZWAgdG8gYEVycihlcnIoKSlgCiAgICAgKiBAcGFyYW0gbm9uZUNhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgT2sodGhpcy5pbm5lcilgIGlmIGBTb21lYCwgYEVycihub25lQ2FsbGJhY2soKSlgIGlzIGBOb25lYAogICAgICovCiAgICBva09yRWxzZVN5bmMobm9uZUNhbGxiYWNrKSB7CiAgICAgICAgcmV0dXJuIG5ldyBFcnIobm9uZUNhbGxiYWNrKCkpOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGBOb25lYCBpZiB0aGUgb3B0aW9uIGlzIGBOb25lYCwgb3RoZXJ3aXNlIGNhbGxzIGBzb21lUHJlZGljYXRlYCB3aXRoIHRoZSB3cmFwcGVkIHZhbHVlCiAgICAgKiBAcGFyYW0gc29tZVByZWRpY2F0ZQogICAgICogQHJldHVybnMgYFNvbWVgIGlmIGBTb21lYCBhbmQgYGF3YWl0IHNvbWVQcmVkaWNhdGUodGhpcy5pbm5lcilgLCBgTm9uZWAgb3RoZXJ3aXNlCiAgICAgKi8KICAgIGFzeW5jIGZpbHRlcihzb21lUHJlZGljYXRlKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYE5vbmVgIGlmIHRoZSBvcHRpb24gaXMgYE5vbmVgLCBvdGhlcndpc2UgY2FsbHMgYHNvbWVQcmVkaWNhdGVgIHdpdGggdGhlIHdyYXBwZWQgdmFsdWUKICAgICAqIEBwYXJhbSBzb21lUHJlZGljYXRlCiAgICAgKiBAcmV0dXJucyBgU29tZWAgaWYgYFNvbWVgIGFuZCBgc29tZVByZWRpY2F0ZSh0aGlzLmlubmVyKWAsIGBOb25lYCBvdGhlcndpc2UKICAgICAqLwogICAgZmlsdGVyU3luYyhzb21lUHJlZGljYXRlKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBgT3B0aW9uPFByb21pc2U8VD4+YCBpbnRvIGBQcm9taXNlPE9wdGlvbjxUPj5gCiAgICAgKiBAcmV0dXJucyBgUHJvbWlzZTxPcHRpb248VD4+YAogICAgICovCiAgICBhc3luYyBhd2FpdCgpIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBgdHJ1ZWAgaWYgdGhlIG9wdGlvbiBpcyBhIGBTb21lYCB2YWx1ZSBjb250YWluaW5nIHRoZSBnaXZlbiB2YWx1ZQogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYFNvbWVgIGFuZCBgdGhpcy5pbm5lciA9PT0gdmFsdWVgLCBgTm9uZWAgb3RoZXJ3aXNlCiAgICAgKi8KICAgIGNvbnRhaW5zKHZhbHVlKSB7CiAgICAgICAgcmV0dXJuIGZhbHNlOwogICAgfQogICAgLyoqCiAgICAgKiBDYWxscyB0aGUgZ2l2ZW4gY2FsbGJhY2sgd2l0aCB0aGUgaW5uZXIgdmFsdWUgaWYgYE9rYAogICAgICogQHBhcmFtIHNvbWVDYWxsYmFjawogICAgICogQHJldHVybnMgYHRoaXNgCiAgICAgKi8KICAgIGFzeW5jIGluc3BlY3Qoc29tZUNhbGxiYWNrKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIENhbGxzIHRoZSBnaXZlbiBjYWxsYmFjayB3aXRoIHRoZSBpbm5lciB2YWx1ZSBpZiBgT2tgCiAgICAgKiBAcGFyYW0gc29tZUNhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgdGhpc2AKICAgICAqLwogICAgaW5zcGVjdFN5bmMoc29tZUNhbGxiYWNrKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIE1hcHMgYW4gYE9wdGlvbjxUPmAgdG8gYE9wdGlvbjxVPmAgYnkgYXBwbHlpbmcgYSBmdW5jdGlvbiB0byBhIGNvbnRhaW5lZCB2YWx1ZSAoaWYgYFNvbWVgKSBvciByZXR1cm5zIGBOb25lYCAoaWYgYE5vbmVgKQogICAgICogQHBhcmFtIHNvbWVNYXBwZXIKICAgICAqIEByZXR1cm5zIGBTb21lKGF3YWl0IHNvbWVNYXBwZXIodGhpcy5pbm5lcikpYCBpZiBgU29tZWAsIGB0aGlzYCBpZiBgTm9uZWAKICAgICAqLwogICAgYXN5bmMgbWFwKHNvbWVNYXBwZXIpIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogTWFwcyBhbiBgT3B0aW9uPFQ+YCB0byBgT3B0aW9uPFU+YCBieSBhcHBseWluZyBhIGZ1bmN0aW9uIHRvIGEgY29udGFpbmVkIHZhbHVlIChpZiBgU29tZWApIG9yIHJldHVybnMgYE5vbmVgIChpZiBgTm9uZWApCiAgICAgKiBAcGFyYW0gc29tZU1hcHBlcgogICAgICogQHJldHVybnMgYFNvbWUoc29tZU1hcHBlcih0aGlzLmlubmVyKSlgIGlmIGBTb21lYCwgYHRoaXNgIGlmIGBOb25lYAogICAgICovCiAgICBtYXBTeW5jKHNvbWVNYXBwZXIpIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyB0aGUgcHJvdmlkZWQgZGVmYXVsdCByZXN1bHQgKGlmIG5vbmUpLCBvciBhcHBsaWVzIGEgZnVuY3Rpb24gdG8gdGhlIGNvbnRhaW5lZCB2YWx1ZSAoaWYgYW55KQogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcGFyYW0gc29tZU1hcHBlcgogICAgICogQHJldHVybnMgYHZhbHVlYCBpZiBgTm9uZWAsIGBhd2FpdCBzb21lTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgU29tZWAKICAgICAqLwogICAgYXN5bmMgbWFwT3IodmFsdWUsIHNvbWVNYXBwZXIpIHsKICAgICAgICByZXR1cm4gdmFsdWU7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgdGhlIHByb3ZpZGVkIGRlZmF1bHQgcmVzdWx0IChpZiBub25lKSwgb3IgYXBwbGllcyBhIGZ1bmN0aW9uIHRvIHRoZSBjb250YWluZWQgdmFsdWUgKGlmIGFueSkKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHBhcmFtIHNvbWVNYXBwZXIKICAgICAqIEByZXR1cm5zIGB2YWx1ZWAgaWYgYE5vbmVgLCBgc29tZU1hcHBlcih0aGlzLmlubmVyKWAgaWYgYFNvbWVgCiAgICAgKi8KICAgIG1hcE9yU3luYyh2YWx1ZSwgc29tZU1hcHBlcikgewogICAgICAgIHJldHVybiB2YWx1ZTsKICAgIH0KICAgIC8qKgogICAgICogQ29tcHV0ZXMgYSBkZWZhdWx0IGZ1bmN0aW9uIHJlc3VsdCAoaWYgbm9uZSksIG9yIGFwcGxpZXMgYSBkaWZmZXJlbnQgZnVuY3Rpb24gdG8gdGhlIGNvbnRhaW5lZCB2YWx1ZSAoaWYgYW55KQogICAgICogQHBhcmFtIG5vbmVDYWxsYmFjawogICAgICogQHBhcmFtIHNvbWVNYXBwZXIKICAgICAqIEByZXR1cm5zIGBhd2FpdCBzb21lTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgU29tZWAsIGBhd2FpdCBub25lQ2FsbGJhY2soKWAgaWYgYE5vbmVgCiAgICAgKi8KICAgIGFzeW5jIG1hcE9yRWxzZShub25lQ2FsbGJhY2ssIHNvbWVNYXBwZXIpIHsKICAgICAgICByZXR1cm4gYXdhaXQgbm9uZUNhbGxiYWNrKCk7CiAgICB9CiAgICAvKioKICAgICAqIENvbXB1dGVzIGEgZGVmYXVsdCBmdW5jdGlvbiByZXN1bHQgKGlmIG5vbmUpLCBvciBhcHBsaWVzIGEgZGlmZmVyZW50IGZ1bmN0aW9uIHRvIHRoZSBjb250YWluZWQgdmFsdWUgKGlmIGFueSkKICAgICAqIEBwYXJhbSBub25lQ2FsbGJhY2sKICAgICAqIEBwYXJhbSBzb21lTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgc29tZU1hcHBlcih0aGlzLmlubmVyKWAgaWYgYFNvbWVgLCBgbm9uZUNhbGxiYWNrKClgIGlmIGBOb25lYAogICAgICovCiAgICBtYXBPckVsc2VTeW5jKG5vbmVDYWxsYmFjaywgc29tZU1hcHBlcikgewogICAgICAgIHJldHVybiBub25lQ2FsbGJhY2soKTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBgTm9uZWAgaWYgdGhlIG9wdGlvbiBpcyBgTm9uZWAsIG90aGVyd2lzZSByZXR1cm5zIGB2YWx1ZWAKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHJldHVybnMgYE5vbmVgIGlmIGBOb25lYCwgYHZhbHVlYCBpZiBgU29tZWAKICAgICAqLwogICAgYW5kKHZhbHVlKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYE5vbmVgIGlmIHRoZSBvcHRpb24gaXMgYE5vbmVgLCBvdGhlcndpc2UgY2FsbHMgYHNvbWVNYXBwZXJgIHdpdGggdGhlIHdyYXBwZWQgdmFsdWUgYW5kIHJldHVybnMgdGhlIHJlc3VsdAogICAgICogQHBhcmFtIHNvbWVNYXBwZXIKICAgICAqIEByZXR1cm5zIGBOb25lYCBpZiBgTm9uZWAsIGBhd2FpdCBzb21lTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgU29tZWAKICAgICAqLwogICAgYXN5bmMgYW5kVGhlbihzb21lTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYE5vbmVgIGlmIHRoZSBvcHRpb24gaXMgYE5vbmVgLCBvdGhlcndpc2UgY2FsbHMgYHNvbWVNYXBwZXJgIHdpdGggdGhlIHdyYXBwZWQgdmFsdWUgYW5kIHJldHVybnMgdGhlIHJlc3VsdAogICAgICogQHBhcmFtIHNvbWVNYXBwZXIKICAgICAqIEByZXR1cm5zIGBOb25lYCBpZiBgTm9uZWAsIGBzb21lTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgU29tZWAKICAgICAqLwogICAgYW5kVGhlblN5bmMoc29tZU1hcHBlcikgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGB0aGlzYCBpZiBgU29tZWAsIG90aGVyd2lzZSByZXR1cm5zIGB2YWx1ZWAKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHJldHVybnMgYHRoaXNgIGlmIGBTb21lYCwgYHZhbHVlYCBpZiBgTm9uZWAKICAgICAqLwogICAgb3IodmFsdWUpIHsKICAgICAgICByZXR1cm4gdmFsdWU7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYHRoaXNgIGlmIGBTb21lYCwgb3RoZXJ3aXNlIGNhbGxzIGBub25lQ2FsbGJhY2tgIGFuZCByZXR1cm5zIHRoZSByZXN1bHQKICAgICAqIEBwYXJhbSBub25lQ2FsbGJhY2sKICAgICAqIEByZXR1cm5zIGB0aGlzYCBpZiBgU29tZWAsIGBhd2FpdCBub25lQ2FsbGJhY2soKWAgaWYgYE5vbmVgCiAgICAgKi8KICAgIGFzeW5jIG9yRWxzZShub25lQ2FsbGJhY2spIHsKICAgICAgICByZXR1cm4gYXdhaXQgbm9uZUNhbGxiYWNrKCk7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYHRoaXNgIGlmIGBTb21lYCwgb3RoZXJ3aXNlIGNhbGxzIGBub25lQ2FsbGJhY2tgIGFuZCByZXR1cm5zIHRoZSByZXN1bHQKICAgICAqIEBwYXJhbSBub25lQ2FsbGJhY2sKICAgICAqIEByZXR1cm5zIGB0aGlzYCBpZiBgU29tZWAsIGBub25lQ2FsbGJhY2soKWAgaWYgYE5vbmVgCiAgICAgKi8KICAgIG9yRWxzZVN5bmMobm9uZUNhbGxiYWNrKSB7CiAgICAgICAgcmV0dXJuIG5vbmVDYWxsYmFjaygpOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGBTb21lYCBpZiBleGFjdGx5IG9uZSBvZiB0aGUgb3B0aW9ucyBpcyBgU29tZWAsIG90aGVyd2lzZSByZXR1cm5zIGBOb25lYAogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcmV0dXJucyBgTm9uZWAgaWYgYm90aCBhcmUgYFNvbWVgIG9yIGJvdGggYXJlIGBOb25lYCwgdGhlIG9ubHkgYFNvbWVgIG90aGVyd2lzZQogICAgICovCiAgICB4b3IodmFsdWUpIHsKICAgICAgICByZXR1cm4gdmFsdWU7CiAgICB9CiAgICAvKioKICAgICAqIFppcHMgYHRoaXNgIHdpdGggYW5vdGhlciBgT3B0aW9uYAogICAgICogQHBhcmFtIG90aGVyCiAgICAgKiBAcmV0dXJucyBgU29tZShbdGhpcy5pbm5lciwgb3RoZXIuaW5uZXJdKWAgaWYgYm90aCBhcmUgYFNvbWVgLCBgTm9uZWAgaWYgb25lIG9mIHRoZW0gaXMgYE5vbmVgCiAgICAgKi8KICAgIHppcChvdGhlcikgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQp9CgoKLy8jIHNvdXJjZU1hcHBpbmdVUkw9bm9uZS5tanMubWFwCgo7Ly8gQ09OQ0FURU5BVEVEIE1PRFVMRTogLi9ub2RlX21vZHVsZXMvQGhhemFlNDEvb3B0aW9uL2Rpc3QvZXNtL21vZHMvb3B0aW9uL29wdGlvbi5tanMKCgoKdmFyIE9wdGlvbjsKKGZ1bmN0aW9uIChPcHRpb24pIHsKICAgIGZ1bmN0aW9uIGZyb20oaW5pdCkgewogICAgICAgIGlmICgiaW5uZXIiIGluIGluaXQpCiAgICAgICAgICAgIHJldHVybiBuZXcgU29tZShpbml0LmlubmVyKTsKICAgICAgICByZXR1cm4gbmV3IE5vbmUoKTsKICAgIH0KICAgIE9wdGlvbi5mcm9tID0gZnJvbTsKICAgIC8qKgogICAgICogQ3JlYXRlIGFuIE9wdGlvbiBmcm9tIGEgbnVsbGFibGUgdmFsdWUKICAgICAqIEBwYXJhbSBpbm5lcgogICAgICogQHJldHVybnMgYFNvbWU8VD5gIGlmIGBUYCwgYE5vbmVgIGlmIGB1bmRlZmluZWRgCiAgICAgKi8KICAgIGZ1bmN0aW9uIHdyYXAoaW5uZXIpIHsKICAgICAgICBpZiAoaW5uZXIgPT0gbnVsbCkKICAgICAgICAgICAgcmV0dXJuIG5ldyBOb25lKCk7CiAgICAgICAgcmV0dXJuIG5ldyBTb21lKGlubmVyKTsKICAgIH0KICAgIE9wdGlvbi53cmFwID0gd3JhcDsKICAgIGFzeW5jIGZ1bmN0aW9uIG1hcChpbm5lciwgbWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIE9wdGlvbi53cmFwKGlubmVyKS5tYXAobWFwcGVyKS50aGVuKG8gPT4gby5nZXQoKSk7CiAgICB9CiAgICBPcHRpb24ubWFwID0gbWFwOwogICAgZnVuY3Rpb24gbWFwU3luYyhpbm5lciwgbWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIE9wdGlvbi53cmFwKGlubmVyKS5tYXBTeW5jKG1hcHBlcikuZ2V0KCk7CiAgICB9CiAgICBPcHRpb24ubWFwU3luYyA9IG1hcFN5bmM7CiAgICBmdW5jdGlvbiB1bndyYXAoaW5uZXIpIHsKICAgICAgICByZXR1cm4gT3B0aW9uLndyYXAoaW5uZXIpLnVud3JhcCgpOwogICAgfQogICAgT3B0aW9uLnVud3JhcCA9IHVud3JhcDsKfSkoT3B0aW9uIHx8IChPcHRpb24gPSB7fSkpOwoKCi8vIyBzb3VyY2VNYXBwaW5nVVJMPW9wdGlvbi5tanMubWFwCgo7Ly8gQ09OQ0FURU5BVEVEIE1PRFVMRTogLi9ub2RlX21vZHVsZXMvQGhhemFlNDEvcmVzdWx0L2Rpc3QvZXNtL21vZHMvcmVzdWx0L3Jlc3VsdC5tanMKCgoKCgp2YXIgUmVzdWx0OwooZnVuY3Rpb24gKFJlc3VsdCkgewogICAgUmVzdWx0LmRlYnVnID0gZmFsc2U7CiAgICAvKioKICAgICAqIENyZWF0ZSBhIFJlc3VsdCBmcm9tIGEgbWF5YmUgRXJyb3IgdmFsdWUKICAgICAqIEBwYXJhbSBpbm5lcgogICAgICogQHJldHVybnMgYE9rPFQ+YCBpZiBgVGAsIGBFcnI8RXJyb3I+YCBpZiBgRXJyb3JgCiAgICAgKi8KICAgIGZ1bmN0aW9uIGZyb20oaW5uZXIpIHsKICAgICAgICBpZiAoaW5uZXIgaW5zdGFuY2VvZiBFcnJvcikKICAgICAgICAgICAgcmV0dXJuIG5ldyBFcnIoaW5uZXIpOwogICAgICAgIGVsc2UKICAgICAgICAgICAgcmV0dXJuIG5ldyBPayhpbm5lcik7CiAgICB9CiAgICBSZXN1bHQuZnJvbSA9IGZyb207CiAgICAvKioKICAgICAqIENyZWF0ZSBhIFJlc3VsdCBmcm9tIGEgYm9vbGVhbgogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcmV0dXJucwogICAgICovCiAgICBmdW5jdGlvbiBhc3NlcnQodmFsdWUpIHsKICAgICAgICByZXR1cm4gdmFsdWUgPyBPay52b2lkKCkgOiBuZXcgRXJyKG5ldyBBc3NlcnRFcnJvcigpKTsKICAgIH0KICAgIFJlc3VsdC5hc3NlcnQgPSBhc3NlcnQ7CiAgICBmdW5jdGlvbiByZXdyYXAod3JhcHBlcikgewogICAgICAgIHRyeSB7CiAgICAgICAgICAgIHJldHVybiBuZXcgT2sod3JhcHBlci51bndyYXAoKSk7CiAgICAgICAgfQogICAgICAgIGNhdGNoIChlcnJvcikgewogICAgICAgICAgICByZXR1cm4gbmV3IEVycihlcnJvcik7CiAgICAgICAgfQogICAgfQogICAgUmVzdWx0LnJld3JhcCA9IHJld3JhcDsKICAgIC8qKgogICAgICogQ2F0Y2ggYW4gRXJyIHRocm93biBmcm9tIEVyci50aHJvdwogICAgICogQHBhcmFtIGNhbGxiYWNrCiAgICAgKiBAcGFyYW0gdHlwZQogICAgICogQHJldHVybnMgYE9rPFQ+YCBpZiBubyBgRXJyYCB3YXMgdGhyb3duLCBgRXJyPEU+YCBvdGhlcndpc2UKICAgICAqIEBzZWUgRXJyLnRocm93CiAgICAgKi8KICAgIGFzeW5jIGZ1bmN0aW9uIHVudGhyb3coY2FsbGJhY2spIHsKICAgICAgICBsZXQgcmVmOwogICAgICAgIHRyeSB7CiAgICAgICAgICAgIHJldHVybiBhd2FpdCBjYWxsYmFjaygoZSkgPT4gcmVmID0gZSk7CiAgICAgICAgfQogICAgICAgIGNhdGNoIChlKSB7CiAgICAgICAgICAgIGlmIChyZWYgIT09IHVuZGVmaW5lZCkKICAgICAgICAgICAgICAgIHJldHVybiByZWY7CiAgICAgICAgICAgIHRocm93IGU7CiAgICAgICAgfQogICAgfQogICAgUmVzdWx0LnVudGhyb3cgPSB1bnRocm93OwogICAgLyoqCiAgICAgKiBDYXRjaCBhbiBFcnIgdGhyb3duIGZyb20gRXJyLnRocm93CiAgICAgKiBAcGFyYW0gY2FsbGJhY2sKICAgICAqIEBwYXJhbSB0eXBlCiAgICAgKiBAcmV0dXJucyBgT2s8VD5gIGlmIG5vIGBFcnJgIHdhcyB0aHJvd24sIGBFcnI8RT5gIG90aGVyd2lzZQogICAgICogQHNlZSBFcnIudGhyb3cKICAgICAqLwogICAgZnVuY3Rpb24gdW50aHJvd1N5bmMoY2FsbGJhY2spIHsKICAgICAgICBsZXQgcmVmOwogICAgICAgIHRyeSB7CiAgICAgICAgICAgIHJldHVybiBjYWxsYmFjaygoZSkgPT4gcmVmID0gZSk7CiAgICAgICAgfQogICAgICAgIGNhdGNoIChlKSB7CiAgICAgICAgICAgIGlmIChyZWYgIT09IHVuZGVmaW5lZCkKICAgICAgICAgICAgICAgIHJldHVybiByZWY7CiAgICAgICAgICAgIHRocm93IGU7CiAgICAgICAgfQogICAgfQogICAgUmVzdWx0LnVudGhyb3dTeW5jID0gdW50aHJvd1N5bmM7CiAgICAvKioKICAgICAqIENvbnZlcnQgdHJ5LWNhdGNoIHRvIFJlc3VsdDxULCB1bmtub3duPgogICAgICogQHBhcmFtIGNhbGxiYWNrCiAgICAgKiBAcmV0dXJucwogICAgICovCiAgICBhc3luYyBmdW5jdGlvbiBydW5BbmRXcmFwKGNhbGxiYWNrKSB7CiAgICAgICAgdHJ5IHsKICAgICAgICAgICAgcmV0dXJuIG5ldyBPayhhd2FpdCBjYWxsYmFjaygpKTsKICAgICAgICB9CiAgICAgICAgY2F0Y2ggKGUpIHsKICAgICAgICAgICAgcmV0dXJuIG5ldyBFcnIoZSk7CiAgICAgICAgfQogICAgfQogICAgUmVzdWx0LnJ1bkFuZFdyYXAgPSBydW5BbmRXcmFwOwogICAgLyoqCiAgICAgKiBDb252ZXJ0IHRyeS1jYXRjaCB0byBSZXN1bHQ8VCwgdW5rbm93bj4KICAgICAqIEBwYXJhbSBjYWxsYmFjawogICAgICogQHJldHVybnMKICAgICAqLwogICAgZnVuY3Rpb24gcnVuQW5kV3JhcFN5bmMoY2FsbGJhY2spIHsKICAgICAgICB0cnkgewogICAgICAgICAgICByZXR1cm4gbmV3IE9rKGNhbGxiYWNrKCkpOwogICAgICAgIH0KICAgICAgICBjYXRjaCAoZSkgewogICAgICAgICAgICByZXR1cm4gbmV3IEVycihlKTsKICAgICAgICB9CiAgICB9CiAgICBSZXN1bHQucnVuQW5kV3JhcFN5bmMgPSBydW5BbmRXcmFwU3luYzsKICAgIC8qKgogICAgICogQ29udmVydCB0cnktY2F0Y2ggdG8gUmVzdWx0PFQsIENhdGNoZWQ+CiAgICAgKiBAcGFyYW0gY2FsbGJhY2sKICAgICAqIEByZXR1cm5zCiAgICAgKi8KICAgIGFzeW5jIGZ1bmN0aW9uIHJ1bkFuZERvdWJsZVdyYXAoY2FsbGJhY2spIHsKICAgICAgICByZXR1cm4gcnVuQW5kV3JhcChjYWxsYmFjaykudGhlbihyID0+IHIubWFwRXJyU3luYyhDYXRjaGVkLmZyb20pKTsKICAgIH0KICAgIFJlc3VsdC5ydW5BbmREb3VibGVXcmFwID0gcnVuQW5kRG91YmxlV3JhcDsKICAgIC8qKgogICAgICogQ29udmVydCB0cnktY2F0Y2ggdG8gUmVzdWx0PFQsIENhdGNoZWQ+CiAgICAgKiBAcGFyYW0gY2FsbGJhY2sKICAgICAqIEByZXR1cm5zCiAgICAgKi8KICAgIGZ1bmN0aW9uIHJ1bkFuZERvdWJsZVdyYXBTeW5jKGNhbGxiYWNrKSB7CiAgICAgICAgcmV0dXJuIHJ1bkFuZFdyYXBTeW5jKGNhbGxiYWNrKS5tYXBFcnJTeW5jKENhdGNoZWQuZnJvbSk7CiAgICB9CiAgICBSZXN1bHQucnVuQW5kRG91YmxlV3JhcFN5bmMgPSBydW5BbmREb3VibGVXcmFwU3luYzsKICAgIC8qKgogICAgICogVHJhbnNmb3JtIFJlc3VsdDxSZXN1bHQ8VCwgRTE+LCBFMj4gaW50byBSZXN1bHQ8VCwgRTEgfCBFMj4KICAgICAqIEBwYXJhbSByZXN1bHQKICAgICAqIEByZXR1cm5zIGB0aGlzYCBpZiBgRXJyYCwgYHRoaXMuaW5uZXJgIGlmIGBPa2AKICAgICAqLwogICAgZnVuY3Rpb24gZmxhdHRlbihyZXN1bHQpIHsKICAgICAgICBpZiAocmVzdWx0LmlzRXJyKCkpCiAgICAgICAgICAgIHJldHVybiByZXN1bHQ7CiAgICAgICAgcmV0dXJuIHJlc3VsdC5nZXQoKTsKICAgIH0KICAgIFJlc3VsdC5mbGF0dGVuID0gZmxhdHRlbjsKICAgIC8qKgogICAgICogVHJhbnNmb3JtIGBJdGVyYWJsZTxSZXN1bHQ8VCxFPmAgaW50byBgUmVzdWx0PEFycmF5PFQ+LCBFPmAKICAgICAqIEBwYXJhbSBpdGVyYWJsZQogICAgICogQHJldHVybnMgYFJlc3VsdDxBcnJheTxUPiwgRT5gCiAgICAgKi8KICAgIGZ1bmN0aW9uIGFsbChpdGVyYWJsZSkgewogICAgICAgIHJldHVybiBjb2xsZWN0KGl0ZXJhdGUoaXRlcmFibGUpKTsKICAgIH0KICAgIFJlc3VsdC5hbGwgPSBhbGw7CiAgICBmdW5jdGlvbiBtYXliZUFsbChpdGVyYWJsZSkgewogICAgICAgIHJldHVybiBtYXliZUNvbGxlY3QobWF5YmVJdGVyYXRlKGl0ZXJhYmxlKSk7CiAgICB9CiAgICBSZXN1bHQubWF5YmVBbGwgPSBtYXliZUFsbDsKICAgIC8qKgogICAgICogVHJhbnNmb3JtIGBJdGVyYWJsZTxSZXN1bHQ8VCxFPmAgaW50byBgSXRlcmF0b3I8VCwgUmVzdWx0PHZvaWQsIEU+PmAKICAgICAqIEBwYXJhbSBpdGVyYWJsZQogICAgICogQHJldHVybnMgYEl0ZXJhdG9yPFQsIFJlc3VsdDx2b2lkLCBFPj5gCiAgICAgKi8KICAgIGZ1bmN0aW9uKiBpdGVyYXRlKGl0ZXJhYmxlKSB7CiAgICAgICAgZm9yIChjb25zdCByZXN1bHQgb2YgaXRlcmFibGUpIHsKICAgICAgICAgICAgaWYgKHJlc3VsdC5pc09rKCkpCiAgICAgICAgICAgICAgICB5aWVsZCByZXN1bHQuZ2V0KCk7CiAgICAgICAgICAgIGVsc2UKICAgICAgICAgICAgICAgIHJldHVybiByZXN1bHQ7CiAgICAgICAgfQogICAgICAgIHJldHVybiBPay52b2lkKCk7CiAgICB9CiAgICBSZXN1bHQuaXRlcmF0ZSA9IGl0ZXJhdGU7CiAgICBmdW5jdGlvbiogbWF5YmVJdGVyYXRlKGl0ZXJhYmxlKSB7CiAgICAgICAgZm9yIChjb25zdCByZXN1bHQgb2YgaXRlcmFibGUpIHsKICAgICAgICAgICAgaWYgKHJlc3VsdCA9PSBudWxsKQogICAgICAgICAgICAgICAgcmV0dXJuIHJlc3VsdDsKICAgICAgICAgICAgZWxzZSBpZiAocmVzdWx0LmlzT2soKSkKICAgICAgICAgICAgICAgIHlpZWxkIHJlc3VsdC5nZXQoKTsKICAgICAgICAgICAgZWxzZQogICAgICAgICAgICAgICAgcmV0dXJuIHJlc3VsdDsKICAgICAgICB9CiAgICAgICAgcmV0dXJuIE9rLnZvaWQoKTsKICAgIH0KICAgIFJlc3VsdC5tYXliZUl0ZXJhdGUgPSBtYXliZUl0ZXJhdGU7CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBgSXRlcmF0b3I8VCwgUmVzdWx0PHZvaWQsIEU+PmAgaW50byBgUmVzdWx0PEFycmF5PFQ+LCBFPmAKICAgICAqIEBwYXJhbSBpdGVyYXRvciBgUmVzdWx0PEFycmF5PFQ+LCBFPmAKICAgICAqLwogICAgZnVuY3Rpb24gY29sbGVjdChpdGVyYXRvcikgewogICAgICAgIGNvbnN0IGFycmF5ID0gbmV3IEFycmF5KCk7CiAgICAgICAgbGV0IHJlc3VsdCA9IGl0ZXJhdG9yLm5leHQoKTsKICAgICAgICBmb3IgKDsgIXJlc3VsdC5kb25lOyByZXN1bHQgPSBpdGVyYXRvci5uZXh0KCkpCiAgICAgICAgICAgIGFycmF5LnB1c2gocmVzdWx0LnZhbHVlKTsKICAgICAgICByZXR1cm4gcmVzdWx0LnZhbHVlLnNldChhcnJheSk7CiAgICB9CiAgICBSZXN1bHQuY29sbGVjdCA9IGNvbGxlY3Q7CiAgICBmdW5jdGlvbiBtYXliZUNvbGxlY3QoaXRlcmF0b3IpIHsKICAgICAgICBjb25zdCBhcnJheSA9IG5ldyBBcnJheSgpOwogICAgICAgIGxldCByZXN1bHQgPSBpdGVyYXRvci5uZXh0KCk7CiAgICAgICAgZm9yICg7ICFyZXN1bHQuZG9uZTsgcmVzdWx0ID0gaXRlcmF0b3IubmV4dCgpKQogICAgICAgICAgICBhcnJheS5wdXNoKHJlc3VsdC52YWx1ZSk7CiAgICAgICAgcmV0dXJuIE9wdGlvbi5tYXBTeW5jKHJlc3VsdC52YWx1ZSwgcmVzdWx0ID0+IHJlc3VsdC5zZXQoYXJyYXkpKTsKICAgIH0KICAgIFJlc3VsdC5tYXliZUNvbGxlY3QgPSBtYXliZUNvbGxlY3Q7CiAgICAvKioKICAgICAqIFVud3JhcCB0aGUgY2FsbGJhY2sgYnV0IHdyYXAgdGhyb3duIGVycm9ycyBpbiBDYXRjaGVkCiAgICAgKiBAcGFyYW0gY2FsbGJhY2sKICAgICAqIEByZXR1cm5zIGBUYCBpZiBgT2tgCiAgICAgKiBAdGhyb3dzIGBDYXRjaGVkYCBpZiBgY2FsbGJhY2soKWAgdGhyb3dzLCBgRWAgaWYgYEVycmAKICAgICAqLwogICAgYXN5bmMgZnVuY3Rpb24gcnVuQW5kVW53cmFwKGNhbGxiYWNrKSB7CiAgICAgICAgbGV0IHJlc3VsdDsKICAgICAgICB0cnkgewogICAgICAgICAgICByZXN1bHQgPSBhd2FpdCBjYWxsYmFjaygpOwogICAgICAgIH0KICAgICAgICBjYXRjaCAoZSkgewogICAgICAgICAgICB0aHJvdyBDYXRjaGVkLmZyb20oZSk7CiAgICAgICAgfQogICAgICAgIHJldHVybiByZXN1bHQudW53cmFwKCk7CiAgICB9CiAgICBSZXN1bHQucnVuQW5kVW53cmFwID0gcnVuQW5kVW53cmFwOwogICAgLyoqCiAgICAgKiBVbndyYXAgdGhlIGNhbGxiYWNrIGJ1dCB3cmFwIHRocm93biBlcnJvcnMgaW4gQ2F0Y2hlZAogICAgICogQHBhcmFtIGNhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgVGAgaWYgYE9rYAogICAgICogQHRocm93cyBgQ2F0Y2hlZGAgaWYgYGNhbGxiYWNrKClgIHRocm93cywgYEVgIGlmIGBFcnJgCiAgICAgKi8KICAgIGZ1bmN0aW9uIHJ1bkFuZFVud3JhcFN5bmMoY2FsbGJhY2spIHsKICAgICAgICBsZXQgcmVzdWx0OwogICAgICAgIHRyeSB7CiAgICAgICAgICAgIHJlc3VsdCA9IGNhbGxiYWNrKCk7CiAgICAgICAgfQogICAgICAgIGNhdGNoIChlKSB7CiAgICAgICAgICAgIHRocm93IENhdGNoZWQuZnJvbShlKTsKICAgICAgICB9CiAgICAgICAgcmV0dXJuIHJlc3VsdC51bndyYXAoKTsKICAgIH0KICAgIFJlc3VsdC5ydW5BbmRVbndyYXBTeW5jID0gcnVuQW5kVW53cmFwU3luYzsKfSkoUmVzdWx0IHx8IChSZXN1bHQgPSB7fSkpOwoKCi8vIyBzb3VyY2VNYXBwaW5nVVJMPXJlc3VsdC5tanMubWFwCgo7Ly8gQ09OQ0FURU5BVEVEIE1PRFVMRTogLi9ub2RlX21vZHVsZXMvQGhhemFlNDEvcmVzdWx0L2Rpc3QvZXNtL21vZHMvcmVzdWx0L29rLm1qcwoKCgoKY2xhc3MgT2sgewogICAgI2lubmVyOwogICAgI3RpbWVvdXQ7CiAgICAvKioKICAgICAqIEEgc3VjY2VzcwogICAgICogQHBhcmFtIGlubmVyCiAgICAgKi8KICAgIGNvbnN0cnVjdG9yKGlubmVyKSB7CiAgICAgICAgdGhpcy4jaW5uZXIgPSBpbm5lcjsKICAgICAgICBpZiAoIVJlc3VsdC5kZWJ1ZykKICAgICAgICAgICAgcmV0dXJuOwogICAgICAgIGNvbnN0IGVycm9yID0gUGFuaWMuZnJvbShuZXcgRXJyb3IoYEFuIE9rIGhhcyBub3QgYmVlbiBoYW5kbGVkIHByb3Blcmx5YCwgeyBjYXVzZTogdGhpcyB9KSk7CiAgICAgICAgdGhpcy4jdGltZW91dCA9IHNldFRpbWVvdXQoKCkgPT4geyB0aHJvdyBlcnJvcjsgfSwgMTAwMCk7CiAgICB9CiAgICAvKioKICAgICAqIENyZWF0ZSBhbiBlbXB0eSBgT2tgCiAgICAgKiBAcmV0dXJucyBgT2sodm9pZClgCiAgICAgKi8KICAgIHN0YXRpYyB2b2lkKCkgewogICAgICAgIHJldHVybiBuZXcgT2sodW5kZWZpbmVkKTsKICAgIH0KICAgIC8qKgogICAgICogQ3JlYXRlIGFuIGBPa2AKICAgICAqIEBwYXJhbSBpbm5lcgogICAgICogQHJldHVybnMgYE9rKGlubmVyKWAKICAgICAqLwogICAgc3RhdGljIG5ldyhpbm5lcikgewogICAgICAgIHJldHVybiBuZXcgT2soaW5uZXIpOwogICAgfQogICAgZ2V0IGlubmVyKCkgewogICAgICAgIHJldHVybiB0aGlzLiNpbm5lcjsKICAgIH0KICAgIC8qKgogICAgICogU2V0IHRoaXMgcmVzdWx0IGFzIGhhbmRsZWQKICAgICAqLwogICAgaWdub3JlKCkgewogICAgICAgIGlmICghdGhpcy4jdGltZW91dCkKICAgICAgICAgICAgcmV0dXJuIHRoaXM7CiAgICAgICAgY2xlYXJUaW1lb3V0KHRoaXMuI3RpbWVvdXQpOwogICAgICAgIHRoaXMuI3RpbWVvdXQgPSB1bmRlZmluZWQ7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIFR5cGUgZ3VhcmQgZm9yIGBPa2AKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgT2tgLCBgZmFsc2VgIGlmIGBFcnJgCiAgICAgKi8KICAgIGlzT2soKSB7CiAgICAgICAgcmV0dXJuIHRydWU7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgdHJ1ZSBpZiB0aGUgcmVzdWx0IGlzIGBPa2AgYW5kIHRoZSB2YWx1ZSBpbnNpZGUgb2YgaXQgbWF0Y2hlcyBhIHByZWRpY2F0ZQogICAgICogQHBhcmFtIG9rUHJlZGljYXRlCiAgICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYE9rYCBhbmQgYGF3YWl0IG9rUHJlZGljYXRlKHRoaXMuaW5uZXIpYCwgYGZhbHNlYCBvdGhlcndpc2UKICAgICAqLwogICAgYXN5bmMgaXNPa0FuZChva1ByZWRpY2F0ZSkgewogICAgICAgIHJldHVybiBhd2FpdCBva1ByZWRpY2F0ZSh0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyB0cnVlIGlmIHRoZSByZXN1bHQgaXMgYE9rYCBhbmQgdGhlIHZhbHVlIGluc2lkZSBvZiBpdCBtYXRjaGVzIGEgcHJlZGljYXRlCiAgICAgKiBAcGFyYW0gb2tQcmVkaWNhdGUKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgT2tgIGFuZCBgYXdhaXQgb2tQcmVkaWNhdGUodGhpcy5pbm5lcilgLCBgZmFsc2VgIG90aGVyd2lzZQogICAgICovCiAgICBpc09rQW5kU3luYyhva1ByZWRpY2F0ZSkgewogICAgICAgIHJldHVybiBva1ByZWRpY2F0ZSh0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogVHlwZSBndWFyZCBmb3IgYEVycmAKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgRXJyYCwgYGZhbHNlYCBpZiBgT2tgCiAgICAgKi8KICAgIGlzRXJyKCkgewogICAgICAgIHJldHVybiBmYWxzZTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyB0cnVlIGlmIHRoZSByZXN1bHQgaXMgYEVycmAgYW5kIHRoZSB2YWx1ZSBpbnNpZGUgb2YgaXQgbWF0Y2hlcyBhIHByZWRpY2F0ZQogICAgICogQHBhcmFtIGVyclByZWRpY2F0ZQogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBFcnJgIGFuZCBgYXdhaXQgZXJyUHJlZGljYXRlKHRoaXMuaW5uZXIpYCwgYGZhbHNlYCBvdGhlcndpc2UKICAgICAqLwogICAgYXN5bmMgaXNFcnJBbmQoZXJyUHJlZGljYXRlKSB7CiAgICAgICAgcmV0dXJuIGZhbHNlOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIHRydWUgaWYgdGhlIHJlc3VsdCBpcyBgRXJyYCBhbmQgdGhlIHZhbHVlIGluc2lkZSBvZiBpdCBtYXRjaGVzIGEgcHJlZGljYXRlCiAgICAgKiBAcGFyYW0gZXJyUHJlZGljYXRlCiAgICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYEVycmAgYW5kIGBhd2FpdCBlcnJQcmVkaWNhdGUodGhpcy5pbm5lcilgLCBgZmFsc2VgIG90aGVyd2lzZQogICAgICovCiAgICBpc0VyckFuZFN5bmMoZXJyUHJlZGljYXRlKSB7CiAgICAgICAgcmV0dXJuIGZhbHNlOwogICAgfQogICAgLyoqCiAgICAgKiBDb21waWxlLXRpbWUgc2FmZWx5IGdldCBgdGhpcy5pbm5lcmAKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYAogICAgICovCiAgICBnZXQoKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gdGhpcy5pbm5lcjsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtIGBSZXN1bHQ8VCwgRT5gIGludG8gYE9wdGlvbjxUPmAKICAgICAqIEByZXR1cm5zIGBTb21lKHRoaXMuaW5uZXIpYCBpZiBgT2tgLCBgTm9uZWAgaWYgYEVycmAKICAgICAqLwogICAgb2soKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gbmV3IFNvbWUodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBgUmVzdWx0PFQsIEU+YCBpbnRvIGBPcHRpb248RT5gCiAgICAgKiBAcmV0dXJucyBgU29tZSh0aGlzLmlubmVyKWAgaWYgYEVycmAsIGBOb25lYCBpZiBgT2tgCiAgICAgKi8KICAgIGVycigpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiBuZXcgTm9uZSgpOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGFuIGl0ZXJhdG9yIG92ZXIgdGhlIHBvc3NpYmx5IGNvbnRhaW5lZCB2YWx1ZQogICAgICogQHlpZWxkcyBgdGhpcy5pbm5lcmAgaWYgYE9rYAogICAgICovCiAgICAqW1N5bWJvbC5pdGVyYXRvcl0oKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICB5aWVsZCB0aGlzLmlubmVyOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm0gYFJlc3VsdDxULEU+YCBpbnRvIGBbVCxFXWAKICAgICAqIEByZXR1cm5zIGBbdGhpcy5pbm5lciwgdW5kZWZpbmVkXWAgaWYgYE9rYCwgYFt1bmRlZmluZWQsIHRoaXMuaW5uZXJdYCBpZiBgRXJyYAogICAgICovCiAgICBzcGxpdCgpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiBbdGhpcy5pbm5lciwgdW5kZWZpbmVkXTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyB0cnVlIGlmIHRoZSByZXN1bHQgaXMgYW4gYE9rYCB2YWx1ZSBjb250YWluaW5nIHRoZSBnaXZlbiB2YWx1ZQogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYE9rYCBhbmQgYHRoaXMuaW5uZXIgPT09IHZhbHVlYCwgYGZhbHNlYCBvdGhlcndpc2UKICAgICAqLwogICAgY29udGFpbnModmFsdWUpIHsKICAgICAgICByZXR1cm4gdGhpcy5pbm5lciA9PT0gdmFsdWU7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgdHJ1ZSBpZiB0aGUgcmVzdWx0IGlzIGFuIGBFcnJgIHZhbHVlIGNvbnRhaW5pbmcgdGhlIGdpdmVuIHZhbHVlCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgRXJyYCBhbmQgYHRoaXMuaW5uZXIgPT09IHZhbHVlYCwgYGZhbHNlYCBvdGhlcndpc2UKICAgICAqLwogICAgY29udGFpbnNFcnIodmFsdWUpIHsKICAgICAgICByZXR1cm4gZmFsc2U7CiAgICB9CiAgICAvKioKICAgICAqIEp1c3QgbGlrZSBgdW53cmFwYCBidXQgaXQgdGhyb3dzIHRvIHRoZSBjbG9zZXN0IGBSZXN1bHQudW50aHJvd2AKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgT2tgCiAgICAgKiBAdGhyb3dzIGB0aGlzYCBpZiBgRXJyYAogICAgICogQHNlZSBSZXN1bHQudW50aHJvdwogICAgICogQHNlZSBSZXN1bHQudW50aHJvd1N5bmMKICAgICAqLwogICAgdGhyb3codGhyb3dlcikgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIHRoaXMuaW5uZXI7CiAgICB9CiAgICAvKioKICAgICAqIEdldCB0aGUgaW5uZXIgdmFsdWUgb3IgdGhyb3cgdGhlIGlubmVyIGVycm9yIHdyYXBwZWQgaW5zaWRlIGFub3RoZXIgRXJyb3IKICAgICAqIEBwYXJhbSBtZXNzYWdlCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAgaWYgYE9rYCwgYEVycm9yKG1lc3NhZ2UsIHsgY2F1c2U6IHRoaXMuaW5uZXIgfSlgIGlmIGBFcnJgCiAgICAgKi8KICAgIGV4cGVjdChtZXNzYWdlKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gdGhpcy5pbm5lcjsKICAgIH0KICAgIC8qKgogICAgICogR2V0IHRoZSBpbm5lciBlcnJvciBvciB0aHJvdyB0aGUgaW5uZXIgdmFsdWUgd3JhcHBlZCBpbnNpZGUgYW5vdGhlciBFcnJvcgogICAgICogQHBhcmFtIG1lc3NhZ2UKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgRXJyYCwgYEVycm9yKG1lc3NhZ2UsIHsgY2F1c2U6IHRoaXMuaW5uZXIgfSlgIGlmIGBPa2AKICAgICAqLwogICAgZXhwZWN0RXJyKG1lc3NhZ2UpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHRocm93IFBhbmljLmZyb20obmV3IEVycm9yKG1lc3NhZ2UsIHsgY2F1c2U6IHRoaXMgfSkpOwogICAgfQogICAgLyoqCiAgICAgKiBHZXQgdGhlIGlubmVyIHZhbHVlIG9yIHBhbmljCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAgaWYgYE9rYAogICAgICogQHRocm93cyBgdGhpcy5pbm5lcmAgaWYgYEVycmAKICAgICAqLwogICAgdW53cmFwKCkgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIHRoaXMuaW5uZXI7CiAgICB9CiAgICAvKioKICAgICAqIEdldCB0aGUgaW5uZXIgZXJyb3Igb3IgcGFuaWMKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgRXJyYAogICAgICogQHRocm93cyBgdGhpcy5pbm5lcmAgaWYgYE9rYAogICAgICovCiAgICB1bndyYXBFcnIoKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICB0aHJvdyBQYW5pYy5mcm9tKG5ldyBFcnJvcihgQW4gT2sgaGFzIGJlZW4gdW53cmFwcGVkYCwgeyBjYXVzZTogdGhpcyB9KSk7CiAgICB9CiAgICAvKioKICAgICAqIEdldCB0aGUgaW5uZXIgdmFsdWUgb3IgYSBkZWZhdWx0IG9uZQogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAgaWYgYE9rYCwgYHZhbHVlYCBpZiBgRXJyYAogICAgICovCiAgICB1bndyYXBPcih2YWx1ZSkgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIHRoaXMuaW5uZXI7CiAgICB9CiAgICAvKioKICAgICAqIEdldCB0aGUgaW5uZXIgdmFsdWUgb3IgY29tcHV0ZSBhIGRlZmF1bHQgb25lIGZyb20gdGhlIGlubmVyIGVycm9yCiAgICAgKiBAcGFyYW0gZXJyTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAgaWYgYE9rYCwgYGF3YWl0IGVyck1hcHBlcih0aGlzLmlubmVyKWAgaWYgYEVycmAKICAgICAqIEB0aHJvd3MgaWYgYGF3YWl0IGVyck1hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIGFzeW5jIHVud3JhcE9yRWxzZShlcnJNYXBwZXIpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiB0aGlzLmlubmVyOwogICAgfQogICAgLyoqCiAgICAgKiBHZXQgdGhlIGlubmVyIHZhbHVlIG9yIGNvbXB1dGUgYSBkZWZhdWx0IG9uZSBmcm9tIHRoZSBpbm5lciBlcnJvcgogICAgICogQHBhcmFtIGVyck1hcHBlcgogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBPa2AsIGBlcnJNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBFcnJgCiAgICAgKiBAdGhyb3dzIGlmIGBlcnJNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICB1bndyYXBPckVsc2VTeW5jKGVyck1hcHBlcikgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIHRoaXMuaW5uZXI7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBSZXN1bHQ8UHJvbWlzZTxUPiwgRT4gaW50byBQcm9taXNlPFJlc3VsdDxULCBFPj4KICAgICAqIEByZXR1cm5zIGBhd2FpdCB0aGlzLmlubmVyYCBpZiBgT2tgLCBgdGhpc2AgaWYgYEVycmAKICAgICAqLwogICAgYXN5bmMgYXdhaXQoKSB7CiAgICAgICAgcmV0dXJuIG5ldyBPayhhd2FpdCB0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtIFJlc3VsdDxULCBQcm9taXNlPEU+PiBpbnRvIFByb21pc2U8UmVzdWx0PFQsIEU+PgogICAgICogQHJldHVybnMgYGF3YWl0IHRoaXMuaW5uZXJgIGlmIGBFcnJgLCBgdGhpc2AgaWYgYE9rYAogICAgICovCiAgICBhc3luYyBhd2FpdEVycigpIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtIFJlc3VsdDxQcm9taXNlPFQ+LCBQcm9taXNlPEU+PiBpbnRvIFByb21pc2U8UmVzdWx0PFQsIEU+PgogICAgICogQHJldHVybnMgYGF3YWl0IHRoaXMuaW5uZXJgCiAgICAgKi8KICAgIGFzeW5jIGF3YWl0QWxsKCkgewogICAgICAgIHJldHVybiBhd2FpdCB0aGlzLmF3YWl0KCk7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBgUmVzdWx0PFQsIEU+YCBpbnRvIGBSZXN1bHQ8dm9pZCwgRT5gCiAgICAgKiBAcmV0dXJucyBgT2s8dm9pZD5gIGlmIGBPazxUPmAsIGBFcnI8RT5gIGlmIGBFPEU+YAogICAgICovCiAgICBjbGVhcigpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiBPay52b2lkKCk7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBgUmVzdWx0PFQsIEU+YCBpbnRvIGBSZXN1bHQ8VCwgdm9pZD5gCiAgICAgKiBAcmV0dXJucyBgT2s8VD5gIGlmIGBPazxUPmAsIGBFcnI8dm9pZD5gIGlmIGBFPEU+YAogICAgICovCiAgICBjbGVhckVycigpIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogQ2FsbHMgdGhlIGdpdmVuIGNhbGxiYWNrIHdpdGggdGhlIGlubmVyIHZhbHVlIGlmIGBPa2AKICAgICAqIEBwYXJhbSBva0NhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgdGhpc2AKICAgICAqLwogICAgYXN5bmMgaW5zcGVjdChva0NhbGxiYWNrKSB7CiAgICAgICAgYXdhaXQgb2tDYWxsYmFjayh0aGlzLmlubmVyKTsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogQ2FsbHMgdGhlIGdpdmVuIGNhbGxiYWNrIHdpdGggdGhlIGlubmVyIHZhbHVlIGlmIGBPa2AKICAgICAqIEBwYXJhbSBva0NhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgdGhpc2AKICAgICAqLwogICAgaW5zcGVjdFN5bmMob2tDYWxsYmFjaykgewogICAgICAgIG9rQ2FsbGJhY2sodGhpcy5pbm5lcik7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIENhbGxzIHRoZSBnaXZlbiBjYWxsYmFjayB3aXRoIHRoZSBpbm5lciB2YWx1ZSBpZiBgRXJyYAogICAgICogQHBhcmFtIGVyckNhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgdGhpc2AKICAgICAqLwogICAgYXN5bmMgaW5zcGVjdEVycihlcnJDYWxsYmFjaykgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBDYWxscyB0aGUgZ2l2ZW4gY2FsbGJhY2sgd2l0aCB0aGUgaW5uZXIgdmFsdWUgaWYgYEVycmAKICAgICAqIEBwYXJhbSBlcnJDYWxsYmFjawogICAgICogQHJldHVybnMgYHRoaXNgCiAgICAgKi8KICAgIGluc3BlY3RFcnJTeW5jKGVyckNhbGxiYWNrKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybiBhIG5ldyBgT2tgIGJ1dCB3aXRoIHRoZSBnaXZlbiBgaW5uZXJgCiAgICAgKiBAcGFyYW0gaW5uZXIKICAgICAqIEByZXR1cm5zIGBPayhpbm5lcilgIGlmIGBPa2AsIGB0aGlzYCBpZiBgRXJyYAogICAgICovCiAgICBzZXQoaW5uZXIpIHsKICAgICAgICByZXR1cm4gbmV3IE9rKGlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJuIGEgbmV3IGBFcnJgIGJ1dCB3aXRoIHRoZSBnaXZlbiBgaW5uZXJgCiAgICAgKiBAcGFyYW0gaW5uZXIKICAgICAqIEByZXR1cm5zIGBFcnIoaW5uZXIpYCBpZiBgRXJyYCwgYHRoaXNgIGlmIGBPa2AKICAgICAqLwogICAgc2V0RXJyKGlubmVyKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIE1hcCB0aGUgaW5uZXIgdmFsdWUgaW50byBhbm90aGVyCiAgICAgKiBAcGFyYW0gb2tNYXBwZXIKICAgICAqIEByZXR1cm5zIGBPayhhd2FpdCBva01hcHBlcih0aGlzLmlubmVyKSlgIGlmIGBPa2AsIGB0aGlzYCBpZiBgRXJyYAogICAgICogQHRocm93cyBpZiBgYXdhaXQgb2tNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICBhc3luYyBtYXAob2tNYXBwZXIpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiBuZXcgT2soYXdhaXQgb2tNYXBwZXIodGhpcy5pbm5lcikpOwogICAgfQogICAgLyoqCiAgICAgKiBNYXAgdGhlIGlubmVyIHZhbHVlIGludG8gYW5vdGhlcgogICAgICogQHBhcmFtIG9rTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgT2sob2tNYXBwZXIodGhpcy5pbm5lcikpYCBpZiBgT2tgLCBgdGhpc2AgaWYgYEVycmAKICAgICAqIEB0aHJvd3MgaWYgYG9rTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgbWFwU3luYyhva01hcHBlcikgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIG5ldyBPayhva01hcHBlcih0aGlzLmlubmVyKSk7CiAgICB9CiAgICAvKioKICAgICAqIE1hcCB0aGUgaW5uZXIgZXJyb3IgaW50byBhbm90aGVyCiAgICAgKiBAcGFyYW0gZXJyTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgRXJyKGF3YWl0IGVyck1hcHBlcih0aGlzLmlubmVyKSlgIGlmIGBFcnJgLCBgdGhpc2AgaWYgYE9rYAogICAgICogQHRocm93cyBpZiBgYXdhaXQgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgYXN5bmMgbWFwRXJyKGVyck1hcHBlcikgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBNYXAgdGhlIGlubmVyIGVycm9yIGludG8gYW5vdGhlcgogICAgICogQHBhcmFtIGVyck1hcHBlcgogICAgICogQHJldHVybnMgYEVycihlcnJNYXBwZXIodGhpcy5pbm5lcikpYCBpZiBgRXJyYCwgYHRoaXNgIGlmIGBPa2AKICAgICAqIEB0aHJvd3MgaWYgYGVyck1hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIG1hcEVyclN5bmMoZXJyTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIE1hcCB0aGUgaW5uZXIgdmFsdWUgaW50byBhbm90aGVyLCBvciBhIGRlZmF1bHQgb25lCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEBwYXJhbSBva01hcHBlcgogICAgICogQHJldHVybnMgYGF3YWl0IG9rTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgT2tgLCBgdmFsdWVgIGlmIGBFcnJgCiAgICAgKiBAdGhyb3dzIGlmIGBhd2FpdCBva01hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIGFzeW5jIG1hcE9yKHZhbHVlLCBva01hcHBlcikgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIGF3YWl0IG9rTWFwcGVyKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBNYXAgdGhlIGlubmVyIHZhbHVlIGludG8gYW5vdGhlciwgb3IgYSBkZWZhdWx0IG9uZQogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcGFyYW0gb2tNYXBwZXIKICAgICAqIEByZXR1cm5zIGBva01hcHBlcih0aGlzLmlubmVyKWAgaWYgYE9rYCwgYHZhbHVlYCBpZiBgRXJyYAogICAgICogQHRocm93cyBpZiBgb2tNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICBtYXBPclN5bmModmFsdWUsIG9rTWFwcGVyKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gb2tNYXBwZXIodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIE1hcCB0aGUgaW5uZXIgdmFsdWUgaW50byBhbm90aGVyLCBvciBhIGRlZmF1bHQgb25lCiAgICAgKiBAcGFyYW0gZXJyTWFwcGVyCiAgICAgKiBAcGFyYW0gb2tNYXBwZXIKICAgICAqIEByZXR1cm5zIGBhd2FpdCBva01hcHBlcih0aGlzLmlubmVyKWAgaWYgYE9rYCwgYGF3YWl0IGVyck1hcHBlcih0aGlzLmlubmVyKWAgaWYgYEVycmAKICAgICAqIEB0aHJvd3MgaWYgYGF3YWl0IG9rTWFwcGVyKHRoaXMuaW5uZXIpYCBvciBgYXdhaXQgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgYXN5bmMgbWFwT3JFbHNlKGVyck1hcHBlciwgb2tNYXBwZXIpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiBhd2FpdCBva01hcHBlcih0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogTWFwIHRoZSBpbm5lciB2YWx1ZSBpbnRvIGFub3RoZXIsIG9yIGEgZGVmYXVsdCBvbmUKICAgICAqIEBwYXJhbSBlcnJNYXBwZXIKICAgICAqIEBwYXJhbSBva01hcHBlcgogICAgICogQHJldHVybnMgYG9rTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgT2tgLCBgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgRXJyYAogICAgICogQHRocm93cyBpZiBgb2tNYXBwZXIodGhpcy5pbm5lcilgIG9yIGBlcnJNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICBtYXBPckVsc2VTeW5jKGVyck1hcHBlciwgb2tNYXBwZXIpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiBva01hcHBlcih0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJuIGB2YWx1ZWAgaWYgYE9rYCwgcmV0dXJuIGB0aGlzYCBpZiBgRXJyYAogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcmV0dXJucyBgdmFsdWVgIGlmIGBPa2AsIGB0aGlzYCBpZiBgRXJyYAogICAgICovCiAgICBhbmQodmFsdWUpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiB2YWx1ZTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJuIGBhd2FpdCBva01hcHBlcih0aGlzLmlubmVyKWAgaWYgYE9rYCwgcmV0dXJuIGB0aGlzYCBpZiBgRXJyYAogICAgICogQHBhcmFtIG9rTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgYXdhaXQgb2tNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBPa2AsIGB0aGlzYCBpZiBgRXJyYAogICAgICogQHRocm93cyBpZiBgYXdhaXQgb2tNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICBhc3luYyBhbmRUaGVuKG9rTWFwcGVyKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gYXdhaXQgb2tNYXBwZXIodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybiBgb2tNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBPa2AsIHJldHVybiBgdGhpc2AgaWYgYEVycmAKICAgICAqIEBwYXJhbSBva01hcHBlcgogICAgICogQHJldHVybnMgYG9rTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgT2tgLCBgdGhpc2AgaWYgYEVycmAKICAgICAqIEB0aHJvd3MgaWYgYG9rTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgYW5kVGhlblN5bmMob2tNYXBwZXIpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiBva01hcHBlcih0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJuIGB2YWx1ZWAgaWYgYEVycmAsIHJldHVybiBgdGhpc2AgaWYgYE9rYAogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcmV0dXJucyBgdmFsdWVgIGlmIGBFcnJgLCBgdGhpc2AgaWYgYE9rYAogICAgICovCiAgICBvcih2YWx1ZSkgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm4gYGF3YWl0IGVyck1hcHBlcih0aGlzLmlubmVyKWAgaWYgYEVycmAsIHJldHVybiBgdGhpc2AgaWYgYE9rYAogICAgICogQHBhcmFtIGVyck1hcHBlcgogICAgICogQHJldHVybnMgYGF3YWl0IGVyck1hcHBlcih0aGlzLmlubmVyKWAgaWYgYEVycmAsIGB0aGlzYCBpZiBgT2tgCiAgICAgKiBAdGhyb3dzIGlmIGBhd2FpdCBlcnJNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICBhc3luYyBvckVsc2UoZXJyTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybiBgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgRXJyYCwgcmV0dXJuIGB0aGlzYCBpZiBgT2tgCiAgICAgKiBAcGFyYW0gZXJyTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgRXJyYCwgYHRoaXNgIGlmIGBPa2AKICAgICAqIEB0aHJvd3MgaWYgYGVyck1hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIG9yRWxzZVN5bmMoZXJyTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBSZXN1bHQ8UmVzdWx0PFQsIEUxPiwgRTI+IGludG8gUmVzdWx0PFQsIEUxIHwgRTI+CiAgICAgKiBAcGFyYW0gcmVzdWx0CiAgICAgKiBAcmV0dXJucyBgdGhpc2AgaWYgYEVycmAsIGB0aGlzLmlubmVyYCBpZiBgT2tgCiAgICAgKi8KICAgIGZsYXR0ZW4oKSB7CiAgICAgICAgcmV0dXJuIHRoaXMuaW5uZXI7CiAgICB9Cn0KCgovLyMgc291cmNlTWFwcGluZ1VSTD1vay5tanMubWFwCgo7Ly8gQ09OQ0FURU5BVEVEIE1PRFVMRTogLi9ub2RlX21vZHVsZXMvQGhhemFlNDEvb3B0aW9uL2Rpc3QvZXNtL21vZHMvb3B0aW9uL3NvbWUubWpzCgoKCmNsYXNzIFNvbWUgewogICAgaW5uZXI7CiAgICAvKioKICAgICAqIEFuIGV4aXN0aW5nIHZhbHVlCiAgICAgKiBAcGFyYW0gaW5uZXIKICAgICAqLwogICAgY29uc3RydWN0b3IoaW5uZXIpIHsKICAgICAgICB0aGlzLmlubmVyID0gaW5uZXI7CiAgICB9CiAgICAvKioKICAgICAqIENyZWF0ZSBhIGBTb21lYAogICAgICogQHBhcmFtIGlubmVyCiAgICAgKiBAcmV0dXJucyBgU29tZShpbm5lcilgCiAgICAgKi8KICAgIHN0YXRpYyBuZXcoaW5uZXIpIHsKICAgICAgICByZXR1cm4gbmV3IFNvbWUoaW5uZXIpOwogICAgfQogICAgc3RhdGljIGZyb20oaW5pdCkgewogICAgICAgIHJldHVybiBuZXcgU29tZShpbml0LmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogVHlwZSBndWFyZCBmb3IgYFNvbWVgCiAgICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYFNvbWVgLCBgZmFsc2VgIGlmIGBOb25lYAogICAgICovCiAgICBpc1NvbWUoKSB7CiAgICAgICAgcmV0dXJuIHRydWU7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYHRydWVgIGlmIHRoZSBvcHRpb24gaXMgYSBgU29tZWAgYW5kIHRoZSB2YWx1ZSBpbnNpZGUgb2YgaXQgbWF0Y2hlcyBhIHByZWRpY2F0ZQogICAgICogQHBhcmFtIHNvbWVQcmVkaWNhdGUKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgU29tZWAgYW5kIGBhd2FpdCBzb21lUHJlZGljYXRlKHRoaXMuaW5uZXIpYCwgYE5vbmVgIG90aGVyd2lzZQogICAgICovCiAgICBhc3luYyBpc1NvbWVBbmQoc29tZVByZWRpY2F0ZSkgewogICAgICAgIHJldHVybiBhd2FpdCBzb21lUHJlZGljYXRlKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGB0cnVlYCBpZiB0aGUgb3B0aW9uIGlzIGEgYFNvbWVgIGFuZCB0aGUgdmFsdWUgaW5zaWRlIG9mIGl0IG1hdGNoZXMgYSBwcmVkaWNhdGUKICAgICAqIEBwYXJhbSBzb21lUHJlZGljYXRlCiAgICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYFNvbWVgIGFuZCBgc29tZVByZWRpY2F0ZSh0aGlzLmlubmVyKWAsIGBOb25lYCBvdGhlcndpc2UKICAgICAqLwogICAgaXNTb21lQW5kU3luYyhzb21lUHJlZGljYXRlKSB7CiAgICAgICAgcmV0dXJuIHNvbWVQcmVkaWNhdGUodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFR5cGUgZ3VhcmQgZm9yIGBOb25lYAogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBOb25lYCwgYGZhbHNlYCBpZiBgU29tZWAKICAgICAqLwogICAgaXNOb25lKCkgewogICAgICAgIHJldHVybiBmYWxzZTsKICAgIH0KICAgIC8qKgogICAgICogQ29tcGlsZS10aW1lIHNhZmVseSBnZXQgYHRoaXMuaW5uZXJgCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAKICAgICAqLwogICAgZ2V0KCkgewogICAgICAgIHJldHVybiB0aGlzLmlubmVyOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGFuIGl0ZXJhdG9yIG92ZXIgdGhlIHBvc3NpYmx5IGNvbnRhaW5lZCB2YWx1ZQogICAgICogQHlpZWxkcyBgdGhpcy5pbm5lcmAgaWYgYFNvbWVgCiAgICAgKi8KICAgICpbU3ltYm9sLml0ZXJhdG9yXSgpIHsKICAgICAgICB5aWVsZCB0aGlzLmlubmVyOwogICAgfQogICAgLyoqCiAgICAgKiBHZXQgdGhlIGlubmVyIHZhbHVlIGlmIGBTb21lYCwgdGhyb3cgYEVycm9yKG1lc3NhZ2UpYCBvdGhlcndpc2UKICAgICAqIEBwYXJhbSBtZXNzYWdlCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAgaWYgYFNvbWVgCiAgICAgKiBAdGhyb3dzIGBFcnJvcihtZXNzYWdlKWAgaWYgYE5vbmVgCiAgICAgKi8KICAgIGV4cGVjdChtZXNzYWdlKSB7CiAgICAgICAgcmV0dXJuIHRoaXMuaW5uZXI7CiAgICB9CiAgICAvKioKICAgICAqIEdldCB0aGUgaW5uZXIgdmFsdWUgb3IgdGhyb3cgYSBOb25lRXJyb3IKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgU29tZWAKICAgICAqIEB0aHJvd3MgYE5vbmVFcnJvcmAgaWYgYE5vbmVgCiAgICAgKi8KICAgIHVud3JhcCgpIHsKICAgICAgICByZXR1cm4gdGhpcy5pbm5lcjsKICAgIH0KICAgIC8qKgogICAgICogR2V0IHRoZSBpbm5lciB2YWx1ZSBvciBhIGRlZmF1bHQgb25lCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgU29tZWAsIGB2YWx1ZWAgaWYgYE5vbmVgCiAgICAgKi8KICAgIHVud3JhcE9yKHZhbHVlKSB7CiAgICAgICAgcmV0dXJuIHRoaXMuaW5uZXI7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgdGhlIGNvbnRhaW5lZCBgU29tZWAgdmFsdWUgb3IgY29tcHV0ZXMgaXQgZnJvbSBhIGNsb3N1cmUKICAgICAqIEBwYXJhbSBub25lQ2FsbGJhY2sKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgU29tZWAsIGBhd2FpdCBub25lQ2FsbGJhY2soKWAgaWYgYE5vbmVgCiAgICAgKi8KICAgIGFzeW5jIHVud3JhcE9yRWxzZShub25lQ2FsbGJhY2spIHsKICAgICAgICByZXR1cm4gdGhpcy5pbm5lcjsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyB0aGUgY29udGFpbmVkIGBTb21lYCB2YWx1ZSBvciBjb21wdXRlcyBpdCBmcm9tIGEgY2xvc3VyZQogICAgICogQHBhcmFtIG5vbmVDYWxsYmFjawogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBTb21lYCwgYG5vbmVDYWxsYmFjaygpYCBpZiBgTm9uZWAKICAgICAqLwogICAgdW53cmFwT3JFbHNlU3luYyhub25lQ2FsbGJhY2spIHsKICAgICAgICByZXR1cm4gdGhpcy5pbm5lcjsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtIGBPcHRpb248VD5gIGludG8gYFJlc3VsdDxULCBOb25lRXJyb3I+YAogICAgICogQHJldHVybnMgYE9rKHRoaXMuaW5uZXIpYCBpZiBgU29tZWAsIGBFcnIoTm9uZUVycm9yKWAgaWYgYE5vbmVgCiAgICAgKi8KICAgIG9rKCkgewogICAgICAgIHJldHVybiBuZXcgT2sodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBgT3B0aW9uPFQ+YCBpbnRvIGBSZXN1bHQ8VCwgRT5gCiAgICAgKiBAcGFyYW0gZXJyb3IKICAgICAqIEByZXR1cm5zIGBPayh0aGlzLmlubmVyKWAgaWYgYFNvbWVgLCBgRXJyKGVycm9yKWAgaWYgYE5vbmVgCiAgICAgKi8KICAgIG9rT3IoZXJyb3IpIHsKICAgICAgICByZXR1cm4gbmV3IE9rKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm1zIHRoZSBgT3B0aW9uPFQ+YCBpbnRvIGEgYFJlc3VsdDxULCBFPmAsIG1hcHBpbmcgYFNvbWUodilgIHRvIGBPayh2KWAgYW5kIGBOb25lYCB0byBgRXJyKGVycigpKWAKICAgICAqIEBwYXJhbSBub25lQ2FsbGJhY2sKICAgICAqIEByZXR1cm5zIGBPayh0aGlzLmlubmVyKWAgaWYgYFNvbWVgLCBgRXJyKGF3YWl0IG5vbmVDYWxsYmFjaygpKWAgaXMgYE5vbmVgCiAgICAgKi8KICAgIGFzeW5jIG9rT3JFbHNlKG5vbmVDYWxsYmFjaykgewogICAgICAgIHJldHVybiBuZXcgT2sodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybXMgdGhlIGBPcHRpb248VD5gIGludG8gYSBgUmVzdWx0PFQsIEU+YCwgbWFwcGluZyBgU29tZSh2KWAgdG8gYE9rKHYpYCBhbmQgYE5vbmVgIHRvIGBFcnIoZXJyKCkpYAogICAgICogQHBhcmFtIG5vbmVDYWxsYmFjawogICAgICogQHJldHVybnMgYE9rKHRoaXMuaW5uZXIpYCBpZiBgU29tZWAsIGBFcnIobm9uZUNhbGxiYWNrKCkpYCBpcyBgTm9uZWAKICAgICAqLwogICAgb2tPckVsc2VTeW5jKG5vbmVDYWxsYmFjaykgewogICAgICAgIHJldHVybiBuZXcgT2sodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYE5vbmVgIGlmIHRoZSBvcHRpb24gaXMgYE5vbmVgLCBvdGhlcndpc2UgY2FsbHMgYHNvbWVQcmVkaWNhdGVgIHdpdGggdGhlIHdyYXBwZWQgdmFsdWUKICAgICAqIEBwYXJhbSBzb21lUHJlZGljYXRlCiAgICAgKiBAcmV0dXJucyBgU29tZWAgaWYgYFNvbWVgIGFuZCBgYXdhaXQgc29tZVByZWRpY2F0ZSh0aGlzLmlubmVyKWAsIGBOb25lYCBvdGhlcndpc2UKICAgICAqLwogICAgYXN5bmMgZmlsdGVyKHNvbWVQcmVkaWNhdGUpIHsKICAgICAgICBpZiAoYXdhaXQgc29tZVByZWRpY2F0ZSh0aGlzLmlubmVyKSkKICAgICAgICAgICAgcmV0dXJuIHRoaXM7CiAgICAgICAgZWxzZQogICAgICAgICAgICByZXR1cm4gbmV3IE5vbmUoKTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBgTm9uZWAgaWYgdGhlIG9wdGlvbiBpcyBgTm9uZWAsIG90aGVyd2lzZSBjYWxscyBgc29tZVByZWRpY2F0ZWAgd2l0aCB0aGUgd3JhcHBlZCB2YWx1ZQogICAgICogQHBhcmFtIHNvbWVQcmVkaWNhdGUKICAgICAqIEByZXR1cm5zIGBTb21lYCBpZiBgU29tZWAgYW5kIGBzb21lUHJlZGljYXRlKHRoaXMuaW5uZXIpYCwgYE5vbmVgIG90aGVyd2lzZQogICAgICovCiAgICBmaWx0ZXJTeW5jKHNvbWVQcmVkaWNhdGUpIHsKICAgICAgICBpZiAoc29tZVByZWRpY2F0ZSh0aGlzLmlubmVyKSkKICAgICAgICAgICAgcmV0dXJuIHRoaXM7CiAgICAgICAgZWxzZQogICAgICAgICAgICByZXR1cm4gbmV3IE5vbmUoKTsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtIGBPcHRpb248UHJvbWlzZTxUPj5gIGludG8gYFByb21pc2U8T3B0aW9uPFQ+PmAKICAgICAqIEByZXR1cm5zIGBQcm9taXNlPE9wdGlvbjxUPj5gCiAgICAgKi8KICAgIGFzeW5jIGF3YWl0KCkgewogICAgICAgIHJldHVybiBuZXcgU29tZShhd2FpdCB0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBgdHJ1ZWAgaWYgdGhlIG9wdGlvbiBpcyBhIGBTb21lYCB2YWx1ZSBjb250YWluaW5nIHRoZSBnaXZlbiB2YWx1ZQogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYFNvbWVgIGFuZCBgdGhpcy5pbm5lciA9PT0gdmFsdWVgLCBgTm9uZWAgb3RoZXJ3aXNlCiAgICAgKi8KICAgIGNvbnRhaW5zKHZhbHVlKSB7CiAgICAgICAgcmV0dXJuIHRoaXMuaW5uZXIgPT09IHZhbHVlOwogICAgfQogICAgLyoqCiAgICAgKiBDYWxscyB0aGUgZ2l2ZW4gY2FsbGJhY2sgd2l0aCB0aGUgaW5uZXIgdmFsdWUgaWYgYE9rYAogICAgICogQHBhcmFtIHNvbWVDYWxsYmFjawogICAgICogQHJldHVybnMgYHRoaXNgCiAgICAgKi8KICAgIGFzeW5jIGluc3BlY3Qoc29tZUNhbGxiYWNrKSB7CiAgICAgICAgYXdhaXQgc29tZUNhbGxiYWNrKHRoaXMuaW5uZXIpOwogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBDYWxscyB0aGUgZ2l2ZW4gY2FsbGJhY2sgd2l0aCB0aGUgaW5uZXIgdmFsdWUgaWYgYE9rYAogICAgICogQHBhcmFtIHNvbWVDYWxsYmFjawogICAgICogQHJldHVybnMgYHRoaXNgCiAgICAgKi8KICAgIGluc3BlY3RTeW5jKHNvbWVDYWxsYmFjaykgewogICAgICAgIHNvbWVDYWxsYmFjayh0aGlzLmlubmVyKTsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogTWFwcyBhbiBgT3B0aW9uPFQ+YCB0byBgT3B0aW9uPFU+YCBieSBhcHBseWluZyBhIGZ1bmN0aW9uIHRvIGEgY29udGFpbmVkIHZhbHVlIChpZiBgU29tZWApIG9yIHJldHVybnMgYE5vbmVgIChpZiBgTm9uZWApCiAgICAgKiBAcGFyYW0gc29tZU1hcHBlcgogICAgICogQHJldHVybnMgYFNvbWUoYXdhaXQgc29tZU1hcHBlcih0aGlzLmlubmVyKSlgIGlmIGBTb21lYCwgYHRoaXNgIGlmIGBOb25lYAogICAgICovCiAgICBhc3luYyBtYXAoc29tZU1hcHBlcikgewogICAgICAgIHJldHVybiBuZXcgU29tZShhd2FpdCBzb21lTWFwcGVyKHRoaXMuaW5uZXIpKTsKICAgIH0KICAgIC8qKgogICAgICogTWFwcyBhbiBgT3B0aW9uPFQ+YCB0byBgT3B0aW9uPFU+YCBieSBhcHBseWluZyBhIGZ1bmN0aW9uIHRvIGEgY29udGFpbmVkIHZhbHVlIChpZiBgU29tZWApIG9yIHJldHVybnMgYE5vbmVgIChpZiBgTm9uZWApCiAgICAgKiBAcGFyYW0gc29tZU1hcHBlcgogICAgICogQHJldHVybnMgYFNvbWUoc29tZU1hcHBlcih0aGlzLmlubmVyKSlgIGlmIGBTb21lYCwgYHRoaXNgIGlmIGBOb25lYAogICAgICovCiAgICBtYXBTeW5jKHNvbWVNYXBwZXIpIHsKICAgICAgICByZXR1cm4gbmV3IFNvbWUoc29tZU1hcHBlcih0aGlzLmlubmVyKSk7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgdGhlIHByb3ZpZGVkIGRlZmF1bHQgcmVzdWx0IChpZiBub25lKSwgb3IgYXBwbGllcyBhIGZ1bmN0aW9uIHRvIHRoZSBjb250YWluZWQgdmFsdWUgKGlmIGFueSkKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHBhcmFtIHNvbWVNYXBwZXIKICAgICAqIEByZXR1cm5zIGB2YWx1ZWAgaWYgYE5vbmVgLCBgYXdhaXQgc29tZU1hcHBlcih0aGlzLmlubmVyKWAgaWYgYFNvbWVgCiAgICAgKi8KICAgIGFzeW5jIG1hcE9yKHZhbHVlLCBzb21lTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIGF3YWl0IHNvbWVNYXBwZXIodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgdGhlIHByb3ZpZGVkIGRlZmF1bHQgcmVzdWx0IChpZiBub25lKSwgb3IgYXBwbGllcyBhIGZ1bmN0aW9uIHRvIHRoZSBjb250YWluZWQgdmFsdWUgKGlmIGFueSkKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHBhcmFtIHNvbWVNYXBwZXIKICAgICAqIEByZXR1cm5zIGB2YWx1ZWAgaWYgYE5vbmVgLCBgc29tZU1hcHBlcih0aGlzLmlubmVyKWAgaWYgYFNvbWVgCiAgICAgKi8KICAgIG1hcE9yU3luYyh2YWx1ZSwgc29tZU1hcHBlcikgewogICAgICAgIHJldHVybiBzb21lTWFwcGVyKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBDb21wdXRlcyBhIGRlZmF1bHQgZnVuY3Rpb24gcmVzdWx0IChpZiBub25lKSwgb3IgYXBwbGllcyBhIGRpZmZlcmVudCBmdW5jdGlvbiB0byB0aGUgY29udGFpbmVkIHZhbHVlIChpZiBhbnkpCiAgICAgKiBAcGFyYW0gbm9uZUNhbGxiYWNrCiAgICAgKiBAcGFyYW0gc29tZU1hcHBlcgogICAgICogQHJldHVybnMgYGF3YWl0IHNvbWVNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBTb21lYCwgYGF3YWl0IG5vbmVDYWxsYmFjaygpYCBpZiBgTm9uZWAKICAgICAqLwogICAgYXN5bmMgbWFwT3JFbHNlKG5vbmVDYWxsYmFjaywgc29tZU1hcHBlcikgewogICAgICAgIHJldHVybiBhd2FpdCBzb21lTWFwcGVyKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBDb21wdXRlcyBhIGRlZmF1bHQgZnVuY3Rpb24gcmVzdWx0IChpZiBub25lKSwgb3IgYXBwbGllcyBhIGRpZmZlcmVudCBmdW5jdGlvbiB0byB0aGUgY29udGFpbmVkIHZhbHVlIChpZiBhbnkpCiAgICAgKiBAcGFyYW0gbm9uZUNhbGxiYWNrCiAgICAgKiBAcGFyYW0gc29tZU1hcHBlcgogICAgICogQHJldHVybnMgYHNvbWVNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBTb21lYCwgYG5vbmVDYWxsYmFjaygpYCBpZiBgTm9uZWAKICAgICAqLwogICAgbWFwT3JFbHNlU3luYyhub25lQ2FsbGJhY2ssIHNvbWVNYXBwZXIpIHsKICAgICAgICByZXR1cm4gc29tZU1hcHBlcih0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBgTm9uZWAgaWYgdGhlIG9wdGlvbiBpcyBgTm9uZWAsIG90aGVyd2lzZSByZXR1cm5zIGB2YWx1ZWAKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHJldHVybnMgYE5vbmVgIGlmIGBOb25lYCwgYHZhbHVlYCBpZiBgU29tZWAKICAgICAqLwogICAgYW5kKHZhbHVlKSB7CiAgICAgICAgcmV0dXJuIHZhbHVlOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGBOb25lYCBpZiB0aGUgb3B0aW9uIGlzIGBOb25lYCwgb3RoZXJ3aXNlIGNhbGxzIGBzb21lTWFwcGVyYCB3aXRoIHRoZSB3cmFwcGVkIHZhbHVlIGFuZCByZXR1cm5zIHRoZSByZXN1bHQKICAgICAqIEBwYXJhbSBzb21lTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgTm9uZWAgaWYgYE5vbmVgLCBgYXdhaXQgc29tZU1hcHBlcih0aGlzLmlubmVyKWAgaWYgYFNvbWVgCiAgICAgKi8KICAgIGFzeW5jIGFuZFRoZW4oc29tZU1hcHBlcikgewogICAgICAgIHJldHVybiBhd2FpdCBzb21lTWFwcGVyKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGBOb25lYCBpZiB0aGUgb3B0aW9uIGlzIGBOb25lYCwgb3RoZXJ3aXNlIGNhbGxzIGBzb21lTWFwcGVyYCB3aXRoIHRoZSB3cmFwcGVkIHZhbHVlIGFuZCByZXR1cm5zIHRoZSByZXN1bHQKICAgICAqIEBwYXJhbSBzb21lTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgTm9uZWAgaWYgYE5vbmVgLCBgc29tZU1hcHBlcih0aGlzLmlubmVyKWAgaWYgYFNvbWVgCiAgICAgKi8KICAgIGFuZFRoZW5TeW5jKHNvbWVNYXBwZXIpIHsKICAgICAgICByZXR1cm4gc29tZU1hcHBlcih0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBgdGhpc2AgaWYgYFNvbWVgLCBvdGhlcndpc2UgcmV0dXJucyBgdmFsdWVgCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEByZXR1cm5zIGB0aGlzYCBpZiBgU29tZWAsIGB2YWx1ZWAgaWYgYE5vbmVgCiAgICAgKi8KICAgIG9yKHZhbHVlKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYHRoaXNgIGlmIGBTb21lYCwgb3RoZXJ3aXNlIGNhbGxzIGBub25lQ2FsbGJhY2tgIGFuZCByZXR1cm5zIHRoZSByZXN1bHQKICAgICAqIEBwYXJhbSBub25lQ2FsbGJhY2sKICAgICAqIEByZXR1cm5zIGB0aGlzYCBpZiBgU29tZWAsIGBhd2FpdCBub25lQ2FsbGJhY2soKWAgaWYgYE5vbmVgCiAgICAgKi8KICAgIGFzeW5jIG9yRWxzZShub25lQ2FsbGJhY2spIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBgdGhpc2AgaWYgYFNvbWVgLCBvdGhlcndpc2UgY2FsbHMgYG5vbmVDYWxsYmFja2AgYW5kIHJldHVybnMgdGhlIHJlc3VsdAogICAgICogQHBhcmFtIG5vbmVDYWxsYmFjawogICAgICogQHJldHVybnMgYHRoaXNgIGlmIGBTb21lYCwgYG5vbmVDYWxsYmFjaygpYCBpZiBgTm9uZWAKICAgICAqLwogICAgb3JFbHNlU3luYyhub25lQ2FsbGJhY2spIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBgU29tZWAgaWYgZXhhY3RseSBvbmUgb2YgdGhlIG9wdGlvbnMgaXMgYFNvbWVgLCBvdGhlcndpc2UgcmV0dXJucyBgTm9uZWAKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHJldHVybnMgYE5vbmVgIGlmIGJvdGggYXJlIGBTb21lYCBvciBib3RoIGFyZSBgTm9uZWAsIHRoZSBvbmx5IGBTb21lYCBvdGhlcndpc2UKICAgICAqLwogICAgeG9yKHZhbHVlKSB7CiAgICAgICAgaWYgKHZhbHVlLmlzU29tZSgpKQogICAgICAgICAgICByZXR1cm4gbmV3IE5vbmUoKTsKICAgICAgICBlbHNlCiAgICAgICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBaaXBzIGB0aGlzYCB3aXRoIGFub3RoZXIgYE9wdGlvbmAKICAgICAqIEBwYXJhbSBvdGhlcgogICAgICogQHJldHVybnMgYFNvbWUoW3RoaXMuaW5uZXIsIG90aGVyLmlubmVyXSlgIGlmIGJvdGggYXJlIGBTb21lYCwgYE5vbmVgIGlmIG9uZSBvZiB0aGVtIGlzIGBOb25lYAogICAgICovCiAgICB6aXAob3RoZXIpIHsKICAgICAgICBpZiAob3RoZXIuaXNTb21lKCkpCiAgICAgICAgICAgIHJldHVybiBuZXcgU29tZShbdGhpcy5pbm5lciwgb3RoZXIuaW5uZXJdKTsKICAgICAgICBlbHNlCiAgICAgICAgICAgIHJldHVybiBvdGhlcjsKICAgIH0KfQoKCi8vIyBzb3VyY2VNYXBwaW5nVVJMPXNvbWUubWpzLm1hcAoKOy8vIENPTkNBVEVOQVRFRCBNT0RVTEU6IC4vbm9kZV9tb2R1bGVzL0BoYXphZTQxL3Jlc3VsdC9kaXN0L2VzbS9tb2RzL3Jlc3VsdC9lcnIubWpzCgoKCgpjbGFzcyBFcnIgewogICAgI2lubmVyOwogICAgI3RpbWVvdXQ7CiAgICAvKioKICAgICAqIEEgZmFpbHVyZQogICAgICogQHBhcmFtIGlubmVyCiAgICAgKi8KICAgIGNvbnN0cnVjdG9yKGlubmVyKSB7CiAgICAgICAgdGhpcy4jaW5uZXIgPSBpbm5lcjsKICAgICAgICBpZiAoIVJlc3VsdC5kZWJ1ZykKICAgICAgICAgICAgcmV0dXJuOwogICAgICAgIGNvbnN0IGVycm9yID0gUGFuaWMuZnJvbShuZXcgRXJyb3IoYEFuIEVyciBoYXMgbm90IGJlZW4gaGFuZGxlZCBwcm9wZXJseWAsIHsgY2F1c2U6IHRoaXMgfSkpOwogICAgICAgIHRoaXMuI3RpbWVvdXQgPSBzZXRUaW1lb3V0KCgpID0+IHsgdGhyb3cgZXJyb3I7IH0sIDEwMDApOwogICAgfQogICAgLyoqCiAgICAgKiBDcmVhdGUgYW4gZW1wdHkgYEVycmAKICAgICAqIEByZXR1cm5zIGBFcnIodm9pZClgCiAgICAgKi8KICAgIHN0YXRpYyB2b2lkKCkgewogICAgICAgIHJldHVybiBuZXcgRXJyKHVuZGVmaW5lZCk7CiAgICB9CiAgICAvKioKICAgICAqIENyZWF0ZSBhbiBgRXJyYAogICAgICogQHBhcmFtIGlubmVyCiAgICAgKiBAcmV0dXJucyBgRXJyKGlubmVyKWAKICAgICAqLwogICAgc3RhdGljIG5ldyhpbm5lcikgewogICAgICAgIHJldHVybiBuZXcgRXJyKGlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogQ3JlYXRlIGFuIGBFcnJgIHdpdGggYW4gYEVycm9yYCBpbnNpZGUKICAgICAqIEBwYXJhbSBtZXNzYWdlCiAgICAgKiBAcGFyYW0gb3B0aW9ucwogICAgICogQHJldHVybnMgYEVycjxFcnJvcj5gCiAgICAgKi8KICAgIHN0YXRpYyBlcnJvcihtZXNzYWdlLCBvcHRpb25zKSB7CiAgICAgICAgcmV0dXJuIG5ldyBFcnIobmV3IEVycm9yKG1lc3NhZ2UsIG9wdGlvbnMpKTsKICAgIH0KICAgIGdldCBpbm5lcigpIHsKICAgICAgICByZXR1cm4gdGhpcy4jaW5uZXI7CiAgICB9CiAgICAvKioKICAgICAqIFNldCB0aGlzIHJlc3VsdCBhcyBoYW5kbGVkCiAgICAgKi8KICAgIGlnbm9yZSgpIHsKICAgICAgICBpZiAoIXRoaXMuI3RpbWVvdXQpCiAgICAgICAgICAgIHJldHVybiB0aGlzOwogICAgICAgIGNsZWFyVGltZW91dCh0aGlzLiN0aW1lb3V0KTsKICAgICAgICB0aGlzLiN0aW1lb3V0ID0gdW5kZWZpbmVkOwogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBUeXBlIGd1YXJkIGZvciBgT2tgCiAgICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYE9rYCwgYGZhbHNlYCBpZiBgRXJyYAogICAgICovCiAgICBpc09rKCkgewogICAgICAgIHJldHVybiBmYWxzZTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyB0cnVlIGlmIHRoZSByZXN1bHQgaXMgYE9rYCBhbmQgdGhlIHZhbHVlIGluc2lkZSBvZiBpdCBtYXRjaGVzIGEgcHJlZGljYXRlCiAgICAgKiBAcGFyYW0gb2tQcmVkaWNhdGUKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgT2tgIGFuZCBgYXdhaXQgb2tQcmVkaWNhdGUodGhpcy5pbm5lcilgLCBgZmFsc2VgIG90aGVyd2lzZQogICAgICovCiAgICBhc3luYyBpc09rQW5kKG9rUHJlZGljYXRlKSB7CiAgICAgICAgcmV0dXJuIGZhbHNlOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIHRydWUgaWYgdGhlIHJlc3VsdCBpcyBgT2tgIGFuZCB0aGUgdmFsdWUgaW5zaWRlIG9mIGl0IG1hdGNoZXMgYSBwcmVkaWNhdGUKICAgICAqIEBwYXJhbSBva1ByZWRpY2F0ZQogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBPa2AgYW5kIGBhd2FpdCBva1ByZWRpY2F0ZSh0aGlzLmlubmVyKWAsIGBmYWxzZWAgb3RoZXJ3aXNlCiAgICAgKi8KICAgIGlzT2tBbmRTeW5jKG9rUHJlZGljYXRlKSB7CiAgICAgICAgcmV0dXJuIGZhbHNlOwogICAgfQogICAgLyoqCiAgICAgKiBUeXBlIGd1YXJkIGZvciBgRXJyYAogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBFcnJgLCBgZmFsc2VgIGlmIGBPa2AKICAgICAqLwogICAgaXNFcnIoKSB7CiAgICAgICAgcmV0dXJuIHRydWU7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgdHJ1ZSBpZiB0aGUgcmVzdWx0IGlzIGBFcnJgIGFuZCB0aGUgdmFsdWUgaW5zaWRlIG9mIGl0IG1hdGNoZXMgYSBwcmVkaWNhdGUKICAgICAqIEBwYXJhbSBlcnJQcmVkaWNhdGUKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgRXJyYCBhbmQgYGF3YWl0IGVyclByZWRpY2F0ZSh0aGlzLmlubmVyKWAsIGBmYWxzZWAgb3RoZXJ3aXNlCiAgICAgKi8KICAgIGFzeW5jIGlzRXJyQW5kKGVyclByZWRpY2F0ZSkgewogICAgICAgIHJldHVybiBhd2FpdCBlcnJQcmVkaWNhdGUodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgdHJ1ZSBpZiB0aGUgcmVzdWx0IGlzIGBFcnJgIGFuZCB0aGUgdmFsdWUgaW5zaWRlIG9mIGl0IG1hdGNoZXMgYSBwcmVkaWNhdGUKICAgICAqIEBwYXJhbSBlcnJQcmVkaWNhdGUKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgRXJyYCBhbmQgYGF3YWl0IGVyclByZWRpY2F0ZSh0aGlzLmlubmVyKWAsIGBmYWxzZWAgb3RoZXJ3aXNlCiAgICAgKi8KICAgIGlzRXJyQW5kU3luYyhlcnJQcmVkaWNhdGUpIHsKICAgICAgICByZXR1cm4gZXJyUHJlZGljYXRlKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBDb21waWxlLXRpbWUgc2FmZWx5IGdldCBgdGhpcy5pbm5lcmAKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYAogICAgICovCiAgICBnZXQoKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gdGhpcy5pbm5lcjsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtIGBSZXN1bHQ8VCwgRT5gIGludG8gYE9wdGlvbjxUPmAKICAgICAqIEByZXR1cm5zIGBTb21lKHRoaXMuaW5uZXIpYCBpZiBgT2tgLCBgTm9uZWAgaWYgYEVycmAKICAgICAqLwogICAgb2soKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gbmV3IE5vbmUoKTsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtIGBSZXN1bHQ8VCwgRT5gIGludG8gYE9wdGlvbjxFPmAKICAgICAqIEByZXR1cm5zIGBTb21lKHRoaXMuaW5uZXIpYCBpZiBgRXJyYCwgYE5vbmVgIGlmIGBPa2AKICAgICAqLwogICAgZXJyKCkgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIG5ldyBTb21lKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGFuIGl0ZXJhdG9yIG92ZXIgdGhlIHBvc3NpYmx5IGNvbnRhaW5lZCB2YWx1ZQogICAgICogQHlpZWxkcyBgdGhpcy5pbm5lcmAgaWYgYE9rYAogICAgICovCiAgICAqW1N5bWJvbC5pdGVyYXRvcl0oKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm47CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBgUmVzdWx0PFQsRT5gIGludG8gYFtULEVdYAogICAgICogQHJldHVybnMgYFt0aGlzLmlubmVyLCB1bmRlZmluZWRdYCBpZiBgT2tgLCBgW3VuZGVmaW5lZCwgdGhpcy5pbm5lcl1gIGlmIGBFcnJgCiAgICAgKi8KICAgIHNwbGl0KCkgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIFt1bmRlZmluZWQsIHRoaXMuaW5uZXJdOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIHRydWUgaWYgdGhlIHJlc3VsdCBpcyBhbiBgT2tgIHZhbHVlIGNvbnRhaW5pbmcgdGhlIGdpdmVuIHZhbHVlCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgT2tgIGFuZCBgdGhpcy5pbm5lciA9PT0gdmFsdWVgLCBgZmFsc2VgIG90aGVyd2lzZQogICAgICovCiAgICBjb250YWlucyh2YWx1ZSkgewogICAgICAgIHJldHVybiBmYWxzZTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyB0cnVlIGlmIHRoZSByZXN1bHQgaXMgYW4gYEVycmAgdmFsdWUgY29udGFpbmluZyB0aGUgZ2l2ZW4gdmFsdWUKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBFcnJgIGFuZCBgdGhpcy5pbm5lciA9PT0gdmFsdWVgLCBgZmFsc2VgIG90aGVyd2lzZQogICAgICovCiAgICBjb250YWluc0Vycih2YWx1ZSkgewogICAgICAgIHJldHVybiB0aGlzLmlubmVyID09PSB2YWx1ZTsKICAgIH0KICAgIC8qKgogICAgICogR2V0IHRoZSBpbm5lciB2YWx1ZSBvciB0aHJvdyB0byB0aGUgY2xvc2VzdCBgUmVzdWx0LnVudGhyb3dgCiAgICAgKiBAcGFyYW0gdGhyb3dlciBUaGUgdGhyb3dlciBmcm9tIGBSZXN1bHQudW50aHJvd2AKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgT2tgCiAgICAgKiBAdGhyb3dzIGB1bmRlZmluZWRgIGlmIGBFcnJgCiAgICAgKiBAc2VlIFJlc3VsdC51bnRocm93CiAgICAgKiBAc2VlIFJlc3VsdC51bnRocm93U3luYwogICAgICovCiAgICB0aHJvdyh0aHJvd2VyKSB7CiAgICAgICAgdGhyb3dlcih0aGlzKTsKICAgICAgICB0aHJvdyBQYW5pYy5mcm9tKG5ldyBFcnJvcihgQW4gRXJyIGhhcyBiZWVuIHRocm93biBidXQgbm90IGNhdGNoZWRgLCB7IGNhdXNlOiB0aGlzIH0pKTsKICAgIH0KICAgIC8qKgogICAgICogR2V0IHRoZSBpbm5lciB2YWx1ZSBvciB0aHJvdyB0aGUgaW5uZXIgZXJyb3Igd3JhcHBlZCBpbnNpZGUgYW5vdGhlciBFcnJvcgogICAgICogQHBhcmFtIG1lc3NhZ2UKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgT2tgLCBgRXJyb3IobWVzc2FnZSwgeyBjYXVzZTogdGhpcy5pbm5lciB9KWAgaWYgYEVycmAKICAgICAqLwogICAgZXhwZWN0KG1lc3NhZ2UpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHRocm93IFBhbmljLmZyb20obmV3IEVycm9yKG1lc3NhZ2UsIHsgY2F1c2U6IHRoaXMgfSkpOwogICAgfQogICAgLyoqCiAgICAgKiBHZXQgdGhlIGlubmVyIGVycm9yIG9yIHRocm93IHRoZSBpbm5lciB2YWx1ZSB3cmFwcGVkIGluc2lkZSBhbm90aGVyIEVycm9yCiAgICAgKiBAcGFyYW0gbWVzc2FnZQogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBFcnJgLCBgRXJyb3IobWVzc2FnZSwgeyBjYXVzZTogdGhpcy5pbm5lciB9KWAgaWYgYE9rYAogICAgICovCiAgICBleHBlY3RFcnIobWVzc2FnZSkgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIHRoaXMuaW5uZXI7CiAgICB9CiAgICAvKioKICAgICAqIEdldCB0aGUgaW5uZXIgdmFsdWUgb3IgcGFuaWMKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgT2tgCiAgICAgKiBAdGhyb3dzIGB0aGlzLmlubmVyYCBpZiBgRXJyYAogICAgICovCiAgICB1bndyYXAoKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICB0aHJvdyBuZXcgUGFuaWMobmV3IEVycm9yKGBBbiBFcnIgaGFzIGJlZW4gdW53cmFwcGVkYCwgeyBjYXVzZTogdGhpcyB9KSk7CiAgICB9CiAgICAvKioKICAgICAqIEdldCB0aGUgaW5uZXIgZXJyb3Igb3IgcGFuaWMKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgRXJyYAogICAgICogQHRocm93cyBgdGhpcy5pbm5lcmAgaWYgYE9rYAogICAgICovCiAgICB1bndyYXBFcnIoKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gdGhpcy5pbm5lcjsKICAgIH0KICAgIC8qKgogICAgICogR2V0IHRoZSBpbm5lciB2YWx1ZSBvciBhIGRlZmF1bHQgb25lCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgT2tgLCBgdmFsdWVgIGlmIGBFcnJgCiAgICAgKi8KICAgIHVud3JhcE9yKHZhbHVlKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gdmFsdWU7CiAgICB9CiAgICAvKioKICAgICAqIEdldCB0aGUgaW5uZXIgdmFsdWUgb3IgY29tcHV0ZSBhIGRlZmF1bHQgb25lIGZyb20gdGhlIGlubmVyIGVycm9yCiAgICAgKiBAcGFyYW0gZXJyTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAgaWYgYE9rYCwgYGF3YWl0IGVyck1hcHBlcih0aGlzLmlubmVyKWAgaWYgYEVycmAKICAgICAqIEB0aHJvd3MgaWYgYGF3YWl0IGVyck1hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIGFzeW5jIHVud3JhcE9yRWxzZShlcnJNYXBwZXIpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiBhd2FpdCBlcnJNYXBwZXIodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIEdldCB0aGUgaW5uZXIgdmFsdWUgb3IgY29tcHV0ZSBhIGRlZmF1bHQgb25lIGZyb20gdGhlIGlubmVyIGVycm9yCiAgICAgKiBAcGFyYW0gZXJyTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAgaWYgYE9rYCwgYGVyck1hcHBlcih0aGlzLmlubmVyKWAgaWYgYEVycmAKICAgICAqIEB0aHJvd3MgaWYgYGVyck1hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIHVud3JhcE9yRWxzZVN5bmMoZXJyTWFwcGVyKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gZXJyTWFwcGVyKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm0gUmVzdWx0PFByb21pc2U8VD4sIEU+IGludG8gUHJvbWlzZTxSZXN1bHQ8VCwgRT4+CiAgICAgKiBAcmV0dXJucyBgYXdhaXQgdGhpcy5pbm5lcmAgaWYgYE9rYCwgYHRoaXNgIGlmIGBFcnJgCiAgICAgKi8KICAgIGFzeW5jIGF3YWl0KCkgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm0gUmVzdWx0PFQsIFByb21pc2U8RT4+IGludG8gUHJvbWlzZTxSZXN1bHQ8VCwgRT4+CiAgICAgKiBAcmV0dXJucyBgYXdhaXQgdGhpcy5pbm5lcmAgaWYgYEVycmAsIGB0aGlzYCBpZiBgT2tgCiAgICAgKi8KICAgIGFzeW5jIGF3YWl0RXJyKCkgewogICAgICAgIHJldHVybiBuZXcgRXJyKGF3YWl0IHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm0gUmVzdWx0PFByb21pc2U8VD4sIFByb21pc2U8RT4+IGludG8gUHJvbWlzZTxSZXN1bHQ8VCwgRT4+CiAgICAgKiBAcmV0dXJucyBgYXdhaXQgdGhpcy5pbm5lcmAKICAgICAqLwogICAgYXN5bmMgYXdhaXRBbGwoKSB7CiAgICAgICAgcmV0dXJuIGF3YWl0IHRoaXMuYXdhaXRFcnIoKTsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtIGBSZXN1bHQ8VCwgRT5gIGludG8gYFJlc3VsdDx2b2lkLCBFPmAKICAgICAqIEByZXR1cm5zIGBPazx2b2lkPmAgaWYgYE9rPFQ+YCwgYEVycjxFPmAgaWYgYEU8RT5gCiAgICAgKi8KICAgIGNsZWFyKCkgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm0gYFJlc3VsdDxULCBFPmAgaW50byBgUmVzdWx0PFQsIHZvaWQ+YAogICAgICogQHJldHVybnMgYE9rPFQ+YCBpZiBgT2s8VD5gLCBgRXJyPHZvaWQ+YCBpZiBgRTxFPmAKICAgICAqLwogICAgY2xlYXJFcnIoKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gRXJyLnZvaWQoKTsKICAgIH0KICAgIC8qKgogICAgICogQ2FsbHMgdGhlIGdpdmVuIGNhbGxiYWNrIHdpdGggdGhlIGlubmVyIHZhbHVlIGlmIGBPa2AKICAgICAqIEBwYXJhbSBva0NhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgdGhpc2AKICAgICAqLwogICAgYXN5bmMgaW5zcGVjdChva0NhbGxiYWNrKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIENhbGxzIHRoZSBnaXZlbiBjYWxsYmFjayB3aXRoIHRoZSBpbm5lciB2YWx1ZSBpZiBgT2tgCiAgICAgKiBAcGFyYW0gb2tDYWxsYmFjawogICAgICogQHJldHVybnMgYHRoaXNgCiAgICAgKi8KICAgIGluc3BlY3RTeW5jKG9rQ2FsbGJhY2spIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogQ2FsbHMgdGhlIGdpdmVuIGNhbGxiYWNrIHdpdGggdGhlIGlubmVyIHZhbHVlIGlmIGBFcnJgCiAgICAgKiBAcGFyYW0gZXJyQ2FsbGJhY2sKICAgICAqIEByZXR1cm5zIGB0aGlzYAogICAgICovCiAgICBhc3luYyBpbnNwZWN0RXJyKGVyckNhbGxiYWNrKSB7CiAgICAgICAgYXdhaXQgZXJyQ2FsbGJhY2sodGhpcy5pbm5lcik7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIENhbGxzIHRoZSBnaXZlbiBjYWxsYmFjayB3aXRoIHRoZSBpbm5lciB2YWx1ZSBpZiBgRXJyYAogICAgICogQHBhcmFtIGVyckNhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgdGhpc2AKICAgICAqLwogICAgaW5zcGVjdEVyclN5bmMoZXJyQ2FsbGJhY2spIHsKICAgICAgICBlcnJDYWxsYmFjayh0aGlzLmlubmVyKTsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJuIGEgbmV3IGBPa2AgYnV0IHdpdGggdGhlIGdpdmVuIGBpbm5lcmAKICAgICAqIEBwYXJhbSBpbm5lcgogICAgICogQHJldHVybnMgYE9rKGlubmVyKWAgaWYgYE9rYCwgYHRoaXNgIGlmIGBFcnJgCiAgICAgKi8KICAgIHNldChpbm5lcikgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm4gYSBuZXcgYEVycmAgYnV0IHdpdGggdGhlIGdpdmVuIGBpbm5lcmAKICAgICAqIEBwYXJhbSBpbm5lcgogICAgICogQHJldHVybnMgYEVycihpbm5lcilgIGlmIGBFcnJgLCBgdGhpc2AgaWYgYE9rYAogICAgICovCiAgICBzZXRFcnIoaW5uZXIpIHsKICAgICAgICByZXR1cm4gbmV3IEVycihpbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIE1hcCB0aGUgaW5uZXIgdmFsdWUgaW50byBhbm90aGVyCiAgICAgKiBAcGFyYW0gb2tNYXBwZXIKICAgICAqIEByZXR1cm5zIGBPayhhd2FpdCBva01hcHBlcih0aGlzLmlubmVyKSlgIGlmIGBPa2AsIGB0aGlzYCBpZiBgRXJyYAogICAgICogQHRocm93cyBpZiBgYXdhaXQgb2tNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICBhc3luYyBtYXAob2tNYXBwZXIpIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogTWFwIHRoZSBpbm5lciB2YWx1ZSBpbnRvIGFub3RoZXIKICAgICAqIEBwYXJhbSBva01hcHBlcgogICAgICogQHJldHVybnMgYE9rKG9rTWFwcGVyKHRoaXMuaW5uZXIpKWAgaWYgYE9rYCwgYHRoaXNgIGlmIGBFcnJgCiAgICAgKiBAdGhyb3dzIGlmIGBva01hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIG1hcFN5bmMob2tNYXBwZXIpIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogTWFwIHRoZSBpbm5lciBlcnJvciBpbnRvIGFub3RoZXIKICAgICAqIEBwYXJhbSBlcnJNYXBwZXIKICAgICAqIEByZXR1cm5zIGBFcnIoYXdhaXQgZXJyTWFwcGVyKHRoaXMuaW5uZXIpKWAgaWYgYEVycmAsIGB0aGlzYCBpZiBgT2tgCiAgICAgKiBAdGhyb3dzIGlmIGBhd2FpdCBlcnJNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICBhc3luYyBtYXBFcnIoZXJyTWFwcGVyKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gbmV3IEVycihhd2FpdCBlcnJNYXBwZXIodGhpcy5pbm5lcikpOwogICAgfQogICAgLyoqCiAgICAgKiBNYXAgdGhlIGlubmVyIGVycm9yIGludG8gYW5vdGhlcgogICAgICogQHBhcmFtIGVyck1hcHBlcgogICAgICogQHJldHVybnMgYEVycihlcnJNYXBwZXIodGhpcy5pbm5lcikpYCBpZiBgRXJyYCwgYHRoaXNgIGlmIGBPa2AKICAgICAqIEB0aHJvd3MgaWYgYGVyck1hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIG1hcEVyclN5bmMoZXJyTWFwcGVyKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gbmV3IEVycihlcnJNYXBwZXIodGhpcy5pbm5lcikpOwogICAgfQogICAgLyoqCiAgICAgKiBNYXAgdGhlIGlubmVyIHZhbHVlIGludG8gYW5vdGhlciwgb3IgYSBkZWZhdWx0IG9uZQogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcGFyYW0gb2tNYXBwZXIKICAgICAqIEByZXR1cm5zIGBhd2FpdCBva01hcHBlcih0aGlzLmlubmVyKWAgaWYgYE9rYCwgYHZhbHVlYCBpZiBgRXJyYAogICAgICogQHRocm93cyBpZiBgYXdhaXQgb2tNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICBhc3luYyBtYXBPcih2YWx1ZSwgb2tNYXBwZXIpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiB2YWx1ZTsKICAgIH0KICAgIC8qKgogICAgICogTWFwIHRoZSBpbm5lciB2YWx1ZSBpbnRvIGFub3RoZXIsIG9yIGEgZGVmYXVsdCBvbmUKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHBhcmFtIG9rTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgb2tNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBPa2AsIGB2YWx1ZWAgaWYgYEVycmAKICAgICAqIEB0aHJvd3MgaWYgYG9rTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgbWFwT3JTeW5jKHZhbHVlLCBva01hcHBlcikgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIHZhbHVlOwogICAgfQogICAgLyoqCiAgICAgKiBNYXAgdGhlIGlubmVyIHZhbHVlIGludG8gYW5vdGhlciwgb3IgYSBkZWZhdWx0IG9uZQogICAgICogQHBhcmFtIGVyck1hcHBlcgogICAgICogQHBhcmFtIG9rTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgYXdhaXQgb2tNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBPa2AsIGBhd2FpdCBlcnJNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBFcnJgCiAgICAgKiBAdGhyb3dzIGlmIGBhd2FpdCBva01hcHBlcih0aGlzLmlubmVyKWAgb3IgYGF3YWl0IGVyck1hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIGFzeW5jIG1hcE9yRWxzZShlcnJNYXBwZXIsIG9rTWFwcGVyKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gYXdhaXQgZXJyTWFwcGVyKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBNYXAgdGhlIGlubmVyIHZhbHVlIGludG8gYW5vdGhlciwgb3IgYSBkZWZhdWx0IG9uZQogICAgICogQHBhcmFtIGVyck1hcHBlcgogICAgICogQHBhcmFtIG9rTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgb2tNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBPa2AsIGBlcnJNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBFcnJgCiAgICAgKiBAdGhyb3dzIGlmIGBva01hcHBlcih0aGlzLmlubmVyKWAgb3IgYGVyck1hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIG1hcE9yRWxzZVN5bmMoZXJyTWFwcGVyLCBva01hcHBlcikgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIGVyck1hcHBlcih0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJuIGB2YWx1ZWAgaWYgYE9rYCwgcmV0dXJuIGB0aGlzYCBpZiBgRXJyYAogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcmV0dXJucyBgdmFsdWVgIGlmIGBPa2AsIGB0aGlzYCBpZiBgRXJyYAogICAgICovCiAgICBhbmQodmFsdWUpIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJuIGBhd2FpdCBva01hcHBlcih0aGlzLmlubmVyKWAgaWYgYE9rYCwgcmV0dXJuIGB0aGlzYCBpZiBgRXJyYAogICAgICogQHBhcmFtIG9rTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgYXdhaXQgb2tNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBPa2AsIGB0aGlzYCBpZiBgRXJyYAogICAgICogQHRocm93cyBpZiBgYXdhaXQgb2tNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICBhc3luYyBhbmRUaGVuKG9rTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybiBgb2tNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBPa2AsIHJldHVybiBgdGhpc2AgaWYgYEVycmAKICAgICAqIEBwYXJhbSBva01hcHBlcgogICAgICogQHJldHVybnMgYG9rTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgT2tgLCBgdGhpc2AgaWYgYEVycmAKICAgICAqIEB0aHJvd3MgaWYgYG9rTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgYW5kVGhlblN5bmMob2tNYXBwZXIpIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJuIGB2YWx1ZWAgaWYgYEVycmAsIHJldHVybiBgdGhpc2AgaWYgYE9rYAogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcmV0dXJucyBgdmFsdWVgIGlmIGBFcnJgLCBgdGhpc2AgaWYgYE9rYAogICAgICovCiAgICBvcih2YWx1ZSkgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIHZhbHVlOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm4gYGF3YWl0IGVyck1hcHBlcih0aGlzLmlubmVyKWAgaWYgYEVycmAsIHJldHVybiBgdGhpc2AgaWYgYE9rYAogICAgICogQHBhcmFtIGVyck1hcHBlcgogICAgICogQHJldHVybnMgYGF3YWl0IGVyck1hcHBlcih0aGlzLmlubmVyKWAgaWYgYEVycmAsIGB0aGlzYCBpZiBgT2tgCiAgICAgKiBAdGhyb3dzIGlmIGBhd2FpdCBlcnJNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICBhc3luYyBvckVsc2UoZXJyTWFwcGVyKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gYXdhaXQgZXJyTWFwcGVyKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm4gYGVyck1hcHBlcih0aGlzLmlubmVyKWAgaWYgYEVycmAsIHJldHVybiBgdGhpc2AgaWYgYE9rYAogICAgICogQHBhcmFtIGVyck1hcHBlcgogICAgICogQHJldHVybnMgYGVyck1hcHBlcih0aGlzLmlubmVyKWAgaWYgYEVycmAsIGB0aGlzYCBpZiBgT2tgCiAgICAgKiBAdGhyb3dzIGlmIGBlcnJNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICBvckVsc2VTeW5jKGVyck1hcHBlcikgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIGVyck1hcHBlcih0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtIFJlc3VsdDxSZXN1bHQ8VCwgRTE+LCBFMj4gaW50byBSZXN1bHQ8VCwgRTEgfCBFMj4KICAgICAqIEBwYXJhbSByZXN1bHQKICAgICAqIEByZXR1cm5zIGB0aGlzYCBpZiBgRXJyYCwgYHRoaXMuaW5uZXJgIGlmIGBPa2AKICAgICAqLwogICAgZmxhdHRlbigpIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KfQoKCi8vIyBzb3VyY2VNYXBwaW5nVVJMPWVyci5tanMubWFwCgo7Ly8gQ09OQ0FURU5BVEVEIE1PRFVMRTogLi9ub2RlX21vZHVsZXMvQGhhemFlNDEvanNvbnJwYy9kaXN0L2VzbS9tb2RzL3JwYy9lcnIubWpzCgoKY2xhc3MgUnBjRXJyb3IgZXh0ZW5kcyBFcnJvciB7CiAgICBjb2RlOwogICAgbWVzc2FnZTsKICAgIGRhdGE7CiAgICAjY2xhc3MgPSBScGNFcnJvcjsKICAgIG5hbWUgPSB0aGlzLiNjbGFzcy5uYW1lOwogICAgc3RhdGljIGNvZGVzID0gewogICAgICAgIFBhcnNlRXJyb3I6IC0zMjcwMCwKICAgICAgICBJbnZhbGlkUmVxdWVzdDogLTMyNjAwLAogICAgICAgIE1ldGhvZE5vdEZvdW5kOiAtMzI2MDEsCiAgICAgICAgSW52YWxpZFBhcmFtczogLTMyNjAyLAogICAgICAgIEludGVybmFsRXJyb3I6IC0zMjYwMwogICAgfTsKICAgIHN0YXRpYyBtZXNzYWdlcyA9IHsKICAgICAgICBQYXJzZUVycm9yOiAiUGFyc2UgZXJyb3IiLAogICAgICAgIEludmFsaWRSZXF1ZXN0OiAiSW52YWxpZCBSZXF1ZXN0IiwKICAgICAgICBNZXRob2ROb3RGb3VuZDogIk1ldGhvZCBub3QgZm91bmQiLAogICAgICAgIEludmFsaWRQYXJhbXM6ICJJbnZhbGlkIHBhcmFtcyIsCiAgICAgICAgSW50ZXJuYWxFcnJvcjogIkludGVybmFsIGVycm9yIiwKICAgICAgICBTZXJ2ZXJFcnJvcjogIlNlcnZlciBlcnJvciIKICAgIH07CiAgICBjb25zdHJ1Y3Rvcihjb2RlLCBtZXNzYWdlLCBkYXRhID0gdW5kZWZpbmVkKSB7CiAgICAgICAgc3VwZXIobWVzc2FnZSk7CiAgICAgICAgdGhpcy5jb2RlID0gY29kZTsKICAgICAgICB0aGlzLm1lc3NhZ2UgPSBtZXNzYWdlOwogICAgICAgIHRoaXMuZGF0YSA9IGRhdGE7CiAgICB9CiAgICBzdGF0aWMgZnJvbShpbml0KSB7CiAgICAgICAgY29uc3QgeyBjb2RlLCBtZXNzYWdlLCBkYXRhIH0gPSBpbml0OwogICAgICAgIHJldHVybiBuZXcgUnBjRXJyb3IoY29kZSwgbWVzc2FnZSwgZGF0YSk7CiAgICB9CiAgICBzdGF0aWMgcmV3cmFwKGVycm9yKSB7CiAgICAgICAgaWYgKGVycm9yIGluc3RhbmNlb2YgUnBjRXJyb3IpCiAgICAgICAgICAgIHJldHVybiBlcnJvcjsKICAgICAgICBpZiAoZXJyb3IgaW5zdGFuY2VvZiBFcnJvcikKICAgICAgICAgICAgcmV0dXJuIG5ldyBScGNFcnJvcigtMzI2MDMsIGVycm9yLm1lc3NhZ2UpOwogICAgICAgIHJldHVybiBuZXcgUnBjRXJyb3IoLTMyNjAzLCAiQW4gdW5rbm93biBlcnJvciBvY2N1cmVkIik7CiAgICB9CiAgICAvKioKICAgICAqIFVzZWQgYnkgSlNPTi5zdHJpbmdpZnkKICAgICAqLwogICAgdG9KU09OKCkgewogICAgICAgIGNvbnN0IHsgY29kZSwgbWVzc2FnZSwgZGF0YSB9ID0gdGhpczsKICAgICAgICByZXR1cm4geyBjb2RlLCBtZXNzYWdlLCBkYXRhIH07CiAgICB9Cn0KY2xhc3MgUnBjUGFyc2VFcnJvciBleHRlbmRzIFJwY0Vycm9yIHsKICAgICNjbGFzcyA9IFJwY1BhcnNlRXJyb3I7CiAgICBuYW1lID0gdGhpcy4jY2xhc3MubmFtZTsKICAgIHN0YXRpYyBjb2RlID0gUnBjRXJyb3IuY29kZXMuUGFyc2VFcnJvcjsKICAgIHN0YXRpYyBtZXNzYWdlID0gUnBjRXJyb3IubWVzc2FnZXMuUGFyc2VFcnJvcjsKICAgIGNvbnN0cnVjdG9yKCkgewogICAgICAgIHN1cGVyKFJwY0Vycm9yLmNvZGVzLlBhcnNlRXJyb3IsIFJwY0Vycm9yLm1lc3NhZ2VzLlBhcnNlRXJyb3IpOwogICAgfQp9CmNsYXNzIFJwY0ludmFsaWRSZXF1ZXN0RXJyb3IgZXh0ZW5kcyBScGNFcnJvciB7CiAgICAjY2xhc3MgPSBScGNJbnZhbGlkUmVxdWVzdEVycm9yOwogICAgbmFtZSA9IHRoaXMuI2NsYXNzLm5hbWU7CiAgICBzdGF0aWMgY29kZSA9IFJwY0Vycm9yLmNvZGVzLkludmFsaWRSZXF1ZXN0OwogICAgc3RhdGljIG1lc3NhZ2UgPSBScGNFcnJvci5tZXNzYWdlcy5JbnZhbGlkUmVxdWVzdDsKICAgIGNvbnN0cnVjdG9yKCkgewogICAgICAgIHN1cGVyKFJwY0Vycm9yLmNvZGVzLkludmFsaWRSZXF1ZXN0LCBScGNFcnJvci5tZXNzYWdlcy5JbnZhbGlkUmVxdWVzdCk7CiAgICB9Cn0KY2xhc3MgUnBjTWV0aG9kTm90Rm91bmRFcnJvciBleHRlbmRzIFJwY0Vycm9yIHsKICAgICNjbGFzcyA9IFJwY01ldGhvZE5vdEZvdW5kRXJyb3I7CiAgICBuYW1lID0gdGhpcy4jY2xhc3MubmFtZTsKICAgIHN0YXRpYyBjb2RlID0gUnBjRXJyb3IuY29kZXMuTWV0aG9kTm90Rm91bmQ7CiAgICBzdGF0aWMgbWVzc2FnZSA9IFJwY0Vycm9yLm1lc3NhZ2VzLk1ldGhvZE5vdEZvdW5kOwogICAgY29uc3RydWN0b3IoKSB7CiAgICAgICAgc3VwZXIoUnBjRXJyb3IuY29kZXMuTWV0aG9kTm90Rm91bmQsIFJwY0Vycm9yLm1lc3NhZ2VzLk1ldGhvZE5vdEZvdW5kKTsKICAgIH0KfQpjbGFzcyBScGNJbnZhbGlkUGFyYW1zRXJyb3IgZXh0ZW5kcyBScGNFcnJvciB7CiAgICAjY2xhc3MgPSBScGNJbnZhbGlkUGFyYW1zRXJyb3I7CiAgICBuYW1lID0gdGhpcy4jY2xhc3MubmFtZTsKICAgIHN0YXRpYyBjb2RlID0gUnBjRXJyb3IuY29kZXMuSW52YWxpZFBhcmFtczsKICAgIHN0YXRpYyBtZXNzYWdlID0gUnBjRXJyb3IubWVzc2FnZXMuSW52YWxpZFBhcmFtczsKICAgIGNvbnN0cnVjdG9yKCkgewogICAgICAgIHN1cGVyKFJwY0Vycm9yLmNvZGVzLkludmFsaWRQYXJhbXMsIFJwY0Vycm9yLm1lc3NhZ2VzLkludmFsaWRQYXJhbXMpOwogICAgfQp9CmNsYXNzIFJwY0ludGVybmFsRXJyb3IgZXh0ZW5kcyBScGNFcnJvciB7CiAgICAjY2xhc3MgPSBScGNJbnRlcm5hbEVycm9yOwogICAgbmFtZSA9IHRoaXMuI2NsYXNzLm5hbWU7CiAgICBzdGF0aWMgY29kZSA9IFJwY0Vycm9yLmNvZGVzLkludGVybmFsRXJyb3I7CiAgICBzdGF0aWMgbWVzc2FnZSA9IFJwY0Vycm9yLm1lc3NhZ2VzLkludGVybmFsRXJyb3I7CiAgICBjb25zdHJ1Y3RvcigpIHsKICAgICAgICBzdXBlcihScGNFcnJvci5jb2Rlcy5JbnRlcm5hbEVycm9yLCBScGNFcnJvci5tZXNzYWdlcy5JbnRlcm5hbEVycm9yKTsKICAgIH0KfQpjbGFzcyBScGNFcnIgZXh0ZW5kcyBFcnIgewogICAgaWQ7CiAgICBlcnJvcjsKICAgIGpzb25ycGMgPSAiMi4wIjsKICAgIGNvbnN0cnVjdG9yKGlkLCBlcnJvcikgewogICAgICAgIHN1cGVyKGVycm9yKTsKICAgICAgICB0aGlzLmlkID0gaWQ7CiAgICAgICAgdGhpcy5lcnJvciA9IGVycm9yOwogICAgfQogICAgc3RhdGljIGZyb20oaW5pdCkgewogICAgICAgIHJldHVybiBuZXcgUnBjRXJyKGluaXQuaWQsIFJwY0Vycm9yLmZyb20oaW5pdC5lcnJvcikpOwogICAgfQogICAgc3RhdGljIHJld3JhcChpZCwgcmVzdWx0KSB7CiAgICAgICAgcmV0dXJuIG5ldyBScGNFcnIoaWQsIFJwY0Vycm9yLnJld3JhcChyZXN1bHQuaW5uZXIpKTsKICAgIH0KfQoKCi8vIyBzb3VyY2VNYXBwaW5nVVJMPWVyci5tanMubWFwCgo7Ly8gQ09OQ0FURU5BVEVEIE1PRFVMRTogLi9ub2RlX21vZHVsZXMvQGhhemFlNDEvanNvbnJwYy9kaXN0L2VzbS9tb2RzL3JwYy9vay5tanMKCgp2YXIgUnBjT2tJbml0OwooZnVuY3Rpb24gKFJwY09rSW5pdCkgewogICAgZnVuY3Rpb24gZnJvbShyZXNwb25zZSkgewogICAgICAgIGNvbnN0IHsganNvbnJwYywgaWQsIHJlc3VsdCB9ID0gcmVzcG9uc2U7CiAgICAgICAgcmV0dXJuIHsganNvbnJwYywgaWQsIHJlc3VsdCB9OwogICAgfQogICAgUnBjT2tJbml0LmZyb20gPSBmcm9tOwp9KShScGNPa0luaXQgfHwgKFJwY09rSW5pdCA9IHt9KSk7CmNsYXNzIFJwY09rIGV4dGVuZHMgT2sgewogICAgaWQ7CiAgICByZXN1bHQ7CiAgICBqc29ucnBjID0gIjIuMCI7CiAgICBjb25zdHJ1Y3RvcihpZCwgcmVzdWx0KSB7CiAgICAgICAgc3VwZXIocmVzdWx0KTsKICAgICAgICB0aGlzLmlkID0gaWQ7CiAgICAgICAgdGhpcy5yZXN1bHQgPSByZXN1bHQ7CiAgICB9CiAgICBzdGF0aWMgZnJvbShpbml0KSB7CiAgICAgICAgcmV0dXJuIG5ldyBScGNPayhpbml0LmlkLCBpbml0LnJlc3VsdCk7CiAgICB9CiAgICBzdGF0aWMgcmV3cmFwKGlkLCByZXN1bHQpIHsKICAgICAgICByZXR1cm4gbmV3IFJwY09rKGlkLCByZXN1bHQuaW5uZXIpOwogICAgfQp9CgoKLy8jIHNvdXJjZU1hcHBpbmdVUkw9b2subWpzLm1hcAoKOy8vIENPTkNBVEVOQVRFRCBNT0RVTEU6IC4vbm9kZV9tb2R1bGVzL0BoYXphZTQxL2pzb25ycGMvZGlzdC9lc20vbW9kcy9ycGMvcmVzcG9uc2UubWpzCgoKCnZhciBScGNSZXNwb25zZTsKKGZ1bmN0aW9uIChScGNSZXNwb25zZSkgewogICAgZnVuY3Rpb24gZnJvbShpbml0KSB7CiAgICAgICAgaWYgKCJlcnJvciIgaW4gaW5pdCkKICAgICAgICAgICAgcmV0dXJuIFJwY0Vyci5mcm9tKGluaXQpOwogICAgICAgIHJldHVybiBScGNPay5mcm9tKGluaXQpOwogICAgfQogICAgUnBjUmVzcG9uc2UuZnJvbSA9IGZyb207CiAgICBmdW5jdGlvbiByZXdyYXAoaWQsIHJlc3VsdCkgewogICAgICAgIGlmIChyZXN1bHQuaXNFcnIoKSkKICAgICAgICAgICAgcmV0dXJuIFJwY0Vyci5yZXdyYXAoaWQsIHJlc3VsdCk7CiAgICAgICAgcmV0dXJuIFJwY09rLnJld3JhcChpZCwgcmVzdWx0KTsKICAgIH0KICAgIFJwY1Jlc3BvbnNlLnJld3JhcCA9IHJld3JhcDsKfSkoUnBjUmVzcG9uc2UgfHwgKFJwY1Jlc3BvbnNlID0ge30pKTsKCgovLyMgc291cmNlTWFwcGluZ1VSTD1yZXNwb25zZS5tanMubWFwCgo7Ly8gQ09OQ0FURU5BVEVEIE1PRFVMRTogLi9ub2RlX21vZHVsZXMvQGhhemFlNDEvanNvbnJwYy9kaXN0L2VzbS9tb2RzL3JwYy9yZXF1ZXN0Lm1qcwpjbGFzcyBScGNSZXF1ZXN0IHsKICAgIGlkOwogICAgbWV0aG9kOwogICAgcGFyYW1zOwogICAganNvbnJwYyA9ICIyLjAiOwogICAgY29uc3RydWN0b3IoaWQsIG1ldGhvZCwgcGFyYW1zKSB7CiAgICAgICAgdGhpcy5pZCA9IGlkOwogICAgICAgIHRoaXMubWV0aG9kID0gbWV0aG9kOwogICAgICAgIHRoaXMucGFyYW1zID0gcGFyYW1zOwogICAgfQogICAgc3RhdGljIGZyb20oaW5pdCkgewogICAgICAgIGNvbnN0IHsgaWQsIG1ldGhvZCwgcGFyYW1zIH0gPSBpbml0OwogICAgICAgIHJldHVybiBuZXcgUnBjUmVxdWVzdChpZCwgbWV0aG9kLCBwYXJhbXMpOwogICAgfQogICAgdG9KU09OKCkgewogICAgICAgIGNvbnN0IHsganNvbnJwYywgaWQsIG1ldGhvZCwgcGFyYW1zIH0gPSB0aGlzOwogICAgICAgIHJldHVybiB7IGpzb25ycGMsIGlkLCBtZXRob2QsIHBhcmFtcyB9OwogICAgfQp9CgoKLy8jIHNvdXJjZU1hcHBpbmdVUkw9cmVxdWVzdC5tanMubWFwCgo7Ly8gQ09OQ0FURU5BVEVEIE1PRFVMRTogLi9ub2RlX21vZHVsZXMvQGhhemFlNDEvanNvbnJwYy9kaXN0L2VzbS9tb2RzL3JwYy9ycGMubWpzCgoKY2xhc3MgUnBjQ291bnRlciB7CiAgICBpZCA9IDA7CiAgICBwcmVwYXJlKGluaXQpIHsKICAgICAgICByZXR1cm4gbmV3IFJwY1JlcXVlc3QodGhpcy5pZCsrLCBpbml0Lm1ldGhvZCwgaW5pdC5wYXJhbXMpOwogICAgfQp9CgoKLy8jIHNvdXJjZU1hcHBpbmdVUkw9cnBjLm1qcy5tYXAKCjsvLyBDT05DQVRFTkFURUQgTU9EVUxFOiAuL3NyYy9tb2RzL2JhY2tncm91bmQvaW5qZWN0ZWRfc2NyaXB0L2luZGV4LnRzCgoKCgpjbGFzcyBQcm92aWRlciB7CiAgICBnZXQgaXNCcnVtZSgpIHsKICAgICAgICByZXR1cm4gdHJ1ZTsKICAgIH0KICAgIGdldCBpc01ldGFNYXNrKCkgewogICAgICAgIHJldHVybiB0cnVlOwogICAgfQogICAgLyoqCiAgICAgKiBAZGVwcmVjYXRlZAogICAgICovIGlzQ29ubmVjdGVkKCkgewogICAgICAgIHJldHVybiB0cnVlOwogICAgfQogICAgLyoqCiAgICAgKiBAZGVwcmVjYXRlZAogICAgICovIGlzVW5sb2NrZWQoKSB7CiAgICAgICAgcmV0dXJuIHRydWU7CiAgICB9CiAgICAvKioKICAgICAqIEBkZXByZWNhdGVkCiAgICAgKi8gZ2V0IGNoYWluSWQoKSB7CiAgICAgICAgcmV0dXJuIHRoaXMuX2NoYWluSWQ7CiAgICB9CiAgICAvKioKICAgICAqIEBkZXByZWNhdGVkCiAgICAgKi8gZ2V0IG5ldHdvcmtWZXJzaW9uKCkgewogICAgICAgIHJldHVybiB0aGlzLl9uZXR3b3JrVmVyc2lvbjsKICAgIH0KICAgIC8qKgogICAgICogQGRlcHJlY2F0ZWQKICAgICAqLyBnZXQgc2VsZWN0ZWRBZGRyZXNzKCkgewogICAgICAgIHJldHVybiB0aGlzLl9hY2NvdW50c1swXTsKICAgIH0KICAgIC8qKgogICAgICogQGRlcHJlY2F0ZWQKICAgICAqLyBnZXQgX21ldGFtYXNrKCkgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBAZGVwcmVjYXRlZAogICAgICovIGV2ZW50TmFtZXMoKSB7CiAgICAgICAgcmV0dXJuIFsKICAgICAgICAgICAgImNvbm5lY3QiLAogICAgICAgICAgICAiZGlzY29ubmVjdCIsCiAgICAgICAgICAgICJjaGFpbkNoYW5nZWQiLAogICAgICAgICAgICAiYWNjb3VudHNDaGFuZ2VkIiwKICAgICAgICAgICAgIm5ldHdvcmtDaGFuZ2VkIgogICAgICAgIF07CiAgICB9CiAgICAvKioKICAgICAqIEBkZXByZWNhdGVkCiAgICAgKi8gZ2V0TWF4TGlzdGVuZXJzKCkgewogICAgICAgIHJldHVybiBOdW1iZXIuTUFYX1NBRkVfSU5URUdFUjsKICAgIH0KICAgIC8qKgogICAgICogQGRlcHJlY2F0ZWQKICAgICAqLyBzZXRNYXhMaXN0ZW5lcnMoeCkgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBAZGVwcmVjYXRlZAogICAgICovIGxpc3RlbmVyQ291bnQoKSB7CiAgICAgICAgcmV0dXJuIHRoaXMuX2xpc3RlbmVyQ291bnQ7CiAgICB9CiAgICAvKioKICAgICAqIEBkZXByZWNhdGVkCiAgICAgKi8gbGlzdGVuZXJzKGtleSkgewogICAgICAgIGNvbnN0IGxpc3RlbmVycyA9IHRoaXMuX2xpc3RlbmVyc0J5RXZlbnQuZ2V0KGtleSk7CiAgICAgICAgaWYgKGxpc3RlbmVycyA9PSBudWxsKSByZXR1cm4gW107CiAgICAgICAgcmV0dXJuIFsKICAgICAgICAgICAgLi4ubGlzdGVuZXJzCiAgICAgICAgXTsKICAgIH0KICAgIC8qKgogICAgICogQGRlcHJlY2F0ZWQKICAgICAqLyByYXdMaXN0ZW5lcnMoa2V5KSB7CiAgICAgICAgcmV0dXJuIHRoaXMubGlzdGVuZXJzKGtleSk7CiAgICB9CiAgICAvKioKICAgICAqIEBkZXByZWNhdGVkCiAgICAgKi8gYXN5bmMgZW5hYmxlKCkgewogICAgICAgIC8qKgogICAgICAgICAqIEVuYWJsZSBjb21wYXRpYmlsaXR5IG1vZGUgZm9yIHRoYXQgb2xkIGFwcCB0aGF0IG5lZWRzIHRvIHJlbG9hZCBvbiBuZXR3b3JrIGNoYW5nZQogICAgICAgICAqLyB0aGlzLmF1dG9SZWZyZXNoT25OZXR3b3JrQ2hhbmdlID0gdHJ1ZTsKICAgICAgICByZXR1cm4gYXdhaXQgdGhpcy5yZXF1ZXN0KHsKICAgICAgICAgICAgaWQ6IG51bGwsCiAgICAgICAgICAgIG1ldGhvZDogImV0aF9yZXF1ZXN0QWNjb3VudHMiCiAgICAgICAgfSk7CiAgICB9CiAgICBhc3luYyB0cnlSZXF1ZXN0KHJlcWluaXQpIHsKICAgICAgICBjb25zdCByZXF1ZXN0ID0gdGhpcy5fY291bnRlci5wcmVwYXJlKHJlcWluaXQpOwogICAgICAgIGNvbnN0IGZ1dHVyZSA9IG5ldyBGdXR1cmUoKTsKICAgICAgICBjb25zdCBvblJlc3BvbnNlID0gKGUpPT57CiAgICAgICAgICAgIGNvbnN0IHJlc2luaXQgPSBKU09OLnBhcnNlKGUuZGV0YWlsKTsKICAgICAgICAgICAgaWYgKHJlc2luaXQuaWQgIT09IHJlcXVlc3QuaWQpIHJldHVybjsKICAgICAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBScGNSZXNwb25zZS5mcm9tKHJlc2luaXQpOwogICAgICAgICAgICBjb25zdCByZXdyYXBwZWQgPSBScGNSZXNwb25zZS5yZXdyYXAocmVxaW5pdC5pZCwgcmVzcG9uc2UpOwogICAgICAgICAgICBmdXR1cmUucmVzb2x2ZShyZXdyYXBwZWQpOwogICAgICAgIH07CiAgICAgICAgdHJ5IHsKICAgICAgICAgICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoImV0aGVyZXVtOnJlc3BvbnNlIiwgb25SZXNwb25zZSk7CiAgICAgICAgICAgIGNvbnN0IGRldGFpbCA9IEpTT04uc3RyaW5naWZ5KHJlcXVlc3QpOwogICAgICAgICAgICBjb25zdCBldmVudCA9IG5ldyBDdXN0b21FdmVudCgiZXRoZXJldW06cmVxdWVzdCIsIHsKICAgICAgICAgICAgICAgIGRldGFpbAogICAgICAgICAgICB9KTsKICAgICAgICAgICAgd2luZG93LmRpc3BhdGNoRXZlbnQoZXZlbnQpOwogICAgICAgICAgICByZXR1cm4gYXdhaXQgZnV0dXJlLnByb21pc2U7CiAgICAgICAgfSBmaW5hbGx5ewogICAgICAgICAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcigiZXRoZXJldW06cmVzcG9uc2UiLCBvblJlc3BvbnNlKTsKICAgICAgICB9CiAgICB9CiAgICBhc3luYyByZXF1ZXN0KGluaXQpIHsKICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCB0aGlzLnRyeVJlcXVlc3QoaW5pdCk7CiAgICAgICAgaWYgKHJlc3VsdC5pc0VycigpKSB0aHJvdyByZXN1bHQuaW5uZXI7CiAgICAgICAgcmV0dXJuIHJlc3VsdC5pbm5lcjsKICAgIH0KICAgIGFzeW5jIHJlcXVlc3RCYXRjaChpbml0cykgewogICAgICAgIHJldHVybiBhd2FpdCBQcm9taXNlLmFsbChpbml0cy5tYXAoKGluaXQpPT50aGlzLnRyeVJlcXVlc3QoaW5pdCkpKTsKICAgIH0KICAgIGFzeW5jIF9zZW5kKGluaXQsIGNhbGxiYWNrKSB7CiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCB0aGlzLnRyeVJlcXVlc3QoaW5pdCk7CiAgICAgICAgaWYgKHJlc3BvbnNlLmlzRXJyKCkpIGNhbGxiYWNrKHJlc3BvbnNlLmlubmVyLCByZXNwb25zZSk7CiAgICAgICAgZWxzZSBjYWxsYmFjayhudWxsLCByZXNwb25zZSk7CiAgICB9CiAgICAvKioKICAgICAqIEBkZXByZWNhdGVkCiAgICAgKi8gc2VuZChpbml0LCBjYWxsYmFjaykgewogICAgICAgIGlmICh0eXBlb2YgaW5pdCA9PT0gInN0cmluZyIpIGluaXQgPSB7CiAgICAgICAgICAgIGlkOiBudWxsLAogICAgICAgICAgICBtZXRob2Q6IGluaXQKICAgICAgICB9OwogICAgICAgIGlmIChjYWxsYmFjayAhPSBudWxsKSByZXR1cm4gdGhpcy5fc2VuZChpbml0LCBjYWxsYmFjayk7CiAgICAgICAgaWYgKGluaXQubWV0aG9kID09PSAiZXRoX2FjY291bnRzIikgcmV0dXJuIFJwY09rLnJld3JhcChpbml0LmlkLCBuZXcgT2sodGhpcy5fYWNjb3VudHMpKTsKICAgICAgICBpZiAoaW5pdC5tZXRob2QgPT09ICJldGhfY29pbmJhc2UiKSByZXR1cm4gUnBjT2sucmV3cmFwKGluaXQuaWQsIG5ldyBPayh0aGlzLl9hY2NvdW50c1swXSkpOwogICAgICAgIGlmIChpbml0Lm1ldGhvZCA9PT0gIm5ldF92ZXJzaW9uIikgcmV0dXJuIFJwY09rLnJld3JhcChpbml0LmlkLCBuZXcgT2sodGhpcy5fbmV0d29ya1ZlcnNpb24pKTsKICAgICAgICBpZiAoaW5pdC5tZXRob2QgPT09ICJldGhfdW5pbnN0YWxsRmlsdGVyIikgdGhyb3cgbmV3IEVycm9yKCJVbmltcGxlbWVudGVkIG1ldGhvZCAiLmNvbmNhdChpbml0Lm1ldGhvZCkpOwogICAgICAgIHRocm93IG5ldyBFcnJvcigiQXN5bmNocm9ub3VzIG1ldGhvZCAiLmNvbmNhdChpbml0Lm1ldGhvZCwgIiByZXF1aXJlcyBhIGNhbGxiYWNrIikpOwogICAgfQogICAgLyoqCiAgICAgKiBAZGVwcmVjYXRlZAogICAgICovIHNlbmRBc3luYyhpbml0LCBjYWxsYmFjaykgewogICAgICAgIGlmICh0eXBlb2YgaW5pdCA9PT0gInN0cmluZyIpIGluaXQgPSB7CiAgICAgICAgICAgIGlkOiBudWxsLAogICAgICAgICAgICBtZXRob2Q6IGluaXQKICAgICAgICB9OwogICAgICAgIHRoaXMuX3NlbmQoaW5pdCwgY2FsbGJhY2spOwogICAgfQogICAgX3JlZW1pdChrZXkpIHsKICAgICAgICB0aGlzLl9saXN0ZW5lcnNCeUV2ZW50LnNldChrZXksIG5ldyBTZXQoKSk7CiAgICAgICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoImV0aGVyZXVtOiIuY29uY2F0KGtleSksIChlKT0+ewogICAgICAgICAgICB0aGlzLmVtaXQoa2V5LCBKU09OLnBhcnNlKGUuZGV0YWlsKSk7CiAgICAgICAgfSwgewogICAgICAgICAgICBwYXNzaXZlOiB0cnVlCiAgICAgICAgfSk7CiAgICB9CiAgICBlbWl0KGtleSkgewogICAgICAgIGZvcih2YXIgX2xlbiA9IGFyZ3VtZW50cy5sZW5ndGgsIHBhcmFtcyA9IG5ldyBBcnJheShfbGVuID4gMSA/IF9sZW4gLSAxIDogMCksIF9rZXkgPSAxOyBfa2V5IDwgX2xlbjsgX2tleSsrKXsKICAgICAgICAgICAgcGFyYW1zW19rZXkgLSAxXSA9IGFyZ3VtZW50c1tfa2V5XTsKICAgICAgICB9CiAgICAgICAgY29uc3QgbGlzdGVuZXJzID0gdGhpcy5fbGlzdGVuZXJzQnlFdmVudC5nZXQoa2V5KTsKICAgICAgICBpZiAobGlzdGVuZXJzID09IG51bGwpIHJldHVybjsKICAgICAgICBmb3IgKGNvbnN0IGxpc3RlbmVyIG9mIGxpc3RlbmVycylsaXN0ZW5lciguLi5wYXJhbXMpOwogICAgICAgIHJldHVybjsKICAgIH0KICAgIG9uKGtleSwgbGlzdGVuZXIpIHsKICAgICAgICB0aGlzLmFkZExpc3RlbmVyKGtleSwgbGlzdGVuZXIpOwogICAgfQogICAgb2ZmKGtleSwgbGlzdGVuZXIpIHsKICAgICAgICB0aGlzLnJlbW92ZUxpc3RlbmVyKGtleSwgbGlzdGVuZXIpOwogICAgfQogICAgb25jZShrZXksIGxpc3RlbmVyKSB7CiAgICAgICAgdmFyIF90aGlzID0gdGhpczsKICAgICAgICBjb25zdCBsaXN0ZW5lcjIgPSBmdW5jdGlvbigpIHsKICAgICAgICAgICAgZm9yKHZhciBfbGVuID0gYXJndW1lbnRzLmxlbmd0aCwgcGFyYW1zID0gbmV3IEFycmF5KF9sZW4pLCBfa2V5ID0gMDsgX2tleSA8IF9sZW47IF9rZXkrKyl7CiAgICAgICAgICAgICAgICBwYXJhbXNbX2tleV0gPSBhcmd1bWVudHNbX2tleV07CiAgICAgICAgICAgIH0KICAgICAgICAgICAgbGlzdGVuZXIoLi4ucGFyYW1zKTsKICAgICAgICAgICAgX3RoaXMub2ZmKGtleSwgbGlzdGVuZXIyKTsKICAgICAgICB9OwogICAgICAgIHRoaXMub24oa2V5LCBsaXN0ZW5lcjIpOwogICAgfQogICAgYWRkTGlzdGVuZXIoa2V5LCBsaXN0ZW5lcikgewogICAgICAgIGNvbnN0IGxpc3RlbmVycyA9IHRoaXMuX2xpc3RlbmVyc0J5RXZlbnQuZ2V0KGtleSk7CiAgICAgICAgaWYgKGxpc3RlbmVycyA9PSBudWxsKSByZXR1cm47CiAgICAgICAgdGhpcy5fbGlzdGVuZXJDb3VudCAtPSBsaXN0ZW5lcnMuc2l6ZTsKICAgICAgICBsaXN0ZW5lcnMuYWRkKGxpc3RlbmVyKTsKICAgICAgICB0aGlzLl9saXN0ZW5lckNvdW50ICs9IGxpc3RlbmVycy5zaXplOwogICAgfQogICAgcmVtb3ZlTGlzdGVuZXIoa2V5LCBsaXN0ZW5lcikgewogICAgICAgIGNvbnN0IGxpc3RlbmVycyA9IHRoaXMuX2xpc3RlbmVyc0J5RXZlbnQuZ2V0KGtleSk7CiAgICAgICAgaWYgKGxpc3RlbmVycyA9PSBudWxsKSByZXR1cm47CiAgICAgICAgaWYgKCFsaXN0ZW5lcnMuZGVsZXRlKGxpc3RlbmVyKSkgcmV0dXJuOwogICAgICAgIHRoaXMuX2xpc3RlbmVyQ291bnQtLTsKICAgIH0KICAgIHJlbW92ZUFsbExpc3RlbmVycyhrZXkpIHsKICAgICAgICBjb25zdCBsaXN0ZW5lcnMgPSB0aGlzLl9saXN0ZW5lcnNCeUV2ZW50LmdldChrZXkpOwogICAgICAgIGlmIChsaXN0ZW5lcnMgPT0gbnVsbCkgcmV0dXJuOwogICAgICAgIHRoaXMuX2xpc3RlbmVyQ291bnQgLT0gbGlzdGVuZXJzLnNpemU7CiAgICAgICAgbGlzdGVuZXJzLmNsZWFyKCk7CiAgICB9CiAgICBwcmVwZW5kTGlzdGVuZXIoa2V5LCBsaXN0ZW5lcikgewogICAgICAgIGNvbnN0IGxpc3RlbmVycyA9IHRoaXMuX2xpc3RlbmVyc0J5RXZlbnQuZ2V0KGtleSk7CiAgICAgICAgaWYgKGxpc3RlbmVycyA9PSBudWxsKSByZXR1cm47CiAgICAgICAgdGhpcy5fbGlzdGVuZXJDb3VudCAtPSBsaXN0ZW5lcnMuc2l6ZTsKICAgICAgICBjb25zdCBvcmlnaW5hbCA9IFsKICAgICAgICAgICAgLi4ubGlzdGVuZXJzCiAgICAgICAgXTsKICAgICAgICBsaXN0ZW5lcnMuY2xlYXIoKTsKICAgICAgICBsaXN0ZW5lcnMuYWRkKGxpc3RlbmVyKTsKICAgICAgICBmb3IgKGNvbnN0IGxpc3RlbmVyIG9mIG9yaWdpbmFsKWxpc3RlbmVycy5hZGQobGlzdGVuZXIpOwogICAgICAgIHRoaXMuX2xpc3RlbmVyQ291bnQgKz0gbGlzdGVuZXJzLnNpemU7CiAgICB9CiAgICBwcmVwZW5kT25jZUxpc3RlbmVyKGtleSwgbGlzdGVuZXIpIHsKICAgICAgICB2YXIgX3RoaXMgPSB0aGlzOwogICAgICAgIGNvbnN0IGxpc3RlbmVyMiA9IGZ1bmN0aW9uKCkgewogICAgICAgICAgICBmb3IodmFyIF9sZW4gPSBhcmd1bWVudHMubGVuZ3RoLCBwYXJhbXMgPSBuZXcgQXJyYXkoX2xlbiksIF9rZXkgPSAwOyBfa2V5IDwgX2xlbjsgX2tleSsrKXsKICAgICAgICAgICAgICAgIHBhcmFtc1tfa2V5XSA9IGFyZ3VtZW50c1tfa2V5XTsKICAgICAgICAgICAgfQogICAgICAgICAgICBsaXN0ZW5lciguLi5wYXJhbXMpOwogICAgICAgICAgICBfdGhpcy5vZmYoa2V5LCBsaXN0ZW5lcjIpOwogICAgICAgIH07CiAgICAgICAgdGhpcy5wcmVwZW5kTGlzdGVuZXIoa2V5LCBsaXN0ZW5lcjIpOwogICAgfQogICAgY29uc3RydWN0b3IoKXsKICAgICAgICB0aGlzLl9jb3VudGVyID0gbmV3IFJwY0NvdW50ZXIoKTsKICAgICAgICB0aGlzLl9saXN0ZW5lcnNCeUV2ZW50ID0gbmV3IE1hcCgpOwogICAgICAgIC8qKgogICAgICogQGRlcHJlY2F0ZWQKICAgICAqLyB0aGlzLmF1dG9SZWZyZXNoT25OZXR3b3JrQ2hhbmdlID0gZmFsc2U7CiAgICAgICAgLyoqCiAgICAgKiBAZGVwcmVjYXRlZAogICAgICovIHRoaXMuX2FjY291bnRzID0gbmV3IEFycmF5KCk7CiAgICAgICAgLyoqCiAgICAgKiBAZGVwcmVjYXRlZAogICAgICovIHRoaXMuX2NoYWluSWQgPSAiMHgxIjsKICAgICAgICAvKioKICAgICAqIEBkZXByZWNhdGVkCiAgICAgKi8gdGhpcy5fbmV0d29ya1ZlcnNpb24gPSAiMSI7CiAgICAgICAgLyoqCiAgICAgKiBAZGVwcmVjYXRlZAogICAgICovIHRoaXMuX2xpc3RlbmVyQ291bnQgPSAwOwogICAgICAgIC8qKgogICAgICAgICAqIEZpeCBmb3IgdGhhdCBwb29ybHktY29kZWQgYXBwIHRoYXQgZG9lcyBgY29uc3QgeyByZXF1ZXN0IH0gPSBwcm92aWRlcmAKICAgICAgICAgKi8gdGhpcy5yZXF1ZXN0ID0gdGhpcy5yZXF1ZXN0LmJpbmQodGhpcyk7CiAgICAgICAgdGhpcy5zZW5kID0gdGhpcy5zZW5kLmJpbmQodGhpcyk7CiAgICAgICAgdGhpcy5zZW5kQXN5bmMgPSB0aGlzLnNlbmRBc3luYy5iaW5kKHRoaXMpOwogICAgICAgIHRoaXMuZW5hYmxlID0gdGhpcy5lbmFibGUuYmluZCh0aGlzKTsKICAgICAgICB0aGlzLmlzQ29ubmVjdGVkID0gdGhpcy5pc0Nvbm5lY3RlZC5iaW5kKHRoaXMpOwogICAgICAgIHRoaXMuaXNVbmxvY2tlZCA9IHRoaXMuaXNVbmxvY2tlZC5iaW5kKHRoaXMpOwogICAgICAgIHRoaXMub24gPSB0aGlzLm9uLmJpbmQodGhpcyk7CiAgICAgICAgdGhpcy5vZmYgPSB0aGlzLm9mZi5iaW5kKHRoaXMpOwogICAgICAgIHRoaXMub25jZSA9IHRoaXMub25jZS5iaW5kKHRoaXMpOwogICAgICAgIHRoaXMuZW1pdCA9IHRoaXMuZW1pdC5iaW5kKHRoaXMpOwogICAgICAgIHRoaXMuYWRkTGlzdGVuZXIgPSB0aGlzLmFkZExpc3RlbmVyLmJpbmQodGhpcyk7CiAgICAgICAgdGhpcy5yZW1vdmVMaXN0ZW5lciA9IHRoaXMucmVtb3ZlTGlzdGVuZXIuYmluZCh0aGlzKTsKICAgICAgICB0aGlzLnByZXBlbmRMaXN0ZW5lciA9IHRoaXMucHJlcGVuZExpc3RlbmVyLmJpbmQodGhpcyk7CiAgICAgICAgdGhpcy5wcmVwZW5kT25jZUxpc3RlbmVyID0gdGhpcy5wcmVwZW5kT25jZUxpc3RlbmVyLmJpbmQodGhpcyk7CiAgICAgICAgdGhpcy5yZW1vdmVBbGxMaXN0ZW5lcnMgPSB0aGlzLnJlbW92ZUFsbExpc3RlbmVycy5iaW5kKHRoaXMpOwogICAgICAgIHRoaXMuZXZlbnROYW1lcyA9IHRoaXMuZXZlbnROYW1lcy5iaW5kKHRoaXMpOwogICAgICAgIHRoaXMubGlzdGVuZXJzID0gdGhpcy5saXN0ZW5lcnMuYmluZCh0aGlzKTsKICAgICAgICB0aGlzLnJhd0xpc3RlbmVycyA9IHRoaXMucmF3TGlzdGVuZXJzLmJpbmQodGhpcyk7CiAgICAgICAgdGhpcy5saXN0ZW5lckNvdW50ID0gdGhpcy5saXN0ZW5lckNvdW50LmJpbmQodGhpcyk7CiAgICAgICAgdGhpcy5nZXRNYXhMaXN0ZW5lcnMgPSB0aGlzLmdldE1heExpc3RlbmVycy5iaW5kKHRoaXMpOwogICAgICAgIHRoaXMuc2V0TWF4TGlzdGVuZXJzID0gdGhpcy5zZXRNYXhMaXN0ZW5lcnMuYmluZCh0aGlzKTsKICAgICAgICB0aGlzLl9yZWVtaXQoImNvbm5lY3QiKTsKICAgICAgICB0aGlzLl9yZWVtaXQoImRpc2Nvbm5lY3QiKTsKICAgICAgICB0aGlzLl9yZWVtaXQoImFjY291bnRzQ2hhbmdlZCIpOwogICAgICAgIHRoaXMuX3JlZW1pdCgiY2hhaW5DaGFuZ2VkIik7CiAgICAgICAgdGhpcy5fcmVlbWl0KCJuZXR3b3JrQ2hhbmdlZCIpOwogICAgICAgIHRoaXMub24oImFjY291bnRzQ2hhbmdlZCIsIChhY2NvdW50cyk9PnsKICAgICAgICAgICAgdGhpcy5fYWNjb3VudHMgPSBhY2NvdW50czsKICAgICAgICB9KTsKICAgICAgICB0aGlzLm9uKCJjaGFpbkNoYW5nZWQiLCAoY2hhaW5JZCk9PnsKICAgICAgICAgICAgdGhpcy5fY2hhaW5JZCA9IGNoYWluSWQ7CiAgICAgICAgfSk7CiAgICAgICAgLyoqCiAgICAgICAgICogRml4IHRoYXQgb2xkIGFwcCB0aGF0IG5lZWRzIHRvIHJlbG9hZCBvbiBuZXR3b3JrIGNoYW5nZQogICAgICAgICAqLyB0aGlzLm9uKCJuZXR3b3JrQ2hhbmdlZCIsIChuZXR3b3JrVmVyc2lvbik9PnsKICAgICAgICAgICAgdGhpcy5fbmV0d29ya1ZlcnNpb24gPSBuZXR3b3JrVmVyc2lvbjsKICAgICAgICAgICAgaWYgKCF0aGlzLmF1dG9SZWZyZXNoT25OZXR3b3JrQ2hhbmdlKSByZXR1cm47CiAgICAgICAgICAgIGxvY2F0aW9uLnJlbG9hZCgpOwogICAgICAgIH0pOwogICAgICAgIC8qKgogICAgICAgICAqIEZvcmNlIHVwZGF0ZSBvZiBgaXNDb25uZWN0ZWRgLCBgc2VsZWN0ZWRBZGRyZXNzYCwgYGNoYWluSWRgIGBuZXR3b3JrVmVyc2lvbmAKICAgICAgICAgKi8gdGhpcy50cnlSZXF1ZXN0KHsKICAgICAgICAgICAgaWQ6IG51bGwsCiAgICAgICAgICAgIG1ldGhvZDogImV0aF9hY2NvdW50cyIKICAgICAgICB9KS50aGVuKChyKT0+ci5pZ25vcmUoKSk7CiAgICB9Cn0KY29uc3QgcHJvdmlkZXIgPSBuZXcgUHJvdmlkZXIoKTsKLy8gY29uc3QgcHJvdmlkZXIgPSBuZXcgUHJveHkobmV3IFByb3ZpZGVyKCksIHsKLy8gICBnZXQodGFyZ2V0LCBwLCByZWNlaXZlcikgewovLyAgICAgcmV0dXJuIFJlZmxlY3QuZ2V0KHRhcmdldCwgcCwgcmVjZWl2ZXIpCi8vICAgfSwKLy8gfSkKLyoqCiAqIEVJUC0xMTkzCiAqLyB3aW5kb3cuZXRoZXJldW0gPSBwcm92aWRlcjsKY29uc3QgaWNvbiA9IG5ldyBGdXR1cmUoKTsKY29uc3Qgb25Mb2dvID0gKGV2ZW50KT0+ewogICAgaWNvbi5yZXNvbHZlKEpTT04ucGFyc2UoZXZlbnQuZGV0YWlsKSk7Cn07CndpbmRvdy5hZGRFdmVudExpc3RlbmVyKCJicnVtZTppY29uIiwgb25Mb2dvLCB7CiAgICBwYXNzaXZlOiB0cnVlLAogICAgb25jZTogdHJ1ZQp9KTsKLyoqCiAqIEVJUC02OTYzCiAqLyB7CiAgICBhc3luYyBmdW5jdGlvbiBhbm5vdW5jZSgpIHsKICAgICAgICBjb25zdCBpbmZvID0gT2JqZWN0LmZyZWV6ZSh7CiAgICAgICAgICAgIHV1aWQ6ICJlNzUwYTk4Yy1mZjJkLTRmYzQtYjZlMi1mYWY0ZDEzZDFhZGQiLAogICAgICAgICAgICBuYW1lOiAiQnJ1bWUgV2FsbGV0IiwKICAgICAgICAgICAgaWNvbjogYXdhaXQgaWNvbi5wcm9taXNlLAogICAgICAgICAgICByZG5zOiAibW9uZXkuYnJ1bWUiCiAgICAgICAgfSk7CiAgICAgICAgY29uc3QgZGV0YWlsID0gT2JqZWN0LmZyZWV6ZSh7CiAgICAgICAgICAgIGluZm8sCiAgICAgICAgICAgIHByb3ZpZGVyCiAgICAgICAgfSk7CiAgICAgICAgY29uc3QgZXZlbnQgPSBuZXcgQ3VzdG9tRXZlbnQoImVpcDY5NjM6YW5ub3VuY2VQcm92aWRlciIsIHsKICAgICAgICAgICAgZGV0YWlsCiAgICAgICAgfSk7CiAgICAgICAgd2luZG93LmRpc3BhdGNoRXZlbnQoZXZlbnQpOwogICAgfQogICAgZnVuY3Rpb24gb25Bbm5vdW5jZVJlcXVlc3QoZXZlbnQpIHsKICAgICAgICBhbm5vdW5jZSgpOwogICAgfQogICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoImVpcDY5NjM6cmVxdWVzdFByb3ZpZGVyIiwgb25Bbm5vdW5jZVJlcXVlc3QsIHsKICAgICAgICBwYXNzaXZlOiB0cnVlCiAgICB9KTsKICAgIGFubm91bmNlKCk7Cn0KLyoqKioqKi8gfSkoKQo7");
    const scriptUrl = browser.runtime.getURL("injected_script.js");
    const element = document.createElement("script");
    element.type = "text/javascript";
    element.textContent = "".concat(scriptBody, "\n//# sourceURL=").concat(scriptUrl);
    container.insertBefore(element, container.children[0]);
    container.removeChild(element);
}
async function tryGetOrigin() {
    const origin = {
        origin: location.origin,
        title: document.title
    };
    for (const meta of document.getElementsByTagName("meta")){
        if (meta.name === "application-name") {
            origin.title = meta.content;
            continue;
        }
    }
    for (const link of document.getElementsByTagName("link")){
        if ([
            "icon",
            "shortcut icon",
            "icon shortcut"
        ].includes(link.rel)) {
            const blob = await tryFetchAsBlob(link.href);
            if (blob.isErr()) continue;
            const data = await Blobs.tryReadAsDataURL(blob.inner);
            if (data.isErr()) continue;
            origin.icon = data.inner;
            continue;
        }
        if (link.rel === "manifest") {
            const manifest = await tryFetchAsJson(link.href);
            if (manifest.isErr()) continue;
            if (manifest.inner.name) origin.title = manifest.inner.name;
            if (manifest.inner.short_name) origin.title = manifest.inner.short_name;
            if (manifest.inner.description) origin.description = manifest.inner.description;
            continue;
        }
    }
    if (!origin.icon) {
        await (async ()=>{
            const blob = await tryFetchAsBlob("/favicon.ico");
            if (blob.isErr()) return;
            const data = await Blobs.tryReadAsDataURL(blob.inner);
            if (data.isErr()) return;
            origin.icon = data.inner;
        })();
    }
    return new ok_Ok(origin);
}
new Pool(async (params)=>{
    return Result.unthrow(async (t)=>{
        const { index, pool } = params;
        await new Promise((ok)=>setTimeout(ok, 1));
        const raw = await tryBrowser(async ()=>{
            const port = browser.runtime.connect({
                name: location.origin
            });
            port.onDisconnect.addListener(()=>void chrome.runtime.lastError);
            return port;
        }).then((r)=>r.throw(t));
        const background = new ExtensionPort("background", raw);
        const onScriptRequest = async (input)=>{
            const request = JSON.parse(input.detail);
            const result = await background.tryRequest({
                method: "brume_run",
                params: [
                    request,
                    mouse
                ]
            });
            const response = RpcResponse.rewrap(request.id, result.andThenSync((r)=>r));
            const detail = JSON.stringify(response);
            const output = new CustomEvent("ethereum:response", {
                detail
            });
            window.dispatchEvent(output);
        };
        window.addEventListener("ethereum:request", onScriptRequest, {
            passive: true
        });
        const onAccountsChanged = async (request)=>{
            const [accounts] = request.params;
            const detail = JSON.stringify(accounts);
            const event = new CustomEvent("ethereum:accountsChanged", {
                detail
            });
            window.dispatchEvent(event);
            return ok_Ok.void();
        };
        const onConnect = async (request)=>{
            const [{ chainId }] = request.params;
            const detail = JSON.stringify({
                chainId
            });
            const event = new CustomEvent("ethereum:connect", {
                detail
            });
            window.dispatchEvent(event);
            return ok_Ok.void();
        };
        const onChainChanged = async (request)=>{
            const [chainId] = request.params;
            const detail = JSON.stringify(chainId);
            const event = new CustomEvent("ethereum:chainChanged", {
                detail
            });
            window.dispatchEvent(event);
            return ok_Ok.void();
        };
        const onNetworkChanged = async (request)=>{
            const [chainId] = request.params;
            const detail = JSON.stringify(chainId);
            const event = new CustomEvent("ethereum:networkChanged", {
                detail
            });
            window.dispatchEvent(event);
            return ok_Ok.void();
        };
        const onBackgroundRequest = async (request)=>{
            if (request.method === "brume_origin") return new Some(await tryGetOrigin());
            if (request.method === "connect") return new Some(await onConnect(request));
            if (request.method === "accountsChanged") return new Some(await onAccountsChanged(request));
            if (request.method === "chainChanged") return new Some(await onChainChanged(request));
            if (request.method === "networkChanged") return new Some(await onNetworkChanged(request));
            return new None();
        };
        background.events.on("request", onBackgroundRequest, {
            passive: true
        });
        const onClose = async ()=>{
            const event = new CustomEvent("ethereum:disconnect", {});
            window.dispatchEvent(event);
            await pool.restart(index);
            return new None();
        };
        background.events.on("close", onClose, {
            passive: true
        });
        {
            const icon = await background.tryRequest({
                method: "brume_icon"
            }).then((r)=>r.throw(t).throw(t));
            const detail = JSON.stringify(icon);
            const event = new CustomEvent("brume:icon", {
                detail
            });
            window.dispatchEvent(event);
        }
        const onClean = ()=>{
            window.removeEventListener("ethereum:request", onScriptRequest);
            background.events.off("close", onClose);
            background.clean();
            raw.disconnect();
        };
        return new ok_Ok(new Disposer(raw, onClean));
    });
}, {
    capacity: 1
});

/******/ })()
;