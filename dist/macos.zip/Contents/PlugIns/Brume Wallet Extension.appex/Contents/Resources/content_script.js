/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 979:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   _: () => (/* binding */ Blobs)
/* harmony export */ });
/* harmony import */ var _hazae41_future__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(71);
/* harmony import */ var _hazae41_result__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(452);


var Blobs;
(function(Blobs) {
    async function tryReadAsDataUrl(blob) {
        return _hazae41_result__WEBPACK_IMPORTED_MODULE_0__/* .Result */ .x.runAndDoubleWrap(()=>readAsDataUrlOrThrow(blob));
    }
    Blobs.tryReadAsDataUrl = tryReadAsDataUrl;
    async function readAsDataUrlOrThrow(blob) {
        const future = new _hazae41_future__WEBPACK_IMPORTED_MODULE_1__/* .Future */ .o();
        const reader = new FileReader();
        const onLoad = ()=>{
            future.resolve(reader.result);
        };
        const onError = ()=>{
            future.reject(reader.error);
        };
        try {
            reader.addEventListener("load", onLoad, {
                passive: true
            });
            reader.addEventListener("error", onError, {
                passive: true
            });
            reader.readAsDataURL(blob);
            return await future.promise;
        } finally{
            reader.removeEventListener("load", onLoad);
            reader.removeEventListener("error", onError);
        }
    }
    Blobs.readAsDataUrlOrThrow = readAsDataUrlOrThrow;
})(Blobs || (Blobs = {}));


/***/ }),

/***/ 681:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   X: () => (/* binding */ browser),
/* harmony export */   v: () => (/* binding */ BrowserError)
/* harmony export */ });
/* harmony import */ var _swc_helpers_class_private_field_get__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(605);
/* harmony import */ var _swc_helpers_class_private_field_init__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(76);
/* harmony import */ var _swc_helpers_class_private_field_set__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(941);
/* harmony import */ var _hazae41_result__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(591);
/* harmony import */ var _hazae41_result__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(166);



var _a;

var _ref, _ref1;
const browser = (_ref1 = (_ref = null) !== null && _ref !== void 0 ? _ref : globalThis.browser) !== null && _ref1 !== void 0 ? _ref1 : globalThis.chrome;
var _class = /*#__PURE__*/ new WeakMap();
class BrowserError extends Error {
    static from(cause) {
        return new _a(undefined, {
            cause
        });
    }
    static async runOrThrow(callback) {
        try {
            const result = await callback();
            if (browser.runtime.lastError) throw browser.runtime.lastError;
            return result;
        } catch (e) {
            throw _a.from(e);
        }
    }
    static runOrThrowSync(callback) {
        try {
            const result = callback();
            if (browser.runtime.lastError) throw browser.runtime.lastError;
            return result;
        } catch (e) {
            throw _a.from(e);
        }
    }
    static async tryRun(callback) {
        try {
            const result = await callback();
            if (browser.runtime.lastError) throw browser.runtime.lastError;
            return new _hazae41_result__WEBPACK_IMPORTED_MODULE_0__.Ok(result);
        } catch (e) {
            return new _hazae41_result__WEBPACK_IMPORTED_MODULE_1__/* .Err */ .U(_a.from(e));
        }
    }
    static tryRunSync(callback) {
        try {
            const result = callback();
            if (browser.runtime.lastError) throw browser.runtime.lastError;
            return new _hazae41_result__WEBPACK_IMPORTED_MODULE_0__.Ok(result);
        } catch (e) {
            return new _hazae41_result__WEBPACK_IMPORTED_MODULE_1__/* .Err */ .U(_a.from(e));
        }
    }
    constructor(...args){
        super(...args);
        (0,_swc_helpers_class_private_field_init__WEBPACK_IMPORTED_MODULE_2__._)(this, _class, {
            writable: true,
            value: void 0
        });
        (0,_swc_helpers_class_private_field_set__WEBPACK_IMPORTED_MODULE_3__._)(this, _class, _a);
        this.name = (0,_swc_helpers_class_private_field_get__WEBPACK_IMPORTED_MODULE_4__._)(this, _class).name;
    }
}
_a = BrowserError;


/***/ }),

/***/ 879:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  D: () => (/* binding */ ExtensionRpcRouter)
});

// UNUSED EXPORTS: MessageRpcRouter

// EXTERNAL MODULE: ./node_modules/@swc/helpers/esm/_class_private_field_get.js + 1 modules
var esm_class_private_field_get = __webpack_require__(605);
// EXTERNAL MODULE: ./node_modules/@swc/helpers/esm/_class_private_field_init.js + 1 modules
var esm_class_private_field_init = __webpack_require__(76);
// EXTERNAL MODULE: ./node_modules/@swc/helpers/esm/_class_private_field_set.js + 1 modules
var esm_class_private_field_set = __webpack_require__(941);
// EXTERNAL MODULE: ./node_modules/@hazae41/jsonrpc/dist/esm/mods/rpc/err.mjs
var err = __webpack_require__(667);
// EXTERNAL MODULE: ./node_modules/@hazae41/jsonrpc/dist/esm/mods/rpc/response.mjs + 1 modules
var rpc_response = __webpack_require__(978);
;// CONCATENATED MODULE: ./node_modules/@hazae41/jsonrpc/dist/esm/mods/rpc/request.mjs
class RpcRequest {
    id;
    method;
    params;
    jsonrpc = "2.0";
    constructor(id, method, params) {
        this.id = id;
        this.method = method;
        this.params = params;
    }
    static from(init) {
        const { id, method, params } = init;
        return new RpcRequest(id, method, params);
    }
    toJSON() {
        const { jsonrpc, id, method, params } = this;
        return { jsonrpc, id, method, params };
    }
}


//# sourceMappingURL=request.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/jsonrpc/dist/esm/mods/rpc/rpc.mjs


class rpc_RpcCounter {
    id = 0;
    prepare(init) {
        const { id = this.id++, method, params } = init;
        return new RpcRequest(id, method, params);
    }
}


//# sourceMappingURL=rpc.mjs.map

// EXTERNAL MODULE: ./node_modules/@hazae41/option/dist/esm/mods/option/none.mjs
var none = __webpack_require__(371);
// EXTERNAL MODULE: ./node_modules/@hazae41/option/dist/esm/mods/option/some.mjs
var some = __webpack_require__(862);
;// CONCATENATED MODULE: ./node_modules/@hazae41/plume/dist/esm/node_modules/tslib/tslib.es6.mjs
/******************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */
/* global Reflect, Promise, SuppressedError, Symbol */


function tslib_es6_addDisposableResource(env, value, async) {
    if (value !== null && value !== void 0) {
        if (typeof value !== "object" && typeof value !== "function") throw new TypeError("Object expected.");
        var dispose;
        if (async) {
            if (!Symbol.asyncDispose) throw new TypeError("Symbol.asyncDispose is not defined.");
            dispose = value[Symbol.asyncDispose];
        }
        if (dispose === void 0) {
            if (!Symbol.dispose) throw new TypeError("Symbol.dispose is not defined.");
            dispose = value[Symbol.dispose];
        }
        if (typeof dispose !== "function") throw new TypeError("Object not disposable.");
        env.stack.push({ value: value, dispose: dispose, async: async });
    }
    else if (async) {
        env.stack.push({ async: true });
    }
    return value;
}

var _SuppressedError = typeof SuppressedError === "function" ? SuppressedError : function (error, suppressed, message) {
    var e = new Error(message);
    return e.name = "SuppressedError", e.error = error, e.suppressed = suppressed, e;
};

function tslib_es6_disposeResources(env) {
    function fail(e) {
        env.error = env.hasError ? new _SuppressedError(e, env.error, "An error was suppressed during disposal.") : e;
        env.hasError = true;
    }
    function next() {
        while (env.stack.length) {
            var rec = env.stack.pop();
            try {
                var result = rec.dispose && rec.dispose.call(rec.value);
                if (rec.async) return Promise.resolve(result).then(next, function(e) { fail(e); return next(); });
            }
            catch (e) {
                fail(e);
            }
        }
        if (env.hasError) throw env.error;
    }
    return next();
}


//# sourceMappingURL=tslib.es6.mjs.map

// EXTERNAL MODULE: ./node_modules/@hazae41/signals/dist/esm/mods/signals/index.mjs
var signals = __webpack_require__(168);
;// CONCATENATED MODULE: ./node_modules/@hazae41/plume/dist/esm/src/mods/errors.mjs


var _a, _b, _c;
class AbortedError extends Error {
    #class = _a;
    name = this.#class.name;
    constructor(options) {
        super("Aborted", options);
    }
    static from(cause) {
        return new _a({ cause });
    }
}
_a = AbortedError;
class ErroredError extends Error {
    #class = _b;
    name = this.#class.name;
    constructor(options) {
        super("Errored", options);
    }
    static from(cause) {
        return new _b({ cause });
    }
}
_b = ErroredError;
var errors_ErrorEvents;
(function (ErrorEvents) {
    function waitOrThrow(target) {
        return target.wait("error", (future, ...[reason]) => {
            future.reject(ErroredError.from(reason));
            return new none/* None */.H();
        });
    }
    ErrorEvents.waitOrThrow = waitOrThrow;
})(errors_ErrorEvents || (errors_ErrorEvents = {}));
class ClosedError extends Error {
    #class = _c;
    name = this.#class.name;
    constructor(options) {
        super("Closed", options);
    }
    static from(cause) {
        return new _c({ cause });
    }
}
_c = ClosedError;
var errors_CloseEvents;
(function (CloseEvents) {
    function waitOrThrow(target) {
        return target.wait("close", (future, ...[reason]) => {
            future.reject(ClosedError.from(reason));
            return new none/* None */.H();
        });
    }
    CloseEvents.waitOrThrow = waitOrThrow;
})(errors_CloseEvents || (errors_CloseEvents = {}));


//# sourceMappingURL=errors.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/plume/dist/esm/src/mods/waiters.mjs




async function waitOrSignal(target, type, callback, signal) {
    const env_1 = { stack: [], error: void 0, hasError: false };
    try {
        const abort = __addDisposableResource(env_1, Signals.rejectOnAbort(signal), false);
        const event = __addDisposableResource(env_1, target.wait(type, callback), false);
        return await Promise.race([abort.get(), event.get()]);
    }
    catch (e_1) {
        env_1.error = e_1;
        env_1.hasError = true;
    }
    finally {
        __disposeResources(env_1);
    }
}
async function waitOrCloseOrError(target, type, callback) {
    const env_2 = { stack: [], error: void 0, hasError: false };
    try {
        const error = __addDisposableResource(env_2, ErrorEvents.waitOrThrow(target), false);
        const close = __addDisposableResource(env_2, CloseEvents.waitOrThrow(target), false);
        const event = __addDisposableResource(env_2, target.wait(type, callback), false);
        return await Promise.race([error.get(), close.get(), event.get()]);
    }
    catch (e_2) {
        env_2.error = e_2;
        env_2.hasError = true;
    }
    finally {
        __disposeResources(env_2);
    }
}
async function waitOrCloseOrErrorOrSignal(target, type, callback, signal) {
    const env_3 = { stack: [], error: void 0, hasError: false };
    try {
        const abort = tslib_es6_addDisposableResource(env_3, signals/* rejectOnAbort */.C$(signal), false);
        const error = tslib_es6_addDisposableResource(env_3, errors_ErrorEvents.waitOrThrow(target), false);
        const close = tslib_es6_addDisposableResource(env_3, errors_CloseEvents.waitOrThrow(target), false);
        const event = tslib_es6_addDisposableResource(env_3, target.wait(type, callback), false);
        return await Promise.race([abort.get(), error.get(), close.get(), event.get()]);
    }
    catch (e_3) {
        env_3.error = e_3;
        env_3.hasError = true;
    }
    finally {
        tslib_es6_disposeResources(env_3);
    }
}


//# sourceMappingURL=waiters.mjs.map

// EXTERNAL MODULE: ./node_modules/@hazae41/plume/dist/esm/src/mods/target.mjs
var target = __webpack_require__(232);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/ok.mjs
var ok = __webpack_require__(591);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/err.mjs
var result_err = __webpack_require__(166);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/result.mjs + 1 modules
var result = __webpack_require__(452);
// EXTERNAL MODULE: ./src/libs/browser/browser.ts
var browser = __webpack_require__(681);
;// CONCATENATED MODULE: ./src/libs/console/index.ts
var console_Console;
(function(Console) {
    Console.debugging = false;
    function debug() {
        for(var _len = arguments.length, params = new Array(_len), _key = 0; _key < _len; _key++){
            params[_key] = arguments[_key];
        }
        if (!Console.debugging) return;
        console.debug(...params);
    }
    Console.debug = debug;
})(console_Console || (console_Console = {}));

// EXTERNAL MODULE: ./src/libs/signals/signals.ts
var signals_signals = __webpack_require__(370);
;// CONCATENATED MODULE: ./src/libs/uuid/uuid.ts
function uuid_randomUUID() {
    if (!isSecureContext) {
        const parts = new Array();
        {
            const bytes = new Uint8Array(4);
            crypto.getRandomValues(bytes);
            parts.push(bytes.reduce((p, c)=>p + c.toString(16).padStart(2, "0"), ""));
        }
        {
            const bytes = new Uint8Array(2);
            crypto.getRandomValues(bytes);
            parts.push(bytes.reduce((p, c)=>p + c.toString(16).padStart(2, "0"), ""));
        }
        {
            const bytes = new Uint8Array(2);
            crypto.getRandomValues(bytes);
            parts.push(bytes.reduce((p, c)=>p + c.toString(16).padStart(2, "0"), ""));
        }
        {
            const bytes = new Uint8Array(2);
            crypto.getRandomValues(bytes);
            parts.push(bytes.reduce((p, c)=>p + c.toString(16).padStart(2, "0"), ""));
        }
        {
            const bytes = new Uint8Array(6);
            crypto.getRandomValues(bytes);
            parts.push(bytes.reduce((p, c)=>p + c.toString(16).padStart(2, "0"), ""));
        }
        return parts.join("-");
    }
    return crypto.randomUUID();
}

;// CONCATENATED MODULE: ./src/libs/channel/channel.ts



var channel_addDisposableResource = undefined && undefined.__addDisposableResource || function(env, value, async) {
    if (value !== null && value !== void 0) {
        if (typeof value !== "object" && typeof value !== "function") throw new TypeError("Object expected.");
        var dispose;
        if (async) {
            if (!Symbol.asyncDispose) throw new TypeError("Symbol.asyncDispose is not defined.");
            dispose = value[Symbol.asyncDispose];
        }
        if (dispose === void 0) {
            if (!Symbol.dispose) throw new TypeError("Symbol.dispose is not defined.");
            dispose = value[Symbol.dispose];
        }
        if (typeof dispose !== "function") throw new TypeError("Object not disposable.");
        env.stack.push({
            value: value,
            dispose: dispose,
            async: async
        });
    } else if (async) {
        env.stack.push({
            async: true
        });
    }
    return value;
};
var channel_disposeResources = undefined && undefined.__disposeResources || function(SuppressedError1) {
    return function(env) {
        function fail(e) {
            env.error = env.hasError ? new SuppressedError1(e, env.error, "An error was suppressed during disposal.") : e;
            env.hasError = true;
        }
        function next() {
            while(env.stack.length){
                var rec = env.stack.pop();
                try {
                    var result = rec.dispose && rec.dispose.call(rec.value);
                    if (rec.async) return Promise.resolve(result).then(next, function(e) {
                        fail(e);
                        return next();
                    });
                } catch (e) {
                    fail(e);
                }
            }
            if (env.hasError) throw env.error;
        }
        return next();
    };
}(typeof SuppressedError === "function" ? SuppressedError : function(error, suppressed, message) {
    var e = new Error(message);
    return e.name = "SuppressedError", e.error = error, e.suppressed = suppressed, e;
});









var _clean = /*#__PURE__*/ new WeakMap();
let _Symbol_dispose = Symbol.dispose;
class MessageRpcRouter {
    [_Symbol_dispose]() {
        _class_private_field_get(this, _clean).call(this);
    }
    async runPingLoop() {
        let count = 0;
        while(true){
            try {
                await new Promise((ok)=>setTimeout(ok, 1000));
                await this.requestOrThrow({
                    id: "ping",
                    method: "brume_ping"
                }, AbortSignal.timeout(1000)).then((r)=>r.unwrap());
                count = 0;
                continue;
            } catch (e) {
                if (count < 2) {
                    count++;
                    continue;
                }
                await this.events.emit("close", [
                    undefined
                ]);
                return;
            }
        }
    }
    async tryRouteRequest(request) {
        try {
            const returned = await this.events.emit("request", request);
            if (returned.isSome()) return returned.inner;
            if (request.method === "brume_hello") return Ok.void();
            if (request.method === "brume_ping") return Ok.void();
            return new Err(new RpcInvalidRequestError());
        } catch (e) {
            console.error(e, {
                e
            });
            return new Err(new RpcInternalError());
        }
    }
    async onRequest(request) {
        if (request.id !== "ping") Console.debug(this.name, "->", request);
        const result = await this.tryRouteRequest(request);
        const response = RpcResponse.rewrap(request.id, result);
        if (request.id !== "ping") Console.debug(this.name, "<-", response, result);
        this.port.postMessage(JSON.stringify(response));
    }
    async onResponse(response) {
        if (response.id !== "ping") Console.debug(this.name, "->", response);
        const returned = await this.events.emit("response", response);
        if (returned.isSome()) return returned.inner;
        return new Err(new Error("Unhandled JSON-RPC response ".concat(JSON.stringify(response))));
    }
    async onMessage(message) {
        const data = JSON.parse(message.data);
        if ("method" in data) return await this.onRequest(data);
        return await this.onResponse(data);
    }
    async tryRequest(init) {
        let signal = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : AbortSignals.never();
        return Result.runAndDoubleWrap(()=>this.requestOrThrow(init, signal));
    }
    async requestOrThrow(init) {
        let signal = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : AbortSignals.never();
        const request = this.counter.prepare(init);
        if (request.id !== "ping") Console.debug(this.name, "<-", request);
        this.port.postMessage(JSON.stringify(request));
        return Plume.waitOrCloseOrErrorOrSignal(this.events, "response", (future, init)=>{
            if (init.id !== request.id) return new None();
            const response = RpcResponse.from(init);
            future.resolve(response);
            return new Some(undefined);
        }, signal);
    }
    async waitHelloOrThrow() {
        let signal = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : AbortSignals.never();
        const env_1 = {
            stack: [],
            error: void 0,
            hasError: false
        };
        try {
            const active = this.requestOrThrow({
                method: "brume_hello"
            }).then((r)=>r.unwrap());
            const passive = channel_addDisposableResource(env_1, this.events.wait("request", (future, init)=>{
                if (init.method !== "brume_hello") return new None();
                future.resolve();
                return new Some(Ok.void());
            }), false);
            const abort = channel_addDisposableResource(env_1, Signals.rejectOnAbort(signal), false);
            return await Promise.race([
                active,
                passive.get(),
                abort.get()
            ]);
        } catch (e_1) {
            env_1.error = e_1;
            env_1.hasError = true;
        } finally{
            channel_disposeResources(env_1);
        }
    }
    constructor(name, port){
        _class_private_field_init(this, _clean, {
            writable: true,
            value: void 0
        });
        this.counter = new RpcCounter();
        this.uuid = randomUUID();
        this.events = new SuperEventTarget();
        this.name = name;
        this.port = port;
        const onMessage = this.onMessage.bind(this);
        this.port.addEventListener("message", onMessage, {
            passive: true
        });
        _class_private_field_set(this, _clean, ()=>{
            this.port.removeEventListener("message", onMessage);
            _class_private_field_set(this, _clean, ()=>{});
        });
    }
}
var _clean1 = /*#__PURE__*/ new WeakMap();
let _Symbol_dispose1 = Symbol.dispose;
class ExtensionRpcRouter {
    [_Symbol_dispose1]() {
        (0,esm_class_private_field_get._)(this, _clean1).call(this);
    }
    async tryRouteRequest(request) {
        try {
            const returned = await this.events.emit("request", request);
            if (returned.isSome()) return returned.inner;
            if (request.method === "brume_hello") return ok.Ok.void();
            if (request.method === "brume_ping") return ok.Ok.void();
            return new result_err/* Err */.U(new err/* RpcInvalidRequestError */.av());
        } catch (e) {
            console.error(e, {
                e
            });
            return new result_err/* Err */.U(new err/* RpcInternalError */.CZ());
        }
    }
    async onRequest(request) {
        if (request.id !== "ping") console_Console.debug(this.name, "->", request);
        const result = await this.tryRouteRequest(request);
        const response = rpc_response/* RpcResponse */.S.rewrap(request.id, result);
        if (request.id !== "ping") console_Console.debug(this.name, "<-", response);
        browser/* BrowserError */.v.tryRunSync(()=>{
            this.port.postMessage(JSON.stringify(response));
        }).ignore();
    }
    async onResponse(response) {
        if (response.id !== "ping") console_Console.debug(this.name, "->", response);
        const returned = await this.events.emit("response", response);
        if (returned.isSome()) return returned.inner;
        return new result_err/* Err */.U(new Error("Unhandled JSON-RPC response ".concat(JSON.stringify(response))));
    }
    async onMessage(message) {
        const data = JSON.parse(message);
        if ("method" in data) return await this.onRequest(data);
        return await this.onResponse(data);
    }
    async onDisconnect() {
        await this.events.emit("close", [
            undefined
        ]);
    }
    async tryRequest(init) {
        return result/* Result */.x.runAndDoubleWrap(()=>this.requestOrThrow(init));
    }
    async requestOrThrow(init) {
        let signal = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : signals_signals/* AbortSignals */.f.never();
        const request = this.counter.prepare(init);
        if (request.id !== "ping") console_Console.debug(this.name, "<-", request);
        browser/* BrowserError */.v.runOrThrowSync(()=>this.port.postMessage(JSON.stringify(request)));
        return waitOrCloseOrErrorOrSignal(this.events, "response", (future, init)=>{
            if (init.id !== request.id) return new none/* None */.H();
            const response = rpc_response/* RpcResponse */.S.from(init);
            future.resolve(response);
            return new some/* Some */.b(undefined);
        }, signal);
    }
    async waitHelloOrThrow() {
        let signal = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : signals_signals/* AbortSignals */.f.never();
        const env_2 = {
            stack: [],
            error: void 0,
            hasError: false
        };
        try {
            const active = this.requestOrThrow({
                method: "brume_hello"
            }).then((r)=>r.unwrap());
            const passive = channel_addDisposableResource(env_2, this.events.wait("request", (future, init)=>{
                if (init.method !== "brume_hello") return new none/* None */.H();
                future.resolve();
                return new some/* Some */.b(ok.Ok.void());
            }), false);
            const abort = channel_addDisposableResource(env_2, signals/* rejectOnAbort */.C$(signal), false);
            return await Promise.race([
                active,
                passive.get(),
                abort.get()
            ]);
        } catch (e_2) {
            env_2.error = e_2;
            env_2.hasError = true;
        } finally{
            channel_disposeResources(env_2);
        }
    }
    constructor(name, port){
        (0,esm_class_private_field_init._)(this, _clean1, {
            writable: true,
            value: void 0
        });
        this.counter = new rpc_RpcCounter();
        this.uuid = uuid_randomUUID();
        this.events = new target/* SuperEventTarget */.v();
        this.name = name;
        this.port = port;
        const onMessage = this.onMessage.bind(this);
        const onDisconnect = this.onDisconnect.bind(this);
        this.port.onMessage.addListener(onMessage);
        this.port.onDisconnect.addListener(onDisconnect);
        (0,esm_class_private_field_set._)(this, _clean1, ()=>{
            this.port.onMessage.removeListener(onMessage);
            this.port.onDisconnect.removeListener(onDisconnect);
            (0,esm_class_private_field_set._)(this, _clean1, ()=>{});
        });
    }
}


/***/ }),

/***/ 830:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Br: () => (/* binding */ tryFetchAsJson),
/* harmony export */   l_: () => (/* binding */ tryFetchAsBlob)
/* harmony export */ });
/* unused harmony exports fetchAsJsonOrThrow, fetchAsBlobOrThrow */
/* harmony import */ var _hazae41_result__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(452);

async function tryFetchAsJson(input, init) {
    return _hazae41_result__WEBPACK_IMPORTED_MODULE_0__/* .Result */ .x.runAndDoubleWrap(()=>fetchAsJsonOrThrow(input, init));
}
async function fetchAsJsonOrThrow(input, init) {
    const res = await fetch(input, init);
    if (!res.ok) throw new Error(await res.text());
    return await res.json();
}
async function tryFetchAsBlob(input, init) {
    return _hazae41_result__WEBPACK_IMPORTED_MODULE_0__/* .Result */ .x.runAndDoubleWrap(()=>fetchAsBlobOrThrow(input, init));
}
async function fetchAsBlobOrThrow(input, init) {
    const res = await fetch(input, init);
    if (!res.ok) throw new Error(await res.text());
    return await res.blob();
}


/***/ }),

/***/ 266:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A$: () => (/* binding */ isFirefoxExtension),
/* harmony export */   WB: () => (/* binding */ isSafariExtension)
/* harmony export */ });
/* unused harmony exports isWebsite, isExtension, isChromeExtension, isAndroidApp, isAppleApp, isIpad */
const IS_DEV = "production" === "development";
function isWebsite() {
    return IS_DEV || false;
}
function isExtension() {
    return !IS_DEV && (false || false || true);
}
function isChromeExtension() {
    return !IS_DEV && false;
}
function isFirefoxExtension() {
    return !IS_DEV && false;
}
function isSafariExtension() {
    return !IS_DEV && true;
}
function isAndroidApp() {
    return !IS_DEV && false;
}
function isAppleApp() {
    return !IS_DEV && false;
}
function isIpad() {
    return navigator.platform === "MacIntel" && navigator.maxTouchPoints > 0;
}


/***/ }),

/***/ 370:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   f: () => (/* binding */ AbortSignals)
/* harmony export */ });
var AbortSignals;
(function(AbortSignals) {
    function never() {
        return new AbortController().signal;
    }
    AbortSignals.never = never;
    function timeout(delay, parent) {
        return merge(AbortSignal.timeout(delay), parent);
    }
    AbortSignals.timeout = timeout;
    function merge(a, b) {
        if (b == null) return a;
        const c = new AbortController();
        const onAbort = (reason)=>{
            c.abort(reason);
            a.removeEventListener("abort", onAbort);
            b.removeEventListener("abort", onAbort);
        };
        a.addEventListener("abort", onAbort, {
            passive: true
        });
        b.addEventListener("abort", onAbort, {
            passive: true
        });
        return c.signal;
    }
    AbortSignals.merge = merge;
})(AbortSignals || (AbortSignals = {}));


/***/ }),

/***/ 731:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   d: () => (/* binding */ qurl)
/* harmony export */ });
function qurl(pathOrUrl) {
    let query = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
    const url = new URL(pathOrUrl, location.href);
    for (const [key, value] of Object.entries(query))if (value != null) url.searchParams.append(key, String(value));
    return url;
}


/***/ }),

/***/ 880:
/***/ ((module, __unused_webpack___webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony import */ var _hazae41_symbol_dispose_polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(801);
/* harmony import */ var _libs_blobs_blobs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(979);
/* harmony import */ var _libs_browser_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(681);
/* harmony import */ var _libs_channel_channel__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(879);
/* harmony import */ var _libs_fetch_fetch__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(830);
/* harmony import */ var _libs_platform_platform__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(266);
/* harmony import */ var _libs_signals_signals__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(370);
/* harmony import */ var _libs_url_url__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(731);
/* harmony import */ var _hazae41_box__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(200);
/* harmony import */ var _hazae41_disposer__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(180);
/* harmony import */ var _hazae41_jsonrpc__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(978);
/* harmony import */ var _hazae41_option__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(862);
/* harmony import */ var _hazae41_option__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(371);
/* harmony import */ var _hazae41_piscine__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(873);
/* harmony import */ var _hazae41_result__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(591);
var __addDisposableResource = undefined && undefined.__addDisposableResource || function(env, value, async) {
    if (value !== null && value !== void 0) {
        if (typeof value !== "object" && typeof value !== "function") throw new TypeError("Object expected.");
        var dispose;
        if (async) {
            if (!Symbol.asyncDispose) throw new TypeError("Symbol.asyncDispose is not defined.");
            dispose = value[Symbol.asyncDispose];
        }
        if (dispose === void 0) {
            if (!Symbol.dispose) throw new TypeError("Symbol.dispose is not defined.");
            dispose = value[Symbol.dispose];
        }
        if (typeof dispose !== "function") throw new TypeError("Object not disposable.");
        env.stack.push({
            value: value,
            dispose: dispose,
            async: async
        });
    } else if (async) {
        env.stack.push({
            async: true
        });
    }
    return value;
};
var __disposeResources = undefined && undefined.__disposeResources || function(SuppressedError1) {
    return function(env) {
        function fail(e) {
            env.error = env.hasError ? new SuppressedError1(e, env.error, "An error was suppressed during disposal.") : e;
            env.hasError = true;
        }
        function next() {
            while(env.stack.length){
                var rec = env.stack.pop();
                try {
                    var result = rec.dispose && rec.dispose.call(rec.value);
                    if (rec.async) return Promise.resolve(result).then(next, function(e) {
                        fail(e);
                        return next();
                    });
                } catch (e) {
                    fail(e);
                }
            }
            if (env.hasError) throw env.error;
        }
        return next();
    };
}(typeof SuppressedError === "function" ? SuppressedError : function(error, suppressed, message) {
    var e = new Error(message);
    return e.name = "SuppressedError", e.error = error, e.suppressed = suppressed, e;
});














async function main() {
    if (location.origin === new URL(_libs_browser_browser__WEBPACK_IMPORTED_MODULE_2__/* .browser */ .X.runtime.getURL("/")).origin) return;
    const mouse = {
        x: window.screen.width / 2,
        y: window.screen.height / 2
    };
    addEventListener("mousemove", (e)=>{
        mouse.x = e.screenX;
        mouse.y = e.screenY;
    }, {
        passive: true
    });
    if ((0,_libs_platform_platform__WEBPACK_IMPORTED_MODULE_5__/* .isFirefoxExtension */ .A$)() || (0,_libs_platform_platform__WEBPACK_IMPORTED_MODULE_5__/* .isSafariExtension */ .WB)()) {
        const container = document.documentElement;
        const scriptBody = atob("LyoqKioqKi8gKCgpID0+IHsgLy8gd2VicGFja0Jvb3RzdHJhcAovKioqKioqLyAJInVzZSBzdHJpY3QiOwp2YXIgX193ZWJwYWNrX2V4cG9ydHNfXyA9IHt9OwoKOy8vIENPTkNBVEVOQVRFRCBNT0RVTEU6IC4vbm9kZV9tb2R1bGVzL0BoYXphZTQxL3N5bWJvbC1kaXNwb3NlLXBvbHlmaWxsL2Rpc3QvZXNtL21vZHMvc3ltYm9sLWRpc3Bvc2UtcG9seWZpbGwvcG9seWZpbGwubWpzCmlmICh0eXBlb2YgU3ltYm9sLmRpc3Bvc2UgIT09ICJzeW1ib2wiKQogICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KFN5bWJvbCwgImRpc3Bvc2UiLCB7CiAgICAgICAgY29uZmlndXJhYmxlOiBmYWxzZSwKICAgICAgICBlbnVtZXJhYmxlOiBmYWxzZSwKICAgICAgICB3cml0YWJsZTogZmFsc2UsCiAgICAgICAgdmFsdWU6IFN5bWJvbC5mb3IoImRpc3Bvc2UiKQogICAgfSk7CmlmICh0eXBlb2YgU3ltYm9sLmFzeW5jRGlzcG9zZSAhPT0gInN5bWJvbCIpCiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoU3ltYm9sLCAiYXN5bmNEaXNwb3NlIiwgewogICAgICAgIGNvbmZpZ3VyYWJsZTogZmFsc2UsCiAgICAgICAgZW51bWVyYWJsZTogZmFsc2UsCiAgICAgICAgd3JpdGFibGU6IGZhbHNlLAogICAgICAgIHZhbHVlOiBTeW1ib2wuZm9yKCJhc3luY0Rpc3Bvc2UiKQogICAgfSk7Ci8vIyBzb3VyY2VNYXBwaW5nVVJMPXBvbHlmaWxsLm1qcy5tYXAKCjsvLyBDT05DQVRFTkFURUQgTU9EVUxFOiAuL25vZGVfbW9kdWxlcy9AaGF6YWU0MS9zeW1ib2wtZGlzcG9zZS1wb2x5ZmlsbC9kaXN0L2VzbS9pbmRleC5tanMKCi8vIyBzb3VyY2VNYXBwaW5nVVJMPWluZGV4Lm1qcy5tYXAKCjsvLyBDT05DQVRFTkFURUQgTU9EVUxFOiAuL25vZGVfbW9kdWxlcy9AaGF6YWU0MS9mdXR1cmUvZGlzdC9lc20vbW9kcy9mdXR1cmUvZnV0dXJlLm1qcwpjbGFzcyBGdXR1cmUgewogICAgI3Jlc29sdmU7CiAgICAjcmVqZWN0OwogICAgcHJvbWlzZTsKICAgIC8qKgogICAgICogSnVzdCBsaWtlIGEgUHJvbWlzZSBidXQgeW91IGNhbiBtYW51YWxseSByZXNvbHZlIG9yIHJlamVjdCBpdAogICAgICovCiAgICBjb25zdHJ1Y3RvcigpIHsKICAgICAgICB0aGlzLnByb21pc2UgPSBuZXcgUHJvbWlzZSgoc3VicmVzb2x2ZSwgc3VicmVqZWN0KSA9PiB7CiAgICAgICAgICAgIHRoaXMuI3Jlc29sdmUgPSBzdWJyZXNvbHZlOwogICAgICAgICAgICB0aGlzLiNyZWplY3QgPSBzdWJyZWplY3Q7CiAgICAgICAgfSk7CiAgICB9CiAgICBnZXQgcmVzb2x2ZSgpIHsKICAgICAgICByZXR1cm4gdGhpcy4jcmVzb2x2ZTsKICAgIH0KICAgIGdldCByZWplY3QoKSB7CiAgICAgICAgcmV0dXJuIHRoaXMuI3JlamVjdDsKICAgIH0KfQoKCi8vIyBzb3VyY2VNYXBwaW5nVVJMPWZ1dHVyZS5tanMubWFwCgo7Ly8gQ09OQ0FURU5BVEVEIE1PRFVMRTogLi9ub2RlX21vZHVsZXMvQGhhemFlNDEvb3B0aW9uL2Rpc3QvZXNtL21vZHMvb3B0aW9uL25vbmUubWpzCgoKY2xhc3MgTm9uZUVycm9yIGV4dGVuZHMgRXJyb3IgewogICAgY29uc3RydWN0b3IoKSB7CiAgICAgICAgc3VwZXIoYE9wdGlvbiBpcyBhIE5vbmVgKTsKICAgIH0KfQpjbGFzcyBOb25lIHsKICAgIGlubmVyOwogICAgLyoqCiAgICAgKiBBbiBlbXB0eSB2YWx1ZQogICAgICovCiAgICBjb25zdHJ1Y3Rvcihpbm5lciA9IHVuZGVmaW5lZCkgewogICAgICAgIHRoaXMuaW5uZXIgPSBpbm5lcjsKICAgIH0KICAgIC8qKgogICAgICogQ3JlYXRlIGEgYE5vbmVgCiAgICAgKiBAcmV0dXJucyBgTm9uZWAKICAgICAqLwogICAgc3RhdGljIG5ldygpIHsKICAgICAgICByZXR1cm4gbmV3IE5vbmUoKTsKICAgIH0KICAgIHN0YXRpYyBmcm9tKGluaXQpIHsKICAgICAgICByZXR1cm4gbmV3IE5vbmUoKTsKICAgIH0KICAgIC8qKgogICAgICogVHlwZSBndWFyZCBmb3IgYFNvbWVgCiAgICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYFNvbWVgLCBgZmFsc2VgIGlmIGBOb25lYAogICAgICovCiAgICBpc1NvbWUoKSB7CiAgICAgICAgcmV0dXJuIGZhbHNlOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGB0cnVlYCBpZiB0aGUgb3B0aW9uIGlzIGEgYFNvbWVgIGFuZCB0aGUgdmFsdWUgaW5zaWRlIG9mIGl0IG1hdGNoZXMgYSBwcmVkaWNhdGUKICAgICAqIEBwYXJhbSBzb21lUHJlZGljYXRlCiAgICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYFNvbWVgIGFuZCBgYXdhaXQgc29tZVByZWRpY2F0ZSh0aGlzLmlubmVyKWAsIGBOb25lYCBvdGhlcndpc2UKICAgICAqLwogICAgYXN5bmMgaXNTb21lQW5kKHNvbWVQcmVkaWNhdGUpIHsKICAgICAgICByZXR1cm4gZmFsc2U7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYHRydWVgIGlmIHRoZSBvcHRpb24gaXMgYSBgU29tZWAgYW5kIHRoZSB2YWx1ZSBpbnNpZGUgb2YgaXQgbWF0Y2hlcyBhIHByZWRpY2F0ZQogICAgICogQHBhcmFtIHNvbWVQcmVkaWNhdGUKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgU29tZWAgYW5kIGBzb21lUHJlZGljYXRlKHRoaXMuaW5uZXIpYCwgYE5vbmVgIG90aGVyd2lzZQogICAgICovCiAgICBpc1NvbWVBbmRTeW5jKHNvbWVQcmVkaWNhdGUpIHsKICAgICAgICByZXR1cm4gZmFsc2U7CiAgICB9CiAgICAvKioKICAgICAqIFR5cGUgZ3VhcmQgZm9yIGBOb25lYAogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBOb25lYCwgYGZhbHNlYCBpZiBgU29tZWAKICAgICAqLwogICAgaXNOb25lKCkgewogICAgICAgIHJldHVybiB0cnVlOwogICAgfQogICAgLyoqCiAgICAgKiBDb21waWxlLXRpbWUgc2FmZWx5IGdldCBgdGhpcy5pbm5lcmAKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYAogICAgICovCiAgICBnZXQoKSB7CiAgICAgICAgcmV0dXJuIHRoaXMuaW5uZXI7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYW4gaXRlcmF0b3Igb3ZlciB0aGUgcG9zc2libHkgY29udGFpbmVkIHZhbHVlCiAgICAgKiBAeWllbGRzIGB0aGlzLmlubmVyYCBpZiBgU29tZWAKICAgICAqLwogICAgKltTeW1ib2wuaXRlcmF0b3JdKCkgewogICAgICAgIHJldHVybjsKICAgIH0KICAgIC8qKgogICAgICogR2V0IHRoZSBpbm5lciB2YWx1ZSBpZiBgU29tZWAsIHRocm93IGBFcnJvcihtZXNzYWdlKWAgb3RoZXJ3aXNlCiAgICAgKiBAcGFyYW0gbWVzc2FnZQogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBTb21lYAogICAgICogQHRocm93cyBgRXJyb3IobWVzc2FnZSlgIGlmIGBOb25lYAogICAgICovCiAgICBleHBlY3QobWVzc2FnZSkgewogICAgICAgIHRocm93IG5ldyBFcnJvcihtZXNzYWdlKTsKICAgIH0KICAgIC8qKgogICAgICogR2V0IHRoZSBpbm5lciB2YWx1ZSBvciB0aHJvdyBhIE5vbmVFcnJvcgogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBTb21lYAogICAgICogQHRocm93cyBgTm9uZUVycm9yYCBpZiBgTm9uZWAKICAgICAqLwogICAgdW53cmFwKCkgewogICAgICAgIHRocm93IG5ldyBFcnJvcihgQSBOb25lIGhhcyBiZWVuIHVud3JhcHBlZGApOwogICAgfQogICAgLyoqCiAgICAgKiBHZXQgdGhlIGlubmVyIHZhbHVlIG9yIGEgZGVmYXVsdCBvbmUKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBTb21lYCwgYHZhbHVlYCBpZiBgTm9uZWAKICAgICAqLwogICAgdW53cmFwT3IodmFsdWUpIHsKICAgICAgICByZXR1cm4gdmFsdWU7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgdGhlIGNvbnRhaW5lZCBgU29tZWAgdmFsdWUgb3IgY29tcHV0ZXMgaXQgZnJvbSBhIGNsb3N1cmUKICAgICAqIEBwYXJhbSBub25lQ2FsbGJhY2sKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgU29tZWAsIGBhd2FpdCBub25lQ2FsbGJhY2soKWAgaWYgYE5vbmVgCiAgICAgKi8KICAgIGFzeW5jIHVud3JhcE9yRWxzZShub25lQ2FsbGJhY2spIHsKICAgICAgICByZXR1cm4gYXdhaXQgbm9uZUNhbGxiYWNrKCk7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgdGhlIGNvbnRhaW5lZCBgU29tZWAgdmFsdWUgb3IgY29tcHV0ZXMgaXQgZnJvbSBhIGNsb3N1cmUKICAgICAqIEBwYXJhbSBub25lQ2FsbGJhY2sKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgU29tZWAsIGBub25lQ2FsbGJhY2soKWAgaWYgYE5vbmVgCiAgICAgKi8KICAgIHVud3JhcE9yRWxzZVN5bmMobm9uZUNhbGxiYWNrKSB7CiAgICAgICAgcmV0dXJuIG5vbmVDYWxsYmFjaygpOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm0gYE9wdGlvbjxUPmAgaW50byBgUmVzdWx0PFQsIE5vbmVFcnJvcj5gCiAgICAgKiBAcmV0dXJucyBgT2sodGhpcy5pbm5lcilgIGlmIGBTb21lYCwgYEVycihOb25lRXJyb3IpYCBpZiBgTm9uZWAKICAgICAqLwogICAgb2soKSB7CiAgICAgICAgcmV0dXJuIG5ldyBFcnIobmV3IE5vbmVFcnJvcigpKTsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtIGBPcHRpb248VD5gIGludG8gYFJlc3VsdDxULCBFPmAKICAgICAqIEBwYXJhbSBlcnJvcgogICAgICogQHJldHVybnMgYE9rKHRoaXMuaW5uZXIpYCBpZiBgU29tZWAsIGBFcnIoZXJyb3IpYCBpZiBgTm9uZWAKICAgICAqLwogICAgb2tPcihlcnJvcikgewogICAgICAgIHJldHVybiBuZXcgRXJyKGVycm9yKTsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtcyB0aGUgYE9wdGlvbjxUPmAgaW50byBhIGBSZXN1bHQ8VCwgRT5gLCBtYXBwaW5nIGBTb21lKHYpYCB0byBgT2sodilgIGFuZCBgTm9uZWAgdG8gYEVycihlcnIoKSlgCiAgICAgKiBAcGFyYW0gbm9uZUNhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgT2sodGhpcy5pbm5lcilgIGlmIGBTb21lYCwgYEVycihhd2FpdCBub25lQ2FsbGJhY2soKSlgIGlzIGBOb25lYAogICAgICovCiAgICBhc3luYyBva09yRWxzZShub25lQ2FsbGJhY2spIHsKICAgICAgICByZXR1cm4gbmV3IEVycihhd2FpdCBub25lQ2FsbGJhY2soKSk7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybXMgdGhlIGBPcHRpb248VD5gIGludG8gYSBgUmVzdWx0PFQsIEU+YCwgbWFwcGluZyBgU29tZSh2KWAgdG8gYE9rKHYpYCBhbmQgYE5vbmVgIHRvIGBFcnIoZXJyKCkpYAogICAgICogQHBhcmFtIG5vbmVDYWxsYmFjawogICAgICogQHJldHVybnMgYE9rKHRoaXMuaW5uZXIpYCBpZiBgU29tZWAsIGBFcnIobm9uZUNhbGxiYWNrKCkpYCBpcyBgTm9uZWAKICAgICAqLwogICAgb2tPckVsc2VTeW5jKG5vbmVDYWxsYmFjaykgewogICAgICAgIHJldHVybiBuZXcgRXJyKG5vbmVDYWxsYmFjaygpKTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBgTm9uZWAgaWYgdGhlIG9wdGlvbiBpcyBgTm9uZWAsIG90aGVyd2lzZSBjYWxscyBgc29tZVByZWRpY2F0ZWAgd2l0aCB0aGUgd3JhcHBlZCB2YWx1ZQogICAgICogQHBhcmFtIHNvbWVQcmVkaWNhdGUKICAgICAqIEByZXR1cm5zIGBTb21lYCBpZiBgU29tZWAgYW5kIGBhd2FpdCBzb21lUHJlZGljYXRlKHRoaXMuaW5uZXIpYCwgYE5vbmVgIG90aGVyd2lzZQogICAgICovCiAgICBhc3luYyBmaWx0ZXIoc29tZVByZWRpY2F0ZSkgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGBOb25lYCBpZiB0aGUgb3B0aW9uIGlzIGBOb25lYCwgb3RoZXJ3aXNlIGNhbGxzIGBzb21lUHJlZGljYXRlYCB3aXRoIHRoZSB3cmFwcGVkIHZhbHVlCiAgICAgKiBAcGFyYW0gc29tZVByZWRpY2F0ZQogICAgICogQHJldHVybnMgYFNvbWVgIGlmIGBTb21lYCBhbmQgYHNvbWVQcmVkaWNhdGUodGhpcy5pbm5lcilgLCBgTm9uZWAgb3RoZXJ3aXNlCiAgICAgKi8KICAgIGZpbHRlclN5bmMoc29tZVByZWRpY2F0ZSkgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm0gYE9wdGlvbjxQcm9taXNlPFQ+PmAgaW50byBgUHJvbWlzZTxPcHRpb248VD4+YAogICAgICogQHJldHVybnMgYFByb21pc2U8T3B0aW9uPFQ+PmAKICAgICAqLwogICAgYXN5bmMgYXdhaXQoKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYHRydWVgIGlmIHRoZSBvcHRpb24gaXMgYSBgU29tZWAgdmFsdWUgY29udGFpbmluZyB0aGUgZ2l2ZW4gdmFsdWUKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBTb21lYCBhbmQgYHRoaXMuaW5uZXIgPT09IHZhbHVlYCwgYE5vbmVgIG90aGVyd2lzZQogICAgICovCiAgICBjb250YWlucyh2YWx1ZSkgewogICAgICAgIHJldHVybiBmYWxzZTsKICAgIH0KICAgIC8qKgogICAgICogQ2FsbHMgdGhlIGdpdmVuIGNhbGxiYWNrIHdpdGggdGhlIGlubmVyIHZhbHVlIGlmIGBPa2AKICAgICAqIEBwYXJhbSBzb21lQ2FsbGJhY2sKICAgICAqIEByZXR1cm5zIGB0aGlzYAogICAgICovCiAgICBhc3luYyBpbnNwZWN0KHNvbWVDYWxsYmFjaykgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBDYWxscyB0aGUgZ2l2ZW4gY2FsbGJhY2sgd2l0aCB0aGUgaW5uZXIgdmFsdWUgaWYgYE9rYAogICAgICogQHBhcmFtIHNvbWVDYWxsYmFjawogICAgICogQHJldHVybnMgYHRoaXNgCiAgICAgKi8KICAgIGluc3BlY3RTeW5jKHNvbWVDYWxsYmFjaykgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBNYXBzIGFuIGBPcHRpb248VD5gIHRvIGBPcHRpb248VT5gIGJ5IGFwcGx5aW5nIGEgZnVuY3Rpb24gdG8gYSBjb250YWluZWQgdmFsdWUgKGlmIGBTb21lYCkgb3IgcmV0dXJucyBgTm9uZWAgKGlmIGBOb25lYCkKICAgICAqIEBwYXJhbSBzb21lTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgU29tZShhd2FpdCBzb21lTWFwcGVyKHRoaXMuaW5uZXIpKWAgaWYgYFNvbWVgLCBgdGhpc2AgaWYgYE5vbmVgCiAgICAgKi8KICAgIGFzeW5jIG1hcChzb21lTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIE1hcHMgYW4gYE9wdGlvbjxUPmAgdG8gYE9wdGlvbjxVPmAgYnkgYXBwbHlpbmcgYSBmdW5jdGlvbiB0byBhIGNvbnRhaW5lZCB2YWx1ZSAoaWYgYFNvbWVgKSBvciByZXR1cm5zIGBOb25lYCAoaWYgYE5vbmVgKQogICAgICogQHBhcmFtIHNvbWVNYXBwZXIKICAgICAqIEByZXR1cm5zIGBTb21lKHNvbWVNYXBwZXIodGhpcy5pbm5lcikpYCBpZiBgU29tZWAsIGB0aGlzYCBpZiBgTm9uZWAKICAgICAqLwogICAgbWFwU3luYyhzb21lTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgdGhlIHByb3ZpZGVkIGRlZmF1bHQgcmVzdWx0IChpZiBub25lKSwgb3IgYXBwbGllcyBhIGZ1bmN0aW9uIHRvIHRoZSBjb250YWluZWQgdmFsdWUgKGlmIGFueSkKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHBhcmFtIHNvbWVNYXBwZXIKICAgICAqIEByZXR1cm5zIGB2YWx1ZWAgaWYgYE5vbmVgLCBgYXdhaXQgc29tZU1hcHBlcih0aGlzLmlubmVyKWAgaWYgYFNvbWVgCiAgICAgKi8KICAgIGFzeW5jIG1hcE9yKHZhbHVlLCBzb21lTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIHZhbHVlOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIHRoZSBwcm92aWRlZCBkZWZhdWx0IHJlc3VsdCAoaWYgbm9uZSksIG9yIGFwcGxpZXMgYSBmdW5jdGlvbiB0byB0aGUgY29udGFpbmVkIHZhbHVlIChpZiBhbnkpCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEBwYXJhbSBzb21lTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgdmFsdWVgIGlmIGBOb25lYCwgYHNvbWVNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBTb21lYAogICAgICovCiAgICBtYXBPclN5bmModmFsdWUsIHNvbWVNYXBwZXIpIHsKICAgICAgICByZXR1cm4gdmFsdWU7CiAgICB9CiAgICAvKioKICAgICAqIENvbXB1dGVzIGEgZGVmYXVsdCBmdW5jdGlvbiByZXN1bHQgKGlmIG5vbmUpLCBvciBhcHBsaWVzIGEgZGlmZmVyZW50IGZ1bmN0aW9uIHRvIHRoZSBjb250YWluZWQgdmFsdWUgKGlmIGFueSkKICAgICAqIEBwYXJhbSBub25lQ2FsbGJhY2sKICAgICAqIEBwYXJhbSBzb21lTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgYXdhaXQgc29tZU1hcHBlcih0aGlzLmlubmVyKWAgaWYgYFNvbWVgLCBgYXdhaXQgbm9uZUNhbGxiYWNrKClgIGlmIGBOb25lYAogICAgICovCiAgICBhc3luYyBtYXBPckVsc2Uobm9uZUNhbGxiYWNrLCBzb21lTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIGF3YWl0IG5vbmVDYWxsYmFjaygpOwogICAgfQogICAgLyoqCiAgICAgKiBDb21wdXRlcyBhIGRlZmF1bHQgZnVuY3Rpb24gcmVzdWx0IChpZiBub25lKSwgb3IgYXBwbGllcyBhIGRpZmZlcmVudCBmdW5jdGlvbiB0byB0aGUgY29udGFpbmVkIHZhbHVlIChpZiBhbnkpCiAgICAgKiBAcGFyYW0gbm9uZUNhbGxiYWNrCiAgICAgKiBAcGFyYW0gc29tZU1hcHBlcgogICAgICogQHJldHVybnMgYHNvbWVNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBTb21lYCwgYG5vbmVDYWxsYmFjaygpYCBpZiBgTm9uZWAKICAgICAqLwogICAgbWFwT3JFbHNlU3luYyhub25lQ2FsbGJhY2ssIHNvbWVNYXBwZXIpIHsKICAgICAgICByZXR1cm4gbm9uZUNhbGxiYWNrKCk7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYE5vbmVgIGlmIHRoZSBvcHRpb24gaXMgYE5vbmVgLCBvdGhlcndpc2UgcmV0dXJucyBgdmFsdWVgCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEByZXR1cm5zIGBOb25lYCBpZiBgTm9uZWAsIGB2YWx1ZWAgaWYgYFNvbWVgCiAgICAgKi8KICAgIGFuZCh2YWx1ZSkgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGBOb25lYCBpZiB0aGUgb3B0aW9uIGlzIGBOb25lYCwgb3RoZXJ3aXNlIGNhbGxzIGBzb21lTWFwcGVyYCB3aXRoIHRoZSB3cmFwcGVkIHZhbHVlIGFuZCByZXR1cm5zIHRoZSByZXN1bHQKICAgICAqIEBwYXJhbSBzb21lTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgTm9uZWAgaWYgYE5vbmVgLCBgYXdhaXQgc29tZU1hcHBlcih0aGlzLmlubmVyKWAgaWYgYFNvbWVgCiAgICAgKi8KICAgIGFzeW5jIGFuZFRoZW4oc29tZU1hcHBlcikgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGBOb25lYCBpZiB0aGUgb3B0aW9uIGlzIGBOb25lYCwgb3RoZXJ3aXNlIGNhbGxzIGBzb21lTWFwcGVyYCB3aXRoIHRoZSB3cmFwcGVkIHZhbHVlIGFuZCByZXR1cm5zIHRoZSByZXN1bHQKICAgICAqIEBwYXJhbSBzb21lTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgTm9uZWAgaWYgYE5vbmVgLCBgc29tZU1hcHBlcih0aGlzLmlubmVyKWAgaWYgYFNvbWVgCiAgICAgKi8KICAgIGFuZFRoZW5TeW5jKHNvbWVNYXBwZXIpIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBgdGhpc2AgaWYgYFNvbWVgLCBvdGhlcndpc2UgcmV0dXJucyBgdmFsdWVgCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEByZXR1cm5zIGB0aGlzYCBpZiBgU29tZWAsIGB2YWx1ZWAgaWYgYE5vbmVgCiAgICAgKi8KICAgIG9yKHZhbHVlKSB7CiAgICAgICAgcmV0dXJuIHZhbHVlOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGB0aGlzYCBpZiBgU29tZWAsIG90aGVyd2lzZSBjYWxscyBgbm9uZUNhbGxiYWNrYCBhbmQgcmV0dXJucyB0aGUgcmVzdWx0CiAgICAgKiBAcGFyYW0gbm9uZUNhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgdGhpc2AgaWYgYFNvbWVgLCBgYXdhaXQgbm9uZUNhbGxiYWNrKClgIGlmIGBOb25lYAogICAgICovCiAgICBhc3luYyBvckVsc2Uobm9uZUNhbGxiYWNrKSB7CiAgICAgICAgcmV0dXJuIGF3YWl0IG5vbmVDYWxsYmFjaygpOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGB0aGlzYCBpZiBgU29tZWAsIG90aGVyd2lzZSBjYWxscyBgbm9uZUNhbGxiYWNrYCBhbmQgcmV0dXJucyB0aGUgcmVzdWx0CiAgICAgKiBAcGFyYW0gbm9uZUNhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgdGhpc2AgaWYgYFNvbWVgLCBgbm9uZUNhbGxiYWNrKClgIGlmIGBOb25lYAogICAgICovCiAgICBvckVsc2VTeW5jKG5vbmVDYWxsYmFjaykgewogICAgICAgIHJldHVybiBub25lQ2FsbGJhY2soKTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBgU29tZWAgaWYgZXhhY3RseSBvbmUgb2YgdGhlIG9wdGlvbnMgaXMgYFNvbWVgLCBvdGhlcndpc2UgcmV0dXJucyBgTm9uZWAKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHJldHVybnMgYE5vbmVgIGlmIGJvdGggYXJlIGBTb21lYCBvciBib3RoIGFyZSBgTm9uZWAsIHRoZSBvbmx5IGBTb21lYCBvdGhlcndpc2UKICAgICAqLwogICAgeG9yKHZhbHVlKSB7CiAgICAgICAgcmV0dXJuIHZhbHVlOwogICAgfQogICAgLyoqCiAgICAgKiBaaXBzIGB0aGlzYCB3aXRoIGFub3RoZXIgYE9wdGlvbmAKICAgICAqIEBwYXJhbSBvdGhlcgogICAgICogQHJldHVybnMgYFNvbWUoW3RoaXMuaW5uZXIsIG90aGVyLmlubmVyXSlgIGlmIGJvdGggYXJlIGBTb21lYCwgYE5vbmVgIGlmIG9uZSBvZiB0aGVtIGlzIGBOb25lYAogICAgICovCiAgICB6aXAob3RoZXIpIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KfQoKCi8vIyBzb3VyY2VNYXBwaW5nVVJMPW5vbmUubWpzLm1hcAoKOy8vIENPTkNBVEVOQVRFRCBNT0RVTEU6IC4vbm9kZV9tb2R1bGVzL0BoYXphZTQxL3Jlc3VsdC9kaXN0L2VzbS9tb2RzL3Jlc3VsdC9lcnJvcnMubWpzCmNsYXNzIFBhbmljIGV4dGVuZHMgRXJyb3IgewogICAgI2NsYXNzID0gUGFuaWM7CiAgICBuYW1lID0gdGhpcy4jY2xhc3MubmFtZTsKfQpjbGFzcyBDYXRjaGVkIGV4dGVuZHMgRXJyb3IgewogICAgI2NsYXNzID0gQ2F0Y2hlZDsKICAgIG5hbWUgPSB0aGlzLiNjbGFzcy5uYW1lOwogICAgc3RhdGljIHdyYXAoY2F1c2UpIHsKICAgICAgICBpZiAoY2F1c2UgaW5zdGFuY2VvZiBFcnJvcikKICAgICAgICAgICAgcmV0dXJuIGNhdXNlOwogICAgICAgIHJldHVybiBuZXcgQ2F0Y2hlZCh1bmRlZmluZWQsIHsgY2F1c2UgfSk7CiAgICB9Cn0KCgovLyMgc291cmNlTWFwcGluZ1VSTD1lcnJvcnMubWpzLm1hcAoKOy8vIENPTkNBVEVOQVRFRCBNT0RVTEU6IC4vbm9kZV9tb2R1bGVzL0BoYXphZTQxL29wdGlvbi9kaXN0L2VzbS9tb2RzL29wdGlvbi9vcHRpb24ubWpzCgoKCnZhciBPcHRpb247CihmdW5jdGlvbiAoT3B0aW9uKSB7CiAgICBmdW5jdGlvbiBmcm9tKGluaXQpIHsKICAgICAgICBpZiAoImlubmVyIiBpbiBpbml0KQogICAgICAgICAgICByZXR1cm4gbmV3IFNvbWUoaW5pdC5pbm5lcik7CiAgICAgICAgcmV0dXJuIG5ldyBOb25lKCk7CiAgICB9CiAgICBPcHRpb24uZnJvbSA9IGZyb207CiAgICAvKioKICAgICAqIENyZWF0ZSBhbiBPcHRpb24gZnJvbSBhIG51bGxhYmxlIHZhbHVlCiAgICAgKiBAcGFyYW0gaW5uZXIKICAgICAqIEByZXR1cm5zIGBTb21lPFQ+YCBpZiBgVGAsIGBOb25lYCBpZiBgdW5kZWZpbmVkYAogICAgICovCiAgICBmdW5jdGlvbiB3cmFwKGlubmVyKSB7CiAgICAgICAgaWYgKGlubmVyID09IG51bGwpCiAgICAgICAgICAgIHJldHVybiBuZXcgTm9uZSgpOwogICAgICAgIHJldHVybiBuZXcgU29tZShpbm5lcik7CiAgICB9CiAgICBPcHRpb24ud3JhcCA9IHdyYXA7CiAgICBhc3luYyBmdW5jdGlvbiBtYXAoaW5uZXIsIG1hcHBlcikgewogICAgICAgIHJldHVybiBPcHRpb24ud3JhcChpbm5lcikubWFwKG1hcHBlcikudGhlbihvID0+IG8uZ2V0KCkpOwogICAgfQogICAgT3B0aW9uLm1hcCA9IG1hcDsKICAgIGZ1bmN0aW9uIG1hcFN5bmMoaW5uZXIsIG1hcHBlcikgewogICAgICAgIHJldHVybiBPcHRpb24ud3JhcChpbm5lcikubWFwU3luYyhtYXBwZXIpLmdldCgpOwogICAgfQogICAgT3B0aW9uLm1hcFN5bmMgPSBtYXBTeW5jOwogICAgZnVuY3Rpb24gdW53cmFwKGlubmVyKSB7CiAgICAgICAgcmV0dXJuIE9wdGlvbi53cmFwKGlubmVyKS51bndyYXAoKTsKICAgIH0KICAgIE9wdGlvbi51bndyYXAgPSB1bndyYXA7Cn0pKE9wdGlvbiB8fCAoT3B0aW9uID0ge30pKTsKCgovLyMgc291cmNlTWFwcGluZ1VSTD1vcHRpb24ubWpzLm1hcAoKOy8vIENPTkNBVEVOQVRFRCBNT0RVTEU6IC4vbm9kZV9tb2R1bGVzL0BoYXphZTQxL3Jlc3VsdC9kaXN0L2VzbS9tb2RzL3Jlc3VsdC9yZXN1bHQubWpzCgoKCgoKdmFyIFJlc3VsdDsKKGZ1bmN0aW9uIChSZXN1bHQpIHsKICAgIFJlc3VsdC5kZWJ1ZyA9IGZhbHNlOwogICAgLyoqCiAgICAgKiBDcmVhdGUgYSBSZXN1bHQgZnJvbSBhIG1heWJlIEVycm9yIHZhbHVlCiAgICAgKiBAcGFyYW0gaW5uZXIKICAgICAqIEByZXR1cm5zIGBPazxUPmAgaWYgYFRgLCBgRXJyPEVycm9yPmAgaWYgYEVycm9yYAogICAgICovCiAgICBmdW5jdGlvbiBmcm9tKGlubmVyKSB7CiAgICAgICAgaWYgKGlubmVyIGluc3RhbmNlb2YgRXJyb3IpCiAgICAgICAgICAgIHJldHVybiBuZXcgRXJyKGlubmVyKTsKICAgICAgICBlbHNlCiAgICAgICAgICAgIHJldHVybiBuZXcgT2soaW5uZXIpOwogICAgfQogICAgUmVzdWx0LmZyb20gPSBmcm9tOwogICAgLyoqCiAgICAgKiBDcmVhdGUgYSBSZXN1bHQgZnJvbSBhIGJvb2xlYW4KICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHJldHVybnMKICAgICAqLwogICAgZnVuY3Rpb24gYXNzZXJ0KHZhbHVlKSB7CiAgICAgICAgcmV0dXJuIHZhbHVlID8gT2sudm9pZCgpIDogRXJyLnZvaWQoKTsKICAgIH0KICAgIFJlc3VsdC5hc3NlcnQgPSBhc3NlcnQ7CiAgICBmdW5jdGlvbiByZXdyYXAod3JhcHBlcikgewogICAgICAgIHRyeSB7CiAgICAgICAgICAgIHJldHVybiBuZXcgT2sod3JhcHBlci51bndyYXAoKSk7CiAgICAgICAgfQogICAgICAgIGNhdGNoIChlcnJvcikgewogICAgICAgICAgICByZXR1cm4gbmV3IEVycihlcnJvcik7CiAgICAgICAgfQogICAgfQogICAgUmVzdWx0LnJld3JhcCA9IHJld3JhcDsKICAgIC8qKgogICAgICogQ2F0Y2ggYW4gRXJyIHRocm93biBmcm9tIEVyci50aHJvdwogICAgICogQHBhcmFtIGNhbGxiYWNrCiAgICAgKiBAcGFyYW0gdHlwZQogICAgICogQHJldHVybnMgYE9rPFQ+YCBpZiBubyBgRXJyYCB3YXMgdGhyb3duLCBgRXJyPEU+YCBvdGhlcndpc2UKICAgICAqIEBzZWUgRXJyLnRocm93CiAgICAgKi8KICAgIGFzeW5jIGZ1bmN0aW9uIHVudGhyb3coY2FsbGJhY2spIHsKICAgICAgICBsZXQgcmVmOwogICAgICAgIHRyeSB7CiAgICAgICAgICAgIHJldHVybiBhd2FpdCBjYWxsYmFjaygoZSkgPT4gcmVmID0gZSk7CiAgICAgICAgfQogICAgICAgIGNhdGNoIChlKSB7CiAgICAgICAgICAgIGlmIChyZWYgIT09IHVuZGVmaW5lZCkKICAgICAgICAgICAgICAgIHJldHVybiByZWY7CiAgICAgICAgICAgIHRocm93IGU7CiAgICAgICAgfQogICAgfQogICAgUmVzdWx0LnVudGhyb3cgPSB1bnRocm93OwogICAgLyoqCiAgICAgKiBDYXRjaCBhbiBFcnIgdGhyb3duIGZyb20gRXJyLnRocm93CiAgICAgKiBAcGFyYW0gY2FsbGJhY2sKICAgICAqIEBwYXJhbSB0eXBlCiAgICAgKiBAcmV0dXJucyBgT2s8VD5gIGlmIG5vIGBFcnJgIHdhcyB0aHJvd24sIGBFcnI8RT5gIG90aGVyd2lzZQogICAgICogQHNlZSBFcnIudGhyb3cKICAgICAqLwogICAgZnVuY3Rpb24gdW50aHJvd1N5bmMoY2FsbGJhY2spIHsKICAgICAgICBsZXQgcmVmOwogICAgICAgIHRyeSB7CiAgICAgICAgICAgIHJldHVybiBjYWxsYmFjaygoZSkgPT4gcmVmID0gZSk7CiAgICAgICAgfQogICAgICAgIGNhdGNoIChlKSB7CiAgICAgICAgICAgIGlmIChyZWYgIT09IHVuZGVmaW5lZCkKICAgICAgICAgICAgICAgIHJldHVybiByZWY7CiAgICAgICAgICAgIHRocm93IGU7CiAgICAgICAgfQogICAgfQogICAgUmVzdWx0LnVudGhyb3dTeW5jID0gdW50aHJvd1N5bmM7CiAgICAvKioKICAgICAqIFJ1biBhIGNhbGxiYWNrIGFuZCB3cmFwIGFueSByZXR1cm5lZCB2YWx1ZSBpbiBPazxUPiBhbmQgYW55IHRocm93biBlcnJvciBpbiBFcnI8dW5rbm93bj4KICAgICAqIEBwYXJhbSBjYWxsYmFjawogICAgICogQHJldHVybnMKICAgICAqLwogICAgYXN5bmMgZnVuY3Rpb24gcnVuQW5kV3JhcChjYWxsYmFjaykgewogICAgICAgIHRyeSB7CiAgICAgICAgICAgIHJldHVybiBuZXcgT2soYXdhaXQgY2FsbGJhY2soKSk7CiAgICAgICAgfQogICAgICAgIGNhdGNoIChlKSB7CiAgICAgICAgICAgIHJldHVybiBuZXcgRXJyKGUpOwogICAgICAgIH0KICAgIH0KICAgIFJlc3VsdC5ydW5BbmRXcmFwID0gcnVuQW5kV3JhcDsKICAgIC8qKgogICAgICogUnVuIGEgY2FsbGJhY2sgYW5kIHdyYXAgYW55IHJldHVybmVkIHZhbHVlIGluIE9rPFQ+IGFuZCBhbnkgdGhyb3duIGVycm9yIGluIEVycjx1bmtub3duPgogICAgICogQHBhcmFtIGNhbGxiYWNrCiAgICAgKiBAcmV0dXJucwogICAgICovCiAgICBmdW5jdGlvbiBydW5BbmRXcmFwU3luYyhjYWxsYmFjaykgewogICAgICAgIHRyeSB7CiAgICAgICAgICAgIHJldHVybiBuZXcgT2soY2FsbGJhY2soKSk7CiAgICAgICAgfQogICAgICAgIGNhdGNoIChlKSB7CiAgICAgICAgICAgIHJldHVybiBuZXcgRXJyKGUpOwogICAgICAgIH0KICAgIH0KICAgIFJlc3VsdC5ydW5BbmRXcmFwU3luYyA9IHJ1bkFuZFdyYXBTeW5jOwogICAgLyoqCiAgICAgKiBSdW4gYSBjYWxsYmFjayBhbmQgd3JhcCBhbnkgcmV0dXJuZWQgdmFsdWUgaW4gT2s8VD4gYW5kIGFueSB0aHJvd24gZXJyb3IgaW4gRXJyPENhdGNoZWQ+CiAgICAgKiBAcGFyYW0gY2FsbGJhY2sKICAgICAqIEByZXR1cm5zCiAgICAgKi8KICAgIGFzeW5jIGZ1bmN0aW9uIHJ1bkFuZERvdWJsZVdyYXAoY2FsbGJhY2spIHsKICAgICAgICB0cnkgewogICAgICAgICAgICByZXR1cm4gbmV3IE9rKGF3YWl0IGNhbGxiYWNrKCkpOwogICAgICAgIH0KICAgICAgICBjYXRjaCAoZSkgewogICAgICAgICAgICByZXR1cm4gbmV3IEVycihDYXRjaGVkLndyYXAoZSkpOwogICAgICAgIH0KICAgIH0KICAgIFJlc3VsdC5ydW5BbmREb3VibGVXcmFwID0gcnVuQW5kRG91YmxlV3JhcDsKICAgIC8qKgogICAgICogUnVuIGEgY2FsbGJhY2sgYW5kIHdyYXAgYW55IHJldHVybmVkIHZhbHVlIGluIE9rPFQ+IGFuZCBhbnkgdGhyb3duIGVycm9yIGluIEVycjxDYXRjaGVkPgogICAgICogQHBhcmFtIGNhbGxiYWNrCiAgICAgKiBAcmV0dXJucwogICAgICovCiAgICBmdW5jdGlvbiBydW5BbmREb3VibGVXcmFwU3luYyhjYWxsYmFjaykgewogICAgICAgIHRyeSB7CiAgICAgICAgICAgIHJldHVybiBuZXcgT2soY2FsbGJhY2soKSk7CiAgICAgICAgfQogICAgICAgIGNhdGNoIChlKSB7CiAgICAgICAgICAgIHJldHVybiBuZXcgRXJyKENhdGNoZWQud3JhcChlKSk7CiAgICAgICAgfQogICAgfQogICAgUmVzdWx0LnJ1bkFuZERvdWJsZVdyYXBTeW5jID0gcnVuQW5kRG91YmxlV3JhcFN5bmM7CiAgICAvKioKICAgICAqIFJ1biBhIGNhbGxiYWNrIGFuZCB3cmFwIGFueSB0aHJvd24gZXJyb3IgaW4gRXJyPHVua25vd24+CiAgICAgKiBAcGFyYW0gY2FsbGJhY2sKICAgICAqIEByZXR1cm5zCiAgICAgKi8KICAgIGFzeW5jIGZ1bmN0aW9uIHJ1bk9yV3JhcChjYWxsYmFjaykgewogICAgICAgIHRyeSB7CiAgICAgICAgICAgIHJldHVybiBhd2FpdCBjYWxsYmFjaygpOwogICAgICAgIH0KICAgICAgICBjYXRjaCAoZSkgewogICAgICAgICAgICByZXR1cm4gbmV3IEVycihlKTsKICAgICAgICB9CiAgICB9CiAgICBSZXN1bHQucnVuT3JXcmFwID0gcnVuT3JXcmFwOwogICAgLyoqCiAgICAgKiBSdW4gYSBjYWxsYmFjayBhbmQgd3JhcCBhbnkgdGhyb3duIGVycm9yIGluIEVycjx1bmtub3duPgogICAgICogQHBhcmFtIGNhbGxiYWNrCiAgICAgKiBAcmV0dXJucwogICAgICovCiAgICBmdW5jdGlvbiBydW5PcldyYXBTeW5jKGNhbGxiYWNrKSB7CiAgICAgICAgdHJ5IHsKICAgICAgICAgICAgcmV0dXJuIGNhbGxiYWNrKCk7CiAgICAgICAgfQogICAgICAgIGNhdGNoIChlKSB7CiAgICAgICAgICAgIHJldHVybiBuZXcgRXJyKGUpOwogICAgICAgIH0KICAgIH0KICAgIFJlc3VsdC5ydW5PcldyYXBTeW5jID0gcnVuT3JXcmFwU3luYzsKICAgIC8qKgogICAgICogUnVuIGEgY2FsbGJhY2sgYW5kIHdyYXAgYW55IHRocm93biBlcnJvciBpbiBFcnI8dW5rbm93bj4KICAgICAqIEBwYXJhbSBjYWxsYmFjawogICAgICogQHJldHVybnMKICAgICAqLwogICAgYXN5bmMgZnVuY3Rpb24gcnVuT3JEb3VibGVXcmFwKGNhbGxiYWNrKSB7CiAgICAgICAgdHJ5IHsKICAgICAgICAgICAgcmV0dXJuIGF3YWl0IGNhbGxiYWNrKCk7CiAgICAgICAgfQogICAgICAgIGNhdGNoIChlKSB7CiAgICAgICAgICAgIHJldHVybiBuZXcgRXJyKENhdGNoZWQud3JhcChlKSk7CiAgICAgICAgfQogICAgfQogICAgUmVzdWx0LnJ1bk9yRG91YmxlV3JhcCA9IHJ1bk9yRG91YmxlV3JhcDsKICAgIC8qKgogICAgICogUnVuIGEgY2FsbGJhY2sgYW5kIHdyYXAgYW55IHRocm93biBlcnJvciBpbiBFcnI8dW5rbm93bj4KICAgICAqIEBwYXJhbSBjYWxsYmFjawogICAgICogQHJldHVybnMKICAgICAqLwogICAgZnVuY3Rpb24gcnVuT3JEb3VibGVXcmFwU3luYyhjYWxsYmFjaykgewogICAgICAgIHRyeSB7CiAgICAgICAgICAgIHJldHVybiBjYWxsYmFjaygpOwogICAgICAgIH0KICAgICAgICBjYXRjaCAoZSkgewogICAgICAgICAgICByZXR1cm4gbmV3IEVycihDYXRjaGVkLndyYXAoZSkpOwogICAgICAgIH0KICAgIH0KICAgIFJlc3VsdC5ydW5PckRvdWJsZVdyYXBTeW5jID0gcnVuT3JEb3VibGVXcmFwU3luYzsKICAgIC8qKgogICAgICogVHJhbnNmb3JtIGBJdGVyYWJsZTxSZXN1bHQ8VCxFPmAgaW50byBgUmVzdWx0PEFycmF5PFQ+LCBFPmAKICAgICAqIEBwYXJhbSBpdGVyYWJsZQogICAgICogQHJldHVybnMgYFJlc3VsdDxBcnJheTxUPiwgRT5gCiAgICAgKi8KICAgIGZ1bmN0aW9uIGFsbChpdGVyYWJsZSkgewogICAgICAgIHJldHVybiBjb2xsZWN0KGl0ZXJhdGUoaXRlcmFibGUpKTsKICAgIH0KICAgIFJlc3VsdC5hbGwgPSBhbGw7CiAgICBmdW5jdGlvbiBtYXliZUFsbChpdGVyYWJsZSkgewogICAgICAgIHJldHVybiBtYXliZUNvbGxlY3QobWF5YmVJdGVyYXRlKGl0ZXJhYmxlKSk7CiAgICB9CiAgICBSZXN1bHQubWF5YmVBbGwgPSBtYXliZUFsbDsKICAgIC8qKgogICAgICogVHJhbnNmb3JtIGBJdGVyYWJsZTxSZXN1bHQ8VCxFPmAgaW50byBgSXRlcmF0b3I8VCwgUmVzdWx0PHZvaWQsIEU+PmAKICAgICAqIEBwYXJhbSBpdGVyYWJsZQogICAgICogQHJldHVybnMgYEl0ZXJhdG9yPFQsIFJlc3VsdDx2b2lkLCBFPj5gCiAgICAgKi8KICAgIGZ1bmN0aW9uKiBpdGVyYXRlKGl0ZXJhYmxlKSB7CiAgICAgICAgZm9yIChjb25zdCByZXN1bHQgb2YgaXRlcmFibGUpIHsKICAgICAgICAgICAgaWYgKHJlc3VsdC5pc09rKCkpCiAgICAgICAgICAgICAgICB5aWVsZCByZXN1bHQuZ2V0KCk7CiAgICAgICAgICAgIGVsc2UKICAgICAgICAgICAgICAgIHJldHVybiByZXN1bHQ7CiAgICAgICAgfQogICAgICAgIHJldHVybiBPay52b2lkKCk7CiAgICB9CiAgICBSZXN1bHQuaXRlcmF0ZSA9IGl0ZXJhdGU7CiAgICBmdW5jdGlvbiogbWF5YmVJdGVyYXRlKGl0ZXJhYmxlKSB7CiAgICAgICAgZm9yIChjb25zdCByZXN1bHQgb2YgaXRlcmFibGUpIHsKICAgICAgICAgICAgaWYgKHJlc3VsdCA9PSBudWxsKQogICAgICAgICAgICAgICAgcmV0dXJuIHJlc3VsdDsKICAgICAgICAgICAgZWxzZSBpZiAocmVzdWx0LmlzT2soKSkKICAgICAgICAgICAgICAgIHlpZWxkIHJlc3VsdC5nZXQoKTsKICAgICAgICAgICAgZWxzZQogICAgICAgICAgICAgICAgcmV0dXJuIHJlc3VsdDsKICAgICAgICB9CiAgICAgICAgcmV0dXJuIE9rLnZvaWQoKTsKICAgIH0KICAgIFJlc3VsdC5tYXliZUl0ZXJhdGUgPSBtYXliZUl0ZXJhdGU7CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBgSXRlcmF0b3I8VCwgUmVzdWx0PHZvaWQsIEU+PmAgaW50byBgUmVzdWx0PEFycmF5PFQ+LCBFPmAKICAgICAqIEBwYXJhbSBpdGVyYXRvciBgUmVzdWx0PEFycmF5PFQ+LCBFPmAKICAgICAqLwogICAgZnVuY3Rpb24gY29sbGVjdChpdGVyYXRvcikgewogICAgICAgIGNvbnN0IGFycmF5ID0gbmV3IEFycmF5KCk7CiAgICAgICAgbGV0IHJlc3VsdCA9IGl0ZXJhdG9yLm5leHQoKTsKICAgICAgICBmb3IgKDsgIXJlc3VsdC5kb25lOyByZXN1bHQgPSBpdGVyYXRvci5uZXh0KCkpCiAgICAgICAgICAgIGFycmF5LnB1c2gocmVzdWx0LnZhbHVlKTsKICAgICAgICByZXR1cm4gcmVzdWx0LnZhbHVlLnNldChhcnJheSk7CiAgICB9CiAgICBSZXN1bHQuY29sbGVjdCA9IGNvbGxlY3Q7CiAgICBmdW5jdGlvbiBtYXliZUNvbGxlY3QoaXRlcmF0b3IpIHsKICAgICAgICBjb25zdCBhcnJheSA9IG5ldyBBcnJheSgpOwogICAgICAgIGxldCByZXN1bHQgPSBpdGVyYXRvci5uZXh0KCk7CiAgICAgICAgZm9yICg7ICFyZXN1bHQuZG9uZTsgcmVzdWx0ID0gaXRlcmF0b3IubmV4dCgpKQogICAgICAgICAgICBhcnJheS5wdXNoKHJlc3VsdC52YWx1ZSk7CiAgICAgICAgcmV0dXJuIE9wdGlvbi5tYXBTeW5jKHJlc3VsdC52YWx1ZSwgcmVzdWx0ID0+IHJlc3VsdC5zZXQoYXJyYXkpKTsKICAgIH0KICAgIFJlc3VsdC5tYXliZUNvbGxlY3QgPSBtYXliZUNvbGxlY3Q7Cn0pKFJlc3VsdCB8fCAoUmVzdWx0ID0ge30pKTsKCgovLyMgc291cmNlTWFwcGluZ1VSTD1yZXN1bHQubWpzLm1hcAoKOy8vIENPTkNBVEVOQVRFRCBNT0RVTEU6IC4vbm9kZV9tb2R1bGVzL0BoYXphZTQxL3Jlc3VsdC9kaXN0L2VzbS9tb2RzL3Jlc3VsdC9vay5tanMKCgoKCmNsYXNzIE9rIHsKICAgICNpbm5lcjsKICAgICN0aW1lb3V0OwogICAgLyoqCiAgICAgKiBBIHN1Y2Nlc3MKICAgICAqIEBwYXJhbSBpbm5lcgogICAgICovCiAgICBjb25zdHJ1Y3Rvcihpbm5lcikgewogICAgICAgIHRoaXMuI2lubmVyID0gaW5uZXI7CiAgICAgICAgaWYgKCFSZXN1bHQuZGVidWcpCiAgICAgICAgICAgIHJldHVybjsKICAgICAgICBjb25zdCBlcnJvciA9IG5ldyBFcnJvcihgQW4gT2sgaGFzIG5vdCBiZWVuIGhhbmRsZWQgcHJvcGVybHlgKTsKICAgICAgICB0aGlzLiN0aW1lb3V0ID0gc2V0VGltZW91dCgoKSA9PiB7IHRocm93IGVycm9yOyB9LCAxMDAwKTsKICAgIH0KICAgIC8qKgogICAgICogQ3JlYXRlIGFuIGVtcHR5IGBPa2AKICAgICAqIEByZXR1cm5zIGBPayh2b2lkKWAKICAgICAqLwogICAgc3RhdGljIHZvaWQoKSB7CiAgICAgICAgcmV0dXJuIG5ldyBPayh1bmRlZmluZWQpOwogICAgfQogICAgLyoqCiAgICAgKiBDcmVhdGUgYW4gYE9rYAogICAgICogQHBhcmFtIGlubmVyCiAgICAgKiBAcmV0dXJucyBgT2soaW5uZXIpYAogICAgICovCiAgICBzdGF0aWMgbmV3KGlubmVyKSB7CiAgICAgICAgcmV0dXJuIG5ldyBPayhpbm5lcik7CiAgICB9CiAgICBnZXQgaW5uZXIoKSB7CiAgICAgICAgcmV0dXJuIHRoaXMuI2lubmVyOwogICAgfQogICAgLyoqCiAgICAgKiBTZXQgdGhpcyByZXN1bHQgYXMgaGFuZGxlZAogICAgICovCiAgICBpZ25vcmUoKSB7CiAgICAgICAgaWYgKCF0aGlzLiN0aW1lb3V0KQogICAgICAgICAgICByZXR1cm4gdGhpczsKICAgICAgICBjbGVhclRpbWVvdXQodGhpcy4jdGltZW91dCk7CiAgICAgICAgdGhpcy4jdGltZW91dCA9IHVuZGVmaW5lZDsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogVHlwZSBndWFyZCBmb3IgYE9rYAogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBPa2AsIGBmYWxzZWAgaWYgYEVycmAKICAgICAqLwogICAgaXNPaygpIHsKICAgICAgICByZXR1cm4gdHJ1ZTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyB0cnVlIGlmIHRoZSByZXN1bHQgaXMgYE9rYCBhbmQgdGhlIHZhbHVlIGluc2lkZSBvZiBpdCBtYXRjaGVzIGEgcHJlZGljYXRlCiAgICAgKiBAcGFyYW0gb2tQcmVkaWNhdGUKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgT2tgIGFuZCBgYXdhaXQgb2tQcmVkaWNhdGUodGhpcy5pbm5lcilgLCBgZmFsc2VgIG90aGVyd2lzZQogICAgICovCiAgICBhc3luYyBpc09rQW5kKG9rUHJlZGljYXRlKSB7CiAgICAgICAgcmV0dXJuIGF3YWl0IG9rUHJlZGljYXRlKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIHRydWUgaWYgdGhlIHJlc3VsdCBpcyBgT2tgIGFuZCB0aGUgdmFsdWUgaW5zaWRlIG9mIGl0IG1hdGNoZXMgYSBwcmVkaWNhdGUKICAgICAqIEBwYXJhbSBva1ByZWRpY2F0ZQogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBPa2AgYW5kIGBhd2FpdCBva1ByZWRpY2F0ZSh0aGlzLmlubmVyKWAsIGBmYWxzZWAgb3RoZXJ3aXNlCiAgICAgKi8KICAgIGlzT2tBbmRTeW5jKG9rUHJlZGljYXRlKSB7CiAgICAgICAgcmV0dXJuIG9rUHJlZGljYXRlKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBUeXBlIGd1YXJkIGZvciBgRXJyYAogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBFcnJgLCBgZmFsc2VgIGlmIGBPa2AKICAgICAqLwogICAgaXNFcnIoKSB7CiAgICAgICAgcmV0dXJuIGZhbHNlOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIHRydWUgaWYgdGhlIHJlc3VsdCBpcyBgRXJyYCBhbmQgdGhlIHZhbHVlIGluc2lkZSBvZiBpdCBtYXRjaGVzIGEgcHJlZGljYXRlCiAgICAgKiBAcGFyYW0gZXJyUHJlZGljYXRlCiAgICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYEVycmAgYW5kIGBhd2FpdCBlcnJQcmVkaWNhdGUodGhpcy5pbm5lcilgLCBgZmFsc2VgIG90aGVyd2lzZQogICAgICovCiAgICBhc3luYyBpc0VyckFuZChlcnJQcmVkaWNhdGUpIHsKICAgICAgICByZXR1cm4gZmFsc2U7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgdHJ1ZSBpZiB0aGUgcmVzdWx0IGlzIGBFcnJgIGFuZCB0aGUgdmFsdWUgaW5zaWRlIG9mIGl0IG1hdGNoZXMgYSBwcmVkaWNhdGUKICAgICAqIEBwYXJhbSBlcnJQcmVkaWNhdGUKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgRXJyYCBhbmQgYGF3YWl0IGVyclByZWRpY2F0ZSh0aGlzLmlubmVyKWAsIGBmYWxzZWAgb3RoZXJ3aXNlCiAgICAgKi8KICAgIGlzRXJyQW5kU3luYyhlcnJQcmVkaWNhdGUpIHsKICAgICAgICByZXR1cm4gZmFsc2U7CiAgICB9CiAgICAvKioKICAgICAqIENvbXBpbGUtdGltZSBzYWZlbHkgZ2V0IE9rJ3MgaW5uZXIgdHlwZQogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgCiAgICAgKiBAdGhyb3dzIGlmIGB0aGlzYCBpcyBgRXJyYAogICAgICovCiAgICBnZXQoKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gdGhpcy5pbm5lcjsKICAgIH0KICAgIC8qKgogICAgICogQ29tcGlsZS10aW1lIHNhZmVseSBnZXQgRXJyJ3MgaW5uZXIgdHlwZQogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgCiAgICAgKiBAdGhyb3dzIGlmIGB0aGlzYCBpcyBgT2tgCiAgICAgKi8KICAgIGdldEVycigpIHsKICAgICAgICB0aHJvdyBuZXcgUGFuaWMoKTsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtIGBSZXN1bHQ8VCwgRT5gIGludG8gYE9wdGlvbjxUPmAKICAgICAqIEByZXR1cm5zIGBTb21lKHRoaXMuaW5uZXIpYCBpZiBgT2tgLCBgTm9uZWAgaWYgYEVycmAKICAgICAqLwogICAgb2soKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gbmV3IFNvbWUodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBgUmVzdWx0PFQsIEU+YCBpbnRvIGBPcHRpb248RT5gCiAgICAgKiBAcmV0dXJucyBgU29tZSh0aGlzLmlubmVyKWAgaWYgYEVycmAsIGBOb25lYCBpZiBgT2tgCiAgICAgKi8KICAgIGVycigpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiBuZXcgTm9uZSgpOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGFuIGl0ZXJhdG9yIG92ZXIgdGhlIHBvc3NpYmx5IGNvbnRhaW5lZCB2YWx1ZQogICAgICogQHlpZWxkcyBgdGhpcy5pbm5lcmAgaWYgYE9rYAogICAgICovCiAgICAqW1N5bWJvbC5pdGVyYXRvcl0oKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICB5aWVsZCB0aGlzLmlubmVyOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm0gYFJlc3VsdDxULEU+YCBpbnRvIGBbVCxFXWAKICAgICAqIEByZXR1cm5zIGBbdGhpcy5pbm5lciwgdW5kZWZpbmVkXWAgaWYgYE9rYCwgYFt1bmRlZmluZWQsIHRoaXMuaW5uZXJdYCBpZiBgRXJyYAogICAgICovCiAgICBzcGxpdCgpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiBbdGhpcy5pbm5lciwgdW5kZWZpbmVkXTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyB0cnVlIGlmIHRoZSByZXN1bHQgaXMgYW4gYE9rYCB2YWx1ZSBjb250YWluaW5nIHRoZSBnaXZlbiB2YWx1ZQogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYE9rYCBhbmQgYHRoaXMuaW5uZXIgPT09IHZhbHVlYCwgYGZhbHNlYCBvdGhlcndpc2UKICAgICAqLwogICAgY29udGFpbnModmFsdWUpIHsKICAgICAgICByZXR1cm4gdGhpcy5pbm5lciA9PT0gdmFsdWU7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgdHJ1ZSBpZiB0aGUgcmVzdWx0IGlzIGFuIGBFcnJgIHZhbHVlIGNvbnRhaW5pbmcgdGhlIGdpdmVuIHZhbHVlCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgRXJyYCBhbmQgYHRoaXMuaW5uZXIgPT09IHZhbHVlYCwgYGZhbHNlYCBvdGhlcndpc2UKICAgICAqLwogICAgY29udGFpbnNFcnIodmFsdWUpIHsKICAgICAgICByZXR1cm4gZmFsc2U7CiAgICB9CiAgICAvKioKICAgICAqIEp1c3QgbGlrZSBgdW53cmFwYCBidXQgaXQgdGhyb3dzIHRvIHRoZSBjbG9zZXN0IGBSZXN1bHQudW50aHJvd2AKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgT2tgCiAgICAgKiBAdGhyb3dzIGB0aGlzYCBpZiBgRXJyYAogICAgICogQHNlZSBSZXN1bHQudW50aHJvdwogICAgICogQHNlZSBSZXN1bHQudW50aHJvd1N5bmMKICAgICAqLwogICAgdGhyb3codGhyb3dlcikgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIHRoaXMuaW5uZXI7CiAgICB9CiAgICAvKioKICAgICAqIEdldCB0aGUgaW5uZXIgdmFsdWUgb3IgdGhyb3cgdGhlIGlubmVyIGVycm9yIHdyYXBwZWQgaW5zaWRlIGFub3RoZXIgRXJyb3IKICAgICAqIEBwYXJhbSBtZXNzYWdlCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAgaWYgYE9rYCwgYEVycm9yKG1lc3NhZ2UsIHsgY2F1c2U6IHRoaXMuaW5uZXIgfSlgIGlmIGBFcnJgCiAgICAgKi8KICAgIGV4cGVjdChtZXNzYWdlKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gdGhpcy5pbm5lcjsKICAgIH0KICAgIC8qKgogICAgICogR2V0IHRoZSBpbm5lciBlcnJvciBvciB0aHJvdyB0aGUgaW5uZXIgdmFsdWUgd3JhcHBlZCBpbnNpZGUgYW5vdGhlciBFcnJvcgogICAgICogQHBhcmFtIG1lc3NhZ2UKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgRXJyYCwgYEVycm9yKG1lc3NhZ2UsIHsgY2F1c2U6IHRoaXMuaW5uZXIgfSlgIGlmIGBPa2AKICAgICAqLwogICAgZXhwZWN0RXJyKG1lc3NhZ2UpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHRocm93IG5ldyBFcnJvcihtZXNzYWdlLCB7IGNhdXNlOiB0aGlzLmlubmVyIH0pOwogICAgfQogICAgLyoqCiAgICAgKiBHZXQgdGhlIGlubmVyIHZhbHVlIG9yIHBhbmljCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAgaWYgYE9rYAogICAgICogQHRocm93cyBgdGhpcy5pbm5lcmAgaWYgYEVycmAKICAgICAqLwogICAgdW53cmFwKCkgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIHRoaXMuaW5uZXI7CiAgICB9CiAgICAvKioKICAgICAqIEdldCB0aGUgaW5uZXIgZXJyb3Igb3IgcGFuaWMKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgRXJyYAogICAgICogQHRocm93cyBgdGhpcy5pbm5lcmAgaWYgYE9rYAogICAgICovCiAgICB1bndyYXBFcnIoKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICB0aHJvdyB0aGlzLmlubmVyOwogICAgfQogICAgLyoqCiAgICAgKiBHZXQgdGhlIGlubmVyIHZhbHVlIG9yIGEgZGVmYXVsdCBvbmUKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBPa2AsIGB2YWx1ZWAgaWYgYEVycmAKICAgICAqLwogICAgdW53cmFwT3IodmFsdWUpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiB0aGlzLmlubmVyOwogICAgfQogICAgLyoqCiAgICAgKiBHZXQgdGhlIGlubmVyIHZhbHVlIG9yIGNvbXB1dGUgYSBkZWZhdWx0IG9uZSBmcm9tIHRoZSBpbm5lciBlcnJvcgogICAgICogQHBhcmFtIGVyck1hcHBlcgogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBPa2AsIGBhd2FpdCBlcnJNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBFcnJgCiAgICAgKiBAdGhyb3dzIGlmIGBhd2FpdCBlcnJNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICBhc3luYyB1bndyYXBPckVsc2UoZXJyTWFwcGVyKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gdGhpcy5pbm5lcjsKICAgIH0KICAgIC8qKgogICAgICogR2V0IHRoZSBpbm5lciB2YWx1ZSBvciBjb21wdXRlIGEgZGVmYXVsdCBvbmUgZnJvbSB0aGUgaW5uZXIgZXJyb3IKICAgICAqIEBwYXJhbSBlcnJNYXBwZXIKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgT2tgLCBgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgRXJyYAogICAgICogQHRocm93cyBpZiBgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgdW53cmFwT3JFbHNlU3luYyhlcnJNYXBwZXIpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiB0aGlzLmlubmVyOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm0gUmVzdWx0PFByb21pc2U8VD4sIEU+IGludG8gUHJvbWlzZTxSZXN1bHQ8VCwgRT4+CiAgICAgKiBAcmV0dXJucyBgYXdhaXQgdGhpcy5pbm5lcmAgaWYgYE9rYCwgYHRoaXNgIGlmIGBFcnJgCiAgICAgKi8KICAgIGFzeW5jIGF3YWl0KCkgewogICAgICAgIHJldHVybiBuZXcgT2soYXdhaXQgdGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBSZXN1bHQ8VCwgUHJvbWlzZTxFPj4gaW50byBQcm9taXNlPFJlc3VsdDxULCBFPj4KICAgICAqIEByZXR1cm5zIGBhd2FpdCB0aGlzLmlubmVyYCBpZiBgRXJyYCwgYHRoaXNgIGlmIGBPa2AKICAgICAqLwogICAgYXN5bmMgYXdhaXRFcnIoKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBSZXN1bHQ8UHJvbWlzZTxUPiwgUHJvbWlzZTxFPj4gaW50byBQcm9taXNlPFJlc3VsdDxULCBFPj4KICAgICAqIEByZXR1cm5zIGBhd2FpdCB0aGlzLmlubmVyYAogICAgICovCiAgICBhc3luYyBhd2FpdEFsbCgpIHsKICAgICAgICByZXR1cm4gYXdhaXQgdGhpcy5hd2FpdCgpOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm0gYFJlc3VsdDxULCBFPmAgaW50byBgUmVzdWx0PHZvaWQsIEU+YAogICAgICogQHJldHVybnMgYE9rPHZvaWQ+YCBpZiBgT2s8VD5gLCBgRXJyPEU+YCBpZiBgRTxFPmAKICAgICAqLwogICAgY2xlYXIoKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gT2sudm9pZCgpOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm0gYFJlc3VsdDxULCBFPmAgaW50byBgUmVzdWx0PFQsIHZvaWQ+YAogICAgICogQHJldHVybnMgYE9rPFQ+YCBpZiBgT2s8VD5gLCBgRXJyPHZvaWQ+YCBpZiBgRTxFPmAKICAgICAqLwogICAgY2xlYXJFcnIoKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIENhbGxzIHRoZSBnaXZlbiBjYWxsYmFjayB3aXRoIHRoZSBpbm5lciB2YWx1ZSBpZiBgT2tgCiAgICAgKiBAcGFyYW0gb2tDYWxsYmFjawogICAgICogQHJldHVybnMgYHRoaXNgCiAgICAgKi8KICAgIGFzeW5jIGluc3BlY3Qob2tDYWxsYmFjaykgewogICAgICAgIGF3YWl0IG9rQ2FsbGJhY2sodGhpcy5pbm5lcik7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIENhbGxzIHRoZSBnaXZlbiBjYWxsYmFjayB3aXRoIHRoZSBpbm5lciB2YWx1ZSBpZiBgT2tgCiAgICAgKiBAcGFyYW0gb2tDYWxsYmFjawogICAgICogQHJldHVybnMgYHRoaXNgCiAgICAgKi8KICAgIGluc3BlY3RTeW5jKG9rQ2FsbGJhY2spIHsKICAgICAgICBva0NhbGxiYWNrKHRoaXMuaW5uZXIpOwogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBDYWxscyB0aGUgZ2l2ZW4gY2FsbGJhY2sgd2l0aCB0aGUgaW5uZXIgdmFsdWUgaWYgYEVycmAKICAgICAqIEBwYXJhbSBlcnJDYWxsYmFjawogICAgICogQHJldHVybnMgYHRoaXNgCiAgICAgKi8KICAgIGFzeW5jIGluc3BlY3RFcnIoZXJyQ2FsbGJhY2spIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogQ2FsbHMgdGhlIGdpdmVuIGNhbGxiYWNrIHdpdGggdGhlIGlubmVyIHZhbHVlIGlmIGBFcnJgCiAgICAgKiBAcGFyYW0gZXJyQ2FsbGJhY2sKICAgICAqIEByZXR1cm5zIGB0aGlzYAogICAgICovCiAgICBpbnNwZWN0RXJyU3luYyhlcnJDYWxsYmFjaykgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm4gYSBuZXcgYE9rYCBidXQgd2l0aCB0aGUgZ2l2ZW4gYGlubmVyYAogICAgICogQHBhcmFtIGlubmVyCiAgICAgKiBAcmV0dXJucyBgT2soaW5uZXIpYCBpZiBgT2tgLCBgdGhpc2AgaWYgYEVycmAKICAgICAqLwogICAgc2V0KGlubmVyKSB7CiAgICAgICAgcmV0dXJuIG5ldyBPayhpbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybiBhIG5ldyBgRXJyYCBidXQgd2l0aCB0aGUgZ2l2ZW4gYGlubmVyYAogICAgICogQHBhcmFtIGlubmVyCiAgICAgKiBAcmV0dXJucyBgRXJyKGlubmVyKWAgaWYgYEVycmAsIGB0aGlzYCBpZiBgT2tgCiAgICAgKi8KICAgIHNldEVycihpbm5lcikgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBNYXAgdGhlIGlubmVyIHZhbHVlIGludG8gYW5vdGhlcgogICAgICogQHBhcmFtIG9rTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgT2soYXdhaXQgb2tNYXBwZXIodGhpcy5pbm5lcikpYCBpZiBgT2tgLCBgdGhpc2AgaWYgYEVycmAKICAgICAqIEB0aHJvd3MgaWYgYGF3YWl0IG9rTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgYXN5bmMgbWFwKG9rTWFwcGVyKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gbmV3IE9rKGF3YWl0IG9rTWFwcGVyKHRoaXMuaW5uZXIpKTsKICAgIH0KICAgIC8qKgogICAgICogTWFwIHRoZSBpbm5lciB2YWx1ZSBpbnRvIGFub3RoZXIKICAgICAqIEBwYXJhbSBva01hcHBlcgogICAgICogQHJldHVybnMgYE9rKG9rTWFwcGVyKHRoaXMuaW5uZXIpKWAgaWYgYE9rYCwgYHRoaXNgIGlmIGBFcnJgCiAgICAgKiBAdGhyb3dzIGlmIGBva01hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIG1hcFN5bmMob2tNYXBwZXIpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiBuZXcgT2sob2tNYXBwZXIodGhpcy5pbm5lcikpOwogICAgfQogICAgLyoqCiAgICAgKiBNYXAgdGhlIGlubmVyIGVycm9yIGludG8gYW5vdGhlcgogICAgICogQHBhcmFtIGVyck1hcHBlcgogICAgICogQHJldHVybnMgYEVycihhd2FpdCBlcnJNYXBwZXIodGhpcy5pbm5lcikpYCBpZiBgRXJyYCwgYHRoaXNgIGlmIGBPa2AKICAgICAqIEB0aHJvd3MgaWYgYGF3YWl0IGVyck1hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIGFzeW5jIG1hcEVycihlcnJNYXBwZXIpIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogTWFwIHRoZSBpbm5lciBlcnJvciBpbnRvIGFub3RoZXIKICAgICAqIEBwYXJhbSBlcnJNYXBwZXIKICAgICAqIEByZXR1cm5zIGBFcnIoZXJyTWFwcGVyKHRoaXMuaW5uZXIpKWAgaWYgYEVycmAsIGB0aGlzYCBpZiBgT2tgCiAgICAgKiBAdGhyb3dzIGlmIGBlcnJNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICBtYXBFcnJTeW5jKGVyck1hcHBlcikgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBNYXAgdGhlIGlubmVyIHZhbHVlIGludG8gYW5vdGhlciwgb3IgYSBkZWZhdWx0IG9uZQogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcGFyYW0gb2tNYXBwZXIKICAgICAqIEByZXR1cm5zIGBhd2FpdCBva01hcHBlcih0aGlzLmlubmVyKWAgaWYgYE9rYCwgYHZhbHVlYCBpZiBgRXJyYAogICAgICogQHRocm93cyBpZiBgYXdhaXQgb2tNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICBhc3luYyBtYXBPcih2YWx1ZSwgb2tNYXBwZXIpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiBhd2FpdCBva01hcHBlcih0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogTWFwIHRoZSBpbm5lciB2YWx1ZSBpbnRvIGFub3RoZXIsIG9yIGEgZGVmYXVsdCBvbmUKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHBhcmFtIG9rTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgb2tNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBPa2AsIGB2YWx1ZWAgaWYgYEVycmAKICAgICAqIEB0aHJvd3MgaWYgYG9rTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgbWFwT3JTeW5jKHZhbHVlLCBva01hcHBlcikgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIG9rTWFwcGVyKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBNYXAgdGhlIGlubmVyIHZhbHVlIGludG8gYW5vdGhlciwgb3IgYSBkZWZhdWx0IG9uZQogICAgICogQHBhcmFtIGVyck1hcHBlcgogICAgICogQHBhcmFtIG9rTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgYXdhaXQgb2tNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBPa2AsIGBhd2FpdCBlcnJNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBFcnJgCiAgICAgKiBAdGhyb3dzIGlmIGBhd2FpdCBva01hcHBlcih0aGlzLmlubmVyKWAgb3IgYGF3YWl0IGVyck1hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIGFzeW5jIG1hcE9yRWxzZShlcnJNYXBwZXIsIG9rTWFwcGVyKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gYXdhaXQgb2tNYXBwZXIodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIE1hcCB0aGUgaW5uZXIgdmFsdWUgaW50byBhbm90aGVyLCBvciBhIGRlZmF1bHQgb25lCiAgICAgKiBAcGFyYW0gZXJyTWFwcGVyCiAgICAgKiBAcGFyYW0gb2tNYXBwZXIKICAgICAqIEByZXR1cm5zIGBva01hcHBlcih0aGlzLmlubmVyKWAgaWYgYE9rYCwgYGVyck1hcHBlcih0aGlzLmlubmVyKWAgaWYgYEVycmAKICAgICAqIEB0aHJvd3MgaWYgYG9rTWFwcGVyKHRoaXMuaW5uZXIpYCBvciBgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgbWFwT3JFbHNlU3luYyhlcnJNYXBwZXIsIG9rTWFwcGVyKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gb2tNYXBwZXIodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybiBgdmFsdWVgIGlmIGBPa2AsIHJldHVybiBgdGhpc2AgaWYgYEVycmAKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHJldHVybnMgYHZhbHVlYCBpZiBgT2tgLCBgdGhpc2AgaWYgYEVycmAKICAgICAqLwogICAgYW5kKHZhbHVlKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gdmFsdWU7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybiBgYXdhaXQgb2tNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBPa2AsIHJldHVybiBgdGhpc2AgaWYgYEVycmAKICAgICAqIEBwYXJhbSBva01hcHBlcgogICAgICogQHJldHVybnMgYGF3YWl0IG9rTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgT2tgLCBgdGhpc2AgaWYgYEVycmAKICAgICAqIEB0aHJvd3MgaWYgYGF3YWl0IG9rTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgYXN5bmMgYW5kVGhlbihva01hcHBlcikgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIGF3YWl0IG9rTWFwcGVyKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm4gYG9rTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgT2tgLCByZXR1cm4gYHRoaXNgIGlmIGBFcnJgCiAgICAgKiBAcGFyYW0gb2tNYXBwZXIKICAgICAqIEByZXR1cm5zIGBva01hcHBlcih0aGlzLmlubmVyKWAgaWYgYE9rYCwgYHRoaXNgIGlmIGBFcnJgCiAgICAgKiBAdGhyb3dzIGlmIGBva01hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIGFuZFRoZW5TeW5jKG9rTWFwcGVyKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gb2tNYXBwZXIodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybiBgdmFsdWVgIGlmIGBFcnJgLCByZXR1cm4gYHRoaXNgIGlmIGBPa2AKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHJldHVybnMgYHZhbHVlYCBpZiBgRXJyYCwgYHRoaXNgIGlmIGBPa2AKICAgICAqLwogICAgb3IodmFsdWUpIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJuIGBhd2FpdCBlcnJNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBFcnJgLCByZXR1cm4gYHRoaXNgIGlmIGBPa2AKICAgICAqIEBwYXJhbSBlcnJNYXBwZXIKICAgICAqIEByZXR1cm5zIGBhd2FpdCBlcnJNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBFcnJgLCBgdGhpc2AgaWYgYE9rYAogICAgICogQHRocm93cyBpZiBgYXdhaXQgZXJyTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgYXN5bmMgb3JFbHNlKGVyck1hcHBlcikgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm4gYGVyck1hcHBlcih0aGlzLmlubmVyKWAgaWYgYEVycmAsIHJldHVybiBgdGhpc2AgaWYgYE9rYAogICAgICogQHBhcmFtIGVyck1hcHBlcgogICAgICogQHJldHVybnMgYGVyck1hcHBlcih0aGlzLmlubmVyKWAgaWYgYEVycmAsIGB0aGlzYCBpZiBgT2tgCiAgICAgKiBAdGhyb3dzIGlmIGBlcnJNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICBvckVsc2VTeW5jKGVyck1hcHBlcikgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm0gUmVzdWx0PFJlc3VsdDxULCBFMT4sIEUyPiBpbnRvIFJlc3VsdDxULCBFMSB8IEUyPgogICAgICogQHBhcmFtIHJlc3VsdAogICAgICogQHJldHVybnMgYHRoaXNgIGlmIGBFcnJgLCBgdGhpcy5pbm5lcmAgaWYgYE9rYAogICAgICovCiAgICBmbGF0dGVuKCkgewogICAgICAgIHJldHVybiB0aGlzLmlubmVyOwogICAgfQp9CgoKLy8jIHNvdXJjZU1hcHBpbmdVUkw9b2subWpzLm1hcAoKOy8vIENPTkNBVEVOQVRFRCBNT0RVTEU6IC4vbm9kZV9tb2R1bGVzL0BoYXphZTQxL29wdGlvbi9kaXN0L2VzbS9tb2RzL29wdGlvbi9zb21lLm1qcwoKCgpjbGFzcyBTb21lIHsKICAgIGlubmVyOwogICAgLyoqCiAgICAgKiBBbiBleGlzdGluZyB2YWx1ZQogICAgICogQHBhcmFtIGlubmVyCiAgICAgKi8KICAgIGNvbnN0cnVjdG9yKGlubmVyKSB7CiAgICAgICAgdGhpcy5pbm5lciA9IGlubmVyOwogICAgfQogICAgLyoqCiAgICAgKiBDcmVhdGUgYSBgU29tZWAKICAgICAqIEBwYXJhbSBpbm5lcgogICAgICogQHJldHVybnMgYFNvbWUoaW5uZXIpYAogICAgICovCiAgICBzdGF0aWMgbmV3KGlubmVyKSB7CiAgICAgICAgcmV0dXJuIG5ldyBTb21lKGlubmVyKTsKICAgIH0KICAgIHN0YXRpYyBmcm9tKGluaXQpIHsKICAgICAgICByZXR1cm4gbmV3IFNvbWUoaW5pdC5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFR5cGUgZ3VhcmQgZm9yIGBTb21lYAogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBTb21lYCwgYGZhbHNlYCBpZiBgTm9uZWAKICAgICAqLwogICAgaXNTb21lKCkgewogICAgICAgIHJldHVybiB0cnVlOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGB0cnVlYCBpZiB0aGUgb3B0aW9uIGlzIGEgYFNvbWVgIGFuZCB0aGUgdmFsdWUgaW5zaWRlIG9mIGl0IG1hdGNoZXMgYSBwcmVkaWNhdGUKICAgICAqIEBwYXJhbSBzb21lUHJlZGljYXRlCiAgICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYFNvbWVgIGFuZCBgYXdhaXQgc29tZVByZWRpY2F0ZSh0aGlzLmlubmVyKWAsIGBOb25lYCBvdGhlcndpc2UKICAgICAqLwogICAgYXN5bmMgaXNTb21lQW5kKHNvbWVQcmVkaWNhdGUpIHsKICAgICAgICByZXR1cm4gYXdhaXQgc29tZVByZWRpY2F0ZSh0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBgdHJ1ZWAgaWYgdGhlIG9wdGlvbiBpcyBhIGBTb21lYCBhbmQgdGhlIHZhbHVlIGluc2lkZSBvZiBpdCBtYXRjaGVzIGEgcHJlZGljYXRlCiAgICAgKiBAcGFyYW0gc29tZVByZWRpY2F0ZQogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBTb21lYCBhbmQgYHNvbWVQcmVkaWNhdGUodGhpcy5pbm5lcilgLCBgTm9uZWAgb3RoZXJ3aXNlCiAgICAgKi8KICAgIGlzU29tZUFuZFN5bmMoc29tZVByZWRpY2F0ZSkgewogICAgICAgIHJldHVybiBzb21lUHJlZGljYXRlKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBUeXBlIGd1YXJkIGZvciBgTm9uZWAKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgTm9uZWAsIGBmYWxzZWAgaWYgYFNvbWVgCiAgICAgKi8KICAgIGlzTm9uZSgpIHsKICAgICAgICByZXR1cm4gZmFsc2U7CiAgICB9CiAgICAvKioKICAgICAqIENvbXBpbGUtdGltZSBzYWZlbHkgZ2V0IGB0aGlzLmlubmVyYAogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgCiAgICAgKi8KICAgIGdldCgpIHsKICAgICAgICByZXR1cm4gdGhpcy5pbm5lcjsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBhbiBpdGVyYXRvciBvdmVyIHRoZSBwb3NzaWJseSBjb250YWluZWQgdmFsdWUKICAgICAqIEB5aWVsZHMgYHRoaXMuaW5uZXJgIGlmIGBTb21lYAogICAgICovCiAgICAqW1N5bWJvbC5pdGVyYXRvcl0oKSB7CiAgICAgICAgeWllbGQgdGhpcy5pbm5lcjsKICAgIH0KICAgIC8qKgogICAgICogR2V0IHRoZSBpbm5lciB2YWx1ZSBpZiBgU29tZWAsIHRocm93IGBFcnJvcihtZXNzYWdlKWAgb3RoZXJ3aXNlCiAgICAgKiBAcGFyYW0gbWVzc2FnZQogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBTb21lYAogICAgICogQHRocm93cyBgRXJyb3IobWVzc2FnZSlgIGlmIGBOb25lYAogICAgICovCiAgICBleHBlY3QobWVzc2FnZSkgewogICAgICAgIHJldHVybiB0aGlzLmlubmVyOwogICAgfQogICAgLyoqCiAgICAgKiBHZXQgdGhlIGlubmVyIHZhbHVlIG9yIHRocm93IGEgTm9uZUVycm9yCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAgaWYgYFNvbWVgCiAgICAgKiBAdGhyb3dzIGBOb25lRXJyb3JgIGlmIGBOb25lYAogICAgICovCiAgICB1bndyYXAoKSB7CiAgICAgICAgcmV0dXJuIHRoaXMuaW5uZXI7CiAgICB9CiAgICAvKioKICAgICAqIEdldCB0aGUgaW5uZXIgdmFsdWUgb3IgYSBkZWZhdWx0IG9uZQogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAgaWYgYFNvbWVgLCBgdmFsdWVgIGlmIGBOb25lYAogICAgICovCiAgICB1bndyYXBPcih2YWx1ZSkgewogICAgICAgIHJldHVybiB0aGlzLmlubmVyOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIHRoZSBjb250YWluZWQgYFNvbWVgIHZhbHVlIG9yIGNvbXB1dGVzIGl0IGZyb20gYSBjbG9zdXJlCiAgICAgKiBAcGFyYW0gbm9uZUNhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAgaWYgYFNvbWVgLCBgYXdhaXQgbm9uZUNhbGxiYWNrKClgIGlmIGBOb25lYAogICAgICovCiAgICBhc3luYyB1bndyYXBPckVsc2Uobm9uZUNhbGxiYWNrKSB7CiAgICAgICAgcmV0dXJuIHRoaXMuaW5uZXI7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgdGhlIGNvbnRhaW5lZCBgU29tZWAgdmFsdWUgb3IgY29tcHV0ZXMgaXQgZnJvbSBhIGNsb3N1cmUKICAgICAqIEBwYXJhbSBub25lQ2FsbGJhY2sKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgU29tZWAsIGBub25lQ2FsbGJhY2soKWAgaWYgYE5vbmVgCiAgICAgKi8KICAgIHVud3JhcE9yRWxzZVN5bmMobm9uZUNhbGxiYWNrKSB7CiAgICAgICAgcmV0dXJuIHRoaXMuaW5uZXI7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBgT3B0aW9uPFQ+YCBpbnRvIGBSZXN1bHQ8VCwgTm9uZUVycm9yPmAKICAgICAqIEByZXR1cm5zIGBPayh0aGlzLmlubmVyKWAgaWYgYFNvbWVgLCBgRXJyKE5vbmVFcnJvcilgIGlmIGBOb25lYAogICAgICovCiAgICBvaygpIHsKICAgICAgICByZXR1cm4gbmV3IE9rKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm0gYE9wdGlvbjxUPmAgaW50byBgUmVzdWx0PFQsIEU+YAogICAgICogQHBhcmFtIGVycm9yCiAgICAgKiBAcmV0dXJucyBgT2sodGhpcy5pbm5lcilgIGlmIGBTb21lYCwgYEVycihlcnJvcilgIGlmIGBOb25lYAogICAgICovCiAgICBva09yKGVycm9yKSB7CiAgICAgICAgcmV0dXJuIG5ldyBPayh0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtcyB0aGUgYE9wdGlvbjxUPmAgaW50byBhIGBSZXN1bHQ8VCwgRT5gLCBtYXBwaW5nIGBTb21lKHYpYCB0byBgT2sodilgIGFuZCBgTm9uZWAgdG8gYEVycihlcnIoKSlgCiAgICAgKiBAcGFyYW0gbm9uZUNhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgT2sodGhpcy5pbm5lcilgIGlmIGBTb21lYCwgYEVycihhd2FpdCBub25lQ2FsbGJhY2soKSlgIGlzIGBOb25lYAogICAgICovCiAgICBhc3luYyBva09yRWxzZShub25lQ2FsbGJhY2spIHsKICAgICAgICByZXR1cm4gbmV3IE9rKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm1zIHRoZSBgT3B0aW9uPFQ+YCBpbnRvIGEgYFJlc3VsdDxULCBFPmAsIG1hcHBpbmcgYFNvbWUodilgIHRvIGBPayh2KWAgYW5kIGBOb25lYCB0byBgRXJyKGVycigpKWAKICAgICAqIEBwYXJhbSBub25lQ2FsbGJhY2sKICAgICAqIEByZXR1cm5zIGBPayh0aGlzLmlubmVyKWAgaWYgYFNvbWVgLCBgRXJyKG5vbmVDYWxsYmFjaygpKWAgaXMgYE5vbmVgCiAgICAgKi8KICAgIG9rT3JFbHNlU3luYyhub25lQ2FsbGJhY2spIHsKICAgICAgICByZXR1cm4gbmV3IE9rKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGBOb25lYCBpZiB0aGUgb3B0aW9uIGlzIGBOb25lYCwgb3RoZXJ3aXNlIGNhbGxzIGBzb21lUHJlZGljYXRlYCB3aXRoIHRoZSB3cmFwcGVkIHZhbHVlCiAgICAgKiBAcGFyYW0gc29tZVByZWRpY2F0ZQogICAgICogQHJldHVybnMgYFNvbWVgIGlmIGBTb21lYCBhbmQgYGF3YWl0IHNvbWVQcmVkaWNhdGUodGhpcy5pbm5lcilgLCBgTm9uZWAgb3RoZXJ3aXNlCiAgICAgKi8KICAgIGFzeW5jIGZpbHRlcihzb21lUHJlZGljYXRlKSB7CiAgICAgICAgaWYgKGF3YWl0IHNvbWVQcmVkaWNhdGUodGhpcy5pbm5lcikpCiAgICAgICAgICAgIHJldHVybiB0aGlzOwogICAgICAgIGVsc2UKICAgICAgICAgICAgcmV0dXJuIG5ldyBOb25lKCk7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYE5vbmVgIGlmIHRoZSBvcHRpb24gaXMgYE5vbmVgLCBvdGhlcndpc2UgY2FsbHMgYHNvbWVQcmVkaWNhdGVgIHdpdGggdGhlIHdyYXBwZWQgdmFsdWUKICAgICAqIEBwYXJhbSBzb21lUHJlZGljYXRlCiAgICAgKiBAcmV0dXJucyBgU29tZWAgaWYgYFNvbWVgIGFuZCBgc29tZVByZWRpY2F0ZSh0aGlzLmlubmVyKWAsIGBOb25lYCBvdGhlcndpc2UKICAgICAqLwogICAgZmlsdGVyU3luYyhzb21lUHJlZGljYXRlKSB7CiAgICAgICAgaWYgKHNvbWVQcmVkaWNhdGUodGhpcy5pbm5lcikpCiAgICAgICAgICAgIHJldHVybiB0aGlzOwogICAgICAgIGVsc2UKICAgICAgICAgICAgcmV0dXJuIG5ldyBOb25lKCk7CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBgT3B0aW9uPFByb21pc2U8VD4+YCBpbnRvIGBQcm9taXNlPE9wdGlvbjxUPj5gCiAgICAgKiBAcmV0dXJucyBgUHJvbWlzZTxPcHRpb248VD4+YAogICAgICovCiAgICBhc3luYyBhd2FpdCgpIHsKICAgICAgICByZXR1cm4gbmV3IFNvbWUoYXdhaXQgdGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYHRydWVgIGlmIHRoZSBvcHRpb24gaXMgYSBgU29tZWAgdmFsdWUgY29udGFpbmluZyB0aGUgZ2l2ZW4gdmFsdWUKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBTb21lYCBhbmQgYHRoaXMuaW5uZXIgPT09IHZhbHVlYCwgYE5vbmVgIG90aGVyd2lzZQogICAgICovCiAgICBjb250YWlucyh2YWx1ZSkgewogICAgICAgIHJldHVybiB0aGlzLmlubmVyID09PSB2YWx1ZTsKICAgIH0KICAgIC8qKgogICAgICogQ2FsbHMgdGhlIGdpdmVuIGNhbGxiYWNrIHdpdGggdGhlIGlubmVyIHZhbHVlIGlmIGBPa2AKICAgICAqIEBwYXJhbSBzb21lQ2FsbGJhY2sKICAgICAqIEByZXR1cm5zIGB0aGlzYAogICAgICovCiAgICBhc3luYyBpbnNwZWN0KHNvbWVDYWxsYmFjaykgewogICAgICAgIGF3YWl0IHNvbWVDYWxsYmFjayh0aGlzLmlubmVyKTsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogQ2FsbHMgdGhlIGdpdmVuIGNhbGxiYWNrIHdpdGggdGhlIGlubmVyIHZhbHVlIGlmIGBPa2AKICAgICAqIEBwYXJhbSBzb21lQ2FsbGJhY2sKICAgICAqIEByZXR1cm5zIGB0aGlzYAogICAgICovCiAgICBpbnNwZWN0U3luYyhzb21lQ2FsbGJhY2spIHsKICAgICAgICBzb21lQ2FsbGJhY2sodGhpcy5pbm5lcik7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIE1hcHMgYW4gYE9wdGlvbjxUPmAgdG8gYE9wdGlvbjxVPmAgYnkgYXBwbHlpbmcgYSBmdW5jdGlvbiB0byBhIGNvbnRhaW5lZCB2YWx1ZSAoaWYgYFNvbWVgKSBvciByZXR1cm5zIGBOb25lYCAoaWYgYE5vbmVgKQogICAgICogQHBhcmFtIHNvbWVNYXBwZXIKICAgICAqIEByZXR1cm5zIGBTb21lKGF3YWl0IHNvbWVNYXBwZXIodGhpcy5pbm5lcikpYCBpZiBgU29tZWAsIGB0aGlzYCBpZiBgTm9uZWAKICAgICAqLwogICAgYXN5bmMgbWFwKHNvbWVNYXBwZXIpIHsKICAgICAgICByZXR1cm4gbmV3IFNvbWUoYXdhaXQgc29tZU1hcHBlcih0aGlzLmlubmVyKSk7CiAgICB9CiAgICAvKioKICAgICAqIE1hcHMgYW4gYE9wdGlvbjxUPmAgdG8gYE9wdGlvbjxVPmAgYnkgYXBwbHlpbmcgYSBmdW5jdGlvbiB0byBhIGNvbnRhaW5lZCB2YWx1ZSAoaWYgYFNvbWVgKSBvciByZXR1cm5zIGBOb25lYCAoaWYgYE5vbmVgKQogICAgICogQHBhcmFtIHNvbWVNYXBwZXIKICAgICAqIEByZXR1cm5zIGBTb21lKHNvbWVNYXBwZXIodGhpcy5pbm5lcikpYCBpZiBgU29tZWAsIGB0aGlzYCBpZiBgTm9uZWAKICAgICAqLwogICAgbWFwU3luYyhzb21lTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIG5ldyBTb21lKHNvbWVNYXBwZXIodGhpcy5pbm5lcikpOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIHRoZSBwcm92aWRlZCBkZWZhdWx0IHJlc3VsdCAoaWYgbm9uZSksIG9yIGFwcGxpZXMgYSBmdW5jdGlvbiB0byB0aGUgY29udGFpbmVkIHZhbHVlIChpZiBhbnkpCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEBwYXJhbSBzb21lTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgdmFsdWVgIGlmIGBOb25lYCwgYGF3YWl0IHNvbWVNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBTb21lYAogICAgICovCiAgICBhc3luYyBtYXBPcih2YWx1ZSwgc29tZU1hcHBlcikgewogICAgICAgIHJldHVybiBhd2FpdCBzb21lTWFwcGVyKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIHRoZSBwcm92aWRlZCBkZWZhdWx0IHJlc3VsdCAoaWYgbm9uZSksIG9yIGFwcGxpZXMgYSBmdW5jdGlvbiB0byB0aGUgY29udGFpbmVkIHZhbHVlIChpZiBhbnkpCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEBwYXJhbSBzb21lTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgdmFsdWVgIGlmIGBOb25lYCwgYHNvbWVNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBTb21lYAogICAgICovCiAgICBtYXBPclN5bmModmFsdWUsIHNvbWVNYXBwZXIpIHsKICAgICAgICByZXR1cm4gc29tZU1hcHBlcih0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogQ29tcHV0ZXMgYSBkZWZhdWx0IGZ1bmN0aW9uIHJlc3VsdCAoaWYgbm9uZSksIG9yIGFwcGxpZXMgYSBkaWZmZXJlbnQgZnVuY3Rpb24gdG8gdGhlIGNvbnRhaW5lZCB2YWx1ZSAoaWYgYW55KQogICAgICogQHBhcmFtIG5vbmVDYWxsYmFjawogICAgICogQHBhcmFtIHNvbWVNYXBwZXIKICAgICAqIEByZXR1cm5zIGBhd2FpdCBzb21lTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgU29tZWAsIGBhd2FpdCBub25lQ2FsbGJhY2soKWAgaWYgYE5vbmVgCiAgICAgKi8KICAgIGFzeW5jIG1hcE9yRWxzZShub25lQ2FsbGJhY2ssIHNvbWVNYXBwZXIpIHsKICAgICAgICByZXR1cm4gYXdhaXQgc29tZU1hcHBlcih0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogQ29tcHV0ZXMgYSBkZWZhdWx0IGZ1bmN0aW9uIHJlc3VsdCAoaWYgbm9uZSksIG9yIGFwcGxpZXMgYSBkaWZmZXJlbnQgZnVuY3Rpb24gdG8gdGhlIGNvbnRhaW5lZCB2YWx1ZSAoaWYgYW55KQogICAgICogQHBhcmFtIG5vbmVDYWxsYmFjawogICAgICogQHBhcmFtIHNvbWVNYXBwZXIKICAgICAqIEByZXR1cm5zIGBzb21lTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgU29tZWAsIGBub25lQ2FsbGJhY2soKWAgaWYgYE5vbmVgCiAgICAgKi8KICAgIG1hcE9yRWxzZVN5bmMobm9uZUNhbGxiYWNrLCBzb21lTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIHNvbWVNYXBwZXIodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYE5vbmVgIGlmIHRoZSBvcHRpb24gaXMgYE5vbmVgLCBvdGhlcndpc2UgcmV0dXJucyBgdmFsdWVgCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEByZXR1cm5zIGBOb25lYCBpZiBgTm9uZWAsIGB2YWx1ZWAgaWYgYFNvbWVgCiAgICAgKi8KICAgIGFuZCh2YWx1ZSkgewogICAgICAgIHJldHVybiB2YWx1ZTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBgTm9uZWAgaWYgdGhlIG9wdGlvbiBpcyBgTm9uZWAsIG90aGVyd2lzZSBjYWxscyBgc29tZU1hcHBlcmAgd2l0aCB0aGUgd3JhcHBlZCB2YWx1ZSBhbmQgcmV0dXJucyB0aGUgcmVzdWx0CiAgICAgKiBAcGFyYW0gc29tZU1hcHBlcgogICAgICogQHJldHVybnMgYE5vbmVgIGlmIGBOb25lYCwgYGF3YWl0IHNvbWVNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBTb21lYAogICAgICovCiAgICBhc3luYyBhbmRUaGVuKHNvbWVNYXBwZXIpIHsKICAgICAgICByZXR1cm4gYXdhaXQgc29tZU1hcHBlcih0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyBgTm9uZWAgaWYgdGhlIG9wdGlvbiBpcyBgTm9uZWAsIG90aGVyd2lzZSBjYWxscyBgc29tZU1hcHBlcmAgd2l0aCB0aGUgd3JhcHBlZCB2YWx1ZSBhbmQgcmV0dXJucyB0aGUgcmVzdWx0CiAgICAgKiBAcGFyYW0gc29tZU1hcHBlcgogICAgICogQHJldHVybnMgYE5vbmVgIGlmIGBOb25lYCwgYHNvbWVNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBTb21lYAogICAgICovCiAgICBhbmRUaGVuU3luYyhzb21lTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIHNvbWVNYXBwZXIodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYHRoaXNgIGlmIGBTb21lYCwgb3RoZXJ3aXNlIHJldHVybnMgYHZhbHVlYAogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcmV0dXJucyBgdGhpc2AgaWYgYFNvbWVgLCBgdmFsdWVgIGlmIGBOb25lYAogICAgICovCiAgICBvcih2YWx1ZSkgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGB0aGlzYCBpZiBgU29tZWAsIG90aGVyd2lzZSBjYWxscyBgbm9uZUNhbGxiYWNrYCBhbmQgcmV0dXJucyB0aGUgcmVzdWx0CiAgICAgKiBAcGFyYW0gbm9uZUNhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgdGhpc2AgaWYgYFNvbWVgLCBgYXdhaXQgbm9uZUNhbGxiYWNrKClgIGlmIGBOb25lYAogICAgICovCiAgICBhc3luYyBvckVsc2Uobm9uZUNhbGxiYWNrKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYHRoaXNgIGlmIGBTb21lYCwgb3RoZXJ3aXNlIGNhbGxzIGBub25lQ2FsbGJhY2tgIGFuZCByZXR1cm5zIHRoZSByZXN1bHQKICAgICAqIEBwYXJhbSBub25lQ2FsbGJhY2sKICAgICAqIEByZXR1cm5zIGB0aGlzYCBpZiBgU29tZWAsIGBub25lQ2FsbGJhY2soKWAgaWYgYE5vbmVgCiAgICAgKi8KICAgIG9yRWxzZVN5bmMobm9uZUNhbGxiYWNrKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgYFNvbWVgIGlmIGV4YWN0bHkgb25lIG9mIHRoZSBvcHRpb25zIGlzIGBTb21lYCwgb3RoZXJ3aXNlIHJldHVybnMgYE5vbmVgCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEByZXR1cm5zIGBOb25lYCBpZiBib3RoIGFyZSBgU29tZWAgb3IgYm90aCBhcmUgYE5vbmVgLCB0aGUgb25seSBgU29tZWAgb3RoZXJ3aXNlCiAgICAgKi8KICAgIHhvcih2YWx1ZSkgewogICAgICAgIGlmICh2YWx1ZS5pc1NvbWUoKSkKICAgICAgICAgICAgcmV0dXJuIG5ldyBOb25lKCk7CiAgICAgICAgZWxzZQogICAgICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogWmlwcyBgdGhpc2Agd2l0aCBhbm90aGVyIGBPcHRpb25gCiAgICAgKiBAcGFyYW0gb3RoZXIKICAgICAqIEByZXR1cm5zIGBTb21lKFt0aGlzLmlubmVyLCBvdGhlci5pbm5lcl0pYCBpZiBib3RoIGFyZSBgU29tZWAsIGBOb25lYCBpZiBvbmUgb2YgdGhlbSBpcyBgTm9uZWAKICAgICAqLwogICAgemlwKG90aGVyKSB7CiAgICAgICAgaWYgKG90aGVyLmlzU29tZSgpKQogICAgICAgICAgICByZXR1cm4gbmV3IFNvbWUoW3RoaXMuaW5uZXIsIG90aGVyLmlubmVyXSk7CiAgICAgICAgZWxzZQogICAgICAgICAgICByZXR1cm4gb3RoZXI7CiAgICB9Cn0KCgovLyMgc291cmNlTWFwcGluZ1VSTD1zb21lLm1qcy5tYXAKCjsvLyBDT05DQVRFTkFURUQgTU9EVUxFOiAuL25vZGVfbW9kdWxlcy9AaGF6YWU0MS9yZXN1bHQvZGlzdC9lc20vbW9kcy9yZXN1bHQvZXJyLm1qcwoKCgoKY2xhc3MgRXJyIHsKICAgICNpbm5lcjsKICAgICN0aW1lb3V0OwogICAgLyoqCiAgICAgKiBBIGZhaWx1cmUKICAgICAqIEBwYXJhbSBpbm5lcgogICAgICovCiAgICBjb25zdHJ1Y3Rvcihpbm5lcikgewogICAgICAgIHRoaXMuI2lubmVyID0gaW5uZXI7CiAgICAgICAgaWYgKCFSZXN1bHQuZGVidWcpCiAgICAgICAgICAgIHJldHVybjsKICAgICAgICBjb25zdCBlcnJvciA9IG5ldyBFcnJvcihgQW4gRXJyIGhhcyBub3QgYmVlbiBoYW5kbGVkIHByb3Blcmx5YCk7CiAgICAgICAgdGhpcy4jdGltZW91dCA9IHNldFRpbWVvdXQoKCkgPT4geyB0aHJvdyBlcnJvcjsgfSwgMTAwMCk7CiAgICB9CiAgICAvKioKICAgICAqIENyZWF0ZSBhbiBlbXB0eSBgRXJyYAogICAgICogQHJldHVybnMgYEVycih2b2lkKWAKICAgICAqLwogICAgc3RhdGljIHZvaWQoKSB7CiAgICAgICAgcmV0dXJuIG5ldyBFcnIodW5kZWZpbmVkKTsKICAgIH0KICAgIC8qKgogICAgICogQ3JlYXRlIGFuIGBFcnJgCiAgICAgKiBAcGFyYW0gaW5uZXIKICAgICAqIEByZXR1cm5zIGBFcnIoaW5uZXIpYAogICAgICovCiAgICBzdGF0aWMgbmV3KGlubmVyKSB7CiAgICAgICAgcmV0dXJuIG5ldyBFcnIoaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBDcmVhdGUgYW4gYEVycmAgd2l0aCBhbiBgRXJyb3JgIGluc2lkZQogICAgICogQHBhcmFtIG1lc3NhZ2UKICAgICAqIEBwYXJhbSBvcHRpb25zCiAgICAgKiBAcmV0dXJucyBgRXJyPEVycm9yPmAKICAgICAqLwogICAgc3RhdGljIGVycm9yKG1lc3NhZ2UsIG9wdGlvbnMpIHsKICAgICAgICByZXR1cm4gbmV3IEVycihuZXcgRXJyb3IobWVzc2FnZSwgb3B0aW9ucykpOwogICAgfQogICAgZ2V0IGlubmVyKCkgewogICAgICAgIHJldHVybiB0aGlzLiNpbm5lcjsKICAgIH0KICAgIC8qKgogICAgICogU2V0IHRoaXMgcmVzdWx0IGFzIGhhbmRsZWQKICAgICAqLwogICAgaWdub3JlKCkgewogICAgICAgIGlmICghdGhpcy4jdGltZW91dCkKICAgICAgICAgICAgcmV0dXJuIHRoaXM7CiAgICAgICAgY2xlYXJUaW1lb3V0KHRoaXMuI3RpbWVvdXQpOwogICAgICAgIHRoaXMuI3RpbWVvdXQgPSB1bmRlZmluZWQ7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIFR5cGUgZ3VhcmQgZm9yIGBPa2AKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgT2tgLCBgZmFsc2VgIGlmIGBFcnJgCiAgICAgKi8KICAgIGlzT2soKSB7CiAgICAgICAgcmV0dXJuIGZhbHNlOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIHRydWUgaWYgdGhlIHJlc3VsdCBpcyBgT2tgIGFuZCB0aGUgdmFsdWUgaW5zaWRlIG9mIGl0IG1hdGNoZXMgYSBwcmVkaWNhdGUKICAgICAqIEBwYXJhbSBva1ByZWRpY2F0ZQogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBPa2AgYW5kIGBhd2FpdCBva1ByZWRpY2F0ZSh0aGlzLmlubmVyKWAsIGBmYWxzZWAgb3RoZXJ3aXNlCiAgICAgKi8KICAgIGFzeW5jIGlzT2tBbmQob2tQcmVkaWNhdGUpIHsKICAgICAgICByZXR1cm4gZmFsc2U7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybnMgdHJ1ZSBpZiB0aGUgcmVzdWx0IGlzIGBPa2AgYW5kIHRoZSB2YWx1ZSBpbnNpZGUgb2YgaXQgbWF0Y2hlcyBhIHByZWRpY2F0ZQogICAgICogQHBhcmFtIG9rUHJlZGljYXRlCiAgICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYE9rYCBhbmQgYGF3YWl0IG9rUHJlZGljYXRlKHRoaXMuaW5uZXIpYCwgYGZhbHNlYCBvdGhlcndpc2UKICAgICAqLwogICAgaXNPa0FuZFN5bmMob2tQcmVkaWNhdGUpIHsKICAgICAgICByZXR1cm4gZmFsc2U7CiAgICB9CiAgICAvKioKICAgICAqIFR5cGUgZ3VhcmQgZm9yIGBFcnJgCiAgICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYEVycmAsIGBmYWxzZWAgaWYgYE9rYAogICAgICovCiAgICBpc0VycigpIHsKICAgICAgICByZXR1cm4gdHJ1ZTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyB0cnVlIGlmIHRoZSByZXN1bHQgaXMgYEVycmAgYW5kIHRoZSB2YWx1ZSBpbnNpZGUgb2YgaXQgbWF0Y2hlcyBhIHByZWRpY2F0ZQogICAgICogQHBhcmFtIGVyclByZWRpY2F0ZQogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBFcnJgIGFuZCBgYXdhaXQgZXJyUHJlZGljYXRlKHRoaXMuaW5uZXIpYCwgYGZhbHNlYCBvdGhlcndpc2UKICAgICAqLwogICAgYXN5bmMgaXNFcnJBbmQoZXJyUHJlZGljYXRlKSB7CiAgICAgICAgcmV0dXJuIGF3YWl0IGVyclByZWRpY2F0ZSh0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyB0cnVlIGlmIHRoZSByZXN1bHQgaXMgYEVycmAgYW5kIHRoZSB2YWx1ZSBpbnNpZGUgb2YgaXQgbWF0Y2hlcyBhIHByZWRpY2F0ZQogICAgICogQHBhcmFtIGVyclByZWRpY2F0ZQogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBFcnJgIGFuZCBgYXdhaXQgZXJyUHJlZGljYXRlKHRoaXMuaW5uZXIpYCwgYGZhbHNlYCBvdGhlcndpc2UKICAgICAqLwogICAgaXNFcnJBbmRTeW5jKGVyclByZWRpY2F0ZSkgewogICAgICAgIHJldHVybiBlcnJQcmVkaWNhdGUodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIENvbXBpbGUtdGltZSBzYWZlbHkgZ2V0IE9rJ3MgaW5uZXIgdHlwZQogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgCiAgICAgKiBAdGhyb3dzIGlmIGB0aGlzYCBpcyBgRXJyYAogICAgICovCiAgICBnZXQoKSB7CiAgICAgICAgdGhyb3cgbmV3IFBhbmljKCk7CiAgICB9CiAgICAvKioKICAgICAqIENvbXBpbGUtdGltZSBzYWZlbHkgZ2V0IEVycidzIGlubmVyIHR5cGUKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYAogICAgICogQHRocm93cyBpZiBgdGhpc2AgaXMgYE9rYAogICAgICovCiAgICBnZXRFcnIoKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gdGhpcy5pbm5lcjsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtIGBSZXN1bHQ8VCwgRT5gIGludG8gYE9wdGlvbjxUPmAKICAgICAqIEByZXR1cm5zIGBTb21lKHRoaXMuaW5uZXIpYCBpZiBgT2tgLCBgTm9uZWAgaWYgYEVycmAKICAgICAqLwogICAgb2soKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gbmV3IE5vbmUoKTsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtIGBSZXN1bHQ8VCwgRT5gIGludG8gYE9wdGlvbjxFPmAKICAgICAqIEByZXR1cm5zIGBTb21lKHRoaXMuaW5uZXIpYCBpZiBgRXJyYCwgYE5vbmVgIGlmIGBPa2AKICAgICAqLwogICAgZXJyKCkgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIG5ldyBTb21lKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIGFuIGl0ZXJhdG9yIG92ZXIgdGhlIHBvc3NpYmx5IGNvbnRhaW5lZCB2YWx1ZQogICAgICogQHlpZWxkcyBgdGhpcy5pbm5lcmAgaWYgYE9rYAogICAgICovCiAgICAqW1N5bWJvbC5pdGVyYXRvcl0oKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm47CiAgICB9CiAgICAvKioKICAgICAqIFRyYW5zZm9ybSBgUmVzdWx0PFQsRT5gIGludG8gYFtULEVdYAogICAgICogQHJldHVybnMgYFt0aGlzLmlubmVyLCB1bmRlZmluZWRdYCBpZiBgT2tgLCBgW3VuZGVmaW5lZCwgdGhpcy5pbm5lcl1gIGlmIGBFcnJgCiAgICAgKi8KICAgIHNwbGl0KCkgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIFt1bmRlZmluZWQsIHRoaXMuaW5uZXJdOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm5zIHRydWUgaWYgdGhlIHJlc3VsdCBpcyBhbiBgT2tgIHZhbHVlIGNvbnRhaW5pbmcgdGhlIGdpdmVuIHZhbHVlCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEByZXR1cm5zIGB0cnVlYCBpZiBgT2tgIGFuZCBgdGhpcy5pbm5lciA9PT0gdmFsdWVgLCBgZmFsc2VgIG90aGVyd2lzZQogICAgICovCiAgICBjb250YWlucyh2YWx1ZSkgewogICAgICAgIHJldHVybiBmYWxzZTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJucyB0cnVlIGlmIHRoZSByZXN1bHQgaXMgYW4gYEVycmAgdmFsdWUgY29udGFpbmluZyB0aGUgZ2l2ZW4gdmFsdWUKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHJldHVybnMgYHRydWVgIGlmIGBFcnJgIGFuZCBgdGhpcy5pbm5lciA9PT0gdmFsdWVgLCBgZmFsc2VgIG90aGVyd2lzZQogICAgICovCiAgICBjb250YWluc0Vycih2YWx1ZSkgewogICAgICAgIHJldHVybiB0aGlzLmlubmVyID09PSB2YWx1ZTsKICAgIH0KICAgIC8qKgogICAgICogR2V0IHRoZSBpbm5lciB2YWx1ZSBvciB0aHJvdyB0byB0aGUgY2xvc2VzdCBgUmVzdWx0LnVudGhyb3dgCiAgICAgKiBAcGFyYW0gdGhyb3dlciBUaGUgdGhyb3dlciBmcm9tIGBSZXN1bHQudW50aHJvd2AKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgT2tgCiAgICAgKiBAdGhyb3dzIGB1bmRlZmluZWRgIGlmIGBFcnJgCiAgICAgKiBAc2VlIFJlc3VsdC51bnRocm93CiAgICAgKiBAc2VlIFJlc3VsdC51bnRocm93U3luYwogICAgICovCiAgICB0aHJvdyh0aHJvd2VyKSB7CiAgICAgICAgdGhyb3dlcih0aGlzKTsKICAgICAgICB0aHJvdyB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBHZXQgdGhlIGlubmVyIHZhbHVlIG9yIHRocm93IHRoZSBpbm5lciBlcnJvciB3cmFwcGVkIGluc2lkZSBhbm90aGVyIEVycm9yCiAgICAgKiBAcGFyYW0gbWVzc2FnZQogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBPa2AsIGBFcnJvcihtZXNzYWdlLCB7IGNhdXNlOiB0aGlzLmlubmVyIH0pYCBpZiBgRXJyYAogICAgICovCiAgICBleHBlY3QobWVzc2FnZSkgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgdGhyb3cgbmV3IEVycm9yKG1lc3NhZ2UsIHsgY2F1c2U6IHRoaXMuaW5uZXIgfSk7CiAgICB9CiAgICAvKioKICAgICAqIEdldCB0aGUgaW5uZXIgZXJyb3Igb3IgdGhyb3cgdGhlIGlubmVyIHZhbHVlIHdyYXBwZWQgaW5zaWRlIGFub3RoZXIgRXJyb3IKICAgICAqIEBwYXJhbSBtZXNzYWdlCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAgaWYgYEVycmAsIGBFcnJvcihtZXNzYWdlLCB7IGNhdXNlOiB0aGlzLmlubmVyIH0pYCBpZiBgT2tgCiAgICAgKi8KICAgIGV4cGVjdEVycihtZXNzYWdlKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gdGhpcy5pbm5lcjsKICAgIH0KICAgIC8qKgogICAgICogR2V0IHRoZSBpbm5lciB2YWx1ZSBvciBwYW5pYwogICAgICogQHJldHVybnMgYHRoaXMuaW5uZXJgIGlmIGBPa2AKICAgICAqIEB0aHJvd3MgYHRoaXMuaW5uZXJgIGlmIGBFcnJgCiAgICAgKi8KICAgIHVud3JhcCgpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHRocm93IHRoaXMuaW5uZXI7CiAgICB9CiAgICAvKioKICAgICAqIEdldCB0aGUgaW5uZXIgZXJyb3Igb3IgcGFuaWMKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgRXJyYAogICAgICogQHRocm93cyBgdGhpcy5pbm5lcmAgaWYgYE9rYAogICAgICovCiAgICB1bndyYXBFcnIoKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gdGhpcy5pbm5lcjsKICAgIH0KICAgIC8qKgogICAgICogR2V0IHRoZSBpbm5lciB2YWx1ZSBvciBhIGRlZmF1bHQgb25lCiAgICAgKiBAcGFyYW0gdmFsdWUKICAgICAqIEByZXR1cm5zIGB0aGlzLmlubmVyYCBpZiBgT2tgLCBgdmFsdWVgIGlmIGBFcnJgCiAgICAgKi8KICAgIHVud3JhcE9yKHZhbHVlKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gdmFsdWU7CiAgICB9CiAgICAvKioKICAgICAqIEdldCB0aGUgaW5uZXIgdmFsdWUgb3IgY29tcHV0ZSBhIGRlZmF1bHQgb25lIGZyb20gdGhlIGlubmVyIGVycm9yCiAgICAgKiBAcGFyYW0gZXJyTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAgaWYgYE9rYCwgYGF3YWl0IGVyck1hcHBlcih0aGlzLmlubmVyKWAgaWYgYEVycmAKICAgICAqIEB0aHJvd3MgaWYgYGF3YWl0IGVyck1hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIGFzeW5jIHVud3JhcE9yRWxzZShlcnJNYXBwZXIpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiBhd2FpdCBlcnJNYXBwZXIodGhpcy5pbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIEdldCB0aGUgaW5uZXIgdmFsdWUgb3IgY29tcHV0ZSBhIGRlZmF1bHQgb25lIGZyb20gdGhlIGlubmVyIGVycm9yCiAgICAgKiBAcGFyYW0gZXJyTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgdGhpcy5pbm5lcmAgaWYgYE9rYCwgYGVyck1hcHBlcih0aGlzLmlubmVyKWAgaWYgYEVycmAKICAgICAqIEB0aHJvd3MgaWYgYGVyck1hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIHVud3JhcE9yRWxzZVN5bmMoZXJyTWFwcGVyKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gZXJyTWFwcGVyKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm0gUmVzdWx0PFByb21pc2U8VD4sIEU+IGludG8gUHJvbWlzZTxSZXN1bHQ8VCwgRT4+CiAgICAgKiBAcmV0dXJucyBgYXdhaXQgdGhpcy5pbm5lcmAgaWYgYE9rYCwgYHRoaXNgIGlmIGBFcnJgCiAgICAgKi8KICAgIGFzeW5jIGF3YWl0KCkgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm0gUmVzdWx0PFQsIFByb21pc2U8RT4+IGludG8gUHJvbWlzZTxSZXN1bHQ8VCwgRT4+CiAgICAgKiBAcmV0dXJucyBgYXdhaXQgdGhpcy5pbm5lcmAgaWYgYEVycmAsIGB0aGlzYCBpZiBgT2tgCiAgICAgKi8KICAgIGFzeW5jIGF3YWl0RXJyKCkgewogICAgICAgIHJldHVybiBuZXcgRXJyKGF3YWl0IHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm0gUmVzdWx0PFByb21pc2U8VD4sIFByb21pc2U8RT4+IGludG8gUHJvbWlzZTxSZXN1bHQ8VCwgRT4+CiAgICAgKiBAcmV0dXJucyBgYXdhaXQgdGhpcy5pbm5lcmAKICAgICAqLwogICAgYXN5bmMgYXdhaXRBbGwoKSB7CiAgICAgICAgcmV0dXJuIGF3YWl0IHRoaXMuYXdhaXRFcnIoKTsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtIGBSZXN1bHQ8VCwgRT5gIGludG8gYFJlc3VsdDx2b2lkLCBFPmAKICAgICAqIEByZXR1cm5zIGBPazx2b2lkPmAgaWYgYE9rPFQ+YCwgYEVycjxFPmAgaWYgYEU8RT5gCiAgICAgKi8KICAgIGNsZWFyKCkgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBUcmFuc2Zvcm0gYFJlc3VsdDxULCBFPmAgaW50byBgUmVzdWx0PFQsIHZvaWQ+YAogICAgICogQHJldHVybnMgYE9rPFQ+YCBpZiBgT2s8VD5gLCBgRXJyPHZvaWQ+YCBpZiBgRTxFPmAKICAgICAqLwogICAgY2xlYXJFcnIoKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gRXJyLnZvaWQoKTsKICAgIH0KICAgIC8qKgogICAgICogQ2FsbHMgdGhlIGdpdmVuIGNhbGxiYWNrIHdpdGggdGhlIGlubmVyIHZhbHVlIGlmIGBPa2AKICAgICAqIEBwYXJhbSBva0NhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgdGhpc2AKICAgICAqLwogICAgYXN5bmMgaW5zcGVjdChva0NhbGxiYWNrKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIENhbGxzIHRoZSBnaXZlbiBjYWxsYmFjayB3aXRoIHRoZSBpbm5lciB2YWx1ZSBpZiBgT2tgCiAgICAgKiBAcGFyYW0gb2tDYWxsYmFjawogICAgICogQHJldHVybnMgYHRoaXNgCiAgICAgKi8KICAgIGluc3BlY3RTeW5jKG9rQ2FsbGJhY2spIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogQ2FsbHMgdGhlIGdpdmVuIGNhbGxiYWNrIHdpdGggdGhlIGlubmVyIHZhbHVlIGlmIGBFcnJgCiAgICAgKiBAcGFyYW0gZXJyQ2FsbGJhY2sKICAgICAqIEByZXR1cm5zIGB0aGlzYAogICAgICovCiAgICBhc3luYyBpbnNwZWN0RXJyKGVyckNhbGxiYWNrKSB7CiAgICAgICAgYXdhaXQgZXJyQ2FsbGJhY2sodGhpcy5pbm5lcik7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIENhbGxzIHRoZSBnaXZlbiBjYWxsYmFjayB3aXRoIHRoZSBpbm5lciB2YWx1ZSBpZiBgRXJyYAogICAgICogQHBhcmFtIGVyckNhbGxiYWNrCiAgICAgKiBAcmV0dXJucyBgdGhpc2AKICAgICAqLwogICAgaW5zcGVjdEVyclN5bmMoZXJyQ2FsbGJhY2spIHsKICAgICAgICBlcnJDYWxsYmFjayh0aGlzLmlubmVyKTsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJuIGEgbmV3IGBPa2AgYnV0IHdpdGggdGhlIGdpdmVuIGBpbm5lcmAKICAgICAqIEBwYXJhbSBpbm5lcgogICAgICogQHJldHVybnMgYE9rKGlubmVyKWAgaWYgYE9rYCwgYHRoaXNgIGlmIGBFcnJgCiAgICAgKi8KICAgIHNldChpbm5lcikgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm4gYSBuZXcgYEVycmAgYnV0IHdpdGggdGhlIGdpdmVuIGBpbm5lcmAKICAgICAqIEBwYXJhbSBpbm5lcgogICAgICogQHJldHVybnMgYEVycihpbm5lcilgIGlmIGBFcnJgLCBgdGhpc2AgaWYgYE9rYAogICAgICovCiAgICBzZXRFcnIoaW5uZXIpIHsKICAgICAgICByZXR1cm4gbmV3IEVycihpbm5lcik7CiAgICB9CiAgICAvKioKICAgICAqIE1hcCB0aGUgaW5uZXIgdmFsdWUgaW50byBhbm90aGVyCiAgICAgKiBAcGFyYW0gb2tNYXBwZXIKICAgICAqIEByZXR1cm5zIGBPayhhd2FpdCBva01hcHBlcih0aGlzLmlubmVyKSlgIGlmIGBPa2AsIGB0aGlzYCBpZiBgRXJyYAogICAgICogQHRocm93cyBpZiBgYXdhaXQgb2tNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICBhc3luYyBtYXAob2tNYXBwZXIpIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogTWFwIHRoZSBpbm5lciB2YWx1ZSBpbnRvIGFub3RoZXIKICAgICAqIEBwYXJhbSBva01hcHBlcgogICAgICogQHJldHVybnMgYE9rKG9rTWFwcGVyKHRoaXMuaW5uZXIpKWAgaWYgYE9rYCwgYHRoaXNgIGlmIGBFcnJgCiAgICAgKiBAdGhyb3dzIGlmIGBva01hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIG1hcFN5bmMob2tNYXBwZXIpIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogTWFwIHRoZSBpbm5lciBlcnJvciBpbnRvIGFub3RoZXIKICAgICAqIEBwYXJhbSBlcnJNYXBwZXIKICAgICAqIEByZXR1cm5zIGBFcnIoYXdhaXQgZXJyTWFwcGVyKHRoaXMuaW5uZXIpKWAgaWYgYEVycmAsIGB0aGlzYCBpZiBgT2tgCiAgICAgKiBAdGhyb3dzIGlmIGBhd2FpdCBlcnJNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICBhc3luYyBtYXBFcnIoZXJyTWFwcGVyKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gbmV3IEVycihhd2FpdCBlcnJNYXBwZXIodGhpcy5pbm5lcikpOwogICAgfQogICAgLyoqCiAgICAgKiBNYXAgdGhlIGlubmVyIGVycm9yIGludG8gYW5vdGhlcgogICAgICogQHBhcmFtIGVyck1hcHBlcgogICAgICogQHJldHVybnMgYEVycihlcnJNYXBwZXIodGhpcy5pbm5lcikpYCBpZiBgRXJyYCwgYHRoaXNgIGlmIGBPa2AKICAgICAqIEB0aHJvd3MgaWYgYGVyck1hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIG1hcEVyclN5bmMoZXJyTWFwcGVyKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gbmV3IEVycihlcnJNYXBwZXIodGhpcy5pbm5lcikpOwogICAgfQogICAgLyoqCiAgICAgKiBNYXAgdGhlIGlubmVyIHZhbHVlIGludG8gYW5vdGhlciwgb3IgYSBkZWZhdWx0IG9uZQogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcGFyYW0gb2tNYXBwZXIKICAgICAqIEByZXR1cm5zIGBhd2FpdCBva01hcHBlcih0aGlzLmlubmVyKWAgaWYgYE9rYCwgYHZhbHVlYCBpZiBgRXJyYAogICAgICogQHRocm93cyBpZiBgYXdhaXQgb2tNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICBhc3luYyBtYXBPcih2YWx1ZSwgb2tNYXBwZXIpIHsKICAgICAgICB0aGlzLmlnbm9yZSgpOwogICAgICAgIHJldHVybiB2YWx1ZTsKICAgIH0KICAgIC8qKgogICAgICogTWFwIHRoZSBpbm5lciB2YWx1ZSBpbnRvIGFub3RoZXIsIG9yIGEgZGVmYXVsdCBvbmUKICAgICAqIEBwYXJhbSB2YWx1ZQogICAgICogQHBhcmFtIG9rTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgb2tNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBPa2AsIGB2YWx1ZWAgaWYgYEVycmAKICAgICAqIEB0aHJvd3MgaWYgYG9rTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgbWFwT3JTeW5jKHZhbHVlLCBva01hcHBlcikgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIHZhbHVlOwogICAgfQogICAgLyoqCiAgICAgKiBNYXAgdGhlIGlubmVyIHZhbHVlIGludG8gYW5vdGhlciwgb3IgYSBkZWZhdWx0IG9uZQogICAgICogQHBhcmFtIGVyck1hcHBlcgogICAgICogQHBhcmFtIG9rTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgYXdhaXQgb2tNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBPa2AsIGBhd2FpdCBlcnJNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBFcnJgCiAgICAgKiBAdGhyb3dzIGlmIGBhd2FpdCBva01hcHBlcih0aGlzLmlubmVyKWAgb3IgYGF3YWl0IGVyck1hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIGFzeW5jIG1hcE9yRWxzZShlcnJNYXBwZXIsIG9rTWFwcGVyKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gYXdhaXQgZXJyTWFwcGVyKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBNYXAgdGhlIGlubmVyIHZhbHVlIGludG8gYW5vdGhlciwgb3IgYSBkZWZhdWx0IG9uZQogICAgICogQHBhcmFtIGVyck1hcHBlcgogICAgICogQHBhcmFtIG9rTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgb2tNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBPa2AsIGBlcnJNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBFcnJgCiAgICAgKiBAdGhyb3dzIGlmIGBva01hcHBlcih0aGlzLmlubmVyKWAgb3IgYGVyck1hcHBlcih0aGlzLmlubmVyKWAgdGhyb3dzCiAgICAgKi8KICAgIG1hcE9yRWxzZVN5bmMoZXJyTWFwcGVyLCBva01hcHBlcikgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIGVyck1hcHBlcih0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJuIGB2YWx1ZWAgaWYgYE9rYCwgcmV0dXJuIGB0aGlzYCBpZiBgRXJyYAogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcmV0dXJucyBgdmFsdWVgIGlmIGBPa2AsIGB0aGlzYCBpZiBgRXJyYAogICAgICovCiAgICBhbmQodmFsdWUpIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJuIGBhd2FpdCBva01hcHBlcih0aGlzLmlubmVyKWAgaWYgYE9rYCwgcmV0dXJuIGB0aGlzYCBpZiBgRXJyYAogICAgICogQHBhcmFtIG9rTWFwcGVyCiAgICAgKiBAcmV0dXJucyBgYXdhaXQgb2tNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBPa2AsIGB0aGlzYCBpZiBgRXJyYAogICAgICogQHRocm93cyBpZiBgYXdhaXQgb2tNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICBhc3luYyBhbmRUaGVuKG9rTWFwcGVyKSB7CiAgICAgICAgcmV0dXJuIHRoaXM7CiAgICB9CiAgICAvKioKICAgICAqIFJldHVybiBgb2tNYXBwZXIodGhpcy5pbm5lcilgIGlmIGBPa2AsIHJldHVybiBgdGhpc2AgaWYgYEVycmAKICAgICAqIEBwYXJhbSBva01hcHBlcgogICAgICogQHJldHVybnMgYG9rTWFwcGVyKHRoaXMuaW5uZXIpYCBpZiBgT2tgLCBgdGhpc2AgaWYgYEVycmAKICAgICAqIEB0aHJvd3MgaWYgYG9rTWFwcGVyKHRoaXMuaW5uZXIpYCB0aHJvd3MKICAgICAqLwogICAgYW5kVGhlblN5bmMob2tNYXBwZXIpIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KICAgIC8qKgogICAgICogUmV0dXJuIGB2YWx1ZWAgaWYgYEVycmAsIHJldHVybiBgdGhpc2AgaWYgYE9rYAogICAgICogQHBhcmFtIHZhbHVlCiAgICAgKiBAcmV0dXJucyBgdmFsdWVgIGlmIGBFcnJgLCBgdGhpc2AgaWYgYE9rYAogICAgICovCiAgICBvcih2YWx1ZSkgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIHZhbHVlOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm4gYGF3YWl0IGVyck1hcHBlcih0aGlzLmlubmVyKWAgaWYgYEVycmAsIHJldHVybiBgdGhpc2AgaWYgYE9rYAogICAgICogQHBhcmFtIGVyck1hcHBlcgogICAgICogQHJldHVybnMgYGF3YWl0IGVyck1hcHBlcih0aGlzLmlubmVyKWAgaWYgYEVycmAsIGB0aGlzYCBpZiBgT2tgCiAgICAgKiBAdGhyb3dzIGlmIGBhd2FpdCBlcnJNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICBhc3luYyBvckVsc2UoZXJyTWFwcGVyKSB7CiAgICAgICAgdGhpcy5pZ25vcmUoKTsKICAgICAgICByZXR1cm4gYXdhaXQgZXJyTWFwcGVyKHRoaXMuaW5uZXIpOwogICAgfQogICAgLyoqCiAgICAgKiBSZXR1cm4gYGVyck1hcHBlcih0aGlzLmlubmVyKWAgaWYgYEVycmAsIHJldHVybiBgdGhpc2AgaWYgYE9rYAogICAgICogQHBhcmFtIGVyck1hcHBlcgogICAgICogQHJldHVybnMgYGVyck1hcHBlcih0aGlzLmlubmVyKWAgaWYgYEVycmAsIGB0aGlzYCBpZiBgT2tgCiAgICAgKiBAdGhyb3dzIGlmIGBlcnJNYXBwZXIodGhpcy5pbm5lcilgIHRocm93cwogICAgICovCiAgICBvckVsc2VTeW5jKGVyck1hcHBlcikgewogICAgICAgIHRoaXMuaWdub3JlKCk7CiAgICAgICAgcmV0dXJuIGVyck1hcHBlcih0aGlzLmlubmVyKTsKICAgIH0KICAgIC8qKgogICAgICogVHJhbnNmb3JtIFJlc3VsdDxSZXN1bHQ8VCwgRTE+LCBFMj4gaW50byBSZXN1bHQ8VCwgRTEgfCBFMj4KICAgICAqIEBwYXJhbSByZXN1bHQKICAgICAqIEByZXR1cm5zIGB0aGlzYCBpZiBgRXJyYCwgYHRoaXMuaW5uZXJgIGlmIGBPa2AKICAgICAqLwogICAgZmxhdHRlbigpIHsKICAgICAgICByZXR1cm4gdGhpczsKICAgIH0KfQoKCi8vIyBzb3VyY2VNYXBwaW5nVVJMPWVyci5tanMubWFwCgo7Ly8gQ09OQ0FURU5BVEVEIE1PRFVMRTogLi9ub2RlX21vZHVsZXMvQGhhemFlNDEvanNvbnJwYy9kaXN0L2VzbS9tb2RzL3JwYy9lcnIubWpzCgoKY2xhc3MgUnBjRXJyb3IgZXh0ZW5kcyBFcnJvciB7CiAgICBjb2RlOwogICAgbWVzc2FnZTsKICAgIGRhdGE7CiAgICAjY2xhc3MgPSBScGNFcnJvcjsKICAgIG5hbWUgPSB0aGlzLiNjbGFzcy5uYW1lOwogICAgc3RhdGljIGNvZGVzID0gewogICAgICAgIFBhcnNlRXJyb3I6IC0zMjcwMCwKICAgICAgICBJbnZhbGlkUmVxdWVzdDogLTMyNjAwLAogICAgICAgIE1ldGhvZE5vdEZvdW5kOiAtMzI2MDEsCiAgICAgICAgSW52YWxpZFBhcmFtczogLTMyNjAyLAogICAgICAgIEludGVybmFsRXJyb3I6IC0zMjYwMwogICAgfTsKICAgIHN0YXRpYyBtZXNzYWdlcyA9IHsKICAgICAgICBQYXJzZUVycm9yOiAiUGFyc2UgZXJyb3IiLAogICAgICAgIEludmFsaWRSZXF1ZXN0OiAiSW52YWxpZCBSZXF1ZXN0IiwKICAgICAgICBNZXRob2ROb3RGb3VuZDogIk1ldGhvZCBub3QgZm91bmQiLAogICAgICAgIEludmFsaWRQYXJhbXM6ICJJbnZhbGlkIHBhcmFtcyIsCiAgICAgICAgSW50ZXJuYWxFcnJvcjogIkludGVybmFsIGVycm9yIiwKICAgICAgICBTZXJ2ZXJFcnJvcjogIlNlcnZlciBlcnJvciIKICAgIH07CiAgICBjb25zdHJ1Y3Rvcihjb2RlLCBtZXNzYWdlLCBkYXRhID0gdW5kZWZpbmVkKSB7CiAgICAgICAgc3VwZXIobWVzc2FnZSk7CiAgICAgICAgdGhpcy5jb2RlID0gY29kZTsKICAgICAgICB0aGlzLm1lc3NhZ2UgPSBtZXNzYWdlOwogICAgICAgIHRoaXMuZGF0YSA9IGRhdGE7CiAgICB9CiAgICBzdGF0aWMgZnJvbShpbml0KSB7CiAgICAgICAgY29uc3QgeyBjb2RlLCBtZXNzYWdlLCBkYXRhIH0gPSBpbml0OwogICAgICAgIHJldHVybiBuZXcgUnBjRXJyb3IoY29kZSwgbWVzc2FnZSwgZGF0YSk7CiAgICB9CiAgICBzdGF0aWMgcmV3cmFwKGVycm9yKSB7CiAgICAgICAgaWYgKGVycm9yIGluc3RhbmNlb2YgUnBjRXJyb3IpCiAgICAgICAgICAgIHJldHVybiBlcnJvcjsKICAgICAgICBpZiAoZXJyb3IgaW5zdGFuY2VvZiBFcnJvcikKICAgICAgICAgICAgcmV0dXJuIG5ldyBScGNJbnRlcm5hbEVycm9yKGVycm9yLm1lc3NhZ2UpOwogICAgICAgIHJldHVybiBuZXcgUnBjSW50ZXJuYWxFcnJvcigpOwogICAgfQogICAgLyoqCiAgICAgKiBVc2VkIGJ5IEpTT04uc3RyaW5naWZ5CiAgICAgKi8KICAgIHRvSlNPTigpIHsKICAgICAgICBjb25zdCB7IGNvZGUsIG1lc3NhZ2UsIGRhdGEgfSA9IHRoaXM7CiAgICAgICAgcmV0dXJuIHsgY29kZSwgbWVzc2FnZSwgZGF0YSB9OwogICAgfQp9CmNsYXNzIFJwY1BhcnNlRXJyb3IgZXh0ZW5kcyBScGNFcnJvciB7CiAgICAjY2xhc3MgPSBScGNQYXJzZUVycm9yOwogICAgbmFtZSA9IHRoaXMuI2NsYXNzLm5hbWU7CiAgICBzdGF0aWMgY29kZSA9IFJwY0Vycm9yLmNvZGVzLlBhcnNlRXJyb3I7CiAgICBzdGF0aWMgbWVzc2FnZSA9IFJwY0Vycm9yLm1lc3NhZ2VzLlBhcnNlRXJyb3I7CiAgICBjb25zdHJ1Y3RvcihtZXNzYWdlID0gUnBjRXJyb3IubWVzc2FnZXMuUGFyc2VFcnJvcikgewogICAgICAgIHN1cGVyKFJwY0Vycm9yLmNvZGVzLlBhcnNlRXJyb3IsIG1lc3NhZ2UpOwogICAgfQp9CmNsYXNzIFJwY0ludmFsaWRSZXF1ZXN0RXJyb3IgZXh0ZW5kcyBScGNFcnJvciB7CiAgICAjY2xhc3MgPSBScGNJbnZhbGlkUmVxdWVzdEVycm9yOwogICAgbmFtZSA9IHRoaXMuI2NsYXNzLm5hbWU7CiAgICBzdGF0aWMgY29kZSA9IFJwY0Vycm9yLmNvZGVzLkludmFsaWRSZXF1ZXN0OwogICAgc3RhdGljIG1lc3NhZ2UgPSBScGNFcnJvci5tZXNzYWdlcy5JbnZhbGlkUmVxdWVzdDsKICAgIGNvbnN0cnVjdG9yKG1lc3NhZ2UgPSBScGNFcnJvci5tZXNzYWdlcy5JbnZhbGlkUmVxdWVzdCkgewogICAgICAgIHN1cGVyKFJwY0Vycm9yLmNvZGVzLkludmFsaWRSZXF1ZXN0LCBtZXNzYWdlKTsKICAgIH0KfQpjbGFzcyBScGNNZXRob2ROb3RGb3VuZEVycm9yIGV4dGVuZHMgUnBjRXJyb3IgewogICAgI2NsYXNzID0gUnBjTWV0aG9kTm90Rm91bmRFcnJvcjsKICAgIG5hbWUgPSB0aGlzLiNjbGFzcy5uYW1lOwogICAgc3RhdGljIGNvZGUgPSBScGNFcnJvci5jb2Rlcy5NZXRob2ROb3RGb3VuZDsKICAgIHN0YXRpYyBtZXNzYWdlID0gUnBjRXJyb3IubWVzc2FnZXMuTWV0aG9kTm90Rm91bmQ7CiAgICBjb25zdHJ1Y3RvcihtZXNzYWdlID0gUnBjRXJyb3IubWVzc2FnZXMuTWV0aG9kTm90Rm91bmQpIHsKICAgICAgICBzdXBlcihScGNFcnJvci5jb2Rlcy5NZXRob2ROb3RGb3VuZCwgbWVzc2FnZSk7CiAgICB9Cn0KY2xhc3MgUnBjSW52YWxpZFBhcmFtc0Vycm9yIGV4dGVuZHMgUnBjRXJyb3IgewogICAgI2NsYXNzID0gUnBjSW52YWxpZFBhcmFtc0Vycm9yOwogICAgbmFtZSA9IHRoaXMuI2NsYXNzLm5hbWU7CiAgICBzdGF0aWMgY29kZSA9IFJwY0Vycm9yLmNvZGVzLkludmFsaWRQYXJhbXM7CiAgICBzdGF0aWMgbWVzc2FnZSA9IFJwY0Vycm9yLm1lc3NhZ2VzLkludmFsaWRQYXJhbXM7CiAgICBjb25zdHJ1Y3RvcihtZXNzYWdlID0gUnBjRXJyb3IubWVzc2FnZXMuSW52YWxpZFBhcmFtcykgewogICAgICAgIHN1cGVyKFJwY0Vycm9yLmNvZGVzLkludmFsaWRQYXJhbXMsIG1lc3NhZ2UpOwogICAgfQp9CmNsYXNzIFJwY0ludGVybmFsRXJyb3IgZXh0ZW5kcyBScGNFcnJvciB7CiAgICAjY2xhc3MgPSBScGNJbnRlcm5hbEVycm9yOwogICAgbmFtZSA9IHRoaXMuI2NsYXNzLm5hbWU7CiAgICBzdGF0aWMgY29kZSA9IFJwY0Vycm9yLmNvZGVzLkludGVybmFsRXJyb3I7CiAgICBzdGF0aWMgbWVzc2FnZSA9IFJwY0Vycm9yLm1lc3NhZ2VzLkludGVybmFsRXJyb3I7CiAgICBjb25zdHJ1Y3RvcihtZXNzYWdlID0gUnBjRXJyb3IubWVzc2FnZXMuSW50ZXJuYWxFcnJvcikgewogICAgICAgIHN1cGVyKFJwY0Vycm9yLmNvZGVzLkludGVybmFsRXJyb3IsIG1lc3NhZ2UpOwogICAgfQp9CmNsYXNzIFJwY0VyciBleHRlbmRzIEVyciB7CiAgICBpZDsKICAgIGVycm9yOwogICAganNvbnJwYyA9ICIyLjAiOwogICAgY29uc3RydWN0b3IoaWQsIGVycm9yKSB7CiAgICAgICAgc3VwZXIoZXJyb3IpOwogICAgICAgIHRoaXMuaWQgPSBpZDsKICAgICAgICB0aGlzLmVycm9yID0gZXJyb3I7CiAgICB9CiAgICBzdGF0aWMgZnJvbShpbml0KSB7CiAgICAgICAgcmV0dXJuIG5ldyBScGNFcnIoaW5pdC5pZCwgUnBjRXJyb3IuZnJvbShpbml0LmVycm9yKSk7CiAgICB9CiAgICBzdGF0aWMgcmV3cmFwKGlkLCByZXN1bHQpIHsKICAgICAgICByZXR1cm4gbmV3IFJwY0VycihpZCwgUnBjRXJyb3IucmV3cmFwKHJlc3VsdC5pbm5lcikpOwogICAgfQp9CgoKLy8jIHNvdXJjZU1hcHBpbmdVUkw9ZXJyLm1qcy5tYXAKCjsvLyBDT05DQVRFTkFURUQgTU9EVUxFOiAuL25vZGVfbW9kdWxlcy9AaGF6YWU0MS9qc29ucnBjL2Rpc3QvZXNtL21vZHMvcnBjL29rLm1qcwoKCnZhciBScGNPa0luaXQ7CihmdW5jdGlvbiAoUnBjT2tJbml0KSB7CiAgICBmdW5jdGlvbiBmcm9tKHJlc3BvbnNlKSB7CiAgICAgICAgY29uc3QgeyBqc29ucnBjLCBpZCwgcmVzdWx0IH0gPSByZXNwb25zZTsKICAgICAgICByZXR1cm4geyBqc29ucnBjLCBpZCwgcmVzdWx0IH07CiAgICB9CiAgICBScGNPa0luaXQuZnJvbSA9IGZyb207Cn0pKFJwY09rSW5pdCB8fCAoUnBjT2tJbml0ID0ge30pKTsKY2xhc3MgUnBjT2sgZXh0ZW5kcyBPayB7CiAgICBpZDsKICAgIHJlc3VsdDsKICAgIGpzb25ycGMgPSAiMi4wIjsKICAgIGNvbnN0cnVjdG9yKGlkLCByZXN1bHQpIHsKICAgICAgICBzdXBlcihyZXN1bHQpOwogICAgICAgIHRoaXMuaWQgPSBpZDsKICAgICAgICB0aGlzLnJlc3VsdCA9IHJlc3VsdDsKICAgIH0KICAgIHN0YXRpYyBmcm9tKGluaXQpIHsKICAgICAgICByZXR1cm4gbmV3IFJwY09rKGluaXQuaWQsIGluaXQucmVzdWx0KTsKICAgIH0KICAgIHN0YXRpYyByZXdyYXAoaWQsIHJlc3VsdCkgewogICAgICAgIHJldHVybiBuZXcgUnBjT2soaWQsIHJlc3VsdC5pbm5lcik7CiAgICB9Cn0KCgovLyMgc291cmNlTWFwcGluZ1VSTD1vay5tanMubWFwCgo7Ly8gQ09OQ0FURU5BVEVEIE1PRFVMRTogLi9ub2RlX21vZHVsZXMvQGhhemFlNDEvanNvbnJwYy9kaXN0L2VzbS9tb2RzL3JwYy9yZXNwb25zZS5tanMKCgoKdmFyIFJwY1Jlc3BvbnNlOwooZnVuY3Rpb24gKFJwY1Jlc3BvbnNlKSB7CiAgICBmdW5jdGlvbiBmcm9tKGluaXQpIHsKICAgICAgICBpZiAoImVycm9yIiBpbiBpbml0KQogICAgICAgICAgICByZXR1cm4gUnBjRXJyLmZyb20oaW5pdCk7CiAgICAgICAgcmV0dXJuIFJwY09rLmZyb20oaW5pdCk7CiAgICB9CiAgICBScGNSZXNwb25zZS5mcm9tID0gZnJvbTsKICAgIGZ1bmN0aW9uIHJld3JhcChpZCwgcmVzdWx0KSB7CiAgICAgICAgaWYgKHJlc3VsdC5pc0VycigpKQogICAgICAgICAgICByZXR1cm4gUnBjRXJyLnJld3JhcChpZCwgcmVzdWx0KTsKICAgICAgICByZXR1cm4gUnBjT2sucmV3cmFwKGlkLCByZXN1bHQpOwogICAgfQogICAgUnBjUmVzcG9uc2UucmV3cmFwID0gcmV3cmFwOwp9KShScGNSZXNwb25zZSB8fCAoUnBjUmVzcG9uc2UgPSB7fSkpOwoKCi8vIyBzb3VyY2VNYXBwaW5nVVJMPXJlc3BvbnNlLm1qcy5tYXAKCjsvLyBDT05DQVRFTkFURUQgTU9EVUxFOiAuL25vZGVfbW9kdWxlcy9AaGF6YWU0MS9qc29ucnBjL2Rpc3QvZXNtL21vZHMvcnBjL3JlcXVlc3QubWpzCmNsYXNzIFJwY1JlcXVlc3QgewogICAgaWQ7CiAgICBtZXRob2Q7CiAgICBwYXJhbXM7CiAgICBqc29ucnBjID0gIjIuMCI7CiAgICBjb25zdHJ1Y3RvcihpZCwgbWV0aG9kLCBwYXJhbXMpIHsKICAgICAgICB0aGlzLmlkID0gaWQ7CiAgICAgICAgdGhpcy5tZXRob2QgPSBtZXRob2Q7CiAgICAgICAgdGhpcy5wYXJhbXMgPSBwYXJhbXM7CiAgICB9CiAgICBzdGF0aWMgZnJvbShpbml0KSB7CiAgICAgICAgY29uc3QgeyBpZCwgbWV0aG9kLCBwYXJhbXMgfSA9IGluaXQ7CiAgICAgICAgcmV0dXJuIG5ldyBScGNSZXF1ZXN0KGlkLCBtZXRob2QsIHBhcmFtcyk7CiAgICB9CiAgICB0b0pTT04oKSB7CiAgICAgICAgY29uc3QgeyBqc29ucnBjLCBpZCwgbWV0aG9kLCBwYXJhbXMgfSA9IHRoaXM7CiAgICAgICAgcmV0dXJuIHsganNvbnJwYywgaWQsIG1ldGhvZCwgcGFyYW1zIH07CiAgICB9Cn0KCgovLyMgc291cmNlTWFwcGluZ1VSTD1yZXF1ZXN0Lm1qcy5tYXAKCjsvLyBDT05DQVRFTkFURUQgTU9EVUxFOiAuL25vZGVfbW9kdWxlcy9AaGF6YWU0MS9qc29ucnBjL2Rpc3QvZXNtL21vZHMvcnBjL3JwYy5tanMKCgpjbGFzcyBScGNDb3VudGVyIHsKICAgIGlkID0gMDsKICAgIHByZXBhcmUoaW5pdCkgewogICAgICAgIGNvbnN0IHsgaWQgPSB0aGlzLmlkKyssIG1ldGhvZCwgcGFyYW1zIH0gPSBpbml0OwogICAgICAgIHJldHVybiBuZXcgUnBjUmVxdWVzdChpZCwgbWV0aG9kLCBwYXJhbXMpOwogICAgfQp9CgoKLy8jIHNvdXJjZU1hcHBpbmdVUkw9cnBjLm1qcy5tYXAKCjsvLyBDT05DQVRFTkFURUQgTU9EVUxFOiAuL3NyYy9tb2RzL2JhY2tncm91bmQvaW5qZWN0ZWRfc2NyaXB0L2luZGV4LnRzCgoKCgpjbGFzcyBQcm92aWRlciB7CiAgICBnZXQgaXNCcnVtZSgpIHsKICAgICAgICByZXR1cm4gdHJ1ZTsKICAgIH0KICAgIGdldCBpc01ldGFNYXNrKCkgewogICAgICAgIHJldHVybiB0cnVlOwogICAgfQogICAgLyoqCiAgICAgKiBAZGVwcmVjYXRlZAogICAgICovIGlzQ29ubmVjdGVkKCkgewogICAgICAgIHJldHVybiB0cnVlOwogICAgfQogICAgLyoqCiAgICAgKiBAZGVwcmVjYXRlZAogICAgICovIGlzVW5sb2NrZWQoKSB7CiAgICAgICAgcmV0dXJuIHRydWU7CiAgICB9CiAgICAvKioKICAgICAqIEBkZXByZWNhdGVkCiAgICAgKi8gZ2V0IGNoYWluSWQoKSB7CiAgICAgICAgcmV0dXJuIHRoaXMuX2NoYWluSWQ7CiAgICB9CiAgICAvKioKICAgICAqIEBkZXByZWNhdGVkCiAgICAgKi8gZ2V0IG5ldHdvcmtWZXJzaW9uKCkgewogICAgICAgIHJldHVybiB0aGlzLl9uZXR3b3JrVmVyc2lvbjsKICAgIH0KICAgIC8qKgogICAgICogQGRlcHJlY2F0ZWQKICAgICAqLyBnZXQgc2VsZWN0ZWRBZGRyZXNzKCkgewogICAgICAgIHJldHVybiB0aGlzLl9hY2NvdW50c1swXTsKICAgIH0KICAgIC8qKgogICAgICogQGRlcHJlY2F0ZWQKICAgICAqLyBnZXQgX21ldGFtYXNrKCkgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBAZGVwcmVjYXRlZAogICAgICovIGV2ZW50TmFtZXMoKSB7CiAgICAgICAgcmV0dXJuIFsKICAgICAgICAgICAgImNvbm5lY3QiLAogICAgICAgICAgICAiZGlzY29ubmVjdCIsCiAgICAgICAgICAgICJjaGFpbkNoYW5nZWQiLAogICAgICAgICAgICAiYWNjb3VudHNDaGFuZ2VkIiwKICAgICAgICAgICAgIm5ldHdvcmtDaGFuZ2VkIgogICAgICAgIF07CiAgICB9CiAgICAvKioKICAgICAqIEBkZXByZWNhdGVkCiAgICAgKi8gZ2V0TWF4TGlzdGVuZXJzKCkgewogICAgICAgIHJldHVybiBOdW1iZXIuTUFYX1NBRkVfSU5URUdFUjsKICAgIH0KICAgIC8qKgogICAgICogQGRlcHJlY2F0ZWQKICAgICAqLyBzZXRNYXhMaXN0ZW5lcnMoeCkgewogICAgICAgIHJldHVybiB0aGlzOwogICAgfQogICAgLyoqCiAgICAgKiBAZGVwcmVjYXRlZAogICAgICovIGxpc3RlbmVyQ291bnQoKSB7CiAgICAgICAgcmV0dXJuIHRoaXMuX2xpc3RlbmVyQ291bnQ7CiAgICB9CiAgICAvKioKICAgICAqIEBkZXByZWNhdGVkCiAgICAgKi8gbGlzdGVuZXJzKGtleSkgewogICAgICAgIGNvbnN0IGxpc3RlbmVycyA9IHRoaXMuX2xpc3RlbmVyc0J5RXZlbnQuZ2V0KGtleSk7CiAgICAgICAgaWYgKGxpc3RlbmVycyA9PSBudWxsKSByZXR1cm4gW107CiAgICAgICAgcmV0dXJuIFsKICAgICAgICAgICAgLi4ubGlzdGVuZXJzCiAgICAgICAgXTsKICAgIH0KICAgIC8qKgogICAgICogQGRlcHJlY2F0ZWQKICAgICAqLyByYXdMaXN0ZW5lcnMoa2V5KSB7CiAgICAgICAgcmV0dXJuIHRoaXMubGlzdGVuZXJzKGtleSk7CiAgICB9CiAgICAvKioKICAgICAqIEBkZXByZWNhdGVkCiAgICAgKi8gYXN5bmMgZW5hYmxlKCkgewogICAgICAgIC8qKgogICAgICAgICAqIEVuYWJsZSBjb21wYXRpYmlsaXR5IG1vZGUgZm9yIHRoYXQgb2xkIGFwcCB0aGF0IG5lZWRzIHRvIHJlbG9hZCBvbiBuZXR3b3JrIGNoYW5nZQogICAgICAgICAqLyB0aGlzLmF1dG9SZWZyZXNoT25OZXR3b3JrQ2hhbmdlID0gdHJ1ZTsKICAgICAgICByZXR1cm4gYXdhaXQgdGhpcy5yZXF1ZXN0KHsKICAgICAgICAgICAgaWQ6IG51bGwsCiAgICAgICAgICAgIG1ldGhvZDogImV0aF9yZXF1ZXN0QWNjb3VudHMiCiAgICAgICAgfSk7CiAgICB9CiAgICBhc3luYyByZXF1ZXN0QW5kV3JhcChyZXFpbml0KSB7CiAgICAgICAgY29uc3QgcmVxdWVzdCA9IHRoaXMuX2NvdW50ZXIucHJlcGFyZShyZXFpbml0KTsKICAgICAgICBjb25zdCBmdXR1cmUgPSBuZXcgRnV0dXJlKCk7CiAgICAgICAgY29uc3Qgb25SZXNwb25zZSA9IChlKT0+ewogICAgICAgICAgICBjb25zdCByZXNpbml0ID0gSlNPTi5wYXJzZShlLmRldGFpbCk7CiAgICAgICAgICAgIGlmIChyZXNpbml0LmlkICE9PSByZXF1ZXN0LmlkKSByZXR1cm47CiAgICAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gUnBjUmVzcG9uc2UuZnJvbShyZXNpbml0KTsKICAgICAgICAgICAgY29uc3QgcmV3cmFwcGVkID0gUnBjUmVzcG9uc2UucmV3cmFwKHJlcWluaXQuaWQsIHJlc3BvbnNlKTsKICAgICAgICAgICAgZnV0dXJlLnJlc29sdmUocmV3cmFwcGVkKTsKICAgICAgICB9OwogICAgICAgIHRyeSB7CiAgICAgICAgICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCJldGhlcmV1bTpyZXNwb25zZSIsIG9uUmVzcG9uc2UpOwogICAgICAgICAgICBjb25zdCBkZXRhaWwgPSBKU09OLnN0cmluZ2lmeShyZXF1ZXN0KTsKICAgICAgICAgICAgY29uc3QgZXZlbnQgPSBuZXcgQ3VzdG9tRXZlbnQoImV0aGVyZXVtOnJlcXVlc3QiLCB7CiAgICAgICAgICAgICAgICBkZXRhaWwKICAgICAgICAgICAgfSk7CiAgICAgICAgICAgIHdpbmRvdy5kaXNwYXRjaEV2ZW50KGV2ZW50KTsKICAgICAgICAgICAgcmV0dXJuIGF3YWl0IGZ1dHVyZS5wcm9taXNlOwogICAgICAgIH0gZmluYWxseXsKICAgICAgICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoImV0aGVyZXVtOnJlc3BvbnNlIiwgb25SZXNwb25zZSk7CiAgICAgICAgfQogICAgfQogICAgYXN5bmMgcmVxdWVzdChpbml0KSB7CiAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgdGhpcy5yZXF1ZXN0QW5kV3JhcChpbml0KTsKICAgICAgICBpZiAocmVzdWx0LmlzRXJyKCkpIHRocm93IHJlc3VsdC5pbm5lcjsKICAgICAgICByZXR1cm4gcmVzdWx0LmlubmVyOwogICAgfQogICAgYXN5bmMgcmVxdWVzdEJhdGNoKGluaXRzKSB7CiAgICAgICAgcmV0dXJuIGF3YWl0IFByb21pc2UuYWxsKGluaXRzLm1hcCgoaW5pdCk9PnRoaXMucmVxdWVzdEFuZFdyYXAoaW5pdCkpKTsKICAgIH0KICAgIGFzeW5jIF9zZW5kKGluaXQsIGNhbGxiYWNrKSB7CiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCB0aGlzLnJlcXVlc3RBbmRXcmFwKGluaXQpOwogICAgICAgIGlmIChyZXNwb25zZS5pc0VycigpKSBjYWxsYmFjayhyZXNwb25zZS5pbm5lciwgcmVzcG9uc2UpOwogICAgICAgIGVsc2UgY2FsbGJhY2sobnVsbCwgcmVzcG9uc2UpOwogICAgfQogICAgLyoqCiAgICAgKiBAZGVwcmVjYXRlZAogICAgICovIHNlbmQoaW5pdCwgY2FsbGJhY2spIHsKICAgICAgICBpZiAodHlwZW9mIGluaXQgPT09ICJzdHJpbmciKSBpbml0ID0gewogICAgICAgICAgICBpZDogbnVsbCwKICAgICAgICAgICAgbWV0aG9kOiBpbml0CiAgICAgICAgfTsKICAgICAgICBpZiAoY2FsbGJhY2sgIT0gbnVsbCkgcmV0dXJuIHRoaXMuX3NlbmQoaW5pdCwgY2FsbGJhY2spOwogICAgICAgIGlmIChpbml0Lm1ldGhvZCA9PT0gImV0aF9hY2NvdW50cyIpIHJldHVybiBScGNPay5yZXdyYXAoaW5pdC5pZCwgbmV3IE9rKHRoaXMuX2FjY291bnRzKSk7CiAgICAgICAgaWYgKGluaXQubWV0aG9kID09PSAiZXRoX2NvaW5iYXNlIikgcmV0dXJuIFJwY09rLnJld3JhcChpbml0LmlkLCBuZXcgT2sodGhpcy5fYWNjb3VudHNbMF0pKTsKICAgICAgICBpZiAoaW5pdC5tZXRob2QgPT09ICJuZXRfdmVyc2lvbiIpIHJldHVybiBScGNPay5yZXdyYXAoaW5pdC5pZCwgbmV3IE9rKHRoaXMuX25ldHdvcmtWZXJzaW9uKSk7CiAgICAgICAgaWYgKGluaXQubWV0aG9kID09PSAiZXRoX3VuaW5zdGFsbEZpbHRlciIpIHRocm93IG5ldyBFcnJvcigiVW5pbXBsZW1lbnRlZCBtZXRob2QgIi5jb25jYXQoaW5pdC5tZXRob2QpKTsKICAgICAgICB0aHJvdyBuZXcgRXJyb3IoIkFzeW5jaHJvbm91cyBtZXRob2QgIi5jb25jYXQoaW5pdC5tZXRob2QsICIgcmVxdWlyZXMgYSBjYWxsYmFjayIpKTsKICAgIH0KICAgIC8qKgogICAgICogQGRlcHJlY2F0ZWQKICAgICAqLyBzZW5kQXN5bmMoaW5pdCwgY2FsbGJhY2spIHsKICAgICAgICBpZiAodHlwZW9mIGluaXQgPT09ICJzdHJpbmciKSBpbml0ID0gewogICAgICAgICAgICBpZDogbnVsbCwKICAgICAgICAgICAgbWV0aG9kOiBpbml0CiAgICAgICAgfTsKICAgICAgICB0aGlzLl9zZW5kKGluaXQsIGNhbGxiYWNrKTsKICAgIH0KICAgIF9yZWVtaXQoa2V5KSB7CiAgICAgICAgdGhpcy5fbGlzdGVuZXJzQnlFdmVudC5zZXQoa2V5LCBuZXcgU2V0KCkpOwogICAgICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCJldGhlcmV1bToiLmNvbmNhdChrZXkpLCAoZSk9PnsKICAgICAgICAgICAgdGhpcy5lbWl0KGtleSwgSlNPTi5wYXJzZShlLmRldGFpbCkpOwogICAgICAgIH0sIHsKICAgICAgICAgICAgcGFzc2l2ZTogdHJ1ZQogICAgICAgIH0pOwogICAgfQogICAgZW1pdChrZXkpIHsKICAgICAgICBmb3IodmFyIF9sZW4gPSBhcmd1bWVudHMubGVuZ3RoLCBwYXJhbXMgPSBuZXcgQXJyYXkoX2xlbiA+IDEgPyBfbGVuIC0gMSA6IDApLCBfa2V5ID0gMTsgX2tleSA8IF9sZW47IF9rZXkrKyl7CiAgICAgICAgICAgIHBhcmFtc1tfa2V5IC0gMV0gPSBhcmd1bWVudHNbX2tleV07CiAgICAgICAgfQogICAgICAgIGNvbnN0IGxpc3RlbmVycyA9IHRoaXMuX2xpc3RlbmVyc0J5RXZlbnQuZ2V0KGtleSk7CiAgICAgICAgaWYgKGxpc3RlbmVycyA9PSBudWxsKSByZXR1cm47CiAgICAgICAgZm9yIChjb25zdCBsaXN0ZW5lciBvZiBsaXN0ZW5lcnMpbGlzdGVuZXIoLi4ucGFyYW1zKTsKICAgICAgICByZXR1cm47CiAgICB9CiAgICBvbihrZXksIGxpc3RlbmVyKSB7CiAgICAgICAgdGhpcy5hZGRMaXN0ZW5lcihrZXksIGxpc3RlbmVyKTsKICAgIH0KICAgIG9mZihrZXksIGxpc3RlbmVyKSB7CiAgICAgICAgdGhpcy5yZW1vdmVMaXN0ZW5lcihrZXksIGxpc3RlbmVyKTsKICAgIH0KICAgIG9uY2Uoa2V5LCBsaXN0ZW5lcikgewogICAgICAgIHZhciBfdGhpcyA9IHRoaXM7CiAgICAgICAgY29uc3QgbGlzdGVuZXIyID0gZnVuY3Rpb24oKSB7CiAgICAgICAgICAgIGZvcih2YXIgX2xlbiA9IGFyZ3VtZW50cy5sZW5ndGgsIHBhcmFtcyA9IG5ldyBBcnJheShfbGVuKSwgX2tleSA9IDA7IF9rZXkgPCBfbGVuOyBfa2V5KyspewogICAgICAgICAgICAgICAgcGFyYW1zW19rZXldID0gYXJndW1lbnRzW19rZXldOwogICAgICAgICAgICB9CiAgICAgICAgICAgIGxpc3RlbmVyKC4uLnBhcmFtcyk7CiAgICAgICAgICAgIF90aGlzLm9mZihrZXksIGxpc3RlbmVyMik7CiAgICAgICAgfTsKICAgICAgICB0aGlzLm9uKGtleSwgbGlzdGVuZXIyKTsKICAgIH0KICAgIGFkZExpc3RlbmVyKGtleSwgbGlzdGVuZXIpIHsKICAgICAgICBjb25zdCBsaXN0ZW5lcnMgPSB0aGlzLl9saXN0ZW5lcnNCeUV2ZW50LmdldChrZXkpOwogICAgICAgIGlmIChsaXN0ZW5lcnMgPT0gbnVsbCkgcmV0dXJuOwogICAgICAgIHRoaXMuX2xpc3RlbmVyQ291bnQgLT0gbGlzdGVuZXJzLnNpemU7CiAgICAgICAgbGlzdGVuZXJzLmFkZChsaXN0ZW5lcik7CiAgICAgICAgdGhpcy5fbGlzdGVuZXJDb3VudCArPSBsaXN0ZW5lcnMuc2l6ZTsKICAgIH0KICAgIHJlbW92ZUxpc3RlbmVyKGtleSwgbGlzdGVuZXIpIHsKICAgICAgICBjb25zdCBsaXN0ZW5lcnMgPSB0aGlzLl9saXN0ZW5lcnNCeUV2ZW50LmdldChrZXkpOwogICAgICAgIGlmIChsaXN0ZW5lcnMgPT0gbnVsbCkgcmV0dXJuOwogICAgICAgIGlmICghbGlzdGVuZXJzLmRlbGV0ZShsaXN0ZW5lcikpIHJldHVybjsKICAgICAgICB0aGlzLl9saXN0ZW5lckNvdW50LS07CiAgICB9CiAgICByZW1vdmVBbGxMaXN0ZW5lcnMoa2V5KSB7CiAgICAgICAgY29uc3QgbGlzdGVuZXJzID0gdGhpcy5fbGlzdGVuZXJzQnlFdmVudC5nZXQoa2V5KTsKICAgICAgICBpZiAobGlzdGVuZXJzID09IG51bGwpIHJldHVybjsKICAgICAgICB0aGlzLl9saXN0ZW5lckNvdW50IC09IGxpc3RlbmVycy5zaXplOwogICAgICAgIGxpc3RlbmVycy5jbGVhcigpOwogICAgfQogICAgcHJlcGVuZExpc3RlbmVyKGtleSwgbGlzdGVuZXIpIHsKICAgICAgICBjb25zdCBsaXN0ZW5lcnMgPSB0aGlzLl9saXN0ZW5lcnNCeUV2ZW50LmdldChrZXkpOwogICAgICAgIGlmIChsaXN0ZW5lcnMgPT0gbnVsbCkgcmV0dXJuOwogICAgICAgIHRoaXMuX2xpc3RlbmVyQ291bnQgLT0gbGlzdGVuZXJzLnNpemU7CiAgICAgICAgY29uc3Qgb3JpZ2luYWwgPSBbCiAgICAgICAgICAgIC4uLmxpc3RlbmVycwogICAgICAgIF07CiAgICAgICAgbGlzdGVuZXJzLmNsZWFyKCk7CiAgICAgICAgbGlzdGVuZXJzLmFkZChsaXN0ZW5lcik7CiAgICAgICAgZm9yIChjb25zdCBsaXN0ZW5lciBvZiBvcmlnaW5hbClsaXN0ZW5lcnMuYWRkKGxpc3RlbmVyKTsKICAgICAgICB0aGlzLl9saXN0ZW5lckNvdW50ICs9IGxpc3RlbmVycy5zaXplOwogICAgfQogICAgcHJlcGVuZE9uY2VMaXN0ZW5lcihrZXksIGxpc3RlbmVyKSB7CiAgICAgICAgdmFyIF90aGlzID0gdGhpczsKICAgICAgICBjb25zdCBsaXN0ZW5lcjIgPSBmdW5jdGlvbigpIHsKICAgICAgICAgICAgZm9yKHZhciBfbGVuID0gYXJndW1lbnRzLmxlbmd0aCwgcGFyYW1zID0gbmV3IEFycmF5KF9sZW4pLCBfa2V5ID0gMDsgX2tleSA8IF9sZW47IF9rZXkrKyl7CiAgICAgICAgICAgICAgICBwYXJhbXNbX2tleV0gPSBhcmd1bWVudHNbX2tleV07CiAgICAgICAgICAgIH0KICAgICAgICAgICAgbGlzdGVuZXIoLi4ucGFyYW1zKTsKICAgICAgICAgICAgX3RoaXMub2ZmKGtleSwgbGlzdGVuZXIyKTsKICAgICAgICB9OwogICAgICAgIHRoaXMucHJlcGVuZExpc3RlbmVyKGtleSwgbGlzdGVuZXIyKTsKICAgIH0KICAgIGNvbnN0cnVjdG9yKCl7CiAgICAgICAgdGhpcy5fY291bnRlciA9IG5ldyBScGNDb3VudGVyKCk7CiAgICAgICAgdGhpcy5fbGlzdGVuZXJzQnlFdmVudCA9IG5ldyBNYXAoKTsKICAgICAgICAvKioKICAgICAqIEBkZXByZWNhdGVkCiAgICAgKi8gdGhpcy5hdXRvUmVmcmVzaE9uTmV0d29ya0NoYW5nZSA9IGZhbHNlOwogICAgICAgIC8qKgogICAgICogQGRlcHJlY2F0ZWQKICAgICAqLyB0aGlzLl9hY2NvdW50cyA9IG5ldyBBcnJheSgpOwogICAgICAgIC8qKgogICAgICogQGRlcHJlY2F0ZWQKICAgICAqLyB0aGlzLl9jaGFpbklkID0gIjB4MSI7CiAgICAgICAgLyoqCiAgICAgKiBAZGVwcmVjYXRlZAogICAgICovIHRoaXMuX25ldHdvcmtWZXJzaW9uID0gIjEiOwogICAgICAgIC8qKgogICAgICogQGRlcHJlY2F0ZWQKICAgICAqLyB0aGlzLl9saXN0ZW5lckNvdW50ID0gMDsKICAgICAgICAvKioKICAgICAgICAgKiBGaXggZm9yIHRoYXQgcG9vcmx5LWNvZGVkIGFwcCB0aGF0IGRvZXMgYGNvbnN0IHsgcmVxdWVzdCB9ID0gcHJvdmlkZXJgCiAgICAgICAgICovIHRoaXMucmVxdWVzdCA9IHRoaXMucmVxdWVzdC5iaW5kKHRoaXMpOwogICAgICAgIHRoaXMuc2VuZCA9IHRoaXMuc2VuZC5iaW5kKHRoaXMpOwogICAgICAgIHRoaXMuc2VuZEFzeW5jID0gdGhpcy5zZW5kQXN5bmMuYmluZCh0aGlzKTsKICAgICAgICB0aGlzLmVuYWJsZSA9IHRoaXMuZW5hYmxlLmJpbmQodGhpcyk7CiAgICAgICAgdGhpcy5pc0Nvbm5lY3RlZCA9IHRoaXMuaXNDb25uZWN0ZWQuYmluZCh0aGlzKTsKICAgICAgICB0aGlzLmlzVW5sb2NrZWQgPSB0aGlzLmlzVW5sb2NrZWQuYmluZCh0aGlzKTsKICAgICAgICB0aGlzLm9uID0gdGhpcy5vbi5iaW5kKHRoaXMpOwogICAgICAgIHRoaXMub2ZmID0gdGhpcy5vZmYuYmluZCh0aGlzKTsKICAgICAgICB0aGlzLm9uY2UgPSB0aGlzLm9uY2UuYmluZCh0aGlzKTsKICAgICAgICB0aGlzLmVtaXQgPSB0aGlzLmVtaXQuYmluZCh0aGlzKTsKICAgICAgICB0aGlzLmFkZExpc3RlbmVyID0gdGhpcy5hZGRMaXN0ZW5lci5iaW5kKHRoaXMpOwogICAgICAgIHRoaXMucmVtb3ZlTGlzdGVuZXIgPSB0aGlzLnJlbW92ZUxpc3RlbmVyLmJpbmQodGhpcyk7CiAgICAgICAgdGhpcy5wcmVwZW5kTGlzdGVuZXIgPSB0aGlzLnByZXBlbmRMaXN0ZW5lci5iaW5kKHRoaXMpOwogICAgICAgIHRoaXMucHJlcGVuZE9uY2VMaXN0ZW5lciA9IHRoaXMucHJlcGVuZE9uY2VMaXN0ZW5lci5iaW5kKHRoaXMpOwogICAgICAgIHRoaXMucmVtb3ZlQWxsTGlzdGVuZXJzID0gdGhpcy5yZW1vdmVBbGxMaXN0ZW5lcnMuYmluZCh0aGlzKTsKICAgICAgICB0aGlzLmV2ZW50TmFtZXMgPSB0aGlzLmV2ZW50TmFtZXMuYmluZCh0aGlzKTsKICAgICAgICB0aGlzLmxpc3RlbmVycyA9IHRoaXMubGlzdGVuZXJzLmJpbmQodGhpcyk7CiAgICAgICAgdGhpcy5yYXdMaXN0ZW5lcnMgPSB0aGlzLnJhd0xpc3RlbmVycy5iaW5kKHRoaXMpOwogICAgICAgIHRoaXMubGlzdGVuZXJDb3VudCA9IHRoaXMubGlzdGVuZXJDb3VudC5iaW5kKHRoaXMpOwogICAgICAgIHRoaXMuZ2V0TWF4TGlzdGVuZXJzID0gdGhpcy5nZXRNYXhMaXN0ZW5lcnMuYmluZCh0aGlzKTsKICAgICAgICB0aGlzLnNldE1heExpc3RlbmVycyA9IHRoaXMuc2V0TWF4TGlzdGVuZXJzLmJpbmQodGhpcyk7CiAgICAgICAgdGhpcy5fcmVlbWl0KCJjb25uZWN0Iik7CiAgICAgICAgdGhpcy5fcmVlbWl0KCJkaXNjb25uZWN0Iik7CiAgICAgICAgdGhpcy5fcmVlbWl0KCJhY2NvdW50c0NoYW5nZWQiKTsKICAgICAgICB0aGlzLl9yZWVtaXQoImNoYWluQ2hhbmdlZCIpOwogICAgICAgIHRoaXMuX3JlZW1pdCgibmV0d29ya0NoYW5nZWQiKTsKICAgICAgICB0aGlzLm9uKCJhY2NvdW50c0NoYW5nZWQiLCAoYWNjb3VudHMpPT57CiAgICAgICAgICAgIHRoaXMuX2FjY291bnRzID0gYWNjb3VudHM7CiAgICAgICAgfSk7CiAgICAgICAgdGhpcy5vbigiY2hhaW5DaGFuZ2VkIiwgKGNoYWluSWQpPT57CiAgICAgICAgICAgIHRoaXMuX2NoYWluSWQgPSBjaGFpbklkOwogICAgICAgIH0pOwogICAgICAgIC8qKgogICAgICAgICAqIEZpeCB0aGF0IG9sZCBhcHAgdGhhdCBuZWVkcyB0byByZWxvYWQgb24gbmV0d29yayBjaGFuZ2UKICAgICAgICAgKi8gdGhpcy5vbigibmV0d29ya0NoYW5nZWQiLCAobmV0d29ya1ZlcnNpb24pPT57CiAgICAgICAgICAgIHRoaXMuX25ldHdvcmtWZXJzaW9uID0gbmV0d29ya1ZlcnNpb247CiAgICAgICAgICAgIGlmICghdGhpcy5hdXRvUmVmcmVzaE9uTmV0d29ya0NoYW5nZSkgcmV0dXJuOwogICAgICAgICAgICBsb2NhdGlvbi5yZWxvYWQoKTsKICAgICAgICB9KTsKICAgIC8qKgogICAgICAgICAqIEZvcmNlIHVwZGF0ZSBvZiBgaXNDb25uZWN0ZWRgLCBgc2VsZWN0ZWRBZGRyZXNzYCwgYGNoYWluSWRgIGBuZXR3b3JrVmVyc2lvbmAKICAgICAgICAgKi8gLy8gVE9ETzogZml4IAogICAgLy8gdGhpcy5yZXF1ZXN0QW5kV3JhcCh7IGlkOiBudWxsLCBtZXRob2Q6ICJldGhfYWNjb3VudHMiIH0pLnRoZW4ociA9PiByLmlnbm9yZSgpKQogICAgfQp9Ci8qKgogKiBGaXggZm9yIHRoYXQgZXh0ZW5zaW9uIHRoYXQgZG9lcyBgT2JqZWN0LmFzc2lnbih3aW5kb3cuZXRoZXJldW0sIHsgLi4uIH0pYAogKi8gY29uc3QgaW5uZXIgPSBuZXcgUHJvdmlkZXIoKTsKY29uc3QgcHJvdmlkZXIgPSBuZXcgUHJveHkoe30sIHsKICAgIGdldCAodGFyZ2V0LCBwcm9wZXJ0eSwgcmVjZWl2ZXIpIHsKICAgICAgICByZXR1cm4gcHJvcGVydHkgaW4gdGFyZ2V0ID8gUmVmbGVjdC5nZXQodGFyZ2V0LCBwcm9wZXJ0eSwgcmVjZWl2ZXIpIDogUmVmbGVjdC5nZXQoaW5uZXIsIHByb3BlcnR5LCByZWNlaXZlcik7CiAgICB9LAogICAgc2V0ICh0YXJnZXQsIHByb3BlcnR5LCB2YWx1ZSwgcmVjZWl2ZXIpIHsKICAgICAgICByZXR1cm4gUmVmbGVjdC5zZXQodGFyZ2V0LCBwcm9wZXJ0eSwgdmFsdWUsIHJlY2VpdmVyKTsKICAgIH0KfSk7Ci8qKgogKiBFSVAtMTE5MyAobGVnYWN5KQogKi8gd2luZG93LmV0aGVyZXVtID0gcHJvdmlkZXI7Ci8qKgogKiBFSVAtNjk2MyAobW9kZXJuKQogKi8gY29uc3QgaWNvbiA9IG5ldyBGdXR1cmUoKTsKY29uc3Qgb25Mb2dvID0gKGV2ZW50KT0+ewogICAgaWNvbi5yZXNvbHZlKEpTT04ucGFyc2UoZXZlbnQuZGV0YWlsKSk7Cn07CndpbmRvdy5hZGRFdmVudExpc3RlbmVyKCJicnVtZTppY29uIiwgb25Mb2dvLCB7CiAgICBwYXNzaXZlOiB0cnVlLAogICAgb25jZTogdHJ1ZQp9KTsKYXN5bmMgZnVuY3Rpb24gYW5ub3VuY2UoKSB7CiAgICBjb25zdCBpbmZvID0gT2JqZWN0LmZyZWV6ZSh7CiAgICAgICAgdXVpZDogImU3NTBhOThjLWZmMmQtNGZjNC1iNmUyLWZhZjRkMTNkMWFkZCIsCiAgICAgICAgbmFtZTogIkJydW1lIFdhbGxldCIsCiAgICAgICAgaWNvbjogYXdhaXQgaWNvbi5wcm9taXNlLAogICAgICAgIHJkbnM6ICJtb25leS5icnVtZSIKICAgIH0pOwogICAgY29uc3QgZGV0YWlsID0gT2JqZWN0LmZyZWV6ZSh7CiAgICAgICAgaW5mbywKICAgICAgICBwcm92aWRlcgogICAgfSk7CiAgICBjb25zdCBldmVudCA9IG5ldyBDdXN0b21FdmVudCgiZWlwNjk2Mzphbm5vdW5jZVByb3ZpZGVyIiwgewogICAgICAgIGRldGFpbAogICAgfSk7CiAgICB3aW5kb3cuZGlzcGF0Y2hFdmVudChldmVudCk7Cn0KZnVuY3Rpb24gb25Bbm5vdW5jZVJlcXVlc3QoZXZlbnQpIHsKICAgIGFubm91bmNlKCk7Cn0Kd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoImVpcDY5NjM6cmVxdWVzdFByb3ZpZGVyIiwgb25Bbm5vdW5jZVJlcXVlc3QsIHsKICAgIHBhc3NpdmU6IHRydWUKfSk7CmFubm91bmNlKCk7CgovKioqKioqLyB9KSgpCjs=");
        const scriptUrl = _libs_browser_browser__WEBPACK_IMPORTED_MODULE_2__/* .browser */ .X.runtime.getURL("injected_script.js");
        const element = document.createElement("script");
        element.type = "text/javascript";
        element.textContent = "".concat(scriptBody, "\n//# sourceURL=").concat(scriptUrl);
        container.insertBefore(element, container.children[0]);
        container.removeChild(element);
    }
    async function getOrigin() {
        const origin = {
            origin: location.origin,
            title: document.title
        };
        for (const meta of document.getElementsByTagName("meta")){
            if (meta.name === "application-name") {
                origin.title = meta.content;
                continue;
            }
        }
        for (const link of document.getElementsByTagName("link")){
            if ([
                "icon",
                "shortcut icon",
                "icon shortcut"
            ].includes(link.rel)) {
                const blob = await (0,_libs_fetch_fetch__WEBPACK_IMPORTED_MODULE_6__/* .tryFetchAsBlob */ .l_)(link.href);
                if (blob.isErr()) continue;
                const data = await _libs_blobs_blobs__WEBPACK_IMPORTED_MODULE_1__/* .Blobs */ ._.tryReadAsDataUrl(blob.inner);
                if (data.isErr()) continue;
                origin.icon = data.inner;
                continue;
            }
            if (link.rel === "manifest") {
                const manifest = await (0,_libs_fetch_fetch__WEBPACK_IMPORTED_MODULE_6__/* .tryFetchAsJson */ .Br)(link.href);
                if (manifest.isErr()) continue;
                if (manifest.inner.name) origin.title = manifest.inner.name;
                if (manifest.inner.short_name) origin.title = manifest.inner.short_name;
                if (manifest.inner.description) origin.description = manifest.inner.description;
                continue;
            }
        }
        if (!origin.icon) {
            await (async ()=>{
                const blob = await (0,_libs_fetch_fetch__WEBPACK_IMPORTED_MODULE_6__/* .tryFetchAsBlob */ .l_)("/favicon.ico");
                if (blob.isErr()) return;
                const data = await _libs_blobs_blobs__WEBPACK_IMPORTED_MODULE_1__/* .Blobs */ ._.tryReadAsDataUrl(blob.inner);
                if (data.isErr()) return;
                origin.icon = data.inner;
            })();
        }
        return origin;
    }
    new _hazae41_piscine__WEBPACK_IMPORTED_MODULE_7__/* .Pool */ .Kg(async (params)=>{
        let connected = false;
        try {
            const env_1 = {
                stack: [],
                error: void 0,
                hasError: false
            };
            try {
                const { index, pool } = params;
                await new Promise((ok)=>setTimeout(ok, 1));
                const raw = _libs_browser_browser__WEBPACK_IMPORTED_MODULE_2__/* .BrowserError */ .v.runOrThrowSync(()=>{
                    const port = _libs_browser_browser__WEBPACK_IMPORTED_MODULE_2__/* .browser */ .X.runtime.connect({
                        name: "content_script->background"
                    });
                    port.onDisconnect.addListener(()=>void chrome.runtime.lastError);
                    return port;
                });
                const preChannel = __addDisposableResource(env_1, new _hazae41_box__WEBPACK_IMPORTED_MODULE_8__/* .Box */ .x(new _hazae41_disposer__WEBPACK_IMPORTED_MODULE_9__/* .Disposer */ .k(raw, ()=>raw.disconnect())), false);
                const preRouter = __addDisposableResource(env_1, new _hazae41_box__WEBPACK_IMPORTED_MODULE_8__/* .Box */ .x(new _libs_channel_channel__WEBPACK_IMPORTED_MODULE_3__/* .ExtensionRpcRouter */ .D("background", preChannel.inner.inner)), false);
                await preRouter.getOrThrow().waitHelloOrThrow(_libs_signals_signals__WEBPACK_IMPORTED_MODULE_4__/* .AbortSignals */ .f.timeout(1000));
                connected = true;
                const port = preChannel.moveOrThrow();
                const router = preRouter.moveOrThrow();
                const onWrapperClean = ()=>{
                    const env_2 = {
                        stack: [],
                        error: void 0,
                        hasError: false
                    };
                    try {
                        const _0 = __addDisposableResource(env_2, port, false);
                        const _1 = __addDisposableResource(env_2, router, false);
                    } catch (e_2) {
                        env_2.error = e_2;
                        env_2.hasError = true;
                    } finally{
                        __disposeResources(env_2);
                    }
                };
                const preWrapper = __addDisposableResource(env_1, new _hazae41_box__WEBPACK_IMPORTED_MODULE_8__/* .Box */ .x(new _hazae41_disposer__WEBPACK_IMPORTED_MODULE_9__/* .Disposer */ .k(router.inner, onWrapperClean)), false);
                const onScriptRequest = async (input)=>{
                    const request = JSON.parse(input.detail);
                    const result = await router.inner.tryRequest({
                        method: "brume_run",
                        params: [
                            request,
                            mouse
                        ]
                    });
                    const response = _hazae41_jsonrpc__WEBPACK_IMPORTED_MODULE_10__/* .RpcResponse */ .S.rewrap(request.id, result.flatten());
                    const detail = JSON.stringify(response);
                    const output = new CustomEvent("ethereum:response", {
                        detail
                    });
                    window.dispatchEvent(output);
                };
                const onAccountsChanged = async (request)=>{
                    const [accounts] = request.params;
                    const detail = JSON.stringify(accounts);
                    const event = new CustomEvent("ethereum:accountsChanged", {
                        detail
                    });
                    window.dispatchEvent(event);
                    return _hazae41_result__WEBPACK_IMPORTED_MODULE_11__.Ok.void();
                };
                const onConnect = async (request)=>{
                    const [{ chainId }] = request.params;
                    const detail = JSON.stringify({
                        chainId
                    });
                    const event = new CustomEvent("ethereum:connect", {
                        detail
                    });
                    window.dispatchEvent(event);
                    return _hazae41_result__WEBPACK_IMPORTED_MODULE_11__.Ok.void();
                };
                const onChainChanged = async (request)=>{
                    const [chainId] = request.params;
                    const detail = JSON.stringify(chainId);
                    const event = new CustomEvent("ethereum:chainChanged", {
                        detail
                    });
                    window.dispatchEvent(event);
                    return _hazae41_result__WEBPACK_IMPORTED_MODULE_11__.Ok.void();
                };
                const onNetworkChanged = async (request)=>{
                    const [chainId] = request.params;
                    const detail = JSON.stringify(chainId);
                    const event = new CustomEvent("ethereum:networkChanged", {
                        detail
                    });
                    window.dispatchEvent(event);
                    return _hazae41_result__WEBPACK_IMPORTED_MODULE_11__.Ok.void();
                };
                const onBackgroundRequest = async (request)=>{
                    if (request.method === "brume_origin") return new _hazae41_option__WEBPACK_IMPORTED_MODULE_12__/* .Some */ .b(new _hazae41_result__WEBPACK_IMPORTED_MODULE_11__.Ok(await getOrigin()));
                    if (request.method === "connect") return new _hazae41_option__WEBPACK_IMPORTED_MODULE_12__/* .Some */ .b(await onConnect(request));
                    if (request.method === "accountsChanged") return new _hazae41_option__WEBPACK_IMPORTED_MODULE_12__/* .Some */ .b(await onAccountsChanged(request));
                    if (request.method === "chainChanged") return new _hazae41_option__WEBPACK_IMPORTED_MODULE_12__/* .Some */ .b(await onChainChanged(request));
                    if (request.method === "networkChanged") return new _hazae41_option__WEBPACK_IMPORTED_MODULE_12__/* .Some */ .b(await onNetworkChanged(request));
                    return new _hazae41_option__WEBPACK_IMPORTED_MODULE_13__/* .None */ .H();
                };
                const onClose = async ()=>{
                    const event = new CustomEvent("ethereum:disconnect", {});
                    window.dispatchEvent(event);
                    pool.restart(index);
                    return new _hazae41_option__WEBPACK_IMPORTED_MODULE_13__/* .None */ .H();
                };
                window.addEventListener("ethereum:request", onScriptRequest, {
                    passive: true
                });
                router.inner.events.on("request", onBackgroundRequest, {
                    passive: true
                });
                router.inner.events.on("close", onClose, {
                    passive: true
                });
                const wrapper = preWrapper.moveOrThrow();
                const onEntryClean = ()=>{
                    const env_3 = {
                        stack: [],
                        error: void 0,
                        hasError: false
                    };
                    try {
                        const postinner = __addDisposableResource(env_3, wrapper, false);
                        window.removeEventListener("ethereum:request", onScriptRequest);
                        router.inner.events.off("request", onBackgroundRequest);
                        router.inner.events.off("close", onClose);
                    } catch (e_3) {
                        env_3.error = e_3;
                        env_3.hasError = true;
                    } finally{
                        __disposeResources(env_3);
                    }
                };
                const preEntry = __addDisposableResource(env_1, new _hazae41_box__WEBPACK_IMPORTED_MODULE_8__/* .Box */ .x(new _hazae41_disposer__WEBPACK_IMPORTED_MODULE_9__/* .Disposer */ .k(wrapper, onEntryClean)), false);
                const icon = await router.inner.requestOrThrow({
                    method: "brume_icon"
                }, _libs_signals_signals__WEBPACK_IMPORTED_MODULE_4__/* .AbortSignals */ .f.never()).then((r)=>r.unwrap());
                const detail = JSON.stringify(icon);
                const event = new CustomEvent("brume:icon", {
                    detail
                });
                window.dispatchEvent(event);
                return preEntry.unwrapOrThrow();
            } catch (e_1) {
                env_1.error = e_1;
                env_1.hasError = true;
            } finally{
                __disposeResources(env_1);
            }
        } catch (e) {
            if (!(0,_libs_platform_platform__WEBPACK_IMPORTED_MODULE_5__/* .isSafariExtension */ .WB)()) throw e;
            if (connected) throw e;
            if (sessionStorage.getItem("brume:opened")) throw e;
            sessionStorage.setItem("brume:opened", "true");
            const opener = _libs_browser_browser__WEBPACK_IMPORTED_MODULE_2__/* .BrowserError */ .v.runOrThrowSync(()=>_libs_browser_browser__WEBPACK_IMPORTED_MODULE_2__/* .browser */ .X.runtime.getURL("/opener.html"));
            const opened = (0,_libs_url_url__WEBPACK_IMPORTED_MODULE_14__/* .qurl */ .d)(opener, {
                url: location.href
            });
            location.replace(opened);
            throw e;
        }
    }, {
        capacity: 1
    });
}
await main();

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } }, 1);

/***/ }),

/***/ 200:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   x: () => (/* binding */ Box)
/* harmony export */ });
/* unused harmony export BoxMovedError */
/* harmony import */ var _hazae41_result__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(166);
/* harmony import */ var _hazae41_result__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(591);


var _a;
class BoxMovedError extends Error {
    #class = _a;
    name = this.#class.name;
    constructor() {
        super(`Box has been moved`);
    }
}
_a = BoxMovedError;
class Box {
    inner;
    #moved = false;
    /**
     * Object that uniquely owns a type T and can dispose it
     */
    constructor(inner) {
        this.inner = inner;
    }
    [Symbol.dispose]() {
        if (this.#moved)
            return;
        this.inner[Symbol.dispose]();
    }
    /**
     * Create a new Box
     * @param inner
     * @returns
     */
    static new(inner) {
        return new Box(inner);
    }
    /**
     * Create a new Box that's already moved
     * @param inner
     * @returns
     */
    static greedy(inner) {
        const box = new Box(inner);
        box.#moved = true;
        return box;
    }
    get moved() {
        return this.#moved;
    }
    get() {
        if (this.#moved)
            return undefined;
        return this.inner;
    }
    /**
     * Just get the inner value
     * @returns T
     * @throws BoxMovedError if moved
     */
    getOrThrow() {
        if (this.#moved)
            throw new BoxMovedError();
        return this.inner;
    }
    /**
     * Just get the inner value
     * @returns Ok<T> or Err<BoxMovedError> if moved
     */
    tryGet() {
        if (this.#moved)
            return new _hazae41_result__WEBPACK_IMPORTED_MODULE_0__/* .Err */ .U(new BoxMovedError());
        return new _hazae41_result__WEBPACK_IMPORTED_MODULE_1__.Ok(this.inner);
    }
    unwrap() {
        if (this.#moved)
            return undefined;
        this.#moved = true;
        return this.inner;
    }
    /**
     * Get the inner value and set this as moved
     * @returns T
     * @throws BoxMovedError if already moved
     */
    unwrapOrThrow() {
        if (this.#moved)
            throw new BoxMovedError();
        this.#moved = true;
        return this.inner;
    }
    /**
     * Get the inner value and set this as moved
     * @returns Ok<T> or Err<BoxMovedError> if already moved
     */
    tryUnwrap() {
        if (this.#moved)
            return new _hazae41_result__WEBPACK_IMPORTED_MODULE_0__/* .Err */ .U(new BoxMovedError());
        this.#moved = true;
        return new _hazae41_result__WEBPACK_IMPORTED_MODULE_1__.Ok(this.inner);
    }
    move() {
        if (this.#moved)
            return undefined;
        this.#moved = true;
        return new Box(this.inner);
    }
    /**
     * Move the inner value to a new box and set this one as moved
     * @returns Box<T>
     * @throws BoxMovedError if already moved
     */
    moveOrThrow() {
        if (this.#moved)
            throw new BoxMovedError();
        this.#moved = true;
        return new Box(this.inner);
    }
    /**
     * Move the inner value to a new box and set this one as moved
     * @returns Ok<Box<T>> or Err<BoxMovedError> if already moved
     */
    tryMove() {
        if (this.#moved)
            return new _hazae41_result__WEBPACK_IMPORTED_MODULE_0__/* .Err */ .U(new BoxMovedError());
        this.#moved = true;
        return new _hazae41_result__WEBPACK_IMPORTED_MODULE_1__.Ok(new Box(this.inner));
    }
    /**
     * Create a new Box that's already moved, and keep this one as is
     * @returns Box<T>
     */
    greed() {
        const moved = new Box(this.inner);
        moved.#moved = true;
        return moved;
    }
}


//# sourceMappingURL=box.mjs.map


/***/ }),

/***/ 180:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   k: () => (/* binding */ Disposer)
/* harmony export */ });
/* unused harmony export AsyncDisposer */
class Disposer {
    inner;
    dispose;
    constructor(inner, dispose) {
        this.inner = inner;
        this.dispose = dispose;
    }
    static from(disposable) {
        return new Disposer(disposable, () => disposable[Symbol.dispose]());
    }
    [Symbol.dispose]() {
        this.dispose(this.inner);
    }
    get() {
        return this.inner;
    }
}
class AsyncDisposer {
    inner;
    dispose;
    constructor(inner, dispose) {
        this.inner = inner;
        this.dispose = dispose;
    }
    static from(disposable) {
        return new AsyncDisposer(disposable, () => disposable[Symbol.asyncDispose]());
    }
    async [Symbol.asyncDispose]() {
        await this.dispose(this.inner);
    }
    get() {
        return this.inner;
    }
}


//# sourceMappingURL=dispose.mjs.map


/***/ }),

/***/ 71:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   o: () => (/* binding */ Future)
/* harmony export */ });
class Future {
    #resolve;
    #reject;
    promise;
    /**
     * Just like a Promise but you can manually resolve or reject it
     */
    constructor() {
        this.promise = new Promise((subresolve, subreject) => {
            this.#resolve = subresolve;
            this.#reject = subreject;
        });
    }
    get resolve() {
        return this.#resolve;
    }
    get reject() {
        return this.#reject;
    }
}


//# sourceMappingURL=future.mjs.map


/***/ }),

/***/ 667:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CZ: () => (/* binding */ RpcInternalError),
/* harmony export */   av: () => (/* binding */ RpcInvalidRequestError),
/* harmony export */   s6: () => (/* binding */ RpcErr)
/* harmony export */ });
/* unused harmony exports RpcError, RpcInvalidParamsError, RpcMethodNotFoundError, RpcParseError */
/* harmony import */ var _hazae41_result__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(166);


class RpcError extends Error {
    code;
    message;
    data;
    #class = RpcError;
    name = this.#class.name;
    static codes = {
        ParseError: -32700,
        InvalidRequest: -32600,
        MethodNotFound: -32601,
        InvalidParams: -32602,
        InternalError: -32603
    };
    static messages = {
        ParseError: "Parse error",
        InvalidRequest: "Invalid Request",
        MethodNotFound: "Method not found",
        InvalidParams: "Invalid params",
        InternalError: "Internal error",
        ServerError: "Server error"
    };
    constructor(code, message, data = undefined) {
        super(message);
        this.code = code;
        this.message = message;
        this.data = data;
    }
    static from(init) {
        const { code, message, data } = init;
        return new RpcError(code, message, data);
    }
    static rewrap(error) {
        if (error instanceof RpcError)
            return error;
        if (error instanceof Error)
            return new RpcInternalError(error.message);
        return new RpcInternalError();
    }
    /**
     * Used by JSON.stringify
     */
    toJSON() {
        const { code, message, data } = this;
        return { code, message, data };
    }
}
class RpcParseError extends RpcError {
    #class = RpcParseError;
    name = this.#class.name;
    static code = RpcError.codes.ParseError;
    static message = RpcError.messages.ParseError;
    constructor(message = RpcError.messages.ParseError) {
        super(RpcError.codes.ParseError, message);
    }
}
class RpcInvalidRequestError extends RpcError {
    #class = RpcInvalidRequestError;
    name = this.#class.name;
    static code = RpcError.codes.InvalidRequest;
    static message = RpcError.messages.InvalidRequest;
    constructor(message = RpcError.messages.InvalidRequest) {
        super(RpcError.codes.InvalidRequest, message);
    }
}
class RpcMethodNotFoundError extends RpcError {
    #class = RpcMethodNotFoundError;
    name = this.#class.name;
    static code = RpcError.codes.MethodNotFound;
    static message = RpcError.messages.MethodNotFound;
    constructor(message = RpcError.messages.MethodNotFound) {
        super(RpcError.codes.MethodNotFound, message);
    }
}
class RpcInvalidParamsError extends RpcError {
    #class = RpcInvalidParamsError;
    name = this.#class.name;
    static code = RpcError.codes.InvalidParams;
    static message = RpcError.messages.InvalidParams;
    constructor(message = RpcError.messages.InvalidParams) {
        super(RpcError.codes.InvalidParams, message);
    }
}
class RpcInternalError extends RpcError {
    #class = RpcInternalError;
    name = this.#class.name;
    static code = RpcError.codes.InternalError;
    static message = RpcError.messages.InternalError;
    constructor(message = RpcError.messages.InternalError) {
        super(RpcError.codes.InternalError, message);
    }
}
class RpcErr extends _hazae41_result__WEBPACK_IMPORTED_MODULE_0__/* .Err */ .U {
    id;
    error;
    jsonrpc = "2.0";
    constructor(id, error) {
        super(error);
        this.id = id;
        this.error = error;
    }
    static from(init) {
        return new RpcErr(init.id, RpcError.from(init.error));
    }
    static rewrap(id, result) {
        return new RpcErr(id, RpcError.rewrap(result.inner));
    }
}


//# sourceMappingURL=err.mjs.map


/***/ }),

/***/ 978:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  S: () => (/* binding */ RpcResponse)
});

// EXTERNAL MODULE: ./node_modules/@hazae41/jsonrpc/dist/esm/mods/rpc/err.mjs
var err = __webpack_require__(667);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/ok.mjs
var ok = __webpack_require__(591);
;// CONCATENATED MODULE: ./node_modules/@hazae41/jsonrpc/dist/esm/mods/rpc/ok.mjs


var RpcOkInit;
(function (RpcOkInit) {
    function from(response) {
        const { jsonrpc, id, result } = response;
        return { jsonrpc, id, result };
    }
    RpcOkInit.from = from;
})(RpcOkInit || (RpcOkInit = {}));
class RpcOk extends ok.Ok {
    id;
    result;
    jsonrpc = "2.0";
    constructor(id, result) {
        super(result);
        this.id = id;
        this.result = result;
    }
    static from(init) {
        return new RpcOk(init.id, init.result);
    }
    static rewrap(id, result) {
        return new RpcOk(id, result.inner);
    }
}


//# sourceMappingURL=ok.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/jsonrpc/dist/esm/mods/rpc/response.mjs



var RpcResponse;
(function (RpcResponse) {
    function from(init) {
        if ("error" in init)
            return err/* RpcErr */.s6.from(init);
        return RpcOk.from(init);
    }
    RpcResponse.from = from;
    function rewrap(id, result) {
        if (result.isErr())
            return err/* RpcErr */.s6.rewrap(id, result);
        return RpcOk.rewrap(id, result);
    }
    RpcResponse.rewrap = rewrap;
})(RpcResponse || (RpcResponse = {}));


//# sourceMappingURL=response.mjs.map


/***/ }),

/***/ 371:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   H: () => (/* binding */ None)
/* harmony export */ });
/* unused harmony export NoneError */
/* harmony import */ var _hazae41_result__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(166);


class NoneError extends Error {
    constructor() {
        super(`Option is a None`);
    }
}
class None {
    inner;
    /**
     * An empty value
     */
    constructor(inner = undefined) {
        this.inner = inner;
    }
    /**
     * Create a `None`
     * @returns `None`
     */
    static new() {
        return new None();
    }
    static from(init) {
        return new None();
    }
    /**
     * Type guard for `Some`
     * @returns `true` if `Some`, `false` if `None`
     */
    isSome() {
        return false;
    }
    /**
     * Returns `true` if the option is a `Some` and the value inside of it matches a predicate
     * @param somePredicate
     * @returns `true` if `Some` and `await somePredicate(this.inner)`, `None` otherwise
     */
    async isSomeAnd(somePredicate) {
        return false;
    }
    /**
     * Returns `true` if the option is a `Some` and the value inside of it matches a predicate
     * @param somePredicate
     * @returns `true` if `Some` and `somePredicate(this.inner)`, `None` otherwise
     */
    isSomeAndSync(somePredicate) {
        return false;
    }
    /**
     * Type guard for `None`
     * @returns `true` if `None`, `false` if `Some`
     */
    isNone() {
        return true;
    }
    /**
     * Compile-time safely get `this.inner`
     * @returns `this.inner`
     */
    get() {
        return this.inner;
    }
    /**
     * Returns an iterator over the possibly contained value
     * @yields `this.inner` if `Some`
     */
    *[Symbol.iterator]() {
        return;
    }
    /**
     * Get the inner value if `Some`, throw `Error(message)` otherwise
     * @param message
     * @returns `this.inner` if `Some`
     * @throws `Error(message)` if `None`
     */
    expect(message) {
        throw new Error(message);
    }
    /**
     * Get the inner value or throw a NoneError
     * @returns `this.inner` if `Some`
     * @throws `NoneError` if `None`
     */
    unwrap() {
        throw new Error(`A None has been unwrapped`);
    }
    /**
     * Get the inner value or a default one
     * @param value
     * @returns `this.inner` if `Some`, `value` if `None`
     */
    unwrapOr(value) {
        return value;
    }
    /**
     * Returns the contained `Some` value or computes it from a closure
     * @param noneCallback
     * @returns `this.inner` if `Some`, `await noneCallback()` if `None`
     */
    async unwrapOrElse(noneCallback) {
        return await noneCallback();
    }
    /**
     * Returns the contained `Some` value or computes it from a closure
     * @param noneCallback
     * @returns `this.inner` if `Some`, `noneCallback()` if `None`
     */
    unwrapOrElseSync(noneCallback) {
        return noneCallback();
    }
    /**
     * Transform `Option<T>` into `Result<T, NoneError>`
     * @returns `Ok(this.inner)` if `Some`, `Err(NoneError)` if `None`
     */
    ok() {
        return new _hazae41_result__WEBPACK_IMPORTED_MODULE_0__/* .Err */ .U(new NoneError());
    }
    /**
     * Transform `Option<T>` into `Result<T, E>`
     * @param error
     * @returns `Ok(this.inner)` if `Some`, `Err(error)` if `None`
     */
    okOr(error) {
        return new _hazae41_result__WEBPACK_IMPORTED_MODULE_0__/* .Err */ .U(error);
    }
    /**
     * Transforms the `Option<T>` into a `Result<T, E>`, mapping `Some(v)` to `Ok(v)` and `None` to `Err(err())`
     * @param noneCallback
     * @returns `Ok(this.inner)` if `Some`, `Err(await noneCallback())` is `None`
     */
    async okOrElse(noneCallback) {
        return new _hazae41_result__WEBPACK_IMPORTED_MODULE_0__/* .Err */ .U(await noneCallback());
    }
    /**
     * Transforms the `Option<T>` into a `Result<T, E>`, mapping `Some(v)` to `Ok(v)` and `None` to `Err(err())`
     * @param noneCallback
     * @returns `Ok(this.inner)` if `Some`, `Err(noneCallback())` is `None`
     */
    okOrElseSync(noneCallback) {
        return new _hazae41_result__WEBPACK_IMPORTED_MODULE_0__/* .Err */ .U(noneCallback());
    }
    /**
     * Returns `None` if the option is `None`, otherwise calls `somePredicate` with the wrapped value
     * @param somePredicate
     * @returns `Some` if `Some` and `await somePredicate(this.inner)`, `None` otherwise
     */
    async filter(somePredicate) {
        return this;
    }
    /**
     * Returns `None` if the option is `None`, otherwise calls `somePredicate` with the wrapped value
     * @param somePredicate
     * @returns `Some` if `Some` and `somePredicate(this.inner)`, `None` otherwise
     */
    filterSync(somePredicate) {
        return this;
    }
    /**
     * Transform `Option<Promise<T>>` into `Promise<Option<T>>`
     * @returns `Promise<Option<T>>`
     */
    async await() {
        return this;
    }
    /**
     * Returns `true` if the option is a `Some` value containing the given value
     * @param value
     * @returns `true` if `Some` and `this.inner === value`, `None` otherwise
     */
    contains(value) {
        return false;
    }
    /**
     * Calls the given callback with the inner value if `Ok`
     * @param someCallback
     * @returns `this`
     */
    async inspect(someCallback) {
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Ok`
     * @param someCallback
     * @returns `this`
     */
    inspectSync(someCallback) {
        return this;
    }
    /**
     * Maps an `Option<T>` to `Option<U>` by applying a function to a contained value (if `Some`) or returns `None` (if `None`)
     * @param someMapper
     * @returns `Some(await someMapper(this.inner))` if `Some`, `this` if `None`
     */
    async map(someMapper) {
        return this;
    }
    /**
     * Maps an `Option<T>` to `Option<U>` by applying a function to a contained value (if `Some`) or returns `None` (if `None`)
     * @param someMapper
     * @returns `Some(someMapper(this.inner))` if `Some`, `this` if `None`
     */
    mapSync(someMapper) {
        return this;
    }
    /**
     * Returns the provided default result (if none), or applies a function to the contained value (if any)
     * @param value
     * @param someMapper
     * @returns `value` if `None`, `await someMapper(this.inner)` if `Some`
     */
    async mapOr(value, someMapper) {
        return value;
    }
    /**
     * Returns the provided default result (if none), or applies a function to the contained value (if any)
     * @param value
     * @param someMapper
     * @returns `value` if `None`, `someMapper(this.inner)` if `Some`
     */
    mapOrSync(value, someMapper) {
        return value;
    }
    /**
     * Computes a default function result (if none), or applies a different function to the contained value (if any)
     * @param noneCallback
     * @param someMapper
     * @returns `await someMapper(this.inner)` if `Some`, `await noneCallback()` if `None`
     */
    async mapOrElse(noneCallback, someMapper) {
        return await noneCallback();
    }
    /**
     * Computes a default function result (if none), or applies a different function to the contained value (if any)
     * @param noneCallback
     * @param someMapper
     * @returns `someMapper(this.inner)` if `Some`, `noneCallback()` if `None`
     */
    mapOrElseSync(noneCallback, someMapper) {
        return noneCallback();
    }
    /**
     * Returns `None` if the option is `None`, otherwise returns `value`
     * @param value
     * @returns `None` if `None`, `value` if `Some`
     */
    and(value) {
        return this;
    }
    /**
     * Returns `None` if the option is `None`, otherwise calls `someMapper` with the wrapped value and returns the result
     * @param someMapper
     * @returns `None` if `None`, `await someMapper(this.inner)` if `Some`
     */
    async andThen(someMapper) {
        return this;
    }
    /**
     * Returns `None` if the option is `None`, otherwise calls `someMapper` with the wrapped value and returns the result
     * @param someMapper
     * @returns `None` if `None`, `someMapper(this.inner)` if `Some`
     */
    andThenSync(someMapper) {
        return this;
    }
    /**
     * Returns `this` if `Some`, otherwise returns `value`
     * @param value
     * @returns `this` if `Some`, `value` if `None`
     */
    or(value) {
        return value;
    }
    /**
     * Returns `this` if `Some`, otherwise calls `noneCallback` and returns the result
     * @param noneCallback
     * @returns `this` if `Some`, `await noneCallback()` if `None`
     */
    async orElse(noneCallback) {
        return await noneCallback();
    }
    /**
     * Returns `this` if `Some`, otherwise calls `noneCallback` and returns the result
     * @param noneCallback
     * @returns `this` if `Some`, `noneCallback()` if `None`
     */
    orElseSync(noneCallback) {
        return noneCallback();
    }
    /**
     * Returns `Some` if exactly one of the options is `Some`, otherwise returns `None`
     * @param value
     * @returns `None` if both are `Some` or both are `None`, the only `Some` otherwise
     */
    xor(value) {
        return value;
    }
    /**
     * Zips `this` with another `Option`
     * @param other
     * @returns `Some([this.inner, other.inner])` if both are `Some`, `None` if one of them is `None`
     */
    zip(other) {
        return this;
    }
}


//# sourceMappingURL=none.mjs.map


/***/ }),

/***/ 862:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   b: () => (/* binding */ Some)
/* harmony export */ });
/* harmony import */ var _hazae41_result__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(591);
/* harmony import */ var _none_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(371);



class Some {
    inner;
    /**
     * An existing value
     * @param inner
     */
    constructor(inner) {
        this.inner = inner;
    }
    /**
     * Create a `Some`
     * @param inner
     * @returns `Some(inner)`
     */
    static new(inner) {
        return new Some(inner);
    }
    static from(init) {
        return new Some(init.inner);
    }
    /**
     * Type guard for `Some`
     * @returns `true` if `Some`, `false` if `None`
     */
    isSome() {
        return true;
    }
    /**
     * Returns `true` if the option is a `Some` and the value inside of it matches a predicate
     * @param somePredicate
     * @returns `true` if `Some` and `await somePredicate(this.inner)`, `None` otherwise
     */
    async isSomeAnd(somePredicate) {
        return await somePredicate(this.inner);
    }
    /**
     * Returns `true` if the option is a `Some` and the value inside of it matches a predicate
     * @param somePredicate
     * @returns `true` if `Some` and `somePredicate(this.inner)`, `None` otherwise
     */
    isSomeAndSync(somePredicate) {
        return somePredicate(this.inner);
    }
    /**
     * Type guard for `None`
     * @returns `true` if `None`, `false` if `Some`
     */
    isNone() {
        return false;
    }
    /**
     * Compile-time safely get `this.inner`
     * @returns `this.inner`
     */
    get() {
        return this.inner;
    }
    /**
     * Returns an iterator over the possibly contained value
     * @yields `this.inner` if `Some`
     */
    *[Symbol.iterator]() {
        yield this.inner;
    }
    /**
     * Get the inner value if `Some`, throw `Error(message)` otherwise
     * @param message
     * @returns `this.inner` if `Some`
     * @throws `Error(message)` if `None`
     */
    expect(message) {
        return this.inner;
    }
    /**
     * Get the inner value or throw a NoneError
     * @returns `this.inner` if `Some`
     * @throws `NoneError` if `None`
     */
    unwrap() {
        return this.inner;
    }
    /**
     * Get the inner value or a default one
     * @param value
     * @returns `this.inner` if `Some`, `value` if `None`
     */
    unwrapOr(value) {
        return this.inner;
    }
    /**
     * Returns the contained `Some` value or computes it from a closure
     * @param noneCallback
     * @returns `this.inner` if `Some`, `await noneCallback()` if `None`
     */
    async unwrapOrElse(noneCallback) {
        return this.inner;
    }
    /**
     * Returns the contained `Some` value or computes it from a closure
     * @param noneCallback
     * @returns `this.inner` if `Some`, `noneCallback()` if `None`
     */
    unwrapOrElseSync(noneCallback) {
        return this.inner;
    }
    /**
     * Transform `Option<T>` into `Result<T, NoneError>`
     * @returns `Ok(this.inner)` if `Some`, `Err(NoneError)` if `None`
     */
    ok() {
        return new _hazae41_result__WEBPACK_IMPORTED_MODULE_0__.Ok(this.inner);
    }
    /**
     * Transform `Option<T>` into `Result<T, E>`
     * @param error
     * @returns `Ok(this.inner)` if `Some`, `Err(error)` if `None`
     */
    okOr(error) {
        return new _hazae41_result__WEBPACK_IMPORTED_MODULE_0__.Ok(this.inner);
    }
    /**
     * Transforms the `Option<T>` into a `Result<T, E>`, mapping `Some(v)` to `Ok(v)` and `None` to `Err(err())`
     * @param noneCallback
     * @returns `Ok(this.inner)` if `Some`, `Err(await noneCallback())` is `None`
     */
    async okOrElse(noneCallback) {
        return new _hazae41_result__WEBPACK_IMPORTED_MODULE_0__.Ok(this.inner);
    }
    /**
     * Transforms the `Option<T>` into a `Result<T, E>`, mapping `Some(v)` to `Ok(v)` and `None` to `Err(err())`
     * @param noneCallback
     * @returns `Ok(this.inner)` if `Some`, `Err(noneCallback())` is `None`
     */
    okOrElseSync(noneCallback) {
        return new _hazae41_result__WEBPACK_IMPORTED_MODULE_0__.Ok(this.inner);
    }
    /**
     * Returns `None` if the option is `None`, otherwise calls `somePredicate` with the wrapped value
     * @param somePredicate
     * @returns `Some` if `Some` and `await somePredicate(this.inner)`, `None` otherwise
     */
    async filter(somePredicate) {
        if (await somePredicate(this.inner))
            return this;
        else
            return new _none_mjs__WEBPACK_IMPORTED_MODULE_1__/* .None */ .H();
    }
    /**
     * Returns `None` if the option is `None`, otherwise calls `somePredicate` with the wrapped value
     * @param somePredicate
     * @returns `Some` if `Some` and `somePredicate(this.inner)`, `None` otherwise
     */
    filterSync(somePredicate) {
        if (somePredicate(this.inner))
            return this;
        else
            return new _none_mjs__WEBPACK_IMPORTED_MODULE_1__/* .None */ .H();
    }
    /**
     * Transform `Option<Promise<T>>` into `Promise<Option<T>>`
     * @returns `Promise<Option<T>>`
     */
    async await() {
        return new Some(await this.inner);
    }
    /**
     * Returns `true` if the option is a `Some` value containing the given value
     * @param value
     * @returns `true` if `Some` and `this.inner === value`, `None` otherwise
     */
    contains(value) {
        return this.inner === value;
    }
    /**
     * Calls the given callback with the inner value if `Ok`
     * @param someCallback
     * @returns `this`
     */
    async inspect(someCallback) {
        await someCallback(this.inner);
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Ok`
     * @param someCallback
     * @returns `this`
     */
    inspectSync(someCallback) {
        someCallback(this.inner);
        return this;
    }
    /**
     * Maps an `Option<T>` to `Option<U>` by applying a function to a contained value (if `Some`) or returns `None` (if `None`)
     * @param someMapper
     * @returns `Some(await someMapper(this.inner))` if `Some`, `this` if `None`
     */
    async map(someMapper) {
        return new Some(await someMapper(this.inner));
    }
    /**
     * Maps an `Option<T>` to `Option<U>` by applying a function to a contained value (if `Some`) or returns `None` (if `None`)
     * @param someMapper
     * @returns `Some(someMapper(this.inner))` if `Some`, `this` if `None`
     */
    mapSync(someMapper) {
        return new Some(someMapper(this.inner));
    }
    /**
     * Returns the provided default result (if none), or applies a function to the contained value (if any)
     * @param value
     * @param someMapper
     * @returns `value` if `None`, `await someMapper(this.inner)` if `Some`
     */
    async mapOr(value, someMapper) {
        return await someMapper(this.inner);
    }
    /**
     * Returns the provided default result (if none), or applies a function to the contained value (if any)
     * @param value
     * @param someMapper
     * @returns `value` if `None`, `someMapper(this.inner)` if `Some`
     */
    mapOrSync(value, someMapper) {
        return someMapper(this.inner);
    }
    /**
     * Computes a default function result (if none), or applies a different function to the contained value (if any)
     * @param noneCallback
     * @param someMapper
     * @returns `await someMapper(this.inner)` if `Some`, `await noneCallback()` if `None`
     */
    async mapOrElse(noneCallback, someMapper) {
        return await someMapper(this.inner);
    }
    /**
     * Computes a default function result (if none), or applies a different function to the contained value (if any)
     * @param noneCallback
     * @param someMapper
     * @returns `someMapper(this.inner)` if `Some`, `noneCallback()` if `None`
     */
    mapOrElseSync(noneCallback, someMapper) {
        return someMapper(this.inner);
    }
    /**
     * Returns `None` if the option is `None`, otherwise returns `value`
     * @param value
     * @returns `None` if `None`, `value` if `Some`
     */
    and(value) {
        return value;
    }
    /**
     * Returns `None` if the option is `None`, otherwise calls `someMapper` with the wrapped value and returns the result
     * @param someMapper
     * @returns `None` if `None`, `await someMapper(this.inner)` if `Some`
     */
    async andThen(someMapper) {
        return await someMapper(this.inner);
    }
    /**
     * Returns `None` if the option is `None`, otherwise calls `someMapper` with the wrapped value and returns the result
     * @param someMapper
     * @returns `None` if `None`, `someMapper(this.inner)` if `Some`
     */
    andThenSync(someMapper) {
        return someMapper(this.inner);
    }
    /**
     * Returns `this` if `Some`, otherwise returns `value`
     * @param value
     * @returns `this` if `Some`, `value` if `None`
     */
    or(value) {
        return this;
    }
    /**
     * Returns `this` if `Some`, otherwise calls `noneCallback` and returns the result
     * @param noneCallback
     * @returns `this` if `Some`, `await noneCallback()` if `None`
     */
    async orElse(noneCallback) {
        return this;
    }
    /**
     * Returns `this` if `Some`, otherwise calls `noneCallback` and returns the result
     * @param noneCallback
     * @returns `this` if `Some`, `noneCallback()` if `None`
     */
    orElseSync(noneCallback) {
        return this;
    }
    /**
     * Returns `Some` if exactly one of the options is `Some`, otherwise returns `None`
     * @param value
     * @returns `None` if both are `Some` or both are `None`, the only `Some` otherwise
     */
    xor(value) {
        if (value.isSome())
            return new _none_mjs__WEBPACK_IMPORTED_MODULE_1__/* .None */ .H();
        else
            return this;
    }
    /**
     * Zips `this` with another `Option`
     * @param other
     * @returns `Some([this.inner, other.inner])` if both are `Some`, `None` if one of them is `None`
     */
    zip(other) {
        if (other.isSome())
            return new Some([this.inner, other.inner]);
        else
            return other;
    }
}


//# sourceMappingURL=some.mjs.map


/***/ }),

/***/ 873:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Kg: () => (/* binding */ Pool)
});

// UNUSED EXPORTS: EmptyPoolError, EmptySlotError, PoolErrEntry, PoolOkEntry

;// CONCATENATED MODULE: ./node_modules/@hazae41/piscine/dist/esm/node_modules/tslib/tslib.es6.mjs
/******************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */
/* global Reflect, Promise, SuppressedError, Symbol */


function __addDisposableResource(env, value, async) {
    if (value !== null && value !== void 0) {
        if (typeof value !== "object" && typeof value !== "function") throw new TypeError("Object expected.");
        var dispose;
        if (async) {
            if (!Symbol.asyncDispose) throw new TypeError("Symbol.asyncDispose is not defined.");
            dispose = value[Symbol.asyncDispose];
        }
        if (dispose === void 0) {
            if (!Symbol.dispose) throw new TypeError("Symbol.dispose is not defined.");
            dispose = value[Symbol.dispose];
        }
        if (typeof dispose !== "function") throw new TypeError("Object not disposable.");
        env.stack.push({ value: value, dispose: dispose, async: async });
    }
    else if (async) {
        env.stack.push({ async: true });
    }
    return value;
}

var _SuppressedError = typeof SuppressedError === "function" ? SuppressedError : function (error, suppressed, message) {
    var e = new Error(message);
    return e.name = "SuppressedError", e.error = error, e.suppressed = suppressed, e;
};

function __disposeResources(env) {
    function fail(e) {
        env.error = env.hasError ? new _SuppressedError(e, env.error, "An error was suppressed during disposal.") : e;
        env.hasError = true;
    }
    function next() {
        while (env.stack.length) {
            var rec = env.stack.pop();
            try {
                var result = rec.dispose && rec.dispose.call(rec.value);
                if (rec.async) return Promise.resolve(result).then(next, function(e) { fail(e); return next(); });
            }
            catch (e) {
                fail(e);
            }
        }
        if (env.hasError) throw env.error;
    }
    return next();
}


//# sourceMappingURL=tslib.es6.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/arrays/dist/esm/mods/arrays/arrays.mjs
/**
 * Get the last value
 * @param array
 * @returns
 */
function last(array) {
    if (array.length === 0)
        return undefined;
    return array[lastIndex(array)];
}
/**
 * Get the last index
 * @param array
 * @returns
 */
function lastIndex(array) {
    return array.length - 1;
}
/**
 * Get a random value using Math's PRNG
 * @param array
 * @returns
 */
function random(array) {
    if (array.length === 0)
        return undefined;
    return array[randomIndex(array)];
}
/**
 * Get a random index using Math's PRNG
 * @param array
 * @returns
 */
function randomIndex(array) {
    return Math.floor(Math.random() * array.length);
}
/**
 * Get a random value using WebCrypto's CSPRNG
 * @param array
 * @returns
 */
function cryptoRandom(array) {
    if (array.length === 0)
        return undefined;
    return array[cryptoRandomIndex(array)];
}
/**
 * Get a random value using WebCrypto's CSPRNG
 * @param array
 * @returns
 */
function cryptoRandomIndex(array) {
    const values = new Uint32Array(1);
    crypto.getRandomValues(values);
    return values[0] % array.length;
}
/**
 * Get a random value using Math's PRNG and delete it from the array
 * @param array
 * @returns
 */
function takeRandom(array) {
    if (array.length === 0)
        return undefined;
    const index = randomIndex(array);
    const element = array[index];
    array.splice(index, 1);
    return element;
}
/**
 * Get a random value using WebCrypto's CSPRNG and delete it from the array
 * @param array
 * @returns
 */
function takeCryptoRandom(array) {
    if (array.length === 0)
        return undefined;
    const index = cryptoRandomIndex(array);
    const element = array[index];
    array.splice(index, 1);
    return element;
}


//# sourceMappingURL=arrays.mjs.map

// EXTERNAL MODULE: ./node_modules/@hazae41/box/dist/esm/mods/box/box.mjs
var box_box = __webpack_require__(200);
// EXTERNAL MODULE: ./node_modules/@hazae41/disposer/dist/esm/mods/dispose/dispose.mjs
var dispose = __webpack_require__(180);
// EXTERNAL MODULE: ./node_modules/@hazae41/plume/dist/esm/src/mods/target.mjs
var target = __webpack_require__(232);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/ok.mjs
var ok = __webpack_require__(591);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/err.mjs
var err = __webpack_require__(166);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/result.mjs + 1 modules
var result_result = __webpack_require__(452);
// EXTERNAL MODULE: ./node_modules/@hazae41/signals/dist/esm/mods/signals/index.mjs
var signals = __webpack_require__(168);
;// CONCATENATED MODULE: ./node_modules/@hazae41/piscine/dist/esm/src/mods/pool/pool.mjs








var _a, _b;
class PoolOkEntry extends ok.Ok {
    pool;
    index;
    value;
    constructor(pool, index, value) {
        super(value);
        this.pool = pool;
        this.index = index;
        this.value = value;
    }
}
class PoolErrEntry extends err/* Err */.U {
    pool;
    index;
    value;
    constructor(pool, index, value) {
        super(value);
        this.pool = pool;
        this.index = index;
        this.value = value;
    }
}
class EmptyPoolError extends Error {
    #class = _a;
    name = this.#class.name;
    constructor() {
        super(`Empty pool`);
    }
}
_a = EmptyPoolError;
class EmptySlotError extends Error {
    #class = _b;
    name = this.#class.name;
    constructor() {
        super(`Empty pool slot`);
    }
}
_b = EmptySlotError;
class Pool {
    creator;
    params;
    #capacity;
    events = new target/* SuperEventTarget */.v();
    #allAborters = new Array();
    /**
     * Entry by index, can be sparse
     */
    #allEntries = new Array();
    /**
     * Promise by index, can be sparse
     */
    #allPromises = new Array();
    /**
     * Entries that are ok
     */
    #okEntries = new Set();
    /**
     * Entries that are err
     */
    #errEntries = new Set();
    /**
     * Promises that are started (running or settled)
     */
    #startedPromises = new Set();
    /**
     * A pool of circuits
     * @param tor
     * @param params
     */
    constructor(creator, params = {}) {
        this.creator = creator;
        this.params = params;
        const { capacity = 3 } = params;
        this.#capacity = capacity;
        for (let index = 0; index < capacity; index++)
            this.#start(index);
        return;
    }
    /**
     * Number of ok elements
     */
    get size() {
        return this.#okEntries.size;
    }
    /**
     * Number of slots
     */
    get capacity() {
        return this.#capacity;
    }
    /**
     * Iterator on ok elements
     * @returns
     */
    [Symbol.iterator]() {
        return this.#okEntries.values();
    }
    /**
     * Whether all entries are err
     */
    get stagnant() {
        return this.#errEntries.size === this.#capacity;
    }
    #start(index) {
        const promise = this.#createOrThrow(index);
        /**
         * Set promise as handled
         */
        promise.catch(() => { });
        this.#allPromises[index] = promise;
        this.#startedPromises.add(promise);
        this.events.emit("started", index).catch(console.error);
    }
    async #createOrThrow(index) {
        const aborter = new AbortController();
        this.#allAborters[index] = aborter;
        const { signal } = aborter;
        const result = await result_result/* Result */.x.runAndDoubleWrap(() => this.creator({ pool: this, index, signal }));
        if (result.isOk()) {
            const env_1 = { stack: [], error: void 0, hasError: false };
            try {
                const box = __addDisposableResource(env_1, new box_box/* Box */.x(result.get()), false);
                signal.throwIfAborted();
                const entry = new PoolOkEntry(this, index, box.unwrapOrThrow());
                this.#allEntries[index] = entry;
                this.#okEntries.add(entry);
                this.events.emit("created", entry).catch(console.error);
                return entry;
            }
            catch (e_1) {
                env_1.error = e_1;
                env_1.hasError = true;
            }
            finally {
                __disposeResources(env_1);
            }
        }
        signal.throwIfAborted();
        const entry = new PoolErrEntry(this, index, result.getErr());
        this.#allEntries[index] = entry;
        this.#errEntries.add(entry);
        this.events.emit("created", entry).catch(console.error);
        throw result.getErr();
    }
    #delete(index) {
        const aborter = this.#allAborters.at(index);
        if (aborter != null) {
            aborter.abort();
            delete this.#allAborters[index];
        }
        const promise = this.#allPromises.at(index);
        if (promise != null) {
            this.#startedPromises.delete(promise);
            delete this.#allPromises[index];
        }
        const entry = this.#allEntries.at(index);
        if (entry != null) {
            if (entry.isOk()) {
                entry.inner[Symbol.dispose]();
                this.#okEntries.delete(entry);
            }
            if (entry.isErr()) {
                this.#errEntries.delete(entry);
            }
            delete this.#allEntries[index];
            this.events.emit("deleted", entry).catch(console.error);
            return entry;
        }
        return undefined;
    }
    /**
     * Restart the index and return the previous entry
     * @param element
     * @returns
     */
    restart(index) {
        const entry = this.#delete(index);
        this.#start(index);
        return entry;
    }
    /**
     * Modify capacity
     * @param capacity
     * @returns
     */
    growOrShrink(capacity) {
        if (capacity > this.#capacity) {
            const previous = this.#capacity;
            this.#capacity = capacity;
            for (let i = previous; i < capacity; i++)
                this.#start(i);
            return previous;
        }
        else if (capacity < this.#capacity) {
            const previous = this.#capacity;
            this.#capacity = capacity;
            for (let i = capacity; i < previous; i++)
                this.#delete(i);
            return previous;
        }
        return this.#capacity;
    }
    async getOrThrow(index, signal = signals/* never */.Fi()) {
        const env_2 = { stack: [], error: void 0, hasError: false };
        try {
            const promise = this.#allPromises.at(index);
            if (promise === undefined)
                throw new EmptySlotError();
            const abort = __addDisposableResource(env_2, signals/* rejectOnAbort */.C$(signal), false);
            return await Promise.race([abort.get(), promise]);
        }
        catch (e_2) {
            env_2.error = e_2;
            env_2.hasError = true;
        }
        finally {
            __disposeResources(env_2);
        }
    }
    /**
     * Get the element at index, if still loading, wait for it, err if not started
     * @param index
     * @returns
     */
    async tryGet(index, signal) {
        return await result_result/* Result */.x.runAndDoubleWrap(() => this.getOrThrow(index, signal));
    }
    /**
     * Get the element at index, throw if empty
     * @param index
     * @returns the element at index
     * @throws if empty
     */
    getSyncOrThrow(index) {
        const entry = this.#allEntries.at(index);
        if (entry === undefined)
            throw new EmptySlotError();
        return entry;
    }
    /**
     * Get the element at index, err if empty
     * @param index
     * @returns
     */
    tryGetSync(index) {
        return result_result/* Result */.x.runAndDoubleWrapSync(() => this.getSyncOrThrow(index));
    }
    /**
     * Wait for any element to be created, then get a random one using Math's PRNG
     * @returns
     */
    async getRandomOrThrow(signal = signals/* never */.Fi()) {
        while (true) {
            const env_3 = { stack: [], error: void 0, hasError: false };
            try {
                const abort = __addDisposableResource(env_3, signals/* rejectOnAbort */.C$(signal), false);
                const first = Promise.any(this.#startedPromises);
                await Promise.race([first, abort.get()]);
                try {
                    return this.getRandomSyncOrThrow();
                }
                catch (e) {
                    /**
                     * The element has been deleted already?
                     */
                }
            }
            catch (e_3) {
                env_3.error = e_3;
                env_3.hasError = true;
            }
            finally {
                __disposeResources(env_3);
            }
        }
    }
    /**
     * Wait for any element to be created, then get a random one using Math's PRNG
     * @returns
     */
    async tryGetRandom(signal) {
        return await result_result/* Result */.x.runAndDoubleWrap(() => this.getRandomOrThrow(signal));
    }
    /**
     * Get a random element from the pool using Math's PRNG, throws if none available
     * @returns
     */
    getRandomSyncOrThrow() {
        if (this.#okEntries.size === 0)
            throw new EmptyPoolError();
        const entries = [...this.#okEntries];
        return random(entries);
    }
    /**
     * Get a random element from the pool using Math's PRNG, throws if none available
     * @returns
     */
    tryGetRandomSync() {
        return result_result/* Result */.x.runAndDoubleWrapSync(() => this.getRandomSyncOrThrow());
    }
    /**
     * Wait for any element to be created, then get a random one using WebCrypto's CSPRNG
     * @returns
     */
    async getCryptoRandomOrThrow(signal = signals/* never */.Fi()) {
        while (true) {
            const env_4 = { stack: [], error: void 0, hasError: false };
            try {
                const abort = __addDisposableResource(env_4, signals/* rejectOnAbort */.C$(signal), false);
                const first = Promise.any(this.#startedPromises);
                await Promise.race([first, abort.get()]);
                try {
                    return this.getCryptoRandomSyncOrThrow();
                }
                catch (e) {
                    /**
                     * The element has been deleted already?
                     */
                }
            }
            catch (e_4) {
                env_4.error = e_4;
                env_4.hasError = true;
            }
            finally {
                __disposeResources(env_4);
            }
        }
    }
    /**
     * Wait for any element to be created, then get a random one using WebCrypto's CSPRNG
     * @returns
     */
    async tryGetCryptoRandom(signal) {
        return await result_result/* Result */.x.runAndDoubleWrap(() => this.getCryptoRandomOrThrow(signal));
    }
    /**
     * Get a random element from the pool using WebCrypto's CSPRNG
     * @returns
     */
    getCryptoRandomSyncOrThrow() {
        if (this.#okEntries.size === 0)
            throw new EmptyPoolError();
        const entries = [...this.#okEntries];
        return cryptoRandom(entries);
    }
    /**
     * Get a random element from the pool using WebCrypto's CSPRNG
     * @returns
     */
    tryGetCryptoRandomSync() {
        return result_result/* Result */.x.runAndDoubleWrapSync(() => this.getCryptoRandomSyncOrThrow());
    }
    /**
     * Take a random element from the pool using Math's PRNG
     * @param pool
     * @returns
     */
    static takeRandomSyncOrThrow(pool) {
        const entry = pool.getRandomSyncOrThrow();
        if (entry.isErr())
            return entry;
        const { index, value } = entry;
        const value2 = new dispose/* Disposer */.k(value.inner.moveOrThrow(), value.dispose);
        const entry2 = new PoolOkEntry(pool, index, value2);
        pool.restart(index);
        return entry2;
    }
    /**
     * Take a random element from the pool using Math's PRNG
     * @param pool
     * @returns
     */
    static tryTakeRandomSync(pool) {
        return result_result/* Result */.x.runAndDoubleWrapSync(() => this.takeRandomSyncOrThrow(pool));
    }
    /**
     * Take a random element from the pool using Math's PRNG
     * @param pool
     * @returns
     */
    static async takeRandomOrThrow(pool, signal = signals/* never */.Fi()) {
        return await pool.lock(async (pool) => {
            const entry = await pool.getRandomOrThrow(signal);
            if (entry.isErr())
                return entry;
            const { index, value } = entry;
            const value2 = new dispose/* Disposer */.k(value.inner.moveOrThrow(), value.dispose);
            const entry2 = new PoolOkEntry(pool, index, value2);
            pool.restart(index);
            return entry2;
        });
    }
    /**
     * Take a random element from the pool using Math's PRNG
     * @param pool
     * @returns
     */
    static async tryTakeRandom(pool, signal) {
        return await result_result/* Result */.x.runAndDoubleWrap(() => this.takeRandomOrThrow(pool, signal));
    }
    /**
     * Take a random element from the pool using WebCrypto's CSPRNG
     * @param pool
     * @returns
     */
    static takeCryptoRandomSyncOrThrow(pool) {
        const entry = pool.getCryptoRandomSyncOrThrow();
        if (entry.isErr())
            return entry;
        const { index, value } = entry;
        const value2 = new dispose/* Disposer */.k(value.inner.moveOrThrow(), value.dispose);
        const entry2 = new PoolOkEntry(pool, index, value2);
        pool.restart(index);
        return entry2;
    }
    /**
     * Take a random element from the pool using WebCrypto's CSPRNG
     * @param pool
     * @returns
     */
    static tryTakeCryptoRandomSync(pool) {
        return result_result/* Result */.x.runAndDoubleWrapSync(() => this.takeCryptoRandomSyncOrThrow(pool));
    }
    /**
     * Take a random element from the pool using WebCrypto's CSPRNG
     * @param pool
     * @returns
     */
    static async takeCryptoRandomOrThrow(pool, signal = signals/* never */.Fi()) {
        return await pool.lock(async (pool) => {
            const entry = await pool.getCryptoRandomOrThrow(signal);
            if (entry.isErr())
                return entry;
            const { index, value } = entry;
            const value2 = new dispose/* Disposer */.k(value.inner.moveOrThrow(), value.dispose);
            const entry2 = new PoolOkEntry(pool, index, value2);
            pool.restart(index);
            return entry2;
        });
    }
    /**
     * Take a random element from the pool using WebCrypto's CSPRNG
     * @param pool
     * @returns
     */
    static async tryTakeCryptoRandom(pool, signal) {
        return await result_result/* Result */.x.runAndDoubleWrap(() => this.takeCryptoRandomOrThrow(pool, signal));
    }
}


//# sourceMappingURL=pool.mjs.map


/***/ }),

/***/ 232:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   v: () => (/* binding */ SuperEventTarget)
/* harmony export */ });
/* harmony import */ var _hazae41_disposer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(180);
/* harmony import */ var _hazae41_future__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(71);
/* harmony import */ var _hazae41_option__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(371);




class SuperEventTarget {
    #listeners = new Map();
    get listeners() {
        return this.#listeners;
    }
    /**
     * Add a listener to an event
     * @param type Event type //  "abort", "error", "message", "close"
     * @param listener Event listener // (e) => new Some(123)
     * @param options Options // { passive: true }
     * @returns
     */
    on(type, listener, options = {}) {
        let listeners = this.#listeners.get(type);
        if (listeners === undefined) {
            listeners = new Map();
            this.#listeners.set(type, listeners);
        }
        const off = () => this.off(type, listener);
        const internalOptions = { ...options, off };
        internalOptions.signal?.addEventListener("abort", off, { passive: true });
        listeners.set(listener, internalOptions);
        return off;
    }
    /**
     * Remove a listener from an event
     * @param type Event type //  "abort", "error", "message", "close"
     * @param listener Event listener // (e) => console.log("hello")
     * @param options Just to look like DOM's EventTarget
     * @returns
     */
    off(type, listener) {
        const listeners = this.#listeners.get(type);
        if (!listeners)
            return;
        const options = listeners.get(listener);
        if (!options)
            return;
        options.signal?.removeEventListener("abort", options.off);
        listeners.delete(listener);
        if (listeners.size > 0)
            return;
        this.#listeners.delete(type);
    }
    /**
     * Dispatch an event to its listeners
     *
     * - Dispatch to active listeners sequencially
     * - Return if one of the listeners returned something
     * - Dispatch to passive listeners concurrently
     * - Return if one of the listeners returned something
     * - Return nothing
     * @param params The object to emit
     * @returns `Some` if the event
     */
    async emit(type, ...params) {
        const listeners = this.#listeners.get(type);
        if (!listeners)
            return new _hazae41_option__WEBPACK_IMPORTED_MODULE_0__/* .None */ .H();
        const promises = new Array();
        for (const [listener, options] of listeners) {
            if (options.passive)
                continue;
            if (options.once)
                this.off(type, listener);
            const returned = await listener(...params);
            if (returned.isNone())
                continue;
            return returned;
        }
        for (const [listener, options] of listeners) {
            if (!options.passive)
                continue;
            if (options.once)
                this.off(type, listener);
            const returned = listener(...params);
            if (returned instanceof Promise) {
                promises.push(returned);
                continue;
            }
            if (returned.isNone())
                continue;
            return returned;
        }
        const returneds = await Promise.all(promises);
        for (const returned of returneds)
            if (returned.isSome())
                return returned;
        return new _hazae41_option__WEBPACK_IMPORTED_MODULE_0__/* .None */ .H();
    }
    /**
     * Like `.on`, but instead of returning to the target, capture the returned value in a future, and return nothing to the target
     * @param type
     * @param callback
     * @returns
     */
    wait(type, callback) {
        const future = new _hazae41_future__WEBPACK_IMPORTED_MODULE_1__/* .Future */ .o();
        const dispose = this.on(type, async (...params) => {
            return await callback(future, ...params);
        }, { passive: true });
        return new _hazae41_disposer__WEBPACK_IMPORTED_MODULE_2__/* .Disposer */ .k(future.promise, dispose);
    }
}


//# sourceMappingURL=target.mjs.map


/***/ }),

/***/ 166:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   U: () => (/* binding */ Err)
/* harmony export */ });
/* harmony import */ var _hazae41_option__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(371);
/* harmony import */ var _hazae41_option__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(862);
/* harmony import */ var _errors_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(564);
/* harmony import */ var _result_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(452);




class Err {
    #inner;
    #timeout;
    /**
     * A failure
     * @param inner
     */
    constructor(inner) {
        this.#inner = inner;
        if (!_result_mjs__WEBPACK_IMPORTED_MODULE_0__/* .Result */ .x.debug)
            return;
        const error = new Error(`An Err has not been handled properly`);
        this.#timeout = setTimeout(() => { throw error; }, 1000);
    }
    /**
     * Create an empty `Err`
     * @returns `Err(void)`
     */
    static void() {
        return new Err(undefined);
    }
    /**
     * Create an `Err`
     * @param inner
     * @returns `Err(inner)`
     */
    static new(inner) {
        return new Err(inner);
    }
    /**
     * Create an `Err` with an `Error` inside
     * @param message
     * @param options
     * @returns `Err<Error>`
     */
    static error(message, options) {
        return new Err(new Error(message, options));
    }
    get inner() {
        return this.#inner;
    }
    /**
     * Set this result as handled
     */
    ignore() {
        if (!this.#timeout)
            return this;
        clearTimeout(this.#timeout);
        this.#timeout = undefined;
        return this;
    }
    /**
     * Type guard for `Ok`
     * @returns `true` if `Ok`, `false` if `Err`
     */
    isOk() {
        return false;
    }
    /**
     * Returns true if the result is `Ok` and the value inside of it matches a predicate
     * @param okPredicate
     * @returns `true` if `Ok` and `await okPredicate(this.inner)`, `false` otherwise
     */
    async isOkAnd(okPredicate) {
        return false;
    }
    /**
     * Returns true if the result is `Ok` and the value inside of it matches a predicate
     * @param okPredicate
     * @returns `true` if `Ok` and `await okPredicate(this.inner)`, `false` otherwise
     */
    isOkAndSync(okPredicate) {
        return false;
    }
    /**
     * Type guard for `Err`
     * @returns `true` if `Err`, `false` if `Ok`
     */
    isErr() {
        return true;
    }
    /**
     * Returns true if the result is `Err` and the value inside of it matches a predicate
     * @param errPredicate
     * @returns `true` if `Err` and `await errPredicate(this.inner)`, `false` otherwise
     */
    async isErrAnd(errPredicate) {
        return await errPredicate(this.inner);
    }
    /**
     * Returns true if the result is `Err` and the value inside of it matches a predicate
     * @param errPredicate
     * @returns `true` if `Err` and `await errPredicate(this.inner)`, `false` otherwise
     */
    isErrAndSync(errPredicate) {
        return errPredicate(this.inner);
    }
    /**
     * Compile-time safely get Ok's inner type
     * @returns `this.inner`
     * @throws if `this` is `Err`
     */
    get() {
        throw new _errors_mjs__WEBPACK_IMPORTED_MODULE_1__/* .Panic */ .F();
    }
    /**
     * Compile-time safely get Err's inner type
     * @returns `this.inner`
     * @throws if `this` is `Ok`
     */
    getErr() {
        this.ignore();
        return this.inner;
    }
    /**
     * Transform `Result<T, E>` into `Option<T>`
     * @returns `Some(this.inner)` if `Ok`, `None` if `Err`
     */
    ok() {
        this.ignore();
        return new _hazae41_option__WEBPACK_IMPORTED_MODULE_2__/* .None */ .H();
    }
    /**
     * Transform `Result<T, E>` into `Option<E>`
     * @returns `Some(this.inner)` if `Err`, `None` if `Ok`
     */
    err() {
        this.ignore();
        return new _hazae41_option__WEBPACK_IMPORTED_MODULE_3__/* .Some */ .b(this.inner);
    }
    /**
     * Returns an iterator over the possibly contained value
     * @yields `this.inner` if `Ok`
     */
    *[Symbol.iterator]() {
        this.ignore();
        return;
    }
    /**
     * Transform `Result<T,E>` into `[T,E]`
     * @returns `[this.inner, undefined]` if `Ok`, `[undefined, this.inner]` if `Err`
     */
    split() {
        this.ignore();
        return [undefined, this.inner];
    }
    /**
     * Returns true if the result is an `Ok` value containing the given value
     * @param value
     * @returns `true` if `Ok` and `this.inner === value`, `false` otherwise
     */
    contains(value) {
        return false;
    }
    /**
     * Returns true if the result is an `Err` value containing the given value
     * @param value
     * @returns `true` if `Err` and `this.inner === value`, `false` otherwise
     */
    containsErr(value) {
        return this.inner === value;
    }
    /**
     * Get the inner value or throw to the closest `Result.unthrow`
     * @param thrower The thrower from `Result.unthrow`
     * @returns `this.inner` if `Ok`
     * @throws `undefined` if `Err`
     * @see Result.unthrow
     * @see Result.unthrowSync
     */
    throw(thrower) {
        thrower(this);
        throw this;
    }
    /**
     * Get the inner value or throw the inner error wrapped inside another Error
     * @param message
     * @returns `this.inner` if `Ok`, `Error(message, { cause: this.inner })` if `Err`
     */
    expect(message) {
        this.ignore();
        throw new Error(message, { cause: this.inner });
    }
    /**
     * Get the inner error or throw the inner value wrapped inside another Error
     * @param message
     * @returns `this.inner` if `Err`, `Error(message, { cause: this.inner })` if `Ok`
     */
    expectErr(message) {
        this.ignore();
        return this.inner;
    }
    /**
     * Get the inner value or panic
     * @returns `this.inner` if `Ok`
     * @throws `this.inner` if `Err`
     */
    unwrap() {
        this.ignore();
        throw this.inner;
    }
    /**
     * Get the inner error or panic
     * @returns `this.inner` if `Err`
     * @throws `this.inner` if `Ok`
     */
    unwrapErr() {
        this.ignore();
        return this.inner;
    }
    /**
     * Get the inner value or a default one
     * @param value
     * @returns `this.inner` if `Ok`, `value` if `Err`
     */
    unwrapOr(value) {
        this.ignore();
        return value;
    }
    /**
     * Get the inner value or compute a default one from the inner error
     * @param errMapper
     * @returns `this.inner` if `Ok`, `await errMapper(this.inner)` if `Err`
     * @throws if `await errMapper(this.inner)` throws
     */
    async unwrapOrElse(errMapper) {
        this.ignore();
        return await errMapper(this.inner);
    }
    /**
     * Get the inner value or compute a default one from the inner error
     * @param errMapper
     * @returns `this.inner` if `Ok`, `errMapper(this.inner)` if `Err`
     * @throws if `errMapper(this.inner)` throws
     */
    unwrapOrElseSync(errMapper) {
        this.ignore();
        return errMapper(this.inner);
    }
    /**
     * Transform Result<Promise<T>, E> into Promise<Result<T, E>>
     * @returns `await this.inner` if `Ok`, `this` if `Err`
     */
    async await() {
        return this;
    }
    /**
     * Transform Result<T, Promise<E>> into Promise<Result<T, E>>
     * @returns `await this.inner` if `Err`, `this` if `Ok`
     */
    async awaitErr() {
        return new Err(await this.inner);
    }
    /**
     * Transform Result<Promise<T>, Promise<E>> into Promise<Result<T, E>>
     * @returns `await this.inner`
     */
    async awaitAll() {
        return await this.awaitErr();
    }
    /**
     * Transform `Result<T, E>` into `Result<void, E>`
     * @returns `Ok<void>` if `Ok<T>`, `Err<E>` if `E<E>`
     */
    clear() {
        return this;
    }
    /**
     * Transform `Result<T, E>` into `Result<T, void>`
     * @returns `Ok<T>` if `Ok<T>`, `Err<void>` if `E<E>`
     */
    clearErr() {
        this.ignore();
        return Err.void();
    }
    /**
     * Calls the given callback with the inner value if `Ok`
     * @param okCallback
     * @returns `this`
     */
    async inspect(okCallback) {
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Ok`
     * @param okCallback
     * @returns `this`
     */
    inspectSync(okCallback) {
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Err`
     * @param errCallback
     * @returns `this`
     */
    async inspectErr(errCallback) {
        await errCallback(this.inner);
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Err`
     * @param errCallback
     * @returns `this`
     */
    inspectErrSync(errCallback) {
        errCallback(this.inner);
        return this;
    }
    /**
     * Return a new `Ok` but with the given `inner`
     * @param inner
     * @returns `Ok(inner)` if `Ok`, `this` if `Err`
     */
    set(inner) {
        return this;
    }
    /**
     * Return a new `Err` but with the given `inner`
     * @param inner
     * @returns `Err(inner)` if `Err`, `this` if `Ok`
     */
    setErr(inner) {
        return new Err(inner);
    }
    /**
     * Map the inner value into another
     * @param okMapper
     * @returns `Ok(await okMapper(this.inner))` if `Ok`, `this` if `Err`
     * @throws if `await okMapper(this.inner)` throws
     */
    async map(okMapper) {
        return this;
    }
    /**
     * Map the inner value into another
     * @param okMapper
     * @returns `Ok(okMapper(this.inner))` if `Ok`, `this` if `Err`
     * @throws if `okMapper(this.inner)` throws
     */
    mapSync(okMapper) {
        return this;
    }
    /**
     * Map the inner error into another
     * @param errMapper
     * @returns `Err(await errMapper(this.inner))` if `Err`, `this` if `Ok`
     * @throws if `await errMapper(this.inner)` throws
     */
    async mapErr(errMapper) {
        this.ignore();
        return new Err(await errMapper(this.inner));
    }
    /**
     * Map the inner error into another
     * @param errMapper
     * @returns `Err(errMapper(this.inner))` if `Err`, `this` if `Ok`
     * @throws if `errMapper(this.inner)` throws
     */
    mapErrSync(errMapper) {
        this.ignore();
        return new Err(errMapper(this.inner));
    }
    /**
     * Map the inner value into another, or a default one
     * @param value
     * @param okMapper
     * @returns `await okMapper(this.inner)` if `Ok`, `value` if `Err`
     * @throws if `await okMapper(this.inner)` throws
     */
    async mapOr(value, okMapper) {
        this.ignore();
        return value;
    }
    /**
     * Map the inner value into another, or a default one
     * @param value
     * @param okMapper
     * @returns `okMapper(this.inner)` if `Ok`, `value` if `Err`
     * @throws if `okMapper(this.inner)` throws
     */
    mapOrSync(value, okMapper) {
        this.ignore();
        return value;
    }
    /**
     * Map the inner value into another, or a default one
     * @param errMapper
     * @param okMapper
     * @returns `await okMapper(this.inner)` if `Ok`, `await errMapper(this.inner)` if `Err`
     * @throws if `await okMapper(this.inner)` or `await errMapper(this.inner)` throws
     */
    async mapOrElse(errMapper, okMapper) {
        this.ignore();
        return await errMapper(this.inner);
    }
    /**
     * Map the inner value into another, or a default one
     * @param errMapper
     * @param okMapper
     * @returns `okMapper(this.inner)` if `Ok`, `errMapper(this.inner)` if `Err`
     * @throws if `okMapper(this.inner)` or `errMapper(this.inner)` throws
     */
    mapOrElseSync(errMapper, okMapper) {
        this.ignore();
        return errMapper(this.inner);
    }
    /**
     * Return `value` if `Ok`, return `this` if `Err`
     * @param value
     * @returns `value` if `Ok`, `this` if `Err`
     */
    and(value) {
        return this;
    }
    /**
     * Return `await okMapper(this.inner)` if `Ok`, return `this` if `Err`
     * @param okMapper
     * @returns `await okMapper(this.inner)` if `Ok`, `this` if `Err`
     * @throws if `await okMapper(this.inner)` throws
     */
    async andThen(okMapper) {
        return this;
    }
    /**
     * Return `okMapper(this.inner)` if `Ok`, return `this` if `Err`
     * @param okMapper
     * @returns `okMapper(this.inner)` if `Ok`, `this` if `Err`
     * @throws if `okMapper(this.inner)` throws
     */
    andThenSync(okMapper) {
        return this;
    }
    /**
     * Return `value` if `Err`, return `this` if `Ok`
     * @param value
     * @returns `value` if `Err`, `this` if `Ok`
     */
    or(value) {
        this.ignore();
        return value;
    }
    /**
     * Return `await errMapper(this.inner)` if `Err`, return `this` if `Ok`
     * @param errMapper
     * @returns `await errMapper(this.inner)` if `Err`, `this` if `Ok`
     * @throws if `await errMapper(this.inner)` throws
     */
    async orElse(errMapper) {
        this.ignore();
        return await errMapper(this.inner);
    }
    /**
     * Return `errMapper(this.inner)` if `Err`, return `this` if `Ok`
     * @param errMapper
     * @returns `errMapper(this.inner)` if `Err`, `this` if `Ok`
     * @throws if `errMapper(this.inner)` throws
     */
    orElseSync(errMapper) {
        this.ignore();
        return errMapper(this.inner);
    }
    /**
     * Transform Result<Result<T, E1>, E2> into Result<T, E1 | E2>
     * @param result
     * @returns `this` if `Err`, `this.inner` if `Ok`
     */
    flatten() {
        return this;
    }
}


//# sourceMappingURL=err.mjs.map


/***/ }),

/***/ 564:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $: () => (/* binding */ Catched),
/* harmony export */   F: () => (/* binding */ Panic)
/* harmony export */ });
class Panic extends Error {
    #class = Panic;
    name = this.#class.name;
}
class Catched extends Error {
    #class = Catched;
    name = this.#class.name;
    static wrap(cause) {
        if (cause instanceof Error)
            return cause;
        return new Catched(undefined, { cause });
    }
}


//# sourceMappingURL=errors.mjs.map


/***/ }),

/***/ 591:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Ok: () => (/* binding */ Ok)
/* harmony export */ });
/* harmony import */ var _hazae41_option__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(862);
/* harmony import */ var _hazae41_option__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(371);
/* harmony import */ var _errors_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(564);
/* harmony import */ var _result_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(452);




class Ok {
    #inner;
    #timeout;
    /**
     * A success
     * @param inner
     */
    constructor(inner) {
        this.#inner = inner;
        if (!_result_mjs__WEBPACK_IMPORTED_MODULE_0__/* .Result */ .x.debug)
            return;
        const error = new Error(`An Ok has not been handled properly`);
        this.#timeout = setTimeout(() => { throw error; }, 1000);
    }
    /**
     * Create an empty `Ok`
     * @returns `Ok(void)`
     */
    static void() {
        return new Ok(undefined);
    }
    /**
     * Create an `Ok`
     * @param inner
     * @returns `Ok(inner)`
     */
    static new(inner) {
        return new Ok(inner);
    }
    get inner() {
        return this.#inner;
    }
    /**
     * Set this result as handled
     */
    ignore() {
        if (!this.#timeout)
            return this;
        clearTimeout(this.#timeout);
        this.#timeout = undefined;
        return this;
    }
    /**
     * Type guard for `Ok`
     * @returns `true` if `Ok`, `false` if `Err`
     */
    isOk() {
        return true;
    }
    /**
     * Returns true if the result is `Ok` and the value inside of it matches a predicate
     * @param okPredicate
     * @returns `true` if `Ok` and `await okPredicate(this.inner)`, `false` otherwise
     */
    async isOkAnd(okPredicate) {
        return await okPredicate(this.inner);
    }
    /**
     * Returns true if the result is `Ok` and the value inside of it matches a predicate
     * @param okPredicate
     * @returns `true` if `Ok` and `await okPredicate(this.inner)`, `false` otherwise
     */
    isOkAndSync(okPredicate) {
        return okPredicate(this.inner);
    }
    /**
     * Type guard for `Err`
     * @returns `true` if `Err`, `false` if `Ok`
     */
    isErr() {
        return false;
    }
    /**
     * Returns true if the result is `Err` and the value inside of it matches a predicate
     * @param errPredicate
     * @returns `true` if `Err` and `await errPredicate(this.inner)`, `false` otherwise
     */
    async isErrAnd(errPredicate) {
        return false;
    }
    /**
     * Returns true if the result is `Err` and the value inside of it matches a predicate
     * @param errPredicate
     * @returns `true` if `Err` and `await errPredicate(this.inner)`, `false` otherwise
     */
    isErrAndSync(errPredicate) {
        return false;
    }
    /**
     * Compile-time safely get Ok's inner type
     * @returns `this.inner`
     * @throws if `this` is `Err`
     */
    get() {
        this.ignore();
        return this.inner;
    }
    /**
     * Compile-time safely get Err's inner type
     * @returns `this.inner`
     * @throws if `this` is `Ok`
     */
    getErr() {
        throw new _errors_mjs__WEBPACK_IMPORTED_MODULE_1__/* .Panic */ .F();
    }
    /**
     * Transform `Result<T, E>` into `Option<T>`
     * @returns `Some(this.inner)` if `Ok`, `None` if `Err`
     */
    ok() {
        this.ignore();
        return new _hazae41_option__WEBPACK_IMPORTED_MODULE_2__/* .Some */ .b(this.inner);
    }
    /**
     * Transform `Result<T, E>` into `Option<E>`
     * @returns `Some(this.inner)` if `Err`, `None` if `Ok`
     */
    err() {
        this.ignore();
        return new _hazae41_option__WEBPACK_IMPORTED_MODULE_3__/* .None */ .H();
    }
    /**
     * Returns an iterator over the possibly contained value
     * @yields `this.inner` if `Ok`
     */
    *[Symbol.iterator]() {
        this.ignore();
        yield this.inner;
    }
    /**
     * Transform `Result<T,E>` into `[T,E]`
     * @returns `[this.inner, undefined]` if `Ok`, `[undefined, this.inner]` if `Err`
     */
    split() {
        this.ignore();
        return [this.inner, undefined];
    }
    /**
     * Returns true if the result is an `Ok` value containing the given value
     * @param value
     * @returns `true` if `Ok` and `this.inner === value`, `false` otherwise
     */
    contains(value) {
        return this.inner === value;
    }
    /**
     * Returns true if the result is an `Err` value containing the given value
     * @param value
     * @returns `true` if `Err` and `this.inner === value`, `false` otherwise
     */
    containsErr(value) {
        return false;
    }
    /**
     * Just like `unwrap` but it throws to the closest `Result.unthrow`
     * @returns `this.inner` if `Ok`
     * @throws `this` if `Err`
     * @see Result.unthrow
     * @see Result.unthrowSync
     */
    throw(thrower) {
        this.ignore();
        return this.inner;
    }
    /**
     * Get the inner value or throw the inner error wrapped inside another Error
     * @param message
     * @returns `this.inner` if `Ok`, `Error(message, { cause: this.inner })` if `Err`
     */
    expect(message) {
        this.ignore();
        return this.inner;
    }
    /**
     * Get the inner error or throw the inner value wrapped inside another Error
     * @param message
     * @returns `this.inner` if `Err`, `Error(message, { cause: this.inner })` if `Ok`
     */
    expectErr(message) {
        this.ignore();
        throw new Error(message, { cause: this.inner });
    }
    /**
     * Get the inner value or panic
     * @returns `this.inner` if `Ok`
     * @throws `this.inner` if `Err`
     */
    unwrap() {
        this.ignore();
        return this.inner;
    }
    /**
     * Get the inner error or panic
     * @returns `this.inner` if `Err`
     * @throws `this.inner` if `Ok`
     */
    unwrapErr() {
        this.ignore();
        throw this.inner;
    }
    /**
     * Get the inner value or a default one
     * @param value
     * @returns `this.inner` if `Ok`, `value` if `Err`
     */
    unwrapOr(value) {
        this.ignore();
        return this.inner;
    }
    /**
     * Get the inner value or compute a default one from the inner error
     * @param errMapper
     * @returns `this.inner` if `Ok`, `await errMapper(this.inner)` if `Err`
     * @throws if `await errMapper(this.inner)` throws
     */
    async unwrapOrElse(errMapper) {
        this.ignore();
        return this.inner;
    }
    /**
     * Get the inner value or compute a default one from the inner error
     * @param errMapper
     * @returns `this.inner` if `Ok`, `errMapper(this.inner)` if `Err`
     * @throws if `errMapper(this.inner)` throws
     */
    unwrapOrElseSync(errMapper) {
        this.ignore();
        return this.inner;
    }
    /**
     * Transform Result<Promise<T>, E> into Promise<Result<T, E>>
     * @returns `await this.inner` if `Ok`, `this` if `Err`
     */
    async await() {
        return new Ok(await this.inner);
    }
    /**
     * Transform Result<T, Promise<E>> into Promise<Result<T, E>>
     * @returns `await this.inner` if `Err`, `this` if `Ok`
     */
    async awaitErr() {
        return this;
    }
    /**
     * Transform Result<Promise<T>, Promise<E>> into Promise<Result<T, E>>
     * @returns `await this.inner`
     */
    async awaitAll() {
        return await this.await();
    }
    /**
     * Transform `Result<T, E>` into `Result<void, E>`
     * @returns `Ok<void>` if `Ok<T>`, `Err<E>` if `E<E>`
     */
    clear() {
        this.ignore();
        return Ok.void();
    }
    /**
     * Transform `Result<T, E>` into `Result<T, void>`
     * @returns `Ok<T>` if `Ok<T>`, `Err<void>` if `E<E>`
     */
    clearErr() {
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Ok`
     * @param okCallback
     * @returns `this`
     */
    async inspect(okCallback) {
        await okCallback(this.inner);
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Ok`
     * @param okCallback
     * @returns `this`
     */
    inspectSync(okCallback) {
        okCallback(this.inner);
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Err`
     * @param errCallback
     * @returns `this`
     */
    async inspectErr(errCallback) {
        return this;
    }
    /**
     * Calls the given callback with the inner value if `Err`
     * @param errCallback
     * @returns `this`
     */
    inspectErrSync(errCallback) {
        return this;
    }
    /**
     * Return a new `Ok` but with the given `inner`
     * @param inner
     * @returns `Ok(inner)` if `Ok`, `this` if `Err`
     */
    set(inner) {
        return new Ok(inner);
    }
    /**
     * Return a new `Err` but with the given `inner`
     * @param inner
     * @returns `Err(inner)` if `Err`, `this` if `Ok`
     */
    setErr(inner) {
        return this;
    }
    /**
     * Map the inner value into another
     * @param okMapper
     * @returns `Ok(await okMapper(this.inner))` if `Ok`, `this` if `Err`
     * @throws if `await okMapper(this.inner)` throws
     */
    async map(okMapper) {
        this.ignore();
        return new Ok(await okMapper(this.inner));
    }
    /**
     * Map the inner value into another
     * @param okMapper
     * @returns `Ok(okMapper(this.inner))` if `Ok`, `this` if `Err`
     * @throws if `okMapper(this.inner)` throws
     */
    mapSync(okMapper) {
        this.ignore();
        return new Ok(okMapper(this.inner));
    }
    /**
     * Map the inner error into another
     * @param errMapper
     * @returns `Err(await errMapper(this.inner))` if `Err`, `this` if `Ok`
     * @throws if `await errMapper(this.inner)` throws
     */
    async mapErr(errMapper) {
        return this;
    }
    /**
     * Map the inner error into another
     * @param errMapper
     * @returns `Err(errMapper(this.inner))` if `Err`, `this` if `Ok`
     * @throws if `errMapper(this.inner)` throws
     */
    mapErrSync(errMapper) {
        return this;
    }
    /**
     * Map the inner value into another, or a default one
     * @param value
     * @param okMapper
     * @returns `await okMapper(this.inner)` if `Ok`, `value` if `Err`
     * @throws if `await okMapper(this.inner)` throws
     */
    async mapOr(value, okMapper) {
        this.ignore();
        return await okMapper(this.inner);
    }
    /**
     * Map the inner value into another, or a default one
     * @param value
     * @param okMapper
     * @returns `okMapper(this.inner)` if `Ok`, `value` if `Err`
     * @throws if `okMapper(this.inner)` throws
     */
    mapOrSync(value, okMapper) {
        this.ignore();
        return okMapper(this.inner);
    }
    /**
     * Map the inner value into another, or a default one
     * @param errMapper
     * @param okMapper
     * @returns `await okMapper(this.inner)` if `Ok`, `await errMapper(this.inner)` if `Err`
     * @throws if `await okMapper(this.inner)` or `await errMapper(this.inner)` throws
     */
    async mapOrElse(errMapper, okMapper) {
        this.ignore();
        return await okMapper(this.inner);
    }
    /**
     * Map the inner value into another, or a default one
     * @param errMapper
     * @param okMapper
     * @returns `okMapper(this.inner)` if `Ok`, `errMapper(this.inner)` if `Err`
     * @throws if `okMapper(this.inner)` or `errMapper(this.inner)` throws
     */
    mapOrElseSync(errMapper, okMapper) {
        this.ignore();
        return okMapper(this.inner);
    }
    /**
     * Return `value` if `Ok`, return `this` if `Err`
     * @param value
     * @returns `value` if `Ok`, `this` if `Err`
     */
    and(value) {
        this.ignore();
        return value;
    }
    /**
     * Return `await okMapper(this.inner)` if `Ok`, return `this` if `Err`
     * @param okMapper
     * @returns `await okMapper(this.inner)` if `Ok`, `this` if `Err`
     * @throws if `await okMapper(this.inner)` throws
     */
    async andThen(okMapper) {
        this.ignore();
        return await okMapper(this.inner);
    }
    /**
     * Return `okMapper(this.inner)` if `Ok`, return `this` if `Err`
     * @param okMapper
     * @returns `okMapper(this.inner)` if `Ok`, `this` if `Err`
     * @throws if `okMapper(this.inner)` throws
     */
    andThenSync(okMapper) {
        this.ignore();
        return okMapper(this.inner);
    }
    /**
     * Return `value` if `Err`, return `this` if `Ok`
     * @param value
     * @returns `value` if `Err`, `this` if `Ok`
     */
    or(value) {
        return this;
    }
    /**
     * Return `await errMapper(this.inner)` if `Err`, return `this` if `Ok`
     * @param errMapper
     * @returns `await errMapper(this.inner)` if `Err`, `this` if `Ok`
     * @throws if `await errMapper(this.inner)` throws
     */
    async orElse(errMapper) {
        return this;
    }
    /**
     * Return `errMapper(this.inner)` if `Err`, return `this` if `Ok`
     * @param errMapper
     * @returns `errMapper(this.inner)` if `Err`, `this` if `Ok`
     * @throws if `errMapper(this.inner)` throws
     */
    orElseSync(errMapper) {
        return this;
    }
    /**
     * Transform Result<Result<T, E1>, E2> into Result<T, E1 | E2>
     * @param result
     * @returns `this` if `Err`, `this.inner` if `Ok`
     */
    flatten() {
        return this.inner;
    }
}


//# sourceMappingURL=ok.mjs.map


/***/ }),

/***/ 452:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  x: () => (/* binding */ Result)
});

// EXTERNAL MODULE: ./node_modules/@hazae41/option/dist/esm/mods/option/none.mjs
var none = __webpack_require__(371);
// EXTERNAL MODULE: ./node_modules/@hazae41/option/dist/esm/mods/option/some.mjs
var some = __webpack_require__(862);
;// CONCATENATED MODULE: ./node_modules/@hazae41/option/dist/esm/mods/option/option.mjs



var Option;
(function (Option) {
    function from(init) {
        if ("inner" in init)
            return new some/* Some */.b(init.inner);
        return new none/* None */.H();
    }
    Option.from = from;
    /**
     * Create an Option from a nullable value
     * @param inner
     * @returns `Some<T>` if `T`, `None` if `undefined`
     */
    function wrap(inner) {
        if (inner == null)
            return new none/* None */.H();
        return new some/* Some */.b(inner);
    }
    Option.wrap = wrap;
    async function map(inner, mapper) {
        return Option.wrap(inner).map(mapper).then(o => o.get());
    }
    Option.map = map;
    function mapSync(inner, mapper) {
        return Option.wrap(inner).mapSync(mapper).get();
    }
    Option.mapSync = mapSync;
    function unwrap(inner) {
        return Option.wrap(inner).unwrap();
    }
    Option.unwrap = unwrap;
})(Option || (Option = {}));


//# sourceMappingURL=option.mjs.map

// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/err.mjs
var err = __webpack_require__(166);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/errors.mjs
var errors = __webpack_require__(564);
// EXTERNAL MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/ok.mjs
var ok = __webpack_require__(591);
;// CONCATENATED MODULE: ./node_modules/@hazae41/result/dist/esm/mods/result/result.mjs





var Result;
(function (Result) {
    Result.debug = false;
    /**
     * Create a Result from a maybe Error value
     * @param inner
     * @returns `Ok<T>` if `T`, `Err<Error>` if `Error`
     */
    function from(inner) {
        if (inner instanceof Error)
            return new err/* Err */.U(inner);
        else
            return new ok.Ok(inner);
    }
    Result.from = from;
    /**
     * Create a Result from a boolean
     * @param value
     * @returns
     */
    function assert(value) {
        return value ? ok.Ok.void() : err/* Err */.U.void();
    }
    Result.assert = assert;
    function rewrap(wrapper) {
        try {
            return new ok.Ok(wrapper.unwrap());
        }
        catch (error) {
            return new err/* Err */.U(error);
        }
    }
    Result.rewrap = rewrap;
    /**
     * Catch an Err thrown from Err.throw
     * @param callback
     * @param type
     * @returns `Ok<T>` if no `Err` was thrown, `Err<E>` otherwise
     * @see Err.throw
     */
    async function unthrow(callback) {
        let ref;
        try {
            return await callback((e) => ref = e);
        }
        catch (e) {
            if (ref !== undefined)
                return ref;
            throw e;
        }
    }
    Result.unthrow = unthrow;
    /**
     * Catch an Err thrown from Err.throw
     * @param callback
     * @param type
     * @returns `Ok<T>` if no `Err` was thrown, `Err<E>` otherwise
     * @see Err.throw
     */
    function unthrowSync(callback) {
        let ref;
        try {
            return callback((e) => ref = e);
        }
        catch (e) {
            if (ref !== undefined)
                return ref;
            throw e;
        }
    }
    Result.unthrowSync = unthrowSync;
    /**
     * Run a callback and wrap any returned value in Ok<T> and any thrown error in Err<unknown>
     * @param callback
     * @returns
     */
    async function runAndWrap(callback) {
        try {
            return new ok.Ok(await callback());
        }
        catch (e) {
            return new err/* Err */.U(e);
        }
    }
    Result.runAndWrap = runAndWrap;
    /**
     * Run a callback and wrap any returned value in Ok<T> and any thrown error in Err<unknown>
     * @param callback
     * @returns
     */
    function runAndWrapSync(callback) {
        try {
            return new ok.Ok(callback());
        }
        catch (e) {
            return new err/* Err */.U(e);
        }
    }
    Result.runAndWrapSync = runAndWrapSync;
    /**
     * Run a callback and wrap any returned value in Ok<T> and any thrown error in Err<Catched>
     * @param callback
     * @returns
     */
    async function runAndDoubleWrap(callback) {
        try {
            return new ok.Ok(await callback());
        }
        catch (e) {
            return new err/* Err */.U(errors/* Catched */.$.wrap(e));
        }
    }
    Result.runAndDoubleWrap = runAndDoubleWrap;
    /**
     * Run a callback and wrap any returned value in Ok<T> and any thrown error in Err<Catched>
     * @param callback
     * @returns
     */
    function runAndDoubleWrapSync(callback) {
        try {
            return new ok.Ok(callback());
        }
        catch (e) {
            return new err/* Err */.U(errors/* Catched */.$.wrap(e));
        }
    }
    Result.runAndDoubleWrapSync = runAndDoubleWrapSync;
    /**
     * Run a callback and wrap any thrown error in Err<unknown>
     * @param callback
     * @returns
     */
    async function runOrWrap(callback) {
        try {
            return await callback();
        }
        catch (e) {
            return new err/* Err */.U(e);
        }
    }
    Result.runOrWrap = runOrWrap;
    /**
     * Run a callback and wrap any thrown error in Err<unknown>
     * @param callback
     * @returns
     */
    function runOrWrapSync(callback) {
        try {
            return callback();
        }
        catch (e) {
            return new err/* Err */.U(e);
        }
    }
    Result.runOrWrapSync = runOrWrapSync;
    /**
     * Run a callback and wrap any thrown error in Err<unknown>
     * @param callback
     * @returns
     */
    async function runOrDoubleWrap(callback) {
        try {
            return await callback();
        }
        catch (e) {
            return new err/* Err */.U(errors/* Catched */.$.wrap(e));
        }
    }
    Result.runOrDoubleWrap = runOrDoubleWrap;
    /**
     * Run a callback and wrap any thrown error in Err<unknown>
     * @param callback
     * @returns
     */
    function runOrDoubleWrapSync(callback) {
        try {
            return callback();
        }
        catch (e) {
            return new err/* Err */.U(errors/* Catched */.$.wrap(e));
        }
    }
    Result.runOrDoubleWrapSync = runOrDoubleWrapSync;
    /**
     * Transform `Iterable<Result<T,E>` into `Result<Array<T>, E>`
     * @param iterable
     * @returns `Result<Array<T>, E>`
     */
    function all(iterable) {
        return collect(iterate(iterable));
    }
    Result.all = all;
    function maybeAll(iterable) {
        return maybeCollect(maybeIterate(iterable));
    }
    Result.maybeAll = maybeAll;
    /**
     * Transform `Iterable<Result<T,E>` into `Iterator<T, Result<void, E>>`
     * @param iterable
     * @returns `Iterator<T, Result<void, E>>`
     */
    function* iterate(iterable) {
        for (const result of iterable) {
            if (result.isOk())
                yield result.get();
            else
                return result;
        }
        return ok.Ok.void();
    }
    Result.iterate = iterate;
    function* maybeIterate(iterable) {
        for (const result of iterable) {
            if (result == null)
                return result;
            else if (result.isOk())
                yield result.get();
            else
                return result;
        }
        return ok.Ok.void();
    }
    Result.maybeIterate = maybeIterate;
    /**
     * Transform `Iterator<T, Result<void, E>>` into `Result<Array<T>, E>`
     * @param iterator `Result<Array<T>, E>`
     */
    function collect(iterator) {
        const array = new Array();
        let result = iterator.next();
        for (; !result.done; result = iterator.next())
            array.push(result.value);
        return result.value.set(array);
    }
    Result.collect = collect;
    function maybeCollect(iterator) {
        const array = new Array();
        let result = iterator.next();
        for (; !result.done; result = iterator.next())
            array.push(result.value);
        return Option.mapSync(result.value, result => result.set(array));
    }
    Result.maybeCollect = maybeCollect;
})(Result || (Result = {}));


//# sourceMappingURL=result.mjs.map


/***/ }),

/***/ 168:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   C$: () => (/* binding */ rejectOnAbort),
/* harmony export */   Fi: () => (/* binding */ never)
/* harmony export */ });
/* unused harmony exports merge, resolveOnAbort */
/* harmony import */ var _hazae41_disposer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(180);
/* harmony import */ var _hazae41_future__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(71);



function never() {
    return new AbortController().signal;
}
function merge(a, b) {
    if (b == null)
        return a;
    if (a.aborted)
        return a;
    if (b.aborted)
        return b;
    const c = new AbortController();
    const onAbort = (reason) => {
        c.abort(reason);
        a.removeEventListener("abort", onAbort);
        b.removeEventListener("abort", onAbort);
    };
    a.addEventListener("abort", onAbort, { passive: true });
    b.addEventListener("abort", onAbort, { passive: true });
    return c.signal;
}
function resolveOnAbort(signal) {
    if (signal.aborted)
        return new Disposer(Promise.resolve(), () => { });
    const resolveOnAbort = new Future();
    const onAbort = () => resolveOnAbort.resolve();
    const onClean = () => signal.removeEventListener("abort", onAbort);
    signal.addEventListener("abort", onAbort, { passive: true });
    resolveOnAbort.promise.then(onClean).then(() => { throw new Error("Aborted"); });
    return new Disposer(resolveOnAbort.promise, onClean);
}
function rejectOnAbort(signal) {
    if (signal.aborted)
        return new _hazae41_disposer__WEBPACK_IMPORTED_MODULE_0__/* .Disposer */ .k(Promise.reject(new Error("Aborted")), () => { });
    const rejectOnAbort = new _hazae41_future__WEBPACK_IMPORTED_MODULE_1__/* .Future */ .o();
    const onAbort = () => rejectOnAbort.reject(new Error("Aborted"));
    const onClean = () => signal.removeEventListener("abort", onAbort);
    signal.addEventListener("abort", onAbort, { passive: true });
    rejectOnAbort.promise.catch(onClean);
    return new _hazae41_disposer__WEBPACK_IMPORTED_MODULE_0__/* .Disposer */ .k(rejectOnAbort.promise, onClean);
}


//# sourceMappingURL=index.mjs.map


/***/ }),

/***/ 801:
/***/ (() => {


;// CONCATENATED MODULE: ./node_modules/@hazae41/symbol-dispose-polyfill/dist/esm/mods/symbol-dispose-polyfill/polyfill.mjs
if (typeof Symbol.dispose !== "symbol")
    Object.defineProperty(Symbol, "dispose", {
        configurable: false,
        enumerable: false,
        writable: false,
        value: Symbol.for("dispose")
    });
if (typeof Symbol.asyncDispose !== "symbol")
    Object.defineProperty(Symbol, "asyncDispose", {
        configurable: false,
        enumerable: false,
        writable: false,
        value: Symbol.for("asyncDispose")
    });
//# sourceMappingURL=polyfill.mjs.map

;// CONCATENATED MODULE: ./node_modules/@hazae41/symbol-dispose-polyfill/dist/esm/index.mjs

//# sourceMappingURL=index.mjs.map


/***/ }),

/***/ 748:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   J: () => (/* binding */ _class_extract_field_descriptor)
/* harmony export */ });
/* unused harmony export _ */
function _class_extract_field_descriptor(receiver, privateMap, action) {
    if (!privateMap.has(receiver)) throw new TypeError("attempted to " + action + " private field on non-instance");

    return privateMap.get(receiver);
}



/***/ }),

/***/ 605:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  _: () => (/* binding */ _class_private_field_get)
});

// UNUSED EXPORTS: _class_private_field_get

;// CONCATENATED MODULE: ./node_modules/@swc/helpers/esm/_class_apply_descriptor_get.js
function _class_apply_descriptor_get(receiver, descriptor) {
    if (descriptor.get) return descriptor.get.call(receiver);

    return descriptor.value;
}


// EXTERNAL MODULE: ./node_modules/@swc/helpers/esm/_class_extract_field_descriptor.js
var _class_extract_field_descriptor = __webpack_require__(748);
;// CONCATENATED MODULE: ./node_modules/@swc/helpers/esm/_class_private_field_get.js



function _class_private_field_get(receiver, privateMap) {
    var descriptor = (0,_class_extract_field_descriptor/* _class_extract_field_descriptor */.J)(receiver, privateMap, "get");
    return _class_apply_descriptor_get(receiver, descriptor);
}



/***/ }),

/***/ 76:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  _: () => (/* binding */ _class_private_field_init)
});

// UNUSED EXPORTS: _class_private_field_init

;// CONCATENATED MODULE: ./node_modules/@swc/helpers/esm/_check_private_redeclaration.js
function _check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}


;// CONCATENATED MODULE: ./node_modules/@swc/helpers/esm/_class_private_field_init.js


function _class_private_field_init(obj, privateMap, value) {
    _check_private_redeclaration(obj, privateMap);
    privateMap.set(obj, value);
}



/***/ }),

/***/ 941:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  _: () => (/* binding */ _class_private_field_set)
});

// UNUSED EXPORTS: _class_private_field_set

;// CONCATENATED MODULE: ./node_modules/@swc/helpers/esm/_class_apply_descriptor_set.js
function _class_apply_descriptor_set(receiver, descriptor, value) {
    if (descriptor.set) descriptor.set.call(receiver, value);
    else {
        if (!descriptor.writable) {
            // This should only throw in strict mode, but class bodies are
            // always strict and private fields can only be used inside
            // class bodies.
            throw new TypeError("attempted to set read only private field");
        }
        descriptor.value = value;
    }
}


// EXTERNAL MODULE: ./node_modules/@swc/helpers/esm/_class_extract_field_descriptor.js
var _class_extract_field_descriptor = __webpack_require__(748);
;// CONCATENATED MODULE: ./node_modules/@swc/helpers/esm/_class_private_field_set.js



function _class_private_field_set(receiver, privateMap, value) {
    var descriptor = (0,_class_extract_field_descriptor/* _class_extract_field_descriptor */.J)(receiver, privateMap, "set");
    _class_apply_descriptor_set(receiver, descriptor, value);
    return value;
}



/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/async module */
/******/ 	(() => {
/******/ 		var webpackQueues = typeof Symbol === "function" ? Symbol("webpack queues") : "__webpack_queues__";
/******/ 		var webpackExports = typeof Symbol === "function" ? Symbol("webpack exports") : "__webpack_exports__";
/******/ 		var webpackError = typeof Symbol === "function" ? Symbol("webpack error") : "__webpack_error__";
/******/ 		var resolveQueue = (queue) => {
/******/ 			if(queue && !queue.d) {
/******/ 				queue.d = 1;
/******/ 				queue.forEach((fn) => (fn.r--));
/******/ 				queue.forEach((fn) => (fn.r-- ? fn.r++ : fn()));
/******/ 			}
/******/ 		}
/******/ 		var wrapDeps = (deps) => (deps.map((dep) => {
/******/ 			if(dep !== null && typeof dep === "object") {
/******/ 				if(dep[webpackQueues]) return dep;
/******/ 				if(dep.then) {
/******/ 					var queue = [];
/******/ 					queue.d = 0;
/******/ 					dep.then((r) => {
/******/ 						obj[webpackExports] = r;
/******/ 						resolveQueue(queue);
/******/ 					}, (e) => {
/******/ 						obj[webpackError] = e;
/******/ 						resolveQueue(queue);
/******/ 					});
/******/ 					var obj = {};
/******/ 					obj[webpackQueues] = (fn) => (fn(queue));
/******/ 					return obj;
/******/ 				}
/******/ 			}
/******/ 			var ret = {};
/******/ 			ret[webpackQueues] = x => {};
/******/ 			ret[webpackExports] = dep;
/******/ 			return ret;
/******/ 		}));
/******/ 		__webpack_require__.a = (module, body, hasAwait) => {
/******/ 			var queue;
/******/ 			hasAwait && ((queue = []).d = 1);
/******/ 			var depQueues = new Set();
/******/ 			var exports = module.exports;
/******/ 			var currentDeps;
/******/ 			var outerResolve;
/******/ 			var reject;
/******/ 			var promise = new Promise((resolve, rej) => {
/******/ 				reject = rej;
/******/ 				outerResolve = resolve;
/******/ 			});
/******/ 			promise[webpackExports] = exports;
/******/ 			promise[webpackQueues] = (fn) => (queue && fn(queue), depQueues.forEach(fn), promise["catch"](x => {}));
/******/ 			module.exports = promise;
/******/ 			body((deps) => {
/******/ 				currentDeps = wrapDeps(deps);
/******/ 				var fn;
/******/ 				var getResult = () => (currentDeps.map((d) => {
/******/ 					if(d[webpackError]) throw d[webpackError];
/******/ 					return d[webpackExports];
/******/ 				}))
/******/ 				var promise = new Promise((resolve) => {
/******/ 					fn = () => (resolve(getResult));
/******/ 					fn.r = 0;
/******/ 					var fnQueue = (q) => (q !== queue && !depQueues.has(q) && (depQueues.add(q), q && !q.d && (fn.r++, q.push(fn))));
/******/ 					currentDeps.map((dep) => (dep[webpackQueues](fnQueue)));
/******/ 				});
/******/ 				return fn.r ? promise : getResult();
/******/ 			}, (err) => ((err ? reject(promise[webpackError] = err) : outerResolve(exports)), resolveQueue(queue)));
/******/ 			queue && (queue.d = 0);
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module used 'module' so it can't be inlined
/******/ 	var __webpack_exports__ = __webpack_require__(880);
/******/ 	
/******/ })()
;